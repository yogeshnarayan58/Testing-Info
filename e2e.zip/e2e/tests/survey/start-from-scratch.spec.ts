import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory, closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartFromScratchPage } from '../../page-objects/survey/start-from-scratch.page';
import { StartWithPromptPage } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { SurveyBuilderPage } from '../../page-objects/common/survey-builder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import { MEDIUM_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';
import {registerEditSurveyTitleTest,registerRequiredStarTest,registerEditQuestionTextTest,
  registerDiscardSaveChangesTest,registerCancelAddQuestionTest,registerDragDropTest,
  registerDeleteDuplicateQuestionTest,registerReviewModeTest,registerReviewModeDeleteAllTest,
  registerAddSingleChoiceQuestionTest,registerAddMultipleChoiceQuestionTest,registerAddRatingQuestionTest,
  registerAddNPSQuestionTest,registerAddPointScaleQuestionTest,registerAddMultiScaleQuestionTest,
  registerStepperNavigationTest,registerValidateDisabledUnderThreeTest,registerSaveDraftTest,
  registerValidateSurveyTest,registerOptionBoundaryTest,
  registerDiscardNewQuestionThenSaveTest,registerDeleteLastThenReAddTest,ensureAtLeastOneQuestion,
  registerEmptyQuestionTextBlocksSaveTest,registerSaveDraftEmptyTitleTest,
  registerReviewSurveyDetailsEditTest,registerPublishSavedSurveyTest,registerSavedSurveyInMyAssetsTest,
} from './common-test-cases/build-survey-common-test-cases';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Start from scratch', { tag: '@StartFromScratch' }, () => {
  let basePage: BasePage;
  let surveyPage: StartFromScratchPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'start-from-scratch-video');
    }
  });

  test(
    'Start from Scratch: Should display the Start from scratch option on the survey home page',
    { tag: '@LandStartFromScratch' },
    async () => {
      basePage = await BasePageFactory.createBasePage();
      surveyPage = new StartFromScratchPage(basePage);

      await surveyPage.navigateToSurvey();

      const isStartFromScratchVisible = await surveyPage.isStartFromScratchVisibleAfterReload();
      assertTrue(isStartFromScratchVisible, '"Start from scratch" option not visible after navigating to survey');

      await surveyPage.clickStartFromScratch();
    }
  );

  test('Dataset Selection: Should select the dataset and confirm the Choose a dataset screen', { tag: '@DatasetSelection' }, async () => {
    await surveyPage.selectProductOffering('');
    const isDatasetSelectionConfirmed = await surveyPage.searchAndSelectDataset(datasetConfig.searchTerm, String(DATASET_NAME));

    assertTrue(isDatasetSelectionConfirmed, `Expected "Choose a dataset" confirmation not visible after selecting ${DATASET_NAME}`);

    await surveyPage.proceedToNextAfterDatasetSelection();
    await surveyPage.applyEntireDataset();
  });

  test('Panelist Filters: Should enable Search for Panelists after all 5 filters are set', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should enable Proceed to survey builder after selecting a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.clickSearchForPanelists();
    await selectPanelistPage.click250Responses();

    const isProceedToSurveyBuilderVisible = await selectPanelistPage.isProceedToSurveyBuilderVisible();
    assertTrue(isProceedToSurveyBuilderVisible, 'Proceed to survey builder button not visible after selecting 250 responses');
  });

  test('Survey Builder: Should navigate to the Build Survey page after proceeding', { tag: '@ProceedToSurveyBuilder' }, async () => {
    await selectPanelistPage.clickProceedToSurveyBuilder();
    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after proceeding');
  });

  test(
    'TC_BS_01: First landing shows "Untitled Survey" and the Add question panel',
    { tag: '@EmptyState' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(basePage);

      const titleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
      assertTrue(titleDisplay === 'Untitled Survey', `Expected survey title to be "Untitled Survey", got "${titleDisplay}"`);
      assertTrue(
        await surveyBuilderPage.areAddQuestionOptionsVisible(),
        'Expected Add Question options visible on first landing'
      );
    }
  );

  registerSaveDraftEmptyTitleTest({ getBasePage: () => basePage });

  registerEditSurveyTitleTest({ getBasePage: () => basePage }, { title: 'TC_BS_02: Edit survey title', tag: '@EditSurveyTitle' });

  registerAddSingleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03a: Add a Single Choice question', tag: '@SingleChoiceQuestion' }
  );

  registerAddMultipleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03b: Add a Multiple Choice question', tag: '@MultipleChoiceQuestion' }
  );

  registerAddRatingQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03c: Add a Rating question', tag: '@RatingQuestion' });

  registerAddNPSQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03d: Add an NPS question', tag: '@NPSQuestion' });

  registerAddPointScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03e: Add a Point Scale question', tag: '@PointScaleQuestion' }
  );

  registerAddMultiScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03f: Add a Multi Scale question', tag: '@MultiScaleQuestion' }
  );

  registerRequiredStarTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_07: Required star appears when the Required toggle is on', tag: '@RequiredStar' }
  );

  registerEditQuestionTextTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_25: Edit question text via the pencil icon', tag: '@EditQuestion' }
  );

  registerDiscardSaveChangesTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_26: Discard / Save changes on an existing question', tag: '@DiscardSave' }
  );

  registerEmptyQuestionTextBlocksSaveTest({ getBasePage: () => basePage });

  registerCancelAddQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_05: Cancelling Add Question leaves the question count unchanged', tag: '@CancelAddQuestion' }
  );

  registerDragDropTest({ getBasePage: () => basePage }, { title: 'TC_BS_15: Drag and drop reorders questions', tag: '@DragDrop' });

  registerDeleteDuplicateQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_06: Delete and duplicate a question via hover row actions', tag: '@DeleteDuplicate' }
  );

  registerOptionBoundaryTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_04: Options boundary - min 2, max 15', tag: '@OptionBoundary' }
  );

  registerStepperNavigationTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey', tag: '@StepperNavigation' }
  );

  test('TC_BS_08: Max questions (10) disables Add question and Duplicate with limit message', { tag: '@MaxQuestions' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText: ratingText } = testData.surveyQuestions.rating;

    try {
      let questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      while (questionNumbers.length < 10) {
        const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
        if (addQuestionState.disabled) {
          break;
        }
        await surveyBuilderPage.openAddQuestionPanel();
        await surveyBuilderPage.addRatingQuestion(ratingText);
        questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      }

      assertTrue(questionNumbers.length === 10, `Expected 10 questions, got ${questionNumbers.length}: ${JSON.stringify(questionNumbers)}`);

      assertTrue(await surveyBuilderPage.isAddQuestionTooltipVisibleOnHover(), 'limit message after hover on add');
      const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
      assertTrue(addQuestionState.disabled, `add-question disabled (class="${addQuestionState.classAttr}")`);

      assertTrue(await surveyBuilderPage.isDuplicateTooltipVisibleOnHover(), 'limit message after hover on duplicate');
      const duplicateState = await surveyBuilderPage.getDuplicateDisabledState();
      assertTrue(duplicateState.disabled, `duplicate disabled (outerHTML="${duplicateState.outerHtml}")`);

      const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(questionNumbersAfter.length === 10, 'count stays 10');
    } catch (error) {
      throw new Error(`Failed to verify max-questions limit: ${error instanceof Error ? error.message : error}`);
    }
  });

  registerReviewModeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit', tag: '@ReviewMode' }
  );

  registerSaveDraftTest({ getBasePage: () => basePage }, { title: 'TC_BS_10: Save survey as draft', tag: '@SaveDraft' });

  registerValidateSurveyTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_23: Validate survey: Completes and shows Optiq feedback when there are recommendations', tag: '@ValidateSurvey' }
  );

  test('TC_AI_12: No Optiq-AI action buttons are visible in the Start From Scratch builder', { tag: '@StartFromScratch' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await ensureAtLeastOneQuestion(surveyBuilderPage);

    const promptPage = new StartWithPromptPage(basePage);
    await promptPage.hoverQuestionRow(0);

    assertTrue(
      await promptPage.areAiButtonsHidden(),
      'Expected no rephrase/generate/reprompt AI buttons visible outside the AI-generated flow'
    );
  });

  registerDiscardNewQuestionThenSaveTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_22: Discard a new question via Add Question cancel, then add and save one', tag: '@CancelAddQuestion' }
  );

  registerDeleteLastThenReAddTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_20: Delete the last question then re-add the same type as last', tag: '@DeleteDuplicate' }
  );

  // Publish (TC_BS_16/18) runs near the end of this flow, after the builder tests, because publishing redirects to My assets.
  registerReviewSurveyDetailsEditTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_29: Review survey details dialog, Edit survey returns to Build Survey', tag: '@ReviewSurveyDetails' }
  );

  registerReviewModeDeleteAllTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_27: Review Mode select all, delete all, stay on Build Survey', tag: '@ReviewModeDeleteAll' }
  );

  registerValidateDisabledUnderThreeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_09: Validate survey is disabled with fewer than 3 questions', tag: '@ValidateDisabled' }
  );

  test('TC_BS_12: Back button returns to the previous step from the builder', { tag: '@BackButton' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await surveyBuilderPage.clickBackButton();

    const isProceedToSurveyBuilderVisible = await selectPanelistPage.isProceedToSurveyBuilderVisible();
    assertTrue(isProceedToSurveyBuilderVisible, 'Expected Proceed to survey builder button (previous step) visible after clicking Back');

    const currentUrl = await surveyBuilderPage.getCurrentUrl();
    assertTrue(currentUrl.includes('select-panelist'), `Expected URL to contain "select-panelist" after clicking Back, got: ${currentUrl}`);
  });

  test('Setup: Return to Build Survey and restore at least three questions', { tag: '@PublishSetup' }, async () => {
    await selectPanelistPage.clickProceedToSurveyBuilder();
    assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Build Survey page did not load after proceeding');

    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText: ratingText } = testData.surveyQuestions.rating;
    const waitForQuestionCountAtLeast = async (target: number): Promise<number> => {
      const deadline = Date.now() + MEDIUM_TIMEOUT;
      let count = await surveyBuilderPage.getQuestionCount();
      while (count < target && Date.now() < deadline) {
        await basePage.getWebActions().delay(UI_STATE_UPDATE_DELAY);
        count = await surveyBuilderPage.getQuestionCount();
      }
      return count;
    };

    let questionCount = await surveyBuilderPage.getQuestionCount();
    if (questionCount === 0) {
      // The empty builder remembers the last selected type (Single Choice), so clicking that tile again opens no editor: start with Rating.
      // addRatingQuestion ends with clickAddQuestion(), which does not exist in the empty state; the text is already entered by then.
      try {
        await surveyBuilderPage.addRatingQuestion(ratingText);
      } catch (error) {
        if (!(error instanceof Error && error.message.includes('Failed to click add question'))) {
          throw error;
        }
      }
      // The first question of an empty builder is saved by a click outside the card (the inline editor listens for document clicks).
      await surveyBuilderPage.saveQuestionChanges();
      questionCount = await waitForQuestionCountAtLeast(1);
      assertTrue(questionCount >= 1, `Expected the first question to be saved, found ${questionCount} questions`);
    }
    while (questionCount < 3) {
      await surveyBuilderPage.openAddQuestionPanel();
      await surveyBuilderPage.addRatingQuestion(ratingText);
      questionCount = await waitForQuestionCountAtLeast(questionCount + 1);
    }
    assertTrue(questionCount >= 3, `Expected at least 3 questions, found ${questionCount}`);
  });

  test('Setup: Save the draft into My Assets again', { tag: '@PublishSetup' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickSaveDraftAndWaitForDialog();
    assertTrue(await surveyBuilderPage.isSaveDraftDialogVisible(), 'Expected "Save your survey" dialog to be visible after clicking Save draft');

    await surveyBuilderPage.fillSaveDraftDialogName(testData.surveyNames.saveDraftDialog);
    // The app saves only into a real folder (one with an asset id), so pick the folder TC_BS_10a created, not the "My Assets" root row.
    const folderName = testData.folders.newFolder;
    assertTrue(
      await surveyBuilderPage.ensureSaveDraftDialogFolderListed(folderName),
      `Expected folder "${folderName}" to be listed in the "Save your survey" dialog`
    );
    await surveyBuilderPage.clickSaveDraftDialogFolder(folderName);
    assertTrue(
      !(await surveyBuilderPage.isSaveDraftDialogSaveButtonDisabled()),
      `Expected the dialog's Save draft button to be enabled after entering a name and selecting "${folderName}"`
    );
    await surveyBuilderPage.clickSaveDraftDialogSaveButton();

    assertTrue(
      await surveyBuilderPage.isDraftSavedToastVisible(),
      'Expected "Survey saved as draft successfully" toast to be visible after saving draft'
    );
  });

  registerPublishSavedSurveyTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_16/TC_BS_18: Publish survey', tag: '@PublishSurvey' }
  );

  registerSavedSurveyInMyAssetsTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_10c: Saved folder and survey are listed in My assets', tag: '@MyAssets' }
  );
});
