import type { ICellRendererParams } from 'ag-grid-community';
import { describe, expect, it, vi } from 'vitest';
import type { QuestionRow } from '../question.model';
import { ExpandIconRendererComponent } from './expand-icon-renderer.component';

describe('ExpandIconRendererComponent', () => {
  it('tracks expanded state and delegates toggles for the related detail panel', () => {
    const onToggle = vi.fn();
    const stopPropagation = vi.fn();
    const component = new ExpandIconRendererComponent();
    component.agInit({
      data: {
        rowType: 'question',
        id: 'q-2',
        expanded: false,
        question: {
          questionNumber: 2,
          question: 'How satisfied are you?',
          type: 'STAR_RATING',
          isRequired: true,
        },
      },
      onToggle,
    } as unknown as ICellRendererParams<QuestionRow> & { onToggle: (questionNumber: number) => void });

    expect(component.isQuestionRow).toBe(true);
    expect(component.expanded).toBe(false);
    expect(component.detailId).toBe('question-detail-2');

    component.onToggle({ stopPropagation } as unknown as Event);

    expect(stopPropagation).toHaveBeenCalledOnce();
    expect(onToggle).toHaveBeenCalledWith(2);
  });

  it('clears question details and skips toggles for non-question rows', () => {
    const component = new ExpandIconRendererComponent();
    const onToggle = vi.fn();
    component.agInit({
      data: { rowType: 'survey', expanded: true },
      onToggle,
    } as unknown as ICellRendererParams<QuestionRow> & { onToggle: (questionNumber: number) => void });

    expect(component.isQuestionRow).toBe(false);
    expect(component.expanded).toBe(true);
    expect(component.detailId).toBe('');

    component.refresh({ data: undefined } as unknown as ICellRendererParams<QuestionRow>);
    component.onToggle({ stopPropagation: vi.fn() } as unknown as Event);

    expect(component.isQuestionRow).toBe(false);
    expect(component.expanded).toBe(false);
    expect(component.detailId).toBe('');
    expect(onToggle).not.toHaveBeenCalled();
  });

  it('refreshes the expanded question details and toggle callback', () => {
    const component = new ExpandIconRendererComponent();
    const previousToggle = vi.fn();
    const nextToggle = vi.fn();
    component.agInit({ data: undefined } as unknown as ICellRendererParams<QuestionRow>);

    expect(component.refresh({
      data: {
        rowType: 'question',
        expanded: true,
        question: { questionNumber: 4 },
      },
      onToggle: nextToggle,
    } as unknown as ICellRendererParams<QuestionRow> & { onToggle: (questionNumber: number) => void })).toBe(true);

    component.onToggle({ stopPropagation: vi.fn() } as unknown as Event);

    expect(component.isQuestionRow).toBe(true);
    expect(component.expanded).toBe(true);
    expect(component.detailId).toBe('question-detail-4');
    expect(previousToggle).not.toHaveBeenCalled();
    expect(nextToggle).toHaveBeenCalledWith(4);
  });
});