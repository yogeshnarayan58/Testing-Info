import { expect, Expect, Locator } from "@playwright/test";
import { ExpectOptions, SoftOption } from "../../constants/optional-parameter-types";
import { getFirstLocator } from "./locator-utils";

/**
 * Asserts that the given element is present in the DOM and visible.
 * @param {string | Locator} input - Either a string (selector) or a Locator object.
 * @param {ExpectOptions} options - The options to pass to the expect function.
 */
export async function expectElementToBeVisible(input: string | Locator, options?: ExpectOptions): Promise<void> {
    const { locator, assert } = getLocatorAndAssert(input, options);
    await assert(locator, options).toBeVisible(options);
  }

  /**
 * Returns a Locator object and an Expect object configured with the given soft option.
 * @param {string | Locator} input - Either a string (selector) or a Locator object.
 * @param {SoftOption} options - The soft option to configure the Expect object with.
 * @returns {Object} - An object containing the Locator and Expect objects.
 */
function getLocatorAndAssert(input: string | Locator, options?: SoftOption): { locator: Locator; assert: Expect } {
    const locator = getFirstLocator(input);
    const assert = getExpectWithSoftOption(options);
    return { locator, assert };
  }

  /**
 * Returns an Expect object configured with the given soft option.
 * @param {SoftOption} options - The soft option to configure the Expect object with.
 * @returns {Expect} - The configured Expect object.
 */
function getExpectWithSoftOption(options?: SoftOption): Expect {
    return expect.configure({ soft: options?.soft });
  }