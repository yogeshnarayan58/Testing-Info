import { BasePage } from '@gfk/gta';
import { CommonPage } from './common-page';
import profilePageResources from '../../locators/survey/profile.locator.json';
import { MEDIUM_TIMEOUT, NAVIGATION_TIMEOUT, PANEL_TRANSITION_DELAY } from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';
import localizationData from '../../test-data/localization-data.json';
import { SurveyLocalizationData } from '../../interfaces/iLocalizationData';
import { findLocaleEntry, getTestDataByLocale } from '../../utils/localization-helper';

const PROFILE_PAGE_COMPONENT_NAME = 'profilePage';
const LAUNCHPAD_RELATIVE_PATH = 'launchpad';
const UNKNOWN_LABEL_PLACEHOLDER = 'TODO';

export class ProfilePage extends CommonPage {
  protected readonly componentName = PROFILE_PAGE_COMPONENT_NAME;

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(PROFILE_PAGE_COMPONENT_NAME, profilePageResources);
  }


  /**
   * With a locale code, language name or country name: returns the language text shown in the language dropdown (e.g. "English (United States)").
   * Without an argument: returns the language currently shown in the Account settings.
   */
  async getLocaleLabel(locale?: string): Promise<string> {
    if (locale !== undefined) {
      const entry = findLocaleEntry<SurveyLocalizationData>(locale, localizationData);
      if (!entry.languageName || entry.languageName === UNKNOWN_LABEL_PLACEHOLDER) {
        throw new Error(`language name for locale '${entry.locale}' is not known yet (TODO in localization-data.json)`);
      }
      return entry.languageName;
    }
    try {
      await this.navigateToProfileSettings();
      const accountTitle = this.webActionHandler.getWebElement(this.getResource('profileAccountTitle'));
      await this.waitUntilVisible(accountTitle, 'Profile account title');

      const languageInput = this.webActionHandler.getWebElement(this.getResource('profileLanguageInput'));
      await this.waitUntilVisible(languageInput, 'Profile language input');
      return ((await languageInput.getText()) ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read the user locale: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Opens the launchpad, opens the account menu and lands on the Account section of the profile settings. */
  async navigateToProfileSettings(): Promise<void> {
    try {
      await this.navigateToUrl(this.buildUrl(envConfig.BASE_URL, LAUNCHPAD_RELATIVE_PATH));
      await this.clickWhenVisible('profileIcon', 'Profile icon', NAVIGATION_TIMEOUT);
      await this.clickWhenVisible('profileSettings', 'Profile settings menu item');
      await this.clickWhenVisible('accountSettings', 'Account settings category');
    } catch (error) {
      throw new Error(`Failed to open the profile settings: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getLaunchpadGreeting(locale: string): string | undefined {
    const greeting = getTestDataByLocale<SurveyLocalizationData>(locale, localizationData).launchpadGreeting;
    return typeof greeting === 'string' && greeting ? greeting : undefined;
  }

  /** Opens the launchpad and waits for the profile icon, i.e. for the app shell to be ready. */
  private async openLaunchpad(): Promise<void> {
    await this.navigateToUrl(this.buildUrl(envConfig.BASE_URL, LAUNCHPAD_RELATIVE_PATH));
    const profileIcon = this.webActionHandler.getWebElement(this.getResource('profileIcon'));
    await this.waitUntilVisible(profileIcon, 'Profile icon', NAVIGATION_TIMEOUT);
  }

  /** True when the launchpad heading ("<greeting>, <name>") is shown in the given locale; false when the locale has no greeting configured. */
  async isAppInLocale(locale: string): Promise<boolean> {
    const greeting = this.getLaunchpadGreeting(locale);
    if (!greeting) {
      return false;
    }
    try {
      await this.openLaunchpad();
      const nativePage = (BasePage as any).page as import('playwright').Page;
      const expectedPrefix = `${greeting},`;
      const headings = nativePage.getByRole('heading', { name: expectedPrefix });
      await headings.first().waitFor({ state: 'visible', timeout: MEDIUM_TIMEOUT });
      const texts = await headings.allTextContents();
      return texts.some((text) => text.trim().startsWith(expectedPrefix));
    } catch {
      return false;
    }
  }

  /** Picks the language in the profile settings and saves; skips when the Account settings already show that language (read directly from the profile language element, never inferred from English wording). Afterwards confirms the switch on the launchpad. Accepts a locale code, language name or country name. */
  async setUserLocale(localeOrName: string): Promise<void> {
    try {
      const { locale } = findLocaleEntry<SurveyLocalizationData>(localeOrName, localizationData);
      const languageName = await this.getLocaleLabel(locale);
      const currentLanguageName = await this.getLocaleLabel();
      if (currentLanguageName.toLowerCase() === languageName.toLowerCase()) {
        console.log(`Already in ${locale}, skipping language switch`);
        return;
      }
      const languageOption = this.webActionHandler.getWebElement(
        this.resourceManager.getMultiDynamicResource('languageOption', { languageName }, this.componentName)
      );
      await this.waitUntilVisible(languageOption, `Language option '${languageName}'`);
      await languageOption.click();
      await this.clickWhenVisible('saveChanges', 'Save changes button');
      const nativePage = (BasePage as any).page as import('playwright').Page; // load-state waits are not exposed by the GTA wrapper
      await nativePage.waitForLoadState('networkidle', { timeout: NAVIGATION_TIMEOUT }).catch(() => undefined);

      if (this.getLaunchpadGreeting(locale)) {
        if (!(await this.isAppInLocale(locale))) {
          await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
          if (!(await this.isAppInLocale(locale))) {
            throw new Error(`the launchpad greeting is not in '${locale}' after saving`);
          }
        }
      } else {
        await this.openLaunchpad();
      }
    } catch (error) {
      throw new Error(`Failed to set the user locale to '${localeOrName}': ${error instanceof Error ? error.message : error}`);
    }
  }
}
