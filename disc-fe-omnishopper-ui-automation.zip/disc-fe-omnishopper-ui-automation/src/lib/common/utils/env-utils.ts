export const resolveEnvValue = (key: string): string | undefined => {
  if (!key || key.trim().length === 0) {
    return undefined;
  }

  const variants = new Set([key, key.toUpperCase(), key.toLowerCase()]);
  for (const variant of variants) {
    const value = process.env[variant];
    if (value && value.trim().length > 0) {
      return value.trim();
    }
  }

  return undefined;
};

/**
 * Parses a string value to a boolean with fallback support.
 * Recognizes common boolean representations: true/false, 1/0, yes/no, y/n, on/off.
 * @param value - The string value to parse (can be undefined or null)
 * @param fallback - The default boolean value to return if parsing fails
 * @returns Parsed boolean or fallback value
 */
export const parseBoolean = (value: string | undefined | null, fallback: boolean): boolean => {
  if (value === undefined || value === null) {
    return fallback;
  }
  const normalized = value.trim().toLowerCase();
  if (["true", "1", "yes", "y", "on"].includes(normalized)) {
    return true;
  }
  if (["false", "0", "no", "n", "off"].includes(normalized)) {
    return false;
  }
  return fallback;
};
