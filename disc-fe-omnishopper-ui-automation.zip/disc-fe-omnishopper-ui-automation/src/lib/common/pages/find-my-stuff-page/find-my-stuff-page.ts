import { BasePage, WebActions } from "@gfk/gta";
import { ResourceManager } from "../../utils/resource-manager";
import * as findMyStuffResources from "./find-my-stuff-page-resources.json";
import { MAX_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../common-test-case/common-test-case";
import { config } from "../../../playwright/config";
const FMS_COMPONENT_NAME = "Findmystuff";

export class FindMyStuff extends CommonTestCase {
  webActionHandler: WebActions;
  resourceManager: ResourceManager;
  constructor(basePage: BasePage) {
    super(basePage);
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
    // Register multiple resources for the same component
    this.resourceManager.registerResources(FMS_COMPONENT_NAME, findMyStuffResources);
  }

  public async clickFindMyStuff() {
    await super.clickWebelement("findMyStuff", FMS_COMPONENT_NAME);
  }

  public async shimmeringtoinvisible() {
    let shimmering = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("shimmering", FMS_COMPONENT_NAME)
    );
    await shimmering.isVisible();
    await shimmering.waitFor(MAX_TEST_TIMEOUT, "hidden");
  }
  async openCurrentReportFMS(savedReportTitle: string) {

    try {

      await this.searchForAssetInFMS(savedReportTitle);
      console.log("Search for Saved Report Title: ", savedReportTitle);
      await super.clickWebelement("firstSearchReport", FMS_COMPONENT_NAME);
      console.log("First Search Result Clicked");
      
      // Wait for page to load
      await this.webActionHandler.delay(SMALL_TIMEOUT);
      
      // Check for backend/UI error banner after page load
      // Use CommonTestCase instance because it has the proper resource registrations
      const commonTestCase = new CommonTestCase(this.basePage);
      const runErrorMessage = await commonTestCase.checkForErrors();

      if (runErrorMessage) {
        // Stop the test early if an error occurred during report load
        throw new Error(`Report failed to load; aborting test. Error: ${runErrorMessage}`);
      }
      console.info("Report opened from FMS successfully!");
    }
    catch (error) {
      console.error(" Full error details:", error);
      throw new Error(`Failed to open report from FMS: ${error instanceof Error ? error.message : JSON.stringify(error)}`);
    }
  }
  async validateShareOptionForNewTemplate(reportUrl: string) {
    console.log(`Waiting for report to load from URL: ${reportUrl}`);
    console.log("Share Icon Button found");

    await this.clickShareIcon();
    console.log("Share Options Clicked");
    await this.webActionHandler.getWebElement(this.resourceManager.getResource("addRecipientsBtn", FMS_COMPONENT_NAME)).click();
    console.log("Clicked 'Add Recipients'");
    const searchInput = this.webActionHandler.getWebElement(this.resourceManager.getResource("peopleSearchInput", FMS_COMPONENT_NAME));
    await searchInput.waitFor();
    await searchInput.click();
    await searchInput.enterText(config.SHARE_MAIL_ID);
    console.log("Email ID searched, fetched successfully");
    const userCheckbox = this.webActionHandler.getWebElement(this.resourceManager.getResource("peopleCheckboxIcon", FMS_COMPONENT_NAME));
    await userCheckbox.waitFor();
    await userCheckbox.click();
    const addRecipientsButton = this.webActionHandler.getWebElement(this.resourceManager.getResource("peopleAddBtn", FMS_COMPONENT_NAME));
    await addRecipientsButton.waitFor();
    await addRecipientsButton.click();
    const inviteButton = this.webActionHandler.getWebElement(this.resourceManager.getResource("inviteBtn", FMS_COMPONENT_NAME));
    await inviteButton.waitFor();
    await inviteButton.click();
    console.log("Invite shared successfully");
    const successToast = this.webActionHandler.getWebElement(this.resourceManager.getResource("successToast", FMS_COMPONENT_NAME));
    await successToast.isVisible();
    await successToast.waitFor();
    console.log("Success toast is visible and hidden after timeout");
  }

  /**
   * Click the FMS Menu after ensuring it is visible.
   * search for given report name and apply report filter.
   */
  public async searchForAssetInFMS(reportName: string): Promise<void> {

    await this.clickFindMyStuff();
    //await this.shimmeringtoinvisible();
    // Interact with the search bar
    await this.clickWebelement("fmsinputSearchBar", FMS_COMPONENT_NAME);
    const searchBar = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("fmsinputSearchBar", FMS_COMPONENT_NAME)
    );

    const regionElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("regionElement", FMS_COMPONENT_NAME)
    );

    // Get environment from config (e.g. DEV, SI, UAT) and normalize to uppercase
    const environment = (config.ENV || "").toUpperCase();

    // Safely check if the dropdown is visible (if element missing, treat as not visible)
    const isRegionElementVisible = await regionElement.isVisible().catch(() => false);

    // Only proceed when dropdown is visible AND the environment is NOT one of the local test envs
    if (isRegionElementVisible && ["PROD_EU", "PROD_US", "PROD_APAC", "PROD_CALATAM"].includes(environment)) {

      await super.clickWebelement("regionDropDown", FMS_COMPONENT_NAME);

      const envResourceMap: Record<string, string> = {
        PROD_EU: "prodEu",
        PROD_US: "prodUs",
        PROD_APAC: "prodApac",
        PROD_CALATAM: "prodCalatam",
      };

      const regionToClick = envResourceMap[environment];
      if (regionToClick) {
        await super.clickWebelement(regionToClick, FMS_COMPONENT_NAME);
      }
    }
  
    await searchBar.enterText(reportName);
    await super.clickWebelement("searchMoreResults", FMS_COMPONENT_NAME);
    await super.clickWebelement("assetTypeFilter", FMS_COMPONENT_NAME);
    await super.clickWebelement("reportCheckBox", FMS_COMPONENT_NAME);
    await super.clickWebelement("applyFilter", FMS_COMPONENT_NAME);
  }
}
