export interface ReportLocalizationData {
    locale: string;
    title: string;
    description: string;
    solutionType: string[];
    madlibText?: string; 
    businessQuestions: string[];
    businessObjectives: string[];
    pivotMadlibText?: string;
    pinMenuQuestions?: string[];
    toggleValues?: {
      question1?: string[];
      question4?: string[];
    };
  }

/**
 * Top level structure for test data
 */
export interface TestData {
    common: CommonAttributes;
    datasets: Record<DatasetContent, DatasetConfig>;
}

/**
 * Common attributes shared across all datasets
 */
  export interface CommonAttributes {
    navigationURL: string;
    themes: string[];
    dataSets: string[];
    thumbnailSrc: string
  }

/**
 * Selection structure for dimension values - supports both array and object formats
 */
export interface Selections {
    [hierarchy: string]: string[] | {
        min: string;
        max: string;
        range: string;
    };
}

/**
 * Selection configuration for a single dimension
 */
export interface DimensionSelection {
    selections: Selections | { value: string[] | { min: string; max: string; range: string } };
    minSelection?: string;
    maxSelection?: string;
    skipMaxSelectionValidation?: boolean;
}

/**
 * Structure for People dimension which has a more complex nested structure
 */
export interface PeopleDimensionSelection {
    selections: Array<{
        [groupType: string]: {
            [subGroupType: string]: {
                [dimensionType: string]: {
                    selections: Selections;
                    minSelection: string;
                    maxSelection: string;
                }
            }
        }
    }>;
    minSelection: string;
    maxSelection: string;
}

/**
 * All dimension selections for a report - this represents one complete set of dimension configurations
 */
export interface DimensionSelections {
    [dimension: string]: DimensionSelection | PeopleDimensionSelection;
}

/**
 * Format panel selection item structure
 */
export interface FormatPanelSelectionItem {
    id: number;
    value: string;
    selected: boolean;
    labelToTest: string;
}

/**
 * Format panel selections structure
 */
export interface FormatPanelSelections {
    default?: FormatPanelSelectionItem[];
    afterChangeCheck?: FormatPanelSelectionItem[];
}

/**
 * Structure for a specific dataset configuration
 */
export interface DatasetConfig {
    sourceType: string;
    dataView: string;
    navUrlWithDataSetId: string;
    dimensionSelections: DimensionSelections[];
    formatPanelSelections?: FormatPanelSelections;
}

// Dataset content options
export type DatasetContent = "Omni Agg SI 3yrs Synd" | "HSCN Agg SI 5yrs Synd" | "Omnishopper Syndicated Weekly MULTI_COUNTRY";
