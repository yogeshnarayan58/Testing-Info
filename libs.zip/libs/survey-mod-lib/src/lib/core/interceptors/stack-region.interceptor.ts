import { inject, Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';

@Injectable()
export class StackRegionInterceptor implements HttpInterceptor {
  environmentConfig = inject(EnvironmentConfig);

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const newRequest = request.clone({
      headers: this.setDataStackHeaders(request),
    });
    return next.handle(newRequest);
  }

  public setDataStackHeaders(req: HttpRequest<any>) {
    return req.headers
      .append('X-NIQ-DISCOVER-CLIENT-HOME-STACK-ID', this.getRegion(this.environmentConfig.region || 'US'))
      .append('X-NIQ-DISCOVER-USER-HOME-STACK-ID', this.getRegion(this.environmentConfig.region || 'US'))
      .append('X-NIQ-DISCOVER-TXN-ORIGIN-STACK-ID', this.getRegion(this.environmentConfig.region || 'US'))
  }

  private getRegion(environmentRegion: string): string {
    switch (environmentRegion) {
      case 'EUSI':
      case 'EUQA':
      case 'EUUAT':
      case 'EUUAT2':
      case 'EUPROD':
        return 'EU';
      case 'CALTMPROD':
        return 'CALATAM';
      case 'APPROD':
        return 'APAC';
      default:
        return 'US';
    }
  }
}
