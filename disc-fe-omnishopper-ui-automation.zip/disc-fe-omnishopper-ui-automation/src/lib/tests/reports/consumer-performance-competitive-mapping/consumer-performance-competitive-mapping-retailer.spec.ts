import test from "@playwright/test";
import {
  findDataSetByName,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import assertionData from "./assertion-data/assertion-data.json";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";

test.describe("Consumer Performance Competitive Mapping Retailer", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  test.beforeAll(() => {
    const isValidTestData =
      reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn(
        "Skipping tests as the required pivot test data is not present"
      );
    }
    test.skip(
      !isValidTestData,
      "Skipping tests as the required pivot test data is not present"
    );
  });
  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);

      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      // Open additional prompts to ensure madlib is visible
      await dataSelector.clickAdditionalPromptEllipsisIcon();

      // Validate using pattern matching with detailed results
      if (localeData.pivotMadlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).retailer;

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(new RegExp(expectedMadlibText, "i"));

        console.log(" Madlib validation passed for locale:", localeData.locale);
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.switchPivotDropdown(pivot);

          // Get Retailer pivot data
          const retailerData = getDimensionSelectionsByPivot(
            pivot,
            reportTestData
          );

          await dataSelector.clickAdditionalPromptEllipsisIcon();

          await dataSelector.clickMadlibDimension("Retailers");
          await dataSelector.setMadlibSelection(retailerData["Retailers"]);
          console.log("Retailers selected");

          await dataSelector.clickMadlibDimension("Products");
          await dataSelector.setMadlibSelection(retailerData["Products"]);
          console.log("Products selected");

          await dataSelector.clickMadlibDimension("Geographies");
          await dataSelector.setMadlibSelection(retailerData["Geographies"]);
          console.log("Geographies selected");

          await dataSelector.clickMadlibDimension("Periods");
          await dataSelector.setPeriodMadlibSelection(retailerData["Periods"]);
          console.log("Periods selected");

          await dataSelector.clickMadlibDimension("Demographic");
          await dataSelector.setMadlibSelection(retailerData["Demographic"]);
          console.log("Demographic selected");

          // await dataSelector.clickMadlibDimension("People");
          // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
          // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
          // for (const selection of retailerData["People"].selections) {
          //   await dataSelector.handlePeopleMenuOptions(selection);
          // }
          // console.log("People selections made");

          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.selectClosedDropdown(
            retailerData["Facts"]["selections"]
          );
          console.log("Facts selected");

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } = await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
    }
  );
});
