import { SurveyLocalizationData } from '../interfaces/iLocalizationData';

export function getTestDataByLocale<T extends SurveyLocalizationData>(locale: string, data: T[]): T {
  const entry = data.find((item) => item.locale === locale);
  if (!entry) {
    throw new Error(`Locale '${locale}' not found`);
  }
  return entry;
}

/** Finds a locale entry by locale code, languageName or countryName (case-insensitive). */
export function findLocaleEntry<T extends SurveyLocalizationData>(codeOrName: string, data: T[]): T {
  const wanted = codeOrName.trim().toLowerCase();
  const entry = data.find((item) =>
    [item.locale, item.languageName, item.countryName].some((value) => value?.toLowerCase() === wanted)
  );
  if (!entry) {
    const valid = data.flatMap((item) => [item.locale, item.languageName, item.countryName]).filter(Boolean);
    throw new Error(`'${codeOrName}' is not a known locale, language or country. Valid values: ${valid.join(', ')}`);
  }
  return entry;
}
