import { BasePage } from "@gfk/gta";
import { Page } from "@playwright/test";

let page: BasePage;

/**
 * Returns the current Page.
 * @returns {Page} The current Page.
 */
export function getPage(): BasePage {
    return page;
  }

/**
 * Sets the current Page.
 * @param {Page} pageInstance - The Page instance to set as the current Page.
 */
export function setPage(pageInstance: BasePage): void {
    page = pageInstance;
  }

