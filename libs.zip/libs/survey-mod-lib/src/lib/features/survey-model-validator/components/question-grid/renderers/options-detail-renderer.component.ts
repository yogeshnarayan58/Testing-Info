import { Component } from '@angular/core';
import type { ICellRendererAngularComp } from 'ag-grid-angular';
import type { ICellRendererParams } from 'ag-grid-community';
import type { Question, QuestionRow } from '../question.model';

/**
 * Full-width row renderer that displays the answer UI belonging to a
 * question, switched on `question.type`. Used as the grid's
 * `fullWidthCellRenderer`, activated whenever `isFullWidthRow` returns true
 * for a synthetic "detail" row.
 */
@Component({
  selector: 'survey-options-detail-renderer',
  standalone: true,
  templateUrl: './options-detail-renderer.component.html',
  styleUrl: './options-detail-renderer.component.scss',
})
export class OptionsDetailRendererComponent implements ICellRendererAngularComp {
  question: Question | null = null;
  detailId = '';
  readonly letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  readonly stars = [1, 2, 3, 4, 5];
  npsValues: number[] = Array.from({ length: 11 }, (_, i) => i);

  agInit(params: ICellRendererParams<QuestionRow>): void {
    this.setState(params);
  }

  refresh(params: ICellRendererParams<QuestionRow>): boolean {
    this.setState(params);
    return true;
  }

  private setState(params: ICellRendererParams<QuestionRow>): void {
    this.question = params.data?.question ?? null;
    this.detailId = this.question ? `question-detail-${this.question.questionNumber}` : '';
  }
}
