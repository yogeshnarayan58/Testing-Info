import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('@nielseniq/athena-core', () => ({
  TabModule: class {},
}));
vi.mock('@ngx-translate/core', () => ({
  TranslateModule: class {},
  TranslateService: class {},
  TranslateStore: class {},
  TranslateLoader: class {},
  TranslateCompiler: class {},
  TranslateParser: class {},
  MissingTranslationHandler: class {},
}));
vi.mock('../survey-overview/survey-overview.component', () => ({
  SurveyOverview: class {},
}));
vi.mock('../survey-overview/survey-overview.component.ts', () => ({
  SurveyOverview: class {},
}));
vi.mock('../results-dashboard/results-dashboard.component', () => ({
  ResultsDashboardComponent: class {},
}));
vi.mock('../results-dashboard/results-dashboard.component.ts', () => ({
  ResultsDashboardComponent: class {},
}));
vi.mock('../../../../shared/components/dataset-footer/dataset-footer.component', () => ({
  DatasetFooterComponent: class {},
}));
vi.mock('../../../../shared/components/dataset-footer/dataset-footer.component.ts', () => ({
  DatasetFooterComponent: class {},
}));
vi.mock('../../../../shared/services/survey-common.service', () => ({
  SurveyCommonService: class {},
}));

import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SURVEY_RESULTS_TAB_VALUES } from '../../models/survey-results';
import { SurveyResultsComponent } from './survey-results.component';

describe('SurveyResultsComponent', () => {
  let component: SurveyResultsComponent;

  const surveyCommonServiceStub = {
    setActiveSurveyStep: vi.fn(),
    setDatasetFooterVisible: vi.fn(),
  };

  beforeEach(async () => {
    surveyCommonServiceStub.setDatasetFooterVisible.mockReset();
    surveyCommonServiceStub.setActiveSurveyStep.mockReset();

    await TestBed.configureTestingModule({
      providers: [{ provide: SurveyCommonService, useValue: surveyCommonServiceStub }],
    });

    component = TestBed.runInInjectionContext(() => new SurveyResultsComponent());
  });

  it('sets footer visibility for default Results tab on init', () => {
    component.ngOnInit();

    expect(surveyCommonServiceStub.setActiveSurveyStep).toHaveBeenCalledWith('results');
    expect(component.selectedTab()).toBe(SURVEY_RESULTS_TAB_VALUES.results);
    expect(surveyCommonServiceStub.setDatasetFooterVisible).toHaveBeenCalledWith(false);
  });

  it('updates selected tab and enables footer on Survey specs tab', () => {
    component.onTabChange(SURVEY_RESULTS_TAB_VALUES.surveySpecs);

    expect(component.selectedTab()).toBe(SURVEY_RESULTS_TAB_VALUES.surveySpecs);
    expect(surveyCommonServiceStub.setDatasetFooterVisible).toHaveBeenCalledWith(true);
  });

  it('resets footer visibility on destroy', () => {
    component.ngOnDestroy();

    expect(surveyCommonServiceStub.setDatasetFooterVisible).toHaveBeenCalledWith(false);
  });
});
