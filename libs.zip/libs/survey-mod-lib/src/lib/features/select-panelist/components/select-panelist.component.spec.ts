import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { SurveyService } from '../../build-survey/services/survey.service';
import { ValidationService } from '../../build-survey/services/validation.service';
import { RunReportService } from '../services/run-report.service';
import { SelectPanelistComponent } from './select-panelist.component';

vi.mock('../../build-survey/services/survey.service', () => ({
  SurveyService: class {},
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  ACAssetManageApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

vi.mock('./panelist-dataselector/panelist-dataselector.component', () => ({
  PanelistDataselectorComponent: class {},
}));

vi.mock('@nielseniq/athena-core', () => ({
  ToastService: class {},
  MenuModule: class {},
  ItemModule: class {},
  CardModule: class {},
  IconModule: class {},
  DropDownModule: class {},
  ButtonModule: class {},
  IconButtonModule: class {},
  SegmentControlModule: class {},
}));

describe('SelectPanelistComponent', () => {
  const createComponent = (surveyId?: string) => {
    const reportCompleted$ = new BehaviorSubject<any>(null);

    const runReportService = {
      reportCompleted$,
      resetReportCompleted: vi.fn(),
    };

    const surveyService = {
      questions: signal<any[]>([]),
      setQuestions: vi.fn(),
      genState: { set: vi.fn() },
      currentSurveyId: surveyId ?? null,
    };
    const validationService = { resetValidation: vi.fn() };

    const surveyCommonService = {
      getSelectPanelistUiState: vi.fn().mockReturnValue({
        reportData: false,
        householdCount: '0',
        selectedResponses: null,
      }),
      setSelectPanelistUiState: vi.fn(),
      setDataselectorLoading: vi.fn(),
      setPanelOpen: vi.fn(),
      setUserPrompt: vi.fn(),
      getUserPrompt: vi.fn().mockReturnValue('Saved prompt'),
      flowType: vi.fn().mockReturnValue({ aiflow: false, scratch: true }),
      setActiveSurveyStep: vi.fn(),
      setDatasetFooterVisible: vi.fn(),
      panelistCompleted: signal(false),
    };

    const route = {
      parent: {},
      snapshot: { paramMap: convertToParamMap(surveyId ? { surveyId } : {}) },
    };

    const router = {
      navigate: vi.fn().mockResolvedValue(true),
    };

    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        { provide: RunReportService, useValue: runReportService },
        { provide: Router, useValue: router },
        { provide: ActivatedRoute, useValue: route },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: SurveyService, useValue: surveyService },
        { provide: ValidationService, useValue: validationService },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new SelectPanelistComponent(
      runReportService as any,
      router as any,
      route as any,
      surveyCommonService as any,
    ));

    return { component, runReportService, surveyService, validationService, surveyCommonService, router, route, reportCompleted$ };
  };

  it('creates and restores initial state from shared UI cache', () => {
    const { component, surveyCommonService } = createComponent();
    (component as any).restoreSelectPanelistUiState();
    component.ngOnInit();

    expect(component).toBeDefined();
    expect(surveyCommonService.setActiveSurveyStep).toHaveBeenCalledWith('select-panelist');
    expect(surveyCommonService.setDatasetFooterVisible).toHaveBeenCalledWith(true);
    expect(surveyCommonService.getSelectPanelistUiState).toHaveBeenCalled();
    expect(component.userPrompt).toBe('Saved prompt');
    expect(component.householdCount).toBe('0');
  });

  it('subscribes to report completion and updates household state', () => {
    const { component, reportCompleted$, surveyCommonService } = createComponent();
    component.ngOnInit();

    reportCompleted$.next({ rowData: [{ c1: { cellValue: 250 } }] });

    expect(component.reportData).toBe(true);
    expect(component.householdCount).toBe('250');
    expect(component.eligibleCount).toBe(250);
    expect(surveyCommonService.setSelectPanelistUiState).toHaveBeenCalledWith({
      reportData: true,
      householdCount: '250',
    });
  });

  it('handles prompt input by syncing prompt and clearing generated questions', () => {
    const { component, surveyCommonService, surveyService } = createComponent();
    surveyService.questions.set([{ question: 'Q1' }]);
    component.userPrompt = 'New prompt';

    component.onPromptInput();

    expect(surveyCommonService.setUserPrompt).toHaveBeenCalledWith('New prompt');
    expect(surveyService.setQuestions).toHaveBeenCalledWith([]);
    expect(surveyService.genState.set).toHaveBeenCalledWith('idle');
  });

  it('selects response and persists panelist UI state', () => {
    const { component, surveyCommonService } = createComponent();

    component.selectResponse(200);

    expect(component.selectedResponses).toBe(200);
    expect(surveyCommonService.setSelectPanelistUiState).toHaveBeenCalledWith({ selectedResponses: 200 });
  });

  it('toggles extra response options only for scratch flow', () => {
    const { component, surveyCommonService } = createComponent();

    component.toggleMoreResponseOptions();
    expect(component.showMoreResponseOptions).toBe(true);

    surveyCommonService.flowType.mockReturnValue({ aiflow: true, scratch: false });
    component.toggleMoreResponseOptions();
    expect(component.showMoreResponseOptions).toBe(true);
  });

  it('clears criteria state when criteria change is not skipped', () => {
    const { component, runReportService, surveyCommonService } = createComponent();
    component.reportData = true;
    component.householdCount = '120';
    component.eligibleCount = 120;
    component.selectedResponses = 100;

    component.onCriteriaChanged();

    expect(runReportService.resetReportCompleted).toHaveBeenCalled();
    expect(component.reportData).toBe(false);
    expect(component.householdCount).toBe('0');
    expect(component.selectedResponses).toBeNull();
    expect(surveyCommonService.setSelectPanelistUiState).toHaveBeenCalledWith({
      reportData: false,
      householdCount: '0',
      selectedResponses: null,
    });
  });

  it('navigates to build-survey and preserves route surveyId', () => {
    const { component, router } = createComponent('survey-42');

    component.proceedToSurveyBuilder();

    expect(router.navigate).toHaveBeenCalledWith(['build-survey', 'survey-42'], expect.any(Object));
  });

  it('returns no response options in unhappy path and filtered options otherwise', () => {
    const { component } = createComponent();

    component.eligibleCount = 100;
    expect(component.filteredResponseCounts).toEqual([]);

    component.eligibleCount = 260;
    expect(component.filteredResponseCounts).toEqual([100, 150, 200, 250]);
  });

  it('handles dataset and panel toggle callbacks', () => {
    const { component, surveyCommonService } = createComponent();

    component.onDatasetSelected('Dataset-X');
    component.onPanelToggled(true);

    expect(component.hasDataset).toBe(true);
    expect(component.selectedDatasetName).toBe('Dataset-X');
    expect(component.isPanelOpen).toBe(true);
    expect(surveyCommonService.setPanelOpen).toHaveBeenCalledWith(true);
  });

  it('supports expanded response options in scratch flow', () => {
    const { component } = createComponent();
    component.eligibleCount = 1000;
    component.showMoreResponseOptions = true;

    expect(component.filteredResponseCounts).toEqual([100, 150, 200, 250, 300, 400, 500, 600, 700, 800, 900, 1000]);
  });

  it('uses service surveyId fallback when route param is missing', () => {
    const { component, router, route } = createComponent();
    (component as any).surveyService.currentSurveyId = 'survey-service-id';
    (route as any).snapshot.paramMap = convertToParamMap({});

    component.proceedToSurveyBuilder();

    expect(router.navigate).toHaveBeenCalledWith(['build-survey', 'survey-service-id'], expect.any(Object));
  });

  it('navigates without surveyId when both route and service id are blank', () => {
    const { component, router, route } = createComponent();
    (component as any).surveyService.currentSurveyId = '';
    (route as any).snapshot.paramMap = convertToParamMap({});

    component.proceedToSurveyBuilder();

    expect(router.navigate).toHaveBeenCalledWith(['build-survey'], expect.any(Object));
  });

  it('uses criteria-skip guard once before resetting criteria state', () => {
    const { component, runReportService } = createComponent();
    (component as any).skipAutoCriteriaReset = true;

    component.onCriteriaChanged();
    expect(runReportService.resetReportCompleted).not.toHaveBeenCalled();

    component.onCriteriaChanged();
    expect(runReportService.resetReportCompleted).toHaveBeenCalledTimes(1);
  });

  it('falls back to zero household count on malformed report payload', () => {
    const { component } = createComponent();
    component.householdCount = '99';
    component.eligibleCount = 99;

    (component as any).extractHouseholdCount({ rowData: [null] });

    expect(component.householdCount).toBe('0');
    expect(component.eligibleCount).toBe(0);
  });
});
