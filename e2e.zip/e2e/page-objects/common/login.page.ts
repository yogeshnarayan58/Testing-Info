/**
 * Login page object for the Survey application.
 *
 * Uses GTA's BasePage/WebActions together with this project's
 * ResourceManager (utils/resource-manager.ts) and ElementResource
 * (interfaces/iElementResource.ts) to resolve selectors from
 * login.locator.json 
 */
import { BasePage } from '@gfk/gta';
import { CommonPage } from './common-page';
import loginPageResources from '../../locators/survey/login.locator.json';

const LOGIN_PAGE_COMPONENT_NAME = 'loginPage';

import { MAX_TEST_TIMEOUT, SMALL_TIMEOUT } from '../../constants/timeout-constants';
const SMALL_TIMEOUT_MS = SMALL_TIMEOUT;
const MAX_TEST_TIMEOUT_MS = MAX_TEST_TIMEOUT;

function validateCredentials(username: string, password: string): void {
  if (!(username && password)) {
    throw new Error(
      'Missing credentials. Please set USER_NAME and PASS_WORD in the .env file.'
    );
  }
}

export class LoginPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(LOGIN_PAGE_COMPONENT_NAME, loginPageResources);
  }

  /**
   * Accepts Terms & Conditions only if the checkbox is visible.
   * Mirrors Omni Shopper's acceptTermsIfPresent(): silently continues
   * if the interstitial never appears or was already accepted.
   */
  private async acceptTermsIfPresent(): Promise<void> {
    console.log('Checking for Terms & Conditions page...');

    try {
      const checkbox = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('termsAcceptCheckbox', LOGIN_PAGE_COMPONENT_NAME)
      );
      await checkbox.waitFor(SMALL_TIMEOUT_MS, 'visible');
      await checkbox.click();

      const acceptButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('termsAcceptButton', LOGIN_PAGE_COMPONENT_NAME)
      );
      await acceptButton.waitFor(MAX_TEST_TIMEOUT_MS, 'visible');
      await acceptButton.click();
      console.log('Terms accepted successfully.');
    } catch {
      // Terms page not shown or already accepted
      console.log('Terms page not shown or already accepted, continuing login...');
    }
  }

  async login(baseURL: string, username: string, password: string): Promise<void> {
    validateCredentials(username, password);
    console.log('Starting login process...');

    // Navigate to the app URL - it auto-redirects to the OAuth login page
    await this.navigateToUrl(baseURL);

    await this.webActionHandler
      .getWebElement(this.resourceManager.getResource('userName', LOGIN_PAGE_COMPONENT_NAME))
      .enterText(username);
    await this.webActionHandler
      .getWebElement(this.resourceManager.getResource('nextButton', LOGIN_PAGE_COMPONENT_NAME))
      .click();

    await this.webActionHandler
      .getWebElement(this.resourceManager.getResource('password', LOGIN_PAGE_COMPONENT_NAME))
      .enterText(password);
    await this.webActionHandler
      .getWebElement(this.resourceManager.getResource('verifyButton', LOGIN_PAGE_COMPONENT_NAME))
      .click();

    // If Terms & Conditions page comes, accept it
    await this.acceptTermsIfPresent();

    // Wait for the app to settle after terms acceptance (if terms were shown)
    await this.webActionHandler.delay(SMALL_TIMEOUT_MS);

    // Regardless of where login redirected to (launchpad, home, etc.),
    // navigate directly to the Survey landing page and verify we got there.
    const surveyURL = this.buildUrl(baseURL, 'survey');
    await this.navigateToUrl(surveyURL);

    const currentUrl = await this.webActionHandler.getPageUrl();
    if (!currentUrl.includes('/survey')) {
      throw new Error('Navigation to Survey failed - landed on ' + currentUrl + ' instead');
    }

    console.log('Login process completed successfully. Landed on ' + currentUrl);

    // Persist the authenticated session for reuse by other tests/specs.
    await this.webActionHandler.getStorageState('storage/auth.json');
  }
}