import { describe, expect, it, beforeEach, vi } from 'vitest';
import { createEnvironmentInjector, runInInjectionContext } from '@angular/core';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { CpfService } from '@nielsen/crf-common';
import { PanelistDatasetService } from './panelist-dataset.service';
import { of, throwError } from 'rxjs';

// Mock the external dependencies
vi.mock('@nielseniq/crf-discover-fe-core', () => ({
  EnvironmentConfig: class {},
  ListCallDatasetService: class {
    getDatasetByIdRegion = vi.fn();
  },
}));

vi.mock('@nielsen/crf-common', () => ({
  CpfService: class {
    loadConfigurationsBuild = vi.fn();
  },
}));

describe('PanelistDatasetService', () => {
  let service: PanelistDatasetService;
  let listCallDatasetServiceMock: any;
  let cpfServiceMock: any;

  beforeEach(() => {
    listCallDatasetServiceMock = {
      getDatasetByIdRegion: vi.fn(),
    };

    cpfServiceMock = {
      loadConfigurationsBuild: vi.fn(),
      getSpecificConfigurationFromBuildResponse: vi.fn(),
    };

    const injector = createEnvironmentInjector(
      [
        { provide: EnvironmentConfig, useValue: { appId: 'test-app-id' } },
        { provide: CpfService, useValue: cpfServiceMock },
      ],
      null as any
    );
    service = runInInjectionContext(injector, () => new PanelistDatasetService());
  });

  describe('loadBaseReportSpec', () => {
    it('should load report spec and handle null configs gracefully', () => {
      const datasetDetails = { id: 'ds-123', dataView: { dataViewId: 'dv-456' }, stackId: 'stack-001' };
      const componentId = 'COMPONENT_ID';
      const mockSpec = { spec: 'test-spec' };

      cpfServiceMock.loadConfigurationsBuild.mockReturnValue(of(mockSpec));
      cpfServiceMock.getSpecificConfigurationFromBuildResponse.mockReturnValue({ configValue: { reportSpec: mockSpec } });

      return new Promise((resolve, reject) => {
        service.loadBaseReportSpec(datasetDetails, componentId).subscribe({
          next: (result) => {
            expect(cpfServiceMock.loadConfigurationsBuild).toHaveBeenCalled();
            resolve(undefined);
          },
          error: reject,
        });
      });
    });

    it('should handle null configs and missing reportSpec value', () => {
      cpfServiceMock.loadConfigurationsBuild.mockReturnValue(of(null));

      return new Promise((resolve, reject) => {
        service.loadBaseReportSpec(null, 'COMPONENT_ID').subscribe({
          next: (result) => {
            expect(result).toBeNull();
            resolve(undefined);
          },
          error: reject,
        });
      });
    });

    it('should handle null configValue and null reportSpec', () => {
      const mockConfigs = { data: 'configs' };
      cpfServiceMock.loadConfigurationsBuild.mockReturnValue(of(mockConfigs));
      cpfServiceMock.getSpecificConfigurationFromBuildResponse.mockReturnValue({ configValue: null });

      return new Promise((resolve, reject) => {
        service.loadBaseReportSpec({ id: 'ds-123', dataView: { dataViewId: 'dv-456' }, stackId: 'stack-001' }, 'COMPONENT_ID').subscribe({
          next: (result) => {
            expect(result).toBeNull();
            resolve(undefined);
          },
          error: reject,
        });
      });
    });

    it('should handle missing dataView and CPF service error', () => {
      const datasetDetails = { id: 'ds-123', stackId: 'stack-001' };
      const error = new Error('CPF Service Error');

      cpfServiceMock.loadConfigurationsBuild.mockReturnValue(throwError(() => error));

      return new Promise((resolve, reject) => {
        service.loadBaseReportSpec(datasetDetails as any, 'COMPONENT_ID').subscribe({
          next: () => reject(new Error('Should have thrown error')),
          error: (err) => {
            expect(err).toEqual(error);
            resolve(undefined);
          },
        });
      });
    });
  });

  describe('Service Initialization', () => {
    it('should create service with all required methods', () => {
      expect(service).toBeTruthy();
      expect(typeof service.loadBaseReportSpec).toBe('function');
    });
  });
});
