import { describe, expect, it } from 'vitest';
import { buildDatasetDisplay } from './survey-dataset-display.util';

describe('survey-dataset-display.util', () => {
  describe('buildDatasetDisplay', () => {
    it('should build display with all fields populated', () => {
      const datasetConfig = {
        productOfferingCode: 'PANEL_OD_OMNI',
        title: 'Test Dataset',
        dataView: { dataViewName: 'View 1' },
      };

      const result = buildDatasetDisplay(datasetConfig);

      expect(result).toContain('Test Dataset');
      expect(result).toContain('View 1');
    });

    it('should use label fallback when title is missing', () => {
      const datasetConfig = {
        productOfferingCode: 'PANEL_OD_OMNI',
        label: 'Dataset Label',
        dataView: { dataViewName: 'View 1' },
      };

      const result = buildDatasetDisplay(datasetConfig);

      expect(result).toContain('Dataset Label');
    });

    it('should use requestInstance productOfferingCode when config is missing', () => {
      const datasetConfig = {
        title: 'Test Dataset',
      };
      const requestInstance = {
        productOfferingCode: 'PANEL_OD_OMNI',
        dataViewName: 'View 1',
      };

      const result = buildDatasetDisplay(datasetConfig, requestInstance);

      expect(result).toContain('Test Dataset');
      expect(result).toContain('View 1');
    });

    it('should use requestInstance datasetLabel when config title and label are missing', () => {
      const datasetConfig = {
        dataView: { dataViewName: 'View 1' },
      };
      const requestInstance = {
        datasetLabel: 'Request Dataset',
        dataViewName: 'View 1',
      };

      const result = buildDatasetDisplay(datasetConfig, requestInstance);

      expect(result).toContain('Request Dataset');
    });

    it('should return only NielsenIQ when all fields are empty', () => {
      const result = buildDatasetDisplay({});

      expect(result).toBe('NielsenIQ');
    });

    it('should filter out empty strings and whitespace', () => {
      const datasetConfig = {
        title: '   ',
        label: '',
        dataView: { dataViewName: '' },
      };

      const result = buildDatasetDisplay(datasetConfig);

      expect(result).toBe('NielsenIQ');
    });

    it('should join all display parts with pipe separator', () => {
      const datasetConfig = {
        productOfferingCode: 'PANEL_OD_OMNI',
        title: 'My Dataset',
        dataView: { dataViewName: 'Main View' },
      };

      const result = buildDatasetDisplay(datasetConfig);

      expect(result).toMatch(/.*\|.*\|.*/);
      expect(result.split('|').length).toBe(3);
    });

    it('should handle null/undefined config gracefully', () => {
      const result = buildDatasetDisplay(null as any);

      expect(result).toBe('NielsenIQ');
    });

    it('should prioritize config values over requestInstance values', () => {
      const datasetConfig = {
        title: 'Config Title',
        dataView: { dataViewName: 'Config View' },
      };
      const requestInstance = {
        datasetLabel: 'Request Title',
        dataViewName: 'Request View',
      };

      const result = buildDatasetDisplay(datasetConfig, requestInstance);

      expect(result).toContain('Config Title');
      expect(result).toContain('Config View');
      expect(result).not.toContain('Request Title');
    });

    it('should use requestInstance type when config type is missing', () => {
      const datasetConfig = {
        title: 'Test Dataset',
      };
      const requestInstance = {
        type: 'PANEL_OD_OMNI',
        dataViewName: 'View 1',
      };

      const result = buildDatasetDisplay(datasetConfig, requestInstance);

      expect(result).toContain('Test Dataset');
    });

    it('should handle dataset config with nested dataView', () => {
      const datasetConfig = {
        productOfferingCode: 'PANEL_OD_HSCN',
        title: 'Homescan Dataset',
        dataView: {
          dataViewId: 'dv-123',
          dataViewName: 'Homescan View',
        },
      };

      const result = buildDatasetDisplay(datasetConfig);

      expect(result).toContain('Homescan Dataset');
      expect(result).toContain('Homescan View');
    });
  });
});
