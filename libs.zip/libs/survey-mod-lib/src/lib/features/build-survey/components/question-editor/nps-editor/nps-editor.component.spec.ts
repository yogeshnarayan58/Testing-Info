import { ElementRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { NpsEditorComponent } from './nps-editor.component';

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('NpsEditorComponent', () => {
  let mockTranslateService: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
  });
  const createComponent = () => TestBed.runInInjectionContext(() =>
    new NpsEditorComponent(new ElementRef(document.createElement('div'))),
  );

  it('updates the question and emits on input', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onInputChange('Would you recommend us?');

    expect(component.question()).toBe('Would you recommend us?');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('updates both NPS labels', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onLeftLabelChange(1);
    component.onRightLabelChange('Definitely recommend');

    expect(component.npsLeftLabel()).toBe('1');
    expect(component.npsRightLabel()).toBe('Definitely recommend');
    expect(emit).toHaveBeenCalledTimes(2);
  });

  it('uses empty text for null input and labels', () => {
    const component = createComponent();

    component.onInputChange(null as unknown as string);
    component.onLeftLabelChange(null as unknown as string);
    component.onRightLabelChange(null as unknown as string);

    expect(component.question()).toBe('');
    expect(component.npsLeftLabel()).toBe('');
    expect(component.npsRightLabel()).toBe('');
  });

  it('updates required state from the toggle', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: true } } as unknown as Event);

    expect(component.isRequired()).toBe(true);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('defaults required state to false when toggle data is missing', () => {
    const component = createComponent();
    component.isRequired.set(true);

    component.toggleChange({ target: {} } as unknown as Event);

    expect(component.isRequired()).toBe(false);
  });
});
