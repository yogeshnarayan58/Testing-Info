import {
  ChangeDetectionStrategy,
  Component,
  computed,
  ElementRef,
  inject,
  input,
  output,
  signal,
  viewChild,
} from '@angular/core';
import { CommonSidePanelComponent } from '../../../../shared/components/common-side-panel/common-side-panel.component';
import { HeaderImgConfig } from '../../../../shared/components/common-side-panel/common-side-panel.model';
import {
  AiSuggestion,
  OPTIQ_FEEDBACK_ACTIONS,
  QuestionModel,
  SuggestionAction,
  SuggestionActionType,
  SuggestionConfig,
  SUGGESTION_SEVERITY,
  SURVEY_SUGGESTIONS_STATE,
} from '../../models/build-survey';
import { ButtonModule, IconModule, SpinnerModule, TooltipModule } from '@nielseniq/athena-core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SurveyService } from '../../services/survey.service';
import { ValidationService } from '../../services/validation.service';
import { buildSpellingHighlights, SpellingHighlight } from '../../services/optiq-feedback.util';

// Applying fixes is instant, so the loader is kept visible for a minimum time.
const FIX_ALL_MIN_LOADER_MS = 500;

interface FixAllItem {
  questionId: string;
  suggestion: AiSuggestion;
  actionType: SuggestionActionType;
}

@Component({
  selector: 'survey-optiq-feedback',
  standalone: true,
  imports: [CommonSidePanelComponent, ButtonModule, TranslateModule, IconModule, SpinnerModule, TooltipModule],
  templateUrl: './optiq-feedback.component.html',
  styleUrl: './optiq-feedback.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OptiqFeedbackComponent {
  readonly open = input(false);
  readonly isApplyingAll = signal(false);
  readonly closeRequested = output<void>();
  readonly optiqFeedbackActions = OPTIQ_FEEDBACK_ACTIONS;
  readonly surveyService = inject(SurveyService);
  private readonly validationService = inject(ValidationService);
  readonly translateService = inject(TranslateService);
  readonly SuggestionActionType = SuggestionActionType;
  readonly suggestionSeverity = SUGGESTION_SEVERITY;
  readonly statusMessage = signal('');
  readonly feedbackContainer = viewChild<ElementRef<HTMLElement>>('feedbackContainer');
  // Set once the help page URL is available.
  readonly learnMoreUrl = '';
  readonly headerImgConfig: HeaderImgConfig =
    { imgSrc: 'assets/images/optiq.svg', altText: 'optiq icon' };


  readonly questions = this.surveyService.questions;
  readonly surveyAIValidationState = this.validationService.surveyAIValidationState;
  readonly surveySuggestionState = this.validationService.surveySuggestionState;
  readonly suggestionState = SURVEY_SUGGESTIONS_STATE;
  readonly mandatorySuggestionCount = computed(() =>
    this.validationService.countSuggestions(this.questions(), SUGGESTION_SEVERITY.MANDATORY)
  );
  readonly optionalSuggestionCount = computed(() =>
    this.validationService.countSuggestions(this.questions(), SUGGESTION_SEVERITY.OPTIONAL)
  );
  readonly hasSuggestions = computed(
    () => this.mandatorySuggestionCount() > 0 || this.optionalSuggestionCount() > 0
  );

  readonly questionsWithSuggestions = computed(() =>
    this.questions().filter((question) => question.suggestions?.length)
  );

  readonly spellingHighlightsBySuggestion = computed(() => {
    const highlightsBySuggestion = new Map<string, SpellingHighlight[]>();
    for (const question of this.questionsWithSuggestions()) {
      // BE offsets describe the text as validated, so they no longer match once the question is edited.
      if (question.reviewRequired) continue;
      for (const suggestion of question.suggestions ?? []) {
        if (
          suggestion.action === SuggestionActionType.REPHRASE
        ) {
          const highlights = buildSpellingHighlights(
            this.getOriginalText(question, suggestion.fieldPath),
            suggestion
          );
          if (highlights) {
            highlightsBySuggestion.set(suggestion.suggestionId, highlights);
          }
        }
      }
    }
    return highlightsBySuggestion;
  });

  /** Builds the sentence shown when we suggest adding a new option to a question. */
  getSuggestedOptionMessage(option: string): string {
    return OPTIQ_FEEDBACK_ACTIONS.suggestedOption(option);
  }

  readonly subheader = computed(() => {
    const mandatory = this.mandatorySuggestionCount();
    const total = mandatory + this.optionalSuggestionCount();

    if (total === 0) {
      return '';
    }

    const changes = total === 1 ? `${total} change found` : `${total} changes found`;
    return mandatory > 0
      ? `${changes} (${mandatory} required to publish)`
      : `${changes} (none required)`;
  });

  /** Decides how each suggestion looks: its title, icon, and which buttons (Apply, Dismiss) it shows. */
  getSuggestionConfig(suggestion: AiSuggestion): SuggestionConfig {
    const actions = this.optiqFeedbackActions;
    const isMandatory = suggestion.severity === SUGGESTION_SEVERITY.MANDATORY;
    const isLabel =
      suggestion.fieldPath === 'npsLeftLabel' ||
      suggestion.fieldPath === 'npsRightLabel';
    const isOption =
      !!suggestion.fieldPath?.startsWith('options[') ||
      !!suggestion.fieldPath?.startsWith('rowOptions[') ||
      !!suggestion.fieldPath?.startsWith('columnOptions[');

    let config: Pick<SuggestionConfig, 'title' | 'buttonLabel' | 'showComparison' | 'showDismiss'>;

    switch (suggestion.action) {
      case SuggestionActionType.ADD_OPTION:
        config = {
          title: actions.addOption,
          buttonLabel: actions.add,
          showComparison: false,
          showDismiss: !isMandatory,
        };
        break;

      case SuggestionActionType.REPHRASE:
        config = {
          title: actions.rephrase,
          buttonLabel: actions.rephrase,
          showComparison: true,
          showDismiss: !isMandatory,
        };
        break;

      case SuggestionActionType.REMOVE:
        config = {
          title: isLabel ? actions.removeLabel : isOption ? actions.removeOption : actions.removeQuestion,
          buttonLabel: isLabel ? null : actions.remove,
          showComparison: false,
          showDismiss: !isMandatory || isLabel,
        };
        break;

      case SuggestionActionType.MARK_OPTIONAL:
        config = {
          title: actions.markOptional,
          buttonLabel: actions.markOptional,
          showComparison: false,
          showDismiss: !isMandatory,
        };
        break;

      case SuggestionActionType.REVIEW:
      default:
        config = {
          title: actions.reviewSuggestion,
          buttonLabel: null,
          showComparison: false,
          showDismiss: true,
        };
        break;
    }

    const requiresSuggestedText =
      suggestion.action === SuggestionActionType.ADD_OPTION ||
      suggestion.action === SuggestionActionType.REPHRASE;

    const hasSuggestedText = !!suggestion.suggestedText?.trim();
    return {
      ...config,
      iconName: isMandatory ? 'error' : 'triangle-alert',
      isMandatory,
      buttonLabel: requiresSuggestedText && !hasSuggestedText ? null : config.buttonLabel,
      showDismiss: config.showDismiss || (requiresSuggestedText && !hasSuggestedText),
    };
  }

  /** Creates the text a screen reader reads for a action button,it includes question it belongs to. */
  getActionAriaLabel(actionLabel: string, question: QuestionModel): string {
    const action = this.translateService.instant(actionLabel);
    const number = question.questionNumber;

    return `${action}, question ${number}`;
  }

  /** Shows or hides the tooltip for keyboard users; niqTooltip only reacts to mouseenter and mouseleave. */
  toggleTooltip(event: Event, show: boolean): void {
    event.currentTarget?.dispatchEvent(new MouseEvent(show ? 'mouseenter' : 'mouseleave'));
  }

  /** Runs the suggestion the user clicked, then tells screen reader users what happened. */
  handleSuggestionAction(
    id: string,
    actionType: SuggestionAction | SuggestionActionType,
    suggestion?: AiSuggestion
  ): void {
    if (!suggestion || !id) {
      return;
    }

    const question = this.questions().find((item) => item.id === id);
    if (!question) {
      return;
    }

    const message = this.getSuggestionAnnouncement(actionType, suggestion, question);
    this.dispatchSuggestionAction(id, actionType, suggestion);
    this.announce(message);
  }

  /** Writes the short message announced to screen reader users after a suggestion is handled. */
  private getSuggestionAnnouncement(
    actionType: SuggestionAction | SuggestionActionType,
    suggestion: AiSuggestion,
    question: QuestionModel
  ): string {
    const questionNumber = question.questionNumber;
    switch (actionType) {
      case SuggestionActionType.ADD_OPTION:
        return `Option added to question ${questionNumber}.`;
      case SuggestionActionType.REPHRASE:
        return `Rephrase applied to question ${questionNumber}.`;
      case SuggestionActionType.REMOVE:
        if (suggestion.fieldPath === 'question') {
          return `Question ${questionNumber} removed.`;
        }
        return `Option removed from question ${questionNumber}.`;
      case SuggestionActionType.DISMISS:
      case SuggestionActionType.REVIEW:
        return `Suggestion dismissed for question ${questionNumber}.`;
      case SuggestionActionType.MARK_OPTIONAL:
        return `Question ${questionNumber} marked optional.`;
      default:
        return `Suggestion resolved for question ${questionNumber}.`;
    }
  }

  /** Makes the actual change to the survey for the chosen suggestion (add, rephrase, remove, dismiss, mark optional). */
  private dispatchSuggestionAction(
    id: string,
    actionType: SuggestionAction | SuggestionActionType,
    suggestion: AiSuggestion
  ): void {
    switch (actionType) {
      case SuggestionActionType.ADD_OPTION:
        this.commitSuggestionChange(
          this.validationService.applyAddOptionSuggestion(this.questions(), id, suggestion)
        );
        break;

      case SuggestionActionType.REPHRASE:
        this.commitSuggestionChange(
          this.validationService.rephraseSuggestion(this.questions(), id, suggestion)
        );
        break;

      // REVIEW has no outcome to apply, so resolving it just removes the suggestion.
      case SuggestionActionType.REVIEW:
      case SuggestionActionType.DISMISS:
        this.commitSuggestionChange(
          this.validationService.dismissSuggestion(this.questions(), id, suggestion.suggestionId)
        );
        break;

      case SuggestionActionType.REMOVE:
        if (suggestion.fieldPath === 'question') {
          const questionIndex = this.questions().findIndex((question) => question.id === id);
          if (questionIndex !== -1) {
            this.surveyService.removeQuestion(questionIndex);
            this.validationService.syncAfterSuggestionChange(this.questions());
          }
        } else {
          this.commitSuggestionChange(
            this.validationService.removeOptionSuggestion(this.questions(), id, suggestion)
          );
        }
        break;

      case SuggestionActionType.MARK_OPTIONAL: {
        const markedOptional = this.questions().map((question) =>
          question.id === id ? { ...question, isRequired: false } : question
        );
        this.commitSuggestionChange(
          this.validationService.dismissSuggestion(markedOptional, id, suggestion.suggestionId)
        );
        break;
      }
    }
  }

  /** Saves the updated questions and refreshes the survey's validation status (e.g. whether it can be published). */
  private commitSuggestionChange(questions: QuestionModel[]): void {
    this.surveyService.setQuestions(questions);
    this.validationService.syncAfterSuggestionChange(this.surveyService.getQuestions());
  }

  /** Applies every suggestion that can be fixed automatically when the user clicks "Fix all". */
  async handleFixAll(): Promise<void> {
    if (this.isApplyingAll()) {
      return;
    }

    const fixes = this.getFixableSuggestions();
    if (fixes.length === 0) {
      return;
    }

    this.isApplyingAll.set(true);
    const startedAt = Date.now();
    const totalBefore = this.mandatorySuggestionCount() + this.optionalSuggestionCount();

    try {
      // Let the loader render before the synchronous updates run.
      await this.wait(0);

      fixes.forEach(({ questionId, suggestion, actionType }) =>
        this.dispatchSuggestionAction(questionId, actionType, suggestion)
      );

      await this.wait(Math.max(0, FIX_ALL_MIN_LOADER_MS - (Date.now() - startedAt)));
    } finally {
      this.isApplyingAll.set(false);
      const count =
        totalBefore - (this.mandatorySuggestionCount() + this.optionalSuggestionCount());
      const message = count === 1 ? `${count} suggestion applied.` : `${count} suggestions applied.`;
      this.announce(message);
    }
  }

  /** Writes a message for screen reader users and moves focus back into the panel, because the clicked button disappears. */
  private announce(message: string): void {
    this.statusMessage.set('');
    // Publish in a separate task so identical consecutive announcements update the live region.
    setTimeout(() => {
      this.statusMessage.set(message);
      this.feedbackContainer()?.nativeElement.focus();
    });
  }

  /** Collects all suggestions that "Fix all" is allowed to apply, in a safe order. */
  private getFixableSuggestions(): FixAllItem[] {
    // Reads the option position from a path like "options[2]".
    const optionIndex = (fieldPath: string): number => {
      const match = fieldPath?.match(/\[(\d+)\]$/);
      return match ? Number(match[1]) : -1;
    };

    // Picks the action for a suggestion, or nothing if it needs the user's own decision.
    const resolveAction = (suggestion: AiSuggestion): SuggestionActionType | null => {
      const hasSuggestedText = !!suggestion.suggestedText?.trim();

      switch (suggestion.action) {
        case 'REMOVE':
          return SuggestionActionType.REMOVE;
        case 'ADD_OPTION':
          return hasSuggestedText ? SuggestionActionType.ADD_OPTION : null;
        case 'REPHRASE':
          return hasSuggestedText ? SuggestionActionType.REPHRASE : null;
        case 'REVIEW':
          return suggestion.severity === SUGGESTION_SEVERITY.OPTIONAL && !hasSuggestedText
            ? SuggestionActionType.REVIEW
            : null;

        case 'MARK_OPTIONAL':
          return SuggestionActionType.MARK_OPTIONAL;
        default:
          return null;
      }
    };

    return this.questionsWithSuggestions().flatMap((question) => {
      const questionId = question.id;
      // Edited questions must be revalidated first, as their suggestions may be out of date.
      if (!questionId || question.reviewRequired) {
        return [];
      }

      return (
        (question.suggestions ?? [])
          .map((suggestion) => ({ questionId, suggestion, actionType: resolveAction(suggestion) }))
          .filter((item): item is FixAllItem => item.actionType !== null)
          // Process higher indices first to prevent changes at lower indices from invalidating remaining suggestion positions.
          .sort((a, b) => optionIndex(b.suggestion.fieldPath) - optionIndex(a.suggestion.fieldPath))
      );
    });
  }

  private wait(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /** Finds the current wording (question, label or option) that a suggestion wants to change. */
  getOriginalText(question: QuestionModel, fieldPath: string): string {
    if (fieldPath === 'question') {
      return question.question;
    }

    if (fieldPath === 'npsLeftLabel' || fieldPath === 'npsRightLabel') {
      return question?.[fieldPath] ?? '';
    }

    const match = fieldPath?.match(/^(options|rowOptions|columnOptions)\[(\d+)\]$/);

    if (!match) {
      return '';
    }

    const [, field, index] = match;
    const values = question[field as 'options' | 'rowOptions' | 'columnOptions'];

    return values?.[Number(index)] ?? '';
  }

  onCloseRequested(): void {
    this.closeRequested.emit();
  }
}
