import { BasePage } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { UI_STATE_UPDATE_DELAY, PANEL_TRANSITION_DELAY } from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';
import surveyBuilderPageResources from '../../locators/survey/surveyBuilder.locator.json';
import devTestData from '../../test-data/dev-test-data.json';

const SURVEY_BUILDER_PAGE_COMPONENT_NAME = 'surveyBuilderPage';
const MAX_QUESTIONS_TOOLTIP_TIMEOUT = 10 * 1000; // TC_BS_08 — tooltip may render in a portal after a short delay
const ADD_QUESTION_VISIBLE_TIMEOUT = 10 * 1000; // ensureQuestionCount — preview-mode's add-question button renders async after the prior question saves
const PUBLISH_SUCCESS_TOAST_TIMEOUT = 15 * 1000; // TC_BS_PUBLISH — toast follows the real /publish network round-trip
const QUESTION_TYPE_PICKER_TIMEOUT = 10 * 1000; // clickQuestionTypeResource / ensureQuestionCount retry — fail fast instead of hanging 5m on a missing tile
const QUESTION_TYPE_TILE_FIRST_CHECK_TIMEOUT = 5 * 1000; // ensureQuestionCount — first check for the type tile after a single add-question click
const QUESTION_SAVE_TIMEOUT = 10 * 1000; // ensureQuestionCount — wait for the saved-question marker count to increase after addRatingQuestion()
const PUBLISH_NAVIGATION_TIMEOUT = 60 * 1000; // TC_BS_PUBLISH — wait for the post-publish redirect to /my-assets/survey
const PUBLISH_TOAST_CHECK_TIMEOUT = 10 * 1000; // TC_BS_PUBLISH — toast check once the redirect has confirmed the publish succeeded
const PUBLISH_POST_CLICK_TIMEOUT = 15 * 1000; // publishSurvey — Publish opens either the Save-a-copy dialog or (if already saved) the Confirm dialog directly

/**
 * SurveyBuilderPage — covers the "Build Survey" screen: adding questions of each
 * type (TC_BS_03–TC_BS_09), review mode (part of TC_BS_13), and save/publish
 * (TC_BS_16).
 *
 * IMPORTANT ASSUMPTIONS / UNCONFIRMED ITEMS (verify against live DOM before
 * trusting these in CI):
 *
 * 1. `optionInputByLabel`/row/column inputs are resolved by role name + `nth=0`,
 * NOT scoped to a specific question. This only works reliably for the question
 * currently expanded/being edited (i.e. call these methods for one question at
 * a time, right after adding it, before adding the next). Once a question
 * collapses (per TC_BS_03 step 4), `reopenCollapsedQuestion()` (via
 * `editQuestionButton`, `[niqtooltip='Edit']`) re-expands it — confirmed present
 * via live DevTools inspection. UNCONFIRMED: `[niqtooltip='Edit']` is a single
 * static locator with no per-question scoping. Once more than one question has
 * collapsed on the page (from TC_BS_04 onward), this selector will match
 * multiple elements and is ambiguous — Playwright strict-mode will throw. A
 * live-DOM check of the collapsed-question container markup is needed to scope
 * this to the specific question (e.g. a per-question wrapper id/data-test-id)
 * before trusting it beyond the very first question.
 * 2. `requiredToggle` ([data-test-id='-input-checkbox']) is CONFIRMED correct per
 * real Codegen recording — the truncated id with no real prefix is how the
 * live DOM actually renders it.
 * 3. Point Scale's "+ Row"/"+ Column" buttons are CONFIRMED (via source, see
 * item 11) to share the exact same `survey-scale-editor` component and
 * matrix-actions hover mechanism as Multi Scale (`selectedType()` only toggles
 * radio-button vs checkbox cells, not the add-row/column controls) — the fix
 * applied to `addRowToQuestion()`/`addColumnToQuestion()` for Multi Scale
 * applies equally to Point Scale. `TC_BS_08` unblocked accordingly.
 * 4. No locator exists yet for the "Text" question type (TC_BS_06) — it was never
 * exercised in the Codegen capture. addTextQuestion() is NOT implemented here;
 * add it once a locator is confirmed.
 * 5. "Publish" is confirmed by the dev team (TC_BS_14, TC_BS_16) to currently be a
 * no-op with no validation. publishSurvey() below only performs the click —
 * callers should NOT assert a "published" outcome until backend support ships.
 * 6. The earlier "Build Survey" blur-click fix (`surveyBuilderBlurTarget`) was
 * REMOVED — a real test run confirmed the blur clicks fired successfully but
 * "Add option" still never became interactable. Root cause is the question
 * card collapsing/saving after a field fill, not just losing focus; the fix
 * is `reopenCollapsedQuestion()` (see item 1) instead of blurring.
 * 7. `ratingQuestionTextInput` is confirmed present via live DevTools inspection
 * for Rating's question-text field, but has NO confirmed per-question/index
 * scoping. Two different real DOM captures have been seen for it at different
 * times: a generic truncated attribute `[data-test-id='-input']`, and later a
 * numeric auto-generated `[id='text-field-80']`-style id (the latter is a
 * classic UI-library sequential-counter id — NOT deterministically tied to
 * the Rating question; its exact number depends on how many similar
 * components were instantiated earlier on the page, so it can silently point
 * at the wrong element between runs, which is the confirmed root cause of
 * TC_BS_05 "runs without error but nothing visibly typed"). Reverted to the
 * generic `data-test-id` attribute with a `:visible` filter appended (only the
 * currently-expanded question's field should be visible; a prior question's
 * collapsed field should not be) as a best-effort interim scoping — this is
 * NOT the index-based `${text}` pattern `questionTextInput` uses, because no
 * confirmed indexed/unique attribute exists for Rating's field yet. A fresh
 * live-DOM capture of Rating's text field specifically while a prior question
 * already exists on the page is needed to confirm a real indexed attribute
 * before this can match the `questionTextInput` pattern. `addRatingQuestion()`
 * does not accept/need a questionIndex at all, since this locator isn't index-based.
 * 8. `addOptionButton` (shared by `addSingleChoiceQuestion()` and
 * `addMultipleChoiceQuestion()` via `addOptionToQuestion()`) was a page-wide,
 * unscoped `text=` locator with no question-scoping — once a prior question
 * already exists on the page (e.g. TC_BS_04 running after TC_BS_03), its
 * "Add option" control resolves to 2 elements and Playwright strict-mode
 * throws. Reverted to the previously-confirmed `niq-button:has-text('Add
 * option')` form with a `:visible` filter appended, same interim mitigation
 * technique as item 7 — assumes a prior (collapsed) question's control isn't
 * visible. Not independently re-confirmed live.
 * 9. `addMultipleChoiceQuestion()`, `addRatingQuestion()`, `addNPSQuestion()`, and
 * `addMultiScaleQuestion()` all now call the existing `clickAddQuestion()`
 * (reusing `addQuestionLink`) at the end, to finalize/save the question (manual
 * click confirmed live to unblock the flow for Multiple Choice → Rating). RISK:
 * `survey-builder.spec.ts` ALSO still calls `clickAddQuestion()` separately
 * before each of `addRatingQuestion()` (TC_BS_05) and `addNPSQuestion()`
 * (TC_BS_07) — "Add question" is clicked twice in a row at each of those
 * transitions, which likely creates an extra blank question each time. Not
 * resolved here since it requires editing the spec file, out of scope for
 * these fixes — needs an explicit follow-up decision on removing the redundant
 * external calls. `addMultiScaleQuestion()` does NOT have this same double-click
 * risk today since no test currently runs after TC_BS_09 that calls
 * `clickAddQuestion()` again.
 * 10. `addNPSQuestion()` fills NPS's question text via the SHARED
 * `questionTextInput` resource (same index-based locator Single/Multiple
 * Choice use: `[data-test-id='question-text-input-${text}-input']`) — CONFIRMED
 * correct via live DevTools inspection: `<input data-test-id="question-text-
 * input-4-input" placeholder="Question">`, matching the live-rendered index at
 * the time of that capture. See item 12 — this index is now computed
 * dynamically rather than passed in by the caller.
 * 11. `addRowToQuestion()`/`addColumnToQuestion()` (Point Scale/Multi Scale):
 * per `e2e/SURVEY_BUILDER_HOVER_INVESTIGATION.md`, the real Angular source
 * (`libs/survey-mod-lib/.../scale-editor.component.html`) confirmed the "Row"/
 * "Column" buttons only exist in the DOM once the WRAPPING `.matrix-action-area`
 * div's `mouseenter` sets `showAddMenu = true` — hovering the button itself
 * (the earlier fix) could never work, and there is NO CSS transition to delay
 * for, so the delay-based mitigation was removed. Now hovers `scaleAddMenuTrigger`
 * (`.matrix-action-area:has(niq-icon-button[iconname='add-large'])`) first,
 * then resolves `addRowButton`/`addColumnButton` SCOPED WITHIN that same
 * wrapper (via `WebElement.getWebElement()` chaining) so the Add menu's
 * buttons are targeted, not the Delete menu's identically-labeled ones.
 * UNCONFIRMED: this has NOT been run against the live app yet. Also: `.last()`
 * does NOT exist on this codebase's `WebElement` API (confirmed by reading
 * `@gfk/gta`'s webElement.d.ts) and `editQuestionButton` does NOT actually use
 * any such pattern today (it has a known, still-open, unscoped-selector risk —
 * see item 1) — so `scaleAddMenuTrigger` uses the same `:visible` interim
 * scoping already used for `ratingQuestionTextInput`/`addOptionButton` (items
 * 7-8) instead, which has the same residual multi-question-on-page risk.
 * 12. `questionIndex` is NO LONGER a caller-supplied literal. Per
 * `question-editor.component.ts`'s `upcomingQuestionNumber = surveyService
 * .getQuestions().length + 1`, the real index for a new question is always
 * `(current saved question count) + 1`, computed live — not a fixed sequence
 * number — because the persisted survey's question count isn't stable across
 * runs (manual testing, partial failures, etc. can leave it with more/fewer
 * questions than the test suite assumes). Hardcoded indices (TC_BS_08 was
 * tried as 6, then 7; the live value was actually 5) are a structural bug
 * class, not a one-off typo. `getNextQuestionIndex()` now counts the
 * rendered `.question-number` markers (`questionNumberMarker` resource) on
 * already-saved questions and returns `count + 1`, mirroring the app's own
 * computation. Every `addXQuestion()` method calls this internally; none of
 * them accept a `questionIndex` parameter anymore.
 */
export class SurveyBuilderPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      SURVEY_BUILDER_PAGE_COMPONENT_NAME,
      surveyBuilderPageResources
    );
  }

  // Question type selection
  private async clickQuestionTypeResource(resourceName: string): Promise<void> {
    const typeButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(resourceName, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    if (!(await typeButton.isVisible(QUESTION_TYPE_PICKER_TIMEOUT))) {
      // isVisible() returns false on timeout instead of throwing, unlike waitFor() — check explicitly so the click can't hang 5m on a missing tile.
      throw new Error(`Question-type tile "${resourceName}" did not become visible within ${QUESTION_TYPE_PICKER_TIMEOUT}ms`);
    }
    await typeButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  // Shared field helpers (operate on the currently expanded/editing question)
  private async fillQuestionText(questionIndex: number, text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('questionTextInput', String(questionIndex), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await questionText.waitFor();
    await questionText.enterText(text);
  }

  /** Fills Option N / Row N / Column N fields by their visible role label, e.g. 'Option 1', 'Row 2'. */
  private async fillLabeledField(label: string, value: string): Promise<void> {
    const field = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('optionInputByLabel', label, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await field.waitFor();
    await field.enterText(value);
  }

  /** Fills Rating's question-text field — see class-level comment #7 for the unscoped-locator risk. */
  private async fillRatingQuestionText(text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('ratingQuestionTextInput', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await questionText.waitFor();
    await questionText.enterText(text);
  }

  /**
   * Computes the questionIndex for a new question the same way the app itself does:
   * `surveyService.getQuestions().length + 1` (see question-editor.component.ts's
   * `upcomingQuestionNumber`). Counts the rendered `.question-number` markers on
   * already-saved questions rather than trusting any hardcoded literal, since the
   * persisted survey's question count is not stable across runs.
   */
  private async getNextQuestionIndex(): Promise<number> {
    const markers = await this.webActionHandler.getWebElementsText(
      this.resourceManager.getResource('questionNumberMarker', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    return markers.length + 1;
  }

  /** Counts rendered `.question-number` markers, for TC_BS_REVIEW_MODE's delete-count assertion. */
  async getQuestionCount(): Promise<number> {
    const markers = await this.webActionHandler.getWebElementsText(
      this.resourceManager.getResource('questionNumberMarker', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    return markers.length;
  }

  /** Re-expands the question card after it collapses/saves on field-fill — see class-level comment #1.
   *  `editQuestionButton` ([niqtooltip='Edit']) matches one icon per question, so once 2+ questions
   *  exist it's a Playwright strict-mode violation; scope to the LAST match (the question just added). */
  private async reopenCollapsedQuestion(): Promise<void> {
    const questionCount = await this.getQuestionCount();
    const editButtonResource = this.resourceManager.getResource('editQuestionButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME);
    const editButton = this.webActionHandler.getWebElement({
      ...editButtonResource,
      selectorType: 'playwrights',
      selectorValue: `${editButtonResource.selectorValue} >> nth=${Math.max(questionCount - 1, 0)}`
    });
    await editButton.waitFor();
    await editButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async addOptionToQuestion(): Promise<void> {
    const addOption = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addOptionButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addOption.waitFor();
    await addOption.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** Hovers the Add-menu trigger wrapper so the Row/Column buttons render — see class-level comment #11. */
  private async hoverScaleAddMenuTrigger() {
    const addMenuTrigger = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('scaleAddMenuTrigger', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addMenuTrigger.waitFor();
    await addMenuTrigger.hover();
    return addMenuTrigger;
  }

  /** UNCONFIRMED for Point Scale — see class-level comment #3. */
  async addRowToQuestion(): Promise<void> {
    const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
    const addRow = addMenuTrigger.getWebElement(
      this.resourceManager.getResource('addRowButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addRow.waitFor();
    await addRow.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** UNCONFIRMED for Point Scale — see class-level comment #3. */
  async addColumnToQuestion(): Promise<void> {
    const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
    const addColumn = addMenuTrigger.getWebElement(
      this.resourceManager.getResource('addColumnButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addColumn.waitFor();
    await addColumn.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** UNCONFIRMED locator — see class-level comment #2. Do not rely on this without a live DOM check. */
  async toggleRequired(): Promise<void> {
    const toggle = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('requiredToggle', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await toggle.waitFor();
    await toggle.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** TC_BS_12 — footer's "Back" button (footer.component.html), no data-test-id, resolved by text. */
  async clickBackButton(): Promise<void> {
    const backButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('backButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await backButton.waitFor(10000);
    await backButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** TC_BS_12 — stepper's clickable circle (niq-step-circle, athena-core StepComponent), text doesn't navigate; index 0 = Select Panelists. */
  async clickSelectPanelistsStep(): Promise<void> {
    const step = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('select-panelists-step-circle', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await step.waitFor(10000);
    await step.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async clickAddQuestion(): Promise<void> {
    const addQuestion = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addQuestionLink', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addQuestion.waitFor();
    await addQuestion.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  // ---------------------------------------------------------------------
  // Per-question-type methods (TC_BS_03–TC_BS_09)
  // Each assumes it is called right after clickAddQuestion() (or for
  // question 1, right after landing on Build Survey), while this question
  // is the currently expanded one.
  // ---------------------------------------------------------------------

  /** TC_BS_03 */
  async addSingleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeSingleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.reopenCollapsedQuestion();
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }
    } catch (error) {
      throw new Error(`Failed to add Single Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_04 */
  async addMultipleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultipleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question, see class-level comment #9 for the double-click risk this introduces
    } catch (error) {
      throw new Error(`Failed to add Multiple Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_05 */
  async addRatingQuestion(questionText: string): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeRating');
      await this.fillRatingQuestionText(questionText); // Rating's input is unscoped by index, see class-level comment #7
      await this.clickAddQuestion(); // finalizes/saves this question, see class-level comment #9 for the double-click risk this introduces
    } catch (error) {
      throw new Error(`Failed to add Rating question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * TC_BS_06 — NOT IMPLEMENTED. No confirmed locator for the "Text" question
   * type exists yet (never exercised in the Codegen capture). Add this once
   * `questionTypeText` is confirmed and added to survey-builder.locator.json.
   */
  // async addTextQuestion(questionIndex: number, questionText: string): Promise<void> { ... }

  /** TC_BS_07 */
  async addNPSQuestion(questionText: string): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeNPS');
      await this.fillQuestionText(questionIndex, questionText); // confirmed via DevTools: NPS reuses questionTextInput at this index, see class-level comment #10
      await this.clickAddQuestion(); // finalizes/saves this question, see class-level comment #9 for the double-click risk this introduces
    } catch (error) {
      throw new Error(`Failed to add Net Promoter Score question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * TC_BS_08 — Point Scale. Shares the exact same `survey-scale-editor` Angular
   * component (and matrix-actions hover mechanism) as Multi Scale — confirmed
   * via source, see class-level comment #11.
   */
  async addPointScaleQuestion(
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypePointScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question, see class-level comment #9 for the double-click risk this introduces
    } catch (error) {
      throw new Error(`Failed to add Point Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_09 — Multi Scale, including add-row/add-column (confirmed real per Codegen + TC_BS_09). */
  async addMultiScaleQuestion(
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultiScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question, see class-level comment #9 for the double-click risk this introduces
    } catch (error) {
      throw new Error(`Failed to add Multi Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Review mode (part of TC_BS_13; select/reorder indices per Codegen —
  // NOT independently confirmed against a clean manual flow)

  async enterReviewMode(): Promise<void> {
    const reviewButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('reviewSurveyButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await reviewButton.waitFor();
    await reviewButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  async selectQuestionInReview(index: number): Promise<void> {
    const questionCheckbox = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await questionCheckbox.waitFor();
    await questionCheckbox.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async deleteSelectedQuestions(): Promise<void> {
    const deleteButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('deleteQuestionsButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await deleteButton.waitFor();
    await deleteButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async selectAll(): Promise<void> {
    const selectAllButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('selectAllButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await selectAllButton.waitFor(10000);
    await selectAllButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async unselectAll(): Promise<void> {
    const unselectAllButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('unselectAllButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await unselectAllButton.waitFor();
    await unselectAllButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async expandAll(): Promise<void> {
    const expandAllButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('expandAllButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await expandAllButton.waitFor(10000);
    await expandAllButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async collapseAll(): Promise<void> {
    const collapseAllButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('collapseAllButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await collapseAllButton.waitFor(10000);
    await collapseAllButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async exitReviewMode(): Promise<void> {
    const exitButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('exitReviewModeButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await exitButton.waitFor();
    await exitButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /** TC_BS_13: Select All/Expand All/Collapse All/Delete/Exit Review Mode buttons all visible. */
  async areReviewControlsVisible(): Promise<boolean> {
    const controls = ['selectAllButton', 'expandAllButton', 'collapseAllButton', 'deleteQuestionsButton', 'exitReviewModeButton'];
    for (const control of controls) {
      const element = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(control, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      if (!(await element.isVisible())) {
        return false;
      }
    }
    return true;
  }

  /** TC_BS_13: counts visible select-question checkboxes across indices 0..questionCount-1. */
  async getReviewCheckboxCount(questionCount: number): Promise<number> {
    let visibleCount = 0;
    for (let index = 0; index < questionCount; index++) {
      const checkbox = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      if (await checkbox.isVisible()) {
        visibleCount++;
      }
    }
    return visibleCount;
  }

  /** TC_BS_14: ticked state of a single Review Mode question checkbox — `select-question-<i>-icon`
   * is a `<niq-icon>` with no checked state of its own; the real `checked`/`unchecked` class
   * lives on its ancestor `.checkbox-container` (niq-checkbox's own template). */
  async isQuestionSelected(index: number): Promise<boolean> {
    const container = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('selectQuestionCheckboxContainer', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    const classAttr = (await container.getAttribute('class')) ?? '';
    return classAttr.split(/\s+/).includes('checked');
  }

  /** TC_BS_14: raw `.question-number` marker texts, for post-delete renumbering assertion. */
  async getQuestionNumbers(): Promise<string[]> {
    return this.webActionHandler.getWebElementsText(
      this.resourceManager.getResource('questionNumberMarker', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
  }

  /** Polls `getQuestionNumbers()` until its length reaches `target`, or throws after `timeout` ms. */
  private async waitForQuestionCountAtLeast(target: number, timeout: number): Promise<string[]> {
    const start = Date.now();
    let questionNumbers = await this.getQuestionNumbers();
    while (questionNumbers.length < target) {
      if (Date.now() - start >= timeout) {
        throw new Error(`Timed out waiting for question count to reach ${target} (current: ${questionNumbers.length})`);
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      questionNumbers = await this.getQuestionNumbers();
    }
    return questionNumbers;
  }

  /** TC_BS_PUBLISH/@ReviewMode precondition — tops up to `min` Rating questions, stopping as soon as the
   *  saved count (`.question-number`) reaches it. The Rating tile is a toggle (clicking add-question again
   *  while it's open closes it with ✕), so add-question is only clicked when the tile isn't already visible. */
  async ensureQuestionCount(min: number): Promise<void> {
    const { questionText } = devTestData.surveyQuestions.rating;
    let questionNumbers = await this.getQuestionNumbers();

    while (questionNumbers.length < min) {
      const countBeforeAdd = questionNumbers.length;
      const typeTile = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('questionTypeRating', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );

      if (!(await typeTile.isVisible(QUESTION_TYPE_TILE_FIRST_CHECK_TIMEOUT))) {
        await this.clickAddQuestion();
        if (!(await typeTile.isVisible(QUESTION_TYPE_PICKER_TIMEOUT))) {
          throw new Error(`Question-type picker did not open after clicking add-question (current question count: ${countBeforeAdd})`);
        }
      }

      await this.addRatingQuestion(`${questionText} ${countBeforeAdd + 1}`);
      questionNumbers = await this.waitForQuestionCountAtLeast(countBeforeAdd + 1, QUESTION_SAVE_TIMEOUT);
    }
  }

  // Survey name, save, publish (TC_BS_02, TC_BS_16)
  /** TC_BS_02 */
  async setSurveyTitle(title: string): Promise<void> {
    try {
      const editIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('editSurveyNameIcon', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await editIcon.waitFor();
      await editIcon.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const titleInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('surveyTitleInput', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await titleInput.waitFor();
      await titleInput.enterText(title);
    } catch (error) {
      throw new Error(`Failed to set survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Fills the Save-a-copy dialog (title, My Assets, save pending changes) — shared by saveDraft() and publishSurvey(). */
  private async fillSaveCopyDialog(title: string): Promise<void> {
    const titleInput = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('saveCopyTitleInput', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await titleInput.waitFor();
    await titleInput.enterText(title);

    const myAssetsTreeItem = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('myAssetsTreeItem', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await myAssetsTreeItem.waitFor();
    await myAssetsTreeItem.click();

    const savePendingChangesButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('savePendingChangesButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await savePendingChangesButton.waitFor();
    await savePendingChangesButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /** TC_BS_SAVE_DRAFT — opens Save Draft dialog, titles the copy, picks My Assets, and confirms. */
  async saveDraft(title: string): Promise<void> {
    try {
      const saveDraftButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('saveDraftButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await saveDraftButton.waitFor();
      await saveDraftButton.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      await this.fillSaveCopyDialog(title);
    } catch (error) {
      throw new Error(`Failed to save draft: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_SAVE_DRAFT — navigates to My Assets and checks the saved survey's gridcell is visible. */
  async isSurveyVisibleInMyAssets(title: string): Promise<boolean> {
    const myAssetsURL = this.buildUrl(envConfig.BASE_URL, 'survey/my-assets');
    await this.navigateToUrl(myAssetsURL);
    const gridcell = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('savedAssetGridcellByTitle', title, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    return gridcell.isVisible();
  }

  /** TC_BS_SAVE_DRAFT — checks the post-save toast confirming the draft was saved. */
  async isDraftSavedToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('saveDraftSuccessToast', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    return toast.isVisible(10000);
  }

  /** TC_BS_08 — "Add question" has no `state` attribute; disabled is reflected as a `disabled` class token (or aria-disabled). */
  async getAddQuestionDisabledState(): Promise<{ disabled: boolean; classAttr: string }> {
    const addQuestion = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addQuestionLink', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    const classAttr = (await addQuestion.getAttribute('class')) ?? '';
    const ariaDisabled = await addQuestion.getAttribute('aria-disabled');
    return { disabled: classAttr.split(/\s+/).includes('disabled') || ariaDisabled === 'true', classAttr };
  }

  /** TC_BS_08 — scrolls into view, hovers "Add question", and checks the max-questions tooltip appears. */
  async isAddQuestionTooltipVisibleOnHover(): Promise<boolean> {
    const addQuestion = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addQuestionLink', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addQuestion.executeScript((e) => e.scrollIntoView());
    await addQuestion.hover();
    const message = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('maxQuestionsMessageText', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    const isTooltipVisible = await message.isVisible(MAX_QUESTIONS_TOOLTIP_TIMEOUT); // web-first wait, no fixed delay
    await this.webActionHandler.mouseMove(0, 0); // move off the hovered button so the tooltip doesn't linger into the next test
    await message.waitFor(MAX_QUESTIONS_TOOLTIP_TIMEOUT, 'hidden');
    return isTooltipVisible;
  }

  /** `duplicateQuestionButton` matches one icon per question — scope to a single question (default: first). */
  private getDuplicateQuestionElement(questionIndex = 0) {
    const duplicateResource = this.resourceManager.getResource('duplicateQuestionButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME);
    return this.webActionHandler.getWebElement({
      ...duplicateResource,
      selectorType: 'playwrights',
      selectorValue: `${duplicateResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** `.question-actions` (incl. Duplicate) is only revealed via `.question-row`'s (mouseenter) handler — see
   *  preview-mode.component.html/.scss — not a CSS :hover. Scope to a single row (default: first). */
  private getQuestionRowElement(questionIndex = 0) {
    const rowResource = this.resourceManager.getResource('questionRow', SURVEY_BUILDER_PAGE_COMPONENT_NAME);
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** TC_BS_08 — hovers the first question's row (reveals Duplicate, see getQuestionRowElement), then hovers
   *  Duplicate and checks the tooltip appears within 10s. */
  async isDuplicateTooltipVisibleOnHover(): Promise<boolean> {
    const row = this.getQuestionRowElement();
    await row.hover();
    const duplicateButton = this.getDuplicateQuestionElement();
    await duplicateButton.executeScript((e) => e.scrollIntoView());
    await duplicateButton.hover();
    const message = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('maxQuestionsMessageText', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    const isTooltipVisible = await message.isVisible(MAX_QUESTIONS_TOOLTIP_TIMEOUT); // web-first wait (10s), no fixed delay
    await this.webActionHandler.mouseMove(0, 0); // move off Duplicate so the tooltip doesn't linger into the next test
    await message.waitFor(MAX_QUESTIONS_TOOLTIP_TIMEOUT, 'hidden');
    return isTooltipVisible;
  }

  /** TC_BS_08 — Duplicate's disabled state (aria-disabled, or legacy `state` attribute) + outerHTML for failure diagnostics. */
  async getDuplicateDisabledState(): Promise<{ disabled: boolean; outerHtml: string }> {
    const duplicateButton = this.getDuplicateQuestionElement();
    const ariaDisabled = await duplicateButton.getAttribute('aria-disabled');
    const state = await duplicateButton.getAttribute('state');
    const outerHtml = String(await duplicateButton.executeScript((e) => e.outerHTML)).slice(0, 400);
    return { disabled: ariaDisabled === 'true' || state === 'disabled', outerHtml };
  }

  /** TC_BS_PUBLISH — clicks Publish, then either fills the Save-a-copy dialog (if it appears) or, if the
   *  survey was already saved (e.g. by Save draft), Publish opens the Confirm publish? dialog directly. */
  async publishSurvey(title: string): Promise<void> {
    try {
      const publishButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('publishSurveyButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await publishButton.waitFor();
      await publishButton.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const titleInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('saveCopyTitleInput', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      const confirmDialogText = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('confirmPublishDialogText', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      const [isTitleInputVisible, isConfirmDialogVisible] = await Promise.all([
        titleInput.isVisible(PUBLISH_POST_CLICK_TIMEOUT),
        confirmDialogText.isVisible(PUBLISH_POST_CLICK_TIMEOUT),
      ]);

      if (isTitleInputVisible) {
        await this.fillSaveCopyDialog(title);
      } else if (!isConfirmDialogVisible) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        throw new Error(`Neither the Save-a-copy dialog nor the Confirm publish? dialog appeared after clicking Publish (url: ${currentUrl})`);
      }
    } catch (error) {
      throw new Error(`Failed to publish survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — "Quick review" dimensions in the Confirm publish? dialog each render with
   *  `data-test-id="ds-<Label>_Dimension"` inside `#publish-data-summary` (confirmed via
   *  @nielsen/crf-data-summary's compiled template). Checks the last expected index is visible. */
  async isPublishDialogDimensionCountVisible(expectedCount: number): Promise<boolean> {
    try {
      if (expectedCount <= 0) return true;
      const lastDimension = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('publish-dialog-dimension-by-index', String(expectedCount - 1), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await lastDimension.waitFor(10000);
      return await lastDimension.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to verify Confirm publish? dimension count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — reads the "<count> responses." text from the Confirm publish? dialog's response summary. */
  async getPublishResponseSummaryText(): Promise<string> {
    try {
      const responseCount = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('publish-response-count-text', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await responseCount.waitFor(10000);
      const text = await responseCount.getText();
      return (text ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read Confirm publish? response summary: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — "Survey published successfully." toast fired by survey-publish-popup.component.ts after confirm. */
  async isPublishSuccessToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('publish-success-toast', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    return toast.isVisible(PUBLISH_SUCCESS_TOAST_TIMEOUT);
  }

  /** TC_BS_PUBLISH — post-Confirm success check: waits for the `/my-assets` redirect (confirmPublish calls
   *  router.navigateByUrl('/my-assets/survey')), then checks the success toast. Throws with current URL,
   *  elapsed time, and any `.survey-action-toast` text if either wait fails. */
  /** TC_BS_PUBLISH — post-Confirm outcome check. Polls up to 60s: success once the URL has redirected to
   *  `/my-assets` and the success toast confirms it; fails fast as soon as `.survey-action-toast` shows
   *  anything other than the success text (survey-publish-popup.component.ts's error handler reuses the
   *  same `containerClass: 'survey-action-toast'` for `InsertToast('error', <backend message>, ...)`, so
   *  there is no separate error-only locator to check). */
  async verifyPublishSucceeded(confirmClickTime: number): Promise<boolean> {
    const elapsedSeconds = () => ((Date.now() - confirmClickTime) / 1000).toFixed(1);
    const actionToast = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('survey-action-toast', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    const successToast = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('publish-success-toast', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );

    const deadline = Date.now() + PUBLISH_NAVIGATION_TIMEOUT;
    while (Date.now() < deadline) {
      const currentUrl = await this.webActionHandler.getPageUrl();
      if (currentUrl.includes('my-assets')) {
        if (await successToast.isVisible(PUBLISH_TOAST_CHECK_TIMEOUT)) {
          return true;
        }
        const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
        throw new Error(`"Survey published successfully" toast did not appear after redirect (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`);
      }

      if (await actionToast.isVisible(0)) {
        const toastText = await actionToast.getText();
        if (!toastText.includes('Survey published successfully')) {
          throw new Error(`Publish failed: "${toastText}" (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s)`);
        }
      }

      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    }

    const currentUrl = await this.webActionHandler.getPageUrl();
    const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
    throw new Error(`Timed out waiting for navigation to /my-assets after Confirm (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`);
  }

  /** TC_BS_PUBLISH — asserts "Confirm publish?" prompt, clicks Confirm, and waits for the "Publishing survey" status. */
  async confirmPublish(): Promise<boolean> {
    try {
      const confirmPublishDialogText = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('confirmPublishDialogText', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await confirmPublishDialogText.waitFor();
      const isConfirmDialogVisible = await confirmPublishDialogText.isVisible();

      const confirmButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('confirmPublishButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await confirmButton.waitFor();
      await confirmButton.click();

      const publishingSurveyStatus = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('publishingSurveyStatus', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await publishingSurveyStatus.waitFor();
      const isPublishingStatusVisible = await publishingSurveyStatus.isVisible();

      return isConfirmDialogVisible && isPublishingStatusVisible;
    } catch (error) {
      throw new Error(`Failed to confirm publish: ${error instanceof Error ? error.message : error}`);
    }
  }
}
