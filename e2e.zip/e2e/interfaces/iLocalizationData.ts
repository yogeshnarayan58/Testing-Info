export interface SurveyLocalizationData {
  locale: string;
  languageName?: string; 
  countryName?: string;
  lastRefreshedLabel?: string; // footer "Last refreshed" label, without trailing colon
  [key: string]: string | string[] | undefined;
}
