import { WebActions } from '@gfk/gta';
import { ResourceManager } from '../../utils/resource-manager';
import { SMALL_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';

/**
 * Resource key names for the dataset elements referenced by
 * searchAndSelectDataset(). start-from-scratch.page.ts and
 * start-with-prompt.page.ts register these under different elementName
 * values, so the caller supplies its own keys.
 */
export interface DatasetSelectionResourceKeys {
  datasetResourceKey: string;
  searchToggleResourceKey: string;
  searchInputResourceKey: string;
}

/**
 * Searches for and selects a dataset on the "Choose a dataset" screen.
 * Extracted from the near-identical searchAndSelectDataset() logic that was
 * duplicated in start-from-scratch.page.ts and start-with-prompt.page.ts:
 * check chooseDatasetBreadcrumb visibility -> fallback to
 * chooseDataviewBreadcrumb -> check default dataset text -> check
 * already-visible dataset element -> toggle search -> type search term ->
 * click dataset element.
 */
export async function searchAndSelectDataset(
  webActionHandler: WebActions,
  resourceManager: ResourceManager,
  componentName: string,
  searchTerm: string,
  datasetLabel: string,
  resourceKeys: DatasetSelectionResourceKeys
): Promise<boolean> {
  const { datasetResourceKey, searchToggleResourceKey, searchInputResourceKey } = resourceKeys;

  const chooseDatasetBreadcrumb = webActionHandler.getWebElement(
    resourceManager.getResource('chooseDatasetBreadcrumb', componentName)
  );
  const isOnDatasetScreen = await chooseDatasetBreadcrumb.isVisible();
  if (!isOnDatasetScreen) {
    const chooseDataviewBreadcrumb = webActionHandler.getWebElement(
      resourceManager.getResource('chooseDataviewBreadcrumb', componentName)
    );
    const hasReachedDataviewScreen = await chooseDataviewBreadcrumb.isVisible().catch(() => false);
    return hasReachedDataviewScreen;
  }

  const defaultDatasetElement = webActionHandler.getWebElement(
    resourceManager.getResource('defaultDataset', componentName)
  );
  const defaultDatasetText = await defaultDatasetElement.getText().catch(() => '');
  const isDefaultDatasetAlreadySelected = defaultDatasetText.trim().toLowerCase().includes(datasetLabel.trim().toLowerCase());
  if (isDefaultDatasetAlreadySelected) {
    return true;
  }

  const existingDatasetElement = webActionHandler.getWebElement(
    resourceManager.getDynamicResource(datasetResourceKey, datasetLabel, componentName)
  );
  const isDatasetAlreadyVisible = await existingDatasetElement.isVisible().catch(() => false);
  if (isDatasetAlreadyVisible) {
    await existingDatasetElement.click();
    return true;
  }

  const searchToggle = webActionHandler.getWebElement(
    resourceManager.getResource(searchToggleResourceKey, componentName)
  );
  await searchToggle.waitFor(SMALL_TIMEOUT);
  await searchToggle.click();

  const searchInput = webActionHandler.getWebElement(
    resourceManager.getResource(searchInputResourceKey, componentName)
  );
  await searchInput.waitFor(SMALL_TIMEOUT);
  await searchInput.enterText(searchTerm);
  await webActionHandler.delay(UI_STATE_UPDATE_DELAY);

  const datasetElement = webActionHandler.getWebElement(
    resourceManager.getDynamicResource(datasetResourceKey, datasetLabel, componentName)
  );
  await datasetElement.waitFor(SMALL_TIMEOUT);
  await datasetElement.click();
  return true;
}
