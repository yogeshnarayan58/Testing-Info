import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import template from './survey-details.component.html?raw';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SurveyDetailsComponent } from './survey-details.component';
import { SurveyGridRow } from '../../models/survey-asset.model';

vi.mock('@nielseniq/athena-core', () => ({
  IconModule: class {},
  TagModule: class {},
  TooltipModule: class {},
}));

describe('SurveyDetailsComponent access', () => {
  it.each(['DRAFT', 'PUBLISHED', 'LIVE', 'SAVED'])('shows sharing guidance for a %s survey', (status) => {
    const { fixture, survey } = createDetails();
    survey.update((value) => ({ ...value, status }));
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.querySelector('[data-test-id="survey-details-share-notice"]')?.textContent)
      .toContain('Surveys can be shared once they are closed');
    expect(element.querySelector('[data-test-id="survey-details-share"]')).toBeNull();
  });

  it.each([
    ['DISCOVERSURVEY', 'CLOSED'],
    ['DISCOVERSURVEY', 'closed'],
    ['DISCOVERFOLDER', 'OPEN'],
    ['DISCOVERSHAREDFOLDER', 'OPEN'],
  ])('hides sharing guidance for %s with status %s', (assetType, status) => {
    const { fixture, survey } = createDetails();
    survey.update((value) => ({ ...value, assetType, status }));
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.querySelector('[data-test-id="survey-details-share-notice"]')).toBeNull();
    expect(element.querySelector('[data-test-id="survey-details-share"]')).not.toBeNull();
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({})
      .overrideComponent(SurveyDetailsComponent, {
        set: {
          imports: [DatePipe],
          schemas: [NO_ERRORS_SCHEMA],
          template,
          templateUrl: undefined,
          styleUrl: undefined,
        },
      }).compileComponents();
  });

  afterEach(() => TestBed.resetTestingModule());

  function createDetails(rights?: SurveyGridRow['rights']) {
    const fixture = TestBed.createComponent(SurveyDetailsComponent);
    const survey = signal<SurveyGridRow>({
      assetId: 'survey-1',
      assetType: 'DISCOVERSURVEY',
      title: 'Survey',
      lastModifiedTimestamp: 0,
      rights,
    });
    Object.defineProperty(fixture.componentInstance, 'survey', { value: survey });
    return { fixture, componentInstance: fixture.componentInstance, survey };
  }

  it('builds a root-to-parent location and ignores ancestors without titles', () => {
    const { componentInstance, survey } = createDetails();
    survey.update((value) => ({
      ...value,
      parentAsset: {
        assetId: 'child', title: 'Child',
        parentAsset: { assetId: 'untitled', parentAsset: { assetId: 'root', title: 'Root' } },
      },
    }));
    expect(componentInstance.location()).toBe('Root / Child');
  });

  it.each([
    [undefined, undefined, '--'],
    [0, 100, '0/100 (0%)'],
    [25, undefined, '25'],
    [25, 0, '25'],
    [25, -1, '25'],
    [1, 3, '1/3 (33%)'],
  ] as const)('formats responses %s / %s as %s', (responsesCollected, responseTarget, expected) => {
    const { componentInstance, survey } = createDetails();
    survey.update((value) => ({ ...value, responsesCollected, responseTarget }));
    expect(componentInstance.responses()).toBe(expected);
  });

  it.each([
    ['', null],
    ['invalid-date', null],
    ['2026-10-16T00:00:00Z', new Date('2026-10-16T00:00:00Z')],
  ] as const)('handles date value %s', (value, expected) => {
    const { componentInstance, survey } = createDetails();
    survey.update((row) => ({ ...row, initialCreation: value }));
    expect(componentInstance.createdDate()).toEqual(expected);
    survey.update((row) => ({ ...row, publishedTimestamp: 0 }));
    expect(componentInstance.publishedDate()).toEqual(new Date(0));
  });

  it('uses creation timestamps in preference to the formatted creation value', () => {
    const { componentInstance, survey } = createDetails();
    survey.update((value) => ({ ...value, initialCreationTimestamp: 0, initialCreation: 'invalid-date' }));
    expect(componentInstance.createdDate()).toEqual(new Date(0));
  });

  it('handles missing availability and falls back to display names or recipient identifiers', () => {
    const { componentInstance } = createDetails([
      { userId: 'ignored' },
      { availability: 'EDIT', userId: 'editor', displayName: 'Editor Name' },
      { availability: 'EDIT', userId: 'user-id' },
      { availability: 'STRICTVIEW', orderManagementId: 'group-id' },
      {
        availability: 'STRICTVIEW',
        orderManagementInfo: { id: 'org-id', type: 'ORGANIZATION', displayName: 'Organization Name' },
      },
    ]);
    expect(componentInstance.sharedWith()).toEqual([
      { id: 'editor', name: 'Editor Name', isGroup: false },
      { id: 'user-id', name: 'user-id', isGroup: false },
      { id: 'order-management::group-id', name: 'group-id', isGroup: false },
      { id: 'order-management:ORGANIZATION:org-id', name: 'Organization Name', isGroup: true },
    ]);
  });

  it('includes unique editors and viewers with display names or user ID fallbacks', () => {
    const { componentInstance: component } = createDetails([
      { userId: 'owner', availability: 'OWNED', userInfo: { displayName: 'Taylor Jones' } },
      { userId: 'editor', availability: 'EDIT', userInfo: { displayName: ' Sam Lee ' } },
      { userId: 'viewer', availability: 'STRICTVIEW', userInfo: { displayName: 'Alex Morgan' } },
      { userId: 'editor', availability: 'STRICTVIEW', userInfo: { displayName: 'Sam Lee' } },
      { userId: 'owner', availability: 'EDIT' },
      { userId: 'other', availability: 'VIEW' },
      { availability: 'EDIT' },
    ]);

    expect(component.owners()).toEqual([{ id: 'owner', name: 'Taylor Jones', isGroup: false }]);
    expect(component.sharedWith()).toEqual([
      { id: 'editor', name: 'Sam Lee', isGroup: false },
      { id: 'viewer', name: 'Alex Morgan', isGroup: false },
      { id: 'other', name: 'other', isGroup: false },
    ]);
  });

  it('returns no shared users when rights are absent or contain only owners', () => {
    const fixture = createDetails();
    expect(fixture.componentInstance.sharedWith()).toEqual([]);
    fixture.survey.set({
      assetId: 'survey-1',
      assetType: 'DISCOVERSURVEY',
      title: 'Survey',
      lastModifiedTimestamp: 0,
      rights: [{ userId: 'owner', availability: 'OWNED' }],
    } satisfies SurveyGridRow);
    expect(fixture.componentInstance.sharedWith()).toEqual([]);
  });

  it('includes order-management strict viewers without user IDs using the full group display name', () => {
    const { componentInstance: component } = createDetails([
      { userId: 'creator', availability: 'CREATOR', userInfo: { displayName: 'Creator Name' } },
      {
        availability: 'STRICTVIEW',
        displayName: 'Strict Viewer',
        orderManagementId: 'group-1',
        orderManagementType: 'COG',
        orderManagementInfo: { id: 'group-1', type: 'COG', displayName: ' NC - Internal - Sharing ' },
      },
    ]);

    expect(component.owners()).toEqual([]);
    expect(component.sharedWith()).toEqual([
      { id: 'order-management:COG:group-1', name: 'NC - Internal - Sharing', isGroup: true },
    ]);
  });

  it('deduplicates group access and includes only OWNED rights in the owner block', () => {
    const group = {
      orderManagementId: 'group-1',
      orderManagementType: 'COG',
      orderManagementInfo: { displayName: 'Shared Group' },
    };
    const { componentInstance: component } = createDetails([
      {
        availability: 'OWNED',
        orderManagementId: 'product-1',
        orderManagementType: 'PRODUCT',
        orderManagementInfo: { displayName: 'Product Owner' },
      },
      { ...group, availability: 'EDIT' },
      { ...group, availability: 'STRICTVIEW' },
      { userId: 'admin', availability: 'ADMIN' },
      { userId: 'creator', availability: 'CREATOR' },
    ]);

    expect(component.owners()).toEqual([
      { id: 'order-management:PRODUCT:product-1', name: 'Product Owner', isGroup: false },
    ]);
    expect(component.sharedWith()).toEqual([
      { id: 'order-management:COG:group-1', name: 'Shared Group', isGroup: true },
    ]);
  });

  it('supports nested group identifiers and keeps user names for user-scoped rights', () => {
    const { componentInstance: component } = createDetails([
      {
        availability: 'EDIT',
        orderManagementInfo: { id: 'group-1', type: 'COG', displayName: 'Group Name' },
      },
      {
        availability: 'STRICTVIEW',
        userId: 'viewer',
        userInfo: { displayName: 'Full User Name' },
        orderManagementInfo: { id: 'group-1', type: 'COG', displayName: 'Group Name' },
      },
    ]);

    expect(component.sharedWith()).toEqual([
      { id: 'order-management:COG:group-1', name: 'Group Name', isGroup: true },
      { id: 'viewer', name: 'Full User Name', isGroup: false },
    ]);
  });

  it('hides the Owner block when empty and displays it when an owner is available', () => {
    const { fixture, survey } = createDetails([
      {
        availability: 'STRICTVIEW',
        orderManagementInfo: { id: 'org-1', type: 'ORGANIZATION', displayName: 'Long Organization Name' },
      },
    ]);
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.textContent).not.toContain('Owner');
    expect(element.textContent).toContain('Shared with (1)');
    expect(fixture.componentInstance.sharedWith()[0].isGroup).toBe(true);

    survey.update((value) => ({
      ...value,
      rights: [{ availability: 'OWNED', userId: 'owner', userInfo: { displayName: 'Taylor Jones' } }],
    }));
    fixture.detectChanges();
    expect(element.textContent).toContain('Owner');
    expect(element.textContent).not.toContain('Shared with');
  });
});
