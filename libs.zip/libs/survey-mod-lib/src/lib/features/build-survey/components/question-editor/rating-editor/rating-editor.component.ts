import { Component, ElementRef, output } from '@angular/core';
import { IconModule, TextFieldModule, ToggleModule } from '@nielseniq/athena-core';
import { BaseQuestionEditorDirective } from '../base-question-editor.directive';
import { SuggestionTagsComponent } from '../suggestion-tags/suggestion-tags.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-rating-editor',
  standalone: true,
  imports: [TextFieldModule, IconModule, ToggleModule, SuggestionTagsComponent,TranslateModule],
  templateUrl: './rating-editor.component.html',
  styleUrls: ['./rating-editor.component.scss'],
})
export class RatingEditorComponent extends BaseQuestionEditorDirective {
  /** Notifies the parent that the form changed so it can run validation/preview side effects. */
  formChange = output<void>();

  constructor(elementRef: ElementRef<HTMLElement>) {
    super(elementRef);
  }

  /**
   * Handles input change event.
   * @param value - The new value of the input.
   */
  onInputChange(value: string | number): void {
    this.question.set(String(value ?? ''));
    this.formChange.emit();
  }

  toggleChange(event: Event): void {
    this.isRequired.set((event.target as HTMLInputElement).checked ?? false);
    this.formChange.emit();
  }
}
