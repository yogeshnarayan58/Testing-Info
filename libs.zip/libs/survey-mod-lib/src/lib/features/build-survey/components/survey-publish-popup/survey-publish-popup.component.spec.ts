import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ToastService } from '@nielseniq/athena-core';
import { of, Subject, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyStatusType } from '../../models/build-survey';
import { SurveyService } from '../../services/survey.service';
import { SurveyPublishPopupComponent } from './survey-publish-popup.component';

vi.mock('../../services/survey.service', () => ({ SurveyService: class {} }));
vi.mock('@nielsen/crf-data-summary', () => ({ CrfDataSummaryModule: class {} }));
vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  ACAssetManageApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('SurveyPublishPopupComponent', () => {
  let mockTranslateService: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
  });
  const createComponent = () => {
    const surveyService = {
      title: signal('BrushLab Marketing Survey'),
      questions: signal([{}, {}]),
      publishSurvey: vi.fn().mockReturnValue(of({})),
      setSurveyId: vi.fn(),
      currentAssetIdValue: null as string | null,
    };
    const surveyCommonService = {
      getSelectPanelistUiState: vi.fn().mockReturnValue({ selectedResponses: 400 }),
      getPanelistDataSelectorState: vi.fn().mockReturnValue({ selections: [{ id: 'PRDC' }] }),
      flowType: vi.fn().mockReturnValue({ aiflow: false }),
    };
    const toastService = { InsertToast: vi.fn() };
    const publishDialog = { open: vi.fn(), close: vi.fn() };
    const router = {
      url: '/survey',
      navigateByUrl: vi.fn().mockResolvedValue(true),
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: SurveyService, useValue: surveyService },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: ToastService, useValue: toastService },
        { provide: Router, useValue: router },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new SurveyPublishPopupComponent());
    (component as any).publishDialog = publishDialog;
    return { component, surveyService, surveyCommonService, toastService, publishDialog, router };
  };

  it('opens and closes the dialog', () => {
    const { component, publishDialog } = createComponent();

    component.open();
    component.close();

    expect(publishDialog.open).toHaveBeenCalledOnce();
    expect(publishDialog.close).toHaveBeenCalledOnce();
  });

  it('closes the dialog immediately and publishes after confirmation', () => {
    const { component, surveyService, publishDialog, toastService, router } = createComponent();
    surveyService.publishSurvey.mockReturnValue(of({ data: { surveyId: 'published-1' } }));

    component.confirmPublish();

    expect(surveyService.publishSurvey).toHaveBeenCalledWith(SurveyStatusType.PUBLISHED, null);
    expect(surveyService.setSurveyId).not.toHaveBeenCalled();
    expect(publishDialog.close).toHaveBeenCalledOnce();
    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'success',
      'SURVEYMOD_SURVEY_PUBLISHED',
      expect.objectContaining({ containerClass: 'survey-action-toast' }),
    );
    expect(router.navigateByUrl).toHaveBeenCalledWith('/my-assets/survey');
    expect(surveyService.currentAssetIdValue).toBeNull();
  });

  it('keeps the page loader active until publishing succeeds', () => {
    const { component, surveyService, toastService, router } = createComponent();
    const pending = new Subject<any>();
    surveyService.publishSurvey.mockReturnValue(pending.asObservable());

    component.confirmPublish();

    expect(component.isPublishing()).toBe(true);
    expect(toastService.InsertToast).not.toHaveBeenCalled();
    expect(router.navigateByUrl).not.toHaveBeenCalled();

    pending.next({ data: { surveyId: 'published-1' } });
    pending.complete();

    expect(component.isPublishing()).toBe(false);
    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'success',
      'SURVEYMOD_SURVEY_PUBLISHED',
      expect.objectContaining({ containerClass: 'survey-action-toast' }),
    );
    expect(router.navigateByUrl).toHaveBeenCalledWith('/my-assets/survey');
    expect(surveyService.currentAssetIdValue).toBeNull();
  });

  it('passes the saved draft assetId when publishing', () => {
    const { component, surveyService } = createComponent();
    surveyService.currentAssetIdValue = 'asset-1';

    component.confirmPublish();

    expect(surveyService.publishSurvey).toHaveBeenCalledWith(SurveyStatusType.PUBLISHED, 'asset-1');
  });

  it('stops the page loader, shows an error toast, and navigates when publishing fails', () => {
    const { component, surveyService, toastService, router } = createComponent();
    const pending = new Subject<any>();
    surveyService.publishSurvey.mockReturnValue(pending.asObservable());

    component.confirmPublish();
    expect(component.isPublishing()).toBe(true);

    pending.error({ error: { errorMessage: 'Publish failed' } });

    expect(component.isPublishing()).toBe(false);
    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'error',
      'Publish failed',
      expect.objectContaining({ containerClass: 'survey-action-toast' }),
    );
    expect(router.navigateByUrl).not.toHaveBeenCalled();
    expect(surveyService.currentAssetIdValue).toBeNull();
  });

  it.each([
    [{ code: { message: 'Backend publish error' } }, 'Backend publish error'],
    [{ errorMessage: 'Direct publish error' }, 'Direct publish error'],
    [{}, 'SURVEYMOD_PUBLISH_FAILED'],
  ])('shows the appropriate publish error', (backendError, expected) => {
    const { component, surveyService, publishDialog, toastService, router } = createComponent();
    surveyService.publishSurvey.mockReturnValue(throwError(() => ({ error: backendError })));

    component.confirmPublish();

    expect(publishDialog.close).toHaveBeenCalledOnce();
    expect(router.navigateByUrl).not.toHaveBeenCalled();
    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'error',
      expected,
      expect.objectContaining({ containerClass: 'survey-action-toast' }),
    );
    expect(component.isPublishing()).toBe(false);
  });

  it('prevents duplicate requests while publishing', () => {
    const { component, surveyService, publishDialog } = createComponent();
    const pending = new Subject<any>();
    surveyService.publishSurvey.mockReturnValue(pending.asObservable());

    component.confirmPublish();
    component.confirmPublish();

    expect(surveyService.publishSurvey).toHaveBeenCalledOnce();
    expect(publishDialog.close).toHaveBeenCalledOnce();
    expect(component.isPublishing()).toBe(true);
    pending.complete();
    expect(component.isPublishing()).toBe(false);
  });

  
  it('navigates to My Assets page for AI flow', () => {
    const { component, surveyService, surveyCommonService, router } = createComponent();
    surveyCommonService.flowType.mockReturnValue({ aiflow: true });
    surveyService.publishSurvey.mockReturnValue(of({ data: { surveyId: 'published-1' } }));

    component.confirmPublish();

    expect(router.navigateByUrl).toHaveBeenCalledWith('/my-assets/survey');
  });

  it('provides review data and safe defaults', () => {
    const { component, surveyCommonService } = createComponent();

    expect(component.panelistSummaryState.selections).toHaveLength(1);
    expect(component.selectedResponseCount).toBe(400);
    expect(component.surveyTitle).toBe('BrushLab Marketing Survey');
    expect(component.questionCount).toBe(2);

    surveyCommonService.getPanelistDataSelectorState.mockReturnValue(null);
    surveyCommonService.getSelectPanelistUiState.mockReturnValue({ selectedResponses: null });
    expect(component.panelistSummaryState).toEqual({});
    expect(component.selectedResponseCount).toBe(0);
  });
});