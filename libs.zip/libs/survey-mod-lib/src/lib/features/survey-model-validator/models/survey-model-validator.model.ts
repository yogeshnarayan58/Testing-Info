import type { AiSuggestion, GenerateSurveyPrompt, QuestionModel, QuestionType } from '../../build-survey/models/build-survey';

/**
 * Data model for the survey-model-validator feature: an internal QA tool that runs the
 * generate-questions AI flow and validates + prints the raw response, without touching the
 * main select-panelist/build-survey wizard state.
 */

/** A single problem found while validating a generated question. */
export interface ValidationIssue {
  /** Zero-based index into the generated questions array, or -1 for list-level issues. */
  questionIndex: number;
  /** The QuestionModel field the issue relates to. */
  field: string;
  /** Human readable description of the problem. */
  message: string;
}

/** Aggregate outcome of validating a generated questions array. */
export interface ValidationResult {
  valid: boolean;
  issueCount: number;
  issues: ValidationIssue[];
}

/** Form state collected on the validator page before calling generate-questions. */
export interface SurveyModelValidatorFormState {
  product: string;
  retailer: string;
  demographic: string;
  geography: string;
  period: string;
  userPrompt: string;
}

export const SURVEY_MODEL_VALIDATOR_MIN_CHOICE_OPTIONS = 2;

export type ValidationSuggestionAction = AiSuggestion['action'] | 'REVIEW';
export type GenerateAndValidateSuggestion = Omit<AiSuggestion, 'action'> & {
  action: ValidationSuggestionAction;
};

export interface GenerateAndValidateSurveyPrompt extends Omit<GenerateSurveyPrompt, 'systemPrompt' | 'questionTypes'> {
  questionTypes?: QuestionType[];
  generateQuestionSystemPrompt: string;
  validateSurveySystemPrompt: string;
}

export interface GenerateAndValidateSurveyPayload {
  prompt: GenerateAndValidateSurveyPrompt;
}

export interface ValidateSurveyQuestion {
  id: string;
  order: number;
  question: string;
  type?: QuestionType;
  options?: string[];
  rowOptions?: string[];
  columnOptions?: string[];
  npsLeftLabel?: string;
  npsRightLabel?: string;
  isRequired?: boolean;
  reviewRequired?: boolean;
}

export type ValidateSurveyQuestionDraft = Omit<ValidateSurveyQuestion, 'id' | 'order'> &
  Partial<Pick<ValidateSurveyQuestion, 'id' | 'order'>>;

export interface ValidateSurveyPayload {
  survey: {
    systemPrompt?: string;
    surveyTitle?: string;
    product?: string;
    retailer?: string;
    geography?: string;
    demographic?: string;
    period?: string;
    userPrompt?: string;
    questions: ValidateSurveyQuestion[];
  };
}

export interface ValidationSuggestionDetails {
  suggestionId?: string;
  severity?: AiSuggestion['severity'];
  ruleCode?: string;
  issue?: string;
  rationale?: string;
  suggestedText?: string;
  fieldPath?: string;
  source?: AiSuggestion['source'];
  action?: ValidationSuggestionAction;
}

export type ValidationSuggestion = string | ValidationSuggestionDetails;

export interface ValidatedSurveyQuestion extends ValidateSurveyQuestion {
  status?: 'APPROVED' | 'NEEDS_MANDATORY_CHANGES';
  suggestions?: ValidationSuggestion[];
}

export interface ValidateSurveyResponse {
  result: ValidatedSurveyQuestion[];
  validation?: {
    status: 'COMPLETED' | 'SKIPPED' | 'UNAVAILABLE';
  };
}

export interface GenerateAndValidateSurveyQuestion extends Omit<ValidatedSurveyQuestion, 'type' | 'isRequired' | 'suggestions' | 'id' | 'order'> {
  id: string;
  order: number;
  type: QuestionType;
  isRequired: boolean;
  suggestions?: GenerateAndValidateSuggestion[];
}

export interface GenerateAndValidateSurveyResponse extends ValidateSurveyResponse {
  title: string;
  validation: {
    status: 'COMPLETED' | 'SKIPPED' | 'UNAVAILABLE';
  };
  result: GenerateAndValidateSurveyQuestion[];
}

export interface GeneratedQuestionsResponse {
  result: QuestionModel[];
  title?: string;
}

export interface SurveyModelValidatorPrompts {
  generateQuestionSystemPrompt: string;
  validateSurveySystemPrompt: string;
}
