import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";

import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import {
  findDataSetByName,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { config } from "../../../playwright/config";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { getDataElement } from "../../test-cases/common-test-cases-helper-service";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import assertionData from "./assertion-data/assertion-data.json";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";


const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";
test.describe("Shopping Basket Value Retailer", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  let formatPanel: FormatPanel;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
        if (!isValidTestData) {
          console.warn('Skipping tests as the required pivot test data is not present');
        }
        test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
      });



  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.switchPivotDropdown(pivot);
          // Get Retailer pivot data

          const retailerData = getDimensionSelectionsByPivot(pivot, reportTestData);
          if (!retailerData) {
            throw new Error("Pivot not found in test data: Retailer");
          }
          await dataSelector.clickAdditionalPromptEllipsisIcon();
          await dataSelector.clickMadlibDimension("Retailers");
          await dataSelector.setMadlibSelection(
            retailerData["Retailers"]
          );
          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            retailerData["Geography"]
          );
          await dataSelector.clickMadlibDimension("Product");
          await dataSelector.setMadlibSelection(
            retailerData["Product"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            retailerData["Period"]
          );



          await dataSelector.clickMadlibDimension("Shopper Group");
          await dataSelector.setMadlibSelection(
            retailerData["Shopper Group"]
          );
          await dataSelector.clickMadlibDimension("Facts");
          /* await dataSelector.assertFactsDropdown(
            reportAssertData["dataSummary"]["facts"]["factList"]
          ); */
          await dataSelector.selectClosedDropdown(
            retailerData["Facts"]["selections"]
          );

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          console.log("run complete in spec");
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );

      test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
        test.skip(
          !savedReportTitle,
          "Skipping FMS test - Report not generated. Run with @RunReport first"
        );

        const basePage = await BasePageFactory.createBasePage();
        const findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });

      // Appended view and snapshot validations
      test(
        "Validate FullScreen",
        { tag: "@ValidateFullScreen" },
        async () => {
          test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.fullScreenView();
        }
      );

      test(
        "Validate presentationMode",
        { tag: "@PresentationMode" },
        async () => {
          test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.presentationMode();
        }
      );

      test("Validate snapshot", { tag: "@Snapshot" }, async () => {
        test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
        let basePage = await BasePageFactory.createBasePage();
        const commonTC = new CommonTestCase(basePage);
        await commonTC.navigateToReportUrl(savedReportUrl);
        const snapshot = new Snapshot(commonTC.getBasePage());
        await snapshot.waitForReportRunCompletion();
        await snapshot.clickSaveIcon();
        await snapshot.clickSnapshotIcon();
        assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
        await snapshot.shiftingToSnapshot();
      });


      test(
        "Validate PPT export",
        {
          tag: "@ValidatePPTExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
        }
      );

      test(
        "Validate Excel export",
        {
          tag: "@ValidateExcelExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality(
            "Excel",
            "Editable objects",
            "Separately"
          );
        }
      );

      test(
        "Validate Add Blank Report",
        { tag: "@ValidateAddBlankReport" },
        async () => {
          if (!savedReportUrl) {
            test.skip(true, "No savedReportUrl available from prior RunReport test");
          }

          // Base context on saved report
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);

          // Make a copy so original saved report remains intact
          const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

          // Navigate to copied report URL
          let newBasePage = await BasePageFactory.createBasePage();
          let newCommonTestCase = new CommonTestCase(newBasePage);
          await newCommonTestCase.navigateToReportUrl(newUrl);

          // Perform blank report flow
          let reportFlowPage = new ReportFlowPage(newBasePage);
          await reportFlowPage.clickAddMenuIcon();
          await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);
          await reportFlowPage.validateAddMenuDropdownOptions();
          await reportFlowPage.clickAddBlankReportOption();
          await reportFlowPage.waitForBlankReportIndicator();
          await reportFlowPage.validateBlankReportCreation();
          await reportFlowPage.validateUntitledReportTitle();
          await reportFlowPage.runBlankReport(config.DATASET);

          // Return to copied report tab and validate madlib text exists
          await reportFlowPage.clickReportByName(newReportTitle);
          const postFlowDataSelector = new DataSelector(newBasePage);
          const madlibText = await postFlowDataSelector.getMadlibText();
          assert(madlibText?.length).toBeGreaterThan(0);
        }
      );
    }
  );



});


