import { Component, computed, input, output } from '@angular/core';
import { ButtonModule, IconModule, TooltipModule } from '@nielseniq/athena-core';
import { SurveyAIValidationState, SURVEY_VALIDATION_STATE } from '../../models/build-survey';
import { TranslateModule } from '@ngx-translate/core';
import { MIN_SURVEY_QUESTIONS_REQUIRED_TO_PUBLISH } from '../../../my-assets/constants/survey-status.constant';

@Component({
  selector: 'build-survey-footer',
  imports: [IconModule, ButtonModule, TranslateModule, TooltipModule],
  standalone: true,
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  readonly minSurveyQuestion: number = MIN_SURVEY_QUESTIONS_REQUIRED_TO_PUBLISH
  isPublishDisable = input(false);
  isBelowMinQuestionCount = input(false);
  surveyAIValidationState = input<SurveyAIValidationState | null>();
  readonly SURVEY_VALIDATION_STATE = SURVEY_VALIDATION_STATE;
  readonly isReviewRequired = input(false);
  readonly isRevalidationRequired = computed(() =>
    this.isReviewRequired() &&
    this.surveyAIValidationState() !== SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION
  );
  readonly isReadyForPublish = computed(() =>
    this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
  );
  readonly isActionDisabled = computed(() =>
    this.isPublishDisable() ||
    (this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW &&
      !this.isRevalidationRequired())
  );

  publish = output<void>();
  goBack = output<void>();
  validateSurvey = output<void>();

  readonly surveyAIValidationInProgress = computed(
    () => this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS
  );

  readonly buttonLabel = computed(() => {
    if (this.isRevalidationRequired()) {
      return 'SURVEYMOD_REVALIDATE_SURVEY';
    }
    switch (this.surveyAIValidationState()) {
      case SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW:
        return 'SURVEYMOD_REVALIDATE_SURVEY';

      case SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH:
        return 'SURVEYMOD_REVIEW_PUBLISH_SURVEY';

      default:
        return 'SURVEYMOD_VALIDATE_SURVEY';
    }
  });

  toggleTooltip(event: Event, show: boolean): void {
    event.currentTarget?.dispatchEvent(new MouseEvent(show ? 'mouseenter' : 'mouseleave'));
  }

  onValidationAction(): void {
    if (this.isActionDisabled() || this.surveyAIValidationInProgress()) {
      return;
    }
    if (this.isReadyForPublish()) {
      this.publish.emit();
    } else {
      this.validateSurvey.emit();
    }
  }
}
