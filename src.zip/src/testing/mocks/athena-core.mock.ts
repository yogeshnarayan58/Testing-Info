export const CardModule = {};
export const IconModule = {};
export const ButtonModule = {};
export const MenuModule = {};
export const ItemModule = {};
export const DropDownModule = {};
export const IconButtonModule = {};
export const SegmentControlModule = {};

export class ToastService {
  insertToast = () => {};
  InsertToast = () => {};
}
