export abstract class FilePathConstants {
  private constructor() {}
  public static readonly PLAYWRIGHT_AUTH: string = "./.auth/";
}
