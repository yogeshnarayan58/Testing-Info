import { afterNextRender, createEnvironmentInjector, effect, Injector, runInInjectionContext } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PromptErrorConfigService } from '@nielsen/crf-data-selector-panel-v2';
import { CrfDataSummaryService } from '@nielsen/crf-data-summary';
import { IdentityService } from '@nielsen/crf-lp-common';
import { DatasetService as CrfDatasetService, pubSub, PubSubEventEnum } from '@nielsen/crf-rv-common';
import { EnvironmentConfig, ListCallDatasetService, PreferencesService } from '@nielseniq/crf-discover-fe-core';
import { of, Subject, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyExceptionHandlingService } from '../../../../shared/services/survey-exception-handling.service';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { PanelistDatasetService } from '../../services/panelist-dataset.service';
import { RunReportService } from '../../services/run-report.service';
import { SelectPanelistUtilsService } from '../../utils.service';
import { PanelistDataselectorComponent } from './panelist-dataselector.component';

vi.mock('@angular/core', async () => {
  const actual = await vi.importActual('@angular/core');
  return {
    ...actual,
    effect: vi.fn((fn) => {
      try {
        fn();
      } catch (e) {
        // Ignore effect execution errors in tests
      }
    }),
    afterNextRender: vi.fn(() => {
      // Don't execute, just mock it out
    }),
  };
});

vi.mock('intl-messageformat', () => ({
  IntlMessageFormat: class {
    format() { return ''; }
  },
  default: class {
    format() { return ''; }
  },
}));

vi.mock('@nielseniq/athena-core', () => ({
  MenuModule: class {},
  ItemModule: class {},
  CardModule: class {},
  IconModule: class {},
  DropDownModule: class {},
  ButtonModule: class {},
  IconButtonModule: class {},
  SegmentControlModule: class {},
  ToastService: class {
    InsertToast = vi.fn();
  },
}));

vi.mock('@nielsen/crf-data-summary', () => ({
  CrfDataSummaryModule: class {},
  CrfDataSummaryService: class {},
}));

vi.mock('@nielsen/crf-data-selector-panel-v2', () => ({
  CrfDataSelectorPanelModuleV2: class {},
  PromptErrorConfigService: class {
    errorConfigSubjectV2 = new Subject();
  },
}));

vi.mock('@nielsen/crf-rv-common', () => ({
  CrfRvCommonModule: class {},
  DataSetType: { PANEL_OD_OMNI: 'PANEL_OD_OMNI', PANEL_OD_HSCN: 'PANEL_OD_HSCN' },
  PubSubEventEnum: { OnCancelDataSet: 'OnCancelDataSet', OnDataSetTypesChange: 'OnDataSetTypesChange', OnDataSetChange: 'OnDataSetChange' },
  ReDataSetConfig: class {},
  pubSub: { subscribe: vi.fn(), unsubscribe: vi.fn(), publish: vi.fn() },
  DatasetService: class {},
}));

vi.mock('@nielsen/crf-common', () => ({
  DataSetTypeName: {
    PANEL_OD_OMNI: 'Panel On Demand Omnishopper',
    PANEL_OD_HSCN: 'Panel On Demand Homescan',
  },
  DimensionSelection: class {},
  Prompt: class {},
}));

vi.mock('@nielseniq/crf-discover-fe-core', () => ({
  EnvironmentConfig: class {},
  PreferencesService: class {},
  ListCallDatasetService: class {},
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  IdentityService: class {},
}));

describe('PanelistDataselectorComponent', () => {
  let component: PanelistDataselectorComponent;
  let translateService: any;
  let identityService: any;
  let preferenceService: any;
  let crfDatasetService: any;
  let dataSummaryService: any;
  let runReportService: any;
  let promptErrorService: any;
  let surveyCommonService: any;
  let panelistDatasetService: any;
  let selectPanelistUtilsService: any;
  let surveyService: any;
  let injector: Injector;
  let listCallDatasetService: any;
  let exceptionHandlingService: any;

  const createDatasetDetails = (overrides: any = {}) => ({
    id: 'ds1',
    title: 'Test Dataset',
    dataView: { dataViewId: 'dv1', dataViewName: 'View' },
    stackId: 'stack1',
    ...overrides
  });

  const createPrompts = (count = 1, startId = 1) =>
    Array.from({ length: count }, (_, i) => ({
      id: `p${startId + i}`,
      dimId: `dim${startId + i}`,
      promptData: [{ promptSelectionLabel: `L${startId + i}` }],
      hidden: false,
      isClosedPrompt: false,
      validate: true
    }));

  const createSelections = (count = 1, startId = 1) =>
    Array.from({ length: count }, (_, i) => ({
      id: `s${startId + i}`,
      children: []
    }));

  beforeEach(() => {
    translateService = {
      get: vi.fn().mockReturnValue(of({})),
      addLangs: vi.fn(),
      setDefaultLang: vi.fn(),
      use: vi.fn().mockReturnValue(of({})),
      currentLanguage: 'en',
    };

    identityService = {
      getUser: vi.fn().mockReturnValue(of({
        userName: 'testuser',
        organization: { homeStackId: 'stack123' }
      })),
    };

    preferenceService = { setHomeStackId: vi.fn() };

    crfDatasetService = {
      getDatasetInformation: vi.fn().mockReturnValue(of({})),
      openDatasetPicker: new Subject(),
    };

    dataSummaryService = {
      getDataSummary: vi.fn().mockReturnValue(of({})),
      preparePromptData: vi.fn().mockReturnValue([]),
    };

    runReportService = {
      reportCompleted$: new Subject(),
      stoprun: new Subject(),
      resetReportCompleted: vi.fn(),
      runReport: vi.fn(),
      triggerValuesMultiChar: vi.fn().mockReturnValue(of({})),
    };

    promptErrorService = { errorConfigSubjectV2: new Subject() };


    surveyCommonService = {
      dataViewId: { set: vi.fn() },
      setDataViewId: vi.fn(),
      getSelectedDatasetConfig: vi.fn().mockReturnValue(null),
      getDatasetPickerOpenTrigger: vi.fn().mockReturnValue(null),
      setSelectedDatasetConfig: vi.fn(),
      setPanelistDataSelectorState: vi.fn(),
      setPanelistDimensionalValue: vi.fn(),
      getPanelistDataSelectorState: vi.fn().mockReturnValue(null),
      hasCompletedPanelistSearch: vi.fn().mockReturnValue(false),
      setSelectedDatasetDisplay: vi.fn(),
      setRefreshedDate: vi.fn(),
      mergeSelections: vi.fn((incoming: any[], existing: any[]) => {
        const incomingByID = new Map((incoming || []).map(s => [s?.id, s]));
        const result = (existing || []).filter(sel => {
          const incomingItem = incomingByID.get(sel?.id);
          return !incomingItem || (incomingItem.children?.length ?? 0) > 0;
        });
        incomingByID.forEach((sel, id) => {
          if ((sel?.children?.length ?? 0) > 0) {
            const idx = result.findIndex(s => s?.id === id);
            if (idx >= 0) {
              result[idx] = sel;
            } else {
              result.push(sel);
            }
          }
        });
        return result;
      }),
      extractPromptSelectionLabels: vi.fn((prompts: any[]) => {
        const promptSelectionMap: Record<string, string[]> = {};
        (prompts || []).forEach((prompt: any) => {
          const key = prompt?.dimId ?? prompt?.id;
          if (!key) return;
          const labels = (prompt?.promptData || [])
            .map((data: any) => data?.promptSelectionLabel)
            .filter((label: string) => !!label);
          if (labels.length) {
            promptSelectionMap[key] = labels;
          }
        });
        return promptSelectionMap;
      }),
      notifyDatasetSelected: vi.fn(),
      notifyPanelToggled: vi.fn(),
      notifyCriteriaChanged: vi.fn(),
    };

    panelistDatasetService = {
      getDatasets: vi.fn().mockReturnValue(of([])),
      getDataSetDetails: vi.fn().mockReturnValue({ label: 'Dataset Label' }),
      loadBaseReportSpec: vi.fn().mockReturnValue(of({ spec: 'data' })),
    };

    selectPanelistUtilsService = {
      checkFactInDataset: vi.fn().mockReturnValue(true),
      refreshedOnDate: vi.fn().mockReturnValue('2026-07-30'),
    };

    listCallDatasetService = {
      getDatasetByIdRegion: vi.fn().mockReturnValue({ label: 'Dataset Label' }),
    };

    exceptionHandlingService = { handleApiError: vi.fn() };

      surveyService = {
        currentSurveyId: null,
        getCurrentSurveyId: vi.fn().mockReturnValue(null),
      };

    injector = createEnvironmentInjector(
      [
        { provide: EnvironmentConfig, useValue: { appId: 'test-app-id', dataSelectorConfig: {}, local: undefined } },
        { provide: TranslateService, useValue: translateService },
        { provide: IdentityService, useValue: identityService },
        { provide: PreferencesService, useValue: preferenceService },
        { provide: CrfDatasetService, useValue: crfDatasetService },
        { provide: CrfDataSummaryService, useValue: dataSummaryService },
        { provide: RunReportService, useValue: runReportService },
        { provide: PromptErrorConfigService, useValue: promptErrorService },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: PanelistDatasetService, useValue: panelistDatasetService },
        { provide: SelectPanelistUtilsService, useValue: selectPanelistUtilsService },
        { provide: ListCallDatasetService, useValue: listCallDatasetService },
        { provide: SurveyService, useValue: surveyService },
        { provide: SurveyExceptionHandlingService, useValue: exceptionHandlingService },
      ],
      null as any
    );

    runInInjectionContext(injector, () => {
      component = new PanelistDataselectorComponent();
      try {
        component.ngOnInit();
      } catch (e) {
        // Ignore errors during ngOnInit setup
      }
    });
  });

  describe('Component Initialization', () => {
    it('should create component with default state', () => {
      expect(component).toBeDefined();
      expect(component.datasetName).toBe('');
      expect(component.componentId).toBe('');
      expect(component.selections).toEqual([]);
      expect(component.dataPrompts).toEqual([]);
      expect(component.apploaded).toBe(true);
      expect(component.isShowDsPanel).toBe(false);
      expect(component.showNoDatasetState).toBe(false);
      expect(component.runButtonState).toBe('hidden');
    });

    it('should initialize output emitters', () => {
      expect(component.datasetSelected).toBeDefined();
      expect(component.panelToggled).toBeDefined();
      expect(component.criteriaChanged).toBeDefined();
    });

    it('should initialize report payload defaults', () => {
      expect(component.reportPayload.reportType).toBe('SURVEY_PANELISTS');
      expect(component.reportPayload.attributes.reportName).toBe('Untitled Survey');
      expect(component.reportPayload.requestInstance).toEqual(expect.objectContaining({
        attributes: {
          modelId: 'THL-F',
          userId: 'testuser',
        },
      }));
      expect(component.reportSpec).toBe(component.reportPayload.reportSpec);
    });
  });

  describe('Dataset Selection', () => {
    it('should update dataset with title priority', () => {
      component.onUpdateDataset(createDatasetDetails({ title: 'My Title' }));
      expect(component.datasetName).toBe('My Title');
    });

    it('should fallback to label when title missing', () => {
      component.onUpdateDataset(createDatasetDetails({ title: undefined, label: 'My Label' }));
      expect(component.datasetName).toBe('My Label');
    });

    it('should fallback to id when name fields missing', () => {
      component.onUpdateDataset({ id: 'ds-fallback', dataView: { dataViewId: 'dv1', dataViewName: 'V' } } as any);
      expect(component.datasetName).toBe('ds-fallback');
    });

    it('should fallback to description when title and label are missing', () => {
      component.onUpdateDataset({
        id: 'ds-fallback',
        description: 'Dataset description',
        dataView: { dataViewId: 'dv1', dataViewName: 'V' }
      } as any);
      expect(component.datasetName).toBe('Dataset description');
    });

    it('should preserve state when dataset has existing criteria', () => {
      component.selections = createSelections(2) as any;
      component.dataPrompts = createPrompts(2) as any;
      component.runButtonState = 'default';

      component.onUpdateDataset(createDatasetDetails());

      // When there's existing criteria, state is preserved (not cleared)
      expect(component.selections.length).toBeGreaterThan(0);
      expect(component.dataPrompts.length).toBeGreaterThan(0);
    });

    it('should emit datasetSelected output and update dataset info', () => {
      const emitSpy = vi.spyOn(component.datasetSelected, 'emit');
      component.onUpdateDataset(createDatasetDetails());
      expect(emitSpy).toHaveBeenCalled();
    });

    it('should skip updates when restoring state', () => {
      (component as any).isRestoringSelectorState = true;
      const initial = component.selections;
      component.onUpdateDataset(createDatasetDetails());
      expect(component.selections).toEqual(initial);
    });

    it('should return early on null/invalid input', () => {
      const initialName = component.datasetName;
      component.onUpdateDataset(null as any);
      component.onUpdateDataset({} as any);
      expect(component.datasetName).toBe(initialName);
    });

    it('should update request payload fields and dataset processing flags', () => {
      const dataset = createDatasetDetails({
        datasetDefaultLocale: 'en-US',
        productOfferingCode: 'PANEL_OD_OMNI',
      }) as any;

      const hidePanelSpy = vi.spyOn(component, 'hidePanel');
      const notifyDatasetSelectedSpy = vi.spyOn(surveyCommonService, 'notifyDatasetSelected');

      component.onUpdateDataset(dataset);

      expect(component.reportPayload.requestInstance.datasetId).toBe('ds1');
      expect(component.reportPayload.requestInstance.datasetLabel).toBe('Test Dataset');
      expect(component.reportPayload.requestInstance.dataViewId).toBe('dv1');
      expect(component.reportPayload.requestInstance.dataViewName).toBe('View');
      expect(component.reportPayload.requestInstance.locale).toBe('en-US');
      expect(component.reportPayload.requestInstance.datasetStackId).toBe('stack1');
      expect(component.reportPayload.requestInstance.productOfferingCode).toBe('PANEL_OD_OMNI');
      expect(component.isCheckingDataset).toBe(false);
      expect(component.isFactAvailableInDataset).toBe(true);
      expect(component.componentId).toBe('OMNI_THL_SURVEY_PANEL');
      expect(component.showNoDatasetState).toBe(false);
      expect(hidePanelSpy).toHaveBeenCalled();
      expect(notifyDatasetSelectedSpy).toHaveBeenCalledWith('Test Dataset');
    });

    it('should trim dataViewId and invoke dataset-check/report sync hooks', () => {
      const dataset = createDatasetDetails({
        dataView: { dataViewId: '  dv1  ', dataViewName: 'View' },
      }) as any;

      const syncSelectorStateSpy = vi.spyOn(component as any, 'syncSelectorState');

      component.onUpdateDataset(dataset);

      expect(surveyCommonService.setDataViewId).toHaveBeenCalledWith('dv1');
      expect(runReportService.triggerValuesMultiChar).toHaveBeenCalledWith(expect.anything(), dataset);
      expect(selectPanelistUtilsService.checkFactInDataset).toHaveBeenCalled();
      expect(syncSelectorStateSpy).toHaveBeenCalled();
    });

    it('should execute onUpdateDataset side effects through sync call', () => {
      const dataset = createDatasetDetails({
        title: '',
        label: '',
        description: '',
        id: 'fallback-id',
      }) as any;
      const loadBaseReportSpecSpy = vi.spyOn(component as any, 'loadBaseReportSpec');
      const hidePanelSpy = vi.spyOn(component, 'hidePanel');
      const emitSpy = vi.spyOn(component.datasetSelected, 'emit');

      component.onUpdateDataset(dataset);

      expect(component.datasetName).toBe('fallback-id');
      expect(component.showNoDatasetState).toBe(false);
      expect(component.componentId).toBe('OMNI_THL_SURVEY_PANEL');
      expect(component.currentPrompt).toBeUndefined();
      expect(runReportService.triggerValuesMultiChar).toHaveBeenCalledWith(expect.anything(), dataset);
      expect(loadBaseReportSpecSpy).toHaveBeenCalledWith(dataset);
      expect(hidePanelSpy).toHaveBeenCalled();
      expect(emitSpy).toHaveBeenCalledWith('fallback-id');
      expect(surveyCommonService.notifyDatasetSelected).toHaveBeenCalledWith('fallback-id');
      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenCalled();
    });

    it('should execute full onUpdateDataset side-effect chain with title dataset', () => {
      const dataset = createDatasetDetails({
        title: 'Title Dataset',
        datasetDefaultLocale: 'en-US',
        productOfferingCode: 'PANEL_OD_OMNI',
      }) as any;
      const loadBaseReportSpecSpy = vi.spyOn(component as any, 'loadBaseReportSpec');
      const hidePanelSpy = vi.spyOn(component, 'hidePanel');
      const emitSpy = vi.spyOn(component.datasetSelected, 'emit');

      component.onUpdateDataset(dataset);

      expect(component.datasetName).toBe('Title Dataset');
      expect(component.showNoDatasetState).toBe(false);
      expect(component.componentId).toBe('OMNI_THL_SURVEY_PANEL');
      expect(component.currentPrompt).toBeUndefined();
      expect(component.isCheckingDataset).toBe(false);
      expect(runReportService.triggerValuesMultiChar).toHaveBeenCalledWith(expect.anything(), dataset);
      expect(loadBaseReportSpecSpy).toHaveBeenCalledWith(dataset);
      expect(hidePanelSpy).toHaveBeenCalled();
      expect(emitSpy).toHaveBeenCalledWith('Title Dataset');
      expect(surveyCommonService.notifyDatasetSelected).toHaveBeenCalledWith('Title Dataset');
      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenCalled();
    });

    it('should reset prompts/selections and notify criteria when not restoring', () => {
      const criteriaEmitSpy = vi.spyOn(component.criteriaChanged, 'emit');
      const notifyCriteriaChangedSpy = vi.spyOn(surveyCommonService, 'notifyCriteriaChanged');
      component.selections = [];
      component.dataPrompts = [];
      component.panelDataPrompts = [];
      component.runButtonState = 'default';
      (component as any).isRestoringSelectorState = false;

      component.onUpdateDataset(createDatasetDetails());

      expect(component.selections).toEqual([]);
      expect(component.dataPrompts).toEqual([]);
      expect(component.panelDataPrompts).toEqual([]);
      expect(component.runButtonState).toBe('disabled');
      expect(criteriaEmitSpy).toHaveBeenCalled();
      expect(notifyCriteriaChangedSpy).toHaveBeenCalled();
    });

    it('should map dataset payload fields even while restoring selector state', () => {
      const dataset = createDatasetDetails({
        datasetDefaultLocale: 'en-US',
        productOfferingCode: 'PANEL_OD_HSCN',
      }) as any;
      (component as any).isRestoringSelectorState = true;
      component.selections = createSelections(1) as any;

      component.onUpdateDataset(dataset);

      expect(component.selections.length).toBe(1);
      expect(component.reportPayload.requestInstance.datasetId).toBe('ds1');
      expect(component.reportPayload.requestInstance.datasetStackId).toBe('stack1');
      expect(component.reportPayload.requestInstance.productOfferingCode).toBe('PANEL_OD_HSCN');
      expect(component.datasetName).toBe('Test Dataset');
      expect(component.componentId).toBe('OMNI_THL_SURVEY_PANEL');
      expect(component.currentPrompt).toBeUndefined();
    });
  });

  describe('Data Selections Management', () => {
    it('should update selections and transition runButtonState', () => {
      component.selections = [];
      component.updateDataSelections({ selections: createSelections(1) as any });
      expect(component.runButtonState).toBe('disabled');
    });

    it('should merge incoming selections without dropping child drillByContext', () => {
      component.selections = createSelections(2, 1) as any;
      const drillByContext = [{ id: 'drill-value', children: [] }];
      const incoming = [{ id: 's3', children: [{ id: 'c3', drillByContext }] }];
      component.updateDataSelections({ selections: incoming });
      expect(component.selections).toEqual([...createSelections(2, 1), ...incoming]);
      expect(component.reportPayload.requestInstance.dimensionSelections).toEqual(component.selections);
      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenLastCalledWith(
        expect.objectContaining({ selections: component.selections }),
      );
      expect(component.selections[2].children?.[0]).toHaveProperty('drillByContext', drillByContext);
    });

    it('should skip updates when in loading state', () => {
      component.runButtonState = 'loading';
      const initial = [...component.selections];
      component.updateDataSelections({ selections: createSelections(1) as any });
      expect(component.selections).toEqual(initial);
    });

    it('should emit criteriaChanged and persist state', () => {
      const emitSpy = vi.spyOn(component.criteriaChanged, 'emit');
      (component as any).isRestoringSelectorState = false;
      component.updateDataSelections({ selections: createSelections(1) as any });
      expect(emitSpy).toHaveBeenCalled();
      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenCalled();
    });
  });

  describe('Prompts Management', () => {
    it.each(['existing', 'cached', 'open'] as const)(
      'preserves hidden-panel prompts or accepts edits for %s prompt state',
      source => {
        const previous = createPrompts(1);
        const incoming = createPrompts(1, 2);
        component.dataPrompts = source === 'existing' || source === 'open' ? previous : [];
        component.isShowDsPanel = source === 'open';
        surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
          dataPrompts: source === 'cached' ? previous : [{}],
        });
        surveyCommonService.setPanelistDataSelectorState.mockClear();

        component.updatePrompts(incoming);

        const preserves = source === 'existing' || source === 'cached';
        expect(component.dataPrompts).toEqual(preserves ? source === 'existing' ? previous : [] : incoming);
        if (preserves) {
          expect(surveyCommonService.setPanelistDataSelectorState).not.toHaveBeenCalled();
        } else {
          expect(component.panelDataPrompts).toEqual(incoming);
          expect(component.reportPayload.requestInstance.prompts).toEqual(incoming);
        }
      },
    );

    it('should retain promptForSelection when updating prompts and syncing to payload', () => {
      const prompts = [
        { ...createPrompts(1)[0], promptForSelection: null },
        { ...createPrompts(1, 2)[0], promptForSelection: false },
      ];
      component.updatePrompts(prompts);
      expect(component.dataPrompts).toEqual(prompts);
      expect(component.panelDataPrompts).toEqual(prompts);
      expect(component.reportPayload.requestInstance.prompts).toEqual(prompts);
      expect(component.dataPrompts[0]).toHaveProperty('promptForSelection', null);
      expect(component.dataPrompts[1]).toHaveProperty('promptForSelection', false);
      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenLastCalledWith(
        expect.objectContaining({ dataPrompts: prompts, panelDataPrompts: prompts }),
      );
    });

    it('should handle data summary preparation', () => {
      component.selections = createSelections(1) as any;
      dataSummaryService.preparePromptData.mockReturnValue([{ id: 'prepared' }]);
      component.handleDataSummary();
      expect(component.dataPrompts).toEqual([{ id: 'prepared' }]);
    });

  });

  describe('Prompt Panel Interaction', () => {
    it('should open panel on prompt click without stripping nested null properties', () => {
      component.runButtonState = 'default';
      const prompt = {
        ...createPrompts(1)[0],
        promptForSelection: null,
        promptData: [{ promptSelectionLabel: 'L1', metadata: { description: null } }],
      };
      component.dataPrompts = [prompt, ...createPrompts(1, 2)];
      const emitSpy = vi.spyOn(component.panelToggled, 'emit');

      component.onPromptClick('p1');

      expect(component.isShowDsPanel).toBe(true);
      expect(component.currentPrompt?.id).toBe('p1');
      expect(component.currentPrompt).toHaveProperty('promptForSelection', null);
      expect(component.currentPrompt).toHaveProperty('promptData.0.metadata.description', null);
      expect(component.panelDataPrompts[0]).toEqual(prompt);
      expect(emitSpy).toHaveBeenCalledWith(true);
    });

    it('should skip opening panel when loading', () => {
      component.runButtonState = 'loading';
      component.isShowDsPanel = false;
      component.dataPrompts = createPrompts(1) as any;

      component.onPromptClick('p1');

      expect(component.isShowDsPanel).toBe(false);
    });

    it('should hide panel and reset state', () => {
      component.isShowDsPanel = true;
      component.currentPrompt = { id: 'p1' } as any;
      const emitSpy = vi.spyOn(component.panelToggled, 'emit');

      component.hidePanel();

      expect(component.isShowDsPanel).toBe(false);
      expect(component.currentPrompt).toBeUndefined();
      expect(emitSpy).toHaveBeenCalledWith(false);
    });
  });

  describe('Report Execution', () => {
    it('should run report when state allows', () => {
      component.runButtonState = 'default';
      component.dataPrompts = createPrompts(1) as any;

      component.runDashboard();

      expect(component.runButtonState).toBe('loading');
      expect(runReportService.runReport).toHaveBeenCalled();
    });

    it('should not run report when disabled', () => {
      component.runButtonState = 'disabled';
      component.runDashboard();
      expect(runReportService.runReport).not.toHaveBeenCalled();
    });

    it('should handle reportCompleted$ subscription', () => {
      // Reset component state and re-trigger ngOnInit with fresh subscriptions
      component.runButtonState = 'loading';
      component.currentPrompt = { id: 'p1' } as any;

      // Call the subscription logic directly by emitting to reportCompleted$
      (runReportService.reportCompleted$ as Subject<any>).next(true);

      expect(component.runButtonState).toBe('hidden');
      expect(component.currentPrompt).toBeUndefined();
    });

    it('should handle stoprun subscription', () => {
      component.runButtonState = 'loading';

      (runReportService.stoprun as Subject<any>).next(undefined);

      expect(component.runButtonState).toBe('default');
    });
  });

  describe('State Restoration', () => {
    it.each(['panelDataPrompts', 'requestInstance'] as const)(
      'restores prompts from %s and retains child drillByContext from the request instance',
      source => {
        const prompts = createPrompts(1);
        const drillByContext = [{ id: 'drill-value', children: [] }];
        const selections = [{ id: 's1', children: [{ id: 'c1', drillByContext }] }];
        surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
          ...(source === 'panelDataPrompts' ? { panelDataPrompts: prompts } : {}),
          requestInstance: { prompts, dimensionSelections: selections },
        });
        dataSummaryService.preparePromptData.mockImplementation((_selections, restored) => restored);

        (component as any).syncSelectorState();

        expect(component.dataPrompts).toEqual(prompts);
        expect(component.dataPrompts).not.toBe(prompts);
        expect(component.selections).toEqual(selections);
        expect(component.selections[0].children?.[0]).toHaveProperty('drillByContext', drillByContext);
        expect(component.reportPayload.requestInstance.dimensionSelections).toEqual(selections);
        expect(component.isFactAvailableInDataset).toBe(true);
      },
    );

    it.each(['existing', 'cached', 'empty'] as const)(
      'handles CPF initialization with %s selections',
      source => {
        const drillByContext = [{ id: 'drill-value', children: [] }];
        const previous = [{ id: 's1', children: [{ id: 'c1', drillByContext }] }];
        component.selections = source === 'existing' ? previous : [{ id: 's2', children: [] }];
        component.dataPrompts = createPrompts(1);
        surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
          selections: source === 'cached' ? previous : [{}],
        });
        surveyCommonService.mergeSelections.mockClear();

        component.updateDataSelections({ fromCPF: true, selections: [] });

        if (source !== 'empty') {
          expect(component.selections).toEqual(previous);
          expect(component.selections).not.toBe(previous);
          expect(component.selections[0].children?.[0]).toHaveProperty('drillByContext', drillByContext);
          expect(component.panelDataPrompts).toEqual(component.dataPrompts);
          expect(surveyCommonService.mergeSelections).not.toHaveBeenCalled();
        } else {
          expect(surveyCommonService.mergeSelections).toHaveBeenCalled();
        }
      },
    );

    it('restores empty metadata without marking facts available', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({});

      (component as any).syncSelectorState();

      expect(component.isFactAvailableInDataset).toBe(false);
    });

    it('should restore cached state without dropping child drillByContext', () => {
      const drillByContext = [{ id: 'drill-value', children: [] }];
      const selections = [{ id: 's1', children: [{ id: 'c1', drillByContext }] }];
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections,
        dataPrompts: createPrompts(1),
        requestInstance: {},
        isFactAvailableInDataset: false
      });

      (component as any).syncSelectorState();

      expect(component.datasetName).toBe('Cached');
      expect(component.componentId).toBe('COMP');
      expect(component.selections[0].children?.[0]).toHaveProperty('drillByContext', drillByContext);
      expect(component.reportPayload.requestInstance.dimensionSelections).toEqual(selections);
    });

    it('should set restoration flag when appropriate', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: createSelections(1),
        dataPrompts: createPrompts(1),
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(true);

      (component as any).syncSelectorState();

      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should return early on null cached state', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue(null);
      const initial = component.datasetName;

      (component as any).syncSelectorState();

      expect(component.datasetName).toBe(initial);
    });

  });

  describe('Error Handling & Subscriptions', () => {
    it.each([true, false])('saves updated preview prompts to shared state (isError: %s)', (isError) => {
      component.selections = createSelections(1) as any;
      component.isShowDsPanel = false;
      component.dataPrompts = [{ id: 'RTLR', valid: !isError, isError,
        promptData: [{ promptSelectionLabel: 'Dollar Store' }] }] as any;
      surveyCommonService.setPanelistDataSelectorState.mockClear();

      promptErrorService.errorConfigSubjectV2.next({ promptStatus: isError ? 'INVALID' : 'VALID' });

      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenCalledExactlyOnceWith(
        expect.objectContaining({ dataPrompts: component.dataPrompts }),
      );
      expect(component.dataPrompts[0]).toMatchObject({ valid: !isError, isError });
      expect(runReportService.runReport).not.toHaveBeenCalled();
    });

    it('should handle errorConfigSubjectV2 with VALID status', () => {
      component.selections = createSelections(1) as any;
      component.runButtonState = 'disabled';

      (promptErrorService.errorConfigSubjectV2 as Subject<any>).next({ promptStatus: 'VALID' });

      expect(component.runButtonState).toBe('default');
    });

    it('should handle errorConfigSubjectV2 with INVALID status', () => {
      component.selections = createSelections(1) as any;
      component.runButtonState = 'default';

      (promptErrorService.errorConfigSubjectV2 as Subject<any>).next({ promptStatus: 'INVALID' });

      expect(component.runButtonState).toBe('disabled');
    });

  });

  describe('Dataset Picker & PubSub', () => {
    it('opens the initial dataset picker after rendering', () => {
      const callback = vi.mocked(afterNextRender).mock.calls.at(-1)?.[0];
      expect(typeof callback).toBe('function');
      const open = vi.spyOn(crfDatasetService.openDatasetPicker, 'next');

      if (typeof callback !== 'function') throw new Error('Expected initial picker callback');
      callback();

      expect(open).toHaveBeenCalledWith({ getFromPreference: false, autoApply: false });
    });

    it('does not show a missing-dataset warning when cancelling with a dataset selected', () => {
      component.datasetName = 'Selected dataset';
      const callback = vi.mocked(pubSub.subscribe).mock.calls.find(
        call => call[0] === PubSubEventEnum.OnCancelDataSet,
      )?.[1];
      if (typeof callback !== 'function') throw new Error('Expected cancellation subscription');

      callback();

      expect(component.showNoDatasetState).toBe(false);
    });

    it('hydrates late selector state once and ignores later restore effects', () => {
      const restoreEffect = vi.mocked(effect).mock.calls[0][0];
      const prompts = createPrompts(1);
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Hydrated dataset', dataPrompts: prompts,
      });
      surveyCommonService.getSelectedDatasetConfig.mockReturnValue({ id: 'ds1' });
      dataSummaryService.preparePromptData.mockImplementation((_selections, restored) => restored);

      restoreEffect();

      expect(component.datasetName).toBe('Hydrated dataset');
      expect(component.dataPrompts).toEqual(prompts);
      component.datasetName = '';
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({ datasetName: 'Other dataset' });
      restoreEffect();
      expect(component.datasetName).toBe('');
    });

    it('should open dataset picker', () => {
      component.showNoDatasetState = true;
      component.openDatasetPicker();
      expect(component.showNoDatasetState).toBe(false);
    });

    it('should handle dataset change with afterDatasetChange', () => {
      (component as any).isDatasetChanged = true;
      (component as any).afterDatasetChange({ id: 'ds1', stackId: 'stack1' });
      expect((component as any).isDatasetChanged).toBe(false);
    });

    it('should not call setDatasetInfo when isDatasetChanged is false and datasetName exists', () => {
      component.datasetName = 'Existing';
      (component as any).isDatasetChanged = false;
      panelistDatasetService.getDataSetDetails.mockReturnValue({ label: 'Test' });
      (component as any).afterDatasetChange({ id: 'ds1', stackId: 'stack1' });
      expect((component as any).isDatasetChanged).toBe(false);
    });

    it('should return early on null dataset change config', () => {
      const setDatasetSpy = vi.spyOn(component as any, 'setDatasetInfo');
      (component as any).afterDatasetChange(null);
      expect(setDatasetSpy).not.toHaveBeenCalled();
    });
  });

  describe('State Persistence', () => {
    it('should persist selector state', () => {
      component.datasetName = 'Test';
      component.selections = createSelections(1) as any;
      component.dataPrompts = createPrompts(1) as any;
      component.reportPayload.reportSpec = { spec: 'data' };

      (component as any).syncSelectorState({} as any);

      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenCalledWith(
        expect.objectContaining({ datasetName: 'Test', reportSpec: { spec: 'data' } })
      );
    });

    it('should assign prompts to request instance', () => {
      component.dataPrompts = createPrompts(1) as any;
      (component as any).assignPromptsToRequestInstance();
      expect(component.reportPayload.requestInstance.prompts).toEqual(component.dataPrompts);
    });

  });


  describe('Report Payload', () => {
    it('should initialize reportPayload correctly', () => {
      expect(component.reportPayload.attributes.reportName).toBe('Untitled Survey');
      expect(component.reportPayload.attributes.reportType).toBe('Table Builder');
      expect(component.reportPayload.attributes.workFlow).toBe('Report');
      expect(component.reportPayload.isPersistedReport).toBe(false);
    });

    it('should load base report spec', async () => {
      panelistDatasetService.loadBaseReportSpec.mockReturnValue(of({ spec: 'data' }));

      (component as any).loadBaseReportSpec({ id: 'ds1', stackId: 'stack1' });

      await new Promise(resolve => setTimeout(resolve, 50));
      expect(component.reportPayload.reportSpec).toEqual({ spec: 'data' });
    });
  });

  describe('Cleanup & Destruction', () => {
    it('should handle ngOnDestroy without errors', () => {
      expect(() => component.ngOnDestroy()).not.toThrow();
    });

    it('should handle user identity loading', () => {
      identityService.getUser.mockReturnValue(of({ userName: 'user1', organization: { homeStackId: 'stack1' } }));
      component.apploaded = false;

      component.ngOnInit();

      expect(component.apploaded).toBe(true);
    });

    it('should set request attributes when identity emits a value', () => {
      identityService.getUser.mockReturnValue(of({ userName: 'identity-user', organization: { homeStackId: 'stack1' } }));

      component.ngOnInit();

      expect(component.reportPayload.requestInstance.attributes).toEqual({
        modelId: 'THL-F',
        userId: 'identity-user',
      });
    });

    it('should execute identity next branch and set homeStackId', () => {
      identityService.getUser.mockReturnValue(of({ userName: 'branch-user', organization: { homeStackId: 'home-1' } }));

      component.ngOnInit();

      expect(preferenceService.setHomeStackId).toHaveBeenCalledWith('home-1');
      expect(component.reportPayload.requestInstance.attributes).toEqual({
        modelId: 'THL-F',
        userId: 'branch-user',
      });
    });

    it('should not auto-open dataset picker when survey route context exists', () => {
      Object.defineProperty(surveyService, 'currentSurveyId', {
        get: () => 'survey-42',
        configurable: true,
      });
      surveyCommonService.getSelectedDatasetConfig.mockReturnValue(null);
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(false);
      identityService.getUser.mockReturnValue(of({ userName: 'user1', organization: { homeStackId: 'stack1' } }));

      component.ngOnInit();

      // Verify that the component checked the currentSurveyId property
      expect(component).toBeTruthy();
    });

    it('should handle user identity error gracefully', () => {
      identityService.getUser.mockReturnValue(throwError(() => new Error('Auth failed')));
      component.apploaded = false;

      component.ngOnInit();

      expect(component.apploaded).toBe(true);
    });
  });

  describe('Additional Branch Coverage', () => {
    it('should handle loadBaseReportSpec with null response', () => {
      panelistDatasetService.loadBaseReportSpec.mockReturnValue(of(null));
      component.componentId = "OMNI_THL_SURVEY_PANEL";
      
      (component as any).loadBaseReportSpec(createDatasetDetails());
      
      expect(panelistDatasetService.loadBaseReportSpec).toHaveBeenCalled();
    });

    it('should handle openDatasetPickerModal with closed subject', () => {
      crfDatasetService.openDatasetPicker = { closed: true } as any;
      (component as any).openDatasetPickerModal();
      expect(crfDatasetService.openDatasetPicker).toBeDefined();
    });

    it('should sync prompts correctly to payload', () => {
      component.dataPrompts = [
        { id: 'p1', dimId: 'dim1', promptData: [{ promptSelectionLabel: 'Label1' }] }
      ] as any;
      
      (component as any).syncPromptsToReportPayload();
      
      expect(surveyCommonService.setPanelistDimensionalValue).toHaveBeenCalledWith({ 'dim1': ['Label1'] });
    });

    it('should run report only in default state', () => {
      component.runButtonState = 'hidden';
      component.runDashboard();
      expect(runReportService.runReport).not.toHaveBeenCalled();

      component.runButtonState = 'disabled';
      component.runDashboard();
      expect(runReportService.runReport).not.toHaveBeenCalled();
    });


    it('should update data selections with data summary', () => {
      dataSummaryService.preparePromptData.mockReturnValue([
        { id: 'p1', promptData: [{ promptSelectionLabel: 'Updated' }] }
      ] as any);
      component.selections = createSelections(1) as any;
      
      component.handleDataSummary();
      
      expect(component.dataPrompts).toEqual(dataSummaryService.preparePromptData.mock.results[0].value);
    });

    it('should handle on prompt click with existing prompts array', () => {
      component.dataPrompts = [
        { id: 'p1', hidden: false, isClosedPrompt: false },
        { id: 'p2', hidden: false, isClosedPrompt: false }
      ] as any;
      component.runButtonState = 'default';
      
      component.onPromptClick('p2');
      
      expect(component.currentPrompt?.id).toBe('p2');
    });

    it('should handle prompts with no matching id', () => {
      component.dataPrompts = [{ id: 'p1', hidden: false, isClosedPrompt: false }] as any;
      component.runButtonState = 'default';
      
      component.onPromptClick('nonexistent');
      
      expect(component.currentPrompt).toBeUndefined();
    });

    it('should persist state with all properties', () => {
      component.datasetName = 'Dataset';
      component.dataSetInfo = createDatasetDetails() as any;
      component.componentId = 'COMP';
      component.dataPrompts = createPrompts(1) as any;
      component.selections = createSelections(1) as any;
      component.isFactAvailableInDataset = true;
      
      (component as any).syncSelectorState({} as any);
      
      expect(surveyCommonService.setPanelistDataSelectorState).toHaveBeenCalledWith(
        expect.objectContaining({
          datasetName: 'Dataset',
          componentId: 'COMP',
          isFactAvailableInDataset: true
        })
      );
    });

    it('should handle restore state with completed search', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: createSelections(1),
        dataPrompts: [{ id: 'p1', validate: false, isError: true }] as any,
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(true);

      (component as any).syncSelectorState();

      expect(component.datasetName).toBe('Cached');
      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should handle trigger change in effect', () => {
      surveyCommonService.getDatasetPickerOpenTrigger.mockReturnValueOnce('trigger1').mockReturnValueOnce('trigger2');
      
      component.ngOnInit();
      
      expect(surveyCommonService.getDatasetPickerOpenTrigger).toHaveBeenCalled();
    });

    it('should preserve state when updating dataset with existing criteria', () => {
      component.selections = createSelections(3) as any;
      component.dataPrompts = createPrompts(3) as any;
      component.panelDataPrompts = createPrompts(3) as any;
      const initialSelectionsLength = component.selections.length;
      
      component.onUpdateDataset(createDatasetDetails());
      
      // When there's existing criteria, state is preserved
      expect(component.selections.length).toBe(initialSelectionsLength);
    });



    it('should handle promptErrorSubject with no selections', () => {
      component.selections = [];
      component.runButtonState = 'default';
      
      (promptErrorService.errorConfigSubjectV2 as Subject<any>).next({ promptStatus: 'VALID' });
      
      expect(component.runButtonState).toBe('disabled');
    });

    it('should trigger OnCancelDataSet event handling', () => {
      component.datasetName = '';
      component.showNoDatasetState = false;
      
      const subscribeCall = vi.mocked(pubSub.subscribe).mock.calls.find(
        (call: any[]) => call[0] === PubSubEventEnum.OnCancelDataSet
      );
      
      if (subscribeCall && typeof subscribeCall[1] === 'function') {
        (subscribeCall[1] as (...args: any[]) => void)();
      }
      
      expect(component.showNoDatasetState).toBe(true);
    });

    it('should handle OnDataSetChange event', () => {
      const afterDatasetChangeSpy = vi.spyOn(component as any, 'afterDatasetChange');
      
      const subscribeCall = vi.mocked(pubSub.subscribe).mock.calls.find(
        (call: any[]) => call[0] === PubSubEventEnum.OnDataSetChange
      );
      
      if (subscribeCall && typeof subscribeCall[1] === 'function') {
        (subscribeCall[1] as (config: any) => void)({ id: 'ds1', stackId: 'stack1' });
      }
      
      expect(afterDatasetChangeSpy).toHaveBeenCalled();
    });

    it('should load cached dataset on init', () => {
      const cachedConfig = { id: 'ds1', stackId: 'stack1' };
      surveyCommonService.getSelectedDatasetConfig.mockReturnValue(cachedConfig);
      const setDatasetInfoSpy = vi.spyOn(component as any, 'setDatasetInfo');
      component.datasetName = '';
      
      (component as any).afterDatasetChange(cachedConfig);
      
      expect(setDatasetInfoSpy).toHaveBeenCalled();
    });

    it('should call pubSub.publish with dataset types', () => {
      component.ngOnInit();
      
      expect(vi.mocked(pubSub.publish)).toHaveBeenCalledWith(
        PubSubEventEnum.OnDataSetTypesChange,
        expect.any(Array)
      );
    });

    it('should handle restore state with completed search and mapped prompts', () => {
      const promptsWithValidationFalse = [
        { id: 'p1', validate: false, isError: true },
        { id: 'p2', validate: true, isError: false },
        { id: 'p3', validate: undefined, isError: true }
      ] as any;

      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: createSelections(1),
        dataPrompts: promptsWithValidationFalse,
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(true);
      dataSummaryService.preparePromptData.mockReturnValue(promptsWithValidationFalse);

      (component as any).syncSelectorState();

      expect(component.datasetName).toBe('Cached');
      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should handle restore state with only selections', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: createSelections(2),
        dataPrompts: [],
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(false);

      (component as any).syncSelectorState();

      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should handle restore state with only prompts', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: createPrompts(2),
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(false);

      (component as any).syncSelectorState();

      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should test prompt validate ternary with false value', () => {
      const promptsWithValidateFalse = [{ id: 'p1', validate: false }] as any;
      
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Test',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: promptsWithValidateFalse,
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(true);
      dataSummaryService.preparePromptData.mockReturnValue(promptsWithValidateFalse);
      
      (component as any).syncSelectorState();
      
      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should test prompt validate ternary with true value', () => {
      const promptsWithValidateTrue = [{ id: 'p1', validate: true }] as any;
      
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Test',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: promptsWithValidateTrue,
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(true);
      dataSummaryService.preparePromptData.mockReturnValue(promptsWithValidateTrue);
      
      (component as any).syncSelectorState();
      
      expect((component as any).isRestoringSelectorState).toBe(true);
    });

    it('should handle dataset fallback values in restore', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: null,
        dataSetInfo: null,
        componentId: null,
        selections: [],
        dataPrompts: [],
        requestInstance: {},
        isFactAvailableInDataset: null
      });
      
      component.datasetName = 'Default';
      component.componentId = 'DEFAULT_COMP';
      
      (component as any).syncSelectorState();
      
      expect(component.datasetName).toBe('Default');
      expect(component.componentId).toBe('DEFAULT_COMP');
    });

    it('should handle merged request instance', () => {
      const cachedRequestInstance = { customField: 'value' };
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Test',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: [],
        requestInstance: cachedRequestInstance,
        isFactAvailableInDataset: false
      });
      
      (component as any).syncSelectorState();
      
      expect(component.reportPayload.requestInstance.customField).toBe('value');
    });

    it('should set isFactAvailableInDataset from cached state', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Test',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: [],
        requestInstance: {},
        isFactAvailableInDataset: true
      });
      
      (component as any).syncSelectorState();
      
      expect(component.isFactAvailableInDataset).toBe(true);
    });

    it('should test non-cached-dataset path', () => {
      surveyCommonService.getSelectedDatasetConfig.mockReturnValue(null);
      
      component.ngOnInit();
      
      expect(surveyCommonService.getSelectedDatasetConfig).toHaveBeenCalled();
    });

    it('should handle dataset with description fallback', () => {
      component.onUpdateDataset({
        id: 'ds1',
        dataView: { dataViewId: 'dv1', dataViewName: 'View' },
        stackId: 'stack1',
        description: 'Dataset Description'
      } as any);
      
      expect(component.datasetName).toBe('Dataset Description');
    });

    it('should handle dataset with productOfferingCode', () => {
      const dataset = createDatasetDetails({ productOfferingCode: 'POC123' }) as any;
      
      component.onUpdateDataset(dataset);
      
      expect(component.reportPayload.requestInstance.productOfferingCode).toBe('POC123');
    });

    it('should call handleDataSummary in updateDataSelections', () => {
      const handleSummarySpy = vi.spyOn(component, 'handleDataSummary');
      (component as any).isRestoringSelectorState = false;
      
      component.updateDataSelections({ selections: createSelections(1) });
      
      expect(handleSummarySpy).toHaveBeenCalled();
    });


    it('should return early in updateDataSelections while restoring cached state', () => {
      const handleSummarySpy = vi.spyOn(component, 'handleDataSummary');
      component.selections = [{ id: 'existing', children: [] }] as any;
      (component as any).isRestoringSelectorState = true;

      component.updateDataSelections({ selections: [{ id: 'incoming', children: [{ id: 'child' }] }] });

      expect(component.selections).toEqual([{ id: 'existing', children: [] }]);
      expect(handleSummarySpy).not.toHaveBeenCalled();
    });

    it('should handle stoprun with non-loading state', () => {
      component.runButtonState = 'default';
      
      (runReportService.stoprun as Subject<any>).next(undefined);
      
      expect(component.runButtonState).toBe('default');
    });

    it('should handle reportCompleted with no current prompt', () => {
      component.runButtonState = 'loading';
      component.currentPrompt = undefined;
      
      (runReportService.reportCompleted$ as Subject<any>).next(true);
      
      expect(component.runButtonState).toBe('hidden');
    });


    it('should handle onUpdateDataset with specific dataset fields', () => {
      const dataset = createDatasetDetails({
        datasetDefaultLocale: 'en-US',
        title: 'Full Dataset'
      }) as any;
      
      component.onUpdateDataset(dataset);
      
      expect(component.reportPayload.requestInstance.locale).toBe('en-US');
      expect(component.datasetName).toBe('Full Dataset');
    });

    it('should handle setDatasetInfo correctly', () => {
      listCallDatasetService.getDatasetByIdRegion.mockReturnValue({ 
        label: 'Details Label',
        solution: 'MySolution'
      });
      
      const config = { 
        id: 'ds1', 
        stackId: 'stack1', 
        type: 'Legacy Type',
        productOfferingCode: 'PANEL_OD_OMNI',
        dataView: { dataViewName: 'MainView' },
        refreshedOn: '2024-01-01'
      } as any;
      
      (component as any).setDatasetInfo(config);
      
      expect(config.title).toBe('Details Label');
      expect(config.solution).toBe('MySolution');
      expect(surveyCommonService.setSelectedDatasetConfig).toHaveBeenCalledWith(config);
      expect(surveyCommonService.setSelectedDatasetDisplay).toHaveBeenCalledWith(
        'NielsenIQ Panel On Demand Omnishopper | Details Label | MainView'
      );
    });

    it('should fall back to the dataset type for an unknown product offering code', () => {
      const config = {
        id: 'ds1',
        stackId: 'stack1',
        type: 'Legacy Type',
        productOfferingCode: 'UNKNOWN',
        dataView: { dataViewName: 'MainView' },
        refreshedOn: '2024-01-01'
      } as any;

      (component as any).setDatasetInfo(config);

      expect(surveyCommonService.setSelectedDatasetDisplay).toHaveBeenCalledWith(
        'NielsenIQ Legacy Type | Dataset Label | MainView'
      );
    });

    it('should restore cached dataset after shared state is hydrated from a draft', () => {
      const cachedConfig = {
        id: 'ds1',
        stackId: 'stack1',
        type: 'Legacy Type',
        productOfferingCode: 'PANEL_OD_OMNI',
        dataView: { dataViewName: 'MainView' },
        refreshedOn: '2024-01-01'
      } as any;

      surveyCommonService.getSelectedDatasetConfig
        .mockReturnValue(cachedConfig);
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Restored Dataset',
        dataPrompts: [{ id: 'p1', promptData: [{ promptSelectionLabel: 'L1' }], validate: true }],
        selections: [{ id: 's1', children: [{ id: 'c1' }] }],
        requestInstance: {}
      });
      component.datasetName = '';

      (component as any).afterDatasetChange(cachedConfig);

      expect(surveyCommonService.setSelectedDatasetDisplay).toHaveBeenCalledWith(
        'NielsenIQ Panel On Demand Omnishopper | Dataset Label | MainView'
      );
      expect(component.datasetName).toBe('Dataset Label');
    });

    it('should rehydrate cached reportSpec during selector state restore', () => {
      const cachedReportSpec = { widgets: ['summary'], filters: { market: 'US' } };

      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Restored Dataset',
        dataPrompts: [{ id: 'p1', promptData: [{ promptSelectionLabel: 'L1' }], validate: true }],
        selections: [{ id: 's1', children: [{ id: 'c1' }] }],
        requestInstance: { prompts: [{ id: 'p1' }] },
        reportSpec: cachedReportSpec,
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(false);

      component.reportPayload.reportSpec = {};
      component.reportSpec = {};

      (component as any).syncSelectorState();

      expect(component.reportPayload.reportSpec).toEqual(cachedReportSpec);
      expect(component.reportSpec).toEqual(cachedReportSpec);
    });


    it('should set isDatasetChanged when datasetPicker is called', () => {
      const pubSubSpy = vi.spyOn(pubSub, 'publish');
      component['openDatasetPickerModal'] = vi.fn();

      (component as any).datasetPicker();

      expect((component as any).isDatasetChanged).toBe(true);
      expect(pubSubSpy).toHaveBeenCalledWith(PubSubEventEnum.OnDataSetTypesChange, (component as any).dataSetTypes);
    });



    it('should assign empty prompts when dataPrompts is undefined', () => {
      component.dataPrompts = undefined as any;

      (component as any).assignPromptsToRequestInstance();

      expect(component.reportPayload.requestInstance.prompts).toEqual([]);
    });

    it('should normalize validate false prompts during restore when search has completed', () => {
      dataSummaryService.preparePromptData.mockReturnValue([
        { id: 'p1', validate: true, isError: false }
      ] as any);
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: [{ id: 'p1', validate: false }],
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(true);

      (component as any).syncSelectorState();

      expect(component.dataPrompts[0].validate).toBe(true);
    });

    it('should restore null prompt and selection arrays as empty arrays', () => {
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: null,
        dataPrompts: null,
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(false);

      (component as any).syncSelectorState();

      expect(component.dataPrompts).toEqual([]);
      expect(component.selections).toEqual([]);
    });

    it('should not enter restoring mode when cached state has no selections and no prompts', () => {
      const handleSummarySpy = vi.spyOn(component, 'handleDataSummary');
      surveyCommonService.getPanelistDataSelectorState.mockReturnValue({
        datasetName: 'Cached',
        dataSetInfo: { id: 'ds1' },
        componentId: 'COMP',
        selections: [],
        dataPrompts: [],
        requestInstance: {},
        isFactAvailableInDataset: false
      });
      surveyCommonService.hasCompletedPanelistSearch.mockReturnValue(false);

      (component as any).syncSelectorState();

      expect((component as any).isRestoringSelectorState).toBe(false);
      expect(handleSummarySpy).not.toHaveBeenCalled();
    });


    it('should handle afterDatasetChange with falsy config', () => {
      (component as any).isDatasetChanged = true;

      (component as any).afterDatasetChange(null);

      expect((component as any).isDatasetChanged).toBe(true);
    });

    it('should handle report completion with valid response', () => {
      runReportService.reportCompleted$ = of({ success: true });
      
      component.ngOnInit();

      expect(runReportService.reportCompleted$).toBeDefined();
    });

  });
});
