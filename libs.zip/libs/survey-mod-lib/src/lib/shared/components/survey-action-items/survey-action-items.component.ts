import { BreakpointObserver } from '@angular/cdk/layout';
import { ChangeDetectionStrategy, Component, computed, inject, input, output } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ButtonModule, LinkModule, TooltipModule } from '@nielseniq/athena-core';
import { map } from 'rxjs';
import { SurveyActionItem, SurveyActionItemClickEvent } from './survey-action-items.model';

/**
 * Reusable bulk-action bar for grid selections. Renders the selected count, a deselect control
 * and the configured actions whose `isVisible` predicate passes for the current selection.
 */
@Component({
  selector: 'survey-action-items',
  standalone: true,
  imports: [ButtonModule, LinkModule, TooltipModule],
  templateUrl: './survey-action-items.component.html',
  styleUrl: './survey-action-items.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyActionItemsComponent<T = unknown, TId extends string = string> {
  private readonly isNarrowViewport = toSignal(
    inject(BreakpointObserver).observe('(max-width: 1279px)').pipe(map((state) => state.matches)),
    { initialValue: false }
  );
  readonly selectedItems = input<readonly T[]>([]);
  readonly actions = input<readonly SurveyActionItem<T, TId>[]>([]);
  readonly selectedCountLabel = input('Assets selected');
  readonly deselectLabel = input('Deselect all');
  /** Forces icon-only buttons regardless of viewport, e.g. while a side panel narrows the page. */
  readonly forceIconsOnly = input(false);
  /** Action rendered in its active (highlighted) state, e.g. Info while its panel is open. */
  readonly activeActionId = input<TId | null>(null);
  readonly iconsOnly = computed(() => this.forceIconsOnly() || this.isNarrowViewport());

  readonly deselectAll = output<void>();
  readonly actionClick = output<SurveyActionItemClickEvent<T, TId>>();

  readonly selectedCount = computed(() => this.selectedItems().length);
  readonly visibleActions = computed(() => {
    const items = this.selectedItems();
    if (!items.length) {
      return [];
    }
    return this.actions().filter((action) => action.isVisible?.(items) ?? true);
  });

  onDeselectAll(): void {
    this.deselectAll.emit();
  }

  onActionClick(action: SurveyActionItem<T, TId>): void {
    this.actionClick.emit({ actionId: action.id, items: this.selectedItems() });
  }
}
