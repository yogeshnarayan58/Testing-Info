import test from "@playwright/test";
import {
  findDataSetByName,
  getTestDataByLocale,
  getDimensionSelectionsByPivot,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import localizationData from "./test-data/localization-data.json";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ExportComponent } from "../../../common/components/export/export";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

let reportTestData = findDataSetByName(devTestData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";

test.describe("Shifting analysis(Quick Insights) - Retailer Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData =
      reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn("Skipping tests as the required pivot test data is not present");
    }
    test.skip(!isValidTestData, "Skipping tests as the required pivot test data is not present");
  });

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@QI:MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(reportUrl);
      let commonBasePage = commonTestCase.getBasePage();
      dataSelector = new DataSelector(commonBasePage);

      await dataSelector.switchPivotDropdown(pivot);

      if (localeData.pivotMadlibText) {
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).retailer;
        assert(actualMadlibText).toMatch(new RegExp(expectedMadlibText, "i"));
      } else {
        console.warn(`No madlib text pattern defined for locale: ${localeData.locale}`);
      }
    }
  );

  test.describe.serial(
    "Run, Exports, Snapshot, FMS",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test("Validate run report", { tag: "@QI:RunReport" }, async () => {
        test.setTimeout(RUN_TEST_TIMEOUT);
        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(reportUrl);
        let commonBasePage = commonTestCase.getBasePage();
        dataSelector = new DataSelector(commonBasePage);

        await dataSelector.switchPivotDropdown(pivot);
        await dataSelector.waitForMadlibStability();

        const retailerPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
        if (!retailerPivotData) {
          throw new Error("Pivot not found in test data: Retailer");
        }

        await dataSelector.clickMadlibDimension("Shifting Universe Retailer");
        await dataSelector.setMadlibSelection(retailerPivotData["Shifting Universe Retailer"]);

        await dataSelector.clickMadlibDimension("Facts");
        await dataSelector.selectClosedDropdown(retailerPivotData["Facts"]["selections"]);

        await dataSelector.clickMadlibDimension("Products");
        await dataSelector.setMadlibSelection(retailerPivotData["Products"]);

        await dataSelector.clickMadlibDimension("Comparison Retailers");
        await dataSelector.setMadlibSelection(retailerPivotData["Comparison Retailers"]);

        await dataSelector.clickMadlibDimension("Period");
        await dataSelector.setPeriodMadlibSelection(retailerPivotData["Period"]);

        await dataSelector.clickMadlibDimension("Comparison Period");
        await dataSelector.setPeriodMadlibSelection(retailerPivotData["Comparison Period"]);

        await dataSelector.clickMadlibDimension("Geography");
        await dataSelector.setMadlibSelection(retailerPivotData["Geography"]);

        await dataSelector.clickMadlibDimension("Demographic");
        await dataSelector.setMadlibSelection(retailerPivotData["Demographic"]);

        let dsBasePage = dataSelector.getBasePage();
        commonTestCase = new CommonTestCase(dsBasePage);
        await commonTestCase.clickRunButton();
        await commonTestCase.waitForReportRunCompletion();

        const { newReportTitle, newUrl } = await commonTestCase.saveReport();
        savedReportTitle = newReportTitle;
        savedReportUrl = newUrl;
      });

      test("Validate PPT export", { tag: "@QI:ValidatePPTExport" }, async () => {
        test.skip(!savedReportUrl, "Skipping PPT Export - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(savedReportUrl);

        let commonBasePage = commonTestCase.getBasePage();
        let exportComponent = new ExportComponent(commonBasePage);

        await exportComponent.validateExportFunctionality(
          "PowerPoint",
          "Editable objects",
          "Separately"
        );
      });

      test("Validate Excel export", { tag: "@QI:ValidateExcelExport" }, async () => {
        test.skip(!savedReportUrl, "Skipping Excel Export - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(savedReportUrl);

        let commonBasePage = commonTestCase.getBasePage();
        let exportComponent = new ExportComponent(commonBasePage);

        await exportComponent.validateExportFunctionality(
          "Excel",
          "Editable objects",
          "Separately"
        );
      });

      test("Validate snapshot", { tag: "@QI:Snapshot" }, async () => {
        test.skip(!savedReportUrl, "Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(savedReportUrl);

        let snapshot = new Snapshot(commonTestCase.getBasePage());
        await snapshot.waitForReportRunCompletion();
        await basePage.getWebActions().delay(SMALL_TIMEOUT);

        await snapshot.clickSaveIcon();
        await basePage.getWebActions().delay(SMALL_TIMEOUT);

        await snapshot.clickSnapshotIcon();
        await basePage.getWebActions().delay(SMALL_TIMEOUT);

        assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
        await snapshot.shiftingToSnapshot();
      });

      test("Validate FullScreen", { tag: "@QI:ValidateFullScreen" }, async () => {
        test.skip(!savedReportUrl, "Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(savedReportUrl);
        await commonTestCase.fullScreenView();
      });

      test("Validate presentationMode", { tag: "@QI:PresentationMode" }, async () => {
        test.skip(!savedReportUrl, "Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(savedReportUrl);
        await commonTestCase.presentationMode();
      });

      test("openCurrentReportFMS", { tag: "@QI:openCurrentReportFMS" }, async () => {
        test.skip(!savedReportTitle, "Skipping openCurrentReportFMS - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);
        await findMyStuff.clickFindMyStuff();
        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        const openedReportUrl = await findMyStuff.webActionHandler.getPageUrl();
        assert(new URL(openedReportUrl).pathname).toBe(new URL(savedReportUrl).pathname);
      });
    }
  );
});
