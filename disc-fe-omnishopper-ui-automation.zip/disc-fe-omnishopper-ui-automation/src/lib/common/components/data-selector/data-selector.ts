import { BasePage, assert } from "@gfk/gta";
import { ResourceManager } from "../../utils/resource-manager";
import * as commonResources from "../../pages/common-test-resources.json";
import * as dsResources from "../data-selector/data-selector-resources.json";
import { MAX_TEST_TIMEOUT, SMALL_TIMEOUT, POLLING_INTERVAL } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../pages/common-test-case/common-test-case";
import { PeopleMenu } from "./people-menu-constant";
import { AssertionMenuOption, AssertionSubMenuOption } from "../../models/data-selector-model";
import { randomInt } from "crypto";
// import * as commonResources from '../../../object-resources/common-resources.json';

// Register the DataSelector resources
const DS_COMPONENT_NAME = "DataSelector";
const COMMON_COMPONENT_NAME = "Common";
export class DataSelector extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.webActionHandler = basePage.getWebActions();
    // Initialize ResourceManager with component resources
    this.resourceManager = new ResourceManager({});

    // Register multiple resources for the same component
    this.resourceManager.registerResources(DS_COMPONENT_NAME, dsResources);
    this.resourceManager.registerResources(
      COMMON_COMPONENT_NAME,
      commonResources
    );    
    
    // this.resourceManager.registerResources(COMMON_COMPONENT_NAME, commonResources); // TODO: Uncomment when common resources are available
  }

  /**
   * Handles interaction with the Additional Prompt Ellipsis (three dots) icon.
   */
  public async clickAdditionalPromptEllipsisIcon(): Promise<void> {
    await super.clickWebelement("additionalPromptEllipsis",DS_COMPONENT_NAME);
  }

  /**
   * Clicks on a Madlib dimension element specified by the given dimension key.
   *
   * @param {string} dimension - The key or identifier used to locate the dimension element.
   */
  public async clickMadlibDimension(dimension: string): Promise<void> {
    try {
      // Retrieve the web element corresponding to the specified dimension
      const dimensionElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(dimension, DS_COMPONENT_NAME)
      );

      // Wait until the element is visible and ready for interaction
      await dimensionElement.waitFor();
      // Click the dimension element
      await dimensionElement.click();
    } catch (error) {
      console.error(`Failed to click Madlib dimension '${dimension}':`, error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Error interacting with Madlib dimension '${dimension}': ${errorMessage}`);
    }
  }

  /**
   * Closes the Data Selector panel by clicking its close icon.
   */
  public async closeDataSelectorPanel(): Promise<void> {
    await super.clickWebelement("Data Selector Close Icon",DS_COMPONENT_NAME);
  }

  /**
   * Removes selected items by clicking the remove icon.
   */
  public async removeSelections(): Promise<void> {
    await super.clickWebelement("removeIcon",DS_COMPONENT_NAME);
  }

  /**
   * Clicks the Add icon.
   * Note: Search icon may appear after folder selection in some dimensions (e.g., Period)
   */
  public async clickAddIcon(): Promise<void> {
    await super.clickWebelement("addIcon",DS_COMPONENT_NAME);
  }

  /**
   * Clicks the Search icon.
   */
  public async clickSearchIcon(): Promise<void> {
    await super.clickWebelement("searchIcon",DS_COMPONENT_NAME);
  }

  /**
   * Enters the given text into the search input field after clearing any existing text.
   *
   * @param inputText - The text to enter into the search field.
   */
  public async enterTextInSearchField(inputText: string): Promise<void> {
    const searchField = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("dsSearchBarInput", DS_COMPONENT_NAME)
    );
    await searchField.waitFor();
    // Clear any existing text
    await searchField.enterText("");
    // Enter the new input text
    await searchField.enterText(inputText);
  }

  /**
   * Selects a folder by clicking on its label based on the folder name.
   *
   * @param folderName - The name of the folder to select.
   */
  public async selectFolder(folderName: string): Promise<void> {
    // Retrieve the folder element dynamically using the folder name
    const folderElement = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource(
        "dsNavigationItemLabel",
        folderName,
        DS_COMPONENT_NAME
      )
    );
    await folderElement.waitFor();
    // Click the folder element to select it
    await folderElement.click();
  }

  /**
   * Checks (selects) an item from the selections viewport based on the given selection name.
   *
   * @param selection - The name of the item to be selected.
   */
  public async checkSelection(selection: string): Promise<void> {
    // Ensure the selections viewport is loaded
    await this.webActionHandler
      .getWebElement(this.resourceManager.getResource("dsSelectionsViewPort"))
      .waitFor();
    // Retrieve the selection element dynamically using the selection name
    const selectionElement = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource(
        "checkboxLabel",
        selection,
        DS_COMPONENT_NAME
      )
    );
    await selectionElement.waitFor();
    // Click the selection element to check/select it
    await selectionElement.click();
  }

  /**
   * Clicks the Done icon to complete the current action or close the panel.
   */
  public async clickDone(): Promise<void> {
    await super.clickWebelement("doneIcon",DS_COMPONENT_NAME);
  }

  
  /**
   * Sets the Madlib selections by iterating through each folder and applying its corresponding dimension selections.
   *
   * @param dimensionSelection - An object containing folder names as keys and their corresponding selections as values.
   */
  public async setMadlibSelection(
    dimensionSelection: {
      selections: Record<string, any>;
    },
    searchReq = true
  ): Promise<void> {

    const folderEntries = Object.entries(dimensionSelection.selections);
    if (!folderEntries.length) {
      return;
    }
    // Clear default/existing state once before processing all folders.
    await this.checkSelectionGroupExists();

    // Loop through each folder and its associated selections.
    for (let index = 0; index < folderEntries.length; index++) {
      const [folderName, selections] = folderEntries[index];
      if (index > 0) { // For second+ folders, create an additional selection group instead of replacing previous selections.
        await this.clickAddIcon();
      }
      await this.setMadlibFolder(folderName, searchReq); // Select the folder
      await this.webActionHandler
        .getWebElement(
          this.resourceManager.getResource("dsSelectionsViewPort", DS_COMPONENT_NAME)
        )
        .waitFor(MAX_TEST_TIMEOUT, "visible");
      await this.setDimensionSelection(selections, searchReq); // Apply the dimension selections within the folder
    }
  }

  /**
   * Selects each dimension value by searching and clicking its corresponding checkbox.
   *
   * @param selections - An array of dimension values to select.
   */
  public async setDimensionSelection(
    selections: string[],
    searchReq = true
  ): Promise<void> {
    try {
      for (const selection of selections) {
        if (searchReq) {
          // Enter the selection text in the search field
          await this.enterTextInSearchField(selection);
        }
        // Wait for the selection viewport to be available in the DOM
        await this.webActionHandler
          .getWebElement(this.resourceManager.getResource("dsSelectionsViewPort", DS_COMPONENT_NAME))
          .waitFor();
        // Click the checkbox corresponding to the selection
        const selectionElement = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource(
            "checkboxLabel",
            selection,
            DS_COMPONENT_NAME
          )
        );
        await selectionElement.click();
      }
      // Click the 'Done' button to finalize the selection process
      await this.clickDone();
    } catch (error) {
      console.error("Error in setDimensionSelection:", error);
      throw new Error(`Failed to set dimension selection: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Opens a Madlib folder by searching for its name and selecting it.
   * Logs an error if the operation fails.
   *
   * @param folderName - The name of the folder to search and select.
   */
  public async setMadlibFolder(
    folderName: string,
    searchReq = true
  ): Promise<void> {
    try {
      if (searchReq) {
         // Get the search icon element
        const searchIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("searchIcon", DS_COMPONENT_NAME)
        );
      // Check if the search icon is visible
        const isVisible = await searchIcon.isVisible();
        if (isVisible) {
          // Click on the search icon to activate the search input
          await this.clickSearchIcon();
          // Enter the folder name into the search field
          await this.enterTextInSearchField(folderName);
        } else {
          // If the search icon is not visible, directly enter the folder name
          // Directly select the folder without searching
          await this.webActionHandler.delay(SMALL_TIMEOUT);
          await this.enterTextInSearchField(folderName);
        }
        // Select the folder from the search results
        await this.selectFolder(folderName);
      } else {
        // Search not required in new UI flows; select directly from visible list.
        await this.selectFolder(folderName);
      }
      console.log(`Folder '${folderName}' successfully selected.`);
    } catch (error) {
      console.error(
        `❌ Failed to select Madlib folder '${folderName}':`,
        error
      );
      throw error;
    }
  }
  /**
   * Retrieves the text value of a specified Madlib dimension.
   *
   * @param dimension - The name of the dimension whose value should be retrieved.
   * @returns The text content of the specified dimension element.
   */
  public async fetchMadlibDimensionValue(dimension: string): Promise<string> {
    // Get the locator for the web element based on the provided dimension name
    const dimensionElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(dimension, DS_COMPONENT_NAME)
    );

    // Wait until the element is present and visible on the page
    await dimensionElement.waitFor();

    // Return the text content of the dimension element
    return await dimensionElement.getText();
  }

  /**
   * Handles the selection of dimensions in a madlib-like UI flow based on a given input.
   * Iterates through each folder and applies corresponding selections.
   *
   * @param dimensionSelection - Object containing dimension folder names and associated selections
   */
  public async setPeriodMadlibSelection(dimensionSelection: {
    selections: Record<string, string[]>;
  }): Promise<void> {
    const { selections } = dimensionSelection;

    for (const [folderName, dimensionValues] of Object.entries(selections)) {
      try {
        //check if any selections exist
        await this.checkSelectionGroupExists();

        // Construct and retrieve the navigation element for the given folder
        const folderElement = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource(
            "dsNavigationItemLabel",
            folderName,
            DS_COMPONENT_NAME
          )
        );
        await folderElement.click();
        await this.setPeriodDimensionSelection(dimensionValues);
      } catch (error) {
        console.error(`Error selecting folder "${folderName}":`, error);
        throw new Error(
          `Failed to process selections for folder: ${folderName}`
        );
      }
    }
  }

  /**
   * Applies a list of dimension selections by clicking each option in the UI.
   *
   * @param selectionValues - List of dimension values to select
   */
  public async setPeriodDimensionSelection(
    selectionValues: string[]
  ): Promise<void> {
    for (const value of selectionValues) {
      try {
        const selectionElement = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource(
            "checkboxLabel",
            value,
            DS_COMPONENT_NAME
          )
        );

        await selectionElement.click();
      } catch (error) {
        console.error(`Error selecting dimension value "${value}":`, error);
        throw new Error(`Failed to select dimension value: ${value}`);
      }
    }

    try {
      await this.clickDone();
    } catch (error) {
      console.error("Error clicking 'Done' button:", error);
      throw new Error("Failed to finalize the dimension selection process.");
    }
  }

  /**
   * Clicks the 'Run' button in the report interface.
   */
  public async clickRunButton(): Promise<void> {
    await super.clickWebelement("reportRunButton", DS_COMPONENT_NAME);
  }

  /**
   * Waits for the report run process to complete by monitoring the visibility
   * of the cancel button during spinner activity. Handles timeout scenarios.
   */
  public async waitForReportRunCompletion(): Promise<void> {
    const cancelButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("inProgressCancel", DS_COMPONENT_NAME)
    );

    try {
      // First wait until the cancel button becomes visible (indicates run started)
      await cancelButton.waitFor(MAX_TEST_TIMEOUT, "visible");
      // Then wait until the cancel button disappears (indicates run completed)
      await cancelButton.waitFor(MAX_TEST_TIMEOUT, "hidden");

      console.info("Report run completed!");
    } catch (error) {
      console.error(
        "Cancel button did not disappear within the expected duration:",
        error
      );
      throw new Error("Report run did not complete within the timeout period.");
    }
  }

  /**
 * Initiates the process to make a copy of a report.
 * This involves clicking the 'Make a Copy' icon, updating the report title,
 * selecting the save location, and saving the new report.
 * After the save operation, it waits for the page to re-render and then retrieves
 * the URL of the new report.
 * Finally, it closes the browser tab and returns an object containing both the
 * new report's title and its URL.
 * 
 * @returns {Promise<{ newReportTitle: string, newUrl: string }>}
 */
  public async makeAcopy(): Promise<{ newReportTitle: string, newUrl: string }> {
    await this.clickMakeAcopyIcon();
    let newReportTitle = await this.updateReportTitle();
    await this.clickMyAssets();
    await this.clickSaveButton();
    await this.webActionHandler.delay(SMALL_TIMEOUT); //Todo: Added a delay after clicking the 'Save' button to accommodate page re-rendering; need to find an alternative approach
    let newUrl = await this.webActionHandler.getPageUrl();
    await this.webActionHandler.closeBrowserTab();
    return { newReportTitle, newUrl };
  }

  /**
   * Clicks the "Make a copy" icon after ensuring it is visible and enabled.
   * Throws an error if the icon is not found, not visible, or not clickable within the timeout.
   */
  public async clickMakeAcopyIcon(): Promise<void> {
    // Wait for and click the "Save" icon
    await this.clickSaveIcon();
    await super.clickWebelement("makeAcopy",DS_COMPONENT_NAME);
    
  }

  /**
   * Clicks the save icon after ensuring it is visible.
   * Throws an error if the icon is not found or not clickable within timeout.
   */
  public async clickSaveIcon(): Promise<void> {
    await super.clickWebelement("saveIcon",DS_COMPONENT_NAME);
  }

  /**
   * Retrieves and updates the report title input field with a new value.
   * @param prefix - The prefix to prepend to the existing report title.
   * @returns The updated report title.
   */
  public async updateReportTitle(): Promise<string> {
    const reportTitleInput = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "reportTitleInput",
        COMMON_COMPONENT_NAME
      )
    );

    // Wait for the report title input to be visible
    await reportTitleInput.waitFor();

    // Retrieve the current value of the report title
    const originalTitle = await reportTitleInput.getValue();

    // Construct the new report title
    const newReportTitle = `Playwright automation - ${originalTitle}`;

    // Enter the new report title into the input field
    await reportTitleInput.enterText(newReportTitle);

    return newReportTitle;
  }

  /**
   * Clicks on the "My assets" element after ensuring it is visible and clickable.
   * Throws an error if the element is not found or not clickable within the specified timeout.
   */
  public async clickMyAssets(): Promise<void> {
    const myAssetsElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("My assets", COMMON_COMPONENT_NAME)
    ); // TODO: "My assets" element lacks a data-test-id; consider adding one for reliable test targeting in the future #refactor-data-test-id

    try {
      // Wait for the "My assets" element to be visible
      await myAssetsElement.waitFor();

      // Click on the "My assets" element
      await myAssetsElement.click();
    } catch (error) {
      throw new Error(
        "Failed to click 'My assets' element: element not visible or clickable."
      );
    }
  }

  /**
   * Clicks on the "Save" button after ensuring it is visible and clickable.
   * Throws an error if the element is not found or not clickable within the specified timeout.
   */
  public async clickSaveButton(): Promise<void> {
    const saveButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("Save button", COMMON_COMPONENT_NAME)
    );

    try {
      // Wait for the "Save" button to be visible
      await saveButton.waitFor();

      // Click on the "Save" button
      await saveButton.click();
    } catch (error) {
      throw new Error(
        "Failed to click 'Save' button: element not visible or clickable."
      );
    }
  }

   public async selectClosedDropdown(selections: any) {
    for (const closedDropDownVal of selections.value) {
      await this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            "closedDropdownSelector",
            closedDropDownVal,
            DS_COMPONENT_NAME
          )
        )
        .click();
    }
  }

  public async multiSelectDropDown(selections: any) {
    for (const closedDropDownVal of selections) {
      const closedDropDownItem = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          "multiSelectDropdownSelector",
          closedDropDownVal,
          DS_COMPONENT_NAME
        )
      );
      await closedDropDownItem.waitFor(MAX_TEST_TIMEOUT, "visible");
      await closedDropDownItem.focus();
      await closedDropDownItem.click();
    }
  }
 /**
 * Switches to a specific pivot option in the dropdown.
 * 
 * @param {string} pivot - The name of the pivot option to select.
 * @param {boolean} waitForMadlibUpdate - Whether to wait for madlib update after pivot switch (default: true)
 * @returns {Promise<void>}
 */
public async switchPivotDropdown(pivot: string, waitForMadlibUpdate: boolean = true): Promise<void> {
  try {
    // Get the pivot dropdown selector element
    const pivotDropdown = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "pivotDropdownSelector",
        DS_COMPONENT_NAME
      )
    );
    await pivotDropdown.waitFor();
    await pivotDropdown.click();
    
    // Get the specific pivot element based on the provided pivot name
    const pivotElement = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource(
        "pivotElement",
        pivot,
        DS_COMPONENT_NAME
      )
    );
    // Wait for the pivot option to be visible after dropdown opens
    await pivotElement.waitFor();
    await pivotElement.click();
    
    // Wait for madlib update after pivot change (network calls to stabilize)
    if (waitForMadlibUpdate) {
      await this.waitForMadlibStability();
    }
    
    console.log(`Successfully switched to pivot: ${pivot}`);
  } catch (error) {
    console.error(`Failed to switch to pivot '${pivot}':`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Error switching to pivot '${pivot}': ${errorMessage}`);
  }
}

  public async assertPivotDropdown(pivotArr: any) {
     if (!pivotArr || !Array.isArray(pivotArr)) return;
    await this.webActionHandler
      .getWebElement(
        this.resourceManager.getResource(
          "pivotDropdownSelector",
          DS_COMPONENT_NAME
        )
      )
      .click();
    for (const element of pivotArr) {
      await this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            "pivotElement",
            element,
            DS_COMPONENT_NAME
          )
        )
        .waitFor(MAX_TEST_TIMEOUT, "visible");
      const dropDownItem = await this.webActionHandler.getWebElementsText(
        this.resourceManager.getDynamicResource(
          "pivotElement",
          element,
          DS_COMPONENT_NAME
        )
      );
      assert(dropDownItem[0]).toBe(element);
    }
    await this.webActionHandler
      .getWebElement(
        this.resourceManager.getResource(
          "pivotDropdownSelector",
          DS_COMPONENT_NAME
        )
      )
      .click();
  }

  public async assertFactsDropdown(factsArr: any) {
    for (const element of factsArr) {
      await this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            "factDropDownOption",
            element,
            DS_COMPONENT_NAME
          )
        )
        .waitFor(MAX_TEST_TIMEOUT, "visible");
      const dropDownItem = await this.webActionHandler.getWebElementsText(
        this.resourceManager.getDynamicResource(
          "factDropDownOption",
          element,
          DS_COMPONENT_NAME
        )
      );
      assert(dropDownItem[0]).toBe(element);
    }
  }

  public async assertPeopleMenuOptions(
    menuOptions: AssertionMenuOption[]
  ) {
    console.log('===Starting assertion for people menu options===');
    for (const item of menuOptions) {
      const menuSelectorText = PeopleMenu[item.name].selectorText;
      const menuElement = this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            item.subMenu?.length ? "peopleDropdownItemWithSubmenus" : "peopleDropdownItemWithoutSubmenus",
            menuSelectorText,
            DS_COMPONENT_NAME
          )
        );
      
      const isVisible = await menuElement.isVisible();
      // The below condition checks whether the menu item should be displayed or not.
      // For example, few datasets may not have certain menu item like "Deal".
      if (item.shouldDisplay) {
        assert(isVisible).toBeTruthy();
      } else {
        assert(isVisible).toBeFalsy();
      }
      console.log(`People Menu "${item.name}" asserted.`);
    }
    await this.ensureAllSubMenusClosed(menuOptions);
    console.log('===Ended assertion for people menu options===');
  }

  /**
   * Iterate and mouse hover the menu dropdown and check people sub menu visibility.
   * @param menuOptions The menu options to assert.
   */
  public async assertPeopleSubMenuOptions(
    menuOptions: AssertionMenuOption[]
  ) {
    console.log('===Starting assertion for people sub menu options===');
    for (const item of menuOptions) {
      if (item.shouldDisplay && item.subMenu && item.subMenu.length) { // Main menu should display and sub menu should display
        const mainMenuSelectorText = PeopleMenu[item.name].selectorText;
        const mainMenuElement = this.webActionHandler
          .getWebElement(
            this.resourceManager.getDynamicResource(
              "peopleDropdownItemWithSubmenus",
              mainMenuSelectorText,
              DS_COMPONENT_NAME
            )
          );
        await mainMenuElement.waitFor();
        const isVisible = await mainMenuElement.isVisible();
        if (!isVisible) {
          throw new Error(`Element for "${item.name}" is not visible and unable to assert sub menu items`);
        }
        await this.checkPeopleSubMenuItems(item, mainMenuElement);
      } else if (item.shouldDisplay && item.subMenu && item.subMenu.length === 0) { // Main menu should display and no sub menu should display
        console.log(`Menu item: "${item.name}" should display but has no sub menu items to assert`);
        assert(!item.subMenu || item.subMenu.length === 0).toBeTruthy();
      } else { // Main menu should not display and no sub menu should display
        console.log(`Menu item: "${item.name}" should not display and no sub menu items to assert`);
      }
    }

    await this.ensureAllSubMenusClosed(menuOptions);
    console.log('===Ended assertion for people sub menu options===');
  }

  /**
   * Hover on main menu item and assert sub menu items visibility.
   * @param {AssertionMenuOption} item The main menu option object containing submenus to assert.
   * @param {any} mainMenuElement The main menu DOM element to hover over to reveal submenus.
   */
  private async checkPeopleSubMenuItems(item: AssertionMenuOption, mainMenuElement: any) {
    const allSubMenus = item.subMenu.map(sub => sub.name).join(", ");
    console.log(`Menu item: "${item.name}" and its sub menu items: "${allSubMenus}" to assert`);

    for (let index = 0; index < item?.subMenu.length; index++) {
      await mainMenuElement.hover(); // Hover on main menu item to reveal sub-menu
      
      const subMenu = item.subMenu[index]; // Example, subMenu = { name: "BOUGHT_EACH_OF", shouldDisplay: true }
      const subMenuSelectorText = PeopleMenu[subMenu.name].selectorText; // Example, selectorText = "Bought each of"
      const subMenuItemElement = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          "peopleDropdownItemSubMenuItems",
          subMenuSelectorText,
          DS_COMPONENT_NAME
        )
      );
      const isVisible = await subMenuItemElement.isVisible();
      // The below condition checks whether the menu item should be displayed or not.
      // For example, few datasets may not have certain menu item like "Deal".
      if (subMenu.shouldDisplay) {
        assert(isVisible).toBeTruthy();
      } else {
        assert(isVisible).toBeFalsy();
      }
      console.log(`Sub menu item: "${subMenu.name}" asserted.`);
    }
  }

  /**
   * Assert People main menu info icon tooltip text.
   * @param menuOptions 
   */
  public async assertPeopleMenuInfoOptions(menuOptions: AssertionMenuOption[]) {
    console.log('===Starting assertion for people menu info icon===');
    for (const item of menuOptions) {
      if (item.shouldDisplay) {
        await this.checkPeopleMenuInfoState(item);
      }
    }
    await this.ensureAllSubMenusClosed(menuOptions);
    console.log('===Ended assertion for people menu info icon===');
  }

  private async checkPeopleMenuInfoState(item: AssertionMenuOption) {
    console.log(`Menu item: "${item.name}" info icon tooltip to assert`);
    const menuSelectorText = PeopleMenu[item.name].selectorText;

    // Hover on the main menu item
    const menuItem = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource(
        item.subMenu?.length ? 'peopleDropdownItemWithSubmenus' : 'peopleDropdownItemWithoutSubmenus',
        menuSelectorText,
        DS_COMPONENT_NAME
      )
    );
    await menuItem.hover();

    // Hover on the info icon to trigger the tooltip
    const menuInfoIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource(
        item.subMenu?.length ? 'peopleMenuWithSubmenusInfoIcon' : 'peopleMenuWithoutSubmenusInfoIcon',
        menuSelectorText,
        DS_COMPONENT_NAME
      )
    );
    await menuInfoIcon.hover();

    // Wait for the tooltip to appear
    await this.webActionHandler.delay(300);
    
    // Get the tooltip text element
    const matTooltipTxt = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "peopleSubmenuInfoTooltipId",
        DS_COMPONENT_NAME
      )
    );
    await menuItem.waitFor(MAX_TEST_TIMEOUT, "visible");
    await matTooltipTxt.waitFor();
    const matTooltipTxtFromUI = await matTooltipTxt.getAllInnerText();
    const tooltipExpectedText = PeopleMenu[item.name].tooltipText;
    assert(matTooltipTxtFromUI[0]).toContain(tooltipExpectedText);
    console.log(`Info icon tooltip text asserted for menu item: "${item.name}"`);
    await menuItem.hover(); // Hover again on main menu to close tooltip
  }
 
  public async handlePeopleMenuOptions(menuOptions: any) {
    for (const folderKey of Object.keys(menuOptions)) {
      await this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            "peopleDropdownItemWithSubmenus",
            folderKey,
            DS_COMPONENT_NAME
          )
        )
        .hover();
      await this.handlePeopleSubMenuOptions(menuOptions[folderKey]);
    }
  }

  public async handlePeopleSubMenuOptions(subMenuOptions: any) {
    for (const folderKey of Object.keys(subMenuOptions)) {
      await this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            "peopleDropdownItemSubMenuItems",
            folderKey,
            DS_COMPONENT_NAME
          )
        )
        .click();
      await this.selectPeopledimensions(subMenuOptions[folderKey]);
    }
  }

  public async selectPeopledimensions(menuDimensions: any) {
    for (const dimensionKey of Object.keys(menuDimensions)) {
      console.log("Selecting People dimension:", dimensionKey);

      // Click correct dimension based on text (Product / Time Period)
      const dimensionLocator = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          "peopleDimensionDataSelectionByText",
          dimensionKey,
          DS_COMPONENT_NAME
        )
      );

      await dimensionLocator.waitFor(MAX_TEST_TIMEOUT, "visible");
      await dimensionLocator.click();

      await this.waitForTimeout(SMALL_TIMEOUT);

          // Handle Product/Retailer normally
      if (dimensionKey === "Product" || dimensionKey === "Retailer") {
        await this.setPeopleDimensionFolder(menuDimensions[dimensionKey]);
        await this.waitForTimeout(SMALL_TIMEOUT); 
      }
      if (dimensionKey === "Time Period") {
        await this.setPeriodMadlibSelection(menuDimensions[dimensionKey]);
        await this.waitForTimeout(SMALL_TIMEOUT);
      }

      console.log(`${dimensionKey} selection completed.`);
    }
    const doneButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("panelPropertiesActionButton", DS_COMPONENT_NAME)
    );

    await doneButton.waitFor(MAX_TEST_TIMEOUT, "visible");

    const startTime = Date.now();
    while (Date.now() - startTime < MAX_TEST_TIMEOUT) {
      const disabledAttr = await doneButton.getAttribute("disabled");
      const classAttr = await doneButton.getAttribute("class");

      if (!disabledAttr && !classAttr?.includes("disabled")) {
        break;
      }

      await this.waitForTimeout(POLLING_INTERVAL);
    }

    // Footer overlay/animation settle
    await this.waitForTimeout(1000);
    await doneButton.click();
  }

  public async setPeopleDimensionFolder(dimensionSelection: any) {
    for (const [folderName, selections] of Object.entries(
      dimensionSelection.selections
    )) {
      try {
        const searchIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("searchIcon", DS_COMPONENT_NAME)
        );
        
        if (await searchIcon.isVisible()) {
          await searchIcon.click();
          const searchBArLocator = this.webActionHandler.getWebElement(
            this.resourceManager.getResource("dsSearchBarInput", DS_COMPONENT_NAME)
          );
          await searchBArLocator.waitFor(MAX_TEST_TIMEOUT, "visible");
          await searchBArLocator.enterText("");
          await searchBArLocator.enterText(folderName);
          console.log("Searched for folder:", folderName);
        }
      } catch (error) {
        console.log("Search not available, selecting folder directly");
      }
      const folderElement = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          "peopleDimensionDataSelectionItemLabel",
          folderName,
          DS_COMPONENT_NAME
        )
      );
      await folderElement.waitFor(MAX_TEST_TIMEOUT, "visible");
      await folderElement.click();
      console.log("folder visible");
      await this.setPeopleMadlibSelection(selections);
    }
  }

  public async setPeopleMadlibSelection(selections: any) {
    for (const selection of selections) {

    const searchBArLocator = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("dsSearchBarInput", DS_COMPONENT_NAME)
    );

    if (await searchBArLocator.isVisible()) {
      await searchBArLocator.enterText("");
      await searchBArLocator.enterText(selection);
    }

      const checkBox = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          "checkboxLabel",
          selection,
          DS_COMPONENT_NAME
        )
      );
      await checkBox.waitFor(MAX_TEST_TIMEOUT, "visible");
    await checkBox.click();

    console.log(`Selected: ${selection}`);
  }

  await super.clickWebelement("doneIcon", DS_COMPONENT_NAME);
  await this.waitForTimeout(SMALL_TIMEOUT);
}
  
public async peopleDialogClose() {
    await super.clickWebelement("peopleDialogCancelBtn", DS_COMPONENT_NAME);
  }

  public async enterTextInput(selectorStr: string, value: any) {
    const inputItem = this.webActionHandler.getWebElement({
      elementName: selectorStr,
      selectorType: "tag",
      selectorValue: selectorStr,
    });
    await inputItem.waitFor(MAX_TEST_TIMEOUT, "visible");
    await inputItem.enterText(value);
  }

  //Handles open prompt fact selections
  public async openPromptFactSelection(
    dimensionSelection: {
      selections: Record<string, any>;
    }
  ): Promise<void> {
    // Remove default facts before starting folder selection
    await this.removeDefaultFacts();
   
    for (const [folderName, folderData] of Object.entries(
      dimensionSelection.selections
    )) {
      // 1. Select main folder
      await this.setOpenFactMadlibFolder(folderName);
  
      // 2. Select sub folder (submenu) if exists
      if (folderData.subFolder) {
        await this.setOpenFactSubFolder(folderData.subFolder);
      }
  
      // 3. Select actual values
      const valuesToSelect = folderData.selections || folderData;
      await this.setOpenFactDimensionSelection(valuesToSelect);
    }
  }

  /**
   * Clears fact selection groups that are pre-populated by the report (e.g. the defaults
   * of a blank report) and reopens the navigation so a fresh fact can be added.
   */
  public async removeDefaultFacts(): Promise<void> {
    const selectionGroupHeaders = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("factsSelectionGroupHeader", DS_COMPONENT_NAME)
    );

    const existingGroupCount = await selectionGroupHeaders.getCount();
    if (existingGroupCount === 0) {
      return;
    }

    try {
      await this.removeAllSelections();
      await this.waitForTimeout(SMALL_TIMEOUT);
      await this.clickAddIcon();
    } catch (error) {
      throw new Error(
        `Failed to clear ${existingGroupCount} pre-selected fact group(s) before adding new facts: ${
          error instanceof Error ? error.message : String(error)
        }`
      );
    }
  }

  public async setOpenFactMadlibFolder(folderName: string): Promise<void> {
    try {
      
      await this.selectFolder(folderName);
      console.log(`Folder '${folderName}' successfully selected.`);
    } catch (error) {
      console.error(
        `Failed to select Madlib folder '${folderName}':`,
        error
      );
      throw error;
    }
  }

  public async setOpenFactDimensionSelection(
    selections: string[],
    searchReq = false
  ): Promise<void> {
    try {
      for (const selection of selections) {
        // Wait for the selection viewport to be available in the DOM
        await this.webActionHandler
          .getWebElement(this.resourceManager.getResource("dsSelectionsViewPort", DS_COMPONENT_NAME))
          .waitFor();
          
        // Directly click the checkbox from subfolder dropdown
        const selectionElement = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource(
            "checkboxLabel",
            selection,
            DS_COMPONENT_NAME
          )
        );
        await selectionElement.click();
      }
       
      await this.clickDone();
    } catch (error) {
      console.error(`Error in setOpenFactDimensionSelection:`, error);
      throw new Error(`Failed to set dimension selection: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
   public async setOpenFactSubFolder(subFolderName: string): Promise<void> {
    try {
      // Click the dropdown to open subfolder menu
      const dropdown = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("dsSubFoldersDropdown", DS_COMPONENT_NAME)
      );
      await dropdown.waitFor(MAX_TEST_TIMEOUT, "visible");
      await dropdown.click();
      
      // Click the specific subfolder option that contains the desired text
      const subFolderElement = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          "dsSubFolderOption",
          subFolderName,
          DS_COMPONENT_NAME
        )
      );
      await subFolderElement.waitFor(MAX_TEST_TIMEOUT, "visible");
      await subFolderElement.click();
    } catch (error) {
      console.error(
        `Failed to select Sub Folder '${subFolderName}':`,
        error
      );
      throw error;
    }
  }

   public async openHMLDimensionSelection(
    dimensionSelection: {
      selections: Record<string, any>;
    }
  ): Promise<void> {
   
    for (const [folderName, selections] of Object.entries(
      dimensionSelection.selections
    )) {     
     await this.setOpenHMLDimensionSelection(selections);
    }
  }

  public async setOpenHMLDimensionSelection(
    selections: string[],
    searchReq = false
  ): Promise<void> {
    try {
      for (const selection of selections) {
        if (searchReq) {
          
          await this.clickSearchIcon();
          // Enter the selection text in the search field
          await this.enterTextInSearchField(selection);
        }
        // Wait for the selection viewport to be available in the DOM
        await this.webActionHandler
          .getWebElement(this.resourceManager.getResource("hmlPresetsContainer", DS_COMPONENT_NAME))
          .waitFor();
          const selectionElement = this.webActionHandler.getWebElement(
           this.resourceManager.getDynamicResource(
             "HMLCheckboxLabel",
             selection,
              DS_COMPONENT_NAME
            )
          );
          await selectionElement.click();
        }
        await this.clickDone();
      } catch (error) {
        console.error(`Error in setOpenHMLDimensionSelection:`, error);
        throw new Error(`Failed to set dimension selection in setOpenHMLDimensionSelection: ${error instanceof Error ? error.message : String(error)}`);
      }
  }

 
  /**
   * Gets the current madlib text content for debugging
   * @returns Promise<string> - The current madlib text
   */
  public async getMadlibText(): Promise<string> {
    try {
      const madlibElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("madlibText", DS_COMPONENT_NAME)
      );
      
      await madlibElement.waitFor(10000, "visible");
      const madlibText = await madlibElement.getText();
      console.log("Acutual madlib text in UI:", madlibText)
      return madlibText?.replace(/[\r\n\s]+/g, ' ').trim() || '';
    } catch (error) {
      console.error('Failed to get madlib text:', error);
      return '';
    }
  }

  /**
   * Waits for madlib stability after pivot changes by monitoring text content stability
   * Ensures that madlib changes at least once, otherwise waits full timeout duration
   * @param {number} timeout - Maximum wait time in milliseconds (default: 10 seconds)
   * @param {number} stabilityDuration - Duration to wait for stability in milliseconds (default: 5 seconds)  
   * @returns Promise<void>
   */
  // TODO: This is a workaround solution. In future, implement network call stability monitoring
  // TODO: instead of relying on UI text changes for detecting pivot switch completion
  public async waitForMadlibStability(timeout: number = 2 * SMALL_TIMEOUT, stabilityDuration: number = SMALL_TIMEOUT): Promise<void> {
    const startTime = Date.now();
    let lastMadlibText = '';
    let stableStartTime = 0;
    let hasDetectedChange = false; // Track if madlib has changed at least once
    
    console.log('Waiting for madlib stability after pivot change...');
    
    try {
      while (Date.now() - startTime < timeout) {
        // Get current madlib text
        const currentMadlibText = await this.getMadlibText();
        
        // Check if madlib text has stabilized
        if (currentMadlibText === lastMadlibText && currentMadlibText.length > 0) {
          // Text is stable - but only exit if we've detected at least one change
          if (hasDetectedChange) {
            if (stableStartTime === 0) {
              stableStartTime = Date.now();
            } else if (Date.now() - stableStartTime >= stabilityDuration) {
              console.log('Madlib text has stabilized after pivot change (change detected)');
              return;
            }
          }
          // If no change detected yet, continue waiting
        } else {
          // Text changed - mark that we've detected a change and reset stability timer
          if (lastMadlibText !== '') {
            hasDetectedChange = true;
            console.log('Madlib text change detected after pivot switch');
            console.log('currentMadlibText:', currentMadlibText);
          }
          lastMadlibText = currentMadlibText;
          stableStartTime = 0;
        }
        
        await this.waitForTimeout(POLLING_INTERVAL); // Check every 300ms
      }
      
      if (!hasDetectedChange) {
        console.warn(`No madlib changes detected after pivot switch. Waited full timeout (${timeout}ms). Proceeding anyway...`);
      } else {
        console.warn(`Madlib stability timeout reached (${timeout}ms). Proceeding anyway...`);
      }
    } catch (error) {
      console.warn('Error while waiting for madlib stability:', error);
      // Continue execution even if stability check fails
    }
  }

  /**
   * Helper method to wait for a specified duration
   * @param {number} ms - Milliseconds to wait
   */
  private async waitForTimeout(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Validates madlib text using regex pattern matching with detailed results
   * @param expectedPattern - The regex pattern to match against
   * @returns Promise<{isValid: boolean, actualText: string, expectedPattern: string, errorMessage?: string}> - Detailed validation result
   */
  public async validateMadlibWithPattern(expectedPattern: string): Promise<{
    isValid: boolean;
    actualText: string;
    expectedPattern: string;
    errorMessage?: string;
  }> {
    try {
      const actualText = await this.getMadlibText();
      const regex = new RegExp(expectedPattern, 'i'); // Case insensitive matching
      const isValid = regex.test(actualText);
      
      return {
        isValid,
        actualText,
        expectedPattern,
        errorMessage: isValid ? undefined : `Pattern "${expectedPattern}" did not match actual text: "${actualText}"`
      };
    } catch (error) {
      console.error('Failed to validate madlib with pattern:', error);
      const errorMessage = `Failed to validate madlib with pattern: ${error}`;
      return {
        isValid: false,
        actualText: '',
        expectedPattern,
        errorMessage
      };
    }
  }

  /**
   * Simple boolean validation for backward compatibility
   * @param expectedPattern - The regex pattern to match against
   * @returns Promise<boolean> - Returns true if pattern matches
   */
  public async validateMadlibPattern(expectedPattern: string): Promise<boolean> {
    const result = await this.validateMadlibWithPattern(expectedPattern);
    return result.isValid;
  }

  /**
   * Returns the base page instance.
   * @returns {BasePage} The base page instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }
  public async editSelections(): Promise<void> {
    const editListButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("editListButton", DS_COMPONENT_NAME)
    );
    await editListButton.waitFor();
    await editListButton.click();
  }

  /**
   * Ensure all sub-menus are closed after assertions.
   * Pick one of random menu item which has shouldDisplay: true
   * And click on sub menu which has shouldDisplay: true to close any open sub-menus.
   * @param menuOptions 
   */
  private async ensureAllSubMenusClosed(menuOptions: AssertionMenuOption[]) {
    console.log('Ensuring all sub-menus are closed after assertions...');
    const filteredMenus = menuOptions.filter(menu => menu.shouldDisplay);
    // Here random index is picked to avoid always picking the first menu item
    // If there are more than 2 filtered menus, pick a random one, else pick the last one
    const randomIndex = filteredMenus.length > 2 ? randomInt(0, filteredMenus.length) : filteredMenus.length - 1;
    const menu: AssertionMenuOption = filteredMenus[randomIndex];
    if (menu) {
      const menuSelectorText = PeopleMenu[menu.name].selectorText;
      // Hover on the main menu item
      const menuElement = this.webActionHandler
        .getWebElement(
          this.resourceManager.getDynamicResource(
            menu.subMenu?.length ? "peopleDropdownItemWithSubmenus" : "peopleDropdownItemWithoutSubmenus",
            menuSelectorText,
            DS_COMPONENT_NAME
          )
        );
      await menuElement.hover();
      // Click on sub menu item if exists to close all sub-menus
      if (menu.subMenu && menu.subMenu.length) {
        const subMenu = menu.subMenu.find((menu: AssertionSubMenuOption) => menu.shouldDisplay); // Example, subMenu = { name: "BOUGHT_EACH_OF", shouldDisplay: true }
        if (subMenu && subMenu.name) {
          const subMenuSelector = PeopleMenu[subMenu.name].selectorText; // Example, selectorText = "Bought each of"
          const subMenuElement = this.webActionHandler
            .getWebElement(
              this.resourceManager.getDynamicResource(
                "peopleDropdownItemSubMenuItems",
                subMenuSelector,
                DS_COMPONENT_NAME
              )
            );
          await subMenuElement.click();
        } else {
          throw new Error(`
            Unable to close all submenus for menu ${menu.name}, please check if at least one of submenu set with shouldDisplay: true or check UI menu
          `);
        }
      } else { // No sub-menu to close
        console.log(`No sub-menu to close, clicking on main menu ${menu.name}`);
        await menuElement.click();
      }
    }
  }

    /**
   * Checks if the selection group exists and is visible.
   */
  private async checkSelectionGroupExists(): Promise<void> {
    try {
      const selectionGroup = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("selectionGroups", DS_COMPONENT_NAME)
      );
      const count = await selectionGroup.getCount();

      if (count > 0) {
        console.warn("Selections found. Removing existing selections.");

        const editListButton = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("editListButton", DS_COMPONENT_NAME)
        );

        if (await editListButton.isVisible()) {
          console.info("Edit List button found. Using edit flow.");
          await editListButton.click();
          await this.removeAllSelections();
          await this.clickAddIcon();
          return;
        }
        const removeIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("removeIcon", DS_COMPONENT_NAME)
        );

        if (await removeIcon.isVisible()) {
          console.info("Direct remove selections option found.");
          await removeIcon.click();
          await this.clickAddIcon();
          return;
        }

        console.warn("Selections exist but no supported remove mechanism found.");
      }
       try {
      const factsRemoveIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("factsRemoveIcon", DS_COMPONENT_NAME)
      );

      if (await factsRemoveIcon.isVisible()) {
        await factsRemoveIcon.click();
        await this.clickAddIcon();
      }
    } catch {
      // factsRemoveIcon not present → ignore silently
    }
    } catch (error) {
      console.error("Error while handling existing selections:", error);
      throw new Error("Failed to clear existing selections safely.");
    }
  }
   /**
   * Removes all selection groups by clicking the delete button.
   */
  public async removeAllSelections(): Promise<void> {
    try {
      await super.clickWebelement("panelHeaderMenuBtn", DS_COMPONENT_NAME);
      await super.clickWebelement("deleteAllSelectionsBtn", DS_COMPONENT_NAME);
      await super.clickWebelement("confirmDeleteAllSelectionsBtn", DS_COMPONENT_NAME);
    } catch (error) {
      console.error("Failed to remove all selections:", error);
      throw new Error("Error occurred while removing all selections.");
    }
  }

  /**
   * Configures the Range dimension with specified parameters.
   * @param volumetricType - Type from dropdown. Available options:
   *   - "Avg. Price (Units)" or "Units"
   *   - "Avg. Price (Value)" or "Value"
   *   - "Avg. Price (EQ)"
   *   - "Avg. Price (EQ2)"
   *   - "Avg. Price (EQ3)"
   *   - "Avg. Price (EQ4)"
   * @param minValue - Minimum range value
   * @param maxValue - Maximum range value
   * @param incrementValue - Increment value for the range
   */
  public async configureRange(
    volumetricType: string | undefined,
    minValue: string,
    maxValue: string,
    incrementValue: string,
    splitBasedOn?: string
  ): Promise<void> {
    try {
      // Select volumetric type (optional - not applicable for Frequency pivot)
      if (volumetricType) {
        await super.clickWebelement("rangeVolumetricDropdown", DS_COMPONENT_NAME);
        console.log("Clicked volumetric dropdown");
        const volumetricOption = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource(
            "rangeVolumetricOption",
            volumetricType,
            DS_COMPONENT_NAME
          )
        );
        await volumetricOption.waitFor();
        await volumetricOption.click();
        console.log(`Selected volumetric type: ${volumetricType}`);
      }

      // Optional: Select split based on (for Contribution pivot)
      if (splitBasedOn) {
        await super.clickWebelement("rangeSplitBasedOnDropdown", DS_COMPONENT_NAME);
        console.log("Clicked split based on dropdown");
        const splitBasedOnOption = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource(
            "rangeSplitBasedOnOption",
            splitBasedOn,
            DS_COMPONENT_NAME
          )
        );
        await splitBasedOnOption.waitFor();
        await splitBasedOnOption.click();
        console.log(`Selected split based on: ${splitBasedOn}`);
      }

      // Step 1: Fill in Min value
      const minInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("rangeMinInput", DS_COMPONENT_NAME)
      );
      await minInput.waitFor();
      await minInput.enterText(minValue);
      console.log(`Entered Min value: ${minValue}`);

      // Step 2: Fill in Max value
      const maxInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("rangeMaxInput", DS_COMPONENT_NAME)
      );
      await maxInput.waitFor();
      await maxInput.enterText(maxValue);
      console.log(`Entered Max value: ${maxValue}`);

      // Step 3: Fill in Increment value
      const incrementInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("rangeIncrementInput", DS_COMPONENT_NAME)
      );
      await incrementInput.waitFor();
      await incrementInput.enterText(incrementValue);
      console.log(`Entered Increment value: ${incrementValue}`);

      // Step 4: Click Apply/Done button
      await super.clickWebelement("rangeApplyButton", DS_COMPONENT_NAME);
      console.log("Clicked Apply button to save Range configuration");

      console.log("Range configuration completed successfully");
    } catch (error) {
      console.error("Failed to configure Range dimension:", error);
      throw new Error(`Error configuring Range dimension: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

    /**
* Checks if the selection group exists and is visible.
*/
  public async checkPeopleSelectionGroupExists(): Promise<void> {
    try {
      const selectionGroup = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("selectionGroups", DS_COMPONENT_NAME)
      );
      const count = await selectionGroup.getCount();

      if (count > 0) {
        console.warn("Selections found. Removing existing selections.");

        const removeIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("removeIcon", DS_COMPONENT_NAME)
        );

        if (await removeIcon.isVisible()) {
          console.info("Direct remove selections option found.");
          await removeIcon.click();
          return;
        }

        console.warn("Selections exist but no supported remove mechanism found.");
      }
    } catch (error) {
      console.error("Error while handling existing selections:", error);
      throw new Error("Failed to clear existing selections safely.");
    }
  }
}
