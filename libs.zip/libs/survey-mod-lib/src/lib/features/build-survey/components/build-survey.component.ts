import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  OnDestroy,
  OnInit,
  signal,
  ViewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { SURVEY_FLOW_STEPS } from '../../../core/config/config';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import {
  SURVEY_VALIDATION_STATE,
  SUGGESTION_SEVERITY,
  DimensionKeys,
  GenerateQuestionsRequest,
  GenerateSurveyPayload,
  QuestionModel,
} from '../models/build-survey';
import { ReviewModeService } from '../services/review-mode.service';
import { SurveyService } from '../services/survey.service';
import { ValidationService } from '../services/validation.service';
import { FooterComponent } from './footer/footer.component';
import { OptiqFeedbackComponent } from './optiq-feedback/optiq-feedback.component';
import { PreviewModeComponent } from './preview-mode/preview-mode.component';
import { QuestionGeneratorComponent } from './question-generator/question-generator';
import { QuestionTypeSelectorComponent } from './question-type-selector/question-type-selector.component';
import { ReviewModeComponent } from './review-mode/review-mode.component';
import { SurveyHeaderComponent } from './survey-header/survey-header.component';
import { SurveyPublishPopupComponent } from './survey-publish-popup/survey-publish-popup.component';

@Component({
  selector: 'build-survey',
  imports: [
    CommonModule,
    SurveyHeaderComponent,
    FooterComponent,
    QuestionTypeSelectorComponent,
    PreviewModeComponent,
    QuestionGeneratorComponent,
    ReviewModeComponent,
    SurveyPublishPopupComponent,
    OptiqFeedbackComponent,
  ],
  standalone: true,
  templateUrl: './build-survey.component.html',
  styleUrls: ['./build-survey.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BuildSurveyComponent implements OnInit, OnDestroy {
  questions = signal<QuestionModel[]>([]);
  questionTypes = signal<GenerateQuestionsRequest['questionTypes']>([]);
  readonly isPageLoading = signal(false);
  private readonly destroyRef = inject(DestroyRef);

  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  surveyService = inject(SurveyService);
  private readonly validationService = inject(ValidationService);
  reviewModeService = inject(ReviewModeService);

  surveyCommonService = inject(SurveyCommonService);
  @ViewChild(SurveyPublishPopupComponent) publishPopup?: SurveyPublishPopupComponent;
  readonly publishRequest = signal<boolean>(false);

  isReviewMode = this.reviewModeService.isReviewMode;



  //Survey AI Validation related fields
  readonly surveyAIValidationState = this.validationService.surveyAIValidationState;
  readonly mandatorySuggestionCount = computed(() =>
    this.validationService.countSuggestions(this.surveyService.questions(), SUGGESTION_SEVERITY.MANDATORY)
  );
  readonly optionalSuggestionCount = computed(() =>
    this.validationService.countSuggestions(this.surveyService.questions(), SUGGESTION_SEVERITY.OPTIONAL)
  );
  readonly hasSuggestions = computed(
    () => this.mandatorySuggestionCount() > 0 || this.optionalSuggestionCount() > 0
  );
  readonly isFeedbackPanelOpen = signal(false);
  // The panel stays mounted once validation has completed, whether or not suggestions remain.
  readonly showFeedbackPanel = computed(() => {
    const state = this.surveyAIValidationState();
    return (
      state === SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW ||
      state === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
    );
  });

  constructor() {
    effect(() => {
      this.questions.set(this.surveyService.questions());
      this.questionTypes.set(this.surveyService.questionTypes());

      if (this.surveyService.genState() !== 'loading' &&
          (this.questions().length > 0 || !this.surveyCommonService.flowType().aiflow)) {
        this.surveyService.genState.set(this.questions().length > 0 ? 'done' : 'idle');
      }
    });
  }

  ngOnInit(): void {
    this.surveyCommonService.setActiveSurveyStep(SURVEY_FLOW_STEPS.BUILD_SURVEY);
    this.surveyCommonService.setDatasetFooterVisible(true);
    const surveyId = this.surveyService.getDuplicateFromId()?.trim();
    if (!surveyId) {
      return;
    }

    this.surveyService.genState.set('loading');
    this.surveyService
      .loadSurveyForDuplicate(surveyId)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.surveyService.clearDuplicateFromId();
        }),
      )
      .subscribe({
        next: () => {
          this.surveyService.genState.set('done');
        },
        error: () => {
          this.surveyService.clearSurveyId();
          this.surveyService.clearCurrentAssetId();
          this.surveyService.genState.set('idle');
        },
      });
  }

  /** Preserve survey context when returning so panelist step can restore the same draft journey. */
  goBack() {
    const routeSurveyId = this.route.snapshot.paramMap.get('surveyId')?.trim() ?? '';
    const savedSurveyId = this.surveyService.currentSurveyId?.trim() ?? '';
    const surveyId = routeSurveyId || savedSurveyId;

    const routeCommands = surveyId ? ['select-panelist', surveyId] : ['select-panelist'];

    this.surveyService.clearCurrentAssetId();
    this.surveyService.setSelectedFolder(null);
    void this.router.navigate(routeCommands, { relativeTo: this.route.parent ?? this.route });
  }

  /**
   * Drives generate-question API flow and keeps `genState` transitions in one place
   * so preview/generator components react consistently on success and failure.
   */
  onGenerateQuestions(request: GenerateQuestionsRequest): void {
    const payload = this.buildGenerateSurveyPayload(request);

    this.questionTypes.set(request.questionTypes);
    this.surveyService.setQuestionTypes(request.questionTypes);
    this.surveyService.genState.set('loading');

    this.surveyService.generateQuestions(payload).subscribe({
      next: () => {
        this.surveyService.genState.set('done');
        this.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
      },
      error: () => {
        this.surveyService.genState.set('idle');
        this.validationService.resetValidation();
      },
    });
  }

  /** Payload composition is constrained to first selected labels per dimension to match the AI API contract. */
  private buildGenerateSurveyPayload(request: GenerateQuestionsRequest): GenerateSurveyPayload {
    const promptSelections = this.surveyCommonService.getPanelistDimensionalValue();
    const firstLabel = (dimId: string): string => promptSelections?.[dimId]?.[0] ?? '';

    return {
      prompt: {
        demographic: firstLabel(DimensionKeys.demographic),
        geography: firstLabel(DimensionKeys.geography),
        period: firstLabel(DimensionKeys.period),
        product: firstLabel(DimensionKeys.product),
        questionCount: request.questionCount,
        questionTypes: request.questionTypes,
        retailer: firstLabel(DimensionKeys.retailer),
        userPrompt: this.surveyCommonService.getUserPrompt(),
      },
    };
  }

  publish(): void {
    this.publishRequest.update((request) => !request);
  }

  openPublishConfirmation(): void {
    this.publishPopup?.open();
  }

  onValidateSurvey(): void {
    this.validationService.validateSurvey(this.surveyService.getQuestions()).subscribe({
      next: (response) => {
        this.surveyService.setQuestions(
          this.validationService.normalizeValidatedQuestions(response)
        );
        this.isFeedbackPanelOpen.set(this.hasSuggestions());
      },
      error: () => undefined,
    });
  }

  toggleFeedbackPanel(): void {
    this.isFeedbackPanelOpen.update((open) => !open);
  }

  closeFeedbackPanel(): void {
    this.isFeedbackPanelOpen.set(false);
  }

  ngOnDestroy(): void {
    this.surveyService.genState.set('idle');
    this.validationService.resetValidation();
  }
}
