import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory, closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartWithPromptPage, OMNISHOPPER_OFFERING_DATA_TEST_ID } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { SurveyBuilderPage } from '../../page-objects/common/survey-builder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import {registerEditSurveyTitleTest,registerRequiredStarTest,registerEditQuestionTextTest,registerDeleteDuplicateQuestionTest,registerDragDropTest,registerCancelAddQuestionTest,registerReviewModeTest,registerReviewModeDeleteAllTest,registerEmptyStateTest,registerAddSingleChoiceQuestionTest,registerAddMultipleChoiceQuestionTest,registerAddRatingQuestionTest,registerAddNPSQuestionTest,registerAddPointScaleQuestionTest,registerAddMultiScaleQuestionTest,registerStepperNavigationTest,} from './test-cases/build-survey-test-cases';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Start with a prompt', { tag: '@StartWithPrompt' }, () => {
  let basePage: BasePage;
  let promptPage: StartWithPromptPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'start-with-prompt-video');
    }
  });

  test('Start with a Prompt: Should display the Start with a prompt option on the survey home page', { tag: '@StartWithPrompt' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    promptPage = new StartWithPromptPage(basePage);

    await promptPage.navigateToSurvey();
    await promptPage.clickStartWithPrompt();

    const isVisible = await promptPage.isDatasetTypeSelectorVisible(0);
    assertTrue(isVisible);
  });

  test('Dataset Selection: Should select the dataset type and dataset', { tag: '@DatasetSelection' }, async () => {
    await promptPage.selectDatasetType(OMNISHOPPER_OFFERING_DATA_TEST_ID);

    const isDatasetSelectionConfirmed = await promptPage.searchAndSelectDataset(
      datasetConfig.searchTerm,
      String(DATASET_NAME)
    );
    assertTrue(
      isDatasetSelectionConfirmed,
      `Expected dataset selection to succeed for ${DATASET_NAME}`
    );

    await promptPage.applyDataset();
  });

  test('Panelist Filters: Should set dimension selections and search for panelists', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);
    await selectPanelistPage.clickSearchForPanelists();

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should select a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.click250Responses();
  });

  test('Generate Survey: Should fill the prompt and reach the Build Survey page', { tag: '@GenerateSurvey' }, async () => {
    await promptPage.fillPromptAndGenerate('Generate a few questions about product satisfaction');

    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after generating the survey from a prompt');
  });

  test('TC_AI_04: Should allow selecting multiple question types on the Customize Questions screen', { tag: '@GenerateSurvey' }, async () => {
    const allTypes = ['SINGLE_CHOICE', 'MULTIPLE_CHOICE', 'STAR_RATING', 'NET_PROMOTER_SCORE', 'SINGLE_POINT_SCALE', 'MULTIPLE_POINT_SCALE'];

    for (const value of allTypes) {
      const { selected, outerHtml } = await promptPage.isQuestionTypeSelected(value);
      assertTrue(selected, `Expected "${value}" to be selected by default (outerHtml="${outerHtml}")`);
    }

    for (const value of allTypes) {
      await promptPage.selectQuestionType(value);
      const { selected, outerHtml } = await promptPage.isQuestionTypeSelected(value);
      assertTrue(!selected, `Expected "${value}" to be de-selected after clicking it (outerHtml="${outerHtml}")`);

      await promptPage.selectQuestionType(value);
      const after = await promptPage.isQuestionTypeSelected(value);
      assertTrue(after.selected, `Expected "${value}" to be re-selected after clicking it again (outerHtml="${after.outerHtml}")`);
    }
  });

  test('Generate more questions: Should increase the question count', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.clickGenerateQuestions();
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  registerEditSurveyTitleTest({ getBasePage: () => basePage }, { title: 'TC_AI_07: Edit the survey title after AI generation', tag: '@StartWithPrompt @BuildSurvey' });

  test('Rephrase with AI: Should clear the loading state and prompt after submit', { tag: '@GenerateSurvey' }, async () => {
    await promptPage.rephraseQuestion(0, 'Make this question more concise');
  });

  test('Suggest new questions: Should increase the question count', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.clickSuggestNewQuestions();
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  test('Describe questions to add: Should increase the question count and close the panel', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.describeAndSubmitReprompt('Add a question about delivery speed');
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  test('TC_AI_11/TC_BS_08: Add Question/Duplicate/Generate more/Describe are disabled at 10 (max) questions', { tag: '@StartWithPrompt @BuildSurvey @MaxQuestions' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    const questionCount = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCount === 10, `Expected 10 questions after the Describe-questions step, found ${questionCount}`);

    assertTrue(await surveyBuilderPage.isAddQuestionTooltipVisibleOnHover(), 'Expected max-questions tooltip on Add question hover');
    const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
    assertTrue(addQuestionState.disabled, `Expected Add question disabled at max (outerHtml="${addQuestionState.outerHtml}")`);

    assertTrue(await surveyBuilderPage.isDuplicateTooltipVisibleOnHover(), 'Expected max-questions tooltip on Duplicate hover');
    const duplicateState = await surveyBuilderPage.getDuplicateDisabledState();
    assertTrue(duplicateState.disabled, `Expected Duplicate disabled at max (outerHTML="${duplicateState.outerHtml}")`);

    const questionCountAfter = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCountAfter === 10, `Expected count to stay 10, found ${questionCountAfter}`);

    const generateMoreState = await promptPage.getGenerateMoreQuestionsDisabledState();
    assertTrue(generateMoreState.disabled, `Expected Generate more questions disabled at max (outerHtml="${generateMoreState.outerHtml}")`);

    const describeState = await promptPage.getDescribeQuestionsDisabledState();
    assertTrue(describeState.disabled, `Expected Describe questions to add disabled at max (outerHtml="${describeState.outerHtml}")`);
  });

  registerRequiredStarTest({ getBasePage: () => basePage }, { title: 'TC_BS_07: Required star appears when the Required toggle is on', tag: '@StartWithPrompt @BuildSurvey' });

  registerEditQuestionTextTest({ getBasePage: () => basePage }, { title: 'Edit question: Should update the question text via the pencil icon', tag: '@StartWithPrompt @BuildSurvey' });

  registerDeleteDuplicateQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_06: Delete and duplicate a question via hover row actions', tag: '@StartWithPrompt @BuildSurvey' });

  registerDragDropTest({ getBasePage: () => basePage }, { title: 'TC_BS_15: Drag and drop reorders questions', tag: '@StartWithPrompt @BuildSurvey' });

  registerCancelAddQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_05: Cancelling Add Question leaves the question count unchanged', tag: '@StartWithPrompt @BuildSurvey' });

  registerReviewModeTest({ getBasePage: () => basePage }, { title: 'TC_BS_13/TC_BS_14a: Review Mode controls, delete selected, exit', tag: '@StartWithPrompt @BuildSurvey' });

  test('TC_BS_09: Validate survey is disabled with fewer than 3 questions', { tag: '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.deleteQuestionsDownTo(2);
    const questionCount = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCount === 2, `Expected exactly 2 questions, found ${questionCount}`);

    const publishState = await surveyBuilderPage.getValidateDisabledState();
    assertTrue(
      publishState.disabled,
      `Expected "Review & Publish Survey" disabled with fewer than 3 questions (matchCount=${publishState.matchCount}, innerText="${publishState.innerText}", hostOuterHtml="${publishState.hostOuterHtml}", innerButtonOuterHtml="${publishState.innerButtonOuterHtml}")`
    );
  });

  registerReviewModeDeleteAllTest({ getBasePage: () => basePage }, { title: 'TC_BS_14b: Review Mode select all, delete, stay on Build Survey', tag: '@StartWithPrompt @BuildSurvey' });

  registerEmptyStateTest({ getBasePage: () => basePage }, { title: 'TC_BS_01: Empty Build Survey state shows Add Question options and 0 rows', tag: '@StartWithPrompt @BuildSurvey' });

  registerAddSingleChoiceQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03: Add a Single Choice question', tag: '@StartWithPrompt @BuildSurvey' });
  registerAddMultipleChoiceQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_04: Add a Multiple Choice question', tag: '@StartWithPrompt @BuildSurvey' });
  registerAddRatingQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_05: Add a Rating question', tag: '@StartWithPrompt @BuildSurvey' });
  registerAddNPSQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_07: Add an NPS question', tag: '@StartWithPrompt @BuildSurvey' });
  registerAddPointScaleQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_08: Add a Point Scale question', tag: '@StartWithPrompt @BuildSurvey' });
  registerAddMultiScaleQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_09: Add a Multi Scale question', tag: '@StartWithPrompt @BuildSurvey' });
  registerStepperNavigationTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey', tag: '@StartWithPrompt @BuildSurvey', responseCountTestId: 'select-response-count-250' } // Prompt flow's Response Count step also used click250Responses()
  );
});