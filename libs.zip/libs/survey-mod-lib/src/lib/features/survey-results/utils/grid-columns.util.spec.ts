import { describe, expect, it } from 'vitest';
import { HEAT_GRID_PREVIEW_RESPONSE, NORMAL_GRID_PREVIEW_RESPONSE } from '../constants/survey-results-preview';
import type { ColDef } from 'ag-grid-community';
import { buildGridColumnDefinitions, getGridHeaderRowCount } from './grid-columns.util';

describe('response driven grid', () => {
  it('keeps only the first column locked and out of the visibility checklist', () => {
    const columns = buildGridColumnDefinitions(NORMAL_GRID_PREVIEW_RESPONSE.components[0]) as ColDef[];
    expect(columns[0]).toMatchObject({ lockVisible: true, suppressColumnsToolPanel: true });
    columns.slice(1).forEach(column => {
      expect(column).toMatchObject({ lockVisible: false, suppressColumnsToolPanel: false });
    });
  });
  it.each([
    { enableFilter: true, filter: 'agSetColumnFilter' },
    { enableFilter: false, filter: false },
    { enableFilter: undefined, filter: false },
  ])('uses filter=$filter when enableFilter=$enableFilter', ({ enableFilter, filter }) => {
    const response = structuredClone(NORMAL_GRID_PREVIEW_RESPONSE.components[0]);
    response.tableConfig.defaultColumnProperty = { enableFilter };
    response.tableConfig.columnProperties = {};
    expect(buildGridColumnDefinitions(response)[1]).toMatchObject({ filter });
    response.tableConfig.columnProperties = { x0: { enableFilter: false } };
    expect(buildGridColumnDefinitions(response)[0]).toMatchObject({ filter: false });
  });
  it.each([false, undefined, true])('respects bandedRows=%s and preserves cell style priority', bandedRows => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.tableConfig.bandedRows = bandedRows;
    response.tableConfig.defaultRowProperty = {
      shade: { color: '#ffffff' }, bandedShade: { color: '#e3e3e3' },
    };
    const columns = buildGridColumnDefinitions(response) as ColDef[];
    const labelStyle = columns[0].cellStyle;
    const valueStyle = columns[1].cellStyle;
    if (typeof labelStyle !== 'function' || typeof valueStyle !== 'function') throw new Error('Expected cell style functions');
    const params = { data: response.objects.data[2], node: { rowIndex: 1 } } as Parameters<typeof labelStyle>[0];
    expect(labelStyle(params)).toMatchObject({ backgroundColor: bandedRows ? '#e3e3e3' : '#ffffff' });
    expect(labelStyle({ ...params, node: { rowIndex: 0 } } as Parameters<typeof labelStyle>[0])).toMatchObject({ backgroundColor: '#ffffff' });
    expect(valueStyle(params)).toMatchObject({ backgroundColor: '#0b513e' });
  });
  it('maps backend column keys to matching headers, values, metadata and position settings', () => {
    const response = structuredClone(NORMAL_GRID_PREVIEW_RESPONSE.components[0]);
    response.tableConfig.columnProperties = { x0: { width: 240 }, x1: { width: 160 } };
    response.objects.metadata['col3'].hoverText = 'Backend percentage';
    const columns = buildGridColumnDefinitions(response) as ColDef[];
    expect(columns[0]).toMatchObject({ colId: 'col2', headerName: 'Answer', width: 240, flex: 240 });
    expect(columns[1]).toMatchObject({ colId: 'col3', headerName: 'Percentage', width: 160, flex: 160, headerTooltip: 'Backend percentage' });
    const getValue = columns[1].valueGetter;
    if (typeof getValue !== 'function') throw new Error('Expected dynamic value getter');
    expect(getValue({ data: response.objects.data[1] } as Parameters<typeof getValue>[0])).toBe(42.11);
  });
  it('uses all supplied statement headers', () => {
    expect(getGridHeaderRowCount(HEAT_GRID_PREVIEW_RESPONSE.components[0])).toBe(1);
    expect(buildGridColumnDefinitions(HEAT_GRID_PREVIEW_RESPONSE.components[0]).map(col => col.headerName)).toEqual(['Statement', 'Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree', 'Overall', 'Average Score']);
  });
  it('discovers extra columns and applies only the matching cell style', () => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.objects.data[0]['extra'] = { cellValue: 'Dynamic header' };
    const columns = buildGridColumnDefinitions(response);
    expect(columns.map(col => 'colId' in col ? col.colId : undefined)).toEqual(['col1', 'col2', 'col3', 'col4', 'col5', 'col6', 'col7', 'col8', 'extra']);
    const style = (columns[1] as ColDef).cellStyle;
    if (typeof style !== 'function') throw new Error('Expected dynamic cell style');
    expect(style({ data: response.objects.data[1], node: { rowIndex: 0 } } as Parameters<typeof style>[0])).toMatchObject({ backgroundColor: '#18a477' });
    response.tableConfig.rowProperties = {};
    expect(style({ data: response.objects.data[1], node: { rowIndex: 0 } } as Parameters<typeof style>[0])).toMatchObject({ backgroundColor: '#FDFDFD' });
  });
});

// Exercise grouped responses separately from the single-header API fixture.
describe('grid structure and values', () => {
  it('builds merged header groups without mutating the response', () => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.objects.attributes = { columnHeaderCount: 2 };
    response.tableConfig.numHeaderRows = 2;
    response.objects.data = [
      { name: { cellValue: '' }, a: { cellValue: 'Results', mergeNextCell: true }, b: { cellValue: 'Results' } },
      { name: { cellValue: 'Statement' }, a: { cellValue: 'Agree' }, b: { cellValue: 'Disagree' } },
      { name: { cellValue: 'Statement one' }, a: { cellValue: 12, factType: 'Number' }, b: { cellValue: 8 } },
    ];
    response.objects.metadata = { name: {}, a: { isFact: true }, b: { isFact: true } };
    const original = structuredClone(response);
    const columns = buildGridColumnDefinitions(response);
    expect(columns[0].headerName).toBe('Statement');
    expect(columns[0]).toMatchObject({ lockVisible: true, suppressColumnsToolPanel: true });
    expect(columns[1]).toMatchObject({ headerName: 'Results', children: [{ headerName: 'Agree' }, { headerName: 'Disagree' }] });
    expect(response).toEqual(original);
  });
  it('merges partial dynamic styles with defaults and column configuration', () => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.tableConfig.defaultRowProperty = { textStyle: { bold: true, font: { color: '#123456', size: 14 } } };
    response.tableConfig.columnProperties = { x1: { width: 220, pinnedLeft: true } };
    response.objects.data[1]['col2'].styleId = 'style-unique-for-rule-1';
    response.tableConfig.rowProperties = { 'style-unique-for-rule-1': { shade: { color: '#abcdef' }, textStyle: { bold: false } } };
    const column = buildGridColumnDefinitions(response)[1] as ColDef;
    expect(column).toMatchObject({ width: 220, pinned: 'left' });
    const style = column.cellStyle;
    if (typeof style !== 'function') throw new Error('Expected cell style');
    expect(style({ data: response.objects.data[1], node: { rowIndex: 0 } } as Parameters<typeof style>[0]))
      .toMatchObject({ backgroundColor: '#abcdef', color: '#123456', fontSize: '14px', fontWeight: 'normal' });
  });
  it('uses top-level alignment when configured', () => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.tableConfig.defaultRowProperty = { alignment: 'center' };
    const column = buildGridColumnDefinitions(response)[0] as ColDef;
    if (typeof column.cellStyle !== 'function') throw new Error('Expected cell style');
    expect(column.cellStyle({ data: response.objects.data[1], node: { rowIndex: 0 } } as Parameters<typeof column.cellStyle>[0]))
      .toMatchObject({ textAlign: 'center' });
  });
  it.each([0, '0012', '109.066494', '42.11 %', '$1,234.50', '', null])('preserves the backend cell value %s', value => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.objects.data[1]['col2'].cellValue = value;
    const column = buildGridColumnDefinitions(response)[1] as ColDef;
    if (typeof column.valueGetter !== 'function') throw new Error('Expected value getter');
    const result = column.valueGetter({ data: response.objects.data[1] } as Parameters<typeof column.valueGetter>[0]);
    expect(result).toBe(value);
    expect(column.valueFormatter).toBeUndefined();
  });
  it('supports no headers and numeric header labels', () => {
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.objects.attributes = { columnHeaderCount: 1 };
    response.objects.data[0]['col3'] = { cellValue: 2026 };
    expect(getGridHeaderRowCount(response)).toBe(1);
    response.tableConfig.headerRow = false;
    expect(getGridHeaderRowCount(response)).toBe(0);
    expect(buildGridColumnDefinitions(response)).toHaveLength(8);
  });
});

it('merges only the leading body cell and disables merging after sorting', () => {
  const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
  response.objects.data = [
    { col2: { cellValue: 'Statement' } },
    { col2: { cellValue: 'Same', mergeNextCell: true } },
    { col2: { cellValue: 'Same' } },
  ];
  response.objects.attributes = { columnHeaderCount: 1 };
  const column = buildGridColumnDefinitions(response)[0] as ColDef;
  if (typeof column.rowSpan !== 'function') throw new Error('Expected row span');
  const rows = response.objects.data.slice(1);
  const api = { isAnyFilterPresent: () => false, getColumnState: () => [],
    getDisplayedRowAtIndex: (index: number) => ({ data: rows[index] }) };
  expect(column.rowSpan({ data: rows[0], node: { rowIndex: 0 }, api } as unknown as Parameters<typeof column.rowSpan>[0])).toBe(2);
  expect(column.rowSpan({ data: rows[1], node: { rowIndex: 1 }, api } as unknown as Parameters<typeof column.rowSpan>[0])).toBe(1);
});

it('passes original headers, raw values, and masking reasons to the custom tooltip', () => {
  const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
  response.objects.data[0]['col2'].originalCellValue = 'Full agreement label';
  response.objects.metadata['maskRef'] = { maskReference: [{ maskRefId: 'masked-1', maskReasons: [{ message: 'Sample too small.' }] }] };
  const column = buildGridColumnDefinitions(response)[1] as ColDef;
  expect(column.headerTooltip).toBe('Full agreement label');
  const tooltip = column.tooltipValueGetter;
  if (typeof tooltip !== 'function') throw new Error('Expected tooltip getter');
  const params = { data: response.objects.data[1] } as unknown as Parameters<typeof tooltip>[0];
  expect(tooltip(params)).toEqual({ value: 6 });
  response.objects.data[1]['col2'] = { cellValue: '', cellValueMasked: true, maskRefId: 'masked-1' };
  expect(tooltip(params)).toEqual({ value: '!', masked: true, header: 'Strongly Disagree', message: 'Sample too small.' });
  // Tooltip masking must not alter the displayed backend value.
  if (typeof column.valueGetter !== 'function') throw new Error('Expected value getter');
  expect(column.valueGetter({ data: response.objects.data[1] } as Parameters<typeof column.valueGetter>[0])).toBe('');
});
