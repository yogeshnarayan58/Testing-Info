import { TagComponent } from '@nielseniq/athena-core';
import { SurveyStatusType } from '../../build-survey/models/build-survey';

// athena-core doesn't export TagVariant, so derive it from niq-tag's input.
export type SurveyStatusVariant = ReturnType<TagComponent['variant']>;

export enum ValidationToastType {
  VALIDATION_IN_PROGRESS = 'validationInProgress',
  MANDATORY_CHANGES = 'mandatoryChanges',
  OPTIONAL_CHANGES = 'optionalChanges',
  NO_CHANGES = 'noChanges',
  SURVEY_EDITED = 'surveyEdited',
  ERROR = 'error',
}

export interface SurveyStatusDisplay {
  label: string;
  dateLabel?: string;
  variant: SurveyStatusVariant;
  icon?: string;
}

export const SURVEY_STATUS_DISPLAY: Partial<Record<SurveyStatusType, SurveyStatusDisplay>> = {
  [SurveyStatusType.DRAFT]: { label: 'Draft', dateLabel: 'Created', variant: 'info', icon: 'edit' },
  [SurveyStatusType.PUBLISHED]: { label: 'In progress', dateLabel: 'Published', variant: 'warning', icon: 'refresh' },
  // Not returned by the API yet.
  [SurveyStatusType.CLOSED]: { label: 'Closed', dateLabel: 'Closed', variant: 'success', icon: 'success' },
};

export const SURVEY_ACCESS_AVAILABILITY = {
  OWNED: 'OWNED',
  EDIT: 'EDIT',
  VIEW: 'VIEW',
  STRICT_VIEW: 'STRICTVIEW',
} as const;

export const SHARED_SURVEY_ACCESS_AVAILABILITIES = [
  SURVEY_ACCESS_AVAILABILITY.EDIT,
  SURVEY_ACCESS_AVAILABILITY.VIEW,
  SURVEY_ACCESS_AVAILABILITY.STRICT_VIEW,
] as const;

export const validationToastTime = 10000;