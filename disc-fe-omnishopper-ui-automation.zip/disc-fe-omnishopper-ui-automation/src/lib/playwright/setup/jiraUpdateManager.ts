import { bufferCount, concatMap, forkJoin, from, map, toArray } from 'rxjs';
import type { Observable } from 'rxjs';
import { getExecutionId, getJiraInfo, getHeaders, getJiraUrl } from './jiraConfigurations';
import { request } from '@playwright/test';
import { readRecordedTestResults, RecordedStatus } from './testResultsReader';
import { jiraUpdateData, JiraMapping } from '../../tests/data/jiraUpdateData';
import path from 'path';

interface CandidateTag {
  normalized: string;
  label: string;
}

type MatchResult = { testCaseId: string; candidate: CandidateTag; matchedKey: string };

const REPORT_SUFFIX_PATTERN = /\s*\[(chromium|firefox|webkit)\]$/i;
const REPORT_FILE_SUFFIX_PATTERN = /\.(spec|test)\.[cm]?[jt]sx?$/i;
const REPORT_VARIANT_SUFFIX_PATTERN = /(?:-|_|\s)(retailer|manufacturer|shopper|channel|summary|detail)$/i;

/**
 * Number of Jira execution updates to dispatch in parallel per batch.
 * Kept low (default 5) to avoid hitting Zephyr API rate limits based on
 * production usage patterns. Override via JIRA_BATCH_SIZE env variable if
 * the rate limit policy changes.
 */
const JIRA_BATCH_SIZE = parseInt(process.env.JIRA_BATCH_SIZE ?? '5', 10) || 5;

const mapStatusToExecutionCode = (statusLabel: string): '1' | '2' | '3' => {
  const normalized = statusLabel.toLowerCase();
  if (normalized.includes('pass')) {
    return '1';
  }
  if (normalized.includes('skip')) {
    return '3';
  }
  return '2';
};

function normalizeReportKey(value?: string | null): string {
  return (value ?? '')
    .trim()
    .replace(/[\\/]+/g, '-')
    .replace(REPORT_FILE_SUFFIX_PATTERN, '')
    .replace(REPORT_VARIANT_SUFFIX_PATTERN, '')
    .replace(/[^a-z0-9]+/gi, '')
    .toLowerCase();
}

function getAllTestCases(): JiraMapping {
  return jiraUpdateData;
}

function getReportTestCases(reportName?: string): Record<string, string> {
  const allTestcases = getAllTestCases();
  const reportCandidates = resolveReportNames(reportName);

  for (const resolvedName of reportCandidates) {
    if (allTestcases[resolvedName]) {
      console.log('Reportname:', resolvedName);
      return allTestcases[resolvedName];
    }

    const matchedKey = Object.keys(allTestcases).find(
      key => normalizeReportKey(key) === normalizeReportKey(resolvedName)
    );
    if (matchedKey) {
      console.log('Reportname:', matchedKey);
      return allTestcases[matchedKey];
    }
  }

  console.error(
    `Parent key '${reportCandidates[0] ?? 'UNKNOWN'}' not found in the Jira mapping data.`
  );
  return {};
}

function resolveReportNames(reportName?: string): string[] {
  const candidates = new Set<string>();

  const registerCandidate = (value?: string) => {
    if (!value) {
      return;
    }

    const trimmed = value.trim();
    if (!trimmed) {
      return;
    }

    candidates.add(trimmed);

    const normalizedPath = trimmed.replace(/[\\/]+/g, path.sep);
    const parsedPath = path.parse(normalizedPath);

    if (parsedPath.base) {
      candidates.add(parsedPath.base);
    }

    if (parsedPath.name) {
      candidates.add(parsedPath.name);
      candidates.add(parsedPath.name.replace(REPORT_VARIANT_SUFFIX_PATTERN, ''));
    }

    if (parsedPath.dir) {
      const dirName = path.basename(parsedPath.dir);
      if (dirName) {
        candidates.add(dirName);
      }
    }

    const withoutFileSuffix = trimmed.replace(REPORT_FILE_SUFFIX_PATTERN, '');
    if (withoutFileSuffix !== trimmed) {
      candidates.add(withoutFileSuffix);
      candidates.add(withoutFileSuffix.replace(REPORT_VARIANT_SUFFIX_PATTERN, ''));
    }
  };

  if (reportName && reportName.trim()) {
    registerCandidate(reportName);
  } else {
    const testFilePath = process.env.PLAYWRIGHT_TEST_FILE;
    if (testFilePath) {
      registerCandidate(testFilePath);
      registerCandidate(path.basename(testFilePath));
    }
  }

  return Array.from(candidates);
}

function resolveReportName(reportName?: string): string | undefined {
  return resolveReportNames(reportName)[0];
}

function stripProjectSuffix(title: string): string {
  return title.replace(REPORT_SUFFIX_PATTERN, '').trim();
}

function normalizeCandidate(value?: string | null): string | null {
  if (!value) {
    return null;
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }
  return trimmed.replace(/^@/, '').replace(/\s+/g, '').toLowerCase();
}

function buildCandidateList(tags: string[], fallbackTitle: string): CandidateTag[] {
  const candidateMap = new Map<string, string>();

  const registerCandidate = (value?: string, displayLabel?: string) => {
    const normalized = normalizeCandidate(value);
    if (!normalized) {
      return;
    }
    if (!candidateMap.has(normalized)) {
      candidateMap.set(normalized, displayLabel ?? value!.trim());
    }
  };

  tags.forEach(tag => {
    const formattedTag = tag.startsWith('@') ? tag : `@${tag}`;
    registerCandidate(tag, formattedTag);
  });

  if (fallbackTitle) {
    registerCandidate(fallbackTitle, fallbackTitle);
    if (fallbackTitle.includes(' ')) {
      registerCandidate(fallbackTitle.replace(/\s+/g, '_'), fallbackTitle);
    }
  }

  return Array.from(candidateMap.entries()).map(([normalized, label]) => ({ normalized, label }));
}

function matchCandidates(
  reportCases: Record<string, string>,
  candidates: CandidateTag[]
): MatchResult | null {
  if (!reportCases || !candidates.length) {
    return null;
  }

  for (const candidate of candidates) {
    const matchedKey = Object.keys(reportCases).find(
      key => normalizeCandidate(key) === candidate.normalized
    );
    if (matchedKey) {
      return { testCaseId: reportCases[matchedKey], candidate, matchedKey };
    }
  }
  return null;
}

function logMatch(reportName: string, match: MatchResult) {
  console.log(
    `Mapped Jira TestCaseID for ${match.candidate.label} in '${reportName}' using key '${match.matchedKey}': ${match.testCaseId}`
  );
}

function getIndividualTestCaseID(
  testTitle: string,
  testTags: string[] = [],
  reportName?: string
): string | null {
  const cleanTitle = stripProjectSuffix(testTitle);
  const candidates = buildCandidateList(testTags, cleanTitle);

  const resolvedReportName = resolveReportName(reportName);
  const reportCases = getReportTestCases(resolvedReportName);

  const directMatch = matchCandidates(reportCases, candidates);
  if (directMatch) {
    logMatch(resolvedReportName ?? 'unknown report', directMatch);
    return directMatch.testCaseId;
  }

  console.warn(
    `[JIRA] No mapping found for testcase '${cleanTitle}' in report '${resolvedReportName}'.`
  );
  return null;
}

export type JiraExecutionUpdateResponse = {
  id?: number | string;
  status?: number | string;
  [key: string]: unknown;
};

export async function updateTestStatusInTestCases(
  executionId: string,
  testResult: RecordedStatus
): Promise<JiraExecutionUpdateResponse | undefined> {
  const apicontext = await request.newContext();
  const updateEndPoint = `${getJiraUrl()}/rest/zapi/latest/execution/${executionId}/execute`;
  const status = mapStatusToExecutionCode(testResult);
  const data = { status };
  const response = await apicontext.put(updateEndPoint, { data: data, headers: getHeaders() });
  if (response.ok()) {
    console.log("Testcase status updated in Jira");
    return response.json();
  }
  const errorBody = await response.text();
  console.error(
    `[JIRA] Failed to update testcase status for execution '${executionId}'. ` +
      `HTTP ${response.status()} ${response.statusText()}. Response body: ${errorBody}`
  );
  throw new Error(
    `Failed to update Jira execution '${executionId}': HTTP ${response.status()} ${response.statusText()}`
  );
}

type ExecutionUpdate = {
  exeID: string;
  status: RecordedStatus;
};

type JiraUpdateResponse = Awaited<ReturnType<typeof updateTestStatusInTestCases>>;

const isNonNullable = <T>(value: T | null): value is T => value !== null;

export async function updateJira() {
  await getJiraInfo();
  const allTestResults = await readRecordedTestResults();

  if (allTestResults.length === 0) {
    console.warn('[jiraUpdateManager] No test results found in JSON reporter output; skipping Jira sync.');
    return;
  }

  console.log(`[jiraUpdateManager] Preparing to sync ${allTestResults.length} test results to Jira.`);

  // Resolve all execution IDs first
  const executionUpdates = await Promise.all(
    allTestResults.map(async result => {
      const issueKey = await getIndividualTestCaseID(result.title, result.tags, result.reportName);
      if (!issueKey || issueKey === 'NA') {
        console.warn(
          `[jiraUpdateManager] No Jira mapping found for '${result.title}' (report: ${result.reportName}). Skipping update.`
        );
        return null;
      }

      const exeID = await getExecutionId(issueKey);
      if (!exeID) return null;

      return { exeID, status: result.status };
    }));

  const filteredUpdates: ExecutionUpdate[] = executionUpdates.filter(isNonNullable);
  if (filteredUpdates.length === 0) {
    console.warn('[jiraUpdateManager] No valid Jira execution IDs resolved; skipping Jira sync.');
    return;
  }

  const updateObservables: Observable<JiraUpdateResponse>[] = filteredUpdates
    .map(item => from(updateTestStatusInTestCases(item.exeID, item.status)));

  const subscription = from(updateObservables)
    .pipe(
      bufferCount(JIRA_BATCH_SIZE), // Process updates in parallel batches to avoid Zephyr API rate limits
      concatMap((batch: Observable<JiraUpdateResponse>[]) => forkJoin(batch)), // Wait for all 5 to complete
      toArray(), // Collect all results
      map((results: JiraUpdateResponse[][]) =>
        results.reduce<JiraUpdateResponse[]>((acc, curr) => acc.concat(curr ?? []), [])
      ) // Flatten arrays without relying on Array.flat
    )
    .subscribe({
      next: (result: JiraUpdateResponse[]) => console.log('All update results:', result),
      error: (err: unknown) => console.error('Update failed:', err),
      complete: () => subscription.unsubscribe()
    });
}