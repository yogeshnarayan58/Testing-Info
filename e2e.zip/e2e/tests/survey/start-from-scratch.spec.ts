import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartWithPromptPage } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { SurveyBuilderPage } from '../../page-objects/common/survey-builder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import {registerEditSurveyTitleTest,registerRequiredStarTest,registerEditQuestionTextTest,
  registerDiscardSaveChangesTest,registerCancelAddQuestionTest,registerDragDropTest,
  registerDeleteDuplicateQuestionTest,registerReviewModeTest,registerReviewModeDeleteAllTest,
  registerAddSingleChoiceQuestionTest,registerAddMultipleChoiceQuestionTest,registerAddRatingQuestionTest,
  registerAddNPSQuestionTest,registerAddPointScaleQuestionTest,registerAddMultiScaleQuestionTest,
  registerStepperNavigationTest,registerValidateDisabledUnderThreeTest,registerSaveDraftTest,
  registerValidateSurveyTest,registerOptionBoundaryTest,
  registerDiscardNewQuestionThenSaveTest,registerDeleteLastThenReAddTest,ensureAtLeastOneQuestion,
  registerEmptyQuestionTextBlocksSaveTest,registerSaveDraftEmptyTitleTest,
} from './common-test-cases/build-survey-common-test-cases';
import { registerScratchSetupTests } from './common-test-cases/scratch-setup';

test.describe.serial('Start from scratch', { tag: '@StartFromScratch' }, () => {
  let basePage: BasePage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'start-from-scratch-video');
    }
  });

  registerScratchSetupTests({
    setBasePage: (page) => {
      basePage = page;
    },
    setSelectPanelistPage: (page) => {
      selectPanelistPage = page;
    },
  });

  test(
    'TC_BS_01: First landing shows "Untitled Survey" and the Add question panel',
    { tag: '@EmptyState' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(basePage);

      const titleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
      assertTrue(titleDisplay === 'Untitled Survey', `Expected survey title to be "Untitled Survey", got "${titleDisplay}"`);
      assertTrue(
        await surveyBuilderPage.areAddQuestionOptionsVisible(),
        'Expected Add Question options visible on first landing'
      );
    }
  );

  registerSaveDraftEmptyTitleTest({ getBasePage: () => basePage });

  registerEditSurveyTitleTest({ getBasePage: () => basePage }, { title: 'TC_BS_02: Edit survey title', tag: '@EditSurveyTitle' });

  registerAddSingleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03a: Add a Single Choice question', tag: '@SingleChoiceQuestion' }
  );

  registerAddMultipleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03b: Add a Multiple Choice question', tag: '@MultipleChoiceQuestion' }
  );

  registerAddRatingQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03c: Add a Rating question', tag: '@RatingQuestion' });

  registerAddNPSQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03d: Add an NPS question', tag: '@NPSQuestion' });

  registerAddPointScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03e: Add a Point Scale question', tag: '@PointScaleQuestion' }
  );

  registerAddMultiScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03f: Add a Multi Scale question', tag: '@MultiScaleQuestion' }
  );

  registerRequiredStarTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_07: Required star appears when the Required toggle is on', tag: '@RequiredStar' }
  );

  registerEditQuestionTextTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_25: Edit question text via the pencil icon', tag: '@EditQuestion' }
  );

  registerDiscardSaveChangesTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_26: Discard / Save changes on an existing question', tag: '@DiscardSave' }
  );

  registerEmptyQuestionTextBlocksSaveTest({ getBasePage: () => basePage });

  registerCancelAddQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_05: Cancelling Add Question leaves the question count unchanged', tag: '@CancelAddQuestion' }
  );

  registerDragDropTest({ getBasePage: () => basePage }, { title: 'TC_BS_15: Drag and drop reorders questions', tag: '@DragDrop' });

  registerDeleteDuplicateQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_06: Delete and duplicate a question via hover row actions', tag: '@DeleteDuplicate' }
  );

  registerOptionBoundaryTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_04: Options boundary - min 2, max 15', tag: '@OptionBoundary' }
  );

  registerStepperNavigationTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey', tag: '@StepperNavigation' }
  );

  test('TC_BS_08: Max questions (10) disables Add question and Duplicate with limit message', { tag: '@MaxQuestions' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText: ratingText } = testData.surveyQuestions.rating;

    try {
      let questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      while (questionNumbers.length < 10) {
        const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
        if (addQuestionState.disabled) {
          break;
        }
        await surveyBuilderPage.openAddQuestionPanel();
        await surveyBuilderPage.addRatingQuestion(ratingText);
        questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      }

      assertTrue(questionNumbers.length === 10, `Expected 10 questions, got ${questionNumbers.length}: ${JSON.stringify(questionNumbers)}`);

      assertTrue(await surveyBuilderPage.isAddQuestionTooltipVisibleOnHover(), 'limit message after hover on add');
      const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
      assertTrue(addQuestionState.disabled, `add-question disabled (class="${addQuestionState.classAttr}")`);

      assertTrue(await surveyBuilderPage.isDuplicateTooltipVisibleOnHover(), 'limit message after hover on duplicate');
      const duplicateState = await surveyBuilderPage.getDuplicateDisabledState();
      assertTrue(duplicateState.disabled, `duplicate disabled (outerHTML="${duplicateState.outerHtml}")`);

      const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(questionNumbersAfter.length === 10, 'count stays 10');
    } catch (error) {
      throw new Error(`Failed to verify max-questions limit: ${error instanceof Error ? error.message : error}`);
    }
  });

  registerReviewModeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit', tag: '@ReviewMode' }
  );

  registerSaveDraftTest({ getBasePage: () => basePage }, { title: 'TC_BS_10: Save survey as draft', tag: '@SaveDraft' });

  registerValidateSurveyTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_23: Validate survey: Completes and shows Optiq feedback when there are recommendations', tag: '@ValidateSurvey' }
  );

  test('TC_AI_12: No Optiq-AI action buttons are visible in the Start From Scratch builder', { tag: '@StartFromScratch' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await ensureAtLeastOneQuestion(surveyBuilderPage);

    const promptPage = new StartWithPromptPage(basePage);
    await promptPage.hoverQuestionRow(0);

    assertTrue(
      await promptPage.areAiButtonsHidden(),
      'Expected no rephrase/generate/reprompt AI buttons visible outside the AI-generated flow'
    );
  });

  registerDiscardNewQuestionThenSaveTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_22: Discard a new question via Add Question cancel, then add and save one', tag: '@CancelAddQuestion' }
  );

  registerDeleteLastThenReAddTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_20: Delete the last question then re-add the same type as last', tag: '@DeleteDuplicate' }
  );

  registerReviewModeDeleteAllTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_27: Review Mode select all, delete all, stay on Build Survey', tag: '@ReviewModeDeleteAll' }
  );

  registerValidateDisabledUnderThreeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_09: Validate survey is disabled with fewer than 3 questions', tag: '@ValidateDisabled' }
  );

  test('TC_BS_12: Back button returns to the previous step from the builder', { tag: '@BackButton' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await surveyBuilderPage.clickBackButton();

    const isProceedToSurveyBuilderVisible = await selectPanelistPage.isProceedToSurveyBuilderVisible();
    assertTrue(isProceedToSurveyBuilderVisible, 'Expected Proceed to survey builder button (previous step) visible after clicking Back');

    const currentUrl = await surveyBuilderPage.getCurrentUrl();
    assertTrue(currentUrl.includes('select-panelist'), `Expected URL to contain "select-panelist" after clicking Back, got: ${currentUrl}`);
  });
});
