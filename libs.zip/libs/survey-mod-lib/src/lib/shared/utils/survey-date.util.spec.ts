import { describe, expect, it } from 'vitest';

import { formatSurveyDate } from './survey-date.util';

describe('formatSurveyDate', () => {
  it('returns fallback when value is not a string', () => {
    expect(formatSurveyDate(undefined)).toBe('-');
    expect(formatSurveyDate(null)).toBe('-');
    expect(formatSurveyDate(123)).toBe('-');
  });

  it('returns fallback when value is not a valid date string', () => {
    expect(formatSurveyDate('not-a-date')).toBe('-');
  });

  it('formats valid ISO date string as expected', () => {
    expect(formatSurveyDate('2026-09-22T00:00:00.000Z')).toBe('September 22, 2026');
  });
});
