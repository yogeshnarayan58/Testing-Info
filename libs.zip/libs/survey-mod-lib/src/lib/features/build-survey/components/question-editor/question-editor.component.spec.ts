import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { MAX_SURVEY_QUESTIONS, QuestionTypes } from '../../models/build-survey';
import { SurveyService } from '../../services/survey.service';
import { QuestionEditorComponent } from './question-editor.component';

vi.mock('../../services/survey.service', () => ({
  SurveyService: class {},
}));

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('QuestionEditorComponent', () => {
  let mockTranslateService: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
  });
  const createComponent = (initialType = '') => {
    TestBed.resetTestingModule();
    const surveyService = {
      getQuestions: vi.fn().mockReturnValue([]),
      getQuestionType: vi.fn().mockReturnValue(initialType),
      addQuestion: vi.fn(),
    };

    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: SurveyService, useValue: surveyService },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new QuestionEditorComponent(surveyService as unknown as SurveyService));
    return { component, surveyService };
  };

  it.each([
    QuestionTypes.SingleChoice,
    QuestionTypes.MultipleChoice,
    QuestionTypes.SinglePointScale,
    QuestionTypes.MultiplePointScale,
    QuestionTypes.StarRating,
    QuestionTypes.NetPromoterScore,
    QuestionTypes.Text,
  ])('does not replay an invalid save request when typing completes a %s question', type => {
    const { component, surveyService } = createComponent(type);
    const publishRequest = signal(0);
    component.publishRequest = publishRequest as unknown as typeof component.publishRequest;
    component.selectedType = (() => type) as typeof component.selectedType;
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    TestBed.tick();

    publishRequest.set(1);
    TestBed.tick();
    expect(surveyService.addQuestion).not.toHaveBeenCalled();

    component.question.set('First question');
    component.options.set(['Option 1', 'Option 2']);
    component.rowOptions.set(['Row 1', 'Row 2']);
    component.columnOptions.set(['Column 1', 'Column 2']);
    component.onFormChange();
    TestBed.tick();

    expect(component.isPublishDisable()).toBe(false);
    expect(component.showQuestionEditor).toBe(true);
    expect(surveyService.addQuestion).not.toHaveBeenCalled();

    publishRequest.set(2);
    TestBed.tick();

    expect(surveyService.addQuestion).toHaveBeenCalledTimes(1);
    expect(surveyService.addQuestion).toHaveBeenCalledWith(expect.objectContaining({
      question: 'First question', type,
    }));
    expect(component.showQuestionEditor).toBe(false);
  });

  it('uses the next question number when none is supplied', () => {
    const { component, surveyService } = createComponent();
    surveyService.getQuestions.mockReturnValue([{}, {}]);

    expect(component.displayQuestionNumber()).toBe(3);
  });

  it('prefers provided questionNumber over upcoming question number', () => {
    const { component, surveyService } = createComponent();
    surveyService.getQuestions.mockReturnValue([{}, {}, {}]);
    component.questionNumber = (() => 9) as typeof component.questionNumber;

    expect(component.displayQuestionNumber()).toBe(9);
  });

  it('validates question text and choice options', () => {
    const { component } = createComponent();
    component.selectedType = (() => QuestionTypes.SingleChoice) as typeof component.selectedType;

    expect(component.isPublishDisable()).toBe(true);
    component.question.set('Favourite snack?');
    expect(component.isPublishDisable()).toBe(true);
    component.options.set(['Chips', 'Candy']);
    expect(component.isPublishDisable()).toBe(false);
  });

  it('validates scale options', () => {
    const { component } = createComponent();
    component.selectedType = (() => QuestionTypes.SinglePointScale) as typeof component.selectedType;
    component.question.set('Rate the product');

    expect(component.isPublishDisable()).toBe(true);
    component.rowOptions.set(['Low', 'High']);
    component.columnOptions.set(['Poor', 'Good']);

    expect(component.isPublishDisable()).toBe(false);
  });

  it('emits type-specific preview data', () => {
    const { component } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    component.selectedType = (() => QuestionTypes.NetPromoterScore) as typeof component.selectedType;
    component.question.set('Would you recommend us?');
    const emit = vi.spyOn(component.questionDataChange, 'emit');

    component.onFormChange();

    expect(emit).toHaveBeenCalledWith({
      question: 'Would you recommend us?',
      isRequired: false,
      npsLeftLabel: 'SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND',
      npsRightLabel: 'SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND',
    });
  });

  it('emits choice and scale preview data', () => {
    const choice = createComponent().component;
    choice.isPreviewContext = (() => true) as typeof choice.isPreviewContext;
    choice.selectedType = (() => QuestionTypes.SingleChoice) as typeof choice.selectedType;
    choice.options.set(['Yes', 'No']);
    const choiceEmit = vi.spyOn(choice.questionDataChange, 'emit');
    choice.onFormChange();
    expect(choiceEmit).toHaveBeenLastCalledWith({ question: '', isRequired: false, options: ['Yes', 'No'] });

    const scale = createComponent().component;
    scale.isPreviewContext = (() => true) as typeof scale.isPreviewContext;
    scale.selectedType = (() => QuestionTypes.SinglePointScale) as typeof scale.selectedType;
    scale.rowOptions.set(['Low', 'High']);
    scale.columnOptions.set(['Poor', 'Good']);
    const scaleEmit = vi.spyOn(scale.questionDataChange, 'emit');
    scale.onFormChange();
    expect(scaleEmit).toHaveBeenLastCalledWith({
      question: '',
      isRequired: false,
      rowOptions: ['Low', 'High'],
      columnOptions: ['Poor', 'Good'],
    });
  });

  it('applies preview question data', () => {
    const { component } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    component.questionData = (() => ({
      question: 'Loaded question',
      options: ['A', 'B'],
      rowOptions: ['Low', 'High'],
      columnOptions: ['Poor', 'Good'],
      isRequired: true,
      type: QuestionTypes.SingleChoice,
    })) as typeof component.questionData;

    TestBed.tick();

    expect(component.question()).toBe('Loaded question');
    expect(component.options()).toEqual(['A', 'B']);
    expect(component.isRequired()).toBe(true);
  });

  it('applies question text through reactive preview flow', () => {
    const { component } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    component.questionData = (() => ({
      question: 'Reactive apply',
      options: ['1', '2'],
      rowOptions: ['r1', 'r2'],
      columnOptions: ['c1', 'c2'],
      isRequired: false,
    } as any)) as typeof component.questionData;

    TestBed.tick();

    expect(component.question()).toBe('Reactive apply');
  });

  it('applies preview data defaults for nullish arrays and labels', () => {
    const { component } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    component.questionData = (() => ({
      question: 'Loaded question',
      options: null,
      rowOptions: undefined,
      columnOptions: null,
      isRequired: false,
      npsLeftLabel: undefined,
      npsRightLabel: null,
    } as any)) as typeof component.questionData;

    TestBed.tick();

    expect(component.options()).toEqual([]);
    expect(component.rowOptions()).toEqual([]);
    expect(component.columnOptions()).toEqual([]);
    expect(component.npsLeftLabel()).toBe('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND');
    expect(component.npsRightLabel()).toBe('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND');
  });

  it('directly applies preview question fields through applyQuestionData', () => {
    const { component } = createComponent();
    component.questionData = (() => ({
      question: 'Direct apply',
      options: ['X', 'Y'],
      isRequired: true,
      npsLeftLabel: 'Left',
      npsRightLabel: 'Right',
      rowOptions: ['R1', 'R2'],
      columnOptions: ['C1', 'C2'],
    } as any)) as typeof component.questionData;

    (component as any).applyQuestionData();

    expect(component.question()).toBe('Direct apply');
    expect(component.options()).toEqual(['X', 'Y']);
    expect(component.isRequired()).toBe(true);
    expect(component.npsLeftLabel()).toBe('Left');
    expect(component.npsRightLabel()).toBe('Right');
    expect(component.rowOptions()).toEqual(['R1', 'R2']);
    expect(component.columnOptions()).toEqual(['C1', 'C2']);
  });

  it('returns from applyQuestionData when source is missing', () => {
    const { component } = createComponent();
    component.question.set('unchanged');
    component.questionData = (() => null) as typeof component.questionData;

    (component as any).applyQuestionData();

    expect(component.question()).toBe('unchanged');
  });

  it('sets question signal in applyQuestionData when source is present', () => {
    const { component } = createComponent();
    component.questionData = (() => ({ question: 'Line 98', options: [] } as any)) as typeof component.questionData;

    (component as any).applyQuestionData();

    expect(component.question()).toBe('Line 98');
  });

  it('emits preview payload from onFormChange when in preview context', () => {
    const { component } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Preview emit');
    const emitSpy = vi.spyOn(component.questionDataChange, 'emit');

    component.onFormChange();

    expect(emitSpy).toHaveBeenCalledWith(expect.objectContaining({ question: 'Preview emit' }));
  });

  it('uses readonly mode only in preview context', () => {
    const { component } = createComponent();
    component.mode = (() => 'readonly') as typeof component.mode;

    expect(component.childMode).toBe('edit');
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    expect(component.childMode).toBe('readonly');
  });

  it('keeps publish disabled for invalid scale options with blanks', () => {
    const { component } = createComponent();
    component.selectedType = (() => QuestionTypes.SinglePointScale) as typeof component.selectedType;
    component.question.set('Rate this');
    component.rowOptions.set(['Low', '']);
    component.columnOptions.set(['Poor', 'Good']);

    expect(component.isPublishDisable()).toBe(true);
  });

  it('keeps publish disabled when scale column option is blank', () => {
    const { component } = createComponent();
    component.selectedType = (() => QuestionTypes.SinglePointScale) as typeof component.selectedType;
    component.question.set('Rate this');
    component.rowOptions.set(['Low', 'High']);
    component.columnOptions.set(['Poor', '']);

    expect(component.isPublishDisable()).toBe(true);
  });

  it('enables publish only when every scale column has non-empty trim value', () => {
    const { component } = createComponent();
    component.selectedType = (() => QuestionTypes.SinglePointScale) as typeof component.selectedType;
    component.question.set('Rate this');
    component.rowOptions.set(['Low', 'High']);
    component.columnOptions.set(['Poor', 'Good']);
    expect(component.isPublishDisable()).toBe(false);

    component.columnOptions.set(['Poor', '   ']);
    expect(component.isPublishDisable()).toBe(true);
  });

  it('evaluates hasValidScaleOptions directly for valid and invalid column content', () => {
    const { component } = createComponent();
    component.rowOptions.set(['Low', 'High']);
    component.columnOptions.set(['Col1', 'Col2']);

    expect((component as any).hasValidScaleOptions()).toBe(true);

    component.columnOptions.set(['Col1', '   ']);
    expect((component as any).hasValidScaleOptions()).toBe(false);
  });

  it('handles missing preview data and fallback question types', () => {
    const { component } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;
    component.questionData = (() => null) as typeof component.questionData;
    TestBed.tick();
    expect(component.question()).toBe('');

    const fallback = createComponent(QuestionTypes.Text).component;
    expect(fallback.currentSelectedType()).toBe(QuestionTypes.Text);
  });

  it('uses history.state selectedType when service and input types are empty', () => {
    const originalHistoryState = history.state;
    Object.defineProperty(history, 'state', { value: { selectedType: QuestionTypes.Text }, configurable: true });

    try {
      const { component } = createComponent('');
      component.selectedType = (() => '') as typeof component.selectedType;
      expect(component.currentSelectedType()).toBe(QuestionTypes.Text);
    } finally {
      Object.defineProperty(history, 'state', { value: originalHistoryState, configurable: true });
    }
  });

  it('saves scale and NPS fields with their matching types', () => {
    const scale = createComponent();
    scale.component.question.set('Scale question');
    scale.component.selectedType = (() => QuestionTypes.SinglePointScale) as typeof scale.component.selectedType;
    scale.component.rowOptions.set(['Low', 'High']);
    scale.component.columnOptions.set(['Poor', 'Good']);
    scale.component.saveChanges();
    expect(scale.surveyService.addQuestion).toHaveBeenLastCalledWith(expect.objectContaining({
      rowOptions: ['Low', 'High'],
      columnOptions: ['Poor', 'Good'],
    }));

    const nps = createComponent();
    nps.component.question.set('NPS question');
    nps.component.selectedType = (() => QuestionTypes.NetPromoterScore) as typeof nps.component.selectedType;
    nps.component.saveChanges();
    expect(nps.surveyService.addQuestion).toHaveBeenLastCalledWith(expect.objectContaining({
      npsLeftLabel: 'SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND',
      npsRightLabel: 'SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND',
    }));
  });

  it('ignores preview changes outside preview mode', () => {
    const { component } = createComponent();
    const emit = vi.spyOn(component.questionDataChange, 'emit');
    const updateSpy = vi.spyOn(component, 'updatePublishState');

    component.onFormChange();

    expect(emit).not.toHaveBeenCalled();
    expect(updateSpy).toHaveBeenCalled();
  });

  it('auto-saves a valid question after an outside click', () => {
    vi.useFakeTimers();
    const { component, surveyService } = createComponent();
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Outside click question');
    component.editorContainer = (() => undefined) as typeof component.editorContainer;

    component.onDocumentClick(new MouseEvent('click', { bubbles: true }));
    vi.runAllTimers();

    expect(surveyService.addQuestion).toHaveBeenCalled();
    vi.useRealTimers();
  });

  it('saves a valid question through publish', () => {
    const { component, surveyService } = createComponent();
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Describe the product');

    component.publish();

    expect(surveyService.addQuestion).toHaveBeenCalledWith(expect.objectContaining({
      question: 'Describe the product',
      type: QuestionTypes.Text,
      questionNumber: 1,
    }));
    expect(component.showQuestionEditor).toBe(false);
  });

  it('does not save an invalid question', () => {
    const { component, surveyService } = createComponent();

    component.publish();

    expect(surveyService.addQuestion).not.toHaveBeenCalled();
    expect(component.showQuestionEditor).toBe(true);
  });

  it('closes and resets the editor when the max question limit is reached', () => {
    const { component, surveyService } = createComponent();
    surveyService.getQuestions.mockReturnValue(Array.from({ length: MAX_SURVEY_QUESTIONS }, () => ({})));
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Blocked question');
    component.isRequired.set(true);

    component.saveChanges();

    expect(surveyService.addQuestion).not.toHaveBeenCalled();
    expect(component.showQuestionEditor).toBe(false);
    expect(component.question()).toBe('');
    expect(component.isRequired()).toBe(false);
  });

  it('ignores clicks inside the editor and invalid outside clicks', () => {
    vi.useFakeTimers();
    const inside = createComponent();
    inside.component.editorContainer = (() => ({
      nativeElement: { contains: () => true },
    })) as unknown as typeof inside.component.editorContainer;
    inside.component.onDocumentClick(new MouseEvent('click'));
    expect(inside.surveyService.addQuestion).not.toHaveBeenCalled();

    const invalid = createComponent();
    invalid.component.editorContainer = (() => undefined) as typeof invalid.component.editorContainer;
    invalid.component.onDocumentClick(new MouseEvent('click'));
    vi.runAllTimers();
    expect(invalid.surveyService.addQuestion).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it('ignores clicks from the survey header', () => {
    const { component, surveyService } = createComponent();
    const header = document.createElement('div');
    header.className = 'survey-header';
    document.body.appendChild(header);

    const event = new MouseEvent('click', { bubbles: true });
    Object.defineProperty(event, 'target', { value: header });
    component.onDocumentClick(event);

    expect(surveyService.addQuestion).not.toHaveBeenCalled();
    header.remove();
  });

  it('ignores document clicks in preview mode', () => {
    const { component, surveyService } = createComponent();
    component.isPreviewContext = (() => true) as typeof component.isPreviewContext;

    component.onDocumentClick(new MouseEvent('click'));

    expect(surveyService.addQuestion).not.toHaveBeenCalled();
  });

  it('ignores document clicks while navigating or when editor is hidden', () => {
    vi.useFakeTimers();
    const hidden = createComponent();
    hidden.component.showQuestionEditor = false;
    hidden.component.onDocumentClick(new MouseEvent('click'));
    vi.runAllTimers();
    expect(hidden.surveyService.addQuestion).not.toHaveBeenCalled();

    const navigating = createComponent();
    navigating.component.selectedType = (() => QuestionTypes.Text) as typeof navigating.component.selectedType;
    navigating.component.question.set('Question');
    (navigating.component as any).isNavigatingToPreview = true;
    navigating.component.onDocumentClick(new MouseEvent('click'));
    vi.runAllTimers();
    expect(navigating.surveyService.addQuestion).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it('ignores document click when pending auto-save is already active', () => {
    const { component, surveyService } = createComponent();
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Question');
    (component as any).pendingAutoSave = true;

    component.onDocumentClick(new MouseEvent('click'));

    expect(surveyService.addQuestion).not.toHaveBeenCalled();
  });

  it('handles outside click when event target is not an HTMLElement', () => {
    vi.useFakeTimers();
    const { component, surveyService } = createComponent();
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Text question');
    component.editorContainer = (() => undefined) as typeof component.editorContainer;

    component.onDocumentClick({ target: null } as unknown as MouseEvent);
    vi.runAllTimers();

    expect(surveyService.addQuestion).toHaveBeenCalled();
    vi.useRealTimers();
  });

  it('aborts auto-save inside timeout when editor is hidden after click', () => {
    vi.useFakeTimers();
    const { component, surveyService } = createComponent();
    component.selectedType = (() => QuestionTypes.Text) as typeof component.selectedType;
    component.question.set('Text question');
    component.editorContainer = (() => undefined) as typeof component.editorContainer;

    component.onDocumentClick({ target: null } as unknown as MouseEvent);
    component.showQuestionEditor = false;
    vi.runAllTimers();

    expect(surveyService.addQuestion).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it('exposes a callable updatePublishState no-op', () => {
    const { component } = createComponent();

    expect(() => component.updatePublishState()).not.toThrow();
  });
});
