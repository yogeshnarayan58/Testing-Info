import { CdkDrag, CdkDropList, DragDropModule } from '@angular/cdk/drag-drop';
import { Component, ElementRef, NO_ERRORS_SCHEMA, Pipe, PipeTransform, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { finalize, of, Subject, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { ADD_MORE_QUESTIONS_DEFAULT_COUNT, MAX_SURVEY_QUESTIONS, QuestionModel, QuestionTypes } from '../../models/build-survey';
import { SurveyService } from '../../services/survey.service';
import { ValidationService } from '../../services/validation.service';
import { PreviewModeComponent } from './preview-mode.component';
import previewTemplate from './preview-mode.component.html?raw';

vi.mock('../../services/survey.service', () => ({
  SurveyService: class {},
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  ACAssetManageApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

@Pipe({
  name: 'translate',
  standalone: true,
})
class MockTranslatePipe implements PipeTransform {
  transform(key: any): any {
    return key;
  }
}

const createMockTranslateService = () => {
  const mockSubject = {
    subscribe: () => ({ unsubscribe: () => {} }),
    unsubscribe: () => {},
  };
  return {
    instant: (key: string) => {
      const translations: { [key: string]: string } = {
        'SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND': 'I will definitely not recommend',
        'SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND': 'I will definitely recommend',
      };
      return translations[key] ?? key;
    },
    get: (key: string) => of(key),
    setDefaultLanguage: () => {},
    use: () => of({}),
    onLangChange: mockSubject,
    onTranslationChange: mockSubject,
  };
};

describe('PreviewModeComponent', () => {
  let mockTranslateService: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
    TestBed.overrideComponent(PreviewModeComponent, {
      set: {
        providers: [],
      },
    });
  });
  const question = (overrides: Partial<QuestionModel> = {}): QuestionModel => ({
    question: 'Question',
    options: ['A', 'B'],
    rowOptions: ['Low', 'High'],
    columnOptions: ['Poor', 'Good'],
    isRequired: false,
    type: QuestionTypes.SingleChoice,
    ...overrides,
  });

  const createComponent = (questions: unknown[] = []) => {
    TestBed.resetTestingModule();
    const serviceDelegate = {
      remapIndexAfterDelete(index: number | null, deletedIndex: number): number | null {
        if (index === null) return null;
        if (index === deletedIndex) return null;
        if (index > deletedIndex) return index - 1;
        return index;
      },
      remapIndexAfterReorder(index: number, previousIndex: number, currentIndex: number): number {
        if (index === previousIndex) return currentIndex;
        if (previousIndex < currentIndex && index > previousIndex && index <= currentIndex) return index - 1;
        if (previousIndex > currentIndex && index >= currentIndex && index < previousIndex) return index + 1;
        return index;
      },
      extractRephrasedQuestion(response: unknown) {
        const valuesToCheck: unknown[] = [];
        if (response && typeof response === 'object') {
          const source = response as Record<string, unknown>;
          valuesToCheck.push(source['result']);
          valuesToCheck.push(source['question']);
        }
        valuesToCheck.push(response);
        for (const candidate of valuesToCheck) {
          if (!candidate) continue;
          if (Array.isArray(candidate)) {
            const first = candidate[0];
            if (first && typeof first === 'object') {
              const firstQuestion = first as Record<string, unknown>;
              if (typeof firstQuestion['question'] === 'string') return firstQuestion;
            }
            continue;
          }
          if (typeof candidate === 'object') {
            const questionObj = candidate as Record<string, unknown>;
            if (typeof questionObj['question'] === 'string') return questionObj;
            const nestedQuestion = questionObj['question'];
            if (nestedQuestion && typeof nestedQuestion === 'object') {
              const nested = nestedQuestion as Record<string, unknown>;
              if (typeof nested['question'] === 'string') return nested;
            }
          }
        }
        return null;
      },
      normalizeRephrasedQuestion(response: unknown, currentQuestion: unknown, index: number) {
        const extracted = this.extractRephrasedQuestion(response);
        if (!extracted) return null;
        const nextType = (extracted as any).type ?? (currentQuestion as any)?.type ?? '';
        const normalized: any = {
          questionNumber: (currentQuestion as any)?.questionNumber ?? index + 1,
          type: nextType,
          question: (((extracted as any).question ?? '').trim()),
          isRequired: (extracted as any).isRequired ?? (currentQuestion as any)?.isRequired ?? false,
          options: [],
          rowOptions: [],
          columnOptions: [],
          npsLeftLabel: '',
          npsRightLabel: '',
        };
        if (nextType === QuestionTypes.SingleChoice || nextType === QuestionTypes.MultipleChoice) {
          normalized.options = Array.isArray((extracted as any).options)
            ? (extracted as any).options.map((o: any) => String(o ?? '').trim())
            : ((currentQuestion as any)?.options ?? []);
        }
        if (nextType === QuestionTypes.SinglePointScale || nextType === QuestionTypes.MultiplePointScale) {
          normalized.rowOptions = Array.isArray((extracted as any).rowOptions)
            ? (extracted as any).rowOptions.map((r: any) => String(r ?? '').trim())
            : ((currentQuestion as any)?.rowOptions ?? []);
          normalized.columnOptions = Array.isArray((extracted as any).columnOptions)
            ? (extracted as any).columnOptions.map((c: any) => String(c ?? '').trim())
            : ((currentQuestion as any)?.columnOptions ?? []);
        }
        if (nextType === QuestionTypes.NetPromoterScore) {
          normalized.npsLeftLabel = (typeof (extracted as any).npsLeftLabel === 'string' ? (extracted as any).npsLeftLabel : '').trim();
          normalized.npsRightLabel = (typeof (extracted as any).npsRightLabel === 'string' ? (extracted as any).npsRightLabel : '').trim();
        }
        return normalized;
      },
    };
    const surveyService = {
      questions: signal(questions as QuestionModel[]),
      isEditingQuestion: signal(false),
      getQuestions: vi.fn(() => surveyService.questions()),
      setQuestions: vi.fn((items: QuestionModel[]) => surveyService.questions.set(items)),
      getDraft: vi.fn(),
      saveDraft: vi.fn(),
      clearDraft: vi.fn(),
      remapDraftsAfterReorder: vi.fn(),
      removeQuestion: vi.fn((index: number) =>
        surveyService.questions.update((items: QuestionModel[]) =>
          items
            .filter((_, itemIndex) => itemIndex !== index)
            .map((item, itemIndex) => ({ ...item, questionNumber: itemIndex + 1 }))
        )
      ),
      addQuestion: vi.fn(),
      rephraseQuestions: vi.fn(),
      buildAddMoreQuestionsPayload: vi.fn().mockReturnValue({ prompt: {} }),
      addMoreQuestions: vi.fn(),
      submitAddMoreQuestions: vi.fn(),
      remapIndexAfterDelete: vi.fn().mockImplementation((a: any, b: any) => serviceDelegate.remapIndexAfterDelete(a, b)),
      remapIndexAfterReorder: vi.fn().mockImplementation((a: any, b: any, c: any) => serviceDelegate.remapIndexAfterReorder(a, b, c)),
      extractRephrasedQuestion: vi.fn().mockImplementation((a: any) => serviceDelegate.extractRephrasedQuestion(a)),
      normalizeRephrasedQuestion: vi.fn().mockImplementation((a: any, b: any, c: any) => serviceDelegate.normalizeRephrasedQuestion(a, b, c)),
    };
    const validationService = {
      markQuestionForReview: vi.fn((items: any[], index: number) =>
        items.map((item, itemIndex) =>
          itemIndex === index ? { ...item, reviewRequired: true } : item
        )
      ),
      invalidateSurveyValidation: vi.fn(),
      syncAfterSuggestionChange: vi.fn(),
    };
    const surveyCommonService = {
      getPanelistDimensionalValue: vi.fn().mockReturnValue({ DEMO: ['Adults'] }),
      getUserPrompt: vi.fn().mockReturnValue('Prompt'),
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: SurveyService, useValue: surveyService },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: ValidationService, useValue: validationService },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new PreviewModeComponent(
      surveyService as unknown as SurveyService,
      surveyCommonService as unknown as SurveyCommonService,
      mockTranslateService,
      validationService as unknown as ValidationService,
    ));
    TestBed.tick();
    return { component, surveyService, validationService, surveyCommonService };
  };

  it('returns the current question signal after updates', () => {
    const { surveyService } = createComponent([question()]);
    const updated = [question({ question: 'Updated question' })];

    surveyService.setQuestions(updated);

    expect(surveyService.getQuestions()).toBe(surveyService.questions());
    expect(surveyService.getQuestions()).toEqual(updated);
  });

  it('registers question rows inside the nested drop container and keeps handle clicks out of edit mode', async () => {
    const { surveyService, validationService, surveyCommonService } = createComponent([question(), question({ question: 'Second' })]);
    Object.assign(surveyCommonService, { flowType: signal({ aiflow: false }) });
    TestBed.resetTestingModule();
    const templateConfig = {
      imports: [DragDropModule, MockTranslatePipe],
      schemas: [NO_ERRORS_SCHEMA],
      template: previewTemplate, templateUrl: undefined, styleUrls: [],
      providers: [{ provide: ValidationService, useValue: validationService }],
    };
    TestBed.overrideComponent(PreviewModeComponent, { set: templateConfig });
    await TestBed.compileComponents();
    @Component({ imports: [DragDropModule, MockTranslatePipe], schemas: [NO_ERRORS_SCHEMA], template: '', providers: [] })
    class PreviewTemplateHarness extends PreviewModeComponent {
      constructor() {
        super(
          surveyService as unknown as SurveyService,
          surveyCommonService as unknown as SurveyCommonService,
          mockTranslateService,
          validationService as unknown as ValidationService
        );
      }
    }
    TestBed.overrideComponent(PreviewTemplateHarness, { set: templateConfig });
    TestBed.configureTestingModule({ imports: [PreviewTemplateHarness] });
    const fixture = TestBed.createComponent(PreviewTemplateHarness);
    fixture.detectChanges();
    const dropList = fixture.debugElement.query(By.directive(CdkDropList)).injector.get(CdkDropList);
    const rows = fixture.debugElement.queryAll(By.directive(CdkDrag));
    const scrollContainer = fixture.debugElement.query(By.css('.container'));

    expect(scrollContainer.references['previewContainer']).toBe(scrollContainer.nativeElement);
    expect(dropList.element.nativeElement).toBe(scrollContainer.nativeElement);
    expect(dropList.elementContainerSelector).toBe('.questions-drop-zone');
    expect(dropList.getSortedItems()).toHaveLength(2);
    expect(rows.every(row => row.nativeElement.parentElement.matches('.questions-drop-zone'))).toBe(true);

    rows[0].nativeElement.querySelector('.drag-handle').click();
    expect(fixture.componentInstance.editingIndex).toBeNull();

    rows[0].nativeElement.click();
    expect(fixture.componentInstance.editingIndex).toBe(0);
  });

  it('syncs questions and builds new question defaults', () => {
    const { component, surveyService } = createComponent([question()]);

    expect(component.questions()).toEqual([question()]);
    expect(component.newQuestionDataModel()).toBeNull();

    component.pendingNewType.set(QuestionTypes.SingleChoice);
    expect(component.newQuestionDataModel()).toEqual(expect.objectContaining({
      type: QuestionTypes.SingleChoice,
      options: ['', ''],
      rowOptions: ['', ''],
      columnOptions: ['', ''],
    }));
    expect(surveyService.questions).toBeDefined();
  });

  it('preserves supplied inline editor values', () => {
    const { component } = createComponent();
    component.pendingNewType.set(QuestionTypes.Text);
    component.newQuestionData.set({
      question: 'Inline',
      options: ['A'],
      rowOptions: ['Row'],
      columnOptions: ['Column'],
      isRequired: true,
      npsLeftLabel: 'Left',
      npsRightLabel: 'Right',
    });

    expect(component.newQuestionDataModel()).toEqual(expect.objectContaining({
      question: 'Inline',
      options: ['A'],
      rowOptions: ['Row'],
      columnOptions: ['Column'],
      isRequired: true,
    }));
  });

  it('selects questions and allows selection change', () => {
    const { component, surveyService } = createComponent([question(), question()]);
    component.selectQuestion(0);
    expect(component.editingIndex).toBe(0);

    surveyService.getDraft.mockReturnValue({ question: 'Draft' });
    component.selectQuestion(1);
    expect(component.editingIndex).toBe(1);
    expect(surveyService.setQuestions).toHaveBeenCalledWith([
      expect.objectContaining({ question: 'Draft' }),
      expect.objectContaining({ question: 'Question' }),
    ]);
    expect(surveyService.clearDraft).toHaveBeenCalledWith(0);
  });

  it('can select a new question when the current question has no draft', () => {
    const { component, surveyService } = createComponent([question(), question()]);
    component.editingIndex = 0;
    surveyService.getDraft.mockReturnValue(undefined);

    component.selectQuestion(1);

    expect(component.editingIndex).toBe(1);
    expect(surveyService.clearDraft).toHaveBeenCalledWith(0);
  });

  it('moves to the new question when previous editing index is stale', () => {
    const { component, surveyService } = createComponent([question(), question({ question: 'Second' })]);
    component.editingIndex = 9;
    surveyService.getDraft.mockReturnValue({ question: 'Draft' });

    component.selectQuestion(1);

    expect(component.editingIndex).toBe(1);
    expect(surveyService.clearDraft).toHaveBeenCalledWith(9);
  });

  it('commits a valid draft before switching questions with the edit action', () => {
    const { component, surveyService } = createComponent([question(), question({ question: 'Second' })]);
    component.editingIndex = 0;
    surveyService.getDraft.mockReturnValue({ question: 'Updated first' });

    component.editQuestion(1);

    expect(surveyService.setQuestions).toHaveBeenCalledWith([
      expect.objectContaining({ question: 'Updated first' }),
      expect.objectContaining({ question: 'Second' }),
    ]);
    expect(surveyService.clearDraft).toHaveBeenCalledWith(0);
    expect(component.editingIndex).toBe(1);
  });

  it('changes question types with type-specific fields', () => {
    const { component, surveyService, validationService } = createComponent([
      question({ reviewRequired: false }),
    ]);

    component.changeQuestionType(0, '');
    component.changeQuestionType(0, QuestionTypes.SingleChoice);
    expect(surveyService.setQuestions).not.toHaveBeenCalled();
    expect(validationService.invalidateSurveyValidation).not.toHaveBeenCalled();

    component.changeQuestionType(0, QuestionTypes.NetPromoterScore);
    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      type: QuestionTypes.NetPromoterScore,
      reviewRequired: true,
      options: [],
      npsLeftLabel: 'I will definitely not recommend',
    })]);
    expect(validationService.invalidateSurveyValidation).toHaveBeenCalledOnce();
  });

  it('keeps existing choice options when changing to another choice type', () => {
    const { component, surveyService } = createComponent([
      question({ type: QuestionTypes.Text, options: ['Keep 1', 'Keep 2'] }),
    ]);

    component.changeQuestionType(0, QuestionTypes.MultipleChoice);

    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      type: QuestionTypes.MultipleChoice,
      options: ['Keep 1', 'Keep 2'],
    })]);
  });

  it('changes question type to scale and initializes row/column defaults', () => {
    const { component, surveyService } = createComponent([
      question({ type: QuestionTypes.Text, rowOptions: undefined as any, columnOptions: undefined as any }),
    ]);

    component.changeQuestionType(0, QuestionTypes.SinglePointScale);

    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      type: QuestionTypes.SinglePointScale,
      rowOptions: ['', ''],
      columnOptions: ['', ''],
      options: [],
    })]);
  });

  it('clears draft and updates questions when changing to scale type', () => {
    const { component, surveyService } = createComponent([
      question({ type: QuestionTypes.Text, rowOptions: ['old'], columnOptions: ['old'] }),
    ]);

    component.changeQuestionType(0, QuestionTypes.MultiplePointScale);

    expect(surveyService.clearDraft).toHaveBeenCalledWith(0);
    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      type: QuestionTypes.MultiplePointScale,
      rowOptions: ['old'],
      columnOptions: ['old'],
    })]);
  });

  it('drafts and saves editor data', () => {
    const { component, surveyService } = createComponent([question()]);
    const data = { question: 'Updated', options: ['A', null] } as any;

    component.onQuestionEditorDataChange(0, data);
    expect(surveyService.saveDraft).toHaveBeenCalledWith(0, { question: 'Updated', options: ['A', ''] });
    expect(surveyService.setQuestions).not.toHaveBeenCalled();

    component.onQuestionEditorDataChange(0, { question: 'Updated', options: ['A', 'B'] });
    expect(surveyService.saveDraft).toHaveBeenLastCalledWith(0, { question: 'Updated', options: ['A', 'B'] });
  });

  it('manages hover and rephrase panel state', () => {
    const { component } = createComponent();
    component.setHoveredQuestion(1);
    component.toggleRephrase(1, { stopPropagation: vi.fn() } as unknown as MouseEvent);
    expect(component.rephraseOpenIndex).toBe(1);
    component.onRephrasePromptChange(1, 'Improve it');
    expect(component.rephrasePrompts[1]).toBe('Improve it');
    component.setHoveredQuestion(2);
    expect(component.rephraseOpenIndex).toBe(1);
    component.clearHoveredQuestion();
    expect(component.hoveredQuestionIndex).toBeNull();
  });

  it('validates and saves a new question', () => {
    const { component, surveyService } = createComponent([question()]);
    component.onAddAnotherQuestion(QuestionTypes.Text);
    component.onNewEditorDataChange({ question: 'New question', isRequired: true });
    expect(component.isNewQuestionValid()).toBe(true);

    component.saveNewQuestion();
    expect(surveyService.addQuestion).toHaveBeenCalledWith(expect.objectContaining({
      questionNumber: 2,
      question: 'New question',
      type: QuestionTypes.Text,
      reviewRequired: true,
    }));
    expect(component.pendingNewType()).toBe('');
  });

  it('creates new question payload with all mapped fields before addQuestion', () => {
    const { component, surveyService } = createComponent([question()]);
    component.onAddAnotherQuestion(QuestionTypes.NetPromoterScore);
    component.onNewEditorDataChange({
      question: 'Would you recommend us?',
      isRequired: true,
      npsLeftLabel: 'No',
      npsRightLabel: 'Yes',
      rowOptions: ['r1'],
      columnOptions: ['c1'],
    });

    component.saveNewQuestion();

    expect(surveyService.addQuestion).toHaveBeenCalledWith(expect.objectContaining({
      questionNumber: 2,
      type: QuestionTypes.NetPromoterScore,
      question: 'Would you recommend us?',
      isRequired: true,
      npsLeftLabel: 'No',
      npsRightLabel: 'Yes',
      rowOptions: ['r1'],
      columnOptions: ['c1'],
    }));
  });

  it('uses empty string when new question text is nullish and validation is forced true', () => {
    const { component, surveyService } = createComponent([question()]);
    component.pendingNewType.set(QuestionTypes.Text);
    component.newQuestionData.set({ options: ['A', 'B'] } as any);
    component.isNewQuestionValid = (() => true) as typeof component.isNewQuestionValid;

    component.saveNewQuestion();

    expect(surveyService.addQuestion).toHaveBeenCalledWith(expect.objectContaining({
      question: '',
      options: ['A', 'B'],
    }));
  });

  it('preserves invalid new question drafts', () => {
    const { component, surveyService } = createComponent();
    component.saveNewQuestion();
    expect(surveyService.addQuestion).not.toHaveBeenCalled();

    component.onAddAnotherQuestion(QuestionTypes.SingleChoice);
    component.onNewEditorDataChange({ question: 'Choice', options: ['Only'] });
    component.saveNewQuestion();
    expect(component.pendingNewType()).toBe(QuestionTypes.SingleChoice);
    expect(component.newQuestionData()).toEqual({ question: 'Choice', options: ['Only'] });
  });

  it('deletes and copies questions while remapping indexes', () => {
    const { component, surveyService, validationService } = createComponent([question(), question({ question: 'Second' })]);
    component.editingIndex = 1;
    component.rephrasePrompts = { 0: 'First', 1: 'Second' };
    component.rephraseOpenIndex = 1;

    component.deleteQuestion(0);
    expect(surveyService.removeQuestion).toHaveBeenCalledWith(0);
    expect(validationService.syncAfterSuggestionChange).toHaveBeenCalledExactlyOnceWith([
      question({ question: 'Second', questionNumber: 1 }),
    ]);
    expect(component.editingIndex).toBe(0);
    expect(component.rephrasePrompts).toEqual({ 0: 'Second' });

    component.copyQuestion(0);
    expect(surveyService.setQuestions).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({ question: 'Second' }),
    ]));
  });

  it('copies a question with nullish NPS labels into empty strings', () => {
    const { component, surveyService } = createComponent([
      question({ type: QuestionTypes.NetPromoterScore, npsLeftLabel: undefined as any, npsRightLabel: undefined as any }),
    ]);

    component.copyQuestion(0);

    expect(surveyService.setQuestions).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        npsLeftLabel: '',
        npsRightLabel: '',
      }),
    ]));
  });

  it('marks a copy for review without changing the validated source question', () => {
    const source = question({ reviewRequired: false });
    const { component, surveyService, validationService } = createComponent([source]);

    component.copyQuestion(0);

    expect(surveyService.questions()).toEqual([
      source,
      expect.objectContaining({ question: source.question, reviewRequired: true }),
    ]);
    expect(source.reviewRequired).toBe(false);
    expect(validationService.invalidateSurveyValidation).toHaveBeenCalledOnce();
  });

  it('copies a question with undefined option arrays and undefined required flag', () => {
    const { component, surveyService } = createComponent([
      question({
        options: undefined as any,
        rowOptions: undefined as any,
        columnOptions: undefined as any,
        isRequired: undefined as any,
      }),
    ]);

    component.copyQuestion(0);

    expect(surveyService.setQuestions).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        options: [],
        rowOptions: [],
        columnOptions: [],
        isRequired: false,
      }),
    ]));
  });

  it('rephrases and normalizes a question response', () => {
    const { component, surveyService } = createComponent([question()]);
    component.rephrasePrompts[0] = ' Improve ';
    surveyService.rephraseQuestions.mockReturnValue(of({ result: [{ question: ' Rephrased ', type: QuestionTypes.Text }] }));

    component.rephraseQuestion(0);

    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      question: 'Rephrased',
      type: QuestionTypes.Text,
    })]);
    expect(component.rephraseLoadingIndex).toBeNull();
    expect(component.rephraseOpenIndex).toBeNull();
  });

  it('ignores unavailable or already-loading rephrase requests', () => {
    const { component, surveyService } = createComponent();
    component.rephraseQuestion(0);
    expect(surveyService.rephraseQuestions).not.toHaveBeenCalled();

    component.rephraseLoadingIndex = 1;
    component.rephraseQuestion(1);
    expect(surveyService.rephraseQuestions).not.toHaveBeenCalled();
  });

  it('suggests questions and resets loading', () => {
    const { component, surveyService } = createComponent();
    surveyService.addMoreQuestions.mockReturnValue(of({ result: [] }));
    const event = { stopPropagation: vi.fn() } as unknown as MouseEvent;

    component.suggestNewQuestions(event);

    expect(event.stopPropagation).toHaveBeenCalled();
    expect(surveyService.buildAddMoreQuestionsPayload).toHaveBeenCalled();
    expect(component.suggestNewQuestionsLoading()).toBe(false);
  });

  it('clamps suggested question count to remaining capacity', () => {
    const existingQuestions = Array.from({ length: MAX_SURVEY_QUESTIONS - 1 }, (_, index) => question({ question: `Question ${index + 1}` }));
    const { component, surveyService } = createComponent(existingQuestions);
    surveyService.addMoreQuestions.mockReturnValue(of({ result: [] }));

    component.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);

    expect(surveyService.buildAddMoreQuestionsPayload).toHaveBeenCalledWith('Prompt', [], { DEMO: ['Adults'] }, 1);
    expect(surveyService.addMoreQuestions).toHaveBeenCalled();
  });

  it('does not suggest questions when no capacity remains', () => {
    const existingQuestions = Array.from({ length: MAX_SURVEY_QUESTIONS }, (_, index) => question({ question: `Question ${index + 1}` }));
    const { component, surveyService } = createComponent(existingQuestions);

    component.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);

    expect(surveyService.buildAddMoreQuestionsPayload).not.toHaveBeenCalled();
    expect(surveyService.addMoreQuestions).not.toHaveBeenCalled();
  });

  it('toggles and submits the reprompt panel', () => {
    const { component, surveyService } = createComponent();
    component.toggleRepromptPanel();
    expect(component.showRepromptPanel()).toBe(true);
    component.repromptPrompt.set('  Add more  ');
    surveyService.submitAddMoreQuestions.mockReturnValue(of({ result: [] }));

    component.submitReprompt();

    expect(surveyService.submitAddMoreQuestions).toHaveBeenCalledWith('Add more', [], { DEMO: ['Adults'] }, ADD_MORE_QUESTIONS_DEFAULT_COUNT);
    expect(component.showRepromptPanel()).toBe(false);
    expect(component.repromptPrompt()).toBe('');
  });

  it.each([
    ['suggest new questions', [], false],
    ['suggest new questions', [question()], true],
    ['reprompt', [], false],
    ['reprompt', [question()], true],
  ] as const)('with %s returning %j, revalidation is requested: %s', (flow, result, requested) => {
    const { component, surveyService, validationService } = createComponent();
    if (flow === 'reprompt') {
      component.repromptPrompt.set('Add more');
      surveyService.submitAddMoreQuestions.mockReturnValue(of({ result }));
      component.submitReprompt();
      expect(component.showRepromptPanel()).toBe(false);
      expect(component.repromptPrompt()).toBe('');
    } else {
      surveyService.addMoreQuestions.mockReturnValue(of({ result }));
      component.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);
    }

    expect(validationService.invalidateSurveyValidation).toHaveBeenCalledTimes(requested ? 1 : 0);
  });

  const createRepromptFixture = async (
    scrollIntoView: HTMLElement['scrollIntoView'],
    scrollTo: HTMLElement['scrollTo'] = vi.fn<(options?: ScrollToOptions | number, y?: number) => void>(),
  ) => {
    const { surveyService, surveyCommonService, validationService } = createComponent();
    TestBed.resetTestingModule();
    TestBed.overrideComponent(PreviewModeComponent, {
      set: { template: '', templateUrl: undefined, styleUrls: [] },
    });
    await TestBed.compileComponents();
    @Component({
      template: `
        <button (click)="toggleRepromptPanel()">Describe</button>
        <div #previewContainer data-test-id="preview-container">
        <div class="questions-drop-zone">
          @for (question of questions(); track $index) {
            <div class="question-row" data-test-id="question-row">{{ question.question }}</div>
          }
        </div>
        <div data-test-id="add-actions-row"></div>
        @if (showRepromptPanel()) {
          <div #repromptActionsPanel data-test-id="reprompt-actions-panel">
            <textarea></textarea>
          </div>
        }
        </div>
      `,
    })
    class RepromptTemplateHarness extends PreviewModeComponent {
      constructor() {
        super(
          surveyService as unknown as SurveyService,
          surveyCommonService as unknown as SurveyCommonService,
          mockTranslateService,
          validationService as unknown as ValidationService,
        );
      }
    }
    TestBed.configureTestingModule({ imports: [RepromptTemplateHarness] });
    await TestBed.compileComponents();
    const fixture = TestBed.createComponent(RepromptTemplateHarness);
    // Vitest does not run Angular's compiler transform for signal queries.
    Object.defineProperty(fixture.componentInstance, 'repromptActionsPanel', {
      value: () => {
        const host = (fixture.nativeElement as HTMLElement).querySelector<HTMLElement>('[data-test-id="reprompt-actions-panel"]');
        if (host) host.scrollIntoView = scrollIntoView;
        return host ? new ElementRef(host) : undefined;
      },
    });
    Object.defineProperty(fixture.componentInstance, 'previewContainer', {
      value: () => {
        const row = (fixture.nativeElement as HTMLElement).querySelector<HTMLElement>('[data-test-id="preview-container"]');
        if (row) {
          row.scrollTo = scrollTo;
          row.querySelectorAll<HTMLElement>('.questions-drop-zone > .question-row').forEach(questionRow => {
            questionRow.scrollIntoView = scrollIntoView;
          });
        }
        return row ? new ElementRef(row) : undefined;
      },
    });
    fixture.detectChanges();
    return fixture;
  };

  it('scrolls the first generated row only after generated questions render', async () => {
    const scrollTo = vi.fn<(options?: ScrollToOptions | number, y?: number) => void>();
    const scrollIntoView = vi.fn();
    const fixture = await createRepromptFixture(scrollIntoView, scrollTo);
    const service = fixture.componentInstance.surveyService;
    const container = fixture.nativeElement.querySelector('[data-test-id="preview-container"]');
    Object.defineProperty(container, 'scrollHeight', { value: 1500 });
    Object.defineProperty(container, 'clientHeight', { value: 500 });
    const existing = question();
    const generated = [question({ question: 'New first' }), question({ question: 'New second' })];
    service.setQuestions([existing]);
    fixture.detectChanges();
    TestBed.tick();
    const response = new Subject<{ result: typeof generated }>();
    vi.spyOn(service, 'addMoreQuestions').mockReturnValue(response);

    fixture.componentInstance.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);
    fixture.detectChanges();
    TestBed.tick();
    expect(scrollTo).not.toHaveBeenCalled();
    expect(scrollIntoView).not.toHaveBeenCalled();

    service.setQuestions([existing, ...generated]);
    response.next({ result: generated });
    expect(scrollTo).not.toHaveBeenCalled();
    expect(scrollIntoView).not.toHaveBeenCalled();
    fixture.detectChanges();
    TestBed.tick();

    const rows = fixture.nativeElement.querySelectorAll('.questions-drop-zone > .question-row');
    expect(scrollTo).not.toHaveBeenCalled();
    expect(scrollIntoView).toHaveBeenCalledExactlyOnceWith({ block: 'start', behavior: 'auto' });
    expect(rows).toHaveLength(3);
    expect(scrollIntoView.mock.contexts[0]).toBe(rows[1]);
    response.complete();
    expect(fixture.componentInstance.suggestNewQuestionsLoading()).toBe(false);
  });

  it('falls back to the container bottom when the generated row cannot be found', async () => {
    const scrollTo = vi.fn<(options?: ScrollToOptions | number, y?: number) => void>();
    const scrollIntoView = vi.fn();
    const fixture = await createRepromptFixture(scrollIntoView, scrollTo);
    const service = fixture.componentInstance.surveyService;
    const generated = [question({ question: 'New question' })];
    service.setQuestions(generated);
    fixture.detectChanges();
    TestBed.tick();
    const container = fixture.nativeElement.querySelector('[data-test-id="preview-container"]');
    Object.defineProperty(container, 'scrollHeight', { value: 1500 });
    vi.spyOn(container, 'querySelectorAll').mockReturnValue([]);
    vi.spyOn(service, 'addMoreQuestions').mockReturnValue(of({ result: generated }));

    fixture.componentInstance.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);
    fixture.detectChanges();
    TestBed.tick();

    expect(scrollTo).toHaveBeenCalledExactlyOnceWith({ top: 1500, behavior: 'auto' });
    expect(scrollTo.mock.contexts[0]).toBe(container);
    expect(scrollIntoView).not.toHaveBeenCalled();
  });

  it('unsubscribes pending generation on destruction without scheduling scrolling', async () => {
    const scrollTo = vi.fn<(options?: ScrollToOptions | number, y?: number) => void>();
    const scrollIntoView = vi.fn();
    const fixture = await createRepromptFixture(scrollIntoView, scrollTo);
    const service = fixture.componentInstance.surveyService;
    const generated = [question({ question: 'New question' })];
    const response = new Subject<{ result: typeof generated }>();
    const unsubscribe = vi.fn();
    vi.spyOn(service, 'addMoreQuestions').mockReturnValue(response.pipe(finalize(unsubscribe)));
    const invalidate = vi.spyOn(fixture.componentInstance['validationService'], 'invalidateSurveyValidation');

    fixture.componentInstance.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);
    expect(fixture.componentInstance.suggestNewQuestionsLoading()).toBe(true);
    expect(unsubscribe).not.toHaveBeenCalled();

    fixture.destroy();
    expect(unsubscribe).toHaveBeenCalledExactlyOnceWith();
    expect(fixture.componentInstance.suggestNewQuestionsLoading()).toBe(false);
    response.next({ result: generated });
    response.complete();
    TestBed.tick();

    expect(invalidate).not.toHaveBeenCalled();
    expect(scrollIntoView).not.toHaveBeenCalled();
    expect(scrollTo).not.toHaveBeenCalled();
  });

  it('cancels pending rephrasing on destruction without updating questions', async () => {
    const fixture = await createRepromptFixture(vi.fn());
    const component = fixture.componentInstance;
    const service = component.surveyService;
    service.setQuestions([question()]);
    const response = new Subject<{ result: QuestionModel }>();
    const unsubscribe = vi.fn();
    vi.spyOn(service, 'rephraseQuestions').mockReturnValue(response.pipe(finalize(unsubscribe)));
    const setQuestions = vi.spyOn(service, 'setQuestions').mockClear();
    const invalidate = vi.spyOn(component['validationService'], 'invalidateSurveyValidation');
    component.rephrasePrompts[0] = 'Make it shorter';
    component.rephraseQuestion(0);
    expect(component.rephraseLoadingIndex).toBe(0);
    expect(unsubscribe).not.toHaveBeenCalled();

    fixture.destroy();
    response.next({ result: question({ question: 'Late rephrase' }) });
    response.complete();

    expect(unsubscribe).toHaveBeenCalledExactlyOnceWith();
    expect(component.rephraseLoadingIndex).toBeNull();
    expect(component.rephrasePrompts[0]).toBe('Make it shorter');
    expect(setQuestions).not.toHaveBeenCalled();
    expect(invalidate).not.toHaveBeenCalled();
  });

  it('cancels pending reprompt on destruction without clearing its state', async () => {
    const fixture = await createRepromptFixture(vi.fn());
    const component = fixture.componentInstance;
    const response = new Subject<{ result: [] }>();
    const unsubscribe = vi.fn();
    vi.spyOn(component.surveyService, 'submitAddMoreQuestions').mockReturnValue(response.pipe(finalize(unsubscribe)));
    const invalidate = vi.spyOn(component['validationService'], 'invalidateSurveyValidation');
    component.showRepromptPanel.set(true);
    component.repromptPrompt.set('Add follow-up questions');
    component.submitReprompt();
    expect(unsubscribe).not.toHaveBeenCalled();

    fixture.destroy();
    response.next({ result: [] });
    response.complete();

    expect(unsubscribe).toHaveBeenCalledExactlyOnceWith();
    expect(component.repromptPrompt()).toBe('Add follow-up questions');
    expect(component.showRepromptPanel()).toBe(true);
    expect(invalidate).not.toHaveBeenCalled();
  });

  it.each(['', 'New question'])('does not process a deferred outside click after destruction (%j)', async text => {
    const fixture = await createRepromptFixture(vi.fn());
    const component = fixture.componentInstance;
    component.onAddAnotherQuestion(QuestionTypes.Text);
    component.onNewEditorDataChange({ question: text });
    const save = vi.spyOn(component, 'saveNewQuestion');
    const cancel = vi.spyOn(component, 'cancelNewQuestion');

    component.closeOnOutsideClick(new MouseEvent('click'));
    fixture.destroy();
    await Promise.resolve();

    expect(save).not.toHaveBeenCalled();
    expect(cancel).not.toHaveBeenCalled();
  });

  it('reports malformed generation rejected by the service without invalidating the survey', () => {
    const { component, surveyService, validationService } = createComponent();
    const errorLog = vi.spyOn(console, 'error').mockImplementation(() => {});
    const error = new Error('Invalid response while adding more questions: result must be an array');
    surveyService.addMoreQuestions.mockReturnValue(throwError(() => error));

    expect(() => component.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent)).not.toThrow();

    expect(errorLog).toHaveBeenCalledExactlyOnceWith('Error adding more questions:', error);
    expect(validationService.invalidateSurveyValidation).not.toHaveBeenCalled();
    expect(component.suggestNewQuestionsLoading()).toBe(false);
  });

  it.each(['empty', 'error'])('does not scroll when generation returns %s', async outcome => {
    const scrollTo = vi.fn<(options?: ScrollToOptions | number, y?: number) => void>();
    const fixture = await createRepromptFixture(vi.fn(), scrollTo);
    const errorLog = vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.spyOn(fixture.componentInstance.surveyService, 'addMoreQuestions').mockReturnValue(
      outcome === 'empty' ? of({ result: [] }) : throwError(() => new Error('Generation failed')),
    );

    fixture.componentInstance.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);
    fixture.detectChanges();
    TestBed.tick();

    expect(scrollTo).not.toHaveBeenCalled();
    expect(fixture.componentInstance.suggestNewQuestionsLoading()).toBe(false);
    if (outcome === 'error') expect(errorLog).toHaveBeenCalledWith('Error adding more questions:', expect.any(Error));
  });

  it.each([false, true, undefined])('scrolls the rendered prompt panel respecting reduced motion (%s)', async (reduceMotion) => {
    const matchMedia = vi.fn().mockReturnValue({ matches: reduceMotion });
    vi.stubGlobal('matchMedia', reduceMotion === undefined ? undefined : matchMedia);
    const scrollIntoView = vi.fn();
    try {
      const fixture = await createRepromptFixture(scrollIntoView);
      const describeButton = fixture.nativeElement.querySelector('button');
      expect(fixture.nativeElement.querySelector('[data-test-id="reprompt-actions-panel"]')).toBeNull();
      expect(scrollIntoView).not.toHaveBeenCalled();

      describeButton.click();
      expect(scrollIntoView).not.toHaveBeenCalled();
      fixture.detectChanges();
      TestBed.tick();

      const panel = fixture.nativeElement.querySelector('[data-test-id="reprompt-actions-panel"]');
      expect(panel).not.toBeNull();
      expect(panel.querySelector('textarea')).not.toBeNull();
      if (reduceMotion !== undefined) {
        expect(matchMedia).toHaveBeenCalledWith('(prefers-reduced-motion: reduce)');
      }
      expect(scrollIntoView).toHaveBeenCalledExactlyOnceWith({
        block: 'nearest', behavior: reduceMotion === false ? 'smooth' : 'auto',
      });
      expect(scrollIntoView.mock.contexts[0]).toBe(panel);

      describeButton.click();
      fixture.detectChanges();
      TestBed.tick();
      expect(fixture.nativeElement.querySelector('[data-test-id="reprompt-actions-panel"]')).toBeNull();
      expect(scrollIntoView).toHaveBeenCalledTimes(1);
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('uses instant scrolling when the document has no browser window', async () => {
    const scrollIntoView = vi.fn();
    const fixture = await createRepromptFixture(scrollIntoView);
    const defaultView = vi.spyOn(document, 'defaultView', 'get').mockReturnValue(null);
    try {
      fixture.componentInstance.toggleRepromptPanel();
      fixture.detectChanges();
      TestBed.tick();

      expect(scrollIntoView).toHaveBeenCalledExactlyOnceWith({ block: 'nearest', behavior: 'auto' });
    } finally {
      defaultView.mockRestore();
    }
  });

  it('does not scroll when the prompt panel closes before the next render', async () => {
    vi.stubGlobal('matchMedia', vi.fn());
    const scrollIntoView = vi.fn();
    try {
      const fixture = await createRepromptFixture(scrollIntoView);
      fixture.componentInstance.toggleRepromptPanel();
      fixture.componentInstance.toggleRepromptPanel();
      fixture.detectChanges();
      TestBed.tick();

      expect(fixture.nativeElement.querySelector('[data-test-id="reprompt-actions-panel"]')).toBeNull();
      expect(scrollIntoView).not.toHaveBeenCalled();
      expect(window.matchMedia).not.toHaveBeenCalled();
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('clamps reprompt question count to remaining capacity', () => {
    const existingQuestions = Array.from({ length: MAX_SURVEY_QUESTIONS - 2 }, (_, index) => question({ question: `Question ${index + 1}` }));
    const { component, surveyService } = createComponent(existingQuestions);
    component.repromptPrompt.set('Prompt');
    surveyService.submitAddMoreQuestions.mockReturnValue(of({ result: [] }));

    component.submitReprompt();

    expect(surveyService.submitAddMoreQuestions).toHaveBeenCalledWith('Prompt', [], { DEMO: ['Adults'] }, 2);
  });

  it('does not submit a reprompt when no capacity remains', () => {
    const existingQuestions = Array.from({ length: MAX_SURVEY_QUESTIONS }, (_, index) => question({ question: `Question ${index + 1}` }));
    const { component, surveyService } = createComponent(existingQuestions);
    component.repromptPrompt.set('Prompt');

    component.submitReprompt();

    expect(surveyService.submitAddMoreQuestions).not.toHaveBeenCalled();
  });

  it('ignores blank reprompt submissions', () => {
    const { component, surveyService } = createComponent();
    component.submitReprompt();
    expect(surveyService.submitAddMoreQuestions).not.toHaveBeenCalled();
  });

  it('reorders questions and remaps indexes on drop', () => {
    const questions = [question({ question: 'First' }), question({ question: 'Second' })];
    const { component, surveyService } = createComponent(questions);
    component.editingIndex = 0;
    component.rephrasePrompts = { 0: 'Prompt' };

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(surveyService.setQuestions).toHaveBeenCalled();
    expect(surveyService.remapDraftsAfterReorder).toHaveBeenCalledWith(0, 1);
    expect(component.editingIndex).toBe(1);
    expect(component.rephrasePrompts).toEqual({ 1: 'Prompt' });
  });

  it('ignores repeated selection and invalid question changes', () => {
    const { component, surveyService } = createComponent([question()]);
    component.selectQuestion(0);
    component.selectQuestion(0);
    component.changeQuestionType(4, QuestionTypes.Text);

    expect(surveyService.setQuestions).not.toHaveBeenCalled();
  });

  it('ignores editor data for a missing question', () => {
    const { component, surveyService } = createComponent();

    component.onQuestionEditorDataChange(0, { question: 'Missing' });

    expect(surveyService.saveDraft).not.toHaveBeenCalled();
    expect(surveyService.setQuestions).not.toHaveBeenCalled();
  });

  it('validates choice, scale, and StarRating new questions', () => {
    const { component } = createComponent();
    component.onAddAnotherQuestion(QuestionTypes.SingleChoice);
    component.onNewEditorDataChange({ question: 'Choice', options: ['Only'] });
    expect(component.isNewQuestionValid()).toBe(false);
    component.onNewEditorDataChange({ options: ['A', 'B'] });
    expect(component.isNewQuestionValid()).toBe(true);

    component.onAddAnotherQuestion(QuestionTypes.SinglePointScale);
    component.onNewEditorDataChange({ question: 'Scale', rowOptions: ['Only'], columnOptions: ['A', 'B'] });
    expect(component.isNewQuestionValid()).toBe(false);
    component.onNewEditorDataChange({ rowOptions: ['Low', 'High'] });
    expect(component.isNewQuestionValid()).toBe(true);

    component.onAddAnotherQuestion(QuestionTypes.StarRating);
    component.onNewEditorDataChange({ question: 'Rate these aspects?', rowOptions: ['Quality'] });
    expect(component.isNewQuestionValid()).toBe(true);
    component.onNewEditorDataChange({ rowOptions: [' '] });
    expect(component.isNewQuestionValid()).toBe(false);
  });

  it('uses supplied defaults when creating an inline question', () => {
    const { component, surveyService } = createComponent();
    component.pendingNewType.set(QuestionTypes.NetPromoterScore);
    component.newQuestionData.set({ question: 'NPS', isRequired: false });

    component.saveNewQuestion();

    expect(surveyService.addQuestion).toHaveBeenCalledWith(expect.objectContaining({
      options: [],
      isRequired: false,
      question: 'NPS',
    }));
  });

  it('toggles rephrase state and closes the panel', () => {
    const { component } = createComponent();
    const event = { stopPropagation: vi.fn() } as unknown as MouseEvent;

    component.toggleRephrase(2, event);
    component.toggleRephrase(2, event);

    expect(event.stopPropagation).toHaveBeenCalledTimes(2);
    expect(component.rephraseOpenIndex).toBeNull();
    expect(component.rephrasePrompts[2]).toBe('');
  });

  it('handles alternate rephrase response shapes', () => {
    const { surveyService } = createComponent();

    expect(surveyService.extractRephrasedQuestion({ question: 'Direct' })).toEqual({ question: 'Direct' });
    expect(surveyService.extractRephrasedQuestion({ question: { question: 'Nested' } })).toEqual({ question: 'Nested' });
    expect(surveyService.extractRephrasedQuestion([{ question: 'Array item' }])).toEqual({ question: 'Array item' });
    expect(surveyService.extractRephrasedQuestion({ invalid: true })).toBeNull();
  });

  it('normalizes choice, scale, and NPS rephrase responses', () => {
    const choice = createComponent([question()]);
    choice.surveyService.rephraseQuestions.mockReturnValue(of({ question: 'Choice', type: QuestionTypes.MultipleChoice, options: [' A ', null] }));
    choice.component.rephraseQuestion(0);
    expect(choice.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ options: ['A', ''] })]);

    const scale = createComponent([question()]);
    scale.surveyService.rephraseQuestions.mockReturnValue(of({ question: 'Scale', type: QuestionTypes.SinglePointScale, rowOptions: [' R '], columnOptions: [' C '] }));
    scale.component.rephraseQuestion(0);
    expect(scale.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ rowOptions: ['R'], columnOptions: ['C'] })]);

    const nps = createComponent([question()]);
    nps.surveyService.rephraseQuestions.mockReturnValue(of({ question: 'NPS', type: QuestionTypes.NetPromoterScore, npsLeftLabel: ' Left ', npsRightLabel: ' Right ' }));
    nps.component.rephraseQuestion(0);
    expect(nps.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ npsLeftLabel: 'Left', npsRightLabel: 'Right' })]);
  });

  it('handles rephrase responses without a question and errors', () => {
    const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => undefined);

    const empty = createComponent([question()]);
    empty.surveyService.rephraseQuestions.mockReturnValue(of({ invalid: true }));
    empty.component.rephraseQuestion(0);
    expect(empty.surveyService.setQuestions).not.toHaveBeenCalled();

    const failed = createComponent([question()]);
    failed.surveyService.rephraseQuestions.mockReturnValue(throwError(() => new Error('Failed')));
    failed.component.rephraseQuestion(0);
    expect(failed.component.rephraseLoadingIndex).toBeNull();
    expect(consoleErrorSpy).toHaveBeenCalled();
    consoleErrorSpy.mockRestore();
  });

  it('uses fallback rephrase payload fields when current question fields are undefined', () => {
    const { component, surveyService } = createComponent([
      question({
        questionNumber: undefined as any,
        question: undefined as any,
        isRequired: undefined as any,
        options: undefined as any,
        rowOptions: undefined as any,
        columnOptions: undefined as any,
        npsLeftLabel: undefined as any,
        npsRightLabel: undefined as any,
      }),
    ]);

    surveyService.rephraseQuestions.mockReturnValue(of({ invalid: true }));
    component.rephraseQuestion(0);

    expect(surveyService.rephraseQuestions).toHaveBeenCalledWith({
      question: expect.objectContaining({
        questionNumber: 1,
        question: '',
        isRequired: false,
        options: [],
        rowOptions: [],
        columnOptions: [],
        npsLeftLabel: '',
        npsRightLabel: '',
      }),
      userPrompt: '',
    });
  });

  it('falls back to current fields for incomplete rephrase responses', () => {
    const choice = createComponent([question({ type: QuestionTypes.SingleChoice, options: ['Keep'] })]);
    choice.surveyService.rephraseQuestions.mockReturnValue(of({ question: 'Choice', type: QuestionTypes.SingleChoice }));
    choice.component.rephraseQuestion(0);
    expect(choice.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ options: ['Keep'] })]);

    const scale = createComponent([question({ type: QuestionTypes.SinglePointScale, rowOptions: ['Keep row'], columnOptions: ['Keep col'] })]);
    scale.surveyService.rephraseQuestions.mockReturnValue(of({ question: 'Scale', type: QuestionTypes.SinglePointScale }));
    scale.component.rephraseQuestion(0);
    expect(scale.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      rowOptions: ['Keep row'],
      columnOptions: ['Keep col'],
    })]);

    const nps = createComponent([question({ type: QuestionTypes.NetPromoterScore })]);
    nps.surveyService.rephraseQuestions.mockReturnValue(of({ question: 'NPS', type: QuestionTypes.NetPromoterScore }));
    nps.component.rephraseQuestion(0);
    expect(nps.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ npsLeftLabel: '', npsRightLabel: '' })]);
  });

  it('ignores missing copies and resets reprompt prompt when opening', () => {
    const { component, surveyService } = createComponent();
    component.copyQuestion(0);
    component.repromptPrompt.set('Old');
    component.toggleRepromptPanel();
    component.toggleRepromptPanel();
    component.toggleRepromptPanel();

    expect(surveyService.setQuestions).not.toHaveBeenCalled();
    expect(component.repromptPrompt()).toBe('');
  });

  it('handles suggestion and reprompt errors', () => {
    const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => undefined);

    const { component, surveyService } = createComponent();
    surveyService.addMoreQuestions.mockReturnValue(throwError(() => new Error('Failed')));
    component.suggestNewQuestions({ stopPropagation: vi.fn() } as unknown as MouseEvent);
    expect(component.suggestNewQuestionsLoading()).toBe(false);

    surveyService.submitAddMoreQuestions.mockReturnValue(throwError(() => new Error('Failed')));
    component.showRepromptPanel.set(true);
    component.repromptPrompt.set('Prompt');
    component.submitReprompt();
    expect(component.showRepromptPanel()).toBe(true);
    expect(consoleErrorSpy).toHaveBeenCalledTimes(2);
    consoleErrorSpy.mockRestore();
  });

  it('ignores drops that do not change position', () => {
    const { component, surveyService } = createComponent([question()]);

    component.drop({ previousIndex: 0, currentIndex: 0 } as any);

    expect(surveyService.setQuestions).not.toHaveBeenCalled();
  });

  it('sanitizes editor fields when saving drafts', () => {
    const { component, surveyService } = createComponent([question()]);
    surveyService.getDraft.mockReturnValue(null);

    component.onQuestionEditorDataChange(0, {
      question: '',
      rowOptions: ['Row', null] as any,
      columnOptions: ['Column', null] as any,
      npsLeftLabel: 'Left',
      npsRightLabel: 'Right',
      isRequired: false,
    });

    expect(surveyService.saveDraft).toHaveBeenCalled();
  });

  it('initializes choice and scale fields when changing type', () => {
    const choice = createComponent([question({ options: [] })]);
    choice.component.changeQuestionType(0, QuestionTypes.MultipleChoice);
    expect(choice.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ options: ['', ''] })]);

    const scale = createComponent([question({ options: [], rowOptions: [], columnOptions: [] })]);
    scale.component.changeQuestionType(0, QuestionTypes.SinglePointScale);
    expect(scale.surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      rowOptions: ['', ''],
      columnOptions: ['', ''],
    })]);
  });

  it('remaps delete state for active and later indexes', () => {
    const active = createComponent([question(), question()]);
    active.component.editingIndex = 0;
    active.component.rephraseOpenIndex = 0;
    active.component.deleteQuestion(0);
    expect(active.component.editingIndex).toBeNull();
    expect(active.component.rephraseOpenIndex).toBeNull();

    const later = createComponent([question(), question(), question()]);
    later.component.editingIndex = 2;
    later.component.rephrasePrompts = { 0: 'Keep', 2: 'Move' };
    later.component.deleteQuestion(1);
    expect(later.component.editingIndex).toBe(1);
    expect(later.component.rephrasePrompts).toEqual({ 0: 'Keep', 1: 'Move' });
  });

  it('reevaluates validation and suggestion states after deleting a question', () => {
    const remainingQuestion = question({
      question: 'Remaining',
      suggestions: [{ severity: 'OPTIONAL' } as any],
    });
    const { component, validationService } = createComponent([
      question({ suggestions: [{ severity: 'MANDATORY' } as any] }),
      remainingQuestion,
    ]);

    component.deleteQuestion(0);

    expect(validationService.syncAfterSuggestionChange).toHaveBeenCalledWith([
      expect.objectContaining({ question: 'Remaining', questionNumber: 1 }),
    ]);
  });

  it('handles outside clicks for existing and inline editors', async () => {
    const existing = createComponent([question()]);
    existing.component.editingIndex = 0;
    existing.surveyService.getDraft.mockReturnValue({ question: 'Valid draft' });
    existing.component.closeOnOutsideClick(new MouseEvent('click'));
    expect(existing.component.editingIndex).toBeNull();

    const inline = createComponent();
    inline.component.pendingNewType.set(QuestionTypes.Text);
    inline.component.newQuestionData.set({ question: 'Inline question' });
    inline.component.closeOnOutsideClick(new MouseEvent('click'));
    await Promise.resolve();
    expect(inline.surveyService.addQuestion).toHaveBeenCalled();
  });

  it('cancels an empty inline editor after an outside click', async () => {
    const { component } = createComponent();
    component.pendingNewType.set(QuestionTypes.Text);
    component.closeOnOutsideClick(new MouseEvent('click'));
    await Promise.resolve();
    expect(component.pendingNewType()).toBe('');
  });

  it('tells the survey while a question is being edited or added', () => {
    const { component, surveyService } = createComponent([question()]);
    expect(surveyService.isEditingQuestion()).toBe(false);

    component.editingIndex = 0;
    expect(surveyService.isEditingQuestion()).toBe(true);
    component.discardQuestionChanges(0);
    expect(surveyService.isEditingQuestion()).toBe(false);

    component.onAddAnotherQuestion(QuestionTypes.Text);
    TestBed.tick();
    expect(surveyService.isEditingQuestion()).toBe(true);
    component.cancelNewQuestion();
    TestBed.tick();
    expect(surveyService.isEditingQuestion()).toBe(false);
  });

  it('clears the editing flag when the preview is destroyed mid-edit', () => {
    const { component, surveyService } = createComponent([question()]);
    component.editingIndex = 0;
    expect(surveyService.isEditingQuestion()).toBe(true);

    TestBed.resetTestingModule();

    expect(surveyService.isEditingQuestion()).toBe(false);
  });

  it('recognizes each kind of inline question input', async () => {
    const cases = [
      { options: ['Option'] },
      { rowOptions: ['Row'] },
      { columnOptions: ['Column'] },
      { isRequired: true },
      { npsLeftLabel: 'Left' },
      { npsRightLabel: 'Right' },
    ];

    for (const data of cases) {
      const { component } = createComponent();
      component.pendingNewType.set(QuestionTypes.Text);
      component.newQuestionData.set(data);
      component.closeOnOutsideClick(new MouseEvent('click'));
      await Promise.resolve();
      expect(component.pendingNewType()).toBe(QuestionTypes.Text);
    }
  });

  it('keeps clicks inside the type list open without a document-wide query', async () => {
    const { component } = createComponent();
    component.pendingNewType.set(QuestionTypes.Text);
    const typeList = document.createElement('div');
    typeList.className = 'question-type-wrapper';
    const option = document.createElement('button');
    typeList.appendChild(option);
    document.body.appendChild(typeList);
    const event = new MouseEvent('click', { bubbles: true });
    Object.defineProperty(event, 'target', { value: option });
    const querySelector = vi.spyOn(document, 'querySelector');

    try {
      component.closeOnOutsideClick(event);
      await Promise.resolve();
      expect(component.pendingNewType()).toBe(QuestionTypes.Text);
      expect(querySelector).not.toHaveBeenCalled();
    } finally {
      querySelector.mockRestore();
      typeList.remove();
    }
  });

  it('remaps prompts before and at the deleted index', () => {
    const { component } = createComponent([question(), question(), question()]);
    component.rephrasePrompts = { 0: 'Before', 1: 'Deleted', 3: 'After', bad: 'Ignore' } as any;
    component.rephraseOpenIndex = 1;
    component.rephraseLoadingIndex = 0;
    component.deleteQuestion(1);

    expect(component.rephrasePrompts).toEqual({ 0: 'Before', 2: 'After' });
    expect(component.rephraseOpenIndex).toBeNull();
    expect(component.rephraseLoadingIndex).toBe(0);
  });

  it('uses current question defaults for incomplete rephrase payloads', () => {
    const { component, surveyService } = createComponent([{
      type: QuestionTypes.Text,
      isRequired: true,
    }]);
    surveyService.rephraseQuestions.mockReturnValue(of({ question: { question: 'Nested' } }));

    component.rephraseQuestion(0);

    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({
      questionNumber: 1,
      question: 'Nested',
      isRequired: true,
    })]);
  });

  it('covers remaining preview guard branches', () => {
    const { component, surveyService } = createComponent();
    expect(component.asQuestionType(QuestionTypes.Text)).toBe(QuestionTypes.Text);
    expect(surveyService.extractRephrasedQuestion([{}])).toBeNull();
    expect(surveyService.extractRephrasedQuestion({ question: {} })).toBeNull();
    expect(surveyService.extractRephrasedQuestion({ result: { question: { question: 'Nested via result' } } })).toEqual({ question: 'Nested via result' });
  });

  it('closes editor on outside click', () => {
    const { component, surveyService } = createComponent([question()]);
    component.editingIndex = 0;
    surveyService.getDraft.mockReturnValue({ question: 'Valid draft' });

    component.closeOnOutsideClick(new MouseEvent('click'));

    expect(component.editingIndex).toBeNull();
  });

  it('keeps unrelated prompt indexes unchanged during a drop', () => {
    const { component } = createComponent([question(), question(), question(), question()]);
    component.rephrasePrompts = { 3: 'Unrelated' };

    component.drop({ previousIndex: 0, currentIndex: 2 } as any);

    expect(component.rephrasePrompts).toEqual({ 3: 'Unrelated' });
  });

  it('remaps reverse drag indexes and clears hover state', () => {
    const questions = [question({ question: 'First' }), question({ question: 'Second' }), question({ question: 'Third' })];
    const { component, surveyService } = createComponent(questions);
    component.editingIndex = 2;
    component.rephraseLoadingIndex = 2;
    component.rephraseOpenIndex = 1;
    component.hoveredQuestionIndex = 1;

    component.drop({ previousIndex: 2, currentIndex: 0 } as any);

    expect(surveyService.remapDraftsAfterReorder).toHaveBeenCalledWith(2, 0);
    expect(component.editingIndex).toBe(0);
    expect(component.rephraseLoadingIndex).toBe(0);
    expect(component.rephraseOpenIndex).toBeNull();
    expect(component.hoveredQuestionIndex).toBeNull();
  });

  it('drops while ignoring non-numeric rephrase prompt keys', () => {
    const { component } = createComponent([question({ question: 'First' }), question({ question: 'Second' })]);
    component.rephrasePrompts = { 0: 'Numeric', bad: 'Ignore me' } as any;

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(component.rephrasePrompts).toEqual({ 1: 'Numeric' });
  });

  it('clears rephrase open and hover state after a valid drop', () => {
    const { component } = createComponent([question(), question()]);
    component.rephraseOpenIndex = 0;
    component.hoveredQuestionIndex = 1;

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(component.rephraseOpenIndex).toBeNull();
    expect(component.hoveredQuestionIndex).toBeNull();
  });

  it('keeps null rephraseLoadingIndex unchanged during drop remap', () => {
    const { component } = createComponent([question(), question()]);
    component.rephraseLoadingIndex = null;

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(component.rephraseLoadingIndex).toBeNull();
  });

  it('keeps null editingIndex unchanged during drop remap', () => {
    const { component } = createComponent([question(), question()]);
    component.editingIndex = null;

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(component.editingIndex).toBeNull();
  });

  it('calls remapDraftsAfterReorder on drop for reordering side effects', () => {
    const { component, surveyService } = createComponent([question(), question()]);

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(surveyService.remapDraftsAfterReorder).toHaveBeenCalledWith(0, 1);
  });

  it('sets editingIndex to null when remap returns null', () => {
    const { component, surveyService } = createComponent([question(), question()]);
    component.editingIndex = 0;
    surveyService.remapIndexAfterReorder.mockReturnValue(null);

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(component.editingIndex).toBeNull();
  });

  it('drops while skipping prompt remap entries when remap returns null', () => {
    const { component, surveyService } = createComponent([question(), question()]);
    component.rephrasePrompts = { 0: 'Drop me', 1: 'Keep me' };
    surveyService.remapIndexAfterReorder.mockImplementation((index: number) => (index === 0 ? null : index));

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(component.rephrasePrompts).toEqual({ 1: 'Keep me' });
  });

  it('remaps indexes between positions on forward and reverse drops', () => {
    const forward = createComponent([question(), question(), question()]);
    forward.component.editingIndex = 1;
    forward.component.rephraseLoadingIndex = 1;
    forward.component.drop({ previousIndex: 0, currentIndex: 2 } as any);
    expect(forward.component.editingIndex).toBe(0);
    expect(forward.component.rephraseLoadingIndex).toBe(0);

    const reverse = createComponent([question(), question(), question()]);
    reverse.component.editingIndex = 1;
    reverse.component.rephraseLoadingIndex = 1;
    reverse.component.drop({ previousIndex: 2, currentIndex: 0 } as any);
    expect(reverse.component.editingIndex).toBe(2);
    expect(reverse.component.rephraseLoadingIndex).toBe(2);
  });

  it('keeps existing editor open when composedPath contains a question row', () => {
    const { component, surveyService } = createComponent([question()]);
    component.editingIndex = 0;

    const questionRow = document.createElement('div');
    questionRow.className = 'question-row';
    const event = {
      target: null,
      composedPath: () => [questionRow],
    } as unknown as MouseEvent;

    component.closeOnOutsideClick(event);

    expect(component.editingIndex).toBe(0);
    expect(surveyService.clearDraft).not.toHaveBeenCalled();
  });

  it('closes existing editor on outside click when merged draft is valid', () => {
    const { component, surveyService } = createComponent([question()]);
    component.editingIndex = 0;
    surveyService.getDraft.mockReturnValue({ question: 'Updated draft' });

    component.closeOnOutsideClick({
      target: null,
      composedPath: () => [],
    } as unknown as MouseEvent);

    expect(surveyService.clearDraft).toHaveBeenCalledWith(0);
    expect(surveyService.clearDraft).toHaveBeenCalledTimes(1);
    expect(surveyService.getDraft).toHaveBeenCalledTimes(1);
    expect(surveyService.getDraft).toHaveBeenCalledWith(0);
    expect(surveyService.setQuestions).toHaveBeenCalledWith([expect.objectContaining({ question: 'Updated draft' })]);
    expect(component.editingIndex).toBeNull();
  });

  it('closes existing editor on outside click when question at editing index is missing', () => {
    const { component, surveyService } = createComponent();
    component.editingIndex = 2;
    surveyService.getDraft.mockReturnValue({ question: 'orphan draft' });

    component.closeOnOutsideClick({
      target: null,
      composedPath: () => [],
    } as unknown as MouseEvent);

    expect(surveyService.clearDraft).toHaveBeenCalledWith(2);
    expect(component.editingIndex).toBeNull();
  });

  it('keeps rephrase panel open when composedPath contains rephrase wrapper', () => {
    const { component } = createComponent([question()]);
    component.rephraseOpenIndex = 0;

    const rephraseWrap = document.createElement('div');
    rephraseWrap.className = 'rephrase-wrap';
    const event = {
      target: null,
      composedPath: () => [rephraseWrap],
    } as unknown as MouseEvent;

    component.closeOnOutsideClick(event);

    expect(component.rephraseOpenIndex).toBe(0);
  });

  it('closes rephrase panel when click is outside rephrase wrapper', () => {
    const { component } = createComponent([question()]);
    component.rephraseOpenIndex = 1;

    const event = {
      target: null,
      composedPath: () => [],
    } as unknown as MouseEvent;

    component.closeOnOutsideClick(event);

    expect(component.rephraseOpenIndex).toBeNull();
  });

  it('keeps inline editor open when composedPath includes editor and type-list nodes', () => {
    const { component, surveyService } = createComponent();
    component.pendingNewType.set(QuestionTypes.Text);

    const editorHost = document.createElement('div');
    const typeList = document.createElement('div');
    typeList.className = 'question-type-wrapper';
    document.body.appendChild(typeList);

    try {
      (component as any).inlineEditorContainer = () => ({ nativeElement: editorHost });

      const event = {
        target: null,
        composedPath: () => [editorHost, typeList],
      } as unknown as MouseEvent;

      component.closeOnOutsideClick(event);

      expect(surveyService.addQuestion).not.toHaveBeenCalled();
      expect(component.pendingNewType()).toBe(QuestionTypes.Text);
    } finally {
      typeList.remove();
    }
  });
});
