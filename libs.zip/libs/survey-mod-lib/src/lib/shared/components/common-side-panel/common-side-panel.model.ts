export type HeaderImgConfig = {
  imgSrc: string;
  altText: string;
};
