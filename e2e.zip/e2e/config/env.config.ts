/**
 * Single shared source for the app's base URL — mirrors Omni Shopper's
 * config.BASE_URL getter (src/lib/playwright/config.ts). Reads
 * process.env.BASE_URL lazily (via a getter) so it still works regardless of
 * when dotenv.config() ran relative to this module being imported.
 */
export const DEFAULT_BASE_URL = 'https://si.connect.nielseniq.io/reportexperience-dev';

export const envConfig = {
  get BASE_URL(): string {
    return process.env.BASE_URL || DEFAULT_BASE_URL;
  },
};
