import {
  Component,
  computed,
  input,
  signal,
  ChangeDetectionStrategy,
} from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ClientSideRowModelModule,
  ModuleRegistry,
  themeQuartz,
  type ColDef,
  type GetRowIdParams,
  type IsFullWidthRowParams,
  type RowClassParams,
  type RowClickedEvent,
  type RowHeightParams,
} from 'ag-grid-community';

import type { Question, QuestionRow } from './question.model';
import { ExpandIconRendererComponent } from './renderers/expand-icon-renderer.component';
import { OptionsDetailRendererComponent } from './renderers/options-detail-renderer.component';
import { RequiredBadgeRendererComponent } from './renderers/required-badge-renderer.component';
import { TypeBadgeRendererComponent } from './renderers/type-badge-renderer.component';

ModuleRegistry.registerModules([ClientSideRowModelModule]);

const QUESTION_ROW_HEIGHT = 56;
const DETAIL_ROW_BASE_HEIGHT = 24;
const CHOICE_OPTION_HEIGHT = 38;
const MATRIX_HEADER_HEIGHT = 40;
const MATRIX_ROW_HEIGHT = 40;
const STAR_RATING_HEIGHT = 64;
const NPS_HEIGHT = 100;

/**
 * Reusable, self-contained ag-grid wrapper that renders a list of survey
 * `Question`s. Clicking a question row expands it in place (Community-edition
 * "full width row" technique) to reveal its answer UI, and a dedicated column
 * always shows the question `type`:
 * - SINGLE_CHOICE / MULTIPLE_CHOICE - radio / checkbox option list
 * - STAR_RATING - 1-5 star scale
 * - NET_PROMOTER_SCORE - 0-10 scale with left/right labels
 * - SINGLE_POINT_SCALE / MULTIPLE_POINT_SCALE - row x column matrix
 *
 * Usage:
 * ```html
 * <survey-question-grid [questions]="myQuestions" />
 * ```
 */
@Component({
  selector: 'survey-question-grid',
  standalone: true,
  imports: [AgGridAngular],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './question-grid.component.html',
  styleUrl: './question-grid.component.scss',
})
export class QuestionGridComponent {
  /** The list of questions to render. Required. */
  readonly questions = input.required<Question[]>();

  /** Question numbers of currently expanded questions. */
  private readonly expandedIds = signal<ReadonlySet<number>>(new Set());

  /** ag-grid theme (new Theming API - no CSS imports required). */
  protected readonly theme = themeQuartz;

  protected readonly headerHeight = 44;
  protected readonly rowHeightPx = QUESTION_ROW_HEIGHT;

  /** Flat row model: a "question" row followed by an optional "detail" row. */
  protected readonly rowData = computed<QuestionRow[]>(() => {
    const expanded = this.expandedIds();
    const rows: QuestionRow[] = [];
    for (const question of this.questions()) {
      const isExpanded = expanded.has(question.questionNumber);
      rows.push({
        rowType: 'question',
        id: `q-${question.questionNumber}`,
        question,
        expanded: isExpanded,
      });
      if (isExpanded) {
        rows.push({
          rowType: 'detail',
          id: `detail-${question.questionNumber}`,
          question,
          parentId: question.questionNumber,
        });
      }
    }
    return rows;
  });

  protected readonly columnDefs: ColDef<QuestionRow>[] = [
    {
      colId: 'expand',
      headerName: '',
      width: 48,
      minWidth: 48,
      maxWidth: 48,
      resizable: false,
      sortable: false,
      filter: false,
      suppressMovable: true,
      cellRenderer: ExpandIconRendererComponent,
      cellRendererParams: {
        onToggle: (questionNumber: number) => this.toggleQuestion(questionNumber),
      },
      cellStyle: { cursor: 'pointer' },
    },
    {
      colId: 'questionNumber',
      headerName: '#',
      width: 64,
      minWidth: 64,
      maxWidth: 80,
      sortable: true,
      cellStyle: { cursor: 'pointer', display: 'flex', alignItems: 'center', color: '#64748b', fontWeight: '600' },
      valueGetter: (p) => (p.data?.rowType === 'question' ? p.data.question?.questionNumber : ''),
    },
    {
      colId: 'question',
      headerName: 'Question',
      flex: 1,
      minWidth: 280,
      sortable: true,
      wrapText: true,
      cellStyle: { cursor: 'pointer', display: 'flex', alignItems: 'center', lineHeight: '1.4' },
      valueGetter: (p) => (p.data?.rowType === 'question' ? p.data.question?.question : ''),
    },
    {
      colId: 'type',
      headerName: 'Type',
      width: 175,
      minWidth: 150,
      sortable: true,
      cellRenderer: TypeBadgeRendererComponent,
      valueGetter: (p) => (p.data?.rowType === 'question' ? p.data.question?.type : ''),
    },
    {
      colId: 'required',
      headerName: 'Required',
      width: 120,
      minWidth: 110,
      sortable: true,
      cellRenderer: RequiredBadgeRendererComponent,
      valueGetter: (p) => (p.data?.rowType === 'question' ? p.data.question?.isRequired : ''),
    },
  ];

  protected readonly defaultColDef: ColDef<QuestionRow> = {
    resizable: true,
    suppressHeaderMenuButton: true,
  };

  /** Options answer panel spans the full row width when a question is expanded. */
  protected readonly isFullWidthRow = (params: IsFullWidthRowParams<QuestionRow>): boolean =>
    params.rowNode.data?.rowType === 'detail';

  protected readonly fullWidthCellRenderer = OptionsDetailRendererComponent;

  protected readonly getRowId = (params: GetRowIdParams<QuestionRow>) => params.data.id;

  protected readonly getRowHeight = (params: RowHeightParams<QuestionRow>): number | undefined => {
    const data = params.data;
    if (!data) return undefined;
    if (data.rowType !== 'detail') return QUESTION_ROW_HEIGHT;

    const question = data.question;
    switch (question?.type) {
      case 'SINGLE_CHOICE':
      case 'MULTIPLE_CHOICE': {
        const optionCount = question.options?.length ?? 0;
        return DETAIL_ROW_BASE_HEIGHT + optionCount * CHOICE_OPTION_HEIGHT;
      }
      case 'STAR_RATING':
        return STAR_RATING_HEIGHT;
      case 'NET_PROMOTER_SCORE':
        return NPS_HEIGHT;
      case 'SINGLE_POINT_SCALE':
      case 'MULTIPLE_POINT_SCALE': {
        const rowCount = question.rowOptions?.length ?? 0;
        return DETAIL_ROW_BASE_HEIGHT + MATRIX_HEADER_HEIGHT + rowCount * MATRIX_ROW_HEIGHT;
      }
      default:
        return DETAIL_ROW_BASE_HEIGHT + CHOICE_OPTION_HEIGHT;
    }
  };

  protected readonly getRowClass = (params: RowClassParams<QuestionRow>) => {
    if (params.data?.rowType !== 'question') return undefined;
    return params.data.expanded ? ['question-row', 'question-row--expanded'] : ['question-row'];
  };

  protected onRowClicked(event: RowClickedEvent<QuestionRow>): void {
    const row = event.data;
    if (!row || row.rowType !== 'question' || !row.question) return;

    this.toggleQuestion(row.question.questionNumber);
  }

  private toggleQuestion(questionNumber: number): void {
    this.expandedIds.update((current) => {
      const next = new Set(current);
      if (next.has(questionNumber)) {
        next.delete(questionNumber);
      } else {
        next.add(questionNumber);
      }
      return next;
    });
  }
}
