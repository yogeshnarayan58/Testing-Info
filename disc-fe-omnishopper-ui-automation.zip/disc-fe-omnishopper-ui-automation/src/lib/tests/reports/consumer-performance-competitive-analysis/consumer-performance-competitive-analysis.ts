import { BasePage } from "@gfk/gta";
import * as reportPageResources from "./resources/report-page-resources.json";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";

const REPORTPAGE = "CPCAReportPage";

export class ConsumerPerformanceCompetitiveAnalysis extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(REPORTPAGE, reportPageResources);
  }

}