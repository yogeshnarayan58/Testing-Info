import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { RepromptActionsComponent } from './reprompt-actions.component';

describe('RepromptActionsComponent', () => {
  it('updates prompt and closes panel', () => {
    const component = TestBed.runInInjectionContext(() => new RepromptActionsComponent());

    component.onPromptInput('New prompt');
    expect(component.prompt()).toBe('New prompt');

    component.isPanelOpen.set(true);
    component.onCloseClicked();
    expect(component.isPanelOpen()).toBe(false);
  });

  it('emits submit only when enabled', () => {
    const component = TestBed.runInInjectionContext(() => new RepromptActionsComponent());
    const emitSpy = vi.spyOn(component.submit, 'emit');

    component.onSubmitClicked();
    expect(emitSpy).toHaveBeenCalledTimes(1);

    (component as any).submitDisabled = () => true;
    component.onSubmitClicked();
    expect(emitSpy).toHaveBeenCalledTimes(1);
  });
});
