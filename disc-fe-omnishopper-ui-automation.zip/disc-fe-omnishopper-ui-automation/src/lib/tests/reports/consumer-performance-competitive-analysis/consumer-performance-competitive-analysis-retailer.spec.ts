import test from "@playwright/test";
import {
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import devTestData from "./test-data/dev-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import localizationData from "./test-data/localization-data.json";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { findDataSetByName, hasPivotInDimensionSelections, getDimensionSelectionsByPivot } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import prodTestData from "./test-data/prod-test-data.json";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;

const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET); //Todo: add strict data model
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";


test.describe("Consumer Performance Competitive Analysis - Retailer Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      // Open additional prompts to ensure madlib is visible
      // await dataSelector.clickAdditionalPromptEllipsisIcon();

      // Validate using pattern matching with detailed results
      if (localeData.pivotMadlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).retailer;

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(
          new RegExp(expectedMadlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

    test.describe.serial(
      "Run, PPT Export, Excel Export",
      { tag: ["@Report_E2E_Flow"] },
      () => {
        test(
          "Report Generation: Validates dimension selection and successful execution",
          {
            tag: "@RunReport",
          },
          async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);

            const retailerPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
            if (!retailerPivotData) {
              throw new Error("Pivot not found in test data: Retailer");
            }

            await dataSelector.switchPivotDropdown(pivot);
            await dataSelector.clickAdditionalPromptEllipsisIcon();

            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.selectClosedDropdown(retailerPivotData["Facts"]["selections"]);

            await dataSelector.clickMadlibDimension("Product");
            await dataSelector.setMadlibSelection(retailerPivotData["Product"]);

            await dataSelector.clickMadlibDimension("Retailers");
            await dataSelector.setMadlibSelection(retailerPivotData["Retailers"]);

            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(retailerPivotData["Geography"]);

            await dataSelector.clickMadlibDimension("Period");
            await dataSelector.setPeriodMadlibSelection(retailerPivotData["Period"]);

            await dataSelector.clickMadlibDimension("Comparison Period");
            await dataSelector.setPeriodMadlibSelection(retailerPivotData["Comparison Period"]);

            await dataSelector.clickMadlibDimension("Demography");
            await dataSelector.setMadlibSelection(retailerPivotData["Demography"]);

            await dataSelector.clickMadlibDimension("People");
            await dataSelector.checkPeopleSelectionGroupExists();
            await dataSelector.clickMadlibDimension("peopleAddGroupButton");
            await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
            await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
            for (const selection of retailerPivotData["People"]
                .selections) {
            await dataSelector.handlePeopleMenuOptions(selection);
            }

            let dsBasePage = await dataSelector.getBasePage();
            commonTestCase = new CommonTestCase(dsBasePage);
            await dataSelector.clickRunButton();
            await dataSelector.waitForReportRunCompletion();
            const { newReportTitle, newUrl } =
              await commonTestCase.saveReport();
            savedReportTitle = newReportTitle;
            savedReportUrl = newUrl;
            console.log("savedReportTitle:", savedReportTitle);
            console.log("savedReportUrl:", savedReportUrl);
          }
        );
  
        test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
          test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');
          let basePage = await BasePageFactory.createBasePage();
          let findMyStuff = new FindMyStuff(basePage);
          await findMyStuff.navigateToUrl(config.BASE_URL);
          await findMyStuff.clickFindMyStuff();
          await findMyStuff.openCurrentReportFMS(savedReportTitle);
  
          console.log("FMS execution successful");
        })
      }
    );
}
);