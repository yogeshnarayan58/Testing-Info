import { describe, expect, it } from 'vitest';
import { buildSurveyResultsPayload } from './survey-results-payload.util';
import barConfig from '../../../../../assets/payload/bar.json';
import columnConfig from '../../../../../assets/payload/column.json';
import gridConfig from '../../../../../assets/payload/grid.json';
import pieConfig from '../../../../../assets/payload/pie.json';

describe('buildSurveyResultsPayload', () => {
  it('maps every saved question without changing its id, text, or type', () => {
    const types = [
      'SINGLE_CHOICE', 'MULTIPLE_CHOICE', 'SINGLE_POINT_SCALE',
      'MULTIPLE_POINT_SCALE', 'NET_PROMOTER_SCORE', 'STAR_RATING',
    ];
    const questions = types.map((type, index) => ({
      id: `saved-question-${index + 10}`,
      prompt: { text: `Question ${index + 1}` },
      type,
    }));
    const original = JSON.stringify(questions);

    const payload = buildSurveyResultsPayload(questions);

    expect(payload).toEqual(questions.map(question => ({
      id: question.id,
      title: question.prompt.text,
      type: question.type,
      attributes: {},
      reportSpec: {
        id: expect.any(String),
        specs: [{
          id: 'spec-1',
          uiConfigs: expect.any(Array),
          objects: expect.any(Array),
          containers: expect.any(Array),
          dataSummary: {},
        }],
      },
    })));
    expect(JSON.stringify(questions)).toBe(original);
    expect(payload[0].reportSpec.specs).not.toBe(payload[1].reportSpec.specs);
    expect(payload[0].attributes).not.toBe(payload[1].attributes);
    expect(payload[0].reportSpec.specs[0]).not.toBe(payload[1].reportSpec.specs[0]);
    const reportSpecIds = payload.map(question => question.reportSpec.id);
    expect(new Set(reportSpecIds).size).toBe(reportSpecIds.length);
    expect(reportSpecIds.every(id => /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id))).toBe(true);
  });

  it('adds the expected chart entries for choice and NPS questions', () => {
    const questions = ['SINGLE_CHOICE', 'MULTIPLE_CHOICE', 'NET_PROMOTER_SCORE'].map((type, index) => ({
      id: `question-${index}`,
      prompt: { text: `Question ${index}` },
      type,
    }));

    const payload = buildSurveyResultsPayload(questions);
    const idsByQuestion = payload.map(question => question.reportSpec.specs[0].uiConfigs.map(config => config['id']));

    expect(idsByQuestion[0]).toEqual([
      'q1_c1_bar_chart_absolute',
      'q1_c1_column_chart_absolute',
      'q1_c1_bar_chart_percentage',
      'q1_c1_column_chart_percentage',
      'q1_c1_pie_chart_percentage',
      'q1_c1_table_percentage',
      'q1_c1_table_absolute',
    ]);
    expect(idsByQuestion[1]).toEqual([
      'q2_c1_bar_chart_absolute',
      'q2_c1_column_chart_absolute',
      'q2_c1_bar_chart_percentage',
      'q2_c1_column_chart_percentage',
      'q2_c1_pie_chart_percentage',
      'q2_c1_table_percentage',
      'q2_c1_table_absolute',
    ]);
    expect(idsByQuestion[2]).toEqual([
      'q3_c1_column_chart_absolute',
      'q3_c1_column_chart_percentage',
      'q3_c1_pie_chart_percentage',
      'q3_c1_table_percentage',
      'q3_c1_table_absolute',
    ]);

    for (const question of payload) {
      const spec = question.reportSpec.specs[0];
      expect(spec.objects).toHaveLength(spec.uiConfigs.length);
      expect(spec.containers).toHaveLength(spec.uiConfigs.length);
    }
  });

  it.each([
    ['STAR_RATING', 1, 7],
    ['SINGLE_POINT_SCALE', 1, 9],
    ['MULTIPLE_POINT_SCALE', 1, 9],
    ['STAR_RATING', 2, 12],
    ['SINGLE_POINT_SCALE', 2, 16],
    ['MULTIPLE_POINT_SCALE', 2, 16],
  ])('builds %s UI configs for %i answer rows (%i expected)', (type, rowCount, expectedCount) => {
    const rows = Array.from({ length: rowCount as number }, (_, index) => ({ value: `r${index + 1}`, label: `Row ${index + 1}` }));
    const question = {
      id: 'scale-question',
      prompt: { text: 'Scale question' },
      type: type as string,
      answerSpec: { rows },
    };

    const [payload] = buildSurveyResultsPayload([question]);
    const uiConfigs = payload.reportSpec.specs[0].uiConfigs;

    expect(uiConfigs).toHaveLength(expectedCount as number);
    expect(uiConfigs.slice(0, 2).map(config => config['id'])).toEqual([
      'q1_c1_heatmap_absolute',
      'q1_c1_heatmap_percentage',
    ]);
    const rowEntries = type === 'STAR_RATING' ? 5 : 7;
    for (let rowNumber = 1; rowNumber <= (rowCount as number); rowNumber++) {
      const expectedRowIds = [
        `q1_c${rowNumber}_bar_chart_absolute`,
        `q1_c${rowNumber}_column_chart_absolute`,
        `q1_c${rowNumber}_bar_chart_percentage`,
        `q1_c${rowNumber}_column_chart_percentage`,
        `q1_c${rowNumber}_pie_chart_percentage`,
        ...(type === 'STAR_RATING' ? [] : [
          `q1_c${rowNumber}_table_percentage`,
          `q1_c${rowNumber}_table_absolute`,
        ]),
      ];
      expect(uiConfigs.slice(2 + (rowNumber as number - 1) * rowEntries, 2 + (rowNumber as number) * rowEntries).map(config => config['id'])).toEqual(expectedRowIds);
    }
  });

  it('defaults scale questions to one row when answerSpec rows are missing or empty', () => {
    const questions = [
      { id: 'missing-rows', prompt: { text: 'No rows property' }, type: 'SINGLE_POINT_SCALE', answerSpec: {} },
      { id: 'empty-rows', prompt: { text: 'Empty rows' }, type: 'MULTIPLE_POINT_SCALE', answerSpec: { rows: [] } },
      { id: 'no-answer-spec', prompt: { text: 'No answer spec' }, type: 'STAR_RATING' },
    ];

    const payload = buildSurveyResultsPayload(questions);
    expect(payload.map(question => question.reportSpec.specs[0].uiConfigs.length)).toEqual([9, 9, 7]);
  });

  it('returns an empty payload for a survey with no questions', () => {
    expect(buildSurveyResultsPayload([])).toEqual([]);
  });

  it('creates matching objects and ordered containers for all chart types and repeated rows', () => {
    const questions = [
      'SINGLE_CHOICE', 'MULTIPLE_CHOICE', 'NET_PROMOTER_SCORE',
      'STAR_RATING', 'SINGLE_POINT_SCALE', 'MULTIPLE_POINT_SCALE',
    ].map((type, index) => ({
      id: `saved-${index}`,
      prompt: { text: 'Question' },
      type,
      answerSpec: { rows: [{ value: 'r1' }, { value: 'r2' }] },
    }));
    const payload = buildSurveyResultsPayload(questions);
    const containerIds: string[] = [];
    for (const question of payload) {
      const spec = question.reportSpec.specs[0];
      expect(spec.objects).toHaveLength(spec.uiConfigs.length);
      expect(spec.containers).toHaveLength(spec.uiConfigs.length);
      expect(spec.dataSummary).toEqual({});
      spec.uiConfigs.forEach((config, index) => {
        const id = config['id'];
        if (typeof id !== 'string') {
          throw new Error('Expected a string UI config ID');
        }
        const chartName = id.replace(/^q\d+_c\d+_/, '').split('_')[0];
        const objectType = chartName === 'heatmap' || chartName === 'table' ? 'grid' : chartName;
        expect(spec.objects[index]).toEqual({
          valid: true,
          id,
          type: objectType,
          name: 'Table-1',
          specId: spec.id,
          title: '',
        });
        const container = spec.containers[index];
        expect(container).toEqual({
          valid: true,
          id: expect.stringMatching(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i),
          type: 'simple',
          positionX: 0,
          positionY: 0,
          width: 100,
          height: 100,
          pageId: '',
          objectId: id,
          connectToId: '',
          children: [],
          pages: [],
          order: index + 1,
        });
        containerIds.push(container.id);
      });
    }
    expect(new Set(containerIds).size).toBe(containerIds.length);
    expect(payload[4].reportSpec.specs[0].objects).toHaveLength(16);
    expect(payload[4].reportSpec.specs[0].containers).toHaveLength(16);
  });

  it('preserves every template field and creates independent copies for each entry', () => {
    const templates: Record<string, object> = {
      bar_chart_absolute: barConfig,
      bar_chart_percentage: barConfig,
      column_chart_absolute: columnConfig,
      column_chart_percentage: columnConfig,
      pie_chart_percentage: pieConfig,
      table_absolute: gridConfig,
      table_percentage: gridConfig,
      heatmap_absolute: gridConfig,
      heatmap_percentage: gridConfig,
    };
    const originalTemplates = structuredClone(templates);
    const questions = ['SINGLE_CHOICE', 'SINGLE_POINT_SCALE', 'STAR_RATING'].map((type, index) => ({
      id: `saved-${index}`,
      prompt: { text: 'Question' },
      type,
      answerSpec: { rows: [{ value: 'r1' }, { value: 'r2' }] },
    }));
    const configs = buildSurveyResultsPayload(questions)
      .flatMap(question => question.reportSpec.specs[0].uiConfigs);
    const ids = configs.map(config => config['id']);
    expect(new Set(ids).size).toBe(ids.length);

    for (const config of configs) {
      const { id, ...templateFields } = config;
      expect(typeof id).toBe('string');
      if (typeof id !== 'string') {
        throw new Error('Expected a string UI config ID');
      }
      const templateId = id.replace(/^q\d+_c\d+_/, '');
      expect(templates[templateId]).toBeDefined();
      expect(templateFields).toEqual(templates[templateId]);
    }

    const [first, second] = configs;
    expect(first['chartConfigs']).not.toBe(second['chartConfigs']);
    const originalSecond = structuredClone(second);
    const chartConfigs = first['chartConfigs'];
    if (!Array.isArray(chartConfigs)) {
      throw new Error('Expected a bar chart configuration array');
    }
    chartConfigs.push({ chartType: 'changed-for-test' });
    expect(second).toEqual(originalSecond);
    expect(templates).toEqual(originalTemplates);
  });

  it.each(['TEXT', 'UNRECOGNIZED_TYPE'])('preserves empty UI configs for %s', type => {
    const [payload] = buildSurveyResultsPayload([{
      id: 'saved-id',
      prompt: { text: 'Question' },
      type,
    }]);
    expect(payload.reportSpec.specs[0].uiConfigs).toEqual([]);
    expect(payload.reportSpec.specs[0].objects).toEqual([]);
    expect(payload.reportSpec.specs[0].containers).toEqual([]);
  });

  it.each([
    { prompt: { text: 'Question' }, type: 'SINGLE_CHOICE' },
    { id: ' ', prompt: { text: 'Question' }, type: 'SINGLE_CHOICE' },
    { id: 1, prompt: { text: 'Question' }, type: 'SINGLE_CHOICE' },
    { id: 'saved-id', type: 'SINGLE_CHOICE' },
    { id: 'saved-id', prompt: null, type: 'SINGLE_CHOICE' },
    { id: 'saved-id', prompt: {}, type: 'SINGLE_CHOICE' },
    { id: 'saved-id', prompt: { text: '' }, type: 'SINGLE_CHOICE' },
    { id: 'saved-id', prompt: { text: 123 }, type: 'SINGLE_CHOICE' },
    { id: 'saved-id', prompt: { text: 'Question' }, type: '' },
    { id: 'saved-id', prompt: { text: 'Question' } },
  ])('reports malformed saved questions instead of inventing values: %j', question => {
    expect(() => buildSurveyResultsPayload([question])).toThrow(
      'Cannot build survey results payload: question 1 requires an id, prompt.text, and type.',
    );
  });
});
