import { BasePage, WebActions } from "@gfk/gta";
import * as resources from "./profile-page-resources.json";
import { expect } from "@playwright/test";

// Function to retrieve a resource from the object repository by name
export function getResource(s: string) {
  return resources.webElements.find((x) => x.elementName === s)!;
}

export class ProfilePage {
  webActionHandler: WebActions;
  constructor(basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
  }

  /*
   * Method will take the locale as a parameter and will update the user profile language
   * @param locale
   */
  public async setUserLocale(locale: string) {
    console.log("Setting user locale..");
    await this.navigateToProfileSettings();
    await this.webActionHandler
      .getWebElement(getResource("profileLanguageSettingsInput"))
      .click();
    await this.webActionHandler.getWebElement(getResource(locale)).click();
    await this.webActionHandler
      .getWebElement(getResource("saveChanges"))
      .click();
    console.log("User locale changed successfully!..");
  }

  public async validateUserLocale(locale: string) {
   let userLocale = this.getUserLocale();
   expect(userLocale).toBe(locale);
   console.log("Validated user locale successfully!..");
  }

  public async getUserLocale() {
    console.log("Getting user locale..");
    await this.navigateToAccountSettings();
    let userLocale = await this.webActionHandler
      .getWebElement(getResource("profileLanguageInput"))
      .getText();
    return userLocale;
  }

  public async navigateToAccountSettings() {
    console.log("Navigate to account settings..");
    await this.navigateToProfileSettings();
    await this.webActionHandler
      .getWebElement(getResource("accountSettings"))
      .click();
    expect(
      await this.webActionHandler.getWebElement(
        getResource("profileAccountTitle")
      ).isVisible
    ).toBeTruthy();
    console.log("Navigated to account settings!");
  }

  public async navigateToProfileSettings() {
    console.log("Navigate to profile settings..");
    await this.webActionHandler
      .getWebElement(getResource("analyseMyData"))
      .waitFor();
    await this.webActionHandler.getWebElement(getResource("profile")).click();
    await this.webActionHandler
      .getWebElement(getResource("profileSettings"))
      .click();
    expect(
      await this.webActionHandler.getWebElement(
        getResource("profileSettingsTitle")
      ).isVisible
    ).toBeTruthy();
    console.log("Navigated to profile settings!");
  }
}
