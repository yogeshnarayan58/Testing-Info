import { DataSetTypeName } from '@nielsen/crf-common';

const dataSetTypeNameMap: Record<string, string> = (DataSetTypeName ?? {}) as Record<string, string>;

export function buildDatasetDisplay(
  datasetConfig: any,
  requestInstance?: any,
): string {
  const productOfferingCode = datasetConfig?.productOfferingCode ?? requestInstance?.productOfferingCode;
  const datasetTypeName = dataSetTypeNameMap[String(productOfferingCode ?? '')]
    || datasetConfig?.type
    || requestInstance?.type
    || '';

  const datasetTitle = datasetConfig?.title
    ?? datasetConfig?.label
    ?? requestInstance?.datasetLabel
    ?? '';

  const dataViewName = datasetConfig?.dataView?.dataViewName
    ?? requestInstance?.dataViewName
    ?? '';

  const displayParts = [
    datasetTypeName ? `NielsenIQ ${datasetTypeName}` : 'NielsenIQ',
    datasetTitle,
    dataViewName,
  ].filter((value) => typeof value === 'string' && value.trim().length > 0);

  return displayParts.join(' | ');
}
