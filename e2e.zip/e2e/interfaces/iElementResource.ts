import { PageElement } from '@gfk/gta';

export interface ElementResource {
  name: string;
  webElements: PageElement[];
}