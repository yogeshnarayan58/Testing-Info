# disc-fe-omnishopper-ui-automation
To install all required npm packages mentioned in package.json file, execute below command in terminal
`npm install`

## Environment Setup
1. Copy `.env.example` to `.env`: `cp .env.example .env`
2. Open `.env` file and replace placeholder values with actual automation service account credentials
3. Update `USER_NAME` with your automation email and `PASS_WORD` with your password
4. ⚠️ Never commit the `.env` file - it contains sensitive credentials and is already in `.gitignore`

To run a single report with headed mode (to auto open browser and test)
`npm run test:headed <test file name.spec.ts>`
For example `npm run test:headed combination-purchase-analysis.spec.ts`

To run a single report with debug mode
`npm run test:debug <test file name.spec.ts>`
For example `npm run test:debug combination-purchase-analysis.spec.ts`

To run a single report with headed mode (to auto open Playwright UI window and test)
`npm run test:ui <test file name.spec.ts>`
For example `npm run test:ui combination-purchase-analysis.spec.ts`


## GTA Package Migration (GitLab -> JFrog)
If package install fails for `@gfk/*`, ensure your local setup follows JFrog migration.

1. Ensure JFrog access is available for your account.
2. Generate/get a JFrog read token and keep it private.
3. Set environment variable as `JFROG_RO_PASSWORD`.
     - Windows PowerShell:
         - `setx JFROG_RO_PASSWORD "<your_jfrog_token>"`
         - Open a new terminal after running `setx`.
4. Ensure project `.npmrc` uses JFrog registries and `${JFROG_RO_PASSWORD}` token.
5. Reinstall dependencies from project root:
     - `npm install`
     - `npx playwright install`

## Validate Setup
- `npm view @gfk/gta version`
- `npm view @gfk/azure-login version`
- `npm ls @gfk/gta`

## Common Issues
- `403` for `@gfk/*` packages:
    - Verify `JFROG_RO_PASSWORD` is set and non-empty.
    - Verify `.npmrc` is correct.
    - If still failing, request `@gfk` entitlement via Data Platform/JFrog support.
- Token not picked up:
    - Restart terminal/session.
    - Re-check env variable in shell.
    - Run `npm install` again.

## Troubleshooting Checklist
- [ ] JFrog account available
- [ ] Access request approved (if required)
- [ ] `JFROG_RO_PASSWORD` configured
- [ ] `.npmrc` updated to JFrog registries
- [ ] Dependencies reinstalled
- [ ] `@gfk/gta` resolves successfully
- [ ] Smoke tests pass

## Reference
- [Onboarding to GTA](https://adlm.nielseniq.com/confluence/spaces/DPTD/pages/647677072/Onboarding+to+GTA)