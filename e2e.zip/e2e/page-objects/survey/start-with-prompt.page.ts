import { BasePage, WebActions } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { ELEMENT_WAIT_TIMEOUT, SMALL_TIMEOUT, NAVIGATION_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';
import startWithPromptPageResources from '../../locators/survey/start-with-prompt.locator.json';
import { searchAndSelectDataset as searchAndSelectDatasetHelper } from '../common/dataset-selection.helper';

const START_WITH_PROMPT_PAGE_COMPONENT_NAME = 'startWithPromptPage';

export const OMNISHOPPER_OFFERING_DATA_TEST_ID = 'rv-dataset-type-selector1';

export class StartWithPromptPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      START_WITH_PROMPT_PAGE_COMPONENT_NAME,
      startWithPromptPageResources
    );
  }

  /** Throws (unlike `waitFor()`, which does not throw on timeout in this framework) if `element` isn't visible within `timeoutMs`. */
  private async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  private getResource(name: string) {
    return this.resourceManager.getResource(name, START_WITH_PROMPT_PAGE_COMPONENT_NAME);
  }

  /** Races `action` against `timeoutMs` since hover/click have no native timeout param, so an occluded/unreachable element fails fast instead of hanging. */
  private async withTimeout<T>(action: Promise<T>, timeoutMs: number, step: string): Promise<T> {
    let timer!: ReturnType<typeof setTimeout>;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${step} timed out after ${timeoutMs}ms`)), timeoutMs);
    });
    try {
      return await Promise.race([action, timeoutPromise]);
    } finally {
      clearTimeout(timer);
    }
  }

  async clickStartWithPrompt(): Promise<void> {
    try {
      const startWithPrompt = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('startWithPrompt', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await startWithPrompt.waitFor(SMALL_TIMEOUT);
      await startWithPrompt.click();
    } catch (error) {
      throw new Error(`Failed to click Start with a prompt: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDatasetTypeSelectorVisible(index = 0): Promise<boolean> {
    try {
      const datasetTypeSelector = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('datasetTypeSelector', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeSelector.waitFor(SMALL_TIMEOUT);
      return datasetTypeSelector.isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check dataset type selector visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectDatasetType(offeringDataTestId: string): Promise<void> {
    try {
      const datasetTypeOption = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('omnishopperOfferingTile', offeringDataTestId, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeOption.waitFor(SMALL_TIMEOUT);

      const tileClass = await datasetTypeOption.getAttribute('class').catch(() => null);
      const isAlreadySelected = (tileClass ?? '').includes('dataset-type-wrapper-selected');
      if (!isAlreadySelected) {
        await datasetTypeOption.click();
      }

      const nextDatasetButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('nextDatasetButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await nextDatasetButton.waitFor(SMALL_TIMEOUT);
      await nextDatasetButton.click();
    } catch (error) {
      throw new Error(`Failed to select dataset type "${offeringDataTestId}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async searchAndSelectDataset(searchTerm: string, datasetLabel: string): Promise<boolean> {
    try {
      return await searchAndSelectDatasetHelper(
        this.webActionHandler,
        this.resourceManager,
        START_WITH_PROMPT_PAGE_COMPONENT_NAME,
        searchTerm,
        datasetLabel,
        {
          datasetResourceKey: 'datasetByText',
          searchToggleResourceKey: 'datasetSearchToggle',
          searchInputResourceKey: 'datasetSearchInput'
        }
      );
    } catch (error) {
      throw new Error(`Failed to search and select dataset "${datasetLabel}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async applyDataset(): Promise<void> {
    try {
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const applyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('applyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();

      const dialogElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dialogElement', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );

      const isChooseViewDialogShown = await dialogElement.isVisible(SMALL_TIMEOUT).catch(() => false);
      if (!isChooseViewDialogShown) {
        return;
      }

      await dialogElement.waitFor(SMALL_TIMEOUT);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();
    } catch (error) {
      throw new Error(`Failed to apply dataset: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillPromptAndGenerate(promptText: string): Promise<void> {
    try {
      const promptTextarea = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('promptTextarea', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await promptTextarea.waitFor(SMALL_TIMEOUT);
      await promptTextarea.enterText(promptText);

      const generateSurveyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('generateSurveyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await generateSurveyButton.waitForEnabled(ELEMENT_WAIT_TIMEOUT);
      await generateSurveyButton.click();
    } catch (error) {
      throw new Error(`Failed to fill prompt and generate survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickGenerateQuestions(): Promise<void> {
    try {
      const generateButton = this.webActionHandler.getWebElement(this.getResource('generateQuestionsButton'));
      await this.waitUntilVisible(generateButton, 'Generate questions button');
      await generateButton.click();
    } catch (error) {
      throw new Error(`Failed to click Generate questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Question type tile on the Customize Questions screen, identified by its QuestionType value (e.g. 'SINGLE_CHOICE'). */
  async selectQuestionType(value: string): Promise<void> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(tile, `Question type tile (${value})`);
      await this.withTimeout(tile.click(), ELEMENT_WAIT_TIMEOUT, `Click question type tile (${value})`);
    } catch (error) {
      throw new Error(`Failed to select question type "${value}": ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Selection reflects as the exact "active" CSS class token, not a `state` attribute. */
  async isQuestionTypeSelected(value: string): Promise<{ selected: boolean; outerHtml: string }> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      const classAttr = (await tile.getAttribute('class')) ?? '';
      const outerHtml = String(await tile.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { selected: classAttr.split(/\s+/).includes('active'), outerHtml };
    } catch (error) {
      throw new Error(`Failed to check question type "${value}" selected state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Generate-more/Describe share the same disabled-state gating as Add Question/Duplicate (state/aria-disabled/niqtooltip attributes). */
  private async getDisabledState(resourceName: string): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    const button = this.webActionHandler.getWebElement(this.getResource(resourceName));
    const state = await button.getAttribute('state');
    const ariaDisabled = await button.getAttribute('aria-disabled');
    const tooltip = await button.getAttribute('niqtooltip');
    const outerHtml = String(await button.executeScript((e) => e.outerHTML)).slice(0, 400);
    return { disabled: state === 'disabled' || ariaDisabled === 'true', tooltip, outerHtml };
  }

  async getGenerateMoreQuestionsDisabledState(): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    try {
      return await this.getDisabledState('suggestNewQuestionsButton');
    } catch (error) {
      throw new Error(`Failed to get Generate-more-questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getDescribeQuestionsDisabledState(): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    try {
      return await this.getDisabledState('repromptNewQuestionsButton');
    } catch (error) {
      throw new Error(`Failed to get Describe-questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Same `.question-number` marker preview-mode renders per question. When `atLeast` is given, polls (AI generation is async) until the count reaches it or `timeoutMs` elapses. */
  async getGeneratedQuestionCount(atLeast?: number, timeoutMs: number = NAVIGATION_TIMEOUT): Promise<number> {
    try {
      const readCount = async () => (await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'))).length;
      let count = await readCount();
      if (atLeast === undefined) {
        return count;
      }
      const start = Date.now();
      while (count < atLeast) {
        if (Date.now() - start >= timeoutMs) {
          throw new Error(`Timed out waiting for question count to reach ${atLeast} (current: ${count})`);
        }
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        count = await readCount();
      }
      return count;
    } catch (error) {
      throw new Error(`Failed to get generated question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `.question-actions` is only revealed via `.question-row`'s mouseenter handler, not CSS :hover. Scope to a single row via nth. */
  private getQuestionRowElement(index: number) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index}`
    });
  }

  /** Hovers row `index` to reveal Rephrase with AI, submits `promptText`, and waits for the request to finish; no panel-closed assertion since the panel may stay open after success. */
  async rephraseQuestion(index: number, promptText: string): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await row.hover();

      const rephraseButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseWithAiButton', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
      await rephraseButton.click();

      const rephraseInput = this.webActionHandler.getWebElement(this.getResource('rephraseInput'));
      // Retry exactly once if the panel didn't open; never retry when already open (a second click would close it).
      let panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (!panelOpened) {
        console.warn('rephrase panel did not open after first click, retried');
        await this.webActionHandler.mouseMove(0, 0);
        await row.hover();
        await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
        await rephraseButton.click();
        panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      }
      if (!panelOpened) {
        throw new Error(`Rephrase panel (index ${index}) did not open after retry`);
      }
      await rephraseInput.enterText(promptText);

      const rephraseSendButton = this.webActionHandler.getWebElement(this.getResource('rephraseSendButton'));
      await this.waitUntilVisible(rephraseSendButton, `Rephrase send button (index ${index})`);

      await rephraseSendButton.click();

      const rephraseSendLoading = this.webActionHandler.getWebElement({
        elementName: 'rephraseSendLoading',
        selectorType: 'css',
        selectorValue: '.rephrase-send-loading'
      });
      // waitFor() doesn't throw on timeout; isHidden() is a real instant check (unlike isVisible(0), which waits forever), so we use it to confirm state and throw ourselves.
      await rephraseSendLoading.waitFor(NAVIGATION_TIMEOUT, 'hidden');
      if (!(await rephraseSendLoading.isHidden())) {
        throw new Error(`Rephrase send button (index ${index}) stayed in loading state after ${NAVIGATION_TIMEOUT}ms`);
      }

      await this.webActionHandler.mouseMove(0, 0); // move off the row so the hover doesn't linger into the next test

      // Only fail if the box is still visible AND still has text; `isVisible(SMALL_TIMEOUT)` bounds the read so a closed panel is never queried.
      const panelStillOpen = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (panelStillOpen) {
        const promptValue = await rephraseInput.getValue();
        if (promptValue !== '') {
          throw new Error(`Rephrase prompt input (index ${index}) was not cleared after submit, value: "${promptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to rephrase question ${index}: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSuggestNewQuestions(): Promise<void> {
    try {
      const suggestButton = this.webActionHandler.getWebElement(this.getResource('suggestNewQuestionsButton'));
      await this.waitUntilVisible(suggestButton, 'Suggest new questions (Generate more questions) button');
      await suggestButton.click();
      await suggestButton.waitForEnabled(NAVIGATION_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to click Suggest new questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Opens "Describe questions to add", types `promptText`, submits, and waits for the panel to close. */
  async describeAndSubmitReprompt(promptText: string): Promise<void> {
    try {
      const repromptButton = this.webActionHandler.getWebElement(this.getResource('repromptNewQuestionsButton'));
      await this.waitUntilVisible(repromptButton, 'Describe questions to add button');
      await repromptButton.click();

      const repromptInput = this.webActionHandler.getWebElement(this.getResource('repromptInput'));
      await this.waitUntilVisible(repromptInput, 'Reprompt input');
      await repromptInput.enterText(promptText);

      const repromptSubmitButton = this.webActionHandler.getWebElement(this.getResource('repromptSubmitButton'));
      await this.waitUntilVisible(repromptSubmitButton, 'Reprompt submit button');
      await repromptSubmitButton.click();

      await repromptInput.waitFor(NAVIGATION_TIMEOUT, 'hidden');
      // Tolerant check: the panel may stay open (empty) or close after success.
      if (await repromptInput.isVisible(SMALL_TIMEOUT)) {
        const repromptValue = await repromptInput.getValue();
        if (repromptValue !== '') {
          throw new Error(`Reprompt panel did not close or clear after submit, value: "${repromptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to describe and submit reprompt: ${error instanceof Error ? error.message : error}`);
    }
  }
}