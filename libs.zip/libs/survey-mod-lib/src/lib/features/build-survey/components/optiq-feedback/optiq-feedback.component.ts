import {
  ChangeDetectionStrategy,
  Component,
  computed,
  ElementRef,
  inject,
  input,
  output,
  signal,
  viewChild,
} from '@angular/core';
import { CommonSidePanelComponent } from '../../../../shared/components/common-side-panel/common-side-panel.component';
import { HeaderImgConfig } from '../../../../shared/components/common-side-panel/common-side-panel.model';
import {
  AiSuggestion,
  OPTIQ_FEEDBACK_ACTIONS,
  QuestionModel,
  SuggestionAction,
  SuggestionActionType,
  SuggestionConfig,
  SUGGESTION_SEVERITY,
  SURVEY_SUGGESTIONS_STATE,
} from '../../models/build-survey';
import { ButtonModule, IconModule, SpinnerModule } from '@nielseniq/athena-core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SurveyService } from '../../services/survey.service';
import { ValidationService } from '../../services/validation.service';

// Applying fixes is instant, so the loader is kept visible for a minimum time.
const FIX_ALL_MIN_LOADER_MS = 500;

interface FixAllItem {
  questionId: string;
  suggestion: AiSuggestion;
  actionType: SuggestionActionType;
}

@Component({
  selector: 'survey-optiq-feedback',
  standalone: true,
  imports: [CommonSidePanelComponent, ButtonModule, TranslateModule, IconModule, SpinnerModule],
  templateUrl: './optiq-feedback.component.html',
  styleUrl: './optiq-feedback.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OptiqFeedbackComponent {
  readonly open = input(false);
  readonly isApplyingAll = signal(false);
  readonly closeRequested = output<void>();
  readonly optiqFeedbackActions = OPTIQ_FEEDBACK_ACTIONS;
  readonly surveyService = inject(SurveyService);
  private readonly validationService = inject(ValidationService);
  readonly translateService = inject(TranslateService);
  readonly SuggestionActionType = SuggestionActionType;
  readonly suggestionSeverity = SUGGESTION_SEVERITY;
  readonly statusMessage = signal('');
  readonly feedbackContainer = viewChild<ElementRef<HTMLElement>>('feedbackContainer');
  // Set once the help page URL is available.
  readonly learnMoreUrl = '';
  readonly headerImgConfig: HeaderImgConfig =
    { imgSrc: 'assets/images/optiq.svg', altText: 'optiq icon' };


  readonly questions = this.surveyService.questions;
  readonly surveyAIValidationState = this.validationService.surveyAIValidationState;
  readonly surveySuggestionState = this.validationService.surveySuggestionState;
  readonly suggestionState = SURVEY_SUGGESTIONS_STATE;
  readonly mandatorySuggestionCount = computed(() =>
    this.validationService.countSuggestions(this.questions(), SUGGESTION_SEVERITY.MANDATORY)
  );
  readonly optionalSuggestionCount = computed(() =>
    this.validationService.countSuggestions(this.questions(), SUGGESTION_SEVERITY.OPTIONAL)
  );
  readonly hasSuggestions = computed(
    () => this.mandatorySuggestionCount() > 0 || this.optionalSuggestionCount() > 0
  );

  readonly questionsWithSuggestions = computed(() =>
    this.questions().filter((question) => question.suggestions?.length)
  );

  readonly subheader = computed(() => {
    const mandatory = this.mandatorySuggestionCount();
    const total = mandatory + this.optionalSuggestionCount();

    if (total === 0) {
      return '';
    }

    const changes = total === 1 ? `${total} change found` : `${total} changes found`;
    return mandatory > 0
      ? `${changes} (${mandatory} required to publish)`
      : `${changes} (none required)`;
  });

  /**
   * Builds suggestion labels, icons, and action visibility based on the action type,
   * severity, target field, and suggested text.
   */
  getSuggestionConfig(suggestion: AiSuggestion): SuggestionConfig {
    const actions = this.optiqFeedbackActions;
    const isMandatory = suggestion.severity === SUGGESTION_SEVERITY.MANDATORY;
    const isLabel =
      suggestion.fieldPath === 'npsLeftLabel' ||
      suggestion.fieldPath === 'npsRightLabel';
    const isOption =
      !!suggestion.fieldPath?.startsWith('options[') ||
      !!suggestion.fieldPath?.startsWith('rowOptions[') ||
      !!suggestion.fieldPath?.startsWith('columnOptions[');

    let config: Pick<SuggestionConfig, 'title' | 'buttonLabel' | 'showComparison' | 'showDismiss'>;

    switch (suggestion.action) {
      case SuggestionActionType.ADD_OPTION:
        config = {
          title: actions.addOption,
          buttonLabel: actions.add,
          showComparison: false,
          showDismiss: !isMandatory,
        };
        break;

      case SuggestionActionType.REPHRASE:
        config = {
          title: actions.rephrase,
          buttonLabel: actions.rephrase,
          showComparison: true,
          showDismiss: !isMandatory,
        };
        break;

      case SuggestionActionType.REMOVE:
        config = {
          title: isLabel ? actions.removeLabel : isOption ? actions.removeOption : actions.removeQuestion,
          buttonLabel: isLabel ? null : actions.remove,
          showComparison: false,
          showDismiss: !isMandatory || isLabel,
        };
        break;

      case SuggestionActionType.REVIEW:
      default:
        config = {
          title: actions.reviewSuggestion,
          buttonLabel: null,
          showComparison: false,
          showDismiss: true,
        };
        break;
    }

    const requiresSuggestedText =
      suggestion.action === SuggestionActionType.ADD_OPTION ||
      suggestion.action === SuggestionActionType.REPHRASE;

    const hasSuggestedText = !!suggestion.suggestedText?.trim();
    return {
      ...config,
      iconName: isMandatory ? 'error' : 'triangle-alert',
      isMandatory,
      buttonLabel: requiresSuggestedText && !hasSuggestedText ? null : config.buttonLabel,
      showDismiss: config.showDismiss || (requiresSuggestedText && !hasSuggestedText),
    };
  }

  /** Accessible name for an action button, naming the question it belongs to. */
  getActionAriaLabel(actionLabel: string, question: QuestionModel): string {
    const action = this.translateService.instant(actionLabel);
    const number = question.questionNumber;

    return `${action}, question ${number}`;
  }

  //Applies the selected suggestion action, announces resolution, and restores focus.
  handleSuggestionAction(
    id: string,
    actionType: SuggestionAction | SuggestionActionType,
    suggestion?: AiSuggestion
  ): void {
    if (!suggestion || !id) {
      return;
    }

    this.dispatchSuggestionAction(id, actionType, suggestion);
    this.announce('Suggestion resolved.');
  }

  private dispatchSuggestionAction(
    id: string,
    actionType: SuggestionAction | SuggestionActionType,
    suggestion: AiSuggestion
  ): void {
    switch (actionType) {
      case SuggestionActionType.ADD_OPTION:
        this.commitSuggestionChange(
          this.validationService.applyAddOptionSuggestion(this.questions(), id, suggestion)
        );
        break;

      case SuggestionActionType.REPHRASE:
        this.commitSuggestionChange(
          this.validationService.rephraseSuggestion(this.questions(), id, suggestion)
        );
        break;

      // REVIEW has no outcome to apply, so resolving it just removes the suggestion.
      case SuggestionActionType.REVIEW:
      case SuggestionActionType.DISMISS:
        this.commitSuggestionChange(
          this.validationService.dismissSuggestion(this.questions(), id, suggestion.suggestionId)
        );
        break;

      case SuggestionActionType.REMOVE:
        if (suggestion.fieldPath === 'question') {
          const questionIndex = this.questions().findIndex((question) => question.id === id);
          if (questionIndex !== -1) {
            this.surveyService.removeQuestion(questionIndex);
            this.validationService.syncAfterSuggestionChange(this.questions());
          }
        } else {
          this.commitSuggestionChange(
            this.validationService.removeOptionSuggestion(this.questions(), id, suggestion)
          );
        }
        break;
    }
  }

  private commitSuggestionChange(questions: QuestionModel[]): void {
    this.surveyService.setQuestions(questions);
    this.validationService.syncAfterSuggestionChange(this.surveyService.getQuestions());
  }

  async handleFixAll(): Promise<void> {
    if (this.isApplyingAll()) {
      return;
    }

    const fixes = this.getFixableSuggestions();
    if (fixes.length === 0) {
      return;
    }

    this.isApplyingAll.set(true);
    const startedAt = Date.now();
    const totalBefore = this.mandatorySuggestionCount() + this.optionalSuggestionCount();

    try {
      // Let the loader render before the synchronous updates run.
      await this.wait(0);

      fixes.forEach(({ questionId, suggestion, actionType }) =>
        this.dispatchSuggestionAction(questionId, actionType, suggestion)
      );

      await this.wait(Math.max(0, FIX_ALL_MIN_LOADER_MS - (Date.now() - startedAt)));
    } finally {
      this.isApplyingAll.set(false);
      const count =
        totalBefore - (this.mandatorySuggestionCount() + this.optionalSuggestionCount());
      const message = count === 1 ? `${count} suggestion applied.` : `${count} suggestions applied.`;
      this.announce(message);
    }
  }

  /** Updates the live region and moves focus into the panel, since the clicked control is removed. */
  private announce(message: string): void {
    this.statusMessage.set(message);
    setTimeout(() => this.feedbackContainer()?.nativeElement.focus());
  }

  private getFixableSuggestions(): FixAllItem[] {
    const optionIndex = (fieldPath: string): number => {
      const match = fieldPath?.match(/\[(\d+)\]$/);
      return match ? Number(match[1]) : -1;
    };

    const resolveAction = (suggestion: AiSuggestion): SuggestionActionType | null => {
      const hasSuggestedText = !!suggestion.suggestedText?.trim();

      switch (suggestion.action) {
        case 'REMOVE':
          return SuggestionActionType.REMOVE;
        case 'ADD_OPTION':
          return hasSuggestedText ? SuggestionActionType.ADD_OPTION : null;
        case 'REPHRASE':
          return hasSuggestedText ? SuggestionActionType.REPHRASE : null;
        case 'REVIEW':
          return suggestion.severity === SUGGESTION_SEVERITY.OPTIONAL && !hasSuggestedText
            ? SuggestionActionType.REVIEW
            : null;
        default:
          return null;
      }
    };

    return this.questionsWithSuggestions().flatMap((question) => {
      const questionId = question.id;
      if (!questionId) {
        return [];
      }

      return (
        (question.suggestions ?? [])
          .map((suggestion) => ({ questionId, suggestion, actionType: resolveAction(suggestion) }))
          .filter((item): item is FixAllItem => item.actionType !== null)
          // Process higher indices first to prevent changes at lower indices from invalidating remaining suggestion positions.
          .sort((a, b) => optionIndex(b.suggestion.fieldPath) - optionIndex(a.suggestion.fieldPath))
      );
    });
  }

  private wait(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  getOriginalText(question: QuestionModel, fieldPath: string): string {
    if (fieldPath === 'question') {
      return question.question;
    }

    if (fieldPath === 'npsLeftLabel' || fieldPath === 'npsRightLabel') {
      return question?.[fieldPath] ?? '';
    }

    const match = fieldPath?.match(/^(options|rowOptions|columnOptions)\[(\d+)\]$/);

    if (!match) {
      return '';
    }

    const [, field, index] = match;
    const values = question[field as 'options' | 'rowOptions' | 'columnOptions'];

    return values?.[Number(index)] ?? '';
  }

  onCloseRequested(): void {
    this.closeRequested.emit();
  }
}
