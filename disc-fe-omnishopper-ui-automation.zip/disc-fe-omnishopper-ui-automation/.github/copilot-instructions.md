
# Copilot Instructions for OmniShopper UI Automation

## Project Overview
Enterprise Playwright automation framework for OmniShopper reporting platform using @gfk/gta library. Tests 25+ report types with page object model architecture and centralized resource management.

## Core Patterns

### Resource Management (Critical - HIGH PRIORITY)
All selectors defined in JSON files, accessed via `ResourceManager`. Never hardcode selectors:
```typescript
// Correct
const element = this.webActionHandler.getWebElement(
  this.resourceManager.getResource("elementName", "ComponentName")
);

// Avoid
const element = page.locator("[data-test-id='some-id']");
```

**🚨 CRITICAL: Resource JSON Structure**
Resources MUST follow the GTA framework's `PageElement` interface with **EXACTLY 3 attributes**:
```typescript
// ✅ CORRECT - Only 3 attributes (as per @gfk/gta PageElement interface)
{
  "elementName": "addBlankReportOption",
  "selectorType": "tag",
  "selectorValue": "li.select-menu--item:has-text('Add blank report')"
}

// ❌ WRONG - 4 attributes (description is NOT part of PageElement interface)
{
  "elementName": "addBlankReportOption",
  "selectorType": "tag",
  "selectorValue": "li.select-menu--item:has-text('Add blank report')",
  "description": "This violates the PageElement interface"  // ❌ REMOVE THIS
}
```

**PageElement Interface (from @gfk/gta):**
```typescript
export interface PageElement {
    elementName: string;    // Required
    selectorType: string;   // Required
    selectorValue: string;  // Required
}
```

**Rules:**
- ✅ Use ONLY: `elementName`, `selectorType`, `selectorValue`
- ❌ NEVER add: `description`, `comment`, or any other fields
- ✅ Keep descriptions in code comments if needed for clarity
- ❌ Adding extra fields will cause type mismatches and runtime errors

### Component Architecture
- **Base Classes**: Extend `CommonTestCase` for shared functionality
- **Page Objects**: In `src/lib/common/pages/` 
- **Components**: In `src/lib/common/components/`
- **Resources**: JSON files with `elementName`, `selectorType`, `selectorValue`

### Standard Test Flow
```typescript
// 1. Initialize via BasePageFactory
let basePage = await BasePageFactory.createBasePage();
let component = new ComponentName(basePage);

// 2. Navigate and configure
await component.navigateToUrl(reportUrl);
await dataSelector.clickMadlibDimension("Period");
await dataSelector.setMadlibSelection(testData.dimensions);

// 3. Execute and validate
await commonTestCase.clickRunButton();
await commonTestCase.waitForReportRunCompletion();
```

## Development Workflows

### Environment Setup
1. `cp .env.example .env` and configure credentials
2. `npm install && npx playwright install`
3. Tests use `storage/auth.json` from global setup

### Test Commands
- Debug: `npm run test report-name.spec.ts --debug`
- Headed: `npm run test report-name.spec.ts --headed`
- UI Mode: `npm run test report-name.spec.ts --ui`
- Reports: `npm run allure:generate && npm run allure:open`

## Framework Conventions

### Timeouts (Use Constants)
```typescript
import { MAX_TEST_TIMEOUT, RUN_TEST_TIMEOUT, NAVIGATION_TIMEOUT, SMALL_TIMEOUT } from '../constants/time-out-constants';
```

### Configuration
Environment-specific URLs via `config.BASE_URL` (resolves DEV/SI/UAT from ENV var)

### Test Data Pattern
```typescript
const reportTestData = findDataSetByName(devTestData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData);
```

### Error Handling
Always include descriptive error messages:
```typescript
try {
  await element.click();
} catch (error) {
  throw new Error(`Failed to click ${elementName}: element not visible or clickable.`);
}
```

## AI-Enhanced Development Tips

### When Adding New Tests
1. Copy existing report structure from similar test type
2. Update resource JSON with new selectors (prefer `data-test-id`)
3. Use dynamic resources for variable content: `getDynamicResource(name, text, component)`
4. Follow naming convention: `elementName` should be descriptive and unique

### When Fixing Broken Tests
1. Check if selector changed in resource JSON first
2. Use browser dev tools to verify current selector
3. Consider multiple fallback selectors for critical elements
4. Update both primary and backup selectors in resources

### Component Creation Pattern
```typescript
export class NewComponent extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources("ComponentName", componentResources);
  }
  
  // Always include error handling and wait conditions
  public async clickElement(): Promise<void> {
    const element = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("elementName", "ComponentName")
    );
    try {
      await element.waitFor();
      await element.click();
    } catch (error) {
      throw new Error("Failed to click element: not visible or clickable.");
    }
  }
}
```

## Integration Points
- **@gfk/gta**: Core library providing `BasePage`, `WebActions`, `PageElement`
- **Allure**: Rich reporting with screenshots and traces
- **Multi-env**: DEV/SI/UAT support via environment variables

---

## PR Review Guidelines for Copilot

When reviewing pull requests, enforce these standards strictly.

### 🚨 Critical Checks (Block Merge)

#### 1. Resource JSON Structure (HIGHEST PRIORITY)
**Rule**: EXACTLY 3 attributes only (`elementName`, `selectorType`, `selectorValue`)

✅ **APPROVE**:
```json
{
  "elementName": "saveButton",
  "selectorType": "tag",
  "selectorValue": "[data-test-id='save-btn']"
}
```

❌ **REJECT**:
```json
{
  "elementName": "saveButton",
  "selectorType": "tag",
  "selectorValue": "[data-test-id='save-btn']",
  "description": "Save button"  // ❌ REMOVE - violates PageElement interface
}
```

#### 2. Selector Priority Hierarchy
**Follow this order strictly** (best to worst):

1. **`data-test-id`** (HIGHEST PRIORITY) - Use `selectorType: "tag"`
   ```json
   {
     "elementName": "submitButton",
     "selectorType": "tag",
     "selectorValue": "[data-test-id='submit-btn']"
   }
   ```

2. **`id`** - Use `selectorType: "id"`
   ```json
   {
     "elementName": "submitButton",
     "selectorType": "id",
     "selectorValue": "submit-btn"
   }
   ```

3. **`css`** - Use `selectorType: "css"`
   ```json
   {
     "elementName": "errorMessage",
     "selectorType": "css",
     "selectorValue": "error-text"
   }
   ```

4. **`xpath`** - Use `selectorType: "xpath"`
   ```json
   {
     "elementName": "dynamicElement",
     "selectorType": "xpath",
     "selectorValue": "//button[@id='submit']"
   }
   ```

5. **`tag`** - Complex selectors (NO `data-test-id`, `#`, or `.` simple patterns)
   ```json
   {
     "elementName": "menuItem",
     "selectorType": "tag",
     "selectorValue": "li.menu-item:has-text('Dashboard')"
   }
   ```

6. **`text`** (LAST RESORT - Warn developer)
   ```json
   {
     "elementName": "loginButton",
     "selectorType": "text",
     "selectorValue": "Log In"
   }
   ```

#### 3. Common Mistakes to Flag

**❌ REJECT - Using "tag" when "id" should be used:**
```json
{
  "elementName": "submitButton",
  "selectorType": "tag",
  "selectorValue": "#submit-btn"  // ❌ Has # prefix = ID selector!
}
```
**Fix**: Change to `selectorType: "id"` and remove `#`:
```json
{
  "elementName": "submitButton",
  "selectorType": "id",
  "selectorValue": "submit-btn"
}
```

**❌ REJECT - Using "tag" for simple CSS class:**
```json
{
  "elementName": "errorMessage",
  "selectorType": "tag",
  "selectorValue": ".error-text"  // ❌ Simple class = CSS selector!
}
```
**Fix**: Change to `selectorType: "css"` and remove `.`:
```json
{
  "elementName": "errorMessage",
  "selectorType": "css",
  "selectorValue": "error-text"
}
```

**⚠️ WARN - Using "text" selector:**
```markdown
⚠️ **Warning: Text-Based Selector (Fragile)**

**Location**: `path/to/resource.json:42`

**Issue**: Text selectors break with UI copy changes, localization, or whitespace modifications.

**Current**:
\`\`\`json
{
  "elementName": "loginButton",
  "selectorType": "text",
  "selectorValue": "Log In"
}
\`\`\`

**Action Required**: Before approving, verify the element doesn't have:
1. ✅ `data-test-id` attribute (most preferred)
2. ✅ `id` attribute
3. ✅ Unique CSS class
4. ✅ Stable xpath or tag selector

**If no alternatives exist**: Developer must confirm and document why text selector is necessary.
```

#### 4. No Hardcoded Selectors in Code
❌ **REJECT**:
```typescript
const element = page.locator("[data-test-id='save-btn']");
const button = await page.getByRole('button', { name: 'Save' });
```

✅ **APPROVE**:
```typescript
const element = this.webActionHandler.getWebElement(
  this.resourceManager.getResource("saveButton", "ComponentName")
);
```

#### 5. Security & Credentials
❌ **REJECT**:
- Hardcoded URLs (must use `config.BASE_URL`)
- Credentials in code
- API keys in source
- `.env` file committed

#### 6. Timeout Constants
❌ **REJECT**: `{ timeout: 30000 }`
✅ **APPROVE**: Import from `time-out-constants.ts`

#### 7. Error Handling
❌ **REJECT**: Silent failures or generic errors
✅ **APPROVE**: Descriptive error messages with context

#### 8. Test Isolation - No .only()
❌ **REJECT**: Using `.only()` in committed code
```typescript
test.only('should validate report', async () => { }); // ❌ Causes CI to run only this test
describe.only('Dashboard tests', () => { }); // ❌ Causes CI to run only this suite
```

✅ **APPROVE**: Clean test declarations
```typescript
test('should validate report', async () => { }); // ✅ Correct
describe('Dashboard tests', () => { }); // ✅ Correct
```

**Why**: `.only()` is for local debugging. When committed, CI will run **only** this test/suite and ignore all others → False positive results (looks like everything passes when other tests are not even running).

**Comment Template**:
```markdown
🚨 **Critical: Test Isolation Violation**

**Location**: `tests/reports/dashboard.spec.ts:15`

**Problem**: Found `.only()` modifier - this causes CI to run only this test and ignore all others

**Current**:
\`\`\`typescript
test.only('should load dashboard', async () => {
  // test code
});
\`\`\`

**Fix**: Remove `.only()` modifier
\`\`\`typescript
test('should load dashboard', async () => {
  // test code
});
\`\`\`

**Why**: `.only()` is for local debugging. When committed, it prevents other tests from running, causing false positive CI results.
```

### ⚠️ Important Checks (Request Changes)

- Components extend proper base class
- Resources registered in constructor
- Test data externalized in JSON
- Naming conventions: camelCase (methods), PascalCase (classes), UPPER_SNAKE_CASE (constants)
- Wait conditions before interactions
- JSDoc comments for public methods

### Selector Type Validation Rules

When reviewing `*-resource.json` files, check each resource:

1. **Has exactly 3 keys** (`elementName`, `selectorType`, `selectorValue`)
2. **Validate selectorType matches selectorValue pattern:**
   - `[data-test-id='...']` → Must use `selectorType: "tag"`
   - Starts with `#` → Must use `selectorType: "id"` (not "tag")
   - Starts with `.` (simple class) → Must use `selectorType: "css"` (not "tag")
   - Starts with `xpath=` or `//` → Must use `selectorType: "xpath"`
   - Plain text or `text=...` → Must use `selectorType: "text"` and warn
   - Complex (multiple conditions) → `selectorType: "tag"` is OK

3. **Flag misuse of "tag" type:**
   - If `selectorValue` has `#id` → Change to `"id"` type
   - If `selectorValue` has `.class` alone → Change to `"css"` type
   - If `selectorValue` has `data-test-id` → Keep `"tag"` type ✅

### Example Review Comments

**For wrong selectorType:**
```markdown
⚠️ **Important: Incorrect selectorType**

**Location**: `src/lib/pages/login/login-resources.json:15`

**Problem**: Using `"tag"` for ID selector

**Current**:
\`\`\`json
{
  "elementName": "submitButton",
  "selectorType": "tag",
  "selectorValue": "#submit-btn"
}
\`\`\`

**Fix**: Use `"id"` type
\`\`\`json
{
  "elementName": "submitButton",
  "selectorType": "id",
  "selectorValue": "submit-btn"
}
\`\`\`

**Why**: `#` prefix indicates ID selector. Using correct `selectorType` aligns with framework's `getPlaywrightSelectorSyntax()` and selector priority hierarchy.
```

**For data-test-id (correct usage):**
```markdown
✅ **Good: Proper data-test-id usage**

Using `selectorType: "tag"` with `data-test-id` is correct:
\`\`\`json
{
  "elementName": "submitButton",
  "selectorType": "tag",
  "selectorValue": "[data-test-id='submit-btn']"
}
\`\`\`

This follows the priority hierarchy (data-test-id is highest priority).
```


### Quick Reference & Framework Context

| Selector Pattern              | selectorType   | Priority/Notes                        | Framework Transformation Example                |
|-------------------------------|----------------|---------------------------------------|-------------------------------------------------|
| `[data-test-id='...']`        | `tag`          | ✅ Highest priority                   | Returns as-is                                  |
| `#elementId`                  | `id`           | Use `id`, not `tag`                   | Adds `#` if missing: `submit-btn` → `#submit-btn` |
| `.className`                  | `css`          | Use `css`, not `tag`                  | Adds `.` if missing: `error-text` → `.error-text` |
| `//xpath`                     | `xpath`        | Use `xpath`, not `tag`                | Adds `xpath=` if missing: `//div` → `xpath=//div` |
| `text content`                | `text`         | ⚠️ Warn: fragile, use only if needed  | Adds `text=` if missing: `Submit` → `text=Submit` |
| `button.class[attr]` (complex)| `tag`          | ✅ For complex selectors               | Returns as-is                                  |
| Playwright native             | `playwrights`  | Use for advanced/edge cases           | Returns as-is                                  |

---

## Error Handling

- Wrap multi-step UI flows in `try/catch` blocks and include contextual logs.
- All error messages must be descriptive (avoid generic messages like `"Failed"`).
- On selector resolution failures, log:
  - selector key  
  - component name  

### Error Handling — Correct vs Incorrect Examples

#### ✔ Correct Example — Error Enrichment + Logging + Rethrow
```ts
async applyDateRange(range: string) {
  try {
    await this.dateRangeSelector.waitFor({ state: "visible" });
    await this.dateRangeSelector.click();
    await this.selectRange(range);
  } catch (err) {
    throw new Error(`Date range selection failed for range: ${range}`);
  }
}
```

#### ✘ Incorrect Example — Missing Context
```ts

async loadReport() {
  try {
    await page.click("#load");
  } catch (err) {
    throw new Error("Something went wrong");
  }
}
```
---
## No Hard‑Coded Selectors in spec.ts or .ts Files (Mandatory Rule)

All selectors must be retrieved from JSON resource files through the `ResourceManager`.  
Direct or hard‑coded selectors are strictly prohibited in:

- `*.spec.ts` test files  
- Page Object files (`*.ts`)  
- Component classes  

### ✔ Correct Usage (Using ResourceManager)
```ts
const applyButton = this.webActionHandler.getWebElement(
  this.resourceManager.getResource("applyButton", "FilterPanel")
);
await applyButton.click();
```
---
## localization-data.json Instructions

- Only these fields: (locale, title, description, solutionType,pivotMadlibText,MadlibText,businessQuestions,businessObjectives) must be defined in `localization-data.json`.
- Do not hardcode any display text in test scripts, page objects, or components.
- Each key in `localization-data.json` should be descriptive and unique to its usage context.
- Ensure all supported locales/languages are included for every key.
- When adding new features or reports, update `localization-data.json` with all required translations.
- **No extra fields** (e.g., `comment`) allowed

---
## dev-test-data.json Instructions

- All test data for reports must be defined in `dev-test-data.json` (or equivalent test data files).
- Do not hardcode test data in test scripts, page objects, or components.
- Each key should be descriptive and unique to its usage context (e.g., dataset, scenario, or locale).
- When adding new tests or features, update the test data JSON with all required data sets.
- Use helper functions to select test data by dataset and locale in your tests.

---
## Reports Folder Instructions

- Each report must have its own subfolder under the `reports` directory (e.g., `src/lib/tests/reports/<report-name>`).
- Each report subfolder should contain:
  - The main `.spec.ts` test file for that report.
  - A `test-data` subfolder for all test data JSON files related to that report.
  - A `resources` subfolder for all resource JSON files (selectors) for that report.
- Keep report-specific page objects and components in their respective folders, but reference them from the report's test file as needed.
- Do not mix test data or resources between different report subfolders.

## .spec.ts File Instructions

- Each test file must be named using the pattern `<report-name>.spec.ts` and placed in the appropriate report subfolder.
- Do not use `.only` or `.skip` in committed test files.

- **Test Structure:**  
  - Use Playwright's `test.describe` to group related tests for the report.
  - Each test method should validate a single, well-defined scenario (e.g., QuickLook, Insights Panel, Format Panel, Pivot selection, Configure Panel, People prompt, Madlib validation, Run Report, Export, Snapshot, No Data).
  - Use descriptive test names and tags for clarity and filtering.

- **Setup & Data:**  
  - Import and use helper functions for test data and localization (e.g., `findDataSetByName`, `getTestDataByLocale`).
  - All test data and localization must be externalized in JSON files; never hardcode values in the test.
  - Use `config.BASE_URL` for URLs; do not hardcode URLs.

- **Selectors & Page Objects:**  
  - All selectors must be accessed via ResourceManager and resource JSON files.
  - Use page object and component classes for all UI interactions (e.g., `DataSelector`, `CommonTestCase`, `FormatPanel`, `InsightsPanel`).
  - Do not use direct Playwright selectors in the test file.

- **Test Data Coverage:**  
  - Cover all major flows: QuickLook, Insights, Format Panel, Pivot, Configure Panel, People, Madlib, Run Report, Export, Snapshot, No Data.
  - Use helper methods for repeated flows (e.g., `runReportWithData`).
  - For Retailer and Geography Pivot spec files cover only the 'run report'.
---

## Workflow Integration for New spec.ts Files

Whenever a new `*.spec.ts` file is introduced into the repository, all related GitHub workflow YAML files must be updated to ensure the test is included in every applicable execution flow.

### Requirements
- Update all relevant GitHub Actions workflows—such as:
  - manual-automation-test-run workflows  
  - scheduler-report-after-run-batch-3 workflows  

---


