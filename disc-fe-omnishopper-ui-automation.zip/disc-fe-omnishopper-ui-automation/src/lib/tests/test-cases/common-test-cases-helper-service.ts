import { assert, BasePage, WebActions } from "@gfk/gta";
import * as resources from "./commonTestCasesResources.json";
import { checkDefaultFormatPanel } from "../components/formatPanel";
import { DataSelector } from "../../common/components/data-selector/data-selector";
import { MAX_TEST_TIMEOUT } from "../../constants/time-out-constants";
import { ReportLocalizationData } from "../../common/models/data-model";

let dataSelector: DataSelector;

// Function to retrieve a resource from the object repository by name
export function getResource(s: string) {
  return resources.webElements.find((x) => x.elementName === s)!;
}

export class CommonTestCases {
  webActionHandler: WebActions;
  constructor(basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
  }

  public async searchReportInAllTemplate(
    basePage: BasePage,
    dataset: string,
    context: any,
    pivot?: string
  ) {
    console.log("Logging in...");
    let value: any;
    await this.webActionHandler
      .getWebElement(getResource("analyseMyData"))
      .waitFor();
    await this.webActionHandler
      .getWebElement(getResource("analyseMyData"))
      .click();
    await this.webActionHandler
      .getWebElement(getResource("chooseAtemplate"))
      .click();
    console.log("Logging in...");
    await this.webActionHandler
      .getWebElement(getResource("inputSearchIcon"))
      .click();
    console.log("Logging in...");
    await this.webActionHandler
      .getWebElement(getResource("inputSearch"))
      .enterText("combination purchase analysis");
    await this.webActionHandler
      .getWebElement(getResource("cardTitle"))
      .waitFor();
    console.log(
      "cartitle:",
      await this.webActionHandler
        .getWebElement(getResource("cardTitle"))
        .isVisible()
    );
    value = await this.webActionHandler.getWebElementsText(
      getResource("cardTitle")
    );
    await this.webActionHandler
        .getWebElement(getResource("cardTitle"))
        .hover();
        await this.webActionHandler
        .getWebElement(getResource("quickLookInfoButton"))
        .click();
    console.log("Login completed", value);
    return value;
  }

  public async runReport(
    reportTestData: any,
    dataset: string,
    basePage: BasePage,
    pivot?: string
  ) {
    // await waitUntilVisible(ANALYZE_MY_DATA, { timeout: MAX_TIMEOUT });
    // const reportModule = reportTestCases[specificReportCases];
    // if (reportModule) {
    //   reportTestData = await reportModule.getReportTestData("dev");
    //   console.log("dynamic test data");
    //   console.log("reportModule:", reportModule);
    //   console.log(reportTestData);
    // } else {
    //   console.error(`No report module found for: ${specificReportCases}`);
    // }
    await this.webActionHandler
      .getWebElement(getResource("analyseMyData"))
      .waitFor();
    const url = reportTestData['NavUrlWithDataSetId'];
    const BASE_URL = process.env.BASE_URL_SI as string;
    console.log("reportURL from process:", process.env.BASE_URL);
    const reportURL = BASE_URL + url;
    console.log("Final report URL:", reportURL);

    // Log any network responses with errors
    // getPage().on("response", (response) => {
    //   if (response.status() >= 400) {
    //     console.error("Failed request:", response.url(), response.status());
    //   }
    // });

    // Navigate to the report URL with extended timeout and wait for the page to fully load
    try {
      // await getPage().goto(reportURL, { waitUntil: "load", timeout: 60000 });
      await this.webActionHandler.navigateTo(reportURL);
      console.log("After page load");
      dataSelector = new DataSelector(basePage);
      // await checkDefaultFormatPanel(reportTestData, dataset); //Todo: convert these logic with gta
      await dataSelector.selectDimensionValues(reportTestData, dataset, pivot);
      await this.webActionHandler.getWebElement(getResource("reportRunButton")).waitFor();
      await this.webActionHandler.getWebElement(getResource("reportRunButton")).click();
      // await waitUntilVisible('[data-test-id="rb-report-btn-run"]', {
      //   timeout: MAX_TIMEOUT,
      // });
      // await getPage().click('[data-test-id="rb-report-btn-run"]');
      console.log("run clicked");
      await this.webActionHandler.getWebElement(getResource("inProgressCancel")).waitFor();
      console.log("inprogress clicked");
      try {
        // await getPage().waitForSelector('[data-test-id="ds-progressCancel"]', {
        //   state: "detached",
        //   timeout: MAX_TIMEOUT,
        // });
        console.log("Report run cancel!");
        await this.webActionHandler.getWebElement(getResource("inProgressCancel")).waitFor(MAX_TEST_TIMEOUT, "detached");
        await this.webActionHandler.getWebElement(getResource("inProgressCancel")).waitFor(MAX_TEST_TIMEOUT, "hidden");
        // await this.webActionHandler.getWebElement(getResource("saveIcon")).waitFor();
        // await this.webActionHandler.getWebElement(getResource("saveIcon")).click();
        // await this.webActionHandler.getWebElement(getResource("makeAcopy")).click();
        // await this.webActionHandler.getWebElement(getResource("reportTitle")).waitFor();
        // let reporttitle = await this.webActionHandler.getWebElement(getResource("reportTitle")).getText();
        // console.log("Report title:", reporttitle);
      } catch (error) {
        console.error(
          "Timeout reached: Cancel button did not disappear in the given time."
        );
      }
    } catch (error) {
      console.error("Error navigating to report URL:", error);
    }
  }

  public async presentationMode(
    reportTestData: any,
    dataset: string,
    context: any,
    basePage: BasePage,
    pivot?: string
  ) {
      try {
        console.log("Validating Presentation Mode!");
        await this.webActionHandler.getWebElement(getResource("presentationIcon")).waitFor();
        await this.webActionHandler.getWebElement(getResource("presentationIcon")).click();
        let pagination = await this.webActionHandler.getWebElement(getResource("presentationPagination")).isVisible();
        let datasetInfo = await this.webActionHandler.getWebElement(getResource("datasetInfo")).isVisible();
        let niqIcon = await this.webActionHandler.getWebElement(getResource("niqIcon")).isVisible();
        assert(pagination).toBeTruthy();
        assert(datasetInfo).toBeTruthy();
        assert(niqIcon).toBeTruthy();
        await this.webActionHandler.getWebElement(getResource("exitButton")).waitFor();
        await this.webActionHandler.getWebElement(getResource("exitButton")).click();
      } catch (error) {
        console.error(
          "Validation failed in Presentation Mode!:", error
        );
      }
    
  }

  public async fullScreenView(
    reportTestData: any,
    dataset: string,
    context: any,
    basePage: BasePage,
    pivot?: string
  ) {
      try {
        console.log("Validating Full!");
        await this.webActionHandler.getWebElement(getResource("expandIcon")).waitFor();
        await this.webActionHandler.getWebElement(getResource("expandIcon")).click();
        await this.webActionHandler.getWebElement(getResource("closeExpandViewIcon")).waitFor();
        let storyButton = await this.webActionHandler.getWebElement(getResource("closeExpandViewIcon")).isVisible();
        let closeExpandViewIcon = await this.webActionHandler.getWebElement(getResource("closeExpandViewIcon")).isVisible();
        assert(storyButton).toBeTruthy();
        assert(closeExpandViewIcon).toBeTruthy();
        await this.webActionHandler.getWebElement(getResource("closeExpandViewIcon")).click();
      } catch (error) {
        console.error(
          "Failed while clicking full screen mode:", error
        );
      }
    
  }

  public async makeAcopy(
    reportTestData: any,
    dataset: string,
    context: any,
    basePage: BasePage,
    pivot?: string
  ) {
      try {
        console.log("Report run cancel!");
        await this.webActionHandler.getWebElement(getResource("inProgressCancel")).waitFor(MAX_TEST_TIMEOUT, "detached");
        await this.webActionHandler.getWebElement(getResource("inProgressCancel")).waitFor(MAX_TEST_TIMEOUT, "hidden");
        await this.webActionHandler.getWebElement(getResource("saveIcon")).waitFor();
        await this.webActionHandler.getWebElement(getResource("saveIcon")).click();
        await this.webActionHandler.getWebElement(getResource("makeAcopy")).click();
        await this.webActionHandler.getWebElement(getResource("reportTitle")).waitFor();
        await this.webActionHandler.getWebElement(getResource("reportTitle")).click();
        await this.webActionHandler.getWebElement(getResource("reportTitle")).enterText(" omni automation");
        let reporttitle = await this.webActionHandler.getWebElement(getResource("reportTitle")).getAllInnerText();
        console.log("Report title:", reporttitle);
      } catch (error) {
        console.error(
          "Failed to make a copy:", error
        );
      }
    
  }
}

export function getLocalizationElement(
  element: keyof ReportLocalizationData,
  language: string,
  localeData: ReportLocalizationData[]
): string | string[] | undefined {
  const report = localeData.find((data) => data.locale === language);

  if (report) {
    return report[element];
  }

  return undefined;
}

export function getDataElement(
  element: keyof any,
  localeData: any[],
  id: string
): string | string[] | undefined {
  const report = localeData.find((data) => data.id === id);
  if (report) {
    return report[element].toString().trim();
  }
  return undefined;
}
