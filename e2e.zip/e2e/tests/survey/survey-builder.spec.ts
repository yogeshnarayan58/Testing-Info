import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory } from '../../utils/base-page-factory';
import { assertTrue } from '../../page-objects/common/assert-utils';
import { StartFromScratchPage } from '../../page-objects/survey/start-from-scratch.page';
import { completePanelistSelectionFlow } from '../../page-objects/common/panelist-flow.helper';
import { SurveyBuilderPage } from '../../page-objects/survey/surveyBuilder.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import devTestData from '../../test-data/dev-test-data.json';

const datasetNames = Object.keys(devTestData.datasets) as Array<keyof typeof devTestData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = devTestData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Survey Builder', () => {
  let basePage: BasePage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      const page = (BasePage as any).page as import('playwright').Page | undefined; // gta exposes no public getter for the raw Page
      const video = page?.video();
      await basePage.getWebActions().closeBrowser(); // closes the context, which finalizes the .webm file
      const videoPath = await video?.path().catch(() => undefined);
      if (videoPath) {
        await testInfo.attach('survey-builder-video', { path: videoPath, contentType: 'video/webm' });
      } else {
        console.log('Survey Builder suite: video path unavailable');
      }
    }
  });

  test('Setup: reach Build Survey page via Start from Scratch', { tag: '@SurveyBuilderSetup' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    const startFromScratchPage = new StartFromScratchPage(basePage);
    await startFromScratchPage.navigateToSurvey();
    await startFromScratchPage.clickStartFromScratch();

    await startFromScratchPage.selectProductOffering('');
    const isDatasetSelectionConfirmed = await startFromScratchPage.searchAndSelectDataset(
      datasetConfig.searchTerm,
      String(DATASET_NAME)
    );
    assertTrue(isDatasetSelectionConfirmed, `Expected "Choose a dataset" confirmation not visible after selecting ${DATASET_NAME}`);

    await startFromScratchPage.proceedToNextAfterDatasetSelection();
    await startFromScratchPage.applyEntireDataset();

    const reachedBuildSurvey = await completePanelistSelectionFlow(basePage, datasetConfig.dimensionSelections);

    assertTrue(reachedBuildSurvey, 'Expected to land on Build Survey page after panelist selection flow');
  });

  test('TC_BS_02: Edit survey title', { tag: '@EditSurveyTitle' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.setSurveyTitle(devTestData.surveyQuestions.surveyTitle);
  });

  test('TC_BS_03: Add a Single Choice question', { tag: '@SingleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText, options } = devTestData.surveyQuestions.singleChoice;

    await surveyBuilderPage.addSingleChoiceQuestion(questionText, options);
  });

  test('TC_BS_04: Add a Multiple Choice question', { tag: '@MultipleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, options } = devTestData.surveyQuestions.multipleChoice;

    await surveyBuilderPage.addMultipleChoiceQuestion(questionText, options);
  });

  test('TC_BS_05: Add a Rating question', { tag: '@RatingQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = devTestData.surveyQuestions.rating;

    await surveyBuilderPage.addRatingQuestion(questionText);
  });

  test('TC_BS_07: Add an NPS question', { tag: '@NPSQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = devTestData.surveyQuestions.nps;

    await surveyBuilderPage.addNPSQuestion(questionText);
  });

  test('TC_BS_08: Add a Point Scale question', { tag: '@PointScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = devTestData.surveyQuestions.pointScale;

    await surveyBuilderPage.addPointScaleQuestion(questionText, rows, columns);
  });

  test('TC_BS_09: Add a Multi Scale question', { tag: '@MultiScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = devTestData.surveyQuestions.multiScale;

    await surveyBuilderPage.addMultiScaleQuestion(questionText, rows, columns);
  });

  test('TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey', { tag: '@StepperNavigation' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const selectPanelistPage = new SelectPanelistPage(basePage);
    const EXPECTED_RESPONSE_COUNT_TEST_ID = 'select-response-count-250'; // Setup used click250Responses()

    try {
      await surveyBuilderPage.clickAddQuestion();
      const { questionText } = devTestData.surveyQuestions.rating;
      await surveyBuilderPage.addRatingQuestion(questionText);
      const questionNumbersBefore = await surveyBuilderPage.getQuestionNumbers();

      await surveyBuilderPage.clickSelectPanelistsStep();

      assertTrue(
        await selectPanelistPage.isProceedToSurveyBuilderVisible(),
        'proceed-to-survey visible after stepper navigation'
      );
      const currentUrl = await selectPanelistPage.getCurrentUrl();
      assertTrue(currentUrl.includes('select-panelist'), `URL contains select-panelist (got ${currentUrl})`);

      const selectedResponseCountTestId = await selectPanelistPage.getSelectedResponseCountDataTestId();
      assertTrue(
        selectedResponseCountTestId === EXPECTED_RESPONSE_COUNT_TEST_ID,
        `response count retained (expected ${EXPECTED_RESPONSE_COUNT_TEST_ID}, got ${selectedResponseCountTestId})`
      );
      // The 5 dimension filters (Product/Retailer/Geography/Demographic/Period) have no stable
      // "currently selected" locator in select-panelist.locator.json — `filledDimensionTile` needs
      // the exact rendered dimension label text, which isn't confirmed in source, so it's skipped
      // rather than guessed.

      await selectPanelistPage.clickProceedToSurveyBuilder();
      assertTrue(
        await selectPanelistPage.isBuildSurveyPageLoaded(),
        'Build Survey page visible after Proceed'
      );

      const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(
        questionNumbersAfter.length === questionNumbersBefore.length,
        `question count retained (expected ${questionNumbersBefore.length}, got ${questionNumbersAfter.length})`
      );
    } catch (error) {
      throw new Error(`Failed to verify stepper navigation retains data: ${error instanceof Error ? error.message : error}`);
    }
  });

  test('TC_BS_MAX_QUESTIONS: Max questions (10) disables Add question and Duplicate with limit message', { tag: '@MaxQuestions' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText: ratingText } = devTestData.surveyQuestions.rating;

    try {
      let questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      while (questionNumbers.length < 10) {
        const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
        if (addQuestionState.disabled) {
          break;
        }
        await surveyBuilderPage.clickAddQuestion();
        await surveyBuilderPage.addRatingQuestion(ratingText);
        questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      }

      assertTrue(
        questionNumbers.length === 10,
        `Expected 10 questions, got ${questionNumbers.length}: ${JSON.stringify(questionNumbers)}`
      );

      assertTrue(
        await surveyBuilderPage.isAddQuestionTooltipVisibleOnHover(),
        'limit message after hover on add'
      );
      const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
      assertTrue(
        addQuestionState.disabled,
        `add-question disabled (class="${addQuestionState.classAttr}")`
      );

      assertTrue(
        await surveyBuilderPage.isDuplicateTooltipVisibleOnHover(),
        'limit message after hover on duplicate'
      );
      const duplicateState = await surveyBuilderPage.getDuplicateDisabledState();
      assertTrue(
        duplicateState.disabled,
        `duplicate disabled (outerHTML="${duplicateState.outerHtml}")`
      );

      const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(questionNumbersAfter.length === 10, 'count stays 10');
    } catch (error) {
      throw new Error(`Failed to verify max-questions limit: ${error instanceof Error ? error.message : error}`);
    }
  });

  test('TC_BS_13: Review Mode controls and per-question checkboxes are visible', { tag: '@ReviewModeControls' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    try {
      await surveyBuilderPage.enterReviewMode();

      const controlsVisible = await surveyBuilderPage.areReviewControlsVisible();
      assertTrue(controlsVisible, 'Expected Select All, Expand All, Collapse All, Delete, Exit Review Mode buttons to be visible');

      const questionCount = await surveyBuilderPage.getQuestionCount();
      const checkboxCount = await surveyBuilderPage.getReviewCheckboxCount(questionCount);
      assertTrue(checkboxCount === questionCount, `Expected one checkbox per question (${questionCount}), found ${checkboxCount}`);
    } catch (error) {
      throw new Error(`Failed to verify Review Mode controls: ${error instanceof Error ? error.message : error}`);
    }
  });

  test('TC_BS_14: Review Mode select all, de-select one, delete, and exit keeps deletions', { tag: '@ReviewModeActions' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    try {
      await surveyBuilderPage.collapseAll();
      await surveyBuilderPage.expandAll();
      const questionCountBeforeDelete = await surveyBuilderPage.getQuestionCount();
      await surveyBuilderPage.selectAll();

      for (let index = 0; index < questionCountBeforeDelete; index++) {
        assertTrue(await surveyBuilderPage.isQuestionSelected(index), `Expected checkbox ${index} to be ticked after Select All`);
      }

      await surveyBuilderPage.selectQuestionInReview(0);
      assertTrue(!(await surveyBuilderPage.isQuestionSelected(0)), 'Expected question 0 checkbox to clear after de-selecting it');
      for (let index = 1; index < questionCountBeforeDelete; index++) {
        assertTrue(await surveyBuilderPage.isQuestionSelected(index), `Expected checkbox ${index} to remain ticked after de-selecting question 0`);
      }

      await surveyBuilderPage.deleteSelectedQuestions();
      const deletedCount = questionCountBeforeDelete - 1;
      const questionCountAfterDelete = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        questionCountAfterDelete === questionCountBeforeDelete - deletedCount,
        `Expected question count to drop by ${deletedCount}, found ${questionCountAfterDelete}`
      );

      const questionNumbersAfterDelete = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(
        questionNumbersAfterDelete.every((number, idx) => number.trim() === `${idx + 1}.`),
        'Expected remaining questions to be renumbered sequentially'
      );

      await surveyBuilderPage.exitReviewMode();
      const questionCountAfterExit = await surveyBuilderPage.getQuestionCount();
      assertTrue(questionCountAfterExit === questionCountAfterDelete, 'Expected Build Survey view to keep deletions after exiting Review Mode');
    } catch (error) {
      throw new Error(`Failed to complete Review Mode actions flow: ${error instanceof Error ? error.message : error}`);
    }
  });

  test('TC_BS_REVIEW_MODE: Review mode select, delete, select/unselect all, expand/collapse all, exit', { tag: '@ReviewMode' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    try {
      await surveyBuilderPage.ensureQuestionCount(3);

      await surveyBuilderPage.enterReviewMode();

      const countBeforeDelete = await surveyBuilderPage.getQuestionCount();
      await surveyBuilderPage.selectQuestionInReview(0);
      await surveyBuilderPage.deleteSelectedQuestions();
      const countAfterDelete = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfterDelete === countBeforeDelete - 1, 'Expected question count to drop by 1 after delete');

      await surveyBuilderPage.selectAll();
      await surveyBuilderPage.unselectAll();

      await surveyBuilderPage.expandAll();
      await surveyBuilderPage.collapseAll();

      await surveyBuilderPage.exitReviewMode();
    } catch (error) {
      throw new Error(`Failed to complete Review Mode flow: ${error instanceof Error ? error.message : error}`);
    }
  });

test('TC_BS_SAVE_DRAFT: Save survey as draft', { tag: '@SaveDraft' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const title = `SaveDraft_${Date.now()}`;
    await surveyBuilderPage.saveDraft(title);
    const isToastVisible = await surveyBuilderPage.isDraftSavedToastVisible();
    assertTrue(isToastVisible, 'Expected "Survey saved as draft successfully" toast to be visible after saving draft');
  });

  test('TC_BS_PUBLISH: Publish survey', { tag: '@PublishSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const title = `Publish_${Date.now()}`;
    const SELECTED_RESPONSE_COUNT = 250; // Setup used click250Responses()

    await surveyBuilderPage.ensureQuestionCount(3);

    await surveyBuilderPage.publishSurvey(title);

    const areDimensionsShown = await surveyBuilderPage.isPublishDialogDimensionCountVisible(datasetConfig.dimensionSelections.length);
    assertTrue(areDimensionsShown, `Expected ${datasetConfig.dimensionSelections.length} dimension selections in Confirm publish? dialog`);

    const responseSummaryText = await surveyBuilderPage.getPublishResponseSummaryText();
    assertTrue(
      responseSummaryText.includes(String(SELECTED_RESPONSE_COUNT)),
      `Expected "${SELECTED_RESPONSE_COUNT} responses" in Confirm publish? dialog, got "${responseSummaryText}"`
    );

    const confirmClickTime = Date.now();
    const isPublishConfirmed = await surveyBuilderPage.confirmPublish();
    assertTrue(isPublishConfirmed, 'Expected "Confirm publish?" prompt and "Publishing survey" status to appear');

    const isSuccessToastVisible = await surveyBuilderPage.verifyPublishSucceeded(confirmClickTime);
    assertTrue(isSuccessToastVisible, 'Expected "Survey published successfully" message after publish');
  });
});