import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { FooterComponent } from './footer.component';
import { SurveyAIValidationState, SURVEY_VALIDATION_STATE } from '../../models/build-survey';

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('FooterComponent', () => {
  let component: FooterComponent;
  let mockTranslateService: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
    component = TestBed.runInInjectionContext(() => new FooterComponent());
  });

  describe('isPublishDisable input', () => {
    it('defaults publishing to enabled', () => {
      expect(component.isPublishDisable()).toBe(false);
    });

    it('disables publishing when input is true', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const isPublishDisable = signal(false);
        (testComponent as any).isPublishDisable = isPublishDisable.asReadonly();
        isPublishDisable.set(true);
        TestBed.tick();

        expect(testComponent.isPublishDisable()).toBe(true);
      });
    });
  });

  describe('surveyAIValidationInProgress computed property', () => {
    it('returns true when validation is in progress', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(true);
      });
    });

    it('returns false for readyForValidation state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });

    it('returns false for validationInReview state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });

    it('returns false for readyForPublish state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });

    it('returns false when state is null', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState | null>(null);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });
  });

  describe('buttonLabel computed property', () => {
    it('returns revalidate label for validationInReview state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_REVALIDATE_SURVEY');
      });
    });

    it('returns publish label for readyForPublish state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_REVIEW_PUBLISH_SURVEY');
      });
    });

    it('returns validateSurvey label for readyForValidation state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_VALIDATE_SURVEY');
      });
    });

    it('returns validateSurvey label as default for null state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState | null>(null);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_VALIDATE_SURVEY');
      });
    });

    it('returns validateSurvey label as default for unknown state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_VALIDATE_SURVEY');
      });
    });
  });

  describe('publish output', () => {
    it('emits when publish is requested', () => {
      let emitted = false;
      component.publish.subscribe(() => emitted = true);

      component.publish.emit();

      expect(emitted).toBe(true);
    });
  });

  describe('goBack output', () => {
    it('emits when going back is requested', () => {
      let emitted = false;
      component.goBack.subscribe(() => emitted = true);

      component.goBack.emit();

      expect(emitted).toBe(true);
    });
  });

  describe('validateSurvey output', () => {
    it('emits when validation is requested', () => {
      let emitted = false;
      component.validateSurvey.subscribe(() => emitted = true);

      component.validateSurvey.emit();

      expect(emitted).toBe(true);
    });
  });

  describe('onValidationAction method', () => {
    it('emits publish event when state is readyForPublish', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(true);
        expect(validateEmitted).toBe(false);
      });
    });

    it('emits validateSurvey event when state is not readyForPublish', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(true);
      });
    });

    it('emits validateSurvey event when state is validationInReview', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(true);
      });
    });

    it('emits validateSurvey event when state is null', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState | null>(null);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(true);
      });
    });

    it('emits validateSurvey event when state is validationInProgress', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(true);
      });
    });
  });
});
