import { MY_ASSETS_ROOT } from '../utils/survey-folder.util';
import { createEnvironmentInjector, Injector, runInInjectionContext, signal } from '@angular/core';
import type { DimensionSelection, Prompt } from '@nielsen/crf-common';
import { ACAssetManageApiService, ACFetchApiService } from '@nielsen/crf-lp-common';
import { TranslateService } from '@ngx-translate/core';
import { ToastService } from '@nielseniq/athena-core';
import { of, Subject, throwError } from 'rxjs';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import type { ReDataSetConfig } from '@nielsen/crf-rv-common';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { FLOW_TYPES, SURVEY_FLOW_STEPS } from '../../core/config/config';
import { SurveyCommonService } from './survey-common.service';

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  ACAssetManageApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

let mockTranslateService: any;

const createDatasetConfig = (id: string, title = 'Dataset'): ReDataSetConfig => ({
  id,
  type: 'test',
  title,
  description: '',
  hasLearnMore: false,
  apiKey: '',
  setConfig: vi.fn(),
});

describe('SurveyCommonService', () => {
  let service: SurveyCommonService;
  const folderApi = { getMyFolders: vi.fn() };
  const assetApi = { createAssetFolder: vi.fn() };
  const toast = { InsertToast: vi.fn() };

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    const injector = createEnvironmentInjector(
      [
        { provide: EnvironmentConfig, useValue: { appId: 'app-1', userId: 'user-1' } },
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: ACFetchApiService, useValue: folderApi },
        { provide: ACAssetManageApiService, useValue: assetApi },
        { provide: ToastService, useValue: toast },
      ],
      Injector.NULL as any,
    );

    service = runInInjectionContext(injector, () => new SurveyCommonService());
  });

  it('manages panel and flow state', () => {
    service.setPanelOpen(true);
    service.setFlowType(FLOW_TYPES.AIFLOW);

    expect(service.isPanelOpen()).toBe(true);
    expect(service.flowType()[FLOW_TYPES.AIFLOW]).toBe(true);

    service.setFlowType(undefined);
    expect(service.flowType()[FLOW_TYPES.SCRATCH]).toBe(true);
  });

  it('stores dataset and panelist selector state with deep clone', () => {
    const config = createDatasetConfig('ds-1', 'Dataset A');
    const selectorState = { datasetName: 'Demo', nested: { count: 1 } };

    service.setSelectedDatasetConfig(config);
    service.setPanelistDataSelectorState(selectorState);

    config.title = 'Dataset B';
    selectorState.nested.count = 2;

    expect(service.getSelectedDatasetConfig()?.title).toBe('Dataset A');
    expect(service.getPanelistDataSelectorState()?.nested?.count).toBe(1);
  });

  it('manages select-panelist ui state and completion', () => {
    service.setSelectPanelistUiState({ reportData: true, householdCount: '150' });

    expect(service.getSelectPanelistUiState()).toEqual({
      reportData: true,
      householdCount: '150',
      selectedResponses: null,
    });
    expect(service.hasCompletedPanelistSearch()).toBe(true);
  });

  it('tracks dataset footer visibility independently of the active step', () => {
    expect(service.datasetFooterVisible()).toBe(false);

    service.setDatasetFooterVisible(true);
    expect(service.datasetFooterVisible()).toBe(true);

    service.setDatasetFooterVisible(false);
    expect(service.datasetFooterVisible()).toBe(false);
  });

  it('tracks active survey step independently of route state', () => {
    expect(service.activeSurveyStep()).toBe(SURVEY_FLOW_STEPS.SELECT_PANELIST);

    service.setActiveSurveyStep(SURVEY_FLOW_STEPS.BUILD_SURVEY);
    expect(service.activeSurveyStep()).toBe(SURVEY_FLOW_STEPS.BUILD_SURVEY);

    service.setActiveSurveyStep(SURVEY_FLOW_STEPS.RESULTS);
    expect(service.activeSurveyStep()).toBe(SURVEY_FLOW_STEPS.RESULTS);

    service.resetState();
    expect(service.activeSurveyStep()).toBe(SURVEY_FLOW_STEPS.SELECT_PANELIST);
  });

  it('manages prompt, dimensions and dataview', () => {
    service.setUserPrompt('Prompt');
    service.setPanelistDimensionalValue({ DEMO: ['Adults'] });
    service.setDataViewId(' view-1 ');

    expect(service.getUserPrompt()).toBe('Prompt');
    expect(service.getPanelistDimensionalValue()).toEqual({ DEMO: ['Adults'] });
    expect(service.getDataViewId()).toBe('view-1');
  });

  it('hydrates partial session state and updates loading flag', () => {
    service.setSurveyLoading(true);
    service.hydrateSurveySessionState({
      userPrompt: 'Hydrated',
      selectPanelistUiState: { reportData: true, householdCount: '90', selectedResponses: 80 },
      dataViewId: 'view-2',
      selectedDatasetConfig: createDatasetConfig('ds-2'),
      selectedDatasetDisplay: 'Dataset 2',
      refreshedDate: '2026-09-01',
      panelistDataSelectorState: { reportSpec: { test: true } },
    });

    expect(service.surveyLoading()).toBe(false);
    expect(service.getUserPrompt()).toBe('Hydrated');
    expect(service.getPanelistDimensionalValue()).toEqual({});
    expect(service.getSelectPanelistUiState()).toEqual({
      reportData: true,
      householdCount: '90',
      selectedResponses: 80,
    });
    expect(service.getDataViewId()).toBe('view-2');
    expect(service.getSelectedDatasetDisplay()).toBe('Dataset 2');
    expect(service.getRefreshedDate()).toBe('2026-09-01');
  });

  it('extracts prompt labels and merges selections', () => {
    const prompts: Prompt[] = [
      { dimId: 'dim1', promptData: [{ promptSelectionLabel: 'A' }, { promptSelectionLabel: 'B' }] } as any,
      { id: 'dim2', promptData: [{ promptSelectionLabel: 'C' }] } as any,
    ];

    expect(service.extractPromptSelectionLabels(prompts)).toEqual({
      dim1: ['A', 'B'],
      dim2: ['C'],
    });

    const incoming: DimensionSelection[] = [
      { id: '1', children: [{ id: 'new' }] } as any,
      { id: '2', children: [{ id: 'child' }] } as any,
    ];
    const existing: DimensionSelection[] = [
      { id: '1', children: [{ id: 'old' }] } as any,
      { id: '3', children: [{ id: 'stay' }] } as any,
    ];

    const merged = service.mergeSelections(incoming, existing);
    expect(merged.map(item => item.id)).toEqual(expect.arrayContaining(['1', '2', '3']));
  });

  it('tracks coordination signals and resets state', () => {
    service.notifyDatasetSelected('Dataset-X');
    service.notifyPanelToggled(true);
    service.notifyCriteriaChanged();

    expect(service.getLastDatasetSelected()).toBe('Dataset-X');
    expect(service.getLastPanelToggledState()).toBe(true);
    expect(service.getCriteriaChangedTrigger()).toBe(1);

    service.resetState();

    expect(service.isPanelOpen()).toBe(false);
    expect(service.getLastDatasetSelected()).toBeNull();
    expect(service.getLastPanelToggledState()).toBeNull();
    expect(service.getCriteriaChangedTrigger()).toBe(0);
    expect(service.getUserPrompt()).toBe('');
  });

  it('resolves and merges user context values', () => {
    expect(service.getUserContext()).toEqual({
      userId: 'user-1',
      clientId: '',
      emailId: '',
      applicationId: 'app-1',
      locale: 'en-US',
    });

    service.setUserContext({ clientId: 'client-1' });
    service.setUserContext({ emailId: 'mail@example.com' });

    expect(service.getUserContext()).toEqual({
      userId: 'user-1',
      clientId: 'client-1',
      emailId: 'mail@example.com',
      applicationId: 'app-1',
      locale: 'en-US',
    });
  });

  it('normalizes null-ish state setters and trigger counters', () => {
    service.setSelectedDatasetConfig(null);
    service.setPanelistDataSelectorState(null);
    service.setPanelistDimensionalValue(null as any);
    service.setUserPrompt(null as any);
    service.setDataViewId(null);

    expect(service.getSelectedDatasetConfig()).toBeNull();
    expect(service.getPanelistDataSelectorState()).toBeNull();
    expect(service.getPanelistDimensionalValue()).toEqual({});
    expect(service.getUserPrompt()).toBe('');
    expect(service.getDataViewId()).toBeNull();

    expect(service.getDatasetPickerOpenTrigger()).toBe(0);
    service.requestDatasetPickerOpen();
    service.requestDatasetPickerOpen();
    expect(service.getDatasetPickerOpenTrigger()).toBe(2);
  });

  it('keeps non-current prompt selections only when either version has children', () => {
    const merged = service.mergeSelections(
      [
        { id: 'current', children: [] } as any,
        { id: 'incoming-children', children: [{ id: 'new' }] } as any,
        { id: 'empty', children: [] } as any,
      ],
      [
        { id: 'current', children: [{ id: 'old' }] } as any,
        { id: 'incoming-children', children: [] } as any,
        { id: 'existing-children', children: [{ id: 'kept' }] } as any,
        { id: 'empty', children: [] } as any,
      ],
      'current',
    );

    expect(merged.map(item => item.id).sort()).toEqual(['existing-children', 'incoming-children']);
  });

  it('ignores empty hydrate input and supports partial defaults', () => {
    service.setSurveyLoading(true);
    service.hydrateSurveySessionState(null as any);
    expect(service.surveyLoading()).toBe(true);

    service.hydrateSurveySessionState({
      selectPanelistUiState: { reportData: true } as any,
      selectedDatasetDisplay: null as any,
      refreshedDate: undefined,
      panelistDataSelectorState: null,
      dataViewId: '  view-77  ',
    });

    expect(service.surveyLoading()).toBe(false);
    expect(service.getSelectPanelistUiState()).toEqual({
      reportData: true,
      householdCount: '0',
      selectedResponses: null,
    });
    expect(service.getSelectedDatasetDisplay()).toBe('');
    expect(service.getRefreshedDate()).toBeNull();
    expect(service.getPanelistDataSelectorState()).toBeNull();
    expect(service.getDataViewId()).toBe('view-77');
  });

  it('leaves existing values unchanged when hydrate receives an empty object', () => {
    service.setUserPrompt('Keep me');
    service.setSelectedDatasetDisplay('Keep display');
    service.setRefreshedDate('keep-date');
    service.setDataViewId('view-keep');

    service.hydrateSurveySessionState({});

    expect(service.getUserPrompt()).toBe('Keep me');
    expect(service.getSelectedDatasetDisplay()).toBe('Keep display');
    expect(service.getRefreshedDate()).toBe('keep-date');
    expect(service.getDataViewId()).toBe('view-keep');
  });

  it('filters invalid incoming selections and prompt labels', () => {
    const merged = service.mergeSelections(
      [
        { id: 'A', children: [] } as any,
        { id: 'B', children: [{ id: 'b1' }] } as any,
      ],
      [
        { id: 'A', children: [{ id: 'a-old' }] } as any,
        { id: 'C', children: [{ id: 'c1' }] } as any,
      ]
    );

    expect(merged.map(item => item.id)).toEqual(expect.arrayContaining(['B', 'C']));
    expect(merged.map(item => item.id)).not.toContain('A');

    const labels = service.extractPromptSelectionLabels([
      { id: 'k1', promptData: [{ promptSelectionLabel: '' }, { promptSelectionLabel: 'X' }] } as any,
      { dimId: 'k2', promptData: [] } as any,
      { promptData: [{ promptSelectionLabel: 'ignored' }] } as any,
    ]);

    expect(labels).toEqual({ k1: ['X'] });
  });

  it('loads folders and handles an absent folder list', () => {
    const { context } = createContext();
    folderApi.getMyFolders.mockReturnValueOnce(of({ data: { assets: [{ assetId: 'folder-1' }] } })).mockReturnValueOnce(of({}));
    service.loadAndOpenFolderDialog(context.location, context.title, context.folders, context.isLoadingFolders, context.isSavingDraft);
    expect(context.folders()).toEqual([MY_ASSETS_ROOT, { assetId: 'folder-1', parentAsset: MY_ASSETS_ROOT }]);
    service.loadAndOpenFolderDialog(context.location, context.title, context.folders, context.isLoadingFolders, context.isSavingDraft);
    expect(context.folders()).toEqual([MY_ASSETS_ROOT]);
    expect(folderApi.getMyFolders).toHaveBeenCalledWith(['DISCOVERFOLDER']);
  });

  it('creates a folder in the selected parent', () => {
    const { context, location } = createContext();
    service.createFolderInSelectedLocation(context.location, context.create, context.folderDialogClosed, { title: 'New folder' });
    expect(assetApi.createAssetFolder).toHaveBeenCalledWith('DISCOVERFOLDER', 'New folder', location.folder);
  });

  it('shows errors and resets loaders when folder requests fail', () => {
    const { context, location, create } = createContext();
    folderApi.getMyFolders.mockReturnValue(throwError(() => new Error('Offline')));
    assetApi.createAssetFolder.mockReturnValue(throwError(() => new Error('Denied')));
    service.loadAndOpenFolderDialog(context.location, context.title, context.folders, context.isLoadingFolders, context.isSavingDraft);
    service.createFolderInSelectedLocation(context.location, context.create, context.folderDialogClosed, { title: 'New' });
    expect(location.open).not.toHaveBeenCalled();
    expect(create.close).not.toHaveBeenCalled();
    expect(context.isLoadingFolders()).toBe(false);
    expect(create.updateLoader).toHaveBeenCalled();
    expect(toast.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_FAILED_TO_LOAD_FOLDERS', expect.any(Object));
    expect(toast.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_FOLDER_CREATION_FAILED', expect.any(Object));
  });

const createContext = () => {
  const api = {
    getSurveyFolders: folderApi.getMyFolders.mockReturnValue(of({ data: { assets: [] } })),
    createSurveyFolder: assetApi.createAssetFolder.mockReturnValue(of({})),
  };
  const location = { open: vi.fn(), close: vi.fn(), emptyAssetSelection: vi.fn(), defaultTitle: '', folder: { assetId: 'parent' } };
  const create = { open: vi.fn(), close: vi.fn(), resetForm: vi.fn(), updateLoader: vi.fn() };
  const context = {
    location: location as any, create: create as any, title: 'Survey',
    folders: signal([]), isLoadingFolders: signal(false), isSavingDraft: signal(false),
    folderDialogClosed: new Subject<void>(),
  };
  return { context, api, location, create };
};

describe('folder dialog service methods', () => {
  it('keeps loading and folders isolated for each caller', () => {
    const first = createContext();
    const second = createContext();
    const firstPending = new Subject<any>();
    const secondPending = new Subject<any>();
    folderApi.getMyFolders
      .mockReturnValueOnce(firstPending)
      .mockReturnValueOnce(secondPending);

    service.loadAndOpenFolderDialog(first.context.location, first.context.title, first.context.folders, first.context.isLoadingFolders, first.context.isSavingDraft);
    service.loadAndOpenFolderDialog(second.context.location, second.context.title, second.context.folders, second.context.isLoadingFolders, second.context.isSavingDraft);

    expect(folderApi.getMyFolders).toHaveBeenCalledTimes(2);
    expect(first.context.isLoadingFolders()).toBe(true);
    expect(second.context.isLoadingFolders()).toBe(true);
    firstPending.next({ data: { assets: [{ assetId: 'folder-1' }] } });
    firstPending.complete();
    expect(first.context.folders()).toEqual([MY_ASSETS_ROOT, { assetId: 'folder-1', parentAsset: MY_ASSETS_ROOT }]);
    expect(second.context.folders()).toEqual([]);
    expect(first.location.defaultTitle).toBe('Survey');
    expect(first.context.isLoadingFolders()).toBe(false);
    expect(second.context.folders()).toEqual([]);
    expect(second.context.isLoadingFolders()).toBe(true);

    secondPending.next({ data: { assets: [{ assetId: 'folder-2' }] } });
    secondPending.complete();

    expect(second.context.folders()).toEqual([MY_ASSETS_ROOT, { assetId: 'folder-2', parentAsset: MY_ASSETS_ROOT }]);
    expect(second.context.isLoadingFolders()).toBe(false);
    expect(first.location.defaultTitle).toBe('Survey');
    expect(second.location.defaultTitle).toBe('Survey');
  });

  it('cancels creation when returning to the selector', () => {
    const { context, api, create, location } = createContext();
    const pending = new Subject<any>();
    api.createSurveyFolder.mockReturnValue(pending);
    location.defaultTitle = 'Edited';
    service.createFolderInSelectedLocation(context.location, context.create, context.folderDialogClosed, { title: 'New' });
    expect(api.createSurveyFolder).toHaveBeenCalledOnce();
    service.reopenFolderDialog(context.location, context.create, context.title, context.folders, context.isLoadingFolders, context.isSavingDraft, context.folderDialogClosed);
    pending.next({});
    expect(create.close).not.toHaveBeenCalled();
    expect(create.updateLoader).toHaveBeenCalled();
    expect(location.defaultTitle).toBe('Edited');
  });

  it('does not load folders while a draft is being saved', () => {
    const { context, api, location } = createContext();
    context.isSavingDraft = signal(true);
    service.loadAndOpenFolderDialog(context.location, context.title, context.folders, context.isLoadingFolders, context.isSavingDraft);
    expect(api.getSurveyFolders).not.toHaveBeenCalled();
    expect(location.open).not.toHaveBeenCalled();
    expect(context.isLoadingFolders()).toBe(false);
  });
});


});

