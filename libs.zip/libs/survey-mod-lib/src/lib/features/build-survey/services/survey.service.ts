import { MY_ASSETS_ROOT, toApiFolderId } from '../../../shared/utils/survey-folder.util';
import { HttpHeaders } from '@angular/common/http';
import { computed, DestroyRef, inject, Injectable, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AssignRightsHelperService, UserService } from '@nielsen/crf-lp-common';
import { EnvironmentConfig, ListCallDatasetService } from '@nielseniq/crf-discover-fe-core';
import {
  catchError,
  combineLatest,
  defer,
  finalize,
  map,
  Observable,
  of,
  switchMap,
  take,
  tap,
  throwError,
} from 'rxjs';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { buildDatasetDisplay } from '../../../shared/utils/survey-dataset-display.util';
import { RunReportService } from '../../select-panelist/services/run-report.service';
import { SelectPanelistUtilsService } from '../../select-panelist/utils.service';
import {
  ADD_MORE_QUESTIONS_DEFAULT_COUNT,
  AddMoreQuestionsPayload,
  ChannelName,
  createAddMoreQuestionsPayload,
  CreateSaveDraftPayloadParams,
  ExcludeQuestion,
  GenerateSurveyPayload,
  QuestionModel,
  QuestionType,
  QuestionTypes,
  RephraseQuestionsPayload,
  SaveDraftDynamics,
  SavedSurveyDetails,
  SaveSurveyResponse,
  SURVEY_ID_PREFIX,
  SURVEY_PAYLOAD_DEFAULTS,
  SurveyFolderSelection,
  SurveyStatusType,
} from '../models/build-survey';
import { buildDraftDatasetConfig, fromSavedOptionLabels, fromSavedQuestions, getExistingQuestionsTitle, resolveLaunchUrlByFlow } from './survey-data-mapper.util';
import { sanitizeFieldValue, toApiQuestion } from './survey-payload.util';
import { ValidationService } from './validation.service';
import { ApiService } from '../../../shared/services/api.service';

type GeneratedQuestionResponse = QuestionModel & {
  answerSpec?: {
    rows?: Array<{ label?: unknown }>;
  };
};
type GeneratedQuestionsResponse = { result: GeneratedQuestionResponse[]; title?: string };

type DatasetRefreshDetails = { id: string; stackId?: string; refreshedOn?: string | number };

function normalizeGeneratedQuestion(question: GeneratedQuestionResponse): QuestionModel {
  // AI responses store Star Rating labels in answerSpec.rows; the builder editor reads rowOptions.
  const rows = question.answerSpec?.rows ?? [];
  if (question.type !== QuestionTypes.StarRating || question.rowOptions?.length || !rows.length) {
    return question;
  }

  const { answerSpec, ...builderQuestion } = question;
  return {
    ...builderQuestion,
    rowOptions: fromSavedOptionLabels(rows),
  };
}

@Injectable({ providedIn: 'root' })
export class SurveyService {
  private readonly environment = inject(EnvironmentConfig);
  private readonly destroyRef = inject(DestroyRef);
  private readonly aiApiHttpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  private readonly _title = signal<string>('Untitled Survey');
  private readonly savedSurveyNameandDescState = signal<
    Readonly<{ name?: string; description?: string }>
  >({});
  readonly title = this._title.asReadonly();

  genState = signal<'idle' | 'loading' | 'done'>('idle');
  private readonly _questions = signal<QuestionModel[]>([]);
  readonly questions = this._questions.asReadonly();
  private readonly _loadedSurveyDetails = signal<SavedSurveyDetails | null>(null);
  readonly loadedSurveyDetails = this._loadedSurveyDetails.asReadonly();
  private readonly _questionTypes = signal<QuestionType[]>([]);
  readonly questionTypes = this._questionTypes.asReadonly();
  private readonly surveyId = signal<string | null>(null);
  private readonly currentAssetId = signal<string | null>(null);
  private readonly currentDataViewId = signal<string | null>(null);
  private readonly selectedFolder = signal<SurveyFolderSelection | null>(null);
  private readonly duplicateFromId = signal<string | null>(null);
  private draftVersion = Number(SURVEY_PAYLOAD_DEFAULTS.version);

  private readonly surveyCommonService = inject(SurveyCommonService);
  private readonly runReportService = inject(RunReportService);
  private readonly listCallDatasetService = inject(ListCallDatasetService);
  private readonly selectPanelistUtilsService = inject(SelectPanelistUtilsService);
  private readonly assignRightsHelperService = inject(AssignRightsHelperService);
  private readonly userService = inject(UserService);
  private readonly validationService = inject(ValidationService);

  readonly repromptLoading = signal(false);
  private readonly pendingQuestionApiRequests = signal(0);
  /** True while questions are being added or rephrased, so the footer can wait for them to arrive. */
  readonly isGeneratingQuestions = computed(() => this.pendingQuestionApiRequests() > 0);
  constructor(private readonly api: ApiService) {}

  /** Counts a request as pending from subscribe until it completes, fails or is cancelled. */
  private trackQuestionApiRequest<T>(request: Observable<T>): Observable<T> {
    return defer(() => {
      this.pendingQuestionApiRequests.update((count) => count + 1);
      return request.pipe(
        finalize(() => this.pendingQuestionApiRequests.update((count) => Math.max(0, count - 1)))
      );
    });
  }

  generateQuestions(
    payload: GenerateSurveyPayload,
    isUtil = false
  ): Observable<GeneratedQuestionsResponse> {
    const endpoint = isUtil ? '/utils/generate-questions-with-prompts' : '/generate-questions';
    const request = this.api.post<GeneratedQuestionsResponse>(
      `${this.environment.apiUrls.surveyAiEngineUrl}${endpoint}`,
      payload,
      this.aiApiHttpOptions
    );

    return isUtil
      ? request
      : request.pipe(tap(({ result, title }) => {
        this._questions.set((result ?? []).map(normalizeGeneratedQuestion));
        if (this.surveyCommonService.flowType().aiflow) {
          // Keep the existing title when AI title is missing/invalid; only apply a valid generated title.
          if (typeof title === 'string' && title.trim()) {
            this.updateTitle(title.trim());
          }
        }
      }));
  }

  addMoreQuestions(payload: AddMoreQuestionsPayload): Observable<{ result: QuestionModel[] }> {
    return this.trackQuestionApiRequest(
      this.api
        .post<{ result: GeneratedQuestionResponse[] }>(
          `${this.environment.apiUrls.surveyAiEngineUrl}/add-more-questions`,
          payload,
          this.aiApiHttpOptions
        )
        .pipe(
          map((questions) => {
            if (!questions || (questions.result != null && !Array.isArray(questions.result))) {
              throw new Error('Invalid response while adding more questions: result must be an array');
            }
            return {
              ...questions,
              result: (questions.result ?? []).map(normalizeGeneratedQuestion),
            };
          }),
          tap((questions) => {
            const existingQuestions = this._questions();
            // Preserve `reviewRequired` so newly added questions are flagged for revalidation.
            const newQuestions = (questions.result ?? []).map((question) => ({
              ...question,
              reviewRequired: true,
            }));
            this.setQuestions([...existingQuestions, ...newQuestions]);
          })
        )
    );
  }

  submitAddMoreQuestions(
    promptText: string,
    questionTypes: QuestionType[],
    promptSelections: Record<string, string[]>,
    count: number = ADD_MORE_QUESTIONS_DEFAULT_COUNT
  ): Observable<{ result: QuestionModel[] }> {
    const payload = this.buildAddMoreQuestionsPayload(
      promptText,
      questionTypes,
      promptSelections,
      count
    );
    this.repromptLoading.set(true);
    return this.addMoreQuestions(payload).pipe(finalize(() => this.repromptLoading.set(false)));
  }

  rephraseQuestions(payload: RephraseQuestionsPayload): Observable<{ result: QuestionModel }> {
    return this.trackQuestionApiRequest(
      this.api.post<{ result: QuestionModel }>(
        `${this.environment.apiUrls.surveyAiEngineUrl}/rephrase-question`,
        payload,
        this.aiApiHttpOptions
      )
    );
  }

  /**
   * Loads an existing survey from the backend and hydrates every state slice that the
   * builder relies on so the user can continue editing without a page-level refresh.
   */
  loadSurvey(surveyId: string): Observable<SavedSurveyDetails> {
    this.surveyCommonService.setSurveyLoading(true);
    this.surveyCommonService.setDataselectorLoading(true);
    return this.userService.getUserData().pipe(
      take(1),
      switchMap((user) =>
        this.api.post<SaveSurveyResponse>(
          this.environment.apiUrls.surveyEntityServiceUrl + '/surveys',
          {
            userId: user.id,
            surveyId,
          },
          this.aiApiHttpOptions
        )
      ),
      map((response) => {
        const survey = response.data;
        if (!survey) {
          throw new Error(`Draft survey ${surveyId} could not be loaded.`);
        }

        return survey;
      }),
      tap((survey) => this.restoreSurveyState(survey)),
      tap((survey) => this.recordAssetOpened(survey.assetInfo?.assetId)),
      switchMap((survey) => this.restoreDatasetRefreshDate(survey)),
      catchError((error) => {
        this.surveyCommonService.setDataselectorLoading(false);
        return throwError(() => error);
      }),
      finalize(() => this.surveyCommonService.setSurveyLoading(false))
    );
  }

  /**
   * Records the asset open in the background without delaying survey loading.
   */
  private recordAssetOpened(assetId?: string): void {
    const normalizedAssetId = assetId?.trim();
    if (!normalizedAssetId) {
      return;
    }

    const url = `${this.environment.apiUrls.assetCatalogDiscovery}/${encodeURIComponent(normalizedAssetId)}`;
    this.api.get<unknown>(
      url,
      {
        withCredentials: true,
        cache: false,
        params: {
          lastOpenedByMe: true,
        },
      },
    ).pipe(
      takeUntilDestroyed(this.destroyRef),
      catchError(() => of(null)),
    ).subscribe();
  }

  /**
   * Restores the dataset refresh date from the backend dataset service.
   * Clears any stale refresh date first (since service is singleton-scoped and persists across survey navigation).
   * Fetches dataset details for the survey's stack, looks up matching dataset by ID, and restores valid refreshedOn date.
   * If dataset lookup fails or metadata is unavailable, refresh date remains cleared to prevent stale dates in footer.
   */
  private restoreDatasetRefreshDate(survey: SavedSurveyDetails): Observable<SavedSurveyDetails> {
    this.surveyCommonService.setRefreshedDate(null);
    const requestInstance = survey.reportDetail?.requestInstance;
    const datasetId = String(requestInstance?.['datasetId'] ?? '').trim();
    const stackId = String(requestInstance?.['datasetStackId'] ?? '').trim();

    if (!datasetId) {
      return of(survey);
    }

    const selectedDataset = this.surveyCommonService.getSelectedDatasetConfig() as Record<string, unknown> | null;
    const selectedMatches = selectedDataset
      && String(selectedDataset['id'] ?? '').trim() === datasetId
      && (!stackId || String(selectedDataset['stackId'] ?? '').trim() === stackId);
    // Reuse an already available refreshedOn value (saved draft or cached selected dataset) before fetching dataset details.
    const localRefreshTimestamp = requestInstance?.['refreshedOn'] ?? (selectedMatches ? selectedDataset?.['refreshedOn'] : null);
    if (localRefreshTimestamp != null && String(localRefreshTimestamp).trim() !== '' && Number.isFinite(Number(localRefreshTimestamp))) {
      this.surveyCommonService.setRefreshedDate(this.selectPanelistUtilsService.refreshedOnDate(localRefreshTimestamp));
      return of(survey);
    }

    return this.listCallDatasetService.getDataSetDetails(stackId).pipe(
      take(1),
      tap((datasets: Record<string, DatasetRefreshDetails[]>) => {
        const dataset = Object.values(datasets ?? {}).flat().find(dataset =>
          String(dataset.id) === datasetId && (!stackId || dataset.stackId === stackId));
        if (dataset?.refreshedOn != null && String(dataset.refreshedOn).trim() && Number.isFinite(Number(dataset.refreshedOn))) {
          this.surveyCommonService.setRefreshedDate(
            this.selectPanelistUtilsService.refreshedOnDate(dataset.refreshedOn),
          );
        }
      }),
      map(() => survey),
      catchError(() => of(survey)),
    );
  }

  loadSurveyForDuplicate(surveyId: string): Observable<void> {
    return this.loadSurvey(surveyId).pipe(
      tap(() => {
        this.clearSurveyId();
        this.clearCurrentAssetId();
      }),
      map(() => undefined)
    );
  }

  /**
   * Reusable guard + load helper for route-driven survey restore.
   * - Sets the active survey id context
   * - Skips API call when the same survey is already loaded in memory
   */
  ensureSurveyLoaded(surveyId: string): Observable<SavedSurveyDetails | null> {
    const normalizedSurveyId = surveyId?.trim() ?? '';
    if (!normalizedSurveyId) {
      return of(null);
    }

    if (this.hasLoadedSurvey(normalizedSurveyId)) {
      return of(null);
    }
    return this.loadSurvey(normalizedSurveyId).pipe(
      tap(() => {
        this.surveyIdValue = normalizedSurveyId;
      })
    );
  }

  // Save the survey draft with the given status
  saveSurveyDraft(status: SurveyStatusType, assetId?: string): Observable<SaveSurveyResponse> {
    return this.submitSurvey('/survey', status, assetId);
  }

  // Publish the survey with the given status
  publishSurvey(
    status: SurveyStatusType.PUBLISHED,
    assetId?: string | null
  ): Observable<SaveSurveyResponse> {
    const reportJobId =
      this.runReportService.reportPayload.jobId ?? this.runReportService.lastJobId;
    return this.runReportService.runReport(true).pipe(
      switchMap((panelistJobId) =>
        this.submitSurvey('/publish', status, assetId, {
          reportJobId,
          panelistJobId,
          invitesSent: this.surveyCommonService.getSelectPanelistUiState().selectedResponses,
        })
      )
    );
  }

  // Submit the survey to the requested endpoint with user context and rights
  private submitSurvey(
    endpoint: string,
    status: SurveyStatusType,
    assetId?: string | null,
    asyncDetails: SaveDraftDynamics = {}
  ): Observable<SaveSurveyResponse> {
    return combineLatest({
      user: this.userService.getUserData(),
      rights: this.assignRightsHelperService.getDefaultRights(),
    }).pipe(
      take(1),
      switchMap(({ user, rights }) => {
        this.surveyCommonService.setUserContext({
          userId: user.id,
          clientId: user.organization?.id,
          emailId: user.userName,
          applicationId: this.environment.appId,
          locale: user.locale,
        });
        const payload = this.buildSurveyPayload(status, rights, assetId, asyncDetails);
        return this.api
          .post<SaveSurveyResponse>(
            `${this.environment.apiUrls.surveyEntityServiceUrl}${endpoint}`,
            payload,
            this.aiApiHttpOptions
          )
          .pipe(
            tap(() => {
              this.savedSurveyNameandDescState.set({
                name: payload.name,
                description: payload.description,
              });
            })
          );
      }),
      tap((response) => {
        if (response?.data) {
          this.api.clearCache(this.environment.apiUrls.assetCatalogDiscovery);
          this.cacheSavedSurveyReferences(response.data);
        }
      })
    );
  }

  // Build the payload for saving or publishing a survey
  buildSurveyPayload(
    status: SurveyStatusType,
    rights: object[] = [],
    assetId?: string | null,
    asyncDetails: SaveDraftDynamics = {}
  ) {
    const user = this.surveyCommonService.getUserContext();
    return this.createSaveDraftPayload({
      title: this.getTitle(),
      questions: this.getQuestions(),
      userPrompt: this.surveyCommonService.getUserPrompt(),
      status,
      surveyId: this.getSurveyId(),
      dynamics: {
        targetCompletes: this.surveyCommonService.getSelectPanelistUiState().selectedResponses,
        dataViewId:
          this.surveyCommonService.dataViewId() ||
          this.surveyCommonService.getSelectedDatasetConfig()?.dataView?.dataViewId?.trim() ||
          '',
        reportJobId:
          asyncDetails.reportJobId ??
          this.runReportService.lastJobId ??
          this.runReportService.reportPayload.jobId,
        userId: user.userId,
        applicationId: user.applicationId,
        clientId: user.clientId,
        emailId: user.emailId,
        locale: user.locale,
        panelistJobId: asyncDetails.panelistJobId,
        invitesSent: asyncDetails.invitesSent,
      },
      rights,
      assetId,
    });
  }

  // Create the payload for saving or publishing a survey
  createSaveDraftPayload({
    title,
    questions,
    userPrompt,
    surveyId,
    status = SurveyStatusType.DRAFT,
    dynamics = {},
    rights = [],
    assetId,
  }: CreateSaveDraftPayloadParams) {
    const apiQuestions = (questions ?? [])
      .filter((question) => !!question.question?.trim())
      .map((question, index) => toApiQuestion(question, index));

    return {
      surveyId,
      name:
        (assetId || this.currentAssetIdValue
          ? this.savedSurveyNameandDescState().name
          : undefined) ??
        ((title ?? SURVEY_PAYLOAD_DEFAULTS.emptyText).trim() ||
          SURVEY_PAYLOAD_DEFAULTS.untitledName),
      description:
        (assetId || this.currentAssetIdValue
          ? this.savedSurveyNameandDescState().description
          : undefined) ??
        ((title ?? SURVEY_PAYLOAD_DEFAULTS.emptyText).trim() ||
          SURVEY_PAYLOAD_DEFAULTS.untitledName),
      version: assetId ? this.incrementDraftVersion() : String(this.draftVersion),
      metadata: {
        questionTypes: this.questionTypes(),
        source: SURVEY_PAYLOAD_DEFAULTS.source,
        userPrompts: userPrompt?.trim() ? [userPrompt.trim()] : [],
      },
      reportInfo: {
        jobId: dynamics.reportJobId ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
        panelistJobId: dynamics.panelistJobId ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
        application: SURVEY_PAYLOAD_DEFAULTS.application,
      },
      assetInfo: {
        ...(assetId ? { assetId } : {}),
        title:
          (title ?? SURVEY_PAYLOAD_DEFAULTS.emptyText).trim() ||
          SURVEY_PAYLOAD_DEFAULTS.untitledName,
        assetType: SURVEY_PAYLOAD_DEFAULTS.assetType,
        rights,
        sourceType: SURVEY_PAYLOAD_DEFAULTS.sourceType,
        parameters: {
          reportType: SURVEY_PAYLOAD_DEFAULTS.reportType,
          dataViewId: dynamics.dataViewId?.trim() || '',
        },
        launchURL: resolveLaunchUrlByFlow(this.surveyCommonService.flowType(), surveyId, status),
        status,
      },
      locale: dynamics.locale ?? SURVEY_PAYLOAD_DEFAULTS.locale,
      createdBy: {
        userId: dynamics.userId ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
        clientId: dynamics.clientId ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
        emailId: dynamics.emailId ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
        applicationId: dynamics.applicationId ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
      },
      folder: {
        name: this.selectedFolder()?.name ?? SURVEY_PAYLOAD_DEFAULTS.emptyText,
        folderId: toApiFolderId(this.selectedFolder()?.folderId),
      },
      panelists: {
        targetCompletes: dynamics.targetCompletes ?? 0,
        maxResponsesPerPanelist: SURVEY_PAYLOAD_DEFAULTS.maxResponsesPerPanelist,
      },
      delivery: this.deliveryPayloadFormat(status, dynamics.invitesSent),
      questions: apiQuestions,
    };
  }

  private incrementDraftVersion(): string {
    return String(++this.draftVersion);
  }

  // Build the required delivery details for the survey status
  deliveryPayloadFormat(status: SurveyStatusType, invitesSent?: number | null) {
    if (status !== SurveyStatusType.PUBLISHED) {
      return {
        invitesSent: 0,
        channels: [],
        schedule: { openAt: null, closeAt: null, timezone: null },
      };
    }

    const openAt = new Date();
    const closeAt = new Date(openAt.getTime() + 10 * 24 * 60 * 60 * 1000);

    return {
      invitesSent: invitesSent ?? 0,
      channels: [
        {
          channel: ChannelName.WebLink,
          enabled: true,
          config: {
            slug: '',
            expiresAt: closeAt.toISOString(),
            singleUse: false,
          },
        },
      ],
      schedule: {
        openAt: openAt.toISOString(),
        closeAt: closeAt.toISOString(),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
    };
  }

  updateTitle(newTitle: string) {
    this._title.set(newTitle);
    this.savedSurveyNameandDescState.update(state => ({
      ...state,
      name: newTitle,
    }));
  }

  // Get current snapshot
  getQuestions(): QuestionModel[] {
    return this._questions();
  }

  getSurveyId(): string {
    const currentId = this.surveyId();
    if (currentId) {
      return currentId;
    }

    const generated = `${SURVEY_ID_PREFIX}${this.createSurveyId()}`;
    this.surveyId.set(generated);
    return generated;
  }

  /** Returns the in-memory survey id without generating a new one. */
  get currentSurveyId(): string | null {
    return this.surveyId();
  }

  private createSurveyId(): string {
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0'))
      .join('')
      .toUpperCase();
  }

  set surveyIdValue(surveyId: string | null) {
    this.surveyId.set(surveyId);
  }

  hasLoadedSurvey(surveyId: string): boolean {
    return this.currentSurveyId === surveyId;
  }

  clearSurveyId(): void {
    this.surveyId.set(null);
  }

  get currentAssetIdValue(): string | null {
    return this.currentAssetId();
  }

  set currentAssetIdValue(assetId: string | null) {
    this.currentAssetId.set(assetId);
  }

  clearCurrentAssetId(): void {
    this.currentAssetId.set(null);
  }

  get currentDataViewIdValue(): string | null {
    return this.currentDataViewId();
  }

  set currentDataViewIdValue(dataViewId: string | null) {
    this.currentDataViewId.set(dataViewId?.trim() || null);
  }

  clearCurrentDataViewId(): void {
    this.currentDataViewId.set(null);
  }

  setSelectedFolder(folder: SurveyFolderSelection | null): void {
    this.selectedFolder.set(folder);
  }

  getSelectedFolder(): SurveyFolderSelection | null {
    return this.selectedFolder();
  }

  getDuplicateFromId(): string | null {
    return this.duplicateFromId();
  }

  setDuplicateFromId(id: string): void {
    this.duplicateFromId.set(id);
  }

  clearDuplicateFromId(): void {
    this.duplicateFromId.set(null);
  }

  /**
   * Caches surveyId and assetId from a saved survey response for future use in the builder.
   */
  cacheSavedSurveyReferences(details: SavedSurveyDetails): void {
    this.savedSurveyNameandDescState.update((state) => ({
      name: details.name ?? state.name,
      description: details.description ?? state.description ?? details.name,
    }));
    if (details?.surveyId) {
      this.surveyIdValue = details.surveyId;
    }

    this.currentAssetIdValue = details?.assetInfo?.assetId ?? null;
  }

  /**
   * Rebuilds the survey builder state from a persisted backend survey.
   * This keeps the restore logic centralized and reusable for reloads and deep links.
   */
  restoreSurveyState(details: SavedSurveyDetails): void {
    this._loadedSurveyDetails.set(details);
    this.setSelectedFolder(
      details.folder?.folderId
        ? { folderId: details.folder.folderId, name: details.folder.name }
        : details.folder?.name === MY_ASSETS_ROOT.title ||
          (!details.folder?.folderId && !details.folder?.name && !!details.assetInfo?.assetId)
          ? { folderId: MY_ASSETS_ROOT.assetId, name: MY_ASSETS_ROOT.title }
          : null
    );
    this.cacheSavedSurveyReferences(details);
    this.updateTitle(
      details.assetInfo?.title?.trim() ||
      details.name?.trim() ||
      SURVEY_PAYLOAD_DEFAULTS.untitledName
    );
    this.setQuestions(fromSavedQuestions(details.questions));
    this.setQuestionTypes(details.metadata?.questionTypes ?? []);
    this.clearAllDrafts();

    const restoredSessionState = this.buildRestoredSessionState(details);
    this.surveyCommonService.hydrateSurveySessionState(restoredSessionState);
    this.surveyCommonService.panelistCompleted.set(true);
    this.currentDataViewIdValue = details.assetInfo?.parameters?.dataViewId?.trim() || null;
    this.surveyCommonService.setDataViewId(
      details.assetInfo?.parameters?.dataViewId?.trim() || null
    );
    // Duplicates need a fresh report job; other surveys retain the saved job ID.
    const isDuplicateFlow = !!this.getDuplicateFromId()?.trim();
    this.runReportService.lastJobId = isDuplicateFlow ? '' : details.reportInfo?.jobId ?? null;
    const status = details.assetInfo?.status;
    if (isDuplicateFlow || (status !== SurveyStatusType.PUBLISHED && status !== SurveyStatusType.CLOSED)) {
      this.runReportService.runReport();
    } else {
      this.surveyCommonService.setDataselectorLoading(false);
    }
  }

  private buildRestoredSessionState(details: SavedSurveyDetails): any {
    const requestInstance = details.reportDetail?.requestInstance as any;
    const reportSpec = details.reportDetail?.reportSpec ?? null;

    const existingSelectorState = this.surveyCommonService.getPanelistDataSelectorState() ?? {};
    const existingDatasetConfig = this.surveyCommonService.getSelectedDatasetConfig();
    const draftDatasetConfig = buildDraftDatasetConfig(requestInstance, existingDatasetConfig);
    const draftDatasetName = String(
      existingSelectorState.datasetName ??
      draftDatasetConfig?.['title'] ??
      requestInstance?.['datasetLabel'] ??
      requestInstance?.['dataViewName'] ??
      ''
    );

    const mergedSelectorState = {
      ...existingSelectorState,
      datasetName: draftDatasetName,
      dataSetInfo: {
        ...existingSelectorState.dataSetInfo,
        ...draftDatasetConfig,
      },
      componentId: existingSelectorState.componentId ?? 'OMNI_THL_SURVEY_PANEL',
      dataPrompts: existingSelectorState.dataPrompts?.length
        ? existingSelectorState.dataPrompts
        : requestInstance?.['prompts'] ?? [],
      panelDataPrompts: existingSelectorState.panelDataPrompts?.length
        ? existingSelectorState.panelDataPrompts
        : requestInstance?.['prompts'] ?? [],
      selections: existingSelectorState.selections?.length
        ? existingSelectorState.selections
        : requestInstance?.['dimensionSelections'] ?? [],
      requestInstance: {
        ...existingSelectorState.requestInstance,
        ...requestInstance,
      },
      reportSpec: reportSpec ?? existingSelectorState.reportSpec ?? {},
      isFactAvailableInDataset: existingSelectorState.isFactAvailableInDataset ?? true,
    };

    return {
      userPrompt: String(details.metadata?.userPrompts?.[0] ?? ''),
      selectPanelistUiState: {
        reportData: true,
        householdCount: String(details.panelists?.targetCompletes ?? 0),
        selectedResponses: details.panelists?.targetCompletes ?? null,
      },
      dataViewId: details.assetInfo?.parameters?.dataViewId?.trim() || null,
      selectedDatasetConfig:
        draftDatasetConfig ?? this.surveyCommonService.getSelectedDatasetConfig(),
      selectedDatasetDisplay: buildDatasetDisplay(draftDatasetConfig, requestInstance),
      refreshedDate: this.surveyCommonService.getRefreshedDate(),
      panelistDataSelectorState: mergedSelectorState,
    };
  }

  addQuestion(question: QuestionModel) {
    const safeQuestion: QuestionModel = {
      questionNumber:
        typeof question.questionNumber === 'number' ? question.questionNumber : undefined,
      question: sanitizeFieldValue('question', question.question) as string,
      options: sanitizeFieldValue('options', question.options) as string[],
      rowOptions: sanitizeFieldValue('rowOptions', question.rowOptions) as string[],
      columnOptions: sanitizeFieldValue('columnOptions', question.columnOptions) as string[],
      npsLeftLabel: sanitizeFieldValue('npsLeftLabel', question.npsLeftLabel) as string,
      npsRightLabel: sanitizeFieldValue('npsRightLabel', question.npsRightLabel) as string,
      isRequired: !!question.isRequired,
      type: question.type ?? '',
      // Preserve `reviewRequired` so newly added questions are flagged for revalidation.
      reviewRequired: question.reviewRequired,
    };

    const updated = [...this._questions(), safeQuestion];
    this.setQuestions(updated);
  }

  setQuestions(questions: QuestionModel[]) {
    const normalizedQuestions = questions.map((question, index) => ({
      ...question,
      questionNumber: index + 1,
    }));

    this._questions.set(normalizedQuestions);
  }

  setQuestionTypes(questionTypes: QuestionType[]) {
    this._questionTypes.set(questionTypes);
  }

  updateQuestionField(index: number, field: keyof QuestionModel, value: unknown) {
    const updated = [...this._questions()];
    const current = updated[index];

    const newValue = sanitizeFieldValue(field as string, value);

    updated[index] = {
      ...current,
      [field]: newValue,
    };

    this.setQuestions(updated);
  }

  updateOptionField(questionIndex: number, optionIndex: number, value: string) {
    const updated = [...this._questions()];

    const q = updated[questionIndex];

    const options = [...(q.options || [])];
    options[optionIndex] = value;

    updated[questionIndex] = {
      ...q,
      options: [...options],
    };

    this.setQuestions(updated);
  }

  removeQuestion(index: number) {
    const updated = this._questions().filter((_, i) => i !== index);
    this.setQuestions(updated);
    if (updated.length === 0) {
      this.setQuestionType('');
    }
    this.remapDraftsAfterDelete(index);
  }

  // ===== Draft Management =====
  private questionDrafts = new Map<number, Partial<QuestionModel>>();
  /** True while a question is open for editing or being added, so other actions can wait for it to be saved. */
  readonly isEditingQuestion = signal(false);

  getDraft(index: number): Partial<QuestionModel> | undefined {
    const draft = this.questionDrafts.get(index);
    return draft ? { ...draft } : undefined;
  }

  saveDraft(index: number, draft: Partial<QuestionModel>): void {
    this.questionDrafts.set(index, { ...draft });
  }

  getTitle(): string {
    return this._title();
  }

  clearDraft(index: number): void {
    this.questionDrafts.delete(index);
  }

  private remapDraftsAfterDelete(deletedIndex: number): void {
    const remappedDrafts = new Map<number, Partial<QuestionModel>>();

    this.questionDrafts.forEach((draft, index) => {
      if (index < deletedIndex) {
        remappedDrafts.set(index, draft);
        return;
      }

      if (index > deletedIndex) {
        remappedDrafts.set(index - 1, draft);
      }
    });

    this.questionDrafts = remappedDrafts;
  }

  clearAllDrafts(): void {
    this.questionDrafts.clear();
  }

  remapDraftsAfterReorder(previousIndex: number, currentIndex: number): void {
    const remappedDrafts = new Map<number, Partial<QuestionModel>>();
    const remapIndex = (index: number): number => {
      if (index === previousIndex) return currentIndex;
      if (previousIndex < currentIndex && index > previousIndex && index <= currentIndex) {
        return index - 1;
      }
      if (previousIndex > currentIndex && index >= currentIndex && index < previousIndex) {
        return index + 1;
      }
      return index;
    };

    this.questionDrafts.forEach((draft, index) => {
      const newIndex = remapIndex(index);
      remappedDrafts.set(newIndex, draft);
    });
    this.questionDrafts = remappedDrafts;
  }

  reset() {
    this._title.set('Untitled Survey');
    this.savedSurveyNameandDescState.set({});
    this.genState.set('idle');
    this.repromptLoading.set(false);
    this.pendingQuestionApiRequests.set(0);
    this.validationService.resetValidation();
    this._questions.set([]);
    this._questionTypes.set([]);
    this._loadedSurveyDetails.set(null);
    this.draftVersion = Number(SURVEY_PAYLOAD_DEFAULTS.version);
    this.clearAllDrafts();
    this._selectedQuestionType.set('');
    this.clearDuplicateFromId();
    this.clearSurveyId();
    this.clearCurrentAssetId();
    this.clearCurrentDataViewId();
    this.setSelectedFolder(null);
    this.runReportService.reset();
  }

  private readonly _selectedQuestionType = signal<QuestionType | ''>('');

  setQuestionType(type: QuestionType | '') {
    this._selectedQuestionType.set(type);
  }

  getQuestionType(): QuestionType | '' {
    return this._selectedQuestionType();
  }

  buildAddMoreQuestionsPayload(
    promptText: string,
    questionTypes: QuestionType[],
    promptSelections: Record<string, string[]>,
    count: number
  ) {
    const firstLabel = (dimId: string): string => {
      return promptSelections?.[dimId]?.[0] ?? '';
    };

    const excludeQuestions: ExcludeQuestion[] = getExistingQuestionsTitle(this.getQuestions());

    return createAddMoreQuestionsPayload(
      firstLabel,
      promptText,
      excludeQuestions,
      questionTypes,
      count
    );
  }

  // ===== Index Remapping =====
  remapIndexAfterDelete(index: number | null, deletedIndex: number): number | null {
    if (index === null) return null;
    if (index === deletedIndex) return null;
    if (index > deletedIndex) return index - 1;
    return index;
  }

  remapIndexAfterReorder(index: number, previousIndex: number, currentIndex: number): number {
    if (index === previousIndex) return currentIndex;
    if (previousIndex < currentIndex && index > previousIndex && index <= currentIndex)
      return index - 1;
    if (previousIndex > currentIndex && index >= currentIndex && index < previousIndex)
      return index + 1;
    return index;
  }
}
