import { parseBoolean, resolveEnvValue } from './env-utils';

const DEFAULT_SUITE_NAME = 'Omni Reports';
const JIRA_FLAG_KEY = 'JiraUpdateEnabled';
const JIRA_FLAG_ALIASES = [JIRA_FLAG_KEY, 'JIRA_UPDATE_ENABLED', 'UpdateJira', 'UPDATE_JIRA'];
const SUITE_NAME_KEY = 'SuiteName';

export const getJiraFlagvalue = (): string => {
  for (const key of JIRA_FLAG_ALIASES) {
    const value = resolveEnvValue(key);
    if (value !== undefined) {
      return value.trim();
    }
  }
  return 'false';
};

export const shouldUpdateJira = (): boolean => {
  return parseBoolean(getJiraFlagvalue(), false);
};

export const getSuiteName = (): string => {
  const value = resolveEnvValue(SUITE_NAME_KEY) ?? resolveEnvValue('PLAYWRIGHT_SUITE_NAME');
  if (value && value.trim().length > 0) {
    return value.trim();
  }
  return resolveEnvValue('npm_package_name') ?? DEFAULT_SUITE_NAME;
};

/**
 * Constructs the LambdaTest build name with optional build identifier suffix.
 * Used consistently across playwright.config.ts and globalTeardown.ts.
 * 
 * @param ltBuild - Base build name (e.g., "Discover build")
 * @param buildIdentifier - Optional identifier to append (e.g., GitHub run number)
 * @returns Formatted build name with identifier if provided
 */
export const getLambdaTestBuildName = (
  ltBuild: string,
  buildIdentifier?: string
): string => {
  return buildIdentifier ? `${ltBuild} (${buildIdentifier})` : ltBuild;
};
