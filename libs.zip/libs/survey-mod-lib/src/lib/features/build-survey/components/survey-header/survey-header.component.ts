import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, OnDestroy, output, signal, untracked, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  ButtonModule,
  IconModule,
  TextFieldModule,
  ToastService,
} from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { Asset } from '@nielsen/crf-lp-common';
import { CreateFolderComponent, DialogsModule, SaveACopyComponent } from '@nielsen/crf-ui-components';
import { finalize, Subject, take } from 'rxjs';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SaveDraftDialogResult, SavedSurveyDetails, SaveSurveyResponse, SurveyStatusType } from '../../models/build-survey';
import { ReviewModeService } from '../../services/review-mode.service';
import { SurveyService } from '../../services/survey.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'build-survey-header',
  imports: [TextFieldModule, IconModule, FormsModule, ButtonModule, DialogsModule, TranslateModule],
  standalone: true,
  templateUrl: './survey-header.component.html',
  styleUrls: ['./survey-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyHeaderComponent implements OnDestroy {
  @ViewChild('saveDraftDialog') private saveDraftDialog?: SaveACopyComponent<Asset>;
  @ViewChild('createFolderDialog') private createFolderDialog?: CreateFolderComponent;
  readonly folderDialogClosed = new Subject<void>();
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly surveyService = inject(SurveyService);
  private readonly toastService = inject(ToastService);
  readonly reviewModeService = inject(ReviewModeService);
  readonly surveyCommonService = inject(SurveyCommonService);
  private readonly translate = inject(TranslateService);

  surveyTitle = '';
  isEditing = false;
  readonly isSavingDraft = signal(false);
  readonly surveyDetails = signal<SavedSurveyDetails | null>(null);
  readonly folders = signal<Asset[]>([]);
  readonly isLoadingFolders = signal(false);
  readonly publishRequest = input<boolean>(false);
  readonly publishReady = output<void>();
  readonly dialogAction = signal<SurveyStatusType>(SurveyStatusType.DRAFT);
  readonly showActionButtons = computed(() => 
    (this.surveyCommonService.flowType().aiflow && this.surveyService.genState() === 'done') || this.surveyService.questions().length > 0
  );
  readonly isReviewMode = this.reviewModeService.isReviewMode;
  readonly allSelected = this.reviewModeService.isAllChecked;
  private isInitialPublishRequest: boolean = true;
  readonly aiSuggestionsAvailable = input<boolean>(false);
  readonly toggleAISuggestions = output<void>();
  surveyErrors = {
    required: this.translate.instant('SURVEYMOD_SURVEY_NAME_REQUIRED'),
    pattern: this.translate.instant('SURVEYMOD_ENTER_VALID_SURVEY_NAME'),
  };

  folderErrors = {
    required: this.translate.instant('SURVEYMOD_FOLDER_NAME_REQUIRED'),
    pattern: this.translate.instant('SURVEYMOD_ENTER_VALID_FOLDER_NAME')
  }

  constructor() {
    effect(() => {
      this.surveyTitle = this.surveyService.title();
    });
    effect(() => {
      this.publishRequest();
      if (this.isInitialPublishRequest) {
        this.isInitialPublishRequest = false;
        return;
      }
      untracked(() => this.prepareForPublish());
    });
  }
  enableEdit() {
    this.isEditing = true;
  }

  disableEdit() {
    this.isEditing = false;
    this.surveyService.updateTitle(this.surveyTitle);
  }

  // Opens the folder selector before saving a draft.
  openSaveDraftDialog(): void {
    const folder = this.surveyService.getSelectedFolder();
    if (folder?.folderId) {
      this.saveAsDraft({
        title: this.surveyTitle,
        folder: { assetId: folder.folderId, title: folder.name },
      });
      return;
    }
    this.dialogAction.set(SurveyStatusType.DRAFT);
    this.surveyCommonService.loadAndOpenFolderDialog(this.saveDraftDialog, this.surveyTitle, this.folders, this.isLoadingFolders, this.isSavingDraft);
  }

  // Opens the folder selector before publishing an unsaved survey.
  prepareForPublish(): void {
    if (this.surveyService.getSelectedFolder()) {
      if (this.hasValidTitle(this.surveyTitle)) {
        this.publishReady.emit();
      }
      return;
    }

    this.dialogAction.set(SurveyStatusType.PUBLISHED);
    this.surveyCommonService.loadAndOpenFolderDialog(this.saveDraftDialog, this.surveyTitle, this.folders, this.isLoadingFolders, this.isSavingDraft);
  }

  isDraftAction(): boolean {
    return this.dialogAction() === SurveyStatusType.DRAFT;
  }

  isPublishAction(): boolean {
    return this.dialogAction() === SurveyStatusType.PUBLISHED;
  }

  // Handles the selected folder for publishing or saving a draft.
  handleLocationSelection(result: SaveDraftDialogResult): void {
    if (this.isPublishAction()) {
      if (!result?.folder?.assetId || !this.hasValidTitle(result.title)) return;

      this.updateSurveyFolder(result);
      this.publishReady.emit();
      return;
    }

    this.saveAsDraft(result);
  }

  // Saves the survey as a draft in the selected folder.
  saveAsDraft(result: SaveDraftDialogResult): void {
    if (this.isSavingDraft() || !result?.folder?.assetId || !this.hasValidTitle(result.title)) return;

    this.updateSurveyFolder(result);
    this.isSavingDraft.set(true);
    this.surveyService.saveSurveyDraft(SurveyStatusType.DRAFT, this.surveyService.currentAssetIdValue ?? undefined)
      .pipe(take(1), finalize(() => this.isSavingDraft.set(false)))
      .subscribe({
        next: (response: SaveSurveyResponse) => {
          this.surveyDetails.set(response.data ?? null);
          if (response.data?.surveyId && !this.route.snapshot.paramMap.get('surveyId')) {
            this.surveyService.surveyIdValue = response.data.surveyId;
            void this.router.navigate(['../build-survey', response.data.surveyId], {
              relativeTo: this.route,
              replaceUrl: true,
            });
          }
          if (response.data?.assetInfo?.assetId) {
            this.surveyService.currentAssetIdValue = response.data.assetInfo.assetId;
          }
          this.toastService.InsertToast(
            'success',
            this.translate.instant('SURVEYMOD_DRAFT_SAVED'),
            {
              dismissAfter: ToastTime.DISMISSAFTER,
              size: 'large',
              containerClass: 'survey-action-toast',
            }
          );
        },
        error: (error: HttpErrorResponse) => {
          const backendError = error.error as SaveSurveyResponse | null;
          const errorMessage =
            backendError?.code?.message ??
            backendError?.errorMessage ??
            this.translate.instant('SURVEYMOD_FAILED_DRAFT');
          this.toastService.InsertToast('error', errorMessage, {
            title: 'Error',
            dismissAfter: ToastTime.DISMISSAFTER,
            size: 'large',
            containerClass: 'survey-action-toast',
          });
        },
      });
  }

  private hasValidTitle(title: string | undefined): boolean {
    if (title?.trim()) return true;

    this.toastService.InsertToast('error', this.translate.instant('SURVEYMOD_VALIDATION_NAME_REQUIRED_ERROR'), {
      title: 'Error', dismissAfter: ToastTime.DISMISSAFTER, size: 'large', containerClass: 'survey-action-toast',
    });
    return false;
  }

  // Updates the survey title and selected folder.
  private updateSurveyFolder(result: SaveDraftDialogResult): void {
    this.surveyService.updateTitle(result.title);
    this.surveyTitle = result.title;
    this.surveyService.setSelectedFolder({
      folderId: String(result.folder.assetId),
      name: result.folder.title ?? '',
    });
  }

  ngOnDestroy(): void {
    this.folderDialogClosed.next();
    this.folderDialogClosed.complete();
  }

  navigateToSurveyListPage() {
    this.router.navigate(['/survey']);
  }

  openAISuggestionsDrawer() {
    this.toggleAISuggestions.emit();
  }

}
