import { BasePage } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { ELEMENT_WAIT_TIMEOUT, SMALL_TIMEOUT, NAVIGATION_TIMEOUT, UI_STATE_UPDATE_DELAY, AI_GENERATION_TIMEOUT } from '../../constants/timeout-constants';
import startWithPromptPageResources from '../../locators/survey/start-with-prompt.locator.json';
import { searchAndSelectDataset as searchAndSelectDatasetHelper } from '../common/dataset-selection.helper';

const START_WITH_PROMPT_PAGE_COMPONENT_NAME = 'startWithPromptPage';

export const OMNISHOPPER_OFFERING_DATA_TEST_ID = 'rv-dataset-type-selector1';

export class StartWithPromptPage extends CommonPage {
  protected readonly componentName = START_WITH_PROMPT_PAGE_COMPONENT_NAME;

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(START_WITH_PROMPT_PAGE_COMPONENT_NAME, startWithPromptPageResources);
  }

  async clickStartWithPrompt(): Promise<void> {
    try {
      const startWithPrompt = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('startWithPrompt', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await startWithPrompt.waitFor(SMALL_TIMEOUT);
      await startWithPrompt.click();
    } catch (error) {
      throw new Error(`Failed to click Start with a prompt: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** If the tile is missing after ELEMENT_WAIT_TIMEOUT, waits for network idle and reloads once before giving up. */
  async isStartWithPromptVisibleAfterReload(): Promise<boolean> {
    return await this.isVisibleAfterOneReload('startWithPrompt');
  }

  async isDatasetTypeSelectorVisible(index = 0): Promise<boolean> {
    try {
      const datasetTypeSelector = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('datasetTypeSelector', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeSelector.waitFor(SMALL_TIMEOUT);
      return datasetTypeSelector.isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check dataset type selector visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectDatasetType(offeringDataTestId: string): Promise<void> {
    try {
      const datasetTypeOption = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('omnishopperOfferingTile', offeringDataTestId, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeOption.waitFor(SMALL_TIMEOUT);

      const tileClass = await datasetTypeOption.getAttribute('class').catch(() => null);
      const isAlreadySelected = (tileClass ?? '').includes('dataset-type-wrapper-selected');
      if (!isAlreadySelected) {
        await datasetTypeOption.click();
      }

      const nextDatasetButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('nextDatasetButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await nextDatasetButton.waitFor(SMALL_TIMEOUT);
      await nextDatasetButton.click();
    } catch (error) {
      throw new Error(`Failed to select dataset type "${offeringDataTestId}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async searchAndSelectDataset(searchTerm: string, datasetLabel: string): Promise<boolean> {
    try {
      return await searchAndSelectDatasetHelper(
        this.webActionHandler,
        this.resourceManager,
        START_WITH_PROMPT_PAGE_COMPONENT_NAME,
        searchTerm,
        datasetLabel,
        {
          datasetResourceKey: 'datasetByText',
          searchToggleResourceKey: 'datasetSearchToggle',
          searchInputResourceKey: 'datasetSearchInput',
        }
      );
    } catch (error) {
      throw new Error(`Failed to search and select dataset "${datasetLabel}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async applyDataset(): Promise<void> {
    try {
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const applyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('applyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();

      const dialogElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dialogElement', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );

      const isChooseViewDialogShown = await dialogElement.isVisible(SMALL_TIMEOUT).catch(() => false);
      if (!isChooseViewDialogShown) {
        return;
      }

      await dialogElement.waitFor(SMALL_TIMEOUT);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();
    } catch (error) {
      throw new Error(`Failed to apply dataset: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillPromptAndGenerate(promptText: string): Promise<void> {
    try {
      const promptTextarea = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('promptTextarea', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await promptTextarea.waitFor(SMALL_TIMEOUT);
      await promptTextarea.enterText(promptText);

      const generateSurveyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('generateSurveyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await generateSurveyButton.waitForEnabled(ELEMENT_WAIT_TIMEOUT);
      await generateSurveyButton.click();
    } catch (error) {
      throw new Error(`Failed to fill prompt and generate survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** The AI-flow heading ("Let's get you started with Optiq!") has no data-test-id in the app template; text-based is the only option. */
  async isOptiqHeadingVisible(): Promise<boolean> {
    try {
      const heading = this.webActionHandler.getWebElement(this.getResource('optiqHeading'));
      return await heading.isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Optiq heading visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isPromptTextareaVisible(): Promise<boolean> {
    try {
      const promptTextarea = this.webActionHandler.getWebElement(this.getResource('promptTextarea'));
      return await promptTextarea.isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check prompt textarea visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Generate Survey uses a native `disabled` attribute (not a niq-button `state`), so a plain isEnabled() check is sufficient. */
  async isGenerateSurveyEnabled(): Promise<boolean> {
    try {
      const generateSurveyButton = this.webActionHandler.getWebElement(this.getResource('generateSurveyButton'));
      return await generateSurveyButton.isEnabled();
    } catch (error) {
      throw new Error(`Failed to check Generate Survey enabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Fills (or clears, with '') the prompt textarea without clicking Generate Survey. */
  async setPromptText(text: string): Promise<void> {
    try {
      const promptTextarea = this.webActionHandler.getWebElement(this.getResource('promptTextarea'));
      await this.waitUntilVisible(promptTextarea, 'Prompt textarea');
      await promptTextarea.enterText(text);
    } catch (error) {
      throw new Error(`Failed to set prompt text: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Generate Survey also gates on a ~1.5s "prompt settling" debounce after typing; waits rather than polling via delay(). */
  async waitForGenerateSurveyEnabled(timeoutMs: number = NAVIGATION_TIMEOUT): Promise<boolean> {
    try {
      const generateSurveyButton = this.webActionHandler.getWebElement(this.getResource('generateSurveyButton'));
      await generateSurveyButton.waitForEnabled(timeoutMs);
      return true;
    } catch (error) {
      throw new Error(`Generate Survey did not become enabled within ${timeoutMs}ms: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Customize Questions "number of questions" number field. */
  private getQuestionCountInput() {
    // TODO test-id: number field has no data-test-id
    const inputResource = this.getResource('questionCountInput');
    return this.webActionHandler.getWebElement({
      ...inputResource,
      selectorType: 'playwrights',
      selectorValue: `${inputResource.selectorValue} >> visible=true >> nth=0`, // first visible non-range input; the range input rejects fill()
    });
  }

  async setQuestionCount(count: number): Promise<void> {
    try {
      const input = this.getQuestionCountInput();
      await this.waitUntilVisible(input, 'Question count number field');
      await input.enterText(String(count));
      await input.pressTab(); // blur so the field validates/commits
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to set question count to ${count}: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getQuestionCountValue(): Promise<number> {
    try {
      const input = this.getQuestionCountInput();
      await this.waitUntilVisible(input, 'Question count number field');
      const raw = await input.getValue();
      const value = Number(raw);
      if (raw === '' || Number.isNaN(value)) {
        throw new Error(`non-numeric value "${raw}"`);
      }
      return value;
    } catch (error) {
      throw new Error(`Failed to read question count value: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Focuses the slider thumb and presses ArrowRight once (keyboard only, no mouse drag). */
  async nudgeQuestionCountSliderRight(): Promise<void> {
    try {
      const sliderResource = this.getResource('questionCountSlider');
      const slider = this.webActionHandler.getWebElement(sliderResource);
      await this.waitUntilVisible(slider, 'Question count slider');
      const nativePage = (BasePage as any).page as import('playwright').Page; // keyboard focus/press isn't exposed by the GTA element wrapper
      const sliderLocator = nativePage.locator(sliderResource.selectorValue);
      const thumb = sliderLocator.locator("[role='slider'], input[type='range']").first();
      const target = (await thumb.count()) > 0 ? thumb : sliderLocator;
      await target.focus();
      await nativePage.keyboard.press('ArrowRight');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to nudge question count slider: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isQuestionCountErrorVisible(timeoutMs: number = SMALL_TIMEOUT): Promise<boolean> {
    try {
      const error = this.webActionHandler.getWebElement(this.getResource('questionCountError'));
      return await error.isVisible(timeoutMs);
    } catch (error) {
      throw new Error(`Failed to check question count error visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Trimmed text of the visible `[role='alert']` inside `.question-count-error` (question-generator card). */
  async getQuestionCountErrorText(): Promise<string> {
    try {
      const error = this.webActionHandler.getWebElement(this.getResource('questionCountError'));
      await this.waitUntilVisible(error, 'Question count error');
      return ((await error.getText()) ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read question count error text: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isGenerateQuestionsDisabled(): Promise<boolean> {
    try {
      const button = this.webActionHandler.getWebElement(this.getResource('generateQuestionsButton'));
      await this.waitUntilVisible(button, 'Generate questions button');
      const disabledAttr = await button.getAttribute('disabled');
      const ariaDisabled = await button.getAttribute('aria-disabled');
      const classAttr = (await button.getAttribute('class')) ?? '';
      return disabledAttr !== null || ariaDisabled === 'true' || classAttr.includes('disabled');
    } catch (error) {
      throw new Error(`Failed to get Generate questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickGenerateQuestions(): Promise<void> {
    try {
      const generateButton = this.webActionHandler.getWebElement(this.getResource('generateQuestionsButton'));
      await this.waitUntilVisible(generateButton, 'Generate questions button');
      await generateButton.click();
    } catch (error) {
      throw new Error(`Failed to click Generate questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Question type tile on the Customize Questions screen, identified by its QuestionType value (e.g. 'SINGLE_CHOICE'). */
  async selectQuestionType(value: string): Promise<void> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(tile, `Question type tile (${value})`);
      await tile.click();
    } catch (error) {
      throw new Error(`Failed to select question type "${value}": ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Selection reflects as the exact "active" CSS class token, not a `state` attribute. */
  async isQuestionTypeSelected(value: string): Promise<{ selected: boolean; outerHtml: string }> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      const classAttr = (await tile.getAttribute('class')) ?? '';
      const outerHtml = String(await tile.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { selected: classAttr.split(/\s+/).includes('active'), outerHtml };
    } catch (error) {
      throw new Error(`Failed to check question type "${value}" selected state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Generate-more/Describe share the same disabled-state gating as Add Question/Duplicate (state/aria-disabled/niqtooltip attributes). */
  private async getDisabledState(resourceName: string): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    const button = this.webActionHandler.getWebElement(this.getResource(resourceName));
    const state = await button.getAttribute('state');
    const ariaDisabled = await button.getAttribute('aria-disabled');
    const tooltip = await button.getAttribute('niqtooltip');
    const outerHtml = String(await button.executeScript((e) => e.outerHTML)).slice(0, 400);
    return { disabled: state === 'disabled' || ariaDisabled === 'true', tooltip, outerHtml };
  }

  async getGenerateMoreQuestionsDisabledState(): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    try {
      return await this.getDisabledState('suggestNewQuestionsButton');
    } catch (error) {
      throw new Error(`Failed to get Generate-more-questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getDescribeQuestionsDisabledState(): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    try {
      return await this.getDisabledState('repromptNewQuestionsButton');
    } catch (error) {
      throw new Error(`Failed to get Describe-questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Same `.question-number` marker preview-mode renders per question. When `atLeast` is given, polls (AI generation is async) until the count reaches it or `timeoutMs` elapses. */
  async getGeneratedQuestionCount(atLeast?: number, timeoutMs: number = AI_GENERATION_TIMEOUT): Promise<number> {
    try {
      const readCount = async () => (await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'))).length;
      let count = await readCount();
      if (atLeast === undefined) {
        return count;
      }
      const start = Date.now();
      while (count < atLeast) {
        if (Date.now() - start >= timeoutMs) {
          throw new Error(`Timed out waiting for question count to reach ${atLeast} (current: ${count})`);
        }
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        count = await readCount();
      }
      return count;
    } catch (error) {
      throw new Error(`Failed to get generated question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `.question-actions` is only revealed via `.question-row`'s mouseenter handler, not CSS :hover. Scope to a single row via nth. */
  private getQuestionRowElement(index: number) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index}`,
    });
  }

  async hoverQuestionRow(index: number): Promise<void> {
    await this.getQuestionRowElement(index).hover();
  }

  async rephraseQuestion(index: number, promptText: string): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await row.hover();

      const rephraseButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseWithAiButton', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
      await rephraseButton.click();

      const rephraseInput = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseInput', String(index), this.componentName)
      );
      let panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (!panelOpened) {
        console.warn('rephrase panel did not open after first click, retried');
        await this.webActionHandler.mouseMove(0, 0);
        await row.hover();
        await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
        await rephraseButton.click();
        panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      }
      if (!panelOpened) {
        throw new Error(`Rephrase panel (index ${index}) did not open after retry`);
      }
      await rephraseInput.enterText(promptText);

      const rephraseSendButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseSendButton', String(index), this.componentName)
      );
      await this.waitUntilVisible(rephraseSendButton, `Rephrase send button (index ${index})`);

      await rephraseSendButton.click();

      const rephraseSendLoading = this.webActionHandler.getWebElement({
        elementName: 'rephraseSendLoading',
        selectorType: 'css',
        selectorValue: '.rephrase-send-loading',
      });
      await rephraseSendLoading.waitFor(NAVIGATION_TIMEOUT, 'hidden');
      if (!(await rephraseSendLoading.isHidden())) {
        throw new Error(`Rephrase send button (index ${index}) stayed in loading state after ${NAVIGATION_TIMEOUT}ms`);
      }

      await this.webActionHandler.mouseMove(0, 0); // move off the row so the hover doesn't linger into the next test

      const panelStillOpen = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (panelStillOpen) {
        const promptValue = await rephraseInput.getValue();
        if (promptValue !== '') {
          throw new Error(`Rephrase prompt input (index ${index}) was not cleared after submit, value: "${promptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to rephrase question ${index}: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** True when `.rephrase-send-loading` is gone and the rephrase input panel for `index` is closed, polling up to `timeoutMs`. */
  async isRephraseSettled(index: number, timeoutMs: number): Promise<boolean> {
    try {
      const loading = this.webActionHandler.getWebElement({
        elementName: 'rephraseSendLoading',
        selectorType: 'css',
        selectorValue: '.rephrase-send-loading',
      });
      const rephraseInput = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseInput', String(index), this.componentName)
      );
      await loading.waitFor(timeoutMs, 'hidden');
      await rephraseInput.waitFor(timeoutMs, 'hidden');
      return (await loading.isHidden()) && (await rephraseInput.isHidden());
    } catch (error) {
      throw new Error(`Failed to check rephrase settled state (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSuggestNewQuestions(): Promise<void> {
    try {
      const suggestButton = this.webActionHandler.getWebElement(this.getResource('suggestNewQuestionsButton'));
      await this.waitUntilVisible(suggestButton, 'Suggest new questions (Generate more questions) button');
      await suggestButton.click();
      await suggestButton.waitForEnabled(NAVIGATION_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to click Suggest new questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  async describeAndSubmitReprompt(promptText: string): Promise<void> {
    try {
      const repromptButton = this.webActionHandler.getWebElement(this.getResource('repromptNewQuestionsButton'));
      await this.waitUntilVisible(repromptButton, 'Describe questions to add button');
      await repromptButton.click();

      const repromptInput = this.webActionHandler.getWebElement(this.getResource('repromptInput'));
      await this.waitUntilVisible(repromptInput, 'Reprompt input');
      await repromptInput.enterText(promptText);

      const repromptSubmitButton = this.webActionHandler.getWebElement(this.getResource('repromptSubmitButton'));
      await this.waitUntilVisible(repromptSubmitButton, 'Reprompt submit button');
      await repromptSubmitButton.click();

      await repromptInput.waitFor(NAVIGATION_TIMEOUT, 'hidden');
      if (await repromptInput.isVisible(SMALL_TIMEOUT)) {
        const repromptValue = await repromptInput.getValue();
        if (repromptValue !== '') {
          throw new Error(`Reprompt panel did not close or clear after submit, value: "${repromptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to describe and submit reprompt: ${error instanceof Error ? error.message : error}`);
    }
  }

  async areAiButtonsHidden(): Promise<boolean> {
    try {
      const generateQuestions = this.webActionHandler.getWebElement(this.getResource('generateQuestionsButton'));
      const suggestNewQuestions = this.webActionHandler.getWebElement(this.getResource('suggestNewQuestionsButton'));
      const repromptNewQuestions = this.webActionHandler.getWebElement(this.getResource('repromptNewQuestionsButton'));
      const rephraseWithAi = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseWithAiButton', '0', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      const [generateHidden, suggestHidden, repromptHidden, rephraseHidden] = await Promise.all([
        generateQuestions.isHidden(),
        suggestNewQuestions.isHidden(),
        repromptNewQuestions.isHidden(),
        rephraseWithAi.isHidden(),
      ]);
      return generateHidden && suggestHidden && repromptHidden && rephraseHidden;
    } catch (error) {
      throw new Error(`Failed to check AI action buttons hidden state: ${error instanceof Error ? error.message : error}`);
    }
  }
}
