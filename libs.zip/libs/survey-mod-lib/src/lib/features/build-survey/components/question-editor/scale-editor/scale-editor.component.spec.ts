import { ElementRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { ScaleEditorComponent } from './scale-editor.component';

describe('ScaleEditorComponent', () => {
  const createComponent = () => TestBed.runInInjectionContext(() =>
    new ScaleEditorComponent(new ElementRef(document.createElement('div'))),
  );

  it('updates the question and emits a change', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onInputChange('Rate each item');

    expect(component.question()).toBe('Rate each item');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('clears the question for null input', () => {
    const component = createComponent();
    component.question.set('Existing question');

    component.onInputChange(null as unknown as string);

    expect(component.question()).toBe('');
  });

  it('deletes rows and columns above the minimum', () => {
    const component = createComponent();
    component.rowOptions.set(['A', 'B', 'C']);
    component.columnOptions.set(['X', 'Y', 'Z']);

    component.deleteRow();
    component.deleteColumn();

    expect(component.rowOptions()).toEqual(['A', 'B']);
    expect(component.columnOptions()).toEqual(['X', 'Y']);
  });

  it('keeps the minimum number of rows and columns', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteRow();
    component.deleteColumn();

    expect(component.rowOptions()).toEqual(['', '']);
    expect(component.columnOptions()).toEqual(['', '']);
    expect(emit).not.toHaveBeenCalled();
  });

  it('updates required state and handles missing toggle data', () => {
    const component = createComponent();

    component.toggleChange({ target: { checked: true } } as unknown as Event);
    expect(component.isRequired()).toBe(true);

    component.toggleChange({ target: {} } as unknown as Event);
    expect(component.isRequired()).toBe(false);
  });

  it('defines minRows constant as 2', () => {
    const component = createComponent();

    expect(component.minRows).toBe(2);
  });

  it('defines minColumns constant as 2', () => {
    const component = createComponent();

    expect(component.minColumns).toBe(2);
  });

  it('prevents deleting row when at minimum', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteRow();

    expect(component.rowOptions()).toEqual(['', '']);
    expect(emit).not.toHaveBeenCalled();
  });

  it('prevents deleting column when at minimum', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteColumn();

    expect(component.columnOptions()).toEqual(['', '']);
    expect(emit).not.toHaveBeenCalled();
  });

  it('deletes row when above minimum', () => {
    const component = createComponent();
    component.rowOptions.set(['Row 1', 'Row 2', 'Row 3']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteRow();

    expect(component.rowOptions()).toEqual(['Row 1', 'Row 2']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('deletes column when above minimum', () => {
    const component = createComponent();
    component.columnOptions.set(['Col 1', 'Col 2', 'Col 3']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteColumn();

    expect(component.columnOptions()).toEqual(['Col 1', 'Col 2']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('deletes row from end of array', () => {
    const component = createComponent();
    component.rowOptions.set(['A', 'B', 'C', 'D', 'E']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteRow();

    expect(component.rowOptions()).toEqual(['A', 'B', 'C', 'D']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('deletes column from end of array', () => {
    const component = createComponent();
    component.columnOptions.set(['X', 'Y', 'Z']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.deleteColumn();

    expect(component.columnOptions()).toEqual(['X', 'Y']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('handles row edit at different indices', () => {
    const component = createComponent();
    component.rowOptions.set(['A', 'B', 'C']);

    component.onRowEdit(0, { target: { value: 'New A' } } as unknown as Event);
    expect(component.rowOptions()).toEqual(['New A', 'B', 'C']);

    component.onRowEdit(2, { target: { value: 'New C' } } as unknown as Event);
    expect(component.rowOptions()).toEqual(['New A', 'B', 'New C']);
  });

  it('handles column edit at different indices', () => {
    const component = createComponent();
    component.columnOptions.set(['X', 'Y', 'Z']);

    component.onColumnEdit(1, { target: { value: 'New Y' } } as unknown as Event);
    expect(component.columnOptions()).toEqual(['X', 'New Y', 'Z']);
  });

  it('emits formChange on row edit', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onRowEdit(0, { target: { value: 'Test' } } as unknown as Event);

    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('emits formChange on column edit', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onColumnEdit(0, { target: { value: 'Test' } } as unknown as Event);

    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('updates required state on toggle change', () => {
    const component = createComponent();
    component.isRequired.set(false);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: true } } as unknown as Event);

    expect(component.isRequired()).toBe(true);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('toggles between required states', () => {
    const component = createComponent();

    component.toggleChange({ target: { checked: true } } as unknown as Event);
    expect(component.isRequired()).toBe(true);

    component.toggleChange({ target: { checked: false } } as unknown as Event);
    expect(component.isRequired()).toBe(false);
  });

  it('converts number input to string in onInputChange', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onInputChange(123);

    expect(component.question()).toBe('123');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('handles zero input in onInputChange', () => {
    const component = createComponent();

    component.onInputChange(0);

    expect(component.question()).toBe('0');
  });

  it('initializes showAddMenu as false', () => {
    const component = createComponent();

    expect(component.showAddMenu).toBe(false);
  });

  it('initializes showDeleteMenu as false', () => {
    const component = createComponent();

    expect(component.showDeleteMenu).toBe(false);
  });

  it('preserves other rows when editing one row', () => {
    const component = createComponent();
    component.rowOptions.set(['Row1', 'Row2', 'Row3']);

    component.onRowEdit(1, { target: { value: 'Modified' } } as unknown as Event);

    expect(component.rowOptions()).toEqual(['Row1', 'Modified', 'Row3']);
  });

  it('preserves other columns when editing one column', () => {
    const component = createComponent();
    component.columnOptions.set(['Col1', 'Col2', 'Col3']);

    component.onColumnEdit(0, { target: { value: 'Changed' } } as unknown as Event);

    expect(component.columnOptions()).toEqual(['Changed', 'Col2', 'Col3']);
  });

  // Tests for the new addOption() method that takes a type parameter
  describe('addOption method with type parameter', () => {
    it('addOption with "row" type adds empty string to rowOptions', () => {
      const component = createComponent();
      component.rowOptions.set(['Option 1', 'Option 2']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.addOption('row');

      expect(component.rowOptions()).toEqual(['Option 1', 'Option 2', '']);
      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('addOption with "column" type adds empty string to columnOptions', () => {
      const component = createComponent();
      component.columnOptions.set(['Option 1', 'Option 2']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.addOption('column');

      expect(component.columnOptions()).toEqual(['Option 1', 'Option 2', '']);
      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('addOption respects MAXIMUM_OPTIONS_ALLOWED for row type', () => {
      const component = createComponent();
      const maxOptions = Array.from({ length: 15 }, (_, i) => `Row ${i + 1}`);
      component.rowOptions.set(maxOptions);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.addOption('row');

      expect(component.rowOptions().length).toBe(15);
      expect(emit).not.toHaveBeenCalled();
    });

    it('addOption respects MAXIMUM_OPTIONS_ALLOWED for column type', () => {
      const component = createComponent();
      const maxOptions = Array.from({ length: 15 }, (_, i) => `Col ${i + 1}`);
      component.columnOptions.set(maxOptions);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.addOption('column');

      expect(component.columnOptions().length).toBe(15);
      expect(emit).not.toHaveBeenCalled();
    });

    it('addOption adds one empty string and creates new array reference for row type', () => {
      const component = createComponent();
      const almostMax = Array.from({ length: 14 }, (_, i) => `Row ${i + 1}`);
      component.rowOptions.set(almostMax);
      const originalReference = component.rowOptions();

      component.addOption('row');

      expect(component.rowOptions().length).toBe(15);
      expect(component.rowOptions()[14]).toBe('');
      expect(component.rowOptions()).not.toBe(originalReference);
    });

    it('addOption adds one empty string and creates new array reference for column type', () => {
      const component = createComponent();
      const almostMax = Array.from({ length: 14 }, (_, i) => `Col ${i + 1}`);
      component.columnOptions.set(almostMax);
      const originalReference = component.columnOptions();

      component.addOption('column');

      expect(component.columnOptions().length).toBe(15);
      expect(component.columnOptions()[14]).toBe('');
      expect(component.columnOptions()).not.toBe(originalReference);
    });

    it('addOption preserves existing elements when adding for row type', () => {
      const component = createComponent();
      const original = ['First', 'Second', 'Third'];
      component.rowOptions.set([...original]);

      component.addOption('row');

      expect(component.rowOptions().slice(0, 3)).toEqual(original);
    });

    it('addOption preserves existing elements when adding for column type', () => {
      const component = createComponent();
      const original = ['First', 'Second', 'Third'];
      component.columnOptions.set([...original]);

      component.addOption('column');

      expect(component.columnOptions().slice(0, 3)).toEqual(original);
    });

    it('addOption uses identical logic for both row and column types', () => {
      const component = createComponent();
      component.rowOptions.set(['Row1', 'Row2']);
      component.columnOptions.set(['Col1', 'Col2']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.addOption('row');
      const rowEmitCalls = emit.mock.calls.length;

      emit.mockClear();
      component.addOption('column');
      const colEmitCalls = emit.mock.calls.length;

      expect(rowEmitCalls).toBe(colEmitCalls);
      expect(rowEmitCalls).toBe(1);
    });
  });

  describe('isAtMaxRowOptions and isAtMaxColumnOptions computed signals', () => {
    it('isAtMaxRowOptions returns true when at maximum', () => {
      const component = createComponent();
      const maxOptions = Array.from({ length: 15 }, (_, i) => `Row ${i + 1}`);
      component.rowOptions.set(maxOptions);

      expect(component.isAtMaxRowOptions()).toBe(true);
    });

    it('isAtMaxRowOptions returns false when below maximum', () => {
      const component = createComponent();
      component.rowOptions.set(['Row 1', 'Row 2']);

      expect(component.isAtMaxRowOptions()).toBe(false);
    });

    it('isAtMaxColumnOptions returns true when at maximum', () => {
      const component = createComponent();
      const maxOptions = Array.from({ length: 15 }, (_, i) => `Col ${i + 1}`);
      component.columnOptions.set(maxOptions);

      expect(component.isAtMaxColumnOptions()).toBe(true);
    });

    it('isAtMaxColumnOptions returns false when below maximum', () => {
      const component = createComponent();
      component.columnOptions.set(['Col 1', 'Col 2']);

      expect(component.isAtMaxColumnOptions()).toBe(false);
    });
  });

  describe('isAtMinRowOptions and isAtMinColumnOptions computed signals', () => {
    it('isAtMinRowOptions returns true when at minimum', () => {
      const component = createComponent();

      expect(component.isAtMinRowOptions()).toBe(true);
    });

    it('isAtMinRowOptions returns false when above minimum', () => {
      const component = createComponent();
      component.rowOptions.set(['Row 1', 'Row 2', 'Row 3']);

      expect(component.isAtMinRowOptions()).toBe(false);
    });

    it('isAtMinColumnOptions returns true when at minimum', () => {
      const component = createComponent();

      expect(component.isAtMinColumnOptions()).toBe(true);
    });

    it('isAtMinColumnOptions returns false when above minimum', () => {
      const component = createComponent();
      component.columnOptions.set(['Col 1', 'Col 2', 'Col 3']);

      expect(component.isAtMinColumnOptions()).toBe(false);
    });
  });

  describe('showAddMenu and showDeleteMenu state', () => {
    it('toggles showAddMenu correctly', () => {
      const component = createComponent();
      expect(component.showAddMenu).toBe(false);

      component.showAddMenu = true;
      expect(component.showAddMenu).toBe(true);

      component.showAddMenu = false;
      expect(component.showAddMenu).toBe(false);
    });

    it('toggles showDeleteMenu correctly', () => {
      const component = createComponent();
      expect(component.showDeleteMenu).toBe(false);

      component.showDeleteMenu = true;
      expect(component.showDeleteMenu).toBe(true);

      component.showDeleteMenu = false;
      expect(component.showDeleteMenu).toBe(false);
    });

    it('showAddMenu and showDeleteMenu are independent', () => {
      const component = createComponent();

      component.showAddMenu = true;
      component.showDeleteMenu = false;

      expect(component.showAddMenu).toBe(true);
      expect(component.showDeleteMenu).toBe(false);

      component.showAddMenu = false;
      component.showDeleteMenu = true;

      expect(component.showAddMenu).toBe(false);
      expect(component.showDeleteMenu).toBe(true);
    });
  });

  describe('onRowEdit and onColumnEdit with different event types', () => {
    it('handles onRowEdit with valid target', () => {
      const component = createComponent();
      component.rowOptions.set(['A', 'B']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.onRowEdit(0, { target: { value: 'Updated' } } as unknown as Event);

      expect(component.rowOptions()).toEqual(['Updated', 'B']);
      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('handles onColumnEdit with valid target', () => {
      const component = createComponent();
      component.columnOptions.set(['X', 'Y']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.onColumnEdit(0, { target: { value: 'Updated' } } as unknown as Event);

      expect(component.columnOptions()).toEqual(['Updated', 'Y']);
      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('handles onRowEdit with out of bounds index gracefully', () => {
      const component = createComponent();
      component.rowOptions.set(['A', 'B']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.onRowEdit(5, { target: { value: 'Z' } } as unknown as Event);

      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('handles onColumnEdit with out of bounds index gracefully', () => {
      const component = createComponent();
      component.columnOptions.set(['X', 'Y']);
      const emit = vi.spyOn(component.formChange, 'emit');

      component.onColumnEdit(5, { target: { value: 'Z' } } as unknown as Event);

      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('handles empty string values in onRowEdit', () => {
      const component = createComponent();
      component.rowOptions.set(['A', 'B']);

      component.onRowEdit(0, { target: { value: '' } } as unknown as Event);

      expect(component.rowOptions()).toEqual(['', 'B']);
    });

    it('handles empty string values in onColumnEdit', () => {
      const component = createComponent();
      component.columnOptions.set(['X', 'Y']);

      component.onColumnEdit(1, { target: { value: '' } } as unknown as Event);

      expect(component.columnOptions()).toEqual(['X', '']);
    });
  });

  describe('deleteRow and deleteColumn edge cases', () => {
    it('deleteRow maintains array immutability', () => {
      const component = createComponent();
      component.rowOptions.set(['A', 'B', 'C']);
      const original = component.rowOptions();

      component.deleteRow();

      expect(component.rowOptions()).not.toBe(original);
      expect(component.rowOptions()).toEqual(['A', 'B']);
    });

    it('deleteColumn maintains array immutability', () => {
      const component = createComponent();
      component.columnOptions.set(['X', 'Y', 'Z']);
      const original = component.columnOptions();

      component.deleteColumn();

      expect(component.columnOptions()).not.toBe(original);
      expect(component.columnOptions()).toEqual(['X', 'Y']);
    });

    it('deleteRow removes last row from longer arrays', () => {
      const component = createComponent();
      component.rowOptions.set(Array.from({ length: 10 }, (_, i) => `Row ${i + 1}`));
      const emit = vi.spyOn(component.formChange, 'emit');

      component.deleteRow();

      expect(component.rowOptions().length).toBe(9);
      expect(component.rowOptions()[8]).toBe('Row 9');
      expect(emit).toHaveBeenCalledTimes(1);
    });

    it('deleteColumn removes last column from longer arrays', () => {
      const component = createComponent();
      component.columnOptions.set(Array.from({ length: 10 }, (_, i) => `Col ${i + 1}`));
      const emit = vi.spyOn(component.formChange, 'emit');

      component.deleteColumn();

      expect(component.columnOptions().length).toBe(9);
      expect(component.columnOptions()[8]).toBe('Col 9');
      expect(emit).toHaveBeenCalledTimes(1);
    });
  });

  describe('selectedType input handling', () => {
    it('initializes with default empty string', () => {
      const component = createComponent();

      expect(component.selectedType()).toBe('');
    });

    it('accepts SINGLE_POINT_SCALE type', () => {
      const component = createComponent();
      component.selectedType = (() => 'SINGLE_POINT_SCALE') as typeof component.selectedType;

      expect(component.selectedType()).toBe('SINGLE_POINT_SCALE');
    });

    it('accepts MULTIPLE_POINT_SCALE type', () => {
      const component = createComponent();
      component.selectedType = (() => 'MULTIPLE_POINT_SCALE') as typeof component.selectedType;

      expect(component.selectedType()).toBe('MULTIPLE_POINT_SCALE');
    });
  });

  describe('model two-way bindings', () => {
    it('updates rowOptions via model', () => {
      const component = createComponent();
      const newRows = ['New1', 'New2', 'New3'];

      component.rowOptions.set(newRows);

      expect(component.rowOptions()).toEqual(newRows);
    });

    it('updates columnOptions via model', () => {
      const component = createComponent();
      const newCols = ['NewX', 'NewY'];

      component.columnOptions.set(newCols);

      expect(component.columnOptions()).toEqual(newCols);
    });

    it('preserves question state across operations', () => {
      const component = createComponent();
      component.question.set('Rate this item');

      component.addOption('row');
      expect(component.question()).toBe('Rate this item');

      component.deleteColumn();
      expect(component.question()).toBe('Rate this item');
    });

    it('preserves isRequired state across operations', () => {
      const component = createComponent();
      component.isRequired.set(true);

      component.addOption('column');
      expect(component.isRequired()).toBe(true);

      component.deleteRow();
      expect(component.isRequired()).toBe(true);
    });
  });
});
