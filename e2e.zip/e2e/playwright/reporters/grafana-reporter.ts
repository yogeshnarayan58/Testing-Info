import { Reporter, Suite, TestCase, TestResult } from '@playwright/test/reporter';
import { FullConfig } from "@playwright/test";
import * as path from 'path';
import { config } from '../../utils/configurationDetails';
import { PostgresActions, CustomReporterOptions, CommonReporterUtils } from "@gfk/gta";


class GrafanaPlaywrightReporter implements Reporter {

    private areaId: number | undefined;
    private domainId: number | undefined;
    private teamId: number | undefined;
    private options: CustomReporterOptions;
    private projectId: number | undefined;
    private environmentName: string;
    private commonReporterUtils: CommonReporterUtils | undefined;
    private postgresActions: PostgresActions;
    private previousTestCaseId: string | null | undefined;
    private resultID: number | undefined;

    constructor(options: CustomReporterOptions) {
        this.options = options;
        console.log(`Custom reporter - Custom options received`);
        this.environmentName = config.ENV;
        this.postgresActions = new PostgresActions(config.postgresAPIUrl);
    }


    async initialize(): Promise<void> {
        if (!this.commonReporterUtils) {
            throw new Error('CommonReporterUtils not initialized. Call onBegin first.');
        }
        const { areaId, domainId, teamId, projectId } = await this.commonReporterUtils.getOrCreateIds();
        this.areaId = areaId;
        this.domainId = domainId;
        this.teamId = teamId;
        this.projectId = projectId;
    }

    async onBegin(fullConfig: FullConfig, suite: Suite) {
        console.log(`Custom reporter - Starting the run with ${suite.allTests().length} tests`);
        this.commonReporterUtils = new CommonReporterUtils(this.options, this.environmentName, config.postgresAPIUrl);
        await this.initialize();
    }

    async onTestEnd(testCase: TestCase, result: TestResult): Promise<void> {
        try {
            if (this.projectId) {
                const isRetry = this.previousTestCaseId === testCase.id;
                const suiteName = path.basename(testCase.parent.title, '.ts');
                // testCaseId: To read from test case tags/annotation
                // testCycleName: process.env.JIRA_CYCLE_NAME || '',
                // releaseVersion: process.env.VERSION_NAME || '',
                this.resultID = await this.postgresActions.createOrUpdateTestResults(
                    {
                        suiteName: suiteName,
                        testcaseName: testCase.title,
                        status: result.status,
                        executionTime: result.startTime,
                        executionDuration: result.duration,
                        envName: this.environmentName,
                        projectId: this.projectId,
                    },
                    isRetry,
                    this.resultID
                );
                console.log('Custom reporter: - Test result created:', this.resultID);
                this.previousTestCaseId = testCase.id;
            } else {
                console.error('Custom reporter - Project ID is not available');
            }
        } catch (error) {
            console.error('Custom reporter - Error creating test result:', error);
        }
    }
}

export default GrafanaPlaywrightReporter;