import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ToastService } from '@nielseniq/athena-core';
import { of, Subject, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { FLOW_TYPES } from '../../../core/config/config';
import { SurveyService } from '../../../features/build-survey/services/survey.service';
import { SurveyCommonService } from '../../services/survey-common.service';
import { CrfSurveyWrapperComponent } from './crf-survey-wrapper.component';

vi.mock('../../../features/build-survey/services/survey.service', () => ({
  SurveyService: class {},
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  ACAssetManageApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

vi.mock('@nielseniq/athena-core', () => ({
  IconButtonModule: class {},
  StepComponent: class {},
  StepperComponent: class {},
  ToastService: class {},
}));

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('CrfSurveyWrapperComponent', () => {
  let mockTranslateService: any;
  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
  });
  const createComponent = ({
    url = '/survey/select-panelist',
    surveyId = 'survey-1',
    ensureError = false,
    panelistDone = false,
  }: {
    url?: string;
    surveyId?: string;
    ensureError?: boolean;
    panelistDone?: boolean;
  } = {}) => {
    const paramMap$ = new Subject<any>();

    const route = {
      firstChild: { paramMap: paramMap$.asObservable() },
      parent: {},
      snapshot: {
        pathFromRoot: [{ data: {} }, { data: { flowType: FLOW_TYPES.SCRATCH } }],
      },
    };

    const router = {
      url,
      navigate: vi.fn().mockResolvedValue(true),
    };

    const surveyCommonService = {
      isPanelOpen: signal(false),
      activeSurveyStep: signal('select-panelist'),
      datasetFooterVisible: signal(true),
      setFlowType: vi.fn(),
      panelistCompleted: signal(panelistDone),
      getSelectedDatasetDisplay: vi.fn().mockReturnValue('Dataset A'),
      requestDatasetPickerOpen: vi.fn(),
      setPanelOpen: vi.fn(),
    };

    const surveyService = {
      currentSurveyId: surveyId,
      ensureSurveyLoaded: vi.fn().mockReturnValue(ensureError ? throwError(() => new Error('fail')) : of(null)),
    };

    const toastService = {
      InsertToast: vi.fn(),
    };

    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: SurveyService, useValue: surveyService },
        { provide: ToastService, useValue: toastService },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new CrfSurveyWrapperComponent(router as any, surveyService as any, mockTranslateService as any));
    return { component, paramMap$, route, router, surveyCommonService, surveyService, toastService };
  };

  it('initializes flow type and tracks route surveyId loading', () => {
    const { component, paramMap$, surveyCommonService, surveyService } = createComponent();

    component.ngOnInit();
    paramMap$.next(convertToParamMap({}));
    paramMap$.next(convertToParamMap({ surveyId: 'survey-99' }));

    expect(surveyCommonService.setFlowType).toHaveBeenCalledWith(FLOW_TYPES.SCRATCH);
    expect(surveyService.ensureSurveyLoaded).toHaveBeenCalledWith('survey-99');
  });

  it('shows error toast and redirects when loading a survey fails', () => {
    const { component, paramMap$, toastService, router } = createComponent({ ensureError: true });

    component.ngOnInit();
    paramMap$.next(convertToParamMap({ surveyId: 'survey-99' }));

    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'error',
      'SURVEYMOD_LOAD_SURVEY_FAILED',
      expect.objectContaining({ size: 'large' }),
    );
    expect(router.navigate).toHaveBeenCalledWith(['select-panelist'], expect.any(Object));
  });

  it('derives step and footer state from explicit active-step state', () => {
    const { component, router, surveyCommonService } = createComponent({ url: '/survey/unrelated' });

    expect(component.currentStep).toBe(0);
    expect(surveyCommonService.datasetFooterVisible()).toBe(true);
    expect(component.isDatasetEditable).toBe(true);

    surveyCommonService.activeSurveyStep.set('build-survey');
    expect(component.currentStep).toBe(1);
    expect(component.isDatasetEditable).toBe(false);

    surveyCommonService.activeSurveyStep.set('select-panelist');
    surveyCommonService.getSelectedDatasetDisplay.mockReturnValue('');
    expect(component.isDatasetFooterHidden).toBe(true);

    surveyCommonService.activeSurveyStep.set('results');
    router.url = '/survey/unrelated';
    expect(component.currentStep).toBe(3);
    surveyCommonService.datasetFooterVisible.set(false);
    expect(surveyCommonService.datasetFooterVisible()).toBe(false);

    surveyCommonService.datasetFooterVisible.set(true);
    expect(surveyCommonService.datasetFooterVisible()).toBe(true);

    expect(component.currentStep).toBe(3);
  });

  it('blocks forward navigation when panelist step is incomplete', () => {
    const { component, router } = createComponent({ panelistDone: false });

    component.onStepClick(1);

    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('navigates with survey id when moving to valid steps', () => {
    const { component, router, surveyCommonService } = createComponent({ panelistDone: true, surveyId: 'survey-55' });

    component.onStepClick(1);
    component.onStepClick(99);

    expect(surveyCommonService.setPanelOpen).toHaveBeenCalledWith(false);
    expect(surveyCommonService.setPanelOpen).toHaveBeenCalledTimes(1);
    expect(router.navigate).toHaveBeenCalledWith(['build-survey', 'survey-55'], expect.any(Object));
    expect(router.navigate).toHaveBeenCalledTimes(1);
  });

  it('blocks skip-ahead navigation by more than one step', () => {
    const { component, router } = createComponent({ panelistDone: true, surveyId: 'survey-55' });

    component.onStepClick(2);

    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('navigates without survey id when not available', () => {
    const { component, router, surveyCommonService } = createComponent({ panelistDone: true, surveyId: '' });

    component.onStepClick(1);

    expect(surveyCommonService.setPanelOpen).toHaveBeenCalledWith(false);
    expect(router.navigate).toHaveBeenCalledWith(['build-survey'], expect.any(Object));
  });

  it('keeps panel state untouched when re-clicking the current step', () => {
    const { component, router, surveyCommonService } = createComponent({ panelistDone: true, surveyId: 'survey-55' });

    component.onStepClick(0);

    expect(surveyCommonService.setPanelOpen).not.toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['select-panelist', 'survey-55'], expect.any(Object));
  });

  it('opens dataset picker only when dataset is editable', () => {
    const { component, surveyCommonService } = createComponent();

    component.onDatasetFooterClick();
    expect(surveyCommonService.requestDatasetPickerOpen).toHaveBeenCalledTimes(1);

    surveyCommonService.activeSurveyStep.set('build-survey');
    component.onDatasetFooterClick();
    expect(surveyCommonService.requestDatasetPickerOpen).toHaveBeenCalledTimes(1);
  });

  it('ignores empty surveyId emissions from the child route', () => {
    const { component, paramMap$, surveyService } = createComponent();

    component.ngOnInit();
    paramMap$.next(convertToParamMap({ surveyId: '' }));

    expect(surveyService.ensureSurveyLoaded).not.toHaveBeenCalled();
  });

  it('ignores invalid step indexes', () => {
    const { component, router } = createComponent({ panelistDone: true });

    component.onStepClick(-1);
    component.onStepClick(99);

    expect(router.navigate).not.toHaveBeenCalled();
  });

  describe('isStepClickable', () => {
    it('returns false for invalid step index', () => {
      const { component } = createComponent({ panelistDone: true });

      expect(component.isStepClickable(-1)).toBe(false);
      expect(component.isStepClickable(99)).toBe(false);
    });

    it('returns true for the current step', () => {
      const { component } = createComponent({ panelistDone: true });

      // Current step is 0 (select-panelist)
      expect(component.isStepClickable(0)).toBe(true);
    });

    it('returns true when navigating backward to a completed step', () => {
      const { component, surveyCommonService } = createComponent({ panelistDone: true });

      surveyCommonService.activeSurveyStep.set('build-survey');
      // Current step becomes 1 (build-survey), so step 0 is completed and clickable
      expect(component.isStepClickable(0)).toBe(true);
    });

    it('returns false when trying to navigate forward but panelist not completed', () => {
      const { component } = createComponent({ panelistDone: false });

      // Trying to move from step 0 to step 1, but panelist not completed
      expect(component.isStepClickable(1)).toBe(false);
    });

    it('returns true when navigating to next step with panelist completed', () => {
      const { component } = createComponent({ panelistDone: true });

      // Step 0 is current, trying to move to step 1 with panelist completed
      expect(component.isStepClickable(1)).toBe(true);
    });

    it('returns false when trying to skip more than one step ahead', () => {
      const { component } = createComponent({ panelistDone: true });

      // Current step is 0, trying to jump to step 2 (skipping step 1)
      expect(component.isStepClickable(2)).toBe(false);
    });

    it('returns false when on results page and trying to navigate back', () => {
      const { component, surveyCommonService } = createComponent({ panelistDone: true });

      surveyCommonService.activeSurveyStep.set('results');
      // On results page, cannot go back to step 0 or 1
      expect(component.isStepClickable(0)).toBe(false);
      expect(component.isStepClickable(1)).toBe(false);
    });

    it('returns true when on results page and clicking results step again', () => {
      const { component, surveyCommonService } = createComponent({ panelistDone: true });

      surveyCommonService.activeSurveyStep.set('results');
      // Can click the results step itself (step 2)
      expect(component.isStepClickable(2)).toBe(true);
    });


    it('blocks forward navigation when previous step is not completed', () => {
      const { component } = createComponent({ panelistDone: false });

      // Cannot navigate forward if panelist not completed (step 0 not done)
      expect(component.isStepClickable(1)).toBe(false);
      expect(component.isStepClickable(2)).toBe(false);
    });

    it('returns false when previous step is not completed (using isStepCompleted logic)', () => {
      const { component, surveyCommonService } = createComponent({ panelistDone: false });

      surveyCommonService.activeSurveyStep.set('select-panelist');
      // Step 0 incomplete (panelist not completed), cannot move forward
      expect(component.isStepClickable(1)).toBe(false);
    });

    it('remains true for step 0 regardless of panelist completion state', () => {
      const { component: component1 } = createComponent({ panelistDone: true });
      const { component: component2 } = createComponent({ panelistDone: false });

      // Step 0 should always be clickable (it's the entry point)
      expect(component1.isStepClickable(0)).toBe(true);
      expect(component2.isStepClickable(0)).toBe(true);
    });
  });
});
