import { TestBed } from '@angular/core/testing';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { BAR_CHART_RESPONSE, COLUMN_CHART_RESPONSE, PIE_CHART_RESPONSE } from '../constants/survey-results-preview';
import type { GridResponse, QuestionChartPreview } from '../models/question-result';
import { QuestionChartPreviewService } from './question-chart-preview.service';

describe('QuestionChartPreviewService', () => {
  let source: QuestionChartPreviewService;
  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [QuestionChartPreviewService] });
    source = TestBed.inject(QuestionChartPreviewService);
  });
  afterEach(() => TestBed.resetTestingModule());

  it.each([
    ['MULTIBAR_HORIZONTAL', BAR_CHART_RESPONSE],
    ['MULTIBAR_VERTICAL', COLUMN_CHART_RESPONSE],
  ])('loads the %s sample response', (type, sample) => {
    let result!: QuestionChartPreview;
    source.load(type).subscribe(value => result = value);
    const response = sample.data[0].components[0];
    expect(result).toEqual({ configs: response.chartConfigs, properties: response.chartProperty,
      data: response.objects.data, metadata: response.objects.metadata });
    expect(result.configs[0].chartType).toBe(type);
    expect(result.properties['preview']).toBe(false);
    expect(result.data.length).toBeGreaterThan(0);
  });

  it('maps the full pie response to the preview fields', () => {
    let result!: QuestionChartPreview;
    source.load('PIE').subscribe(value => result = value);

    expect(PIE_CHART_RESPONSE.data[0]).not.toHaveProperty('layout');
    expect(PIE_CHART_RESPONSE.data[0]).not.toHaveProperty('dataSummary');
    expect(PIE_CHART_RESPONSE.data[0]).not.toHaveProperty('source');
    expect(PIE_CHART_RESPONSE.data[0]).not.toHaveProperty('metaData');
    expect(PIE_CHART_RESPONSE.data[0]).not.toHaveProperty('filterSummary');
    expect(PIE_CHART_RESPONSE).not.toHaveProperty('timeMillis');
    expect(Object.keys(result).sort()).toEqual(['configs', 'data', 'metadata', 'properties']);
    expect(result.configs).toEqual(PIE_CHART_RESPONSE.data[0].components[0].chartConfigs);
    expect(result.properties).toEqual(PIE_CHART_RESPONSE.data[0].components[0].chartProperty);
    expect(result.data).toEqual(PIE_CHART_RESPONSE.data[0].components[0].objects.data);
    expect(result.metadata).toEqual(PIE_CHART_RESPONSE.data[0].components[0].objects.metadata);
  });
  it('preserves the original pie percentage response', () => {
    let result!: QuestionChartPreview;
    source.load('PIE').subscribe(value => result = value);
    expect(result.data.map(item => item['metric1'])).toEqual([11.379, 7.397, 2.869, 5.379]);
    expect(result.metadata['metric1']).toEqual({
      title: 'Units Absolute', type: 'currency', format: '$#,##0.0',
      currencyLocale: 'en_US', currencyCode: 'USD',
    });
    expect(result.configs[0].showPiePercentage).toBe(true);
    expect(result.configs[0].axisConfig).toEqual({ showXaxis: false, showYaxis: false });
    expect(result.configs[0].seriesConfig).toEqual({ showValues: true, showMarker: true });
    expect(result.properties).toEqual({
      legend: {
        font: { name: "'aktiv-grotesk', sans-serif", color: '#262626', size: 11 },
        align: 'RIGHT',
      },
    });
  });

  it('returns an empty preview when no sample response exists', () => {
    let result!: QuestionChartPreview;
    source.load('unknown').subscribe(value => result = value);
    expect(result).toEqual({ configs: [], properties: {}, data: [], metadata: {} });
  });
  it('preserves heat styles and isolates preview mutations', () => {
    let first!: QuestionChartPreview;
    let second!: QuestionChartPreview;
    source.load('heatmap').subscribe(value => first = value);
    expect(first.gridResponse?.tableConfig.rowProperties?.['style-unique-for-rule-1'].shade?.color).toBe('#a3445e');
    first.gridResponse!.tableConfig.rowProperties = {};
    source.load('heatmap').subscribe(value => second = value);
    expect(second.gridResponse?.tableConfig.rowProperties?.['style-unique-for-rule-1'].shade?.color).toBe('#a3445e');
  });

  it('returns an independent normal-grid response on each load', () => {
    let first!: GridResponse;
    let second!: GridResponse;
    source.loadGrid().subscribe(value => first = value);
    source.loadGrid().subscribe(value => second = value);
    expect(first.objects.data[0]['col3'].cellValue).toBe('Percentage');
    expect(first.tableConfig.rowProperties).toEqual({});
    expect(first.objects.data[1]['col3'].cellValue).toBe(42.11);
    expect(second).toEqual(first);
    expect(second).not.toBe(first);
  });

});
