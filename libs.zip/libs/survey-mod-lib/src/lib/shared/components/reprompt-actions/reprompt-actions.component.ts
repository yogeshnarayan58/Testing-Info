import { Component, input, model, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from '@nielseniq/athena-core';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-reprompt-actions',
  standalone: true,
  imports: [CommonModule, ButtonModule, TranslateModule],
  templateUrl: './reprompt-actions.component.html',
  styleUrl: './reprompt-actions.component.scss',
})
export class RepromptActionsComponent {
  isPanelOpen = model(false);
  prompt = model('');
  repromptLoading = input(false);
  submitDisabled = input(false);

  submit = output<void>();

  onPromptInput(value: string): void {
    this.prompt.set(value);
  }

  onCloseClicked(): void {
    this.isPanelOpen.set(false);
  }

  onSubmitClicked(): void {
    if (this.submitDisabled()) {
      return;
    }

    this.submit.emit();
  }
}
