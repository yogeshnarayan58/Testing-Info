import { getJiraFlagvalue, getSuiteName, shouldUpdateJira, getLambdaTestBuildName } from "../../common/utils/configurationDetails";
import { updateJira } from "./jiraUpdateManager";
import * as fs from "fs";
import * as path from "path";
import { MAX_TEST_TIMEOUT } from "../../constants/time-out-constants";

const ALLURE_RESULTS_DIR = path.join(process.cwd(), "allure-results");
const ENV_PROPS_PATH = path.join(ALLURE_RESULTS_DIR, "environment.properties");

/**
 * global-teardown.ts: This module is responsible for tearing down the global state after all tests have completed.
 * It includes a default export function that runs after all tests, cleaning up any necessary global context.
 * By centralizing these teardown operations, it ensures a consistent end state for all tests, improving test reliability.
 * You can add any teardown setup code within this function.
 * Note: Due to a known issue (https://github.com/microsoft/playwright/issues/23875),
 * the last line of output from this function may be cleared by the line reporter.
 */
export default async () => {
  const isLambdaTest = process.env.LAMBDATEST === "true";

  if (isLambdaTest) {
    try {
      console.log("[global-teardown] Adding LambdaTest videos to Allure report...");

      const ltUser = process.env.LAMBDATEST_USERNAME || process.env.LT_USERNAME;
      const ltAccessKey = process.env.LAMBDATEST_ACCESS_KEY || process.env.LT_ACCESS_KEY;
      const ltBuild = process.env.LT_BUILD || "Discover build";
      const buildIdentifier =
        process.env.LT_BUILD_IDENTIFIER ||
        process.env.BUILD_NUMBER ||
        process.env.GITHUB_RUN_NUMBER ||
        undefined;
      
      // Construct the actual build name used in LambdaTest.
      // getLambdaTestBuildName centralizes the naming convention (typically something like
      // "BuildName-RunNumber") so that both Playwright configuration and this teardown step
      // use the same format, ensuring LambdaTest sessions are grouped correctly and external
      // tooling (like Allure or Jira sync) can reliably correlate results across runs.
      const actualBuildName = getLambdaTestBuildName(ltBuild, buildIdentifier);

      fs.mkdirSync(ALLURE_RESULTS_DIR, { recursive: true });

      console.log("[global-teardown] Step 1: Reading test-session mappings...");
      const sessionDir = path.join(process.cwd(), ".lt-sessions");

      const testSessionMap = new Map<string, string>(); // fullName -> sessionName
      const testIdMap = new Map<string, string>(); // testId -> sessionName

      // Read individual mapping files (one per test) to avoid concurrent write conflicts
      if (fs.existsSync(sessionDir)) {
        const mappingFiles = fs.readdirSync(sessionDir).filter(f => f.startsWith('test-') && f.endsWith('.json'));

        console.log(`[global-teardown] Found ${mappingFiles.length} test-session mapping file(s)`);

        for (const file of mappingFiles) {
          try {
            const sanitizedFile = path.basename(file);
            const filePath = path.join(sessionDir, sanitizedFile);
            const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

            if (data.sessionName) {
              if (data.fullName) {
                testSessionMap.set(data.fullName.trim(), data.sessionName);
              }
              if (data.testId) {
                testIdMap.set(data.testId, data.sessionName);
              }
            }
          } catch (e) {
            console.warn(`[global-teardown] Failed to parse mapping file ${file}:`, e);
          }
        }
      } else {
        console.warn(`[global-teardown] No .lt-sessions directory found at ${sessionDir}`);
      }

      // Step 2: Read Allure result files
      console.log("[global-teardown] Step 2: Reading Allure result files...");
      const allureFiles = fs
        .readdirSync(ALLURE_RESULTS_DIR)
        .filter((f) => f.endsWith("-result.json"));

      console.log(`[global-teardown] Found ${allureFiles.length} Allure result files`);

      const testResults = allureFiles.map((file) => {
        // Sanitize filename to prevent path traversal attacks
        const sanitizedFile = path.basename(file);
        const filePath = path.join(ALLURE_RESULTS_DIR, sanitizedFile);
        const result = JSON.parse(fs.readFileSync(filePath, "utf-8"));
        return { filePath, result };
      });

         // Step 3: Inject LT_SESSION into Allure result files
      console.log("[global-teardown] Step 3: Injecting LT_SESSION into Allure files...");
      for (const testResult of testResults) {
        const result = testResult.result;

        const testName = result.name?.trim();
        if (!testName) continue;

        const testId = result.testCaseId;

        const labels = result.labels || [];
        const parentSuite = labels.find((l: any) => l.name === "parentSuite")?.value;
        const suite = labels.find((l: any) => l.name === "suite")?.value;
        const subSuite = labels.find((l: any) => l.name === "subSuite")?.value;

        const fullName = [parentSuite, suite, subSuite, testName].filter(Boolean).join(" › ").trim();

        // Normalize > separator to › for consistent mapping with reporter
        const normalizedFullName = fullName.replace(/\s*>\s*/g, ' › ');

        let sessionName = testSessionMap.get(normalizedFullName);

        if (!sessionName && testId) {
          sessionName = testIdMap.get(testId);
        }

        if (sessionName) {
          result.parameters = result.parameters || [];
          const hasLTSession = result.parameters.some((p: any) => p.name === "LT_SESSION");

          if (!hasLTSession) {
            result.parameters.push({ name: "LT_SESSION", value: sessionName });
            // Safe: testResult.filePath was sanitized with path.basename() during file reading 
            fs.writeFileSync(testResult.filePath, JSON.stringify(result, null, 2));
            console.log(`[global-teardown]  Added LT_SESSION for "${fullName}": ${sessionName}`);
          }
        } else {
          console.warn(`[global-teardown]  No session mapping found for: "${fullName}"`);
        }
      }

      // Step 4: Fetch LambdaTest sessions from API
      console.log("[global-teardown] Step 4: Fetching LambdaTest sessions...");
      if (!ltUser || !ltAccessKey) {
        console.warn("[global-teardown] Missing LambdaTest credentials. Skipping API calls.");
        return;
      }

      const auth = Buffer.from(`${ltUser}:${ltAccessKey}`).toString("base64");

      const response = await fetch(
        `https://api.lambdatest.com/automation/api/v1/sessions?build=${encodeURIComponent(actualBuildName)}&limit=100`,
        {
          headers: { Authorization: `Basic ${auth}` },
          signal: AbortSignal.timeout(MAX_TEST_TIMEOUT),
        }
      );

      if (!response.ok) {
        const errorBody = await response.text().catch(() => "");
        throw new Error(
          `[global-teardown] LambdaTest API failed: ${response.status} ${response.statusText}` +
            (errorBody ? ` Body: ${errorBody}` : "")
        );
      }

      const data = await response.json();
      const sessions = data?.data || [];

      console.log(`[global-teardown] Found ${sessions.length} LambdaTest sessions`);

      // Extract build ID from the first session that exposes it
      let buildId: string | undefined;
      for (const session of sessions) {
        const sessionBuildId = session.build_id || session.buildId || session.build_number;
        if (sessionBuildId) {
          buildId = sessionBuildId.toString();
          console.log(`[global-teardown] Extracted Build ID: ${buildId}`);
          break;
        }
      }

      // Step 5: Add LambdaTest video links to Allure
      console.log("[global-teardown] Step 5: Adding video links to Allure files...");

      for (const testResult of testResults) {
        const result = testResult.result;
        const testName = result.name?.trim();

        if (!testName) continue;

        const ltSessionParam = result.parameters?.find((p: any) => p.name === "LT_SESSION");
        const sessionName = ltSessionParam?.value;

        if (!sessionName) {
          console.warn(`[global-teardown] No LT_SESSION parameter for test: ${testName}`);
          continue;
        }

        console.log(`[global-teardown] Looking for session: ${sessionName}`);
        const session = sessions.find((s: any) => s.name === sessionName);
        if (!session) {
          console.warn(`[global-teardown] Session "${sessionName}" not found in LT API`);
          console.warn(`[global-teardown]    Available sessions (first 5): ${sessions.slice(0, 5).map((s: any) => s.name).join(", ")}`);
          continue;
        }
        console.log(`[global-teardown] ✓ Found session in LT API: ${session.session_id}`);

        result.links = result.links || [];
        result.links = result.links.filter((link: any) => link.name !== "LambdaTest Video");

        result.links.push({
          name: "LambdaTest Video",
          url: `https://automation.lambdatest.com/logs/?sessionID=${session.session_id}`,
          type: "link",
        });

        // Update LT status
        const testStatus = result.status === "passed" ? "passed" : "failed";

        try {
          await fetch(`https://api.lambdatest.com/automation/api/v1/sessions/${session.session_id}`, {
            method: "PATCH",
            headers: {
              Authorization: `Basic ${auth}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ status_ind: testStatus }),
            signal: AbortSignal.timeout(MAX_TEST_TIMEOUT),
          });
        } catch (e) {
          console.warn(`[global-teardown] Failed to update status for session ${session.session_id}`, e);
        }

        // Safe: testResult.filePath was sanitized with path.basename() during file reading (line 87)
        fs.writeFileSync(testResult.filePath, JSON.stringify(result, null, 2));
        console.log(`[global-teardown] ✓ Added video link for "${testName}"`);
      }

      // Step 6: environment.properties write
      if (buildId) {
        process.env.LT_BUILD_ID = buildId;
      }

      const ltBuildId = buildId || process.env.LT_BUILD_ID;

      let buildUrl: string;

      if (ltBuildId) {
        // Use simple format: ?build=<id> (not pageType)
        buildUrl = `https://automation.lambdatest.com/build?build=${ltBuildId}`;
      } else {
        // Fallback to build name search
        buildUrl = `https://automation.lambdatest.com/build?buildName=${encodeURIComponent(actualBuildName)}`;
      }

      let envContent =
        `LambdaTest.Build.URL=${buildUrl}\n` +
        `LambdaTest.Build.Name=${actualBuildName}\n` +
        (buildIdentifier ? `LambdaTest.Build.Identifier=${buildIdentifier}\n` : "") +
        (ltBuildId ? `LambdaTest.Build.ID=${ltBuildId}\n` : "") +
        `Execution.Mode=LambdaTest Cloud\n`;

      // #cycode_sast_ignore_here Safe: ENV_PROPS_PATH uses path.join() with hardcoded directory and filename, no user input
      fs.writeFileSync(ENV_PROPS_PATH, envContent, "utf-8");

      console.log("[global-teardown] LambdaTest videos added to Allure report successfully.");
      console.log(`[global-teardown] Build URL: ${buildUrl}`);
    } catch (error) {
      console.warn("[global-teardown] Failed to add LambdaTest info:", error);
    }
  }

  const suiteName = getSuiteName();
  const jiraFlagValue = getJiraFlagvalue();
  const isEnabled = shouldUpdateJira();

  console.log(`[global-teardown] Suite: ${suiteName}`);
  console.log(`[global-teardown] Jira update flag: ${jiraFlagValue}`);

  if (!isEnabled) {
    console.log("[global-teardown] Jira sync disabled via environment flag.");
    return;
  }

  try {
    await updateJira();
    console.log("[global-teardown] Jira execution status updated successfully.");
  } catch (error) {
    console.error("[global-teardown] Jira update failed. Test results NOT affected.", error);
  }
};