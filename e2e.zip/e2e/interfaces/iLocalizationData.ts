export interface SurveyLocalizationData {
  locale: string;
  [key: string]: string | string[] | undefined;
}
