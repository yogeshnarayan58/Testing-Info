/**
 * Supported question types rendered by the grid. Mirrors the survey-builder
 * payload contract (see `QuestionType` in `build-survey/models/build-survey.ts`).
 */
export type QuestionType =
  | 'SINGLE_CHOICE'
  | 'MULTIPLE_CHOICE'
  | 'STAR_RATING'
  | 'NET_PROMOTER_SCORE'
  | 'SINGLE_POINT_SCALE'
  | 'MULTIPLE_POINT_SCALE';

/**
 * Shape of the data consumed by <survey-question-grid>. Matches the raw survey
 * question payload:
 * - `options` is used by SINGLE_CHOICE / MULTIPLE_CHOICE.
 * - `rowOptions` + `columnOptions` are used by SINGLE_POINT_SCALE /
 *   MULTIPLE_POINT_SCALE (matrix questions) - SINGLE_POINT_SCALE allows one
 *   selection per row (radio), MULTIPLE_POINT_SCALE allows several (checkbox).
 * - `npsLeftLabel` / `npsRightLabel` are used by NET_PROMOTER_SCORE.
 * - STAR_RATING has no extra fields (rendered as a fixed 1-5 star scale).
 */
export interface Question {
  questionNumber: number;
  question: string;
  type: QuestionType;
  isRequired: boolean;
  options?: string[];
  rowOptions?: string[];
  columnOptions?: string[];
  npsLeftLabel?: string;
  npsRightLabel?: string;
}

/**
 * Internal row shape used inside the grid. A `Question` becomes a
 * "master" row, and when expanded a synthetic "detail" row is inserted
 * directly beneath it so ag-grid (Community) full-width rows can render
 * the question's answer UI without needing the Enterprise Master/Detail
 * feature.
 */
export interface QuestionRow {
  rowType: 'question' | 'detail';
  id: string;
  question?: Question;
  expanded?: boolean;
  parentId?: number;
}
