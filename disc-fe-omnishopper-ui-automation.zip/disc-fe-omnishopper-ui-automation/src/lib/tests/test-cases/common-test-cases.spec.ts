// import test from "@playwright/test";
// import {
//   MAX_TEST_TIMEOUT
// } from "../../constants/time-out-constants";
// import * as timeStampedGroupTestcase from "../reports/time-stamped-groups/time-stamped-groups";
// import * as consumerPerformanceOverviewTestcase from "../reports/consumer-performance-overview/consumer-performance-overview";
// import * as tradePlannerRetailerShareComponentsTestcase from "../reports/trade-planner-retailer-share-components/trade-planner-retailer-share-components";
// import {
//   CommonTestCases,
//   getLocalizationElement
// } from "./common-test-cases-helper-service";
// import { assert, BasePage } from "@gfk/gta";
// import { BasePageFactory } from "../../common/utils/base-page-factory";
// import { ProfilePage } from "../../common/pages/profile-page/profile-page";
// import { LoginPage } from "../../common/pages/login-page/login.Page";
// import { ReportLocalizationData } from "../../common/models/data-model";


// const reportTestCases: { [key: string]: any } = {
//   timeStampedGroupTestcase: timeStampedGroupTestcase,
//   consumerPerformanceOverviewTestcase: consumerPerformanceOverviewTestcase,
//   tradePlannerRetailerShareComponentsTestcase:
//     tradePlannerRetailerShareComponentsTestcase,
//   // Add more reports here in the future if needed
// };

// let commonTestCases: CommonTestCases;
// let loginPage: LoginPage;
// let profilePage: ProfilePage;

// export const omniReportTestcases = (
//   reportTestData: any,
//   localizationData: ReportLocalizationData[],
//   dataset: string,
//   language: string,
//   pivot?: string
// ) => {
//   const ANALYZE_MY_DATA = "[id='analyzemydata']";
//   let basePage: BasePage;
//   test.setTimeout(MAX_TEST_TIMEOUT);
//   // let reportTestData: any;
//   let context: any;

//   test.beforeAll(async () => {
//     basePage = await BasePageFactory.createBasePage();
//     loginPage = new LoginPage(basePage);
//     commonTestCases = new CommonTestCases(basePage);
//     await loginPage.login(basePage);
//     // test.setTimeout(MAX_TEST_TIMEOUT);
//     // await profilePage.setLanguagePreference(basePage, language);
//     console.log("after login");
//   });

//   // test("Validate user language preference change", async () => {
//   //   try {
//   //     profilePage = new ProfilePage(basePage);
//   //     // await profilePage.setLanguagePreference(basePage, language);
//   //     console.log("User profile language successfully changed to ", language)
//   //   } catch (error) {
//   //     console.error("Error changing user languge preference:", error);
//   //     throw error;
//   //   }
//   // });



//   // test("A002_validateQuickLook", async () => {
//   //   try {
//   //     console.log("inside serach report")
//   //     let templateTitle = await commonTestCases.searchReportInAllTemplate(reportTestData, dataset, context, pivot);
//   //     assert(templateTitle[0]).toEqual(getLocalizationElement("title", language, localizationData));
//   //   } catch (error) {
//   //     console.error("Error validating search report in all template:", error);
//   //     throw error;
//   //   }
//   // });

//   // test("A003_validateSearchAndOpenReport", async () => {
//   //   try {
//   //     commonTestCases = new CommonTestCases(basePage);
//   //     console.log("inside serach report")
//   //     let templateTitle = await commonTestCases.searchReportInAllTemplate(reportTestData, dataset, context, pivot);
//   //     assert(templateTitle[0]).toEqual(getLocalizationElement("title", language, localizationData));
//   //   } catch (error) {
//   //     console.error("Error validating search report in all template:", error);
//   //     throw error;
//   //   }
//   // });

//   // test("A004_validateTheSourceOption", async () => {
//   //   try {
//   //     commonTestCases = new CommonTestCases(basePage);
//   //     console.log("inside serach report")
//   //     let templateTitle = await commonTestCases.searchReportInAllTemplate(reportTestData, dataset, context, pivot);
//   //     assert(templateTitle[0]).toEqual(getLocalizationElement("title", language, localizationData));
//   //   } catch (error) {
//   //     console.error("Error validating search report in all template:", error);
//   //     throw error;
//   //   }
//   // });

//   // test("A006_validateInsights", async () => {
//   //   try {
//   //     commonTestCases = new CommonTestCases(basePage);
//   //     console.log("inside serach report")
//   //     let templateTitle = await commonTestCases.searchReportInAllTemplate(reportTestData, dataset, context, pivot);
//   //     assert(templateTitle[0]).toEqual(getLocalizationElement("title", language, localizationData));
//   //   } catch (error) {
//   //     console.error("Error validating search report in all template:", error);
//   //     throw error;
//   //   }
//   // });

 
//   test("Validate run report", async () => {
//     try {
      
//       await commonTestCases.runReport(reportTestData, dataset, context, basePage, pivot);
//       //Todo: add one assertion Ex: visibility of chart/grid componenet
//     } catch (error) {
//       console.error("Error during running the report:", error);
//       throw error;
//     }
//   });

//   // test("D001_validatePresentationMode", async () => {
//   //   try {
//   //     await commonTestCases.presentationMode(reportTestData, dataset, context, basePage, pivot);
//   //   } catch (error) {
//   //     console.error("Error while doing presentation mode:", error);
//   //     throw error;
//   //   }
//   // });

//   // test("F001_validateFullScreen", async () => {
//   //   try {
//   //     await commonTestCases.fullScreenView(reportTestData, dataset, context, basePage, pivot);
//   //   } catch (error) {
//   //     console.error("Error while validating full screen mode:", error);
//   //     throw error;
//   //   }
//   // });

//   //  test("G001_saveTheReport", async () => {
//   //   try {
//   //     await commonTestCases.makeAcopy(reportTestData, dataset, context, basePage, pivot);
//   //   } catch (error) {
//   //     console.error("Error during make a copy:", error);
//   //     throw error;
//   //   }
//   // });

//   // test("validate save the report", async () => {
//   //   await waitUntilVisible('[iconname="slideshow"]', { timeout: MAX_TIMEOUT });
//   //   // await getPage().click('[iconname="slideshow"]');
//   //   await waitUntilVisible('[class="niq-cancel-btn"]', {
//   //     timeout: MAX_TIMEOUT,
//   //   });
//   //   // await getPage().click('[class="niq-cancel-btn"]');
//   //   // Todo: Get the report from FMS
//   // });

//   // test("validate presentation mode", async () => {
//   //   await waitUntilVisible('[iconname="slideshow"]', { timeout: MAX_TIMEOUT });
//   //   await getPage().click('[iconname="slideshow"]');
//   //   await waitUntilVisible('[class="niq-cancel-btn"]', {
//   //     timeout: MAX_TIMEOUT,
//   //   });
//   //   await getPage().click('[class="niq-cancel-btn"]');
//   // });
// };
