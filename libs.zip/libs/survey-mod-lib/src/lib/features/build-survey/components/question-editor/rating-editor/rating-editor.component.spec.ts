import { ElementRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { MAXIMUM_OPTIONS_ALLOWED } from '../../../models/build-survey';
import { RatingEditorComponent } from './rating-editor.component';

describe('RatingEditorComponent', () => {
  const createComponent = () => TestBed.runInInjectionContext(() =>
    new RatingEditorComponent(new ElementRef(document.createElement('div'))),
  );

  it('updates the question and emits on text input', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onInputChange('Rate this product');

    expect(component.question()).toBe('Rate this product');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('converts numeric input to text', () => {
    const component = createComponent();

    component.onInputChange(5);

    expect(component.question()).toBe('5');
  });

  it('clears the question for null input', () => {
    const component = createComponent();
    component.question.set('Existing rating question');

    component.onInputChange(null as unknown as string);

    expect(component.question()).toBe('');
  });

  it('starts with one blank rating row', () => {
    const component = createComponent();

    expect(component.rowOptions()).toEqual(['']);
  });

  it('updates a row label and emits on edit', () => {
    const component = createComponent();
    component.rowOptions.set(['First', 'Second']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onRowEdit(1, 'Updated');

    expect(component.rowOptions()).toEqual(['First', 'Updated']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('ignores an out-of-range row index', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onRowEdit(1, 'Invalid');

    expect(component.rowOptions()).toEqual(['']);
    expect(emit).not.toHaveBeenCalled();
  });

  it('adds a blank row and emits', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.addRow();

    expect(component.rowOptions()).toEqual(['', '']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('does not add rows past the shared maximum', () => {
    const component = createComponent();
    component.rowOptions.set(Array.from({ length: MAXIMUM_OPTIONS_ALLOWED }, (_, index) => `Row ${index + 1}`));
    const emit = vi.spyOn(component.formChange, 'emit');

    component.addRow();

    expect(component.rowOptions()).toHaveLength(MAXIMUM_OPTIONS_ALLOWED);
    expect(emit).not.toHaveBeenCalled();
  });

  it('removes the selected row while keeping at least one', () => {
    const component = createComponent();
    component.rowOptions.set(['First', 'Second']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeRow(0);

    expect(component.rowOptions()).toEqual(['Second']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('does not remove the last rating row', () => {
    const component = createComponent();
    component.rowOptions.set(['Only row']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeRow(0);

    expect(component.rowOptions()).toEqual(['Only row']);
    expect(emit).not.toHaveBeenCalled();
  });

  it.each([-1, 2, 0.5])('does not emit for invalid row index %s', index => {
    const component = createComponent();
    component.rowOptions.set(['First', 'Second']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeRow(index);

    expect(component.rowOptions()).toEqual(['First', 'Second']);
    expect(emit).not.toHaveBeenCalled();
  });

  it('updates required state from the toggle', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: true } } as unknown as Event);

    expect(component.isRequired()).toBe(true);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('defaults required state to false when toggle data is missing', () => {
    const component = createComponent();
    component.isRequired.set(true);

    component.toggleChange({ target: {} } as unknown as Event);

    expect(component.isRequired()).toBe(false);
  });
});
