import test from "@playwright/test";
import {
  findDataSetByName,
  hasPivotInDimensionSelections,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import localizationData from "./test-data/localization-data.json";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import assertionData from "./assertion-data/assertion-data.json";
import { ExportComponent } from "../../../common/components/export/export";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";

let reportTestData = findDataSetByName(devTestData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Product";

test.describe("Trended report (Quick Insights) - Product", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData;
    if (!isValidTestData) {
      console.warn('Skipping Trended Quick Insights Product tests as the test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping Trended Quick Insights Product tests as the test data is not present');
  });

    test(
      "QuickLook: Should display correct preview information when template is selected",
      {
        tag:"@QI:QuickLook",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        let landingPage = new LandingPage(basePage);
        await landingPage.navigateToUrl(config.BASE_URL);
        await landingPage.clickAnalyseMyData();
        await landingPage.clickChooseATemplate();
        let chooseAtemplatePage = new ChooseAtemplatePage(
          landingPage.getBasePage()
        );
        await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
        try {
          await chooseAtemplatePage.hoverThumbnailBySrc(devTestData.common.thumbnailSrc);
        } catch {
          console.warn('Thumbnail hover by src failed, hovering first search result...');
          await chooseAtemplatePage.hoverOnFirstSearchResult();
        }
        await chooseAtemplatePage.clickQuickLookInfoButton();
        let quickLookPage = new QuickLookPage(
          chooseAtemplatePage.getBasePage()
        );
        const previewDescriptionValue = await quickLookPage.getPreviewDescription();
        assert(previewDescriptionValue).toBe(localeData.description);
        const themesValue = await quickLookPage.getPreviewThemes();
        assert(assertionData.common.themes.length > 0).toBeTruthy();
        assertionData.common.themes.forEach((expectedTheme: string) => {
          assert(themesValue).toContain(expectedTheme);
        });
        const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
        assertionData.common.dataSets.forEach((expectedDataset: string) => {
          assert(previewDatasetsValue).toContain(expectedDataset);
        });
      }
    );

  test(
    "Insights Panel: Should validate business questions and report metadata",
    {
      tag: "@QI:Insights",
    },
    async () => {
      const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
      if (!isValidTestData) {
        console.warn('Skipping tests as the required pivot test data is not present');
      }
      test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');

      let basePage = await BasePageFactory.createBasePage();
      const insightsPanel = new InsightsPanel(basePage);
      await insightsPanel.navigateToUrl(reportUrl);
      await insightsPanel.clickInsightsIcon();

      const isTitleVisible = await insightsPanel.isReportInsightsTitleVisible();
      assert(isTitleVisible).toBeTruthy();

      const isCloseIconVisible = await insightsPanel.isReportInsightsPanelCloseIconVisible();
      assert(isCloseIconVisible).toBeTruthy();

      // Validate insights report title
      const insightsReportTitle = await insightsPanel.getInsightsReportTitle();
      assert(insightsReportTitle?.trim()).toBe(localeData.title);

      // Validate insights description
      const description = await insightsPanel.getInsightsPanelDescription();
      assert(description?.trim()).toBe(localeData.description);

      // Validate business questions
      const isBusinessTitleVisible = await insightsPanel.isBusinessQuestionsTitleVisible();
      assert(isBusinessTitleVisible).toBeTruthy();

      if (localeData.businessQuestions && localeData.businessQuestions.length > 0) {
        await insightsPanel.validateBusinessQuestions(localeData.businessQuestions);
      }
      await insightsPanel.closeInsightsPanel();
    }
  );

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@QI:MadlibValidation",
    },
    async () => {
      const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
     
      if (!isValidTestData) {
        console.warn('Skipping tests as the required pivot test data is not present');
      }
      test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');

      let basePage = await BasePageFactory.createBasePage();
      dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      if (localeData.pivotMadlibText) {
        const pivotMadlibTextByKey = localeData.pivotMadlibText as any;
        const expectedMadlibText = pivotMadlibTextByKey[pivot.toLowerCase()];

        if (expectedMadlibText) {
          const actualMadlibText = await dataSelector.getMadlibText();
          console.log("Actual Madlib Text:", actualMadlibText);
          console.log("Expected Pattern:", expectedMadlibText);
          assert(actualMadlibText).toMatch(new RegExp(expectedMadlibText, "i"));
        } else {
          console.warn(
            `No pivot madlib text pattern defined for pivot: ${pivot} and locale: ${localeData.locale}`
          );
        }
      } else {
        console.warn(
          `No pivotMadlibText defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: "@QI:Report_E2E_Flow" },
    () => {
  test(
    "Run Report: Should successfully execute Trended Quick Insights report with selected data",
    {
      tag: "@QI:RunReport",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
      if (!isValidTestData) {
        console.warn('Skipping tests as the required pivot test data is not present');
      }
      test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');

      let basePage = await BasePageFactory.createBasePage();
      dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);

      const productPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
      if (!productPivotData) {
        throw new Error("Pivot not found in test data: Product");
      }

      // 1. Select Facts
      await dataSelector.clickMadlibDimension("Facts");
      await dataSelector.selectClosedDropdown(productPivotData["Facts"]["selections"]);

      // 2. Select Products
      await dataSelector.clickMadlibDimension("Products");
      await dataSelector.setMadlibSelection(productPivotData["Products"]);

      // 3. Select Retailers
      await dataSelector.clickMadlibDimension("Retailers");
      await dataSelector.setMadlibSelection(productPivotData["Retailers"]);

      // 4. Select Geography
      await dataSelector.clickMadlibDimension("Geography");
      await dataSelector.setMadlibSelection(productPivotData["Geography"]);

      // 5. Select Demographic
      await dataSelector.clickMadlibDimension("Demographic");
      await dataSelector.setMadlibSelection(productPivotData["Demographic"]);

      // Run report
      let dsBasePage = await dataSelector.getBasePage();
      commonTestCase = new CommonTestCase(dsBasePage);
      await commonTestCase.clickRunButton();
      await commonTestCase.waitForReportRunCompletion();

      console.log("✅ Trended Quick Insights report executed successfully");

      // Save report
      const { newReportTitle, newUrl } = await commonTestCase.saveReport();
      savedReportTitle = newReportTitle;
      savedReportUrl = newUrl;

      console.log("Saved Report Title:", savedReportTitle);
      console.log("Saved Report URL:", savedReportUrl);
    }
  );

  test(
    "Validate PPT export",
    {
      tag: "@QI:ValidatePPTExport",
    },
    async () => {
      test.skip(!savedReportUrl, 'Skipping PPT Export - Report not generated. Run with @Report_E2E_Flow first');

      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);

      let commonBasePage = commonTestCase.getBasePage();
      let exportComponent = new ExportComponent(commonBasePage);

      await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");

      console.log("✅ Trended Quick Insights Product PPT export validated successfully");
    }
  );

  test(
    "Validate Excel export",
    {
      tag: "@QI:ValidateExcelExport",
    },
    async () => {
      test.skip(!savedReportUrl, 'Skipping Excel Export - Report not generated. Run with @Report_E2E_Flow first');

      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);

      let commonBasePage = commonTestCase.getBasePage();
      let exportComponent = new ExportComponent(commonBasePage);

      await exportComponent.validateExportFunctionality("Excel", "Editable objects", "Separately");

      console.log("✅ Trended Quick Insights Product Excel export validated successfully");
    }
  );

  test(
    "Snapshot: Should successfully create snapshot of Trended Quick Insights report",
    {
      tag: "@QI:Snapshot",
    },
    async () => {
      test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @Report_E2E_Flow first');

      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);

      let snapshot = new Snapshot(commonTestCase.getBasePage());
      await snapshot.waitForReportRunCompletion();
      await basePage.getWebActions().delay(SMALL_TIMEOUT);

      await snapshot.clickSaveIcon();
      await basePage.getWebActions().delay(SMALL_TIMEOUT);

      await snapshot.clickSnapshotIcon();
      await basePage.getWebActions().delay(SMALL_TIMEOUT);

      assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
      await snapshot.shiftingToSnapshot();

      console.log("✅ Trended Quick Insights snapshot created successfully");
    }
  );

  test(
    "Validate FullScreen",
    {
      tag: "@QI:ValidateFullScreen",
    },
    async () => {
    
      test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @Report_E2E_Flow first');

      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);

      await commonTestCase.fullScreenView();

      console.log("✅ Trended Quick Insights Product full-screen view validated successfully");
    }
  );

  test(
    "Validate presentationMode",
    {
      tag: "@QI:PresentationMode",
    },
    async () => {
   
      test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @Report_E2E_Flow first');

      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);

      await commonTestCase.presentationMode();

      console.log("✅ Trended Quick Insights Product presentation mode validated successfully");
    }
  );

    }
  );
});