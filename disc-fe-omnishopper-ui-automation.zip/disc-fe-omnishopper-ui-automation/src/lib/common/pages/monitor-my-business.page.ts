
import { BIG_TIMEOUT, TEST_TIMEOUT } from '../../constants/time-out-constants';
import * as GlobalNavBar from '../../tests/components/globalNavBar';
import { expectElementToBeVisible } from '../utils/assert-utils';
import { waitUntilVisible } from '../utils/element-utils';
export const globalNavBar = () => GlobalNavBar;

const PAGE_HEADER = '[class=header-items]';
const NIQ_INSIGHTS_LAUNCHPAD = "//*[contains(@data-test-id,'launchpad-widget-display')]";

export async function verifyLandingPageLoad() {
    await waitUntilVisible(PAGE_HEADER, { timeout: BIG_TIMEOUT });
    await expectElementToBeVisible(NIQ_INSIGHTS_LAUNCHPAD, { timeout: TEST_TIMEOUT });
}