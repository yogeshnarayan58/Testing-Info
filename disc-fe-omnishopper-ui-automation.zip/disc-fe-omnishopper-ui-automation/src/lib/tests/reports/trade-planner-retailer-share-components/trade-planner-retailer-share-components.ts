import devTestData from './test-data/dev-test-data.json';
import siTestData from './test-data/si-test-data.json';

export async function getReportTestData(env: string) {
  console.log('Get test data');
  if (env == 'dev') {
    return devTestData;
  } else if (env == 'si' ) {
    return siTestData;
  } else {
    return;
  }
}