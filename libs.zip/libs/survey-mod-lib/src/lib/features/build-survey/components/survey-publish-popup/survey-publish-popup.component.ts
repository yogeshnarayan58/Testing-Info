import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, inject, signal, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { CrfDataSummaryModule } from '@nielsen/crf-data-summary';
import { ButtonModule, DialogComponent, DialogModule, IconModule, SpinnerModule, ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { finalize } from 'rxjs';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { PanelistSummaryState, SaveSurveyResponse, SurveyStatusType } from '../../models/build-survey';
import { SurveyService } from '../../services/survey.service';

@Component({
  selector: 'survey-publish-popup',
  standalone: true,
  imports: [CommonModule, ButtonModule, DialogModule, IconModule, SpinnerModule, CrfDataSummaryModule, TranslateModule],
  providers: [TranslateService],
  templateUrl: './survey-publish-popup.component.html',
  styleUrls: ['./survey-publish-popup.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyPublishPopupComponent {
  readonly isPublishing = signal(false);

  private readonly surveyService = inject(SurveyService);
  private readonly surveyCommonService = inject(SurveyCommonService);
  private readonly toastService = inject(ToastService);
  private readonly router = inject(Router);
  private readonly translate = inject(TranslateService);

  @ViewChild('publishDialog') private readonly publishDialog?: DialogComponent;

  get surveyTitle(): string {
    return this.surveyService.title();
  }

  get questionCount(): number {
    return this.surveyService.questions().length;
  }

  get panelistSummaryState(): PanelistSummaryState {
    return this.surveyCommonService.getPanelistDataSelectorState() ?? {};
  }

  get selectedResponseCount(): number {
    return this.surveyCommonService.getSelectPanelistUiState().selectedResponses ?? 0;
  }

  open(): void {
    this.publishDialog?.open();
  }

  close(): void {
    this.publishDialog?.close();
  }

  confirmPublish(): void {
    if (this.isPublishing()) return;

    this.close();
    this.isPublishing.set(true);
    this.surveyService.publishSurvey(SurveyStatusType.PUBLISHED, this.surveyService.currentAssetIdValue)
      .pipe(finalize(() => {
        this.isPublishing.set(false);
        this.surveyService.currentAssetIdValue = null;
      }))
      .subscribe({
        next: () => {
          void this.router.navigateByUrl('/my-assets/survey');
          this.toastService.InsertToast('success', this.translate.instant('SURVEYMOD_SURVEY_PUBLISHED'), { dismissAfter: ToastTime.DISMISSAFTER, size: 'large', containerClass: 'survey-action-toast' });
        },
        error: (error: HttpErrorResponse) => {
          const backendError = error.error as SaveSurveyResponse | null;
          const errorMessage = backendError?.code?.message ?? backendError?.errorMessage ?? this.translate.instant('SURVEYMOD_PUBLISH_FAILED');
          this.toastService.InsertToast('error', errorMessage, { dismissAfter: ToastTime.DISMISSAFTER, size: 'large', containerClass: 'survey-action-toast' });
        },
      });
  }
}