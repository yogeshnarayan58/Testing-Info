import { Component, computed, input } from '@angular/core';
import { TagModule } from '@nielseniq/athena-core';
import { TranslateModule } from '@ngx-translate/core';
import { SuggestionTag } from '../../../models/build-survey';

@Component({
  selector: 'survey-suggestion-tags',
  standalone: true,
  imports: [TagModule, TranslateModule],
  template: `
    <div class="question-suggestion-tags">
      @if (suggestionCounts(); as counts) {
      @if(counts.mandatoryCount > 0) {
      <niq-tag [iconName]="'error'" [size]="'x-small'" variant="error"
        [label]="requiredLabel() | translate: { count: counts.mandatoryCount }"
        [tooltipLabel]="requiredLabel() | translate: { count: counts.mandatoryCount }">
      </niq-tag>
      } @if (counts.optionalCount > 0) {
      <niq-tag [iconName]="'triangle-alert'" [size]="'x-small'" variant="warning" data-test-id="suggestion-tag-recommendation"
        [label]="recommendationLabel() | translate: { count: counts.optionalCount }"
        [tooltipLabel]="recommendationLabel() | translate: { count: counts.optionalCount }">
      </niq-tag>
      }
    }
    </div>
  `,
  styleUrl: './suggestion-tags.component.scss'
})
export class SuggestionTagsComponent {
  suggestionCounts = input<SuggestionTag | null>(null);


  readonly requiredLabel = computed(() =>
    this.suggestionCounts()?.mandatoryCount === 1
      ? 'SURVEYMOD_REQUIRED_CHANGE'
      : 'SURVEYMOD_REQUIRED_CHANGES'
  );

  readonly recommendationLabel = computed(() =>
    this.suggestionCounts()?.optionalCount === 1
      ? 'SURVEYMOD_RECOMMENDATION'
      : 'SURVEYMOD_RECOMMENDATIONS'
  );
}
