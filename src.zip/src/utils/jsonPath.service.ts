import { Injectable } from '@angular/core';
import { jsonPaths } from './translations';

@Injectable({
	providedIn: 'root'
})
export class JsonPathService {
	constructor() {
		return jsonPaths;
	}
}
