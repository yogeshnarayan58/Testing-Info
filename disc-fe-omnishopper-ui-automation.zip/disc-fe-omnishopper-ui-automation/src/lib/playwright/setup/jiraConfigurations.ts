import { request } from '@playwright/test';
import { resolveEnvValue } from '../../common/utils/env-utils';
import { config } from '../config';

let projectID: string, versionID: string, cycleID: string, folderID: string;

type JiraRequestParams = Record<string, string | number | boolean>;

interface JiraVersionSummary {
  label: string;
  value: string | number;
}

interface JiraVersionBoardResponse {
  unreleasedVersions?: JiraVersionSummary[];
  releasedVersions?: JiraVersionSummary[];
}

interface JiraFolder {
  folderName?: string;
  folderId: string | number;
}

const configFallbacks = {
  JiraUrl: config.jiraUrl,
  JiraRelease: config.jiraRelease,
  JiraCycle: config.jiraCycle,
  FolderName: config.jiraFolderName,
  JiraProjectId: config.jiraProjectId,
  AuthorizationKey: config.jiraAuthorizationKey,
} as const;

type JiraConfigKey = keyof typeof configFallbacks;

const envCache: Partial<Record<JiraConfigKey, string>> = {};

const getRequiredEnv = (key: JiraConfigKey): string => {
  if (envCache[key]) {
    return envCache[key] as string;
  }

  const value = resolveEnvValue(key) ?? configFallbacks[key];
  if (!value) {
    throw new Error(`[JIRA] Missing required environment variable: ${key}`);
  }
  envCache[key] = value;
  return value;
};

const getOptionalEnv = (key: JiraConfigKey): string | undefined => {
  if (envCache[key]) {
    return envCache[key] as string;
  }

  const value = (resolveEnvValue(key) ?? configFallbacks[key])?.trim();
  if (!value) {
    return undefined;
  }

  envCache[key] = value;
  return value;
};

export const getJiraUrl = (): string => getRequiredEnv('JiraUrl');

const getAuthKey = (): string => getRequiredEnv('AuthorizationKey');

export const getHeaders = () => ({
  Authorization: `Bearer ${getAuthKey()}`,
  'Content-Type': 'application/json'
});

export async function getCallApi(apiEndPoint: string, params?: JiraRequestParams) {
  const context = await request.newContext();
  const response = await context.get(apiEndPoint, { headers: getHeaders(), params });
  if (!response.ok()) {
    const body = await response.text().catch(() => '<unable to read response body>');
    throw new Error(
      `[JIRA] API request failed: GET ${apiEndPoint} returned HTTP ${response.status()} ${response.statusText()}. Response: ${body}`
    );
  }
  return response;
}

export const getReleaseName = (): string => getRequiredEnv('JiraRelease');
export const getCycleName = (): string => getRequiredEnv('JiraCycle');
export const getFolderName = (): string | undefined => getOptionalEnv('FolderName');

export async function getJiraInfo() {
  try {
    const folderName = getFolderName();
    const releaseName = getReleaseName();
    const cycleName = getCycleName();

    projectID = getRequiredEnv('JiraProjectId');

    versionID = await getVersionID(projectID, releaseName);
    cycleID = await getCycleID(projectID, cycleName, versionID);
    if (folderName) {
      folderID = await getFolderID(projectID, versionID, cycleID, folderName);
      console.log('Jira Info (with folder):', { projectID, versionID, cycleID, folderID });
    } else {
      folderID = '-1';
      console.log('Jira Info (no folder):', { projectID, versionID, cycleID });
    }
  } catch (error) {
    console.error('[JIRA] Jira metadata resolution failed:', error);
    throw error;
  }
}

export async function getVersionID(projectId: string, releaseName: string) {
  const endpoint = `${getJiraUrl()}/rest/zapi/latest/util/versionBoard-list`;
  const response = await getCallApi(endpoint, { projectId });
  const data: JiraVersionBoardResponse = await response.json();
  const normalize = (s: string) => s.trim().toLowerCase();
  const normalizedReleaseName = normalize(releaseName);

  const findVersionByLabel = (versions?: JiraVersionSummary[]) =>
    versions?.find(version => normalize(version.label) === normalizedReleaseName);

  const version = findVersionByLabel(data?.unreleasedVersions) ?? findVersionByLabel(data?.releasedVersions);

  if (!version) throw new Error(`[JIRA] Release '${releaseName}' not found`);
  return String(version.value);
}

export async function getCycleID(projectId: string, cycleName: string, versionID: string) {
  const endpoint = `${getJiraUrl()}/rest/zapi/latest/cycle`;
  const response = await getCallApi(endpoint, { projectId, versionId: versionID });
  const cycles = await response.json();

  for (const [key, value] of Object.entries(cycles)) {
    if (isCycleObject(value) && value.name.toLowerCase() === cycleName.toLowerCase()) {
      return key;
    }
  }
  throw new Error(`[JIRA] Cycle '${cycleName}' not found`);
}

export async function getFolderID(projectId: string, versionID: string, cycleID: string, folderName: string) {
  const endpoint = `${getJiraUrl()}/rest/zapi/latest/cycle/${cycleID}/folders`;
  const response = await getCallApi(endpoint, { projectId, versionId: versionID });
  const folders: JiraFolder[] = await response.json();
  const normalizedTarget = folderName.trim().toLowerCase();
  const folder = folders.find(
    entry => entry.folderName?.trim().toLowerCase() === normalizedTarget
  );
  if (!folder) throw new Error(`[JIRA] Folder '${folderName}' not found under cycle`);
  return String(folder.folderId);
}

function isCycleObject(value: unknown): value is { name: string } {
  return typeof value === 'object' && value !== null && 'name' in value && typeof (value as any).name === 'string';
}

export async function getIssueID(issueKey: string) {
  const endpoint = `${getJiraUrl()}/rest/api/latest/issue/${issueKey}`;
  const response = await getCallApi(endpoint);
  const data = await response.json();
  return data.id;
}

export async function getExecutionId(issueKey: string) {
  const endpoint = `${getJiraUrl()}/rest/zapi/latest/execution/`;
  const issueId = await getIssueID(issueKey);

  const payload: Record<string, string | number> = {
    issueId,
    cycleId: cycleID,
    versionId: versionID,
    projectId: projectID
  };

  if (folderID && folderID !== '-1') {
    payload.folderId = folderID;
  }

  const context = await request.newContext();
  const response = await context.post(endpoint, { data: payload, headers: getHeaders() });
  const data = await response.json();
  const executionKey = Object.keys(data)[0];
  return data[executionKey]?.id;
}