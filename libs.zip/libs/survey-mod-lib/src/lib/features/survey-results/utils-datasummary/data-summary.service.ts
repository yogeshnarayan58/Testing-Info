import { DOCUMENT } from '@angular/common';
import { Injectable, inject, signal } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SavedSurveyDetails, SurveyStatusType } from '../../build-survey/models/build-survey';
import { buildDatasetDisplay } from '../../../shared/utils/survey-dataset-display.util';

const GO_BACK_TO_REPORT_TRANSLATION_KEY = 'EXPORT_FILE_GO_BACK_TO_REPORT';
const SUMMARY_DEFAULTS = {
  title: 'Untitled Report',
  goBackToReport: 'Go back to report',
  copyrightTitle: 'Copyright \u00a9',
  copyrightCompany: 'Nielsen Consumer LLC',
  copyrightRights: 'All Rights Reserved',
  termsAndConditions: 'Terms & Conditions',
  dataset: 'Dataset:',
  currency: 'Currency:',
  font: 'Aktiv Grotesk',
  textColor: '#000000',
  linkColor: '#0000FF',
} as const;
const SAVED_SURVEY_STATUSES: readonly SurveyStatusType[] = [
  SurveyStatusType.PUBLISHED, SurveyStatusType.LIVE, SurveyStatusType.CLOSED,
];
 
/** Create the text style expected by the report renderer. */
function textStyle(alignment: 'LEFT' | 'CENTER', size = 11, color: string = SUMMARY_DEFAULTS.textColor) {
  return { bold: false, alignment, font: { name: SUMMARY_DEFAULTS.font, color, size } };
}

/** Assemble report header and footer metadata in the export format. */
function buildDataSummary(
  title: string,
  summary: string,
  datasetDisplay: string,
  copyrightDisplay: string,
  goBackToReport?: { displayText: string; hyperlink: string },
) {
  return {
    footer: {
      dataSourceInfo: {
        displayText: `${SUMMARY_DEFAULTS.dataset} ${datasetDisplay}`,
        dataSourceTextStyle: textStyle('CENTER'),
      },
      copyrightsInfo: {
        displayText: copyrightDisplay,
        copyrightsTextStyle: textStyle('CENTER'),
      },
      termsAndConditionsInfo: {
        termsAndConditionsText: SUMMARY_DEFAULTS.termsAndConditions,
        termsAndConditionsTextStyle: { ...textStyle('CENTER', 11, SUMMARY_DEFAULTS.linkColor), underline: true },
        termsAndConditionsHyperlinkTextStyle: { ...textStyle('CENTER', 11, SUMMARY_DEFAULTS.linkColor), underline: true },
      },
    },
    header: {
      summary,
      headerTextStyle: { ...textStyle('LEFT'), underline: false },
      title,
      titleTextStyle: { ...textStyle('LEFT', 13), underline: false },
      ...(goBackToReport ? {
        goBackToReportDisplayText: goBackToReport.displayText,
        goBackToReportTextStyle: { ...textStyle('LEFT', 11, SUMMARY_DEFAULTS.linkColor), underline: true },
        hyperlink: goBackToReport.hyperlink,
      } : {}),
    },
  };
}

export type ReportDataSummary = ReturnType<typeof buildDataSummary>;

@Injectable({ providedIn: 'root' })
export class DataSummaryService {
  private readonly document = inject(DOCUMENT);
  private readonly translate = inject(TranslateService);
  private readonly latestDataSummary = signal<ReportDataSummary | null>(null);
  readonly dataSummary = this.latestDataSummary.asReadonly();

  /** Generate and store export metadata from the loaded survey and its visible selections. */
  generateDataSummary(survey: Pick<SavedSurveyDetails, 'name' | 'assetInfo' | 'reportDetail'>): ReportDataSummary | null {
    const requestInstance = survey.reportDetail?.requestInstance;
    if (!this.isObject(requestInstance)) {
      this.clearDataSummary();
      return null;
    }

    const prompts = Array.isArray(requestInstance['prompts']) ? requestInstance['prompts'] : [];
    const summary = prompts
      .filter((prompt): prompt is Record<string, unknown> =>
        this.isObject(prompt) && prompt['hidden'] !== true && prompt['excludeReportSpec'] !== true && prompt['validate'] !== false)
      .sort((first, second) => this.promptOrder(first) - this.promptOrder(second))
      .map(prompt => {
        const selections = Array.isArray(prompt['promptData']) ? prompt['promptData'] : [];
        const labels = selections.flatMap(selection => {
          if (!this.isObject(selection)) {
            return [];
          }
          const label = this.text(selection['promptSelectionLabel']);
          return label ? [label] : Array.isArray(selection['allSelectedValues'])
            ? selection['allSelectedValues'].map(value => this.text(value)).filter(Boolean)
            : [];
        });
        // The report renderer uses #b#...#/b# for bold summary text.
        return labels.length ? `${this.text(prompt['preLabel'])} #b#${labels.join(', ')}#/b#`.trim() : '';
      })
      .filter(Boolean)
      .join(' ');

    const dataSummary = buildDataSummary(
      this.text(survey.assetInfo?.title) || this.text(survey.name) || SUMMARY_DEFAULTS.title,
      summary,
      this.buildDataSourceDisplay(requestInstance),
      this.buildCopyrightDisplay(),
      this.buildGoBackToReport(survey),
    );
    this.latestDataSummary.set(dataSummary);
    return dataSummary;
  }

  /** Return the latest generated summary, or null when none is available. */
  getDataSummary(): ReportDataSummary | null {
    return this.latestDataSummary();
  }

  /** Clear the stored summary when the survey is unavailable or closed. */
  clearDataSummary(): void {
    this.latestDataSummary.set(null);
  }

  /** Resolve the saved order, using zero for an absent or invalid order. */
  private promptOrder(prompt: Record<string, unknown>): number {
    return typeof prompt['promptOrder'] === 'number' && Number.isFinite(prompt['promptOrder']) ? prompt['promptOrder'] : 0;
  }

  /** Format available dataset, view, and currency details for the footer. */
  private buildDataSourceDisplay(requestInstance: Record<string, unknown>): string {
    const datasetType = buildDatasetDisplay(
      { productOfferingCode: requestInstance['productOfferingCode'], type: requestInstance['type'] },
      { ...requestInstance, datasetLabel: '', dataViewName: '' },
    );
    const datasetName = this.text(requestInstance['datasetLabel'] ?? requestInstance['name']);
    const dataViewName = this.text(requestInstance['dataViewName']);
    const currency = this.text(requestInstance['selectedCurrency'] ?? requestInstance['currency']);
    const datasetDisplay = `${datasetType}${datasetName ? ` | ${datasetName}` : ''}${dataViewName ? ` (${dataViewName})` : ''}`;

    return `${datasetDisplay}${currency ? ` | ${SUMMARY_DEFAULTS.currency} ${currency}` : ''}`;
  }

  /** Build the copyright notice using Report Builder translation keys and the current year. */
  private buildCopyrightDisplay(): string {
    const translatedPart = (key: string, fallback: string): string => {
      const value = this.translate.instant(key);
      return typeof value === 'string' && value.trim() && value !== key ? value.trim() : fallback;
    };
    const title = translatedPart('COPY_RIGHT.TITLE', SUMMARY_DEFAULTS.copyrightTitle);
    const companyName = translatedPart('COPY_RIGHT.COMPANY_NAME', SUMMARY_DEFAULTS.copyrightCompany);
    const allRightsReserved = translatedPart('COPY_RIGHT.ALL_RIGHTS_RESERVED', SUMMARY_DEFAULTS.copyrightRights);

    return `${title} ${new Date().getFullYear()} ${companyName}. ${allRightsReserved}.`;
  }

  /** Include a localized return link only for saved surveys with a usable browser URL. */
  private buildGoBackToReport(
    survey: Pick<SavedSurveyDetails, 'assetInfo'>,
  ): { displayText: string; hyperlink: string } | undefined {
    if (!survey.assetInfo?.assetId || !SAVED_SURVEY_STATUSES.includes(survey.assetInfo.status as SurveyStatusType)) {
      return undefined;
    }

    const href = this.document.defaultView?.location.href;
    if (!href) {
      return undefined;
    }

    let hyperlink: string;
    try {
      const reportUrl = new URL(href);
      hyperlink = `${reportUrl.origin}${reportUrl.pathname}`;
    } catch {
      return undefined;
    }

    const translatedText = this.translate.instant(GO_BACK_TO_REPORT_TRANSLATION_KEY);
    return {
      displayText: typeof translatedText === 'string' && translatedText.trim() && translatedText !== GO_BACK_TO_REPORT_TRANSLATION_KEY
        ? translatedText
        : SUMMARY_DEFAULTS.goBackToReport,
      hyperlink,
    };
  }

  /** Normalize optional text values from the API payload. */
  private text(value: unknown): string {
    return typeof value === 'string' ? value.trim() : '';
  }

  /** Distinguish JSON objects from null, arrays, and primitive values. */
  private isObject(value: unknown): value is Record<string, unknown> {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
  }
}