/**
 * Custom Playwright reporter to capture LambdaTest session names.
 * NOTE: This reporter does NOT create sessions - it only captures session names created by 
 * BasePageFactory (which uses getLambdaTestBuildName for consistent build naming).
 * Stores test -> session mapping into individual per-test JSON files 
 * (.lt-sessions/test-<id>-<pid>-<timestamp>.json) to avoid concurrent write conflicts.
 */

import { Reporter, TestCase, TestResult, FullResult } from "@playwright/test/reporter";
import * as fs from "fs";
import * as path from "path";

class LTSessionReporter implements Reporter {
  private testSessions = new Map<string, string>(); // fullName -> sessionName

  onBegin() {
    if (process.env.LAMBDATEST !== "true") return;
    
    console.log("[LT Reporter] Initialized - capturing LambdaTest sessions...");
  }

  onTestBegin(test: TestCase) {
    if (process.env.LAMBDATEST !== "true") return;
    
    process.env.__CURRENT_TEST_ID__ = test.id;
    (global as any).__CURRENT_TEST_ID__ = test.id;

    console.log(`[LT Reporter] Test started: "${test.title}" (testId: ${test.id})`);
  }

  onTestEnd(test: TestCase, result: TestResult) {
    if (process.env.LAMBDATEST !== "true") return;

    const testId = test.id;
    const sessionDir = path.join(process.cwd(), ".lt-sessions");
    const testSessionFile = path.join(sessionDir, `test-${testId}.json`);

    let sessionName: string | null = null;

    try {
      // 1st priority: test-specific session file
      if (fs.existsSync(testSessionFile)) {
        const data = JSON.parse(fs.readFileSync(testSessionFile, "utf-8"));
        sessionName = data.sessionName;

        // cleanup
        try {
          fs.unlinkSync(testSessionFile);
        } catch {}
      }

      // fallback: sessions.jsonl
      if (!sessionName) {
        const sessionsLogFile = path.join(sessionDir, "sessions.jsonl");
        const workerIndex = result.parallelIndex ?? 0;
        const testStartTime = result.startTime?.getTime() || 0;

        if (fs.existsSync(sessionsLogFile)) {
          const lines = fs.readFileSync(sessionsLogFile, "utf-8").split("\n").filter(Boolean);

          let bestMatch: { sessionName: string; diff: number } | null = null;

          for (const line of lines) {
            try {
              const s = JSON.parse(line);
              if (s.workerIndex === workerIndex && s.timestamp && testStartTime) {
                const diff = Math.abs(s.timestamp - testStartTime);
                if (diff < 60000 && (!bestMatch || diff < bestMatch.diff)) {
                  bestMatch = { sessionName: s.sessionName, diff };
                }
              }
            } catch {}
          }

          if (bestMatch) sessionName = bestMatch.sessionName;
        }
      }
    } catch (err) {
      console.error("[LT Reporter] Error reading session:", err);
    }

    if (!sessionName) {
      console.warn(`[LT Reporter] No session found for "${test.title}" (testId: ${testId})`);
      return;
    }

    const fullName = test.titlePath().filter(Boolean).join(" › ");
    // Normalize > separator to › for consistent mapping with globalTeardown
    const normalizedFullName = fullName.replace(/\s*>\s*/g, ' › ');
    
    this.testSessions.set(normalizedFullName, sessionName);

    console.log(`[LT Reporter] Stored: "${normalizedFullName}" -> ${sessionName}`);

    // Write mapping per test/worker to avoid concurrent write conflicts
    try {
      fs.mkdirSync(sessionDir, { recursive: true });

      // Use a collision-resistant filename per test/process to prevent concurrent write conflicts
      const safeTestId = testId.replace(/[^a-zA-Z0-9-]/g, '_');
      const mappingFile = path.join(sessionDir, `test-${safeTestId}-${process.pid}-${Date.now()}.json`);
      fs.writeFileSync(
        mappingFile,
        JSON.stringify({
          testName: test.title,
          fullName: normalizedFullName,
          testId,
          sessionName,
          timestamp: Date.now(),
        }, null, 2),
        "utf-8"
      );

      console.log(`[LT Reporter] Mapping written to ${path.basename(mappingFile)}`);
    } catch (err) {
      console.error("[LT Reporter] Failed to write mapping:", err);
    }
  }

  onEnd(result: FullResult) {
    if (process.env.LAMBDATEST !== "true") return;

    if (this.testSessions.size === 0) {
      console.warn("[LT Reporter] No sessions captured.");
      return;
    }

    try {
      const sessionDir = path.join(process.cwd(), ".lt-sessions");
      fs.mkdirSync(sessionDir, { recursive: true });

      const mappingFile = path.join(sessionDir, "session-mappings.json");
      fs.writeFileSync(mappingFile, JSON.stringify(Object.fromEntries(this.testSessions), null, 2));

      console.log(`[LT Reporter] Saved ${this.testSessions.size} session mappings.`);
    } catch (err) {
      console.error("[LT Reporter] Failed to save mappings:", err);
    }
  }
}

export default LTSessionReporter;