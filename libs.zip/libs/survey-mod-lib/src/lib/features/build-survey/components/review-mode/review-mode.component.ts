import { Component, inject, signal, effect, ChangeDetectionStrategy } from '@angular/core';
import { SurveyService } from '../../services/survey.service';
import { ReviewModeService } from '../../services/review-mode.service';
import { QuestionModel, QuestionTypes } from '../../models/build-survey';
import { DragDropModule, CdkDragDrop, CdkDragStart, moveItemInArray } from '@angular/cdk/drag-drop';
import {
  CardModule,
  IconModule,
  ButtonModule,
  RadioButtonModule,
  CheckboxModule,
  AccordionModule,
  TextFieldModule,
  TooltipModule,
} from '@nielseniq/athena-core';
import { TranslateModule } from '@ngx-translate/core';
@Component({
  selector: 'survey-review-mode',
  imports: [
    CardModule,
    IconModule,
    ButtonModule,
    RadioButtonModule,
    CheckboxModule,
    DragDropModule,
    TextFieldModule,
    AccordionModule,
    TooltipModule,
    TranslateModule
  ],
  standalone: true,
  templateUrl: './review-mode.component.html',
  styleUrls: ['./review-mode.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ReviewModeComponent {
  private surveyService = inject(SurveyService);
  readonly reviewModeService = inject(ReviewModeService);
  questionTypes = QuestionTypes;

  questions = signal<QuestionModel[]>([]);
  readonly npsScale = Array.from({length: 10}, (_, i) => i + 1);
  readonly starScale = Array.from({length: 5}, (_, i) => i + 1);

  constructor() {
    // Keep local signal in sync with service (runs immediately on init, then on changes)
    effect(() => {
      this.questions.set(this.surveyService.questions());
    });
  }

  drop(event: CdkDragDrop<QuestionModel[]>) {
    if (event.previousIndex === event.currentIndex) return;

    const questions = [...this.questions()];
    moveItemInArray(questions, event.previousIndex, event.currentIndex);

    // Recalculate question numbers based on new position
    questions.forEach((q, idx) => {
      q.questionNumber = idx + 1;
    });

    this.surveyService.setQuestions(questions);
  }

  onDragStart(event: CdkDragStart, index: number) {
    // Collapse all items when starting drag
    if (this.questions().length > 0) {
      this.reviewModeService.setAllCardsCollapsed(true);
    }
  }
}