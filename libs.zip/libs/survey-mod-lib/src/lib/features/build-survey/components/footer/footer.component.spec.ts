import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { NO_ERRORS_SCHEMA, signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { FooterComponent } from './footer.component';
import template from './footer.component.html?raw';
import { SurveyAIValidationState, SURVEY_VALIDATION_STATE } from '../../models/build-survey';

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('FooterComponent', () => {
  let component: FooterComponent;
  let mockTranslateService: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
    component = TestBed.runInInjectionContext(() => new FooterComponent());
  });

  describe('isPublishDisable input', () => {
    it('defaults publishing to enabled', () => {
      expect(component.isPublishDisable()).toBe(false);
    });

    it('disables publishing when input is true', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const isPublishDisable = signal(false);
        (testComponent as any).isPublishDisable = isPublishDisable.asReadonly();
        isPublishDisable.set(true);
        TestBed.tick();

        expect(testComponent.isPublishDisable()).toBe(true);
      });
    });
  });

  describe('surveyAIValidationInProgress computed property', () => {
    it('returns true when validation is in progress', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(true);
      });
    });

    it('returns false for readyForValidation state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });

    it('returns false for validationInReview state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });

    it('returns false for readyForPublish state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });

    it('returns false when state is null', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState | null>(null);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.surveyAIValidationInProgress()).toBe(false);
      });
    });
  });

  describe('buttonLabel computed property', () => {
    it('returns revalidate label for validationInReview state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_REVALIDATE_SURVEY');
      });
    });

    it('returns publish label for readyForPublish state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_REVIEW_PUBLISH_SURVEY');
      });
    });

    it('returns validateSurvey label for readyForValidation state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_VALIDATE_SURVEY');
      });
    });

    it('returns validateSurvey label as default for null state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState | null>(null);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_VALIDATE_SURVEY');
      });
    });

    it('returns validateSurvey label as default for unknown state', () => {
      TestBed.runInInjectionContext(() => {
        const testComponent = new FooterComponent();
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (testComponent as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        expect(testComponent.buttonLabel()).toBe('SURVEYMOD_VALIDATE_SURVEY');
      });
    });
  });

  describe('publish output', () => {
    it('emits when publish is requested', () => {
      let emitted = false;
      component.publish.subscribe(() => emitted = true);

      component.publish.emit();

      expect(emitted).toBe(true);
    });
  });

  describe('goBack output', () => {
    it('emits when going back is requested', () => {
      let emitted = false;
      component.goBack.subscribe(() => emitted = true);

      component.goBack.emit();

      expect(emitted).toBe(true);
    });
  });

  describe('validateSurvey output', () => {
    it('emits when validation is requested', () => {
      let emitted = false;
      component.validateSurvey.subscribe(() => emitted = true);

      component.validateSurvey.emit();

      expect(emitted).toBe(true);
    });
  });

  describe('onValidationAction method', () => {
    it('emits publish event when state is readyForPublish', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(true);
        expect(validateEmitted).toBe(false);
      });
    });

      describe('footer action rules', () => {
        it.each([
          [SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION, false, 'SURVEYMOD_VALIDATE_SURVEY', false, false, 'validate'],
          [SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION, true, 'SURVEYMOD_VALIDATE_SURVEY', false, false, 'validate'],
          [SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW, false, 'SURVEYMOD_REVALIDATE_SURVEY', true, false, 'none'],
          [SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW, true, 'SURVEYMOD_REVALIDATE_SURVEY', false, false, 'validate'],
          [SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH, false, 'SURVEYMOD_REVIEW_PUBLISH_SURVEY', false, true, 'publish'],
          [SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS, true, 'SURVEYMOD_REVALIDATE_SURVEY', false, false, 'none'],
        ] as const)('handles %s with reviewRequired=%s', (state, reviewRequired, label, disabled, readyToPublish, action) => {
          TestBed.resetTestingModule();
          TestBed.configureTestingModule({ imports: [TranslateModule.forRoot()] });
          TestBed.overrideComponent(FooterComponent, {
            set: {
              imports: [TranslateModule],
              schemas: [NO_ERRORS_SCHEMA],
              template,
              templateUrl: undefined,
              styles: [],
              styleUrls: [],
            },
          });
          const fixture = TestBed.createComponent(FooterComponent);
          const footer = fixture.componentInstance;
          const minimumQuestionsDisabled = signal(false);
          Object.defineProperties(footer, {
            surveyAIValidationState: { value: signal(state).asReadonly() },
            isReviewRequired: { value: signal(reviewRequired).asReadonly() },
            isPublishDisable: { value: minimumQuestionsDisabled.asReadonly() },
          });
          const publish = vi.fn();
          const validate = vi.fn();
          footer.publish.subscribe(publish);
          footer.validateSurvey.subscribe(validate);

          expect(footer.buttonLabel()).toBe(label);
          expect(footer.isActionDisabled()).toBe(disabled);
          expect(footer.isReadyForPublish()).toBe(readyToPublish);
          fixture.detectChanges();
          const element: HTMLElement = fixture.nativeElement;
          const button = element.querySelector('[data-test-id="publish-survey"], [data-test-id="validate-survey"]');
          expect(button?.getAttribute('data-test-id')).toBe(readyToPublish ? 'publish-survey' : 'validate-survey');
          expect(button?.textContent?.trim()).toBe(label);
          expect(button && Reflect.get(button, 'state')).toBe(
            state === SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS
              ? 'loading'
              : disabled ? 'disabled' : 'default'
          );
          footer.onValidationAction();
          expect(publish).toHaveBeenCalledTimes(action === 'publish' ? 1 : 0);
          expect(validate).toHaveBeenCalledTimes(action === 'validate' ? 1 : 0);

          minimumQuestionsDisabled.set(true);
          expect(footer.isActionDisabled()).toBe(true);
          publish.mockClear();
          validate.mockClear();
          footer.onValidationAction();
          expect(publish).not.toHaveBeenCalled();
          expect(validate).not.toHaveBeenCalled();
        });
      });

    it('emits validateSurvey event when state is not readyForPublish', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(true);
      });
    });

    it('does not emit validateSurvey while suggestions remain without a review requirement', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(false);
      });
    });

    it('emits validateSurvey event when state is null', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState | null>(null);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(true);
      });
    });

    it('does not emit validateSurvey while validation is in progress', () => {
      let publishEmitted = false;
      let validateEmitted = false;
      component.publish.subscribe(() => publishEmitted = true);
      component.validateSurvey.subscribe(() => validateEmitted = true);

      TestBed.runInInjectionContext(() => {
        const validationState = signal<SurveyAIValidationState>(SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS);
        (component as any).surveyAIValidationState = validationState.asReadonly();
        TestBed.tick();

        component.onValidationAction();

        expect(publishEmitted).toBe(false);
        expect(validateEmitted).toBe(false);
      });
    });
  });
});
