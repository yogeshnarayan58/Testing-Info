import { Component, input, output } from '@angular/core';
import { SliderModule, ButtonModule } from '@nielseniq/athena-core';
import { QuestionTypeListComponent } from '../question-type-list/question-type-list.component';
import { DefaultQuestionTypes, GenerateQuestionsRequest, MAX_SURVEY_QUESTIONS, ADD_MORE_QUESTIONS_DEFAULT_COUNT, QUESTION_COUNT_DEFAULT, QuestionType, QuestionTypeOptions } from '../../models/build-survey';
import { TranslateModule } from '@ngx-translate/core';
@Component({
  selector: 'survey-question-generator',
  imports: [SliderModule, ButtonModule, QuestionTypeListComponent, TranslateModule],
  standalone: true,
  templateUrl: './question-generator.html',
  styleUrl: './question-generator.scss',
})
export class QuestionGeneratorComponent {
  readonly minQuestionCount = input(ADD_MORE_QUESTIONS_DEFAULT_COUNT);
  readonly maxQuestionCount = input(MAX_SURVEY_QUESTIONS);
  readonly showGenerateButton = input(true);
  readonly showQuestionTypes = input(true);
  readonly showQuestionCount = input(true);

  questionCount = QUESTION_COUNT_DEFAULT;

  generate = output<GenerateQuestionsRequest>();
  isGenerating = input(false);
  onGenerateQuestions() {
    if (this.isGenerating() || this.isQuestionCountOutOfRange()) {
      return;
    }
    this.generate.emit({
      questionCount: this.questionCount,
      questionTypes: this.selectedQuestionTypes,
    });
  }

  questionTypeOptions = QuestionTypeOptions;
  selectedQuestionTypes: QuestionType[] = [...DefaultQuestionTypes];

  onQuestionCountChange(value: number): void {
    this.questionCount = value;
    if (this.isQuestionCountOutOfRange()) {
      return;
    }
  }

  isQuestionCountOutOfRange(): boolean {
    return this.questionCount < this.minQuestionCount() || this.questionCount > this.maxQuestionCount();
  }


}
