import { BasePage, WebActions } from '@gfk/gta';
import { ResourceManager } from '../../utils/resource-manager';
import { ELEMENT_WAIT_TIMEOUT, NAVIGATION_TIMEOUT } from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';

export abstract class CommonPage {
  protected webActionHandler: WebActions;
  protected resourceManager: ResourceManager;
  /** Component name each subclass registers its resources under; backs getResource(). */
  protected abstract readonly componentName: string;

  constructor(protected basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
  }

  /** Looks up `name` under this page's registered componentName. */
  protected getResource(name: string) {
    return this.resourceManager.getResource(name, this.componentName);
  }

  /** Throws (unlike `waitFor()`, which does not throw on timeout in this framework) if `element` isn't visible within `timeoutMs`. */
  protected async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then clicks it. */
  protected async clickWhenVisible(resourceName: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.click();
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then fills it. */
  protected async fillWhenVisible(
    resourceName: string,
    text: string,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.enterText(text);
  }

  /** Reads the browser's current URL. */
  public async getCurrentUrl(): Promise<string> {
    try {
      return await this.webActionHandler.getPageUrl();
    } catch (error) {
      throw new Error(`Failed to get current URL: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * Navigates the browser to the specified URL within the given timeout.
   *
   * @param targetUrl - The full URL to navigate to.
   * @param timeout - Optional maximum time to wait for navigation. Defaults to NAVIGATION_TIMEOUT.
   */
  public async navigateToUrl(targetUrl: string, timeout: number = NAVIGATION_TIMEOUT): Promise<void> {
    try {
      await this.webActionHandler.navigateTo(targetUrl, timeout, 'domcontentloaded');
    } catch (navigationError) {
      console.error(`Navigation to URL failed: ${targetUrl}`, navigationError);
      throw navigationError;
    }
  }

  /** Joins a base URL with a relative path, normalizing a missing trailing slash first. */
  public buildUrl(baseURL: string, relativePath: string): string {
    const normalizedBaseURL = baseURL.endsWith('/') ? baseURL : `${baseURL}/`;
    return new URL(relativePath, normalizedBaseURL).toString();
  }

  /** Navigates to the survey home page using the configured base URL. */
  public async navigateToSurvey(): Promise<void> {
    const surveyURL = this.buildUrl(envConfig.BASE_URL, 'survey');
    await this.navigateToUrl(surveyURL);
  }
}
