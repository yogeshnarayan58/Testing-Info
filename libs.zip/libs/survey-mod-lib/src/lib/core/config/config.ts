export const FLOW_TYPES = {
  IMPORT: 'import',
  SCRATCH: 'scratch',
  AIFLOW: 'aiflow',
  TEMPLATE: 'template',
} as const;

export type FlowType = typeof FLOW_TYPES[keyof typeof FLOW_TYPES];

export type FlowFlags = Record<FlowType, boolean>;

export const SURVEY_FLOW_STEPS = {
  SELECT_PANELIST: 'select-panelist',
  BUILD_SURVEY: 'build-survey',
  RESULTS: 'results',
} as const;

export type SurveyFlowStep = typeof SURVEY_FLOW_STEPS[keyof typeof SURVEY_FLOW_STEPS];
