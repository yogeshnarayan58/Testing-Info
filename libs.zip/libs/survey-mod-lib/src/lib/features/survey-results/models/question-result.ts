export type ResultChartType = 'MULTIBAR_HORIZONTAL' | 'MULTIBAR_VERTICAL' | 'PIE';
export type JsonObject = Record<string, unknown>;

export interface ChartConfig {
  chartType: ResultChartType;
  dataDefinition: {
    xaxis: { value: string; displayValue: string }[];
    series?: { value: string }[];
    yaxis?: { value: string };
  };
  axisConfig: JsonObject;
  seriesConfig?: JsonObject;
  showPiePercentage?: boolean;
  applyFontSizeForAll?: boolean;
}

export interface DataSummary {
  header: {
    title: string;
    summary: string;
    [key: string]: unknown;
  };
  footer: JsonObject;
}

export interface ReportQuestion {
  qid: string;
  type: string;
  title: string;
}

export interface ChartTemplate {
  chartConfigs: ChartConfig[];
  chartProperty: JsonObject;
}

export enum ReportUiConfigType {
  Chart = 'CHART',
  Grid = 'GRID',
}

export interface ReportUiConfig extends ChartTemplate {
  engine?: 'highcharts';
  id: string;
  type: ReportUiConfigType.Chart;
}

export interface GridTemplate {
  attributes?: JsonObject;
  showTitle?: boolean;
  tableConfig: GridResponse['tableConfig'];
  chartProperty: JsonObject;
}

export interface GridReportUiConfig extends GridTemplate {
  id: string;
  type: ReportUiConfigType.Grid;
}

export interface ReportObject extends JsonObject {
  id: string;
  specId: string;
  type: string;
  name: string;
  title?: string;
  hideInExport?: boolean;
}

export interface ReportContainer extends JsonObject {
  id: string;
  objectId: string;
  positionX: number;
  positionY: number;
  width: number;
  height: number;
  order: number;
}

export interface ReportSpec {
  id: string;
  uiConfigs: (ReportUiConfig | GridReportUiConfig)[];
  objects: ReportObject[];
  containers: ReportContainer[];
  dataSummary?: DataSummary;
}

export interface QuestionReportRequest {
  attributes: JsonObject;
  reportSpec: {
    id: string;
    specs: ReportSpec[];
  };
  jobId: string;
}

export interface QuestionChartPreview {
  gridResponse?: GridResponse;
  configs: ChartConfig[];
  properties: JsonObject;
  data: JsonObject[];
  metadata: JsonObject;
}

export interface QuestionChartResponse {
  data: {
    components: {
      chartConfigs: ChartConfig[];
      chartProperty: JsonObject;
      objects: {
        data: JsonObject[];
        metadata: JsonObject;
      };
    }[];
  }[];
}

export interface QuestionChartContext {
  surveyId: string | null;
  surveyTitle: string;
  question: ReportQuestion;
  dataSummary?: DataSummary;
}

export interface CommonReportTemplate {
  attributes: JsonObject;
  reportSpec: {
    id: string;
    specs: Omit<ReportSpec, 'dataSummary'>[];
  };
  jobId: string;
}

export interface GridCell {
  id?: string;
  isConcat?: boolean;
  uniqueColumnId?: string;
  cellValue?: string | number | null;
  styleId?: string;
  format?: string;
  factType?: string;
  altDesc?: string;
  cellValueMasked?: boolean;
  maskRefId?: string | number;
  originalCellValue?: string | number;
  mergeNextCell?: boolean;
  mergeHeaderCell?: string;
  indent?: number;
  [key: string]: unknown;
}

export interface GridTooltipValue {
  value: string | number | null | undefined;
  masked?: boolean;
  header?: string;
  message?: string;
}

export interface GridMetadata {
  type?: string;
  isSkipUISorting?: boolean;
  isSkipColFormatting?: boolean;
  isFact?: boolean;
  format?: string;
  hoverText?: string;
  factType?: string;
  maskReference?: {
    maskRefId: string | number;
    maskReasons?: { message?: string }[];
  }[];
}

export interface GridProperty {
  autoFit?: boolean;
  trimChar?: number;
  cellTooltip?: boolean;
  specificColorFormat?: boolean;
  shade?: { color?: string };
  bandedShade?: { color?: string };
  alignment?: 'left' | 'center' | 'right';
  width?: number;
  pinnedLeft?: boolean;
  enableSort?: boolean;
  enableFilter?: boolean;
  enableColumnResizing?: boolean;
  enableColumnMoving?: boolean;
  textStyle?: { alignment?: 'LEFT' | 'CENTER' | 'RIGHT'; italic?: boolean; bold?: boolean; underline?: boolean; font?: { color?: string; size?: number } };
}

export interface GridAttributes {
  rowHeaderCount?: string | number;
  columnHeaderCount?: string | number;
  totalColumns?: string | number;
  recordCount?: number;
  totalRecordCount?: number;
  [key: string]: string | number | undefined;
}

export interface GridResponse {
  id?: string;
  type: string;
  chartType?: string;
  objects: {
    id?: string;
    currency?: string;
    title?: string;
    attributes?: GridAttributes;
    data: Record<string, GridCell>[];
    metadata: Record<string, GridMetadata>;
  };
  tableConfig: {
    id?: string;
    type?: string;
    chartType?: string;
    headerRow?: boolean;
    columnStyleForHeader?: boolean;
    totalRow?: boolean;
    bandedRows?: boolean;
    firstColumn?: boolean;
    lastColumn?: boolean;
    bandedColumns?: boolean;
    transpose?: boolean;
    subtitleColumn?: string;
    numberScalingInExport?: boolean;
    mode?: string;
    removeExtraColumn?: boolean;
    groupingEnabled?: boolean;
    showFooter?: boolean;
    dataDefinition?: { value: string }[];
    altDescEnabled?: boolean;
    hideInExport?: boolean;
    rowProperties?: Record<string, GridProperty>;
    defaultRowProperty?: GridProperty;
    defaultColumnProperty?: GridProperty;
    columnProperties?: Record<string, GridProperty>;
    numHeaderRows?: number;
    enableClick?: { type: 'row' | 'cell'; selectedRowIndex?: number };
    [key: string]: unknown;
  };
}

export interface QuestionGridResponse {
  qid: string;
  components: GridResponse[];
}
