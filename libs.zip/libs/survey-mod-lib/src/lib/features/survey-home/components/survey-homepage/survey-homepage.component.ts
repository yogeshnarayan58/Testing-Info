import { Component, ChangeDetectionStrategy, CUSTOM_ELEMENTS_SCHEMA, DestroyRef, inject, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { 
  CardModule, 
  IconModule, 
  ButtonModule,
  TilesModule
} from '@nielseniq/athena-core';
import { TranslateModule } from '@ngx-translate/core';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyExceptionHandlingService } from '../../../../shared/services/survey-exception-handling.service';
import { SurveyAssetApiService } from '../../../my-assets/services/survey-asset-api.service';
import { SurveyGridHandlerService } from '../../../my-assets/services/survey-grid-handler.service';
import { FEATURE_CARDS, HELP_ITEMS, QUICK_SURVEY_CARDS, PREBUILT_SURVEYS, SURVEY_CREDITS, SURVEY_CREDITS_NO_USAGE, Survey, SURVEY_PREVIEW_RESPONSE_COUNTS, DEFAULT_RESPONSE_COUNT, SURVEY_HOME_FETCH_LIMIT, FeatureCard, HelpItem } from '../../models/survey-home';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize } from 'rxjs';
import { SURVEY_STATUS_DISPLAY, SurveyStatusVariant } from '../../../my-assets/constants/survey-status.constant';
import { SurveyStatusType } from '../../../build-survey/models/build-survey';
import { SurveyGridAsset } from '../../../my-assets/models/survey-asset.model';

@Component({
  selector: 'survey-mod-survey-homepage',
  standalone: true,
  imports: [CommonModule, CardModule, IconModule, ButtonModule, TilesModule, TranslateModule],
  templateUrl: './survey-homepage.component.html',
  styleUrls: ['./survey-homepage.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SurveyHomepageComponent implements OnInit {
  private readonly router = inject(Router);
  private readonly surveyCommonService = inject(SurveyCommonService);
  private readonly surveyService = inject(SurveyService);
  private readonly surveyAssetApi = inject(SurveyAssetApiService);
  private readonly exceptionHandlingService = inject(SurveyExceptionHandlingService);
  private readonly surveyGridHandler = inject(SurveyGridHandlerService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly CREATED_THRESHOLD_MS = 1000; // Within 1 second

  readonly surveys = signal<Survey[]>([]);
  readonly isLoadingSurveys = signal(false);
  readonly loadedSuccessfully = signal(false);
  readonly surveyTotalCount = signal(0);
  readonly features = FEATURE_CARDS;
  readonly helpItems = HELP_ITEMS;
  readonly quickSurveyCards = QUICK_SURVEY_CARDS;
  readonly prebuiltSurveys = PREBUILT_SURVEYS;
  readonly isNewUser = computed(() => 
    this.loadedSuccessfully() && 
    this.surveys().length === 0 && 
    this.surveyTotalCount() === 0
  );
  readonly surveyCredits = computed(() =>
    this.isNewUser()
      ? SURVEY_CREDITS_NO_USAGE
      : SURVEY_CREDITS
  );

  ngOnInit(): void {
    this.loadSurveys();
  }

  private loadSurveys(): void {
    this.isLoadingSurveys.set(true);
    this.loadedSuccessfully.set(false);
    
    // Using undefined values to skip optional params (sortModel, pageSize, tab)
    // Last param (true) enables surveyTypesOnly
    this.surveyAssetApi.fetchSurveyAssets(0, SURVEY_HOME_FETCH_LIMIT, undefined, undefined, undefined, true)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.isLoadingSurveys.set(false))
      )
      .subscribe({
        next: (response) => {
          const recentSurveys = this.getRecentSurveys(response.assets || []);
          this.surveys.set(recentSurveys);
          this.surveyTotalCount.set(response.totalCount || 0);
          this.loadedSuccessfully.set(true);
        },
        error: (err) => {
          this.exceptionHandlingService.handleApiError(err);
        }
      });
  }

  private getRecentSurveys(surveys: SurveyGridAsset[]): Survey[] {
    return surveys.map((asset: SurveyGridAsset, index: number) => this.transformAssetToSurvey(asset, index));
  }

  private isNewlyCreatedSurvey(asset: SurveyGridAsset): boolean {
    const created = asset.initialCreationTimestamp || asset.lastModifiedTimestamp || 0;
    const modified = asset.lastModifiedTimestamp || 0;
    return Math.abs(created - modified) < this.CREATED_THRESHOLD_MS;
  }

  private getEffectiveTimestamp(asset: SurveyGridAsset): number {
    return asset.lastModifiedTimestamp || asset.initialCreationTimestamp || 0;
  }

  private transformAssetToSurvey(asset: SurveyGridAsset, index?: number): Survey {
    const statusMapping = this.mapStatus(asset.status || 'DRAFT');
    const { dateLabel, dateLabelText, dateTimestamp } = this.determineDateInfo(asset, statusMapping);
    const dateStr = this.formatDate(dateTimestamp);
    const responseCount = (statusMapping.internal === 'in-progress' || statusMapping.internal === 'closed')
      ? SURVEY_PREVIEW_RESPONSE_COUNTS[index ?? 0] || DEFAULT_RESPONSE_COUNT
      : DEFAULT_RESPONSE_COUNT;

    return {
      id: asset.assetId,
      name: asset.title,
      status: statusMapping.internal,
      statusText: statusMapping.display,
      icon: statusMapping.icon,
      dateLabel,
      dateLabelText,
      date: dateStr,
      responseCount,
      variant: statusMapping.variant,
      launchURL: asset.launchURL,
      originalStatus: asset.status || 'DRAFT'
    };
  }

  private determineDateInfo(asset: SurveyGridAsset, statusMapping: any): { dateLabel?: string; dateLabelText?: string; dateTimestamp: number } {
    return statusMapping.internal !== 'draft'
      ? this.getPublishedDateInfo(asset, statusMapping)
      : this.getDraftDateInfo(asset, statusMapping);
  }

  private getPublishedDateInfo(asset: SurveyGridAsset, statusMapping: any): { dateLabel: string; dateTimestamp: number } {
    const dateLabel = statusMapping.internal === 'in-progress' 
      ? 'SURVEYMOD_STATUS_PUBLISHED' 
      : 'SURVEYMOD_STATUS_CLOSED';
    const dateTimestamp = statusMapping.internal === 'in-progress'
      ? (asset.publishedTimestamp || this.getEffectiveTimestamp(asset))
      : this.getEffectiveTimestamp(asset);
    return { dateLabel, dateTimestamp };
  }

  private getDraftDateInfo(asset: SurveyGridAsset, statusMapping: any): { dateLabel?: string; dateLabelText?: string; dateTimestamp: number } {
    if (this.isNewlyCreatedSurvey(asset)) {
      return { dateLabel: 'SURVEYMOD_STATUS_CREATED', dateTimestamp: asset.initialCreationTimestamp || this.getEffectiveTimestamp(asset) };
    }
    if (asset.lastModifiedTimestamp && asset.lastModifiedTimestamp !== asset.initialCreationTimestamp) {
      return { dateLabelText: 'Modified', dateTimestamp: asset.lastModifiedTimestamp };
    }
    return { dateLabel: statusMapping.dateLabel, dateTimestamp: this.getEffectiveTimestamp(asset) };
  }

  private mapStatus(status: string): { internal: 'closed' | 'in-progress' | 'draft'; display: string; icon: string; dateLabel: string; variant: SurveyStatusVariant } {
    const normalized = status.toUpperCase() as SurveyStatusType;
    const statusDisplay = SURVEY_STATUS_DISPLAY[normalized];
    
    if (!statusDisplay) {
      return {
        internal: 'draft' as const,
        display: 'SURVEYMOD_STATUS_DRAFT',
        icon: 'edit',
        dateLabel: 'SURVEYMOD_STATUS_CREATED',
        variant: 'info' as SurveyStatusVariant
      };
    }
    
    return {
      internal: this.normalizeStatusInternal(normalized),
      display: statusDisplay.label,
      icon: statusDisplay.icon || 'edit',
      dateLabel: statusDisplay.dateLabel || 'Created',
      variant: statusDisplay.variant
    };
  }

  private normalizeStatusInternal(status: SurveyStatusType): 'closed' | 'in-progress' | 'draft' {
    if (status === SurveyStatusType.CLOSED) return 'closed';
    if (status === SurveyStatusType.PUBLISHED) return 'in-progress';
    if (status === SurveyStatusType.DRAFT) return 'draft';
    return 'draft'; 
  }

  private formatDate(timestamp?: number): string {
    if (!timestamp) {
      return '--/--';
    }
    const dateObj = new Date(timestamp);
    const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
    const day = dateObj.getDate().toString().padStart(2, '0');
    return `${month}/${day}`;
  }

  navigateToMyAssets(): void {
    this.router.navigate(['/my-assets/survey']);
  }

  navigateToSurvey(survey: Survey): void {
    if (survey.launchURL) {
      const normalizedUrl = this.surveyGridHandler.getSafeLaunchUrl(survey.launchURL, survey.originalStatus);
      if (normalizedUrl) {
        this.surveyCommonService.resetState();
        this.surveyService.reset();
        const urlToNavigate = normalizedUrl.startsWith(document.baseURI)
          ? normalizedUrl.replace(document.baseURI, '/')
          : normalizedUrl;
        void this.router.navigateByUrl(urlToNavigate);
      }
    }
  }

  navigateToSelectPanelist(): void {
    this.resetSurveyState();
    this.router.navigate(['/survey/select-panelist']);
  }

  navigateToAiflow(): void {
    this.resetSurveyState();
    this.router.navigate(['/survey/aiflow/select-panelist']);
  }

  resetSurveyState(): void {
    this.surveyService.reset();
    this.surveyCommonService.resetState();
  }

  calculateProgressPercent(responseCount: string | undefined): number {
    if (!responseCount) return 0;
    const match = responseCount.match(/(\d+)\/(\d+)/);
    if (match) {
      const collected = parseInt(match[1], 10);
      const target = parseInt(match[2], 10);
      return target > 0 ? (collected / target) * 100 : 0;
    }
    return 0;
  }

  isDraftSurvey(survey: Survey): boolean {
    return survey.status === 'draft';
  }

  openHelpItemOrFeature(item: FeatureCard | HelpItem): void {
    if (item.url) {
      window.open(item.url, '_blank', 'noopener');
    }
  }
}
