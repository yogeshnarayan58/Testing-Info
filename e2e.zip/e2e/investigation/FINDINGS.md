# E2E Investigation Findings, round 2: publish popups, save draft, test inventory (read-only; no code changed)

Paths are relative to `e2e\` unless they start with `libs\`. Code is copied verbatim from the current files (state at 2026-11-05).
Not available to me in this read-only pass: git history (no terminal) and the translation files (the app's `SURVEYMOD_*` keys are not in this repo), so exact UI wording behind the keys is not confirmed.

> The older round-1 findings (Rating, Rephrase, round-1 state map) are kept at the bottom of this file under "ARCHIVE" because the file could not be deleted without a terminal. Round 1 is superseded where it disagrees with this section (code has changed since).

---

## 1. PUBLISH TESTS

### 1.1 TC_BS_17: `registerPublishPopupCancelTest` (`tests\survey\common-test-cases\build-survey-common-test-cases.ts`)

```ts
export function registerPublishPopupCancelTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_17: Publish popup Cancel leaves the survey unpublished',
    { tag: options?.tag ?? '@PublishPopup' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
      await surveyBuilderPage.ensureQuestionCount(3);
      await surveyBuilderPage.openPublishDialog();

      const countBefore = await surveyBuilderPage.getQuestionCount();

      assertTrue(await surveyBuilderPage.isPublishLocationDialogVisible(), 'Expected "Publish your survey" dialog to be visible');
      assertTrue(
        await surveyBuilderPage.isPublishLocationDialogContinueDisabled(),
        'Expected Continue to be disabled before selecting a location'
      );

      await surveyBuilderPage.clickPublishLocationDialogCancel();

      assertTrue(
        !(await surveyBuilderPage.isPublishLocationDialogVisible()),
        'Expected "Publish your survey" dialog to be closed after Cancel'
      );
      assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Expected Build Survey page still shown after Cancel');
      const countAfter = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfter === countBefore, `Expected question count unchanged after Cancel (before ${countBefore}, after ${countAfter})`);
    }
  );
}
```

### 1.2 TC_BS_24 / TC_AI_14: `registerCreateFolderFromPublishPopupTest` (same file)

```ts
export function registerCreateFolderFromPublishPopupTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_24: Create a new folder from the Publish popup',
    { tag: options?.tag ?? '@PublishPopup' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
      await surveyBuilderPage.ensureQuestionCount(3);
      await surveyBuilderPage.openPublishDialog();

      await surveyBuilderPage.clickCreateNewFolderLink();

      assertTrue(await surveyBuilderPage.isCreateNewFolderDialogVisible(), 'Expected "Create new folder" dialog to be visible');
      const controls = await surveyBuilderPage.areCreateNewFolderDialogControlsVisible();
      assertTrue(controls.nameInput, 'Expected Name field visible in "Create new folder" dialog');
      assertTrue(controls.cancel, 'Expected Cancel visible in "Create new folder" dialog');
      assertTrue(controls.create, 'Expected Create visible in "Create new folder" dialog');
      assertTrue(controls.close, 'Expected close X visible in "Create new folder" dialog');

      const folderName = `${testData.folders.newFolder}${uniqueNameSuffix()}`;
      await surveyBuilderPage.fillCreateNewFolderDialogName(folderName);
      await surveyBuilderPage.clickCreateNewFolderDialogCreate();

      assertTrue(
        await surveyBuilderPage.isPublishLocationFolderHighlighted(folderName),
        `Expected new folder "${folderName}" to be listed and highlighted in "Choose a location"`
      );
      assertTrue(
        !(await surveyBuilderPage.isPublishLocationDialogContinueDisabled()),
        'Expected Continue to be enabled with the new folder selected'
      );

      await surveyBuilderPage.clickPublishLocationFolder(folderName);
      await surveyBuilderPage.clickCreateNewFolderInLocation();
      assertTrue(await surveyBuilderPage.isCreateNewFolderDialogVisible(), 'Expected nested "Create new folder" dialog to be visible');

      await surveyBuilderPage.clickCreateNewFolderDialogCancel();

      assertTrue(
        !(await surveyBuilderPage.isCreateNewFolderDialogVisible()),
        'Expected nested "Create new folder" dialog to close after Cancel'
      );
      assertTrue(await surveyBuilderPage.isPublishLocationDialogVisible(), 'Expected "Publish your survey" dialog to be shown again');

      await surveyBuilderPage.clickPublishLocationDialogCancel();
      assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Expected Build Survey page still shown after closing the popup');
    }
  );
}
```

Helper used for the folder/survey names (same file):

```ts
// Short readable per-run suffix, e.g. " - 04 Nov 22:55" (date and minute, so same-day reruns rarely collide).
function uniqueNameSuffix(): string {
  const now = new Date();
  const date = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
  return ` - ${date} ${time}`;
}
```

### 1.3 TC_BS_16 / TC_BS_18: publish test (`tests\survey\start-from-scratch.spec.ts`, Scratch only, still `test.fixme`)

```ts
  test.fixme('TC_BS_16/TC_BS_18: Publish survey', { tag: '@PublishSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const title = `Publish_${Date.now()}`;
    const SELECTED_RESPONSE_COUNT = 250; // Setup used click250Responses()
    await surveyBuilderPage.ensureQuestionCount(3);
    await surveyBuilderPage.publishSurvey(title);
    const areDimensionsShown = await surveyBuilderPage.isPublishDialogDimensionCountVisible(datasetConfig.dimensionSelections.length);
    assertTrue(areDimensionsShown, `Expected ${datasetConfig.dimensionSelections.length} dimension selections in Confirm publish? dialog`);

    const responseSummaryText = await surveyBuilderPage.getPublishResponseSummaryText();
    assertTrue(
      responseSummaryText.includes(String(SELECTED_RESPONSE_COUNT)),
      `Expected "${SELECTED_RESPONSE_COUNT} responses" in Confirm publish? dialog, got "${responseSummaryText}"`
    );

    const confirmClickTime = Date.now();
    const isPublishConfirmed = await surveyBuilderPage.confirmPublish();
    assertTrue(isPublishConfirmed, 'Expected "Confirm publish?" prompt and "Publishing survey" status to appear');
    const isSuccessToastVisible = await surveyBuilderPage.verifyPublishSucceeded(confirmClickTime);
    assertTrue(isSuccessToastVisible, 'Expected "Survey published successfully" message after publish');
  });
```

Prompt flow has no TC_BS_16/18 test.

### 1.4 Page-object methods these tests use (`page-objects\common\survey-builder.page.ts`)

Shared base helpers (`page-objects\common\common-page.ts`): `waitUntilVisible`, `clickWhenVisible`, `fillWhenVisible` (code in round-1 section 1.3 below).

```ts
  /** Tops up to `min` Rating questions; the Rating tile toggles closed if add-question is clicked while already open, so only click it when not visible. */
  async ensureQuestionCount(min: number): Promise<void> {
    try {
      const { questionText } = devTestData.surveyQuestions.rating;
      let questionNumbers = await this.getQuestionNumbers();

      while (questionNumbers.length < min) {
        const countBeforeAdd = questionNumbers.length;
        const typeTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));

        if (!(await typeTile.isVisible(SMALL_TIMEOUT))) {
          await this.clickAddQuestion();
          if (!(await typeTile.isVisible(MEDIUM_TIMEOUT))) {
            throw new Error(`Question-type picker did not open after clicking add-question (current question count: ${countBeforeAdd})`);
          }
        }

        await this.addRatingQuestion(`${questionText} ${countBeforeAdd + 1}`);
        questionNumbers = await this.waitForQuestionCountAtLeast(countBeforeAdd + 1, MEDIUM_TIMEOUT);
      }
    } catch (error) {
      throw new Error(`Failed to ensure question count: ${error instanceof Error ? error.message : error}`);
    }
  }
```

```ts
  async clickValidateSurvey(): Promise<void> {
    await this.clickWhenVisible('validateSurveyButton', 'Validate survey button');
  }

  async waitForValidationComplete(): Promise<void> {
    const nativePage = (BasePage as any).page as import('playwright').Page;
    await nativePage.locator('.footer-page-loader').waitFor({ state: 'hidden', timeout: NAVIGATION_TIMEOUT });
  }

  async validateSurvey(): Promise<void> {
    try {
      await this.clickValidateSurvey();
      await this.waitForValidationComplete();
    } catch (error) {
      throw new Error(`Failed to validate survey: ${error instanceof Error ? error.message : error}`);
    }
  }
```

```ts
  /** Persistent (non-toast) signal that validation finished: 'publishSurveyButton' has replaced 'validateSurveyButton'. */
  async isValidationCompleted(): Promise<boolean> {
    const publishButton = this.webActionHandler.getWebElement(this.getResource('publishSurveyButton'));
    const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
    const [isPublishVisible, isValidateHidden] = await Promise.all([
      publishButton.isVisible(ELEMENT_WAIT_TIMEOUT),
      validateButton.isHidden(),
    ]);
    return isPublishVisible && isValidateHidden;
  }

  async isViewOptiqFeedbackLinkVisible(): Promise<boolean> {
    const link = this.webActionHandler.getWebElement(this.getResource('viewOptiqFeedbackLink'));
    return await link.isVisible(SMALL_TIMEOUT);
  }

  /** Closes the validate/publish toast if one is still showing; does nothing otherwise. */
  async dismissToastIfVisible(): Promise<void> {
    const closeButton = this.webActionHandler.getWebElement(this.getResource('toastCloseButton'));
    if (await closeButton.isVisible(SMALL_TIMEOUT)) {
      await closeButton.click();
    }
  }


  async openPublishDialog(): Promise<void> {
    try {
      const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
      if (await validateButton.isVisible(SMALL_TIMEOUT)) {
        await this.validateSurvey();
      }
      await this.dismissToastIfVisible();

      await this.clickWhenVisible('publishSurveyButton', 'Publish survey button');
    } catch (error) {
      throw new Error(`Failed to open Publish dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  async publishSurvey(title: string): Promise<void> {
    try {
      await this.openPublishDialog();

      const titleInput = this.webActionHandler.getWebElement(this.getResource('saveCopyTitleInput'));
      const confirmDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      const [isTitleInputVisible, isConfirmDialogVisible] = await Promise.all([
        titleInput.isVisible(ELEMENT_WAIT_TIMEOUT),
        confirmDialogText.isVisible(ELEMENT_WAIT_TIMEOUT),
      ]);

      if (isTitleInputVisible) {
        await this.fillSaveCopyDialog(title);
      } else if (!isConfirmDialogVisible) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        throw new Error(
          `Neither the Save-a-copy dialog nor the Review survey details dialog appeared after clicking Publish (url: ${currentUrl})`
        );
      }
    } catch (error) {
      throw new Error(`Failed to publish survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Checks the last expected dimension index is visible in the Review survey details dialog's Quick review list. */
  async isPublishDialogDimensionCountVisible(expectedCount: number): Promise<boolean> {
    try {
      if (expectedCount <= 0) return true;
      const lastDimension = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          'publish-dialog-dimension-by-index',
          String(expectedCount - 1),
          SURVEY_BUILDER_PAGE_COMPONENT_NAME
        )
      );
      await this.waitUntilVisible(lastDimension, `Publish dialog dimension (index ${expectedCount - 1})`, 10000);
      return await lastDimension.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to verify Review survey details dimension count: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getPublishResponseSummaryText(): Promise<string> {
    try {
      const responseCount = this.webActionHandler.getWebElement(this.getResource('publish-response-count-text'));
      await this.waitUntilVisible(responseCount, 'Publish response count text', 10000);
      const text = await responseCount.getText();
      return (text ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read Review survey details response summary: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Polls until redirect to /my-assets plus success toast, or fails fast if `.survey-action-toast` shows non-success text (there's no separate error-only locator). */
  async verifyPublishSucceeded(confirmClickTime: number): Promise<boolean> {
    try {
      const elapsedSeconds = () => ((Date.now() - confirmClickTime) / 1000).toFixed(1);
      const actionToast = this.webActionHandler.getWebElement(this.getResource('survey-action-toast'));
      const successToast = this.webActionHandler.getWebElement(this.getResource('publish-success-toast'));

      const deadline = Date.now() + NAVIGATION_TIMEOUT;
      while (Date.now() < deadline) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        if (currentUrl.includes('my-assets')) {
          if (await successToast.isVisible(MEDIUM_TIMEOUT)) {
            return true;
          }
          const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
          throw new Error(
            `"Survey published successfully" toast did not appear after redirect (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`
          );
        }

        if (!(await actionToast.isHidden())) {
          const toastText = await actionToast.getText();
          if (!toastText.includes('Survey published successfully')) {
            throw new Error(`Publish failed: "${toastText}" (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s)`);
          }
        }

        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }

      const currentUrl = await this.webActionHandler.getPageUrl();
      const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
      throw new Error(
        `Timed out waiting for navigation to /my-assets after Confirm (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`
      );
    } catch (error) {
      throw new Error(`Failed to verify publish succeeded: ${error instanceof Error ? error.message : error}`);
    }
  }

  async confirmPublish(): Promise<boolean> {
    try {
      const confirmPublishDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      await this.waitUntilVisible(confirmPublishDialogText, 'Review survey details dialog text');
      const isConfirmDialogVisible = await confirmPublishDialogText.isVisible();

      await this.clickWhenVisible('confirmPublishButton', 'Confirm publish button');

      const publishingSurveyStatus = this.webActionHandler.getWebElement(this.getResource('publishingSurveyStatus'));
      await this.waitUntilVisible(publishingSurveyStatus, 'Publishing survey status');
      const isPublishingStatusVisible = await publishingSurveyStatus.isVisible();

      return isConfirmDialogVisible && isPublishingStatusVisible;
    } catch (error) {
      throw new Error(`Failed to confirm publish: ${error instanceof Error ? error.message : error}`);
    }
  }
```

Location popup ("Publish your survey") and Create-new-folder methods:

```ts
  private getScopedElement(dialogResourceName: string, childResourceName: string) {
    const dialog = this.getResource(dialogResourceName);
    const child = this.getResource(childResourceName);
    return this.webActionHandler.getWebElement({
      ...child,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${child.selectorValue}`,
    });
  }

  private getScopedDynamicElement(dialogResourceName: string, childResourceName: string, text: string) {
    const dialog = this.getResource(dialogResourceName);
    const child = this.resourceManager.getDynamicResource(childResourceName, text, SURVEY_BUILDER_PAGE_COMPONENT_NAME);
    return this.webActionHandler.getWebElement({
      ...child,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${child.selectorValue}`,
    });
  }

  private async getScopedElementsText(dialogResourceName: string, childResourceName: string): Promise<string[]> {
    const dialog = this.getResource(dialogResourceName);
    const child = this.getResource(childResourceName);
    return this.webActionHandler.getWebElementsText({
      ...child,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${child.selectorValue}`,
    });
  }

  async isPublishLocationDialogVisible(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('publishLocationDialog'));
      return await dialog.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Publish your survey dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isPublishLocationDialogContinueDisabled(): Promise<boolean> {
    try {
      const continueButton = this.getScopedElement('publishLocationDialog', 'dialogContinueButton');
      const ariaDisabled = await continueButton.getAttribute('aria-disabled');
      const state = await continueButton.getAttribute('state');
      const disabledAttr = await continueButton.getAttribute('disabled');
      const classAttr = (await continueButton.getAttribute('class')) ?? '';
      return ariaDisabled === 'true' || state === 'disabled' || disabledAttr !== null || classAttr.split(/\s+/).includes('disabled');
    } catch (error) {
      throw new Error(`Failed to get Publish your survey dialog Continue button disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickPublishLocationDialogCancel(): Promise<void> {
    try {
      const cancelButton = this.getScopedElement('publishLocationDialog', 'saveDraftDialogCancelButton');
      await this.waitUntilVisible(cancelButton, 'Publish your survey dialog Cancel button');
      await cancelButton.click();
    } catch (error) {
      throw new Error(`Failed to click Publish your survey dialog Cancel button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderLink(): Promise<void> {
    try {
      const link = this.getScopedElement('publishLocationDialog', 'createNewFolderLink');
      await this.waitUntilVisible(link, 'Create new folder link');
      await link.click();
    } catch (error) {
      throw new Error(`Failed to click Create new folder link: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderInLocation(): Promise<void> {
    try {
      const button = this.getScopedElement('publishLocationDialog', 'createNewFolderInLocationButton');
      await this.waitUntilVisible(button, 'Create new folder in location button');
      await button.click();
    } catch (error) {
      throw new Error(`Failed to click "Create new folder in location" button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isCreateNewFolderDialogVisible(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('createNewFolderDialog'));
      return await dialog.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Create new folder dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async areCreateNewFolderDialogControlsVisible(): Promise<{ nameInput: boolean; cancel: boolean; create: boolean; close: boolean }> {
    try {
      const [nameInput, cancel, create, close] = await Promise.all([
        this.getScopedElement('createNewFolderDialog', 'saveDraftDialogNameInput').isVisible(MEDIUM_TIMEOUT),
        this.getScopedElement('createNewFolderDialog', 'saveDraftDialogCancelButton').isVisible(MEDIUM_TIMEOUT),
        this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogCreateButton').isVisible(MEDIUM_TIMEOUT),
        this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogCloseButton').isVisible(MEDIUM_TIMEOUT),
      ]);
      return { nameInput, cancel, create, close };
    } catch (error) {
      throw new Error(`Failed to check Create new folder dialog controls: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillCreateNewFolderDialogName(name: string): Promise<void> {
    try {
      const nameInput = this.getScopedElement('createNewFolderDialog', 'saveDraftDialogNameInput');
      await this.waitUntilVisible(nameInput, 'Create new folder dialog Name input');
      await nameInput.enterText(name);
    } catch (error) {
      throw new Error(`Failed to fill Create new folder dialog Name input: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderDialogCreate(): Promise<void> {
    try {
      const createButton = this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogCreateButton');
      await this.waitUntilVisible(createButton, 'Create new folder dialog Create button');
      await createButton.click();
    } catch (error) {
      throw new Error(`Failed to click Create new folder dialog Create button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderDialogCancel(): Promise<void> {
    try {
      const cancelButton = this.getScopedElement('createNewFolderDialog', 'saveDraftDialogCancelButton');
      await this.waitUntilVisible(cancelButton, 'Create new folder dialog Cancel button');
      await cancelButton.click();
    } catch (error) {
      throw new Error(`Failed to click Create new folder dialog Cancel button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getPublishLocationFolderCount(): Promise<number> {
    try {
      return (await this.getScopedElementsText('publishLocationDialog', 'locationDialogFolderRow')).length;
    } catch (error) {
      throw new Error(`Failed to get folder count in Publish your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isPublishLocationFolderHighlighted(folderName: string): Promise<boolean> {
    try {
      const folder = this.getScopedDynamicElement('publishLocationDialog', 'locationDialogFolderByName', folderName);
      const ariaSelected = await folder.getAttribute('aria-selected');
      const classAttr = (await folder.getAttribute('class')) ?? '';
      return ariaSelected === 'true' || classAttr.split(/\s+/).includes('selected') || classAttr.split(/\s+/).includes('highlighted');
    } catch (error) {
      throw new Error(`Failed to check folder highlighted state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickPublishLocationFolder(folderName: string): Promise<void> {
    try {
      const folder = this.getScopedDynamicElement('publishLocationDialog', 'locationDialogFolderByName', folderName);
      await this.waitUntilVisible(folder, `Folder "${folderName}" in Publish your survey dialog`);
      await folder.click();
    } catch (error) {
      throw new Error(`Failed to click folder "${folderName}" in Publish your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }
```

Other publish-related methods (validate/publish button state, validation toasts):

```ts
  private async getButtonDisabledState(
    resourceName: string
  ): Promise<{ disabled: boolean; hostOuterHtml: string; innerButtonOuterHtml: string | null; matchCount: number; innerText: string }> {
    const matchCount = (await this.webActionHandler.getWebElementsText(this.getResource(resourceName))).length;
    const button = this.webActionHandler.getWebElement(this.getResource(resourceName));
    const innerText = (await button.getText()).trim();
    const ariaDisabled = await button.getAttribute('aria-disabled');
    const state = await button.getAttribute('state');
    const disabledAttr = await button.getAttribute('disabled');
    const classAttr = (await button.getAttribute('class')) ?? '';
    const hostOuterHtml = String(await button.executeScript((e) => e.outerHTML)).slice(0, 400);
    const innerButtonDisabled = await button.executeScript((e) => {
      const inner = e.querySelector('button');
      return inner ? inner.disabled : null;
    });
    const innerButtonOuterHtml = await button.executeScript((e) => {
      const inner = e.querySelector('button');
      return inner ? inner.outerHTML : null;
    });
    const disabled =
      ariaDisabled === 'true' ||
      state === 'disabled' ||
      disabledAttr !== null ||
      classAttr.split(/\s+/).includes('disabled') ||
      innerButtonDisabled === true;
    return {
      disabled,
      hostOuterHtml,
      innerButtonOuterHtml: innerButtonOuterHtml === null ? null : String(innerButtonOuterHtml).slice(0, 400),
      matchCount,
      innerText,
    };
  }

  async getPublishDisabledState(): Promise<{
    disabled: boolean;
    hostOuterHtml: string;
    innerButtonOuterHtml: string | null;
    matchCount: number;
    innerText: string;
  }> {
    try {
      return await this.getButtonDisabledState('publishSurveyButton');
    } catch (error) {
      throw new Error(`Failed to get publish disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getValidateDisabledState(): Promise<{
    disabled: boolean;
    hostOuterHtml: string;
    innerButtonOuterHtml: string | null;
    matchCount: number;
    innerText: string;
  }> {
    try {
      return await this.getButtonDisabledState('validateSurveyButton');
    } catch (error) {
      throw new Error(`Failed to get validate disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isValidateSurveyButtonVisible(timeoutMs: number = SMALL_TIMEOUT): Promise<boolean> {
    const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
    return await validateButton.isVisible(timeoutMs);
  }

  async isValidatingToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(this.getResource('validatingSurveyToastText'));
    return await toast.isVisible(SMALL_TIMEOUT);
  }

  async isChangesRecommendedToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    return await toast.isVisible(SMALL_TIMEOUT);
  }

  /** True if any of the three post-validation result toasts (complete / recommended / needed) is visible. */
  async isValidationResultToastVisible(): Promise<boolean> {
    const complete = this.webActionHandler.getWebElement(this.getResource('validationCompleteToastText'));
    const recommended = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    const needed = this.webActionHandler.getWebElement(this.getResource('changesNeededToastText'));
    // Checked in parallel: the result toast auto-hides, so sequential checks can miss it.
    const [isCompleteVisible, isRecommendedVisible, isNeededVisible] = await Promise.all([
      complete.isVisible(SMALL_TIMEOUT),
      recommended.isVisible(SMALL_TIMEOUT),
      needed.isVisible(SMALL_TIMEOUT),
    ]);
    return isCompleteVisible || isRecommendedVisible || isNeededVisible;
  }

  async isRecommendationTagVisible(): Promise<boolean> {
    const tag = this.webActionHandler.getWebElement(this.getResource('recommendationTagText'));
    return await tag.isVisible(SMALL_TIMEOUT);
  }

  /** Which of the three post-validation result toasts (complete / recommended / needed) is showing, or 'none' if none is. */
  async getValidationOutcome(): Promise<'complete' | 'recommended' | 'needed' | 'none'> {
    const complete = this.webActionHandler.getWebElement(this.getResource('validationCompleteToastText'));
    const recommended = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    const needed = this.webActionHandler.getWebElement(this.getResource('changesNeededToastText'));
    // Checked in parallel: the result toast auto-hides, so sequential checks can miss it.
    const [isCompleteVisible, isRecommendedVisible, isNeededVisible] = await Promise.all([
      complete.isVisible(SMALL_TIMEOUT),
      recommended.isVisible(SMALL_TIMEOUT),
      needed.isVisible(SMALL_TIMEOUT),
    ]);
    if (isNeededVisible) {
      return 'needed';
    }
    if (isRecommendedVisible) {
      return 'recommended';
    }
    if (isCompleteVisible) {
      return 'complete';
    }
    return 'none';
  }
```

Review-mode methods (the "review" word; used by TC_BS_13/14 and TC_BS_27, not by the publish tests):

```ts
  async enterReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('reviewSurveyButton', 'Review survey button');
      const selectAllButtonAfterEntering = this.webActionHandler.getWebElement(this.getResource('selectAllButton'));
      await this.waitUntilVisible(selectAllButtonAfterEntering, 'Select all button (review mode controls)');
    } catch (error) {
      throw new Error(`Failed to enter review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  async exitReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('exitReviewModeButton', 'Exit review mode button');
      const reviewButtonAfterExit = this.webActionHandler.getWebElement(this.getResource('reviewSurveyButton'));
      await this.waitUntilVisible(reviewButtonAfterExit, 'Review survey button (back on Build Survey screen)');
    } catch (error) {
      throw new Error(`Failed to exit review mode: ${error instanceof Error ? error.message : error}`);
    }
  }
```

Save-a-copy / save-draft methods used by `publishSurvey` and `saveDraft` (`selectSaveLocation`, `fillSaveCopyDialog`, `saveDraft`) are in section 6.

### 1.5 Locator entries (`locators\survey\survey-builder.locator.json`) that mention publish, validate, review, folder, dialog, close, confirm or save-a-copy

Also matched by name/selector: "save", "location", "toast", "optiq", "recommend".

```json
    { "elementName": "reviewSurveyButton", "selectorType": "css", "selectorValue": "[data-test-id='review-survey']" },
    { "elementName": "exitReviewModeButton", "selectorType": "text", "selectorValue": "Exit Review Mode" },
    { "elementName": "saveDraftButton", "selectorType": "css", "selectorValue": "[data-test-id='save-draft']" },
    { "elementName": "saveCopyTitleInput", "selectorType": "css", "selectorValue": "[data-test-id='save-a-copy-title-input']" },
    { "elementName": "myAssetsTreeItem", "selectorType": "playwrights", "selectorValue": "role=treeitem[name*=\"My Assets\"]" },
    { "elementName": "savePendingChangesButton", "selectorType": "css", "selectorValue": "[data-test-id='save-pending-changes-button']" },
    { "elementName": "saveDraftDialog", "selectorType": "playwrights", "selectorValue": "[role='dialog']:has-text(\"Save your survey\") >> nth=0" },
    { "elementName": "saveDraftDialogNameInput", "selectorType": "playwrights", "selectorValue": "role=textbox[name=\"Name\"]" },
    { "elementName": "saveDraftDialogErrorText", "selectorType": "playwrights", "selectorValue": "text=\"Survey name is required.\" >> nth=0" },
    { "elementName": "saveDraftDialogMyAssetsFolder", "selectorType": "playwrights", "selectorValue": "role=treeitem[name*=\"My Assets\"] >> nth=0" },
    { "elementName": "saveDraftDialogSaveButton", "selectorType": "playwrights", "selectorValue": "role=button[name=\"Save draft\"] >> nth=0" },
    { "elementName": "saveDraftDialogCancelButton", "selectorType": "playwrights", "selectorValue": "role=button[name=\"Cancel\"] >> nth=0" },
    { "elementName": "publishLocationDialog", "selectorType": "playwrights", "selectorValue": "[role='dialog']:has-text(\"Publish your survey\") >> nth=0" },
    { "elementName": "dialogContinueButton", "selectorType": "playwrights", "selectorValue": "role=button[name=\"Continue\"]" },
    { "elementName": "createNewFolderLink", "selectorType": "playwrights", "selectorValue": "text=\"Create new folder\"" },
    { "elementName": "createNewFolderInLocationButton", "selectorType": "playwrights", "selectorValue": "text=\"Create new folder in location\"" },
    { "elementName": "createNewFolderDialog", "selectorType": "playwrights", "selectorValue": "[role='dialog']:has-text(\"Create new folder\") >> nth=0" },
    { "elementName": "createNewFolderDialogCreateButton", "selectorType": "playwrights", "selectorValue": "role=button[name=\"Create\"]" },
    { "elementName": "createNewFolderDialogCloseButton", "selectorType": "playwrights", "selectorValue": "role=button[name=\"Close\"]" },
    { "elementName": "locationDialogFolderRow", "selectorType": "playwrights", "selectorValue": "role=treeitem" },
    { "elementName": "locationDialogFolderByName", "selectorType": "playwrights", "selectorValue": "role=treeitem[name*=\"${text}\"]" },
    { "elementName": "savedAssetGridcellByTitle", "selectorType": "playwrights", "selectorValue": "role=gridcell[name=\"${text}\"]" },
    { "elementName": "confirmPublishDialogText", "selectorType": "text", "selectorValue": "Review survey details" },
    { "elementName": "validateSurveyButton", "selectorType": "css", "selectorValue": "[data-test-id='validate-survey']" },
    { "elementName": "toastCloseButton", "selectorType": "css", "selectorValue": "[data-test-id='-close-button']" },
    { "elementName": "validatingSurveyToastText","selectorType": "playwrights","selectorValue": "text=\"Validating your survey\" >> nth=0"},
    { "elementName": "changesRecommendedToastText","selectorType": "playwrights","selectorValue": "text=\"Changes recommended\" >> nth=0"},
    { "elementName": "validationCompleteToastText","selectorType": "playwrights","selectorValue": "text=\"Validation complete\" >> nth=0"},
    { "elementName": "changesNeededToastText", "selectorType": "playwrights", "selectorValue": "text=\"Changes needed\" >> nth=0" },
    { "elementName": "recommendationTagText", "selectorType": "playwrights", "selectorValue": "text=/\\d+ recommendation/i >> nth=0" },
    { "elementName": "viewOptiqFeedbackLink", "selectorType": "text", "selectorValue": "View Optiq feedback" },
    { "elementName": "saveDraftSuccessToast", "selectorType": "text", "selectorValue": "Survey saved as draft successfully" },
    { "elementName": "publishingSurveyStatus", "selectorType": "playwrights", "selectorValue": "role=status[name=\"Publishing survey\"]" },
    { "elementName": "publishSurveyButton", "selectorType": "css", "selectorValue": "[data-test-id='publish-survey']" },
    { "elementName": "confirmPublishButton","selectorType": "playwrights","selectorValue": "[data-test-id='-footer'] >> role=button[name=\"Publish survey\"]"},
    { "elementName": "publish-dialog-dimension-by-index","selectorType": "playwrights","selectorValue": ".publish-review-details [data-test-id$='_Dimension'] >> nth=${text}"},
    { "elementName": "publish-response-count-text", "selectorType": "css", "selectorValue": ".publish-review-details" },
    { "elementName": "publish-success-toast", "selectorType": "text", "selectorValue": "Survey published successfully" },
    { "elementName": "survey-action-toast", "selectorType": "css", "selectorValue": ".survey-action-toast" },
    { "elementName": "saveQuestionChangesButton","selectorType": "playwrights","selectorValue": "survey-question-editor .save-changes-action:visible"},
    { "elementName": "discardChangesButton","selectorType": "playwrights","selectorValue": ".question-row .edit-actions >> text=\"Discard changes\" >> nth=0"},
```

Entries that match only because of "dialog" in the file's other scopes (`select-panelist.locator.json`, `start-with-prompt.locator.json`, `start-from-scratch.locator.json`): `dialogElement` (`[data-test-id='title-second-dialog']`), `cancelDatasetButton` (`[data-test-id='rv-dataset-selector-footer'] niq-button.btn-cancel`). They belong to the dataset flow, not publish.

---

## 2. ORDER AND STATE

### 2.1 Test order around the publish tests (current)

**Scratch** (`start-from-scratch.spec.ts`, `test.describe.serial`):

| Position | Test | Status |
|---|---|---|
| prev 3 | TC_AI_12: No Optiq-AI action buttons are visible in the Start From Scratch builder | active |
| prev 2 | TC_BS_22: Discard a new question via Add Question cancel, then add and save one | active |
| prev 1 | TC_BS_20: Delete the last question then re-add the same type as last | active |
| **TC_BS_17** | Publish popup Cancel leaves the survey unpublished | active |
| **TC_BS_24** | Create a new folder from the Publish popup | active |
| next 1 | TC_BS_16/TC_BS_18: Publish survey | test.fixme |
| next 2 | TC_BS_27: Review Mode select all, delete all, stay on Build Survey | active |
| next 3 | TC_BS_09: Validate survey is disabled with fewer than 3 questions | active |

Before that, in order: TC_BS_13/TC_BS_14 Review Mode, **TC_BS_10 Save survey as draft**, TC_BS_23 Validate survey.

**Prompt** (`start-with-prompt.spec.ts`, `test.describe.serial`):

| Position | Test | Status |
|---|---|---|
| prev 3 | TC_BS_10a: Save draft with empty title requires a survey name | active |
| prev 2 | TC_BS_10: Save survey as draft | active |
| prev 1 | TC_AI_13: Validate survey: Completes and shows Optiq feedback when there are recommendations | active |
| **TC_BS_17** | Publish popup Cancel leaves the survey unpublished | active |
| **TC_AI_14** | Create a new folder from the Publish popup | active (last test in the file) |
| next 1..3 | none (end of file) | |

For TC_AI_14 specifically: prev 3 = TC_BS_10, TC_AI_13, TC_BS_17. For TC_BS_24 (Scratch): prev 3 = TC_BS_22, TC_BS_20, TC_BS_17; next 3 = TC_BS_16/18 (fixme), TC_BS_27, TC_BS_09.

### 2.2 Which earlier tests save the survey (select a folder) before them

| Flow | Saving tests, in run order | How |
|---|---|---|
| Scratch | **TC_BS_10a** (test #7 of the file, very early), then **TC_BS_10** (test #26) | 10a goes through the "Save your survey" dialog: fills the name, clicks the "My Assets" tree item, clicks "Save draft". That sets the survey's selected folder. TC_BS_10 then clicks Save draft again; the dialog does not appear and it saves directly (this is the case `saveDraft()` handles with its 3 s wait). |
| Prompt | **TC_BS_10a**, then **TC_BS_10** (order swapped in an earlier change; same order as Scratch) | same mechanics |

### 2.3 What the app does once a folder is selected (from `libs\survey-mod-lib`, read, not run)

`survey-header.component.ts`:

```ts
  // Opens the folder selector before saving a draft.
  openSaveDraftDialog(): void {
    const folder = this.surveyService.getSelectedFolder();
    if (folder?.folderId) {
      this.saveAsDraft({
        title: this.surveyTitle,
        folder: { assetId: folder.folderId, title: folder.name },
      });
      return;
    }
    this.dialogAction.set(SurveyStatusType.DRAFT);
    this.surveyCommonService.loadAndOpenFolderDialog(this.saveDraftDialog, this.surveyTitle, this.folders, this.isLoadingFolders, this.isSavingDraft);
  }

  // Opens the folder selector before publishing an unsaved survey.
  prepareForPublish(): void {
    if (this.surveyService.getSelectedFolder()) {
      if (this.hasValidTitle(this.surveyTitle)) {
        this.publishReady.emit();
      }
      return;
    }

    this.dialogAction.set(SurveyStatusType.PUBLISHED);
    this.surveyCommonService.loadAndOpenFolderDialog(this.saveDraftDialog, this.surveyTitle, this.folders, this.isLoadingFolders, this.isSavingDraft);
  }
```

`updateSurveyFolder()` (called from both `saveAsDraft` and the publish location selection) calls `surveyService.setSelectedFolder(...)`.

**Consequence (code reading, not verified by a run):** in both flows the survey already has a selected folder before TC_BS_17 / TC_BS_24 / TC_AI_14 run (saved by TC_BS_10a and TC_BS_10). Clicking `publish-survey` then goes straight to the "Review survey details" dialog (`publishReady.emit()`), and the "Publish your survey" location popup is NOT opened. TC_BS_17 asserts that popup is visible, and TC_BS_24 / TC_AI_14 click "Create new folder" inside it, so they are expected to fail at those steps unless the selected folder is cleared or the tests run on an unsaved survey. They were previously test.fixme for a reason that the code comment gives as "publish popup flow not working on DEV".

**Other state facts that affect these tests** (`libs\...\validation.service.ts`):

```ts
          this.surveyAIValidationState.set(
            this.countSuggestions(validatedQuestions, SUGGESTION_SEVERITY.MANDATORY) > 0
              ? SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW
              : SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
          );
...
  invalidateSurveyValidation(): void {
    if (this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH) {
      this.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
      this.showValidationToast([], ValidationToastType.SURVEY_EDITED);
    }
  }
```

- Mandatory suggestions keep the footer on `validate-survey` (label "Revalidate survey"); `publish-survey` never appears, so `isValidationCompleted()` in TC_BS_23 / TC_AI_13 would be false.
- `invalidateSurveyValidation()` is the survey-edited path: after TC_BS_23 validates, later edits (TC_BS_22, TC_BS_20 add/delete questions in Scratch) move the state back to `validate-survey`. `openPublishDialog()` copes with that (it re-validates if the validate button is visible), but each re-validate also fires validation toasts and may open the Optiq panel (section 4).
- Both TC_BS_17 and TC_BS_24 call `ensureQuestionCount(3)` first; in Scratch the survey has ~10 questions at that point and in Prompt ~8.

---

## 3. REVIEW DIALOG (new UI)

### 3.1 What the app renders (`libs\...\survey-publish-popup\survey-publish-popup.component.html`)

```html
<niq-dialog #publishDialog size="large" [closeOnEsc]="true" [closeOnClickOutside]="false" [showCloseButton]="true">
  <div dialogTitle class="publish-dialog-title" data-test-id="publish-dialog-title">{{ 'SURVEYMOD_REVIEW_SURVEY_DETAILS' | translate }}</div>
  <div dialogBody class="publish-content">
    <p class="publish-guidance">{{ 'SURVEYMOD_PUBLISH_WARNING' | translate }}</p>
    <div class="publish-review-card">
      <div class="publish-survey-heading">
        <niq-icon iconName="clipboard" [useSprite]="true" size="small" aria-hidden="true"></niq-icon>
        <h3 class="publish-survey-title">{{ surveyTitle }}</h3>
      </div>
      <div class="publish-review-details">
        <div class="publish-audience-summary" [attr.aria-label]="'SURVEYMOD_SELECTED_PANELIST_CRITERIA' | translate">
          <crf-data-summary id="publish-data-summary" class="publish-review-summary" [selections]="panelistSummaryState.selections ?? []"
            [promptData]="$any(panelistSummaryState.dataPrompts ?? [])"
            [requestInstance]="$any(panelistSummaryState.requestInstance ?? {})"
            [reportSpec]="$any(panelistSummaryState.reportSpec ?? {})" [showAdditionalPrompts]="false" [isSnapShotView]="true">
          </crf-data-summary>
        </div>
        <p class="publish-question-summary">{{ questionCount | number }} {{ (questionCount === 1 ? 'SURVEYMOD_QUESTION' : 'SURVEYMOD_QUESTIONS') | translate | lowercase}}</p>
        <p class="publish-response-summary" data-test-id="publish-response-count">{{ selectedResponseCount | number }} {{ 'SURVEYMOD_RESPONSES' | translate }}</p>
      </div>
    </div>
  </div>
  <div dialogFooter class="publish-actions">
    <niq-button variant="secondary" size="medium" colorTheme="light" (click)="close()">
      {{ 'SURVEYMOD_EDIT_SURVEY' | translate }}
    </niq-button>
    <niq-button data-test-id="confirm-publish" variant="primary" size="medium" colorTheme="light" [state]="isPublishing() ? 'loading' : 'default'"
      (click)="confirmPublish()">
      {{ 'SURVEYMOD_PUBLISH_SURVEY' | translate }}
    </niq-button>
  </div>
</niq-dialog>

@if (isPublishing()) {
  <div class="publish-page-loader" data-test-id="publishing-survey-loader" role="status" [attr.aria-label]="'SURVEYMOD_PUBLISHING_SURVEY' | translate">
    <niq-spinner size="medium"></niq-spinner>
  </div>
}
```

### 3.2 "Review survey details" dialog: e2e locators that exist vs missing

| UI element | In e2e? | Locator / note |
|---|---|---|
| Dialog (open check) | yes, text only | `confirmPublishDialogText` = `text "Review survey details"`. No `data-test-id` locator for the dialog; the app has no test-id on `niq-dialog` (none in the template). The spec's ids "publish-survey-dialog" do not exist in the app template either. |
| Title `publish-dialog-title` | **missing** | Not in any e2e locator. App has `data-test-id="publish-dialog-title"`. |
| Survey title (`.publish-survey-title`, h3) | **missing** | |
| Panelist criteria summary (`#publish-data-summary`, `crf-data-summary`) | partly | `publish-dialog-dimension-by-index` = `.publish-review-details [data-test-id$='_Dimension'] >> nth=${text}` (used only in the fixme test). |
| Question count text (`.publish-question-summary`) | **missing** | |
| Response count `publish-response-count` | **missing by test-id** | e2e uses `publish-response-count-text` = `.publish-review-details` (the whole details block, not the `<p data-test-id="publish-response-count">`), read with `getPublishResponseSummaryText()` (used only in the fixme test). |
| "Edit survey" button (secondary, closes the dialog) | **missing** | No locator, no page-object method, no test. App button has no test-id (text from `SURVEYMOD_EDIT_SURVEY`). |
| Confirm / "Publish survey" button `confirm-publish` | **missing by test-id** | e2e uses `confirmPublishButton` = `[data-test-id='-footer'] >> role=button[name="Publish survey"]`, which depends on a truncated footer id and the button's accessible name. App has `data-test-id="confirm-publish"`. |
| Dialog close X (`showCloseButton`) | **missing** | |
| "Publishing survey" loader | yes | `publishingSurveyStatus` = `role=status[name="Publishing survey"]` (app has `data-test-id="publishing-survey-loader"`, `role="status"`). |
| Success toast | yes | `publish-success-toast` = text "Survey published successfully"; `survey-action-toast` = `.survey-action-toast`. |

Which tests touch this dialog: only the fixme TC_BS_16/TC_BS_18 (via `publishSurvey`, `isPublishDialogDimensionCountVisible`, `getPublishResponseSummaryText`, `confirmPublish`, `verifyPublishSucceeded`). With a folder selected (section 2.3), TC_BS_17 / TC_BS_24 / TC_AI_14 would land on this dialog, not on the location popup.

### 3.3 "Publish your survey" location popup: e2e locators that exist vs missing

The location popup is a folder-picker dialog opened by `loadAndOpenFolderDialog` (not in the publish popup component above).

| UI element | In e2e? | Locator |
|---|---|---|
| Dialog | yes | `publishLocationDialog` = `[role='dialog']:has-text("Publish your survey") >> nth=0` |
| Name field | partly | Only the shared `saveDraftDialogNameInput` (`role=textbox[name="Name"]`) is used, and only inside "Create new folder". No Name-field check inside the "Publish your survey" dialog itself. |
| "Choose a location" heading/tree | partly | Tree rows only: `locationDialogFolderRow` (`role=treeitem`), `locationDialogFolderByName` (`role=treeitem[name*="${text}"]`). **No locator for the "Choose a location" heading.** |
| "Create new folder" link | yes | `createNewFolderLink` = `text="Create new folder"` (scoped to the dialog) |
| "Create new folder in location" button | yes | `createNewFolderInLocationButton` |
| Continue | yes | `dialogContinueButton` = `role=button[name="Continue"]` (disabled-state read in `isPublishLocationDialogContinueDisabled`). **No click method for Continue.** |
| Cancel | yes | `saveDraftDialogCancelButton` (shared, scoped by `getScopedElement`) |
| Close X of the "Publish your survey" dialog | **missing** | `createNewFolderDialogCloseButton` (`role=button[name="Close"]`) exists but is used only for the Create-new-folder dialog. |
| Create new folder dialog | yes | `createNewFolderDialog`, `createNewFolderDialogCreateButton`, `createNewFolderDialogCloseButton`, Name input and Cancel (shared with save-draft locators) |

---

## 4. FOOTER AND OPTIQ PANEL

### 4.1 How `validate-survey` becomes `publish-survey`

App footer (`libs\...\footer\footer.component.html`):

```html
  <niq-button
    [attr.data-test-id]="
      surveyAIValidationState() === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
        ? 'publish-survey'
        : 'validate-survey'
    "
    [state]="
      surveyAIValidationState() === SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS
        ? 'loading'
        : isPublishDisable()
        ? 'disabled'
        : 'default'
    "
    (click)="onValidationAction()"
```

`footer.component.ts`:

```ts
  readonly buttonLabel = computed(() => {
    switch (this.surveyAIValidationState()) {
      case SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW:
        return 'SURVEYMOD_REVALIDATE_SURVEY';

      case SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH:
        return 'SURVEYMOD_REVIEW_PUBLISH_SURVEY';

      default:
        return 'SURVEYMOD_VALIDATE_SURVEY';
    }
  });

  onValidationAction(): void {
    if (this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH) {
      this.publish.emit();
    } else {
      this.validateSurvey.emit();
    }
  }
```

Flow: `validate-survey` click -> state `VALIDATION_IN_PROGRESS` (button loading, `.footer-page-loader` with `data-test-id="survey-validation-loader"`, "Validating" toast) -> API returns -> state `READY_FOR_PUBLISH` (no mandatory suggestions) or `VALIDATION_IN_REVIEW` (mandatory suggestions). Only `READY_FOR_PUBLISH` renders `data-test-id="publish-survey"` (label "Review & publish survey"). Any edit afterwards calls `invalidateSurveyValidation()` and flips it back to `VALIDATION_IN_REVIEW` (`validate-survey`, label "Revalidate survey").

Build Survey component (`build-survey.component.ts`): `onValidateSurvey()` sets `isFeedbackPanelOpen` to `hasSuggestions()` after validation, so the Optiq feedback side panel opens by itself when there are suggestions. `publish()` toggles `publishRequest`; the header then runs `prepareForPublish()` (section 2.3), which calls `openPublishConfirmation()` -> `publishPopup.open()` when a folder is already selected.

### 4.2 e2e page-object methods that click them

| Click | Method (`survey-builder.page.ts`) |
|---|---|
| `validate-survey` | `clickValidateSurvey()` (`clickWhenVisible('validateSurveyButton', ...)`), wrapped by `validateSurvey()` which then waits for `.footer-page-loader` to be hidden (up to `NAVIGATION_TIMEOUT`), via `waitForValidationComplete()` |
| `publish-survey` | `openPublishDialog()` (`clickWhenVisible('publishSurveyButton', 'Publish survey button')`) |
| detect validation done | `isValidationCompleted()`: `publishSurveyButton` visible AND `validateSurveyButton` hidden |

### 4.3 What the code does after clicking `publish-survey`

- `openPublishDialog()`: nothing after the click. It returns right away (no wait for any dialog).
- TC_BS_17 / TC_BS_24 / TC_AI_14: immediately assert/click inside the "Publish your survey" popup (`isPublishLocationDialogVisible()` waits up to `MEDIUM_TIMEOUT`; `clickCreateNewFolderLink()` waits up to `ELEMENT_WAIT_TIMEOUT`).
- `publishSurvey()` (used by the fixme test): waits in parallel (`ELEMENT_WAIT_TIMEOUT`) for the Save-a-copy title input (`saveCopyTitleInput`) OR the text "Review survey details"; if the title input shows it runs `fillSaveCopyDialog(title)`; if neither shows it throws "Neither the Save-a-copy dialog nor the Review survey details dialog appeared after clicking Publish". It never selects the "Publish your survey" location popup, so that popup is not handled by `publishSurvey()` (only the older Save-a-copy dialog is).

### 4.4 `-close-button` clicked twice: not in the e2e code

I searched all `*.ts` under `e2e\` for `toastCloseButton`, `-close-button`, `Optiq Feedback` and `dismissToastIfVisible`:

- `toastCloseButton` = `[data-test-id='-close-button']` is used in exactly ONE place: `dismissToastIfVisible()`, which clicks it at most **once** (if visible within `SMALL_TIMEOUT`).
- `dismissToastIfVisible()` is called from exactly ONE place: `openPublishDialog()`, once, between validation and the click on `publish-survey`.
- There is no second click and no code that closes the Optiq Feedback panel. The only Optiq-panel references in e2e are the locator `viewOptiqFeedbackLink` (text "View Optiq feedback", checked only if a recommendation tag is visible in TC_BS_23 / TC_AI_13) and `recommendationTagText`.

So I cannot say why the code clicks it twice, because it does not. What the app code suggests (reading `libs\`, not run):

- A validation run can produce more than one toast (an "in progress" toast, then a result toast, and a "survey edited" toast after later edits; all via `toastService.InsertToast`). If two toasts are on screen, `getWebElement(...)` on the toast close selector would match more than one element; this is a strict-mode risk, not a double click.
- The Optiq Feedback panel (`survey-optiq-feedback` -> `survey-common-side-panel`) opens automatically when validation returns suggestions, and has `closeOnOutsideClick=false`. Its close button in the app is `data-test-id="survey-side-panel-close"` (`libs\...\common-side-panel.component.html`). **e2e has no locator for it.** If it is open it can cover the footer, which may be why `publish-survey` is not clickable; the e2e code does not handle that.

### 4.5 Optiq panel and toast locators in e2e vs the app

| UI | In app | In e2e |
|---|---|---|
| Panel root | `data-test-id="survey-side-panel"`, content `survey-side-panel-content`, title `survey-side-panel-title` | missing |
| Panel close | `data-test-id="survey-side-panel-close"` | missing |
| Feedback content | `optiq-feedback-content`, `optiq-feedback-status`, `optiq-feedback-loader` | missing |
| "Fix all" / Dismiss / apply suggestion buttons | niq-buttons (text via keys) | missing |
| Toast close | (toast component) | `toastCloseButton` = `[data-test-id='-close-button']` (truncated id) |

---

## 5. WHY FIXME

- **TC_BS_16/TC_BS_18** (`tests\survey\start-from-scratch.spec.ts`, line 246): `test.fixme(...)` with **no comment** above or inside it. No explanation in code.
- **TC_BS_17 / TC_BS_24 / TC_AI_14** had, until the last change, a comment immediately above the `test.fixme(` in each of the two functions: `// FIXME: publish popup flow not working on DEV; revisit later`. (Removed when they were enabled.)
- Searched `e2e\**\*.md` and `.github\skills\playwright-e2e` for `TC_BS_16`, `TC_BS_18`, `test.fixme`, and "publish ... DEV": **no matches**. No README or doc explains it.
- **Git history: not checked.** I cannot run `git log` / `git blame` in this read-only pass. To get it, run: `git log -S"test.fixme('TC_BS_16/TC_BS_18" -- e2e/tests/survey/start-from-scratch.spec.ts` and `git log -S"FIXME: publish popup flow" -- e2e/tests/survey/common-test-cases/build-survey-common-test-cases.ts`.
- What the code itself shows about the publish failure (not a stated reason): `verifyPublishSucceeded()` has fail-fast branches for "Publish failed: <toast text>" and a timeout waiting for `/my-assets`, which would be consistent with a backend publish failing; `.survey-action-toast` is used for both success and error toasts in the app (`survey-publish-popup.component.ts`: success -> `router.navigateByUrl('/my-assets/survey')` + success toast; error -> error toast).

---

## 6. SAVE DRAFT TOAST

### 6.1 Current code (`page-objects\common\survey-builder.page.ts`)

```ts
  /** Expands "My Assets" via its own row-scoped `.arrow` (not page-wide) and picks the first non-"My Assets" folder row, only when Save isn't already enabled on "My Assets" alone. Shared by fillSaveCopyDialog(); publish can reuse it too. */
  private async selectSaveLocation(): Promise<void> {
    await this.clickWhenVisible('myAssetsTreeItem', 'My Assets tree item');

    const saveButton = this.webActionHandler.getWebElement(this.getResource('savePendingChangesButton'));
    const isSaveButtonVisible = await saveButton.isVisible(SMALL_TIMEOUT);
    const isSaveReady = isSaveButtonVisible && (await saveButton.isEnabled());
    if (isSaveReady) {
      return;
    }

    const nativePage = (BasePage as any).page as import('playwright').Page; // "not My Assets" folder filtering needs Playwright's filter API, not expressible via resource strings
    const myAssetsRow = nativePage.getByRole('treeitem', { name: 'My Assets' });
    await myAssetsRow.locator('.arrow').click({ timeout: SMALL_TIMEOUT });

    const folderRow = nativePage.getByRole('treeitem').filter({ hasNotText: 'My Assets' }).first();
    await folderRow.click({ timeout: SMALL_TIMEOUT });
  }

  /** Fills the Save-a-copy dialog (title, My Assets, save pending changes) — shared by saveDraft() and publishSurvey(). */
  private async fillSaveCopyDialog(title: string): Promise<void> {
    await this.fillWhenVisible('saveCopyTitleInput', title, 'Save-copy title input');
    await this.selectSaveLocation();
    await this.clickWhenVisible('savePendingChangesButton', 'Save pending changes button');
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /** Already-saved surveys (e.g. after TC_BS_10a) save directly without the Save-a-copy dialog, so the dialog flow is skipped when it doesn't appear within 3s. */
  async saveDraft(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');

      const titleInput = this.webActionHandler.getWebElement(this.getResource('saveCopyTitleInput'));
      if (!(await titleInput.isVisible(SAVE_DIALOG_APPEAR_TIMEOUT))) {
        return;
      }
      await this.fillSaveCopyDialog(title);
    } catch (error) {
      throw new Error(`Failed to save draft: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDraftSavedToastVisible(): Promise<boolean> {
    try {
      const toast = this.webActionHandler.getWebElement(this.getResource('saveDraftSuccessToast'));
      return toast.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to check draft saved toast visibility: ${error instanceof Error ? error.message : error}`);
    }
  }
```

Constants (`constants\timeout-constants.ts`): `SAVE_DIALOG_APPEAR_TIMEOUT = 3 * 1000`, `PANEL_TRANSITION_DELAY = 1000`, `SMALL_TIMEOUT = 5 * 1000`, `MEDIUM_TIMEOUT = 10 * 1000`.

Toast locators (`locators\survey\survey-builder.locator.json`):

```json
    { "elementName": "saveDraftSuccessToast", "selectorType": "text", "selectorValue": "Survey saved as draft successfully" },
    { "elementName": "survey-action-toast", "selectorType": "css", "selectorValue": ".survey-action-toast" },
    { "elementName": "toastCloseButton", "selectorType": "css", "selectorValue": "[data-test-id='-close-button']" },
```

Callers: `registerSaveDraftTest` (TC_BS_10) and `registerSaveDraftEmptyTitleTest` (TC_BS_10a), shown in full in the ARCHIVE section 3.3 below (current versions are in section 3 there except the names now come from `testData.surveyNames` + `uniqueNameSuffix()`):

```ts
export function registerSaveDraftTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_10: Save survey as draft', { tag: options?.tag ?? '@SaveDraft' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const title = `${testData.surveyNames.saveDraft}${uniqueNameSuffix()}`;
    await surveyBuilderPage.saveDraft(title);
    const isToastVisible = await surveyBuilderPage.isDraftSavedToastVisible();
    assertTrue(isToastVisible, 'Expected "Survey saved as draft successfully" toast to be visible after saving draft');
  });
}
```

### 6.2 How the app produces the toast (`libs\...\survey-header.component.ts`, `saveAsDraft`)

```ts
          this.toastService.InsertToast(
            'success',
            this.translate.instant('SURVEYMOD_DRAFT_SAVED'),
            {
              dismissAfter: ToastTime.DISMISSAFTER,
              size: 'large',
              containerClass: 'survey-action-toast',
            }
          );
```

It is inserted only in the `next` handler of the save API call (after the HTTP response). The error toast uses the same `containerClass: 'survey-action-toast'` (`title: 'Error'`). Also, after the first save the app navigates (`router.navigate(['../build-survey', surveyId], { replaceUrl: true })`) when the route has no `surveyId`.

### 6.3 Race points for making the TC_BS_10 check race-free (facts)

1. **No click-to-toast ordering.** `saveDraft()` returns right after the click when the dialog does not appear within 3 s (the already-saved path). The toast only appears after the API round trip; `isDraftSavedToastVisible()` then waits up to 10 s for the text. A slow save (> 10 s) false-fails.
2. **Stale toast.** The toast has `dismissAfter: ToastTime.DISMISSAFTER` (value not in this repo's e2e code). TC_BS_10a's success toast and TC_BS_10's can overlap if both run close together; the text locator cannot tell them apart, so TC_BS_10 could pass on 10a's toast. (In Scratch they are ~20 tests apart; in Prompt they are adjacent.)
3. **Missing `await`.** `return toast.isVisible(10000);` inside the `try` is not awaited, so a rejection bypasses the `catch` and the error wrapper.
4. **3 s dialog gate.** The 3 s `SAVE_DIALOG_APPEAR_TIMEOUT` can lose to a slow folder-dialog load on a not-yet-saved survey (the dialog then gets skipped and the toast check fails or times out; the draft is not saved).
5. **Text match.** `saveDraftSuccessToast` is the visible English text "Survey saved as draft successfully"; the app key is `SURVEYMOD_DRAFT_SAVED` (the translation file is not in this repo, so the match is unverified here).
6. **Toast container.** `.survey-action-toast` is shared by draft-saved, error, and publish toasts, so it cannot distinguish them on its own.

---

## 7. TEST INVENTORY (for the Excel)

Rows are one per registration, in run order. "Flow": Scratch / Prompt / Select Panelists (the Select Panelists spec starts from "Start from scratch" to reach its screen). A test shared by both flows appears once in each spec's table. Status: active / test.fixme / skipped. No test uses `test.skip`. Titles are exactly what Playwright reports (including the default title where the spec passes no title).

### 7.1 `tests\survey\start-from-scratch.spec.ts` (Scratch, `describe.serial 'Start from scratch'`, tag `@StartFromScratch`)

| # | TC id | Full test title | Spec file | Flow | Status |
|---|---|---|---|---|---|
| 1 | n/a | Start from Scratch: Should display the Start from scratch option on the survey home page | start-from-scratch.spec.ts | Scratch | active |
| 2 | n/a | Dataset Selection: Should select the dataset and confirm the Choose a dataset screen | start-from-scratch.spec.ts | Scratch | active |
| 3 | n/a | Panelist Filters: Should enable Search for Panelists after all 5 filters are set | start-from-scratch.spec.ts | Scratch | active |
| 4 | n/a | Response Count: Should enable Proceed to survey builder after selecting a response count | start-from-scratch.spec.ts | Scratch | active |
| 5 | n/a | Survey Builder: Should navigate to the Build Survey page after proceeding | start-from-scratch.spec.ts | Scratch | active |
| 6 | TC_BS_01 | TC_BS_01: First landing shows "Untitled Survey" and the Add question panel | start-from-scratch.spec.ts | Scratch | active |
| 7 | TC_BS_10a | TC_BS_10a: Save draft with empty title requires a survey name | start-from-scratch.spec.ts | both | active |
| 8 | TC_BS_02 | TC_BS_02: Edit survey title | start-from-scratch.spec.ts | Scratch | active |
| 9 | TC_BS_03a | TC_BS_03a: Add a Single Choice question | start-from-scratch.spec.ts | both | active |
| 10 | TC_BS_03b | TC_BS_03b: Add a Multiple Choice question | start-from-scratch.spec.ts | both | active |
| 11 | TC_BS_03c | TC_BS_03c: Add a Rating question | start-from-scratch.spec.ts | both | active |
| 12 | TC_BS_03d | TC_BS_03d: Add an NPS question | start-from-scratch.spec.ts | both | active |
| 13 | TC_BS_03e | TC_BS_03e: Add a Point Scale question | start-from-scratch.spec.ts | both | active |
| 14 | TC_BS_03f | TC_BS_03f: Add a Multi Scale question | start-from-scratch.spec.ts | both | active |
| 15 | TC_BS_07 | TC_BS_07: Required star appears when the Required toggle is on | start-from-scratch.spec.ts | both | active |
| 16 | TC_BS_25 | TC_BS_25: Edit question text via the pencil icon | start-from-scratch.spec.ts | both | active |
| 17 | TC_BS_26 | TC_BS_26: Discard / Save changes on an existing question | start-from-scratch.spec.ts | both | active |
| 18 | TC_BS_28 | TC_BS_28: Empty question text blocks Save changes | start-from-scratch.spec.ts | both | active |
| 19 | TC_BS_05 | TC_BS_05: Cancelling Add Question leaves the question count unchanged | start-from-scratch.spec.ts | both | active |
| 20 | TC_BS_15 | TC_BS_15: Drag and drop reorders questions | start-from-scratch.spec.ts | both | active |
| 21 | TC_BS_06 | TC_BS_06: Delete and duplicate a question via hover row actions | start-from-scratch.spec.ts | both | active |
| 22 | TC_BS_04 | TC_BS_04: Options boundary - min 2, max 15 | start-from-scratch.spec.ts | both | active |
| 23 | TC_BS_12 | TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey | start-from-scratch.spec.ts | both | active |
| 24 | TC_BS_08 | TC_BS_08: Max questions (10) disables Add question and Duplicate with limit message | start-from-scratch.spec.ts | Scratch | active |
| 25 | TC_BS_13/TC_BS_14 | TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit | start-from-scratch.spec.ts | both | active |
| 26 | TC_BS_10 | TC_BS_10: Save survey as draft | start-from-scratch.spec.ts | both | active |
| 27 | TC_BS_23 | TC_BS_23: Validate survey: Completes and shows Optiq feedback when there are recommendations | start-from-scratch.spec.ts | Scratch | active |
| 28 | TC_AI_12 | TC_AI_12: No Optiq-AI action buttons are visible in the Start From Scratch builder | start-from-scratch.spec.ts | Scratch | active |
| 29 | TC_BS_22 | TC_BS_22: Discard a new question via Add Question cancel, then add and save one | start-from-scratch.spec.ts | both | active |
| 30 | TC_BS_20 | TC_BS_20: Delete the last question then re-add the same type as last | start-from-scratch.spec.ts | both | active |
| 31 | TC_BS_17 | TC_BS_17: Publish popup Cancel leaves the survey unpublished | start-from-scratch.spec.ts | both | active (was test.fixme, enabled) |
| 32 | TC_BS_24 | TC_BS_24: Create a new folder from the Publish popup | start-from-scratch.spec.ts | Scratch (Prompt twin is TC_AI_14) | active (was test.fixme, enabled) |
| 33 | TC_BS_16/TC_BS_18 | TC_BS_16/TC_BS_18: Publish survey | start-from-scratch.spec.ts | Scratch | **test.fixme** |
| 34 | TC_BS_27 | TC_BS_27: Review Mode select all, delete all, stay on Build Survey | start-from-scratch.spec.ts | both | active |
| 35 | TC_BS_09 | TC_BS_09: Validate survey is disabled with fewer than 3 questions | start-from-scratch.spec.ts | both | active |
| 36 | TC_BS_12 | TC_BS_12: Back button returns to the previous step from the builder | start-from-scratch.spec.ts | Scratch | active |

Note: two different tests share the TC id TC_BS_12 (rows 23 and 36), with different titles. The shared implementations live in `tests\survey\common-test-cases\build-survey-common-test-cases.ts` (rows marked "both"); TC_BS_01 has an inline version here and a shared `registerEmptyStateTest` in Prompt.

### 7.2 `tests\survey\start-with-prompt.spec.ts` (Prompt, `describe.serial 'Start with a prompt'`, tag `@StartWithPrompt`)

| # | TC id | Full test title | Spec file | Flow | Status |
|---|---|---|---|---|---|
| 1 | n/a | Start with a Prompt: Should display the Start with a prompt option on the survey home page | start-with-prompt.spec.ts | Prompt | active |
| 2 | n/a | Dataset Selection: Should select the dataset type and dataset | start-with-prompt.spec.ts | Prompt | active |
| 3 | n/a | Panelist Filters: Should set dimension selections and search for panelists | start-with-prompt.spec.ts | Prompt | active |
| 4 | n/a | Response Count: Should select a response count | start-with-prompt.spec.ts | Prompt | active |
| 5 | TC_AI_01 | TC_AI_01: Select Panelists shows the Optiq heading, prompt textbox, and disables Generate Survey until prompt is entered | start-with-prompt.spec.ts | Prompt | active |
| 6 | n/a | Generate Survey: Should fill the prompt and reach the Build Survey page | start-with-prompt.spec.ts | Prompt | active |
| 7 | TC_AI_04 | TC_AI_04: Should allow selecting multiple question types on the Customize Questions screen | start-with-prompt.spec.ts | Prompt | active |
| 8 | TC_AI_03 | TC_AI_03: Question count slider and number field | start-with-prompt.spec.ts | Prompt | active |
| 9 | TC_AI_05 | TC_AI_05: Generate questions creates AI questions | start-with-prompt.spec.ts | Prompt | active |
| 10 | TC_AI_07 | TC_AI_07: Edit the survey title after AI generation | start-with-prompt.spec.ts | Prompt | active |
| 11 | TC_AI_10 | TC_AI_10: Rephrase with AI clears the loading state and prompt | start-with-prompt.spec.ts | Prompt | active |
| 12 | TC_AI_08 | TC_AI_08: Generate more questions increases the question count | start-with-prompt.spec.ts | Prompt | active |
| 13 | TC_AI_09 | TC_AI_09: Describe questions to add increases the question count | start-with-prompt.spec.ts | Prompt | active |
| 14 | TC_AI_11/TC_BS_08 | TC_AI_11/TC_BS_08: Add Question/Duplicate/Generate more/Describe are disabled at 10 (max) questions | start-with-prompt.spec.ts | Prompt | active |
| 15 | TC_BS_07 | TC_BS_07: Required star appears when the Required toggle is on | start-with-prompt.spec.ts | both | active |
| 16 | TC_BS_25 | TC_BS_25: Edit question text via the pencil icon | start-with-prompt.spec.ts | both | active |
| 17 | TC_BS_26 | TC_BS_26: Discard / Save changes on an existing question | start-with-prompt.spec.ts | both | active |
| 18 | TC_BS_28 | TC_BS_28: Empty question text blocks Save changes | start-with-prompt.spec.ts | both | active |
| 19 | TC_BS_06 | TC_BS_06: Delete and duplicate a question via hover row actions | start-with-prompt.spec.ts | both | active |
| 20 | TC_BS_15 | TC_BS_15: Drag and drop reorders questions | start-with-prompt.spec.ts | both | active |
| 21 | TC_BS_05 | TC_BS_05: Cancelling Add Question leaves the question count unchanged | start-with-prompt.spec.ts | both | active |
| 22 | TC_BS_22 | TC_BS_22: Discard a new question via Add Question cancel, then add and save one | start-with-prompt.spec.ts | both | active |
| 23 | TC_BS_20 | TC_BS_20: Delete the last question then re-add the same type as last | start-with-prompt.spec.ts | both | active |
| 24 | TC_BS_13/TC_BS_14 | TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit | start-with-prompt.spec.ts | both | active |
| 25 | TC_BS_09 | TC_BS_09: Validate survey is disabled with fewer than 3 questions | start-with-prompt.spec.ts | both | active |
| 26 | TC_BS_27 | TC_BS_27: Review Mode select all, delete all, stay on Build Survey | start-with-prompt.spec.ts | both | active |
| 27 | TC_BS_01 | TC_BS_01: Empty Build Survey state shows Add Question options and 0 rows | start-with-prompt.spec.ts | Prompt | active |
| 28 | TC_BS_03a | TC_BS_03a: Add a Single Choice question | start-with-prompt.spec.ts | both | active |
| 29 | TC_BS_03b | TC_BS_03b: Add a Multiple Choice question | start-with-prompt.spec.ts | both | active |
| 30 | TC_BS_03c | TC_BS_03c: Add a Rating question | start-with-prompt.spec.ts | both | active |
| 31 | TC_BS_03d | TC_BS_03d: Add an NPS question | start-with-prompt.spec.ts | both | active |
| 32 | TC_BS_03e | TC_BS_03e: Add a Point Scale question | start-with-prompt.spec.ts | both | active |
| 33 | TC_BS_03f | TC_BS_03f: Add a Multi Scale question | start-with-prompt.spec.ts | both | active |
| 34 | TC_BS_12 | TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey | start-with-prompt.spec.ts | both | active |
| 35 | TC_BS_04 | TC_BS_04: Options boundary - min 2, max 15 | start-with-prompt.spec.ts | both | active |
| 36 | TC_BS_10a | TC_BS_10a: Save draft with empty title requires a survey name | start-with-prompt.spec.ts | both | active |
| 37 | TC_BS_10 | TC_BS_10: Save survey as draft | start-with-prompt.spec.ts | both | active |
| 38 | TC_AI_13 | TC_AI_13: Validate survey: Completes and shows Optiq feedback when there are recommendations | start-with-prompt.spec.ts | Prompt | active |
| 39 | TC_BS_17 | TC_BS_17: Publish popup Cancel leaves the survey unpublished | start-with-prompt.spec.ts | both | active (was test.fixme, enabled) |
| 40 | TC_AI_14 | TC_AI_14: Create a new folder from the Publish popup | start-with-prompt.spec.ts | Prompt | active (was test.fixme, enabled) |

### 7.3 `tests\survey\select-panelist.spec.ts` (Select Panelists)

| # | TC id | Full test title | Describe | Flow | Status |
|---|---|---|---|---|---|
| 1 | TC_SP_03 | TC_SP_03: Cancelling the Product Offering modal applies no dataset | 'Select Panelists - Product Offering modal' (not serial) | Select Panelists | active |
| 2 | n/a | Setup: Should land on the survey home page and start from scratch | 'Select Panelists - filters and search' (serial) | Select Panelists | active |
| 3 | n/a | Setup: Should select the product offering and dataset and reach Select Panelists | same (serial) | Select Panelists | active |
| 4 | TC_SP_05 | TC_SP_05: All 5 filters are shown correctly in the summary sentence | same (serial) | Select Panelists | active |
| 5 | TC_SP_04 | TC_SP_04: Footer shows the source, dataset and view with a "Last refreshed" date | same (serial) | Select Panelists | active |
| 6 | TC_SP_07 | TC_SP_07: Search for Panelists is enabled only when every filter has exactly 1 selection | same (serial) | Select Panelists | active |
| 7 | TC_SP_06 | TC_SP_06: Filter validation banner and counter reflect the number of selected items | same (serial) | Select Panelists | active |
| 8 | TC_SP_08 | TC_SP_08: Search result shows eligible count, response options and credit message | same (serial) | Select Panelists | active |
| 9 | TC_SP_11 | TC_SP_11 - + More options shows additional response count choices | same (serial) | Select Panelists | active |
| 10 | TC_SP_10 | TC_SP_10 - selecting a response count enables Proceed, and changing a filter resets it | same (serial) | Select Panelists | active |
| 11 | TC_SP_09 | TC_SP_09: Too few eligible participants shows a message and blocks proceeding | same (serial) | Select Panelists | active |

Totals: Scratch 36 rows (35 active, 1 fixme); Prompt 40 rows (all active); Select Panelists 11 rows (all active). `select-panelist.spec.ts` has a note: TC_SP_03 and the serial describe use separate browsers (separate `basePage`).

---

## 8. NEW UI WITHOUT TESTS

One line each. "Locator only" means a locator or page-object method exists but no active test calls it. "Nothing in e2e" means no locator or method at all.

- **Pre-built surveys carousel**: nothing in e2e (no locator, no method, no test; searched for carousel / pre-built / template).
- **Pin icon / pinned surveys**: nothing in e2e (searched for pin / pinned).
- **"Edit survey" button in the Review survey details dialog**: nothing in e2e (no locator, no method).
- **Review survey details dialog (title, survey title, question count, response count, criteria summary, close X)**: only the fixme TC_BS_16/18 touches it (`confirmPublishDialogText`, `publish-dialog-dimension-by-index`, `publish-response-count-text`, `confirmPublishButton`); no active test. Test-ids `publish-dialog-title`, `publish-response-count`, `confirm-publish` are in the app but not in e2e locators.
- **"Publishing survey" loader and success redirect to `/my-assets`**: locator and methods exist (`publishingSurveyStatus`, `verifyPublishSucceeded`), used only by fixme TC_BS_16/18.
- **My Assets page / saved asset grid (`savedAssetGridcellByTitle`)**: locator only, no method or test uses it.
- **Optiq Feedback side panel (open/close, "Fix all", Dismiss, apply suggestion, status message)**: nothing in e2e except the text link `viewOptiqFeedbackLink`, checked only if a recommendation tag is visible; panel test-ids (`survey-side-panel`, `survey-side-panel-close`, `optiq-feedback-content`, `optiq-feedback-status`, `optiq-feedback-loader`) are missing.
- **Validation toasts (Validating / Changes recommended / Validation complete / Changes needed) and `getValidationOutcome()`**: locators and page-object methods exist (`isValidatingToastVisible`, `isChangesRecommendedToastVisible`, `isValidationResultToastVisible`, `getValidationOutcome`) but no test calls them.
- **"Revalidate survey" state (`validate-survey` after an edit) and "survey edited" toast**: no locator or test.
- **Publish location popup: Continue click, "Choose a location" heading, close X, folder count (`getPublishLocationFolderCount`)**: Continue disabled-state is read by TC_BS_17; click, heading and close X are missing; folder count is a method with no caller.
- **Delete survey button (header)**: appears in both page snapshots (`Delete survey`); nothing in e2e.
- **Dataset-selection locators `chooseDataviewBreadcrumb`, `defaultDataset`, `datasetSearchToggle`**: used inside the dataset helper only, no assertion of their own.
- **Question-count slider extras**: the number field and ArrowRight are tested by TC_AI_03; slider mouse-drag and min/max thumb positions are not.
- **Filter banner/counter for filters other than Product** (TC_SP_06 covers Product only): no test.

---

---

# ARCHIVE: round-1 findings (superseded where they disagree with the sections above)

# E2E Investigation Findings (read-only; no source code changed)

Paths below are relative to `e2e\`. Code is copied verbatim from the current files.

Note on the Page snapshots: the Playwright snapshots contain icon-font private-use glyphs (e.g. `button ""`). They are not
rendered in the tool output I read, so those characters are absent in the copies below. Everything else is verbatim.

---

## 1. RATING FAILURE (TC_BS_03c, Start from scratch)

Error (from `test-results\survey-start-from-scratch--5495e-S-03c-Add-a-Rating-question-chromium\error-context.md`):

```
Error: Failed to add Rating question: Rating question text input not visible after 15000ms
```

Test location per the report: `tests\survey\common-test-cases\build-survey-common-test-cases.ts:526:7`.

### 1.1 Spec registration (`tests\survey\start-from-scratch.spec.ts`)

```ts
  registerAddRatingQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03c: Add a Rating question', tag: '@RatingQuestion' });
```

### 1.2 The test (`tests\survey\common-test-cases\build-survey-common-test-cases.ts`)

```ts
export function registerAddRatingQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03c: Add a Rating question', { tag: options?.tag ?? '@RatingQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = testData.surveyQuestions.rating;

    await surveyBuilderPage.addRatingQuestion(questionText);
  });
}
```

Test data (`test-data\dev-test-data.json`): `surveyQuestions.rating.questionText` = `"Rate your experience"`.

### 1.3 Page-object methods it calls (`page-objects\common\survey-builder.page.ts`)

```ts
  // Question type selection
  private async clickQuestionTypeResource(resourceName: string): Promise<void> {
    await this.clickWhenVisible(resourceName, `Question-type tile "${resourceName}"`, MEDIUM_TIMEOUT);
  }
```

```ts
  /** Fills Rating's question-text field — locator is unscoped by question index (interim `:visible`-based mitigation). */
  private async fillRatingQuestionText(text: string): Promise<void> {
    await this.fillWhenVisible('ratingQuestionTextInput', text, 'Rating question text input');
  }
```

```ts
  async clickAddQuestion(): Promise<void> {
    try {
      await this.clickWhenVisible('addQuestionLink', 'Add question link');
      await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
    } catch (error) {
      throw new Error(`Failed to click add question: ${error instanceof Error ? error.message : error}`);
    }
  }
```

```ts
  async addRatingQuestion(questionText: string): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeRating');
      await this.fillRatingQuestionText(questionText); // unscoped by index (interim :visible-based mitigation)
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Rating question: ${error instanceof Error ? error.message : error}`);
    }
  }
```

Shared helpers (`page-objects\common\common-page.ts`) that produce the "not visible after 15000ms" message
(`ELEMENT_WAIT_TIMEOUT` = 15 * 1000):

```ts
  /** Throws (unlike `waitFor()`, which does not throw on timeout in this framework) if `element` isn't visible within `timeoutMs`. */
  protected async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then clicks it. */
  protected async clickWhenVisible(resourceName: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.click();
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then fills it. */
  protected async fillWhenVisible(
    resourceName: string,
    text: string,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.enterText(text);
  }
```

### 1.4 "Rating branch of addQuestion"

There is no method named `addQuestion`. The Rating add path is `addRatingQuestion` (above). The only other Rating branch is
in `ensureQuestionCount` (tops up with Rating questions; it also calls `addRatingQuestion`):

```ts
  /** Tops up to `min` Rating questions; the Rating tile toggles closed if add-question is clicked while already open, so only click it when not visible. */
  async ensureQuestionCount(min: number): Promise<void> {
    try {
      const { questionText } = devTestData.surveyQuestions.rating;
      let questionNumbers = await this.getQuestionNumbers();

      while (questionNumbers.length < min) {
        const countBeforeAdd = questionNumbers.length;
        const typeTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));

        if (!(await typeTile.isVisible(SMALL_TIMEOUT))) {
          await this.clickAddQuestion();
          if (!(await typeTile.isVisible(MEDIUM_TIMEOUT))) {
            throw new Error(`Question-type picker did not open after clicking add-question (current question count: ${countBeforeAdd})`);
          }
        }

        await this.addRatingQuestion(`${questionText} ${countBeforeAdd + 1}`);
        questionNumbers = await this.waitForQuestionCountAtLeast(countBeforeAdd + 1, MEDIUM_TIMEOUT);
      }
    } catch (error) {
      throw new Error(`Failed to ensure question count: ${error instanceof Error ? error.message : error}`);
    }
  }
```

### 1.5 How the other question types fill the text (for contrast)

```ts
  private async fillQuestionText(questionIndex: number, text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('questionTextInput', String(questionIndex), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await this.waitUntilVisible(questionText, 'Question text input');
    await questionText.enterText(text);
  }

  /** Counts rendered `.question-number` markers rather than trusting a hardcoded literal, since the persisted survey's question count is not stable across runs. */
  private async getNextQuestionIndex(): Promise<number> {
    const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    return markers.length + 1;
  }
```

`addNPSQuestion`, `addSingleChoiceQuestion`, `addMultipleChoiceQuestion`, `addScaleQuestion` all use
`getNextQuestionIndex()` + `fillQuestionText(questionIndex, ...)`. Only `addRatingQuestion` uses `ratingQuestionTextInput`.

`requiredToggle` usage (same truncated-id pattern):

```ts
  /** `requiredToggle`'s truncated id matches EVERY question's checkbox once more than one editor has been opened, so when `index` is given this scopes to that row instead of a page-wide nth. */
  async toggleRequired(index?: number): Promise<void> {
    try {
      if (index === undefined) {
        await this.clickWhenVisible('requiredToggle', 'Required toggle');
      } else {
        await this.closeInlineAddEditorIfOpen();
        const rowResource = this.getResource('questionRow');
        const toggleResource = this.getResource('requiredToggle');
        const toggle = this.webActionHandler.getWebElement({
          ...toggleResource,
          selectorType: 'playwrights',
          selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue}`,
        });
        await this.waitUntilVisible(toggle, `Required toggle (index ${index})`);
        await toggle.click();
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to toggle required: ${error instanceof Error ? error.message : error}`);
    }
  }
```

### 1.6 Locator JSON entries (`locators\survey\survey-builder.locator.json`)

```json
    { "elementName": "questionTextInput", "selectorType": "css", "selectorValue": "[data-test-id='question-text-input-${text}-input']" },
    { "elementName": "ratingQuestionTextInput", "selectorType": "playwrights", "selectorValue": "[data-test-id='-input']:visible" },
    { "elementName": "requiredToggle", "selectorType": "css", "selectorValue": "[data-test-id='-input-checkbox']" },
```

Related entries used by this flow:

```json
    { "elementName": "questionTypeRating", "selectorType": "css", "selectorValue": "[data-test-id='question-type-STAR_RATING']" },
    { "elementName": "addQuestionLink", "selectorType": "css", "selectorValue": "[data-test-id='add-question']" },
    { "elementName": "questionNumberMarker", "selectorType": "css", "selectorValue": ".question-number" },
```

### 1.7 Page snapshot (verbatim from the Rating `error-context.md`)

What the snapshot shows (facts only): the survey title is "Automation Test Survey", there are 2 saved questions (1 Single Choice, 2 Multiple Choice),
the Add-question type tiles are visible, and a question 3 editor is open with a focused `textbox "Question"`, a `switch "Required"`, and
"Discard changes" / "Save changes" buttons. So the editor did render, but `[data-test-id='-input']:visible` did not match it within 15 s.
The snapshot does not expose `data-test-id` attributes, so the actual id on that textbox is not verifiable from it.

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e7]:
      - generic [ref=e9]:
        - generic [ref=e10]:
          - button "" [ref=e11] [cursor=pointer]
          - generic [ref=e14]:
            - generic [ref=e15] [cursor=pointer]: 
            - button "" [ref=e20] [cursor=pointer]: 
            - button "" [ref=e24] [cursor=pointer]: 
            - button "" [ref=e28] [cursor=pointer]: 
        - generic [ref=e30] [cursor=pointer]:
          - generic [ref=e31]: 
          - img "logo" [ref=e32]
      - generic [ref=e33]:
        - generic [ref=e35] [cursor=pointer]:
          - status [ref=e36]
          - generic [ref=e37]: 
        - generic [ref=e38] [cursor=pointer]: 
        - generic "Open Optiq" [ref=e40] [cursor=pointer]:
          - img "arthur" [ref=e41]
        - generic [ref=e46] [cursor=pointer]:
          - generic [ref=e47]: 
          - generic [ref=e49]: Automation1
    - button "CHANGE DATASET" [ref=e51] [cursor=pointer]
    - generic [ref=e53]:
      - generic [ref=e55]:
        - generic [ref=e57]:
          - button "Step" [ref=e58] [cursor=pointer]
          - generic [ref=e62]: Select Panelists
        - generic [ref=e64]:
          - button "Step" [ref=e65] [cursor=pointer]
          - generic [ref=e69]: Build Survey
        - generic [ref=e71]:
          - button "Step" [ref=e72]
          - generic [ref=e73]: Survey Results
      - generic [ref=e76]:
        - generic [ref=e78]:
          - generic [ref=e80]:
            - paragraph [ref=e81]: Automation Test Survey
            - generic [ref=e82] [cursor=pointer]: 
          - generic [ref=e83]:
            - button "Save draft " [ref=e84] [cursor=pointer]:
              - generic [ref=e85]: Save draft
              - generic [ref=e86]: 
            - button "Review Survey" [ref=e87] [cursor=pointer]
            - button "Delete survey " [ref=e89] [cursor=pointer]:
              - generic [ref=e90]: Delete survey
              - generic [ref=e91]: 
        - generic [ref=e95]:
          - generic [ref=e96]:
            - generic [ref=e98]:
              - generic [ref=e104]:
                - generic [ref=e105]: "1."
                - generic [ref=e106]:
                  - generic "How satisfied are you with this product?" [ref=e108]
                  - generic [ref=e109]:
                    - generic [ref=e110]: 
                    - generic "Very satisfied" [ref=e111]
                  - generic [ref=e112]:
                    - generic [ref=e113]: 
                    - generic "Satisfied" [ref=e114]
                  - generic [ref=e115]:
                    - generic [ref=e116]: 
                    - generic "Not satisfied" [ref=e117]
              - text:   
            - generic [ref=e119]:
              - generic [ref=e125]:
                - generic [ref=e126]: "2."
                - generic [ref=e127]:
                  - generic "Which features do you use regularly?" [ref=e129]
                  - generic [ref=e130]:
                    - generic [ref=e131]: 
                    - generic "Search" [ref=e132]
                  - generic [ref=e133]:
                    - generic [ref=e134]: 
                    - generic "Filters" [ref=e135]
                  - generic [ref=e136]:
                    - generic [ref=e137]: 
                    - generic "Export" [ref=e138]
                  - generic [ref=e139]:
                    - generic [ref=e140]: 
                    - generic "Dashboard" [ref=e141]
              - text:   
          - button " Add question" [ref=e144] [cursor=pointer]:
            - generic [ref=e145]: 
            - generic [ref=e146]: Add question
          - generic [ref=e149]:
            - button "Single Choice" [ref=e150] [cursor=pointer]
            - button "Multiple Choice" [ref=e155] [cursor=pointer]
            - button "Rating" [ref=e160] [cursor=pointer]
            - button "Net Promoter Score" [ref=e165] [cursor=pointer]
            - button "Point Scale" [ref=e170] [cursor=pointer]
            - button "Multi Scale" [ref=e175] [cursor=pointer]
          - generic [ref=e183]:
            - generic [ref=e187]:
              - generic [ref=e188]:
                - generic [ref=e189]: "3."
                - textbox "Question" [active] [ref=e194]
              - generic [ref=e195]:
                - generic [ref=e196]: 
                - generic [ref=e198]: 
                - generic [ref=e200]: 
                - generic [ref=e202]: 
                - generic [ref=e204]: 
              - generic [ref=e206]:
                - switch "Required" [ref=e208] [cursor=pointer]
                - generic [ref=e213]: Required
            - generic [ref=e214]:
              - button "Discard changes " [ref=e215] [cursor=pointer]:
                - generic [ref=e216]: Discard changes
                - generic [ref=e217]: 
              - button "Save changes " [ref=e218] [cursor=pointer]:
                - generic [ref=e219]: Save changes
                - generic [ref=e220]: 
        - generic [ref=e222]:
          - button "Back" [ref=e223] [cursor=pointer]
          - button "Validate survey" [disabled]
      - generic:
        - generic:
          - generic:
            - generic:
              - generic: Source
              - generic: NielsenIQ Panel On Demand Omnishopper | Omni Agg SI 3yrs Synd | Entire Dataset
            - generic: "Last refreshed: Nov 2, 2026"
    - generic:                 
    - generic:
      - generic:
        - generic: Monitor my business
        - generic: Analyze my data
        - generic: Find my stuff
        - generic: Discover more tools
    - generic:
      - generic:
        - generic [ref=e262]:
          - heading "Optiq" [level=3] [ref=e263]
          - generic [ref=e264] [cursor=pointer]: ✕
        - generic [ref=e265]:
          - generic:
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic:
                      - generic:
                        - generic:
                          - paragraph: Ask a question to get started. Optiq is rapidly improving, so your feedback will help.
        - button "New chat " [ref=e270] [cursor=pointer]:
          - generic [ref=e271]: New chat
          - generic [ref=e272]: 
        - generic [ref=e274]:
          - textbox "Ask a question…" [ref=e275]
          - generic [ref=e276]: 0/2000
          - generic [ref=e277]: 
        - generic:
          - generic:
            - generic [ref=e279]:
              - text: AI generated content can be wrong.
              - link "Learn more" [ref=e282] [cursor=pointer]
            - text: 
    - text:  
  - tooltip
```

---

## 2. REPHRASE FAILURE (Start with a prompt, TC_AI_10 "Rephrase with AI clears the loading state and prompt")

Error (from `test-results\survey-start-with-prompt-S-1c458-he-loading-state-and-prompt-chromium\error-context.md`):

```
Error: Expected question 0 text to change after rephrase (before: "Overall, how satisfied are you with the appliance(s) you bought from Dollar Store? *", after: "Overall, how satisfied are you with the appliance(s) you bought from Dollar Store? *")
expect(received).toBeTruthy()

Received: false
```

### 2.1 Full test (`tests\survey\start-with-prompt.spec.ts`)

```ts
  test('TC_AI_10: Rephrase with AI clears the loading state and prompt', { tag: '@GenerateSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const normalize = (text: string) => text.replace(/\s+/g, '').replace(/\*$/, '');
    const textBefore0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textBefore1 = await surveyBuilderPage.getQuestionTextDisplay(1);

    await promptPage.rephraseQuestion(0, 'Make this question more concise');

    const textAfter0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textAfter1 = await surveyBuilderPage.getQuestionTextDisplay(1);
    assertTrue(
      normalize(textAfter0) !== normalize(textBefore0),
      `Expected question 0 text to change after rephrase (before: "${textBefore0}", after: "${textAfter0}")`
    );
    assertTrue(
      normalize(textAfter1) === normalize(textBefore1),
      `Expected question 1 text to remain unchanged after rephrasing question 0 (before: "${textBefore1}", after: "${textAfter1}")`
    );
  });
```

### 2.2 `rephraseQuestion()` (`page-objects\survey\start-with-prompt.page.ts`)

```ts
  /** `.question-actions` is only revealed via `.question-row`'s mouseenter handler, not CSS :hover. Scope to a single row via nth. */
  private getQuestionRowElement(index: number) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index}`,
    });
  }

  async rephraseQuestion(index: number, promptText: string): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await row.hover();

      const rephraseButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseWithAiButton', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
      await rephraseButton.click();

      const rephraseInput = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseInput', String(index), this.componentName)
      );
      let panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (!panelOpened) {
        console.warn('rephrase panel did not open after first click, retried');
        await this.webActionHandler.mouseMove(0, 0);
        await row.hover();
        await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
        await rephraseButton.click();
        panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      }
      if (!panelOpened) {
        throw new Error(`Rephrase panel (index ${index}) did not open after retry`);
      }
      await rephraseInput.enterText(promptText);

      const rephraseSendButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseSendButton', String(index), this.componentName)
      );
      await this.waitUntilVisible(rephraseSendButton, `Rephrase send button (index ${index})`);

      await rephraseSendButton.click();

      const rephraseSendLoading = this.webActionHandler.getWebElement({
        elementName: 'rephraseSendLoading',
        selectorType: 'css',
        selectorValue: '.rephrase-send-loading',
      });
      await rephraseSendLoading.waitFor(NAVIGATION_TIMEOUT, 'hidden');
      if (!(await rephraseSendLoading.isHidden())) {
        throw new Error(`Rephrase send button (index ${index}) stayed in loading state after ${NAVIGATION_TIMEOUT}ms`);
      }

      await this.webActionHandler.mouseMove(0, 0); // move off the row so the hover doesn't linger into the next test

      const panelStillOpen = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (panelStillOpen) {
        const promptValue = await rephraseInput.getValue();
        if (promptValue !== '') {
          throw new Error(`Rephrase prompt input (index ${index}) was not cleared after submit, value: "${promptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to rephrase question ${index}: ${error instanceof Error ? error.message : error}`);
    }
  }
```

### 2.3 `getQuestionTextDisplay()` and its element builder (`page-objects\common\survey-builder.page.ts`)

```ts
  private getQuestionTextDisplayElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const resource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...resource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${resource.selectorValue}`,
    });
  }
```

```ts
  /** Readonly display text includes a trailing `*` when Required is on. */
  async getQuestionTextDisplay(index: number): Promise<string> {
    try {
      const textElement = this.getQuestionTextDisplayElement(index);
      await this.waitUntilVisible(textElement, `Question text display (index ${index})`);
      return (await textElement.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read question ${index} text display: ${error instanceof Error ? error.message : error}`);
    }
  }
```

### 2.4 Locator JSON — every entry starting with "rephrase"

`locators\survey\start-with-prompt.locator.json`:

```json
    { "elementName": "rephraseWithAiButton", "selectorType": "playwrights", "selectorValue": ".rephrase-action >> nth=${text}" },
    { "elementName": "rephraseInput", "selectorType": "css", "selectorValue": ".rephrase-input:not([data-tmp='${text}'])" },
    { "elementName": "rephraseSendButton", "selectorType": "css", "selectorValue": ".rephrase-send:not([data-tmp='${text}'])" },
```

No entries starting with "rephrase" exist in the other locator JSON files (`survey-builder`, `start-from-scratch`, `select-panelist`, `login`).
`rephraseSendLoading` (`.rephrase-send-loading`) is NOT in any JSON; it is defined inline in `rephraseQuestion()` (shown above).

Locators used to read the before/after text (`locators\survey\survey-builder.locator.json`):

```json
    { "elementName": "questionRow", "selectorType": "css", "selectorValue": ".question-row" },
    { "elementName": "questionTextDisplay", "selectorType": "css", "selectorValue": ".question-text" }
```

### 2.5 Exactly which element the before/after text is read from, and when

- Element: `SurveyBuilderPage.getQuestionTextDisplay(index)` reads `.question-row >> nth=<index> >> .question-text` (selectorType `playwrights`),
  via `getText()` then `.trim()`. The same element is used for both "before" and "after", for index 0 (and index 1 as the control).
  The read is a single point-in-time `getText()` after a visibility wait; there is no polling/`expect.poll` for the text to change.
- "Before": read at the start of the test, before `rephraseQuestion()` is called, so it is correctly the pre-rephrase text.
- "After": read immediately after `rephraseQuestion()` returns. `rephraseQuestion()` considers the rephrase finished when
  `.rephrase-send-loading` is `hidden` (up to `NAVIGATION_TIMEOUT` = 60 s), then does `mouseMove(0,0)` and an `isVisible(SMALL_TIMEOUT)` check on the rephrase input.
  Nothing waits for the question text itself to change. So whether "after" is read before the rephrase finishes depends on whether the
  loading class was ever applied/removed around the response:
  `waitFor(..., 'hidden')` passes immediately if `.rephrase-send-loading` is not in the DOM at that moment (for example, if it has not appeared yet,
  or it was removed before the new text rendered). This is a code-reading inference; the failure output does not prove which case occurred.
  In the failure, before and after are identical, including the trailing ` *`.

### 2.6 Page snapshot (verbatim from the Rephrase `error-context.md`)

What it shows (facts only): 5 questions; question 1 is a rating-style question "Overall, how satisfied are you with the appliance(s) you bought from Dollar Store? *";
question 3 (index 2) has its hover actions visible (`Rephrase with AI` button and 3 icon buttons); no rephrase input panel and no loading element is visible at
snapshot time; the survey title is "Automation Test Survey"; 10-question limit is not reached (5 questions).

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e7]:
      - generic [ref=e9]:
        - generic [ref=e10]:
          - button "" [ref=e11] [cursor=pointer]
          - generic [ref=e14]:
            - generic [ref=e15] [cursor=pointer]: 
            - button "" [ref=e20] [cursor=pointer]: 
            - button "" [ref=e24] [cursor=pointer]: 
            - button "" [ref=e28] [cursor=pointer]: 
        - generic [ref=e30] [cursor=pointer]:
          - generic [ref=e31]: 
          - img "logo" [ref=e32]
      - generic [ref=e33]:
        - generic [ref=e35] [cursor=pointer]:
          - status [ref=e36]
          - generic [ref=e37]: 
        - generic [ref=e38] [cursor=pointer]: 
        - generic "Open Optiq" [ref=e40] [cursor=pointer]:
          - img "arthur" [ref=e41]
        - generic [ref=e46] [cursor=pointer]:
          - generic [ref=e47]: 
          - generic [ref=e49]: Automation1
    - button "CHANGE DATASET" [ref=e51] [cursor=pointer]
    - generic [ref=e53]:
      - generic [ref=e55]:
        - generic [ref=e57]:
          - button "Step" [ref=e58] [cursor=pointer]
          - generic [ref=e62]: Select Panelists
        - generic [ref=e64]:
          - button "Step" [ref=e65] [cursor=pointer]
          - generic [ref=e69]: Build Survey
        - generic [ref=e71]:
          - button "Step" [ref=e72]
          - generic [ref=e73]: Survey Results
      - generic [ref=e76]:
        - generic [ref=e78]:
          - generic [ref=e80]:
            - paragraph [ref=e81]: Automation Test Survey
            - generic [ref=e82] [cursor=pointer]: 
          - generic [ref=e83]:
            - button "Save draft " [ref=e84] [cursor=pointer]:
              - generic [ref=e85]: Save draft
              - generic [ref=e86]: 
            - button "Review Survey" [ref=e87] [cursor=pointer]
            - button "Delete survey " [ref=e89] [cursor=pointer]:
              - generic [ref=e90]: Delete survey
              - generic [ref=e91]: 
        - generic [ref=e95]:
          - generic [ref=e96]:
            - generic [ref=e98]:
              - generic [ref=e104]:
                - generic [ref=e105]: "1."
                - generic [ref=e106]:
                  - generic [ref=e107]: Overall, how satisfied are you with the appliance(s) you bought from Dollar Store? *
                  - generic [ref=e109]:
                    - generic [ref=e110]:
                      - generic [ref=e111]: Very dissatisfied
                      - generic [ref=e113]: Dissatisfied
                      - generic [ref=e115]: Neither satisfied nor dissatisfied
                      - generic [ref=e117]: Satisfied
                      - generic [ref=e119]: Very satisfied
                    - generic [ref=e121]:
                      - generic [ref=e122]: Overall satisfaction
                      - generic:
                        - radio
                      - generic:
                        - radio
                      - generic:
                        - radio
                      - generic:
                        - radio
                      - generic:
                        - radio
              - text:    
            - generic [ref=e125]:
              - generic [ref=e131]:
                - generic [ref=e132]: "2."
                - generic [ref=e133]:
                  - generic [ref=e134]: How well did the appliance(s) you bought meet your expectations? *
                  - generic [ref=e136]:
                    - generic [ref=e137]:
                      - generic [ref=e138]: Much worse than expected
                      - generic [ref=e140]: Somewhat worse than expected
                      - generic [ref=e142]: As expected
                      - generic [ref=e144]: Somewhat better than expected
                      - generic [ref=e146]: Much better than expected
                    - generic [ref=e148]:
                      - generic [ref=e149]: Meets expectations
                      - generic:
                        - radio
                      - generic:
                        - radio
                      - generic:
                        - radio
                      - generic:
                        - radio
                      - generic:
                        - radio
              - text:    
            - generic [ref=e152]:
              - generic [ref=e158]:
                - generic [ref=e159]: "3."
                - generic [ref=e160]:
                  - generic "Which aspects of the appliance(s) are you satisfied with?" [ref=e162]: Which aspects of the appliance(s) are you satisfied with? *
                  - generic [ref=e163]:
                    - generic [ref=e164]: 
                    - generic "Performance" [ref=e165]
                  - generic [ref=e166]:
                    - generic [ref=e167]: 
                    - generic "Ease of use" [ref=e168]
                  - generic [ref=e169]:
                    - generic [ref=e170]: 
                    - generic "Price/value" [ref=e171]
                  - generic [ref=e172]:
                    - generic [ref=e173]: 
                    - generic "Design/appearance" [ref=e174]
                  - generic [ref=e175]:
                    - generic [ref=e176]: 
                    - generic "None of the above" [ref=e177]
              - generic [ref=e321]:
                - button "Rephrase with AI " [ref=e323] [cursor=pointer]:
                  - generic [ref=e324]: Rephrase with AI
                  - generic [ref=e325]: 
                - button "" [ref=e326] [cursor=pointer]
                - button "" [ref=e329] [cursor=pointer]
                - button "" [ref=e332] [cursor=pointer]
            - generic [ref=e179]:
              - generic [ref=e185]:
                - generic [ref=e186]: "4."
                - generic [ref=e187]:
                  - generic [ref=e188]: How likely are you to recommend the appliance brand you bought to a friend or family member? *
                  - generic [ref=e190]:
                    - generic [ref=e191]:
                      - button "1" [ref=e192] [cursor=pointer]
                      - button "2" [ref=e194] [cursor=pointer]
                      - button "3" [ref=e196] [cursor=pointer]
                      - button "4" [ref=e198] [cursor=pointer]
                      - button "5" [ref=e200] [cursor=pointer]
                      - button "6" [ref=e202] [cursor=pointer]
                      - button "7" [ref=e204] [cursor=pointer]
                      - button "8" [ref=e206] [cursor=pointer]
                      - button "9" [ref=e208] [cursor=pointer]
                      - button "10" [ref=e210] [cursor=pointer]
                    - generic [ref=e212]:
                      - generic [ref=e213]: Not at all likely
                      - generic [ref=e214]: Extremely likely
              - text:    
            - generic [ref=e216]:
              - generic [ref=e222]:
                - generic [ref=e223]: "5."
                - generic [ref=e224]:
                  - generic "What is the main reason for your satisfaction with the appliance(s) you bought?" [ref=e226]
                  - generic [ref=e227]:
                    - generic [ref=e228]: 
                    - generic "It works as expected" [ref=e229]
                  - generic [ref=e230]:
                    - generic [ref=e231]: 
                    - generic "Good value for the price" [ref=e232]
                  - generic [ref=e233]:
                    - generic [ref=e234]: 
                    - generic "Easy to use" [ref=e235]
                  - generic [ref=e236]:
                    - generic [ref=e237]: 
                    - generic "I am not satisfied" [ref=e238]
                  - generic [ref=e239]:
                    - generic [ref=e240]: 
                    - generic "Other" [ref=e241]
              - text:    
          - generic [ref=e243]:
            - button " Add question" [ref=e244] [cursor=pointer]:
              - generic [ref=e245]: 
              - generic [ref=e246]: Add question
            - button " Generate more questions" [ref=e247] [cursor=pointer]:
              - generic [ref=e248]: 
              - generic [ref=e249]: Generate more questions
            - button " Describe questions to add" [ref=e250] [cursor=pointer]:
              - generic [ref=e251]: 
              - generic [ref=e252]: Describe questions to add
        - generic [ref=e254]:
          - button "Back" [ref=e255] [cursor=pointer]
          - button "Validate survey" [ref=e257] [cursor=pointer]
      - generic:
        - generic:
          - generic:
            - generic:
              - generic: Source
              - generic: NielsenIQ Panel On Demand Omnishopper | Omni Agg SI 3yrs Synd | Entire Dataset
            - generic: "Last refreshed: Nov 2, 2026"
    - generic:                 
    - generic:
      - generic:
        - generic: Monitor my business
        - generic: Analyze my data
        - generic: Find my stuff
        - generic: Discover more tools
    - generic:
      - generic:
        - generic [ref=e296]:
          - heading "Optiq" [level=3] [ref=e297]
          - generic [ref=e298] [cursor=pointer]: ✕
        - generic [ref=e299]:
          - generic:
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic:
                      - generic:
                        - generic:
                          - paragraph: Ask a question to get started. Optiq is rapidly improving, so your feedback will help.
        - button "New chat " [ref=e304] [cursor=pointer]:
          - generic [ref=e305]: New chat
          - generic [ref=e306]: 
        - generic [ref=e308]:
          - textbox "Ask a question…" [ref=e309]
          - generic [ref=e310]: 0/2000
          - generic [ref=e311]: 
        - generic:
          - generic:
            - generic [ref=e313]:
              - text: AI generated content can be wrong.
              - link "Learn more" [ref=e316] [cursor=pointer]
            - text: 
    - text:  
  - tooltip
```

---

## 3. SAVE DRAFT (current code)

### 3.1 `saveDraft()` and the helpers it calls (`page-objects\common\survey-builder.page.ts`)

```ts
  /** Expands "My Assets" via its own row-scoped `.arrow` (not page-wide) and picks the first non-"My Assets" folder row, only when Save isn't already enabled on "My Assets" alone. Shared by fillSaveCopyDialog(); publish can reuse it too. */
  private async selectSaveLocation(): Promise<void> {
    await this.clickWhenVisible('myAssetsTreeItem', 'My Assets tree item');

    const saveButton = this.webActionHandler.getWebElement(this.getResource('savePendingChangesButton'));
    const isSaveButtonVisible = await saveButton.isVisible(SMALL_TIMEOUT);
    const isSaveReady = isSaveButtonVisible && (await saveButton.isEnabled());
    if (isSaveReady) {
      return;
    }

    const nativePage = (BasePage as any).page as import('playwright').Page; // "not My Assets" folder filtering needs Playwright's filter API, not expressible via resource strings
    const myAssetsRow = nativePage.getByRole('treeitem', { name: 'My Assets' });
    await myAssetsRow.locator('.arrow').click({ timeout: SMALL_TIMEOUT });

    const folderRow = nativePage.getByRole('treeitem').filter({ hasNotText: 'My Assets' }).first();
    await folderRow.click({ timeout: SMALL_TIMEOUT });
  }

  /** Fills the Save-a-copy dialog (title, My Assets, save pending changes) — shared by saveDraft() and publishSurvey(). */
  private async fillSaveCopyDialog(title: string): Promise<void> {
    await this.fillWhenVisible('saveCopyTitleInput', title, 'Save-copy title input');
    await this.selectSaveLocation();
    await this.clickWhenVisible('savePendingChangesButton', 'Save pending changes button');
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /** Already-saved surveys (e.g. after TC_BS_10a) save directly without the Save-a-copy dialog, so the dialog flow is skipped when it doesn't appear within 3s. */
  async saveDraft(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');

      const titleInput = this.webActionHandler.getWebElement(this.getResource('saveCopyTitleInput'));
      if (!(await titleInput.isVisible(SAVE_DIALOG_APPEAR_TIMEOUT))) {
        return;
      }
      await this.fillSaveCopyDialog(title);
    } catch (error) {
      throw new Error(`Failed to save draft: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDraftSavedToastVisible(): Promise<boolean> {
    try {
      const toast = this.webActionHandler.getWebElement(this.getResource('saveDraftSuccessToast'));
      return toast.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to check draft saved toast visibility: ${error instanceof Error ? error.message : error}`);
    }
  }
```

`SAVE_DIALOG_APPEAR_TIMEOUT` = 3 * 1000 (`constants\timeout-constants.ts`).

### 3.2 `clickSaveDraftButton` and `isSaveDraftDialogVisible`

```ts
  async clickSaveDraftButton(): Promise<void> {
    try {
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');
    } catch (error) {
      throw new Error(`Failed to click Save draft button: ${error instanceof Error ? error.message : error}`);
    }
  }
```

```ts
  async isSaveDraftDialogVisible(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('saveDraftDialog'));
      return await dialog.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Save draft dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }
```

### 3.3 `registerSaveDraftTest` and `registerSaveDraftEmptyTitleTest` (`tests\survey\common-test-cases\build-survey-common-test-cases.ts`)

```ts
export function registerSaveDraftTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_10: Save survey as draft', { tag: options?.tag ?? '@SaveDraft' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const title = `SaveDraft_${Date.now()}`;
    await surveyBuilderPage.saveDraft(title);
    const isToastVisible = await surveyBuilderPage.isDraftSavedToastVisible();
    assertTrue(isToastVisible, 'Expected "Survey saved as draft successfully" toast to be visible after saving draft');
  });
}

export function registerSaveDraftEmptyTitleTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_10a: Save draft with empty title requires a survey name',
    { tag: options?.tag ?? '@SaveDraftDialog' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const initialQuestionCount = await surveyBuilderPage.getQuestionCount();

      await surveyBuilderPage.setSurveyTitle('');
      const titleValue = await surveyBuilderPage.getSurveyTitleValue();
      assertTrue(titleValue === '', `Expected survey title value to be empty before saving draft, got "${titleValue}"`);
      await surveyBuilderPage.commitSurveyTitle();


      await ensureAtLeastOneQuestion(surveyBuilderPage);

      await surveyBuilderPage.clickSaveDraftButton();

      assertTrue(
        await surveyBuilderPage.isSaveDraftDialogVisible(),
        'Expected "Save your survey" dialog to be visible after clicking Save draft'
      );
      assertTrue(
        await surveyBuilderPage.isSaveDraftDialogValidationErrorVisible(),
        'Expected "Survey name is required." error to be visible with an empty survey name'
      );
      assertTrue(
        await surveyBuilderPage.isSaveDraftDialogSaveButtonDisabled(),
        "Expected the dialog's Save draft button to be disabled with an empty survey name"
      );

      await surveyBuilderPage.fillSaveDraftDialogName('testing');
      await surveyBuilderPage.clickSaveDraftDialogMyAssetsFolder();
      assertTrue(
        !(await surveyBuilderPage.isSaveDraftDialogSaveButtonDisabled()),
        "Expected the dialog's Save draft button to be enabled after entering a name and selecting My Assets"
      );

      await surveyBuilderPage.clickSaveDraftDialogSaveButton();

      const isToastVisible = await surveyBuilderPage.isDraftSavedToastVisible();
      assertTrue(isToastVisible, 'Expected "Survey saved as draft successfully" toast to be visible after saving draft');

      const titleAfterSave = await surveyBuilderPage.getSurveyTitleDisplay();
      assertTrue(titleAfterSave === 'testing', `Expected survey title to update to "testing" after saving draft, got "${titleAfterSave}"`);

      // TC_BS_03a (next registered test) assumes a 0-question empty state, so undo the question added above.
      // Skipped when questions already existed (e.g. AI-generated) so real questions are not deleted.
      if (initialQuestionCount === 0) {
        await surveyBuilderPage.deleteQuestionAt(0);
      }
    }
  );
}
```

### 3.4 Save-draft locators (`locators\survey\survey-builder.locator.json`)

```json
    { "elementName": "saveDraftButton", "selectorType": "css", "selectorValue": "[data-test-id='save-draft']" },
    { "elementName": "saveCopyTitleInput", "selectorType": "css", "selectorValue": "[data-test-id='save-a-copy-title-input']" },
    { "elementName": "myAssetsTreeItem", "selectorType": "playwrights", "selectorValue": "role=treeitem[name*=\"My Assets\"]" },
    { "elementName": "savePendingChangesButton", "selectorType": "css", "selectorValue": "[data-test-id='save-pending-changes-button']" },
    { "elementName": "saveDraftDialog", "selectorType": "playwrights", "selectorValue": "[role='dialog']:has-text(\"Save your survey\") >> nth=0" },
    { "elementName": "saveDraftDialogNameInput", "selectorType": "playwrights", "selectorValue": "role=textbox[name=\"Name\"]" },
    { "elementName": "saveDraftDialogErrorText", "selectorType": "playwrights", "selectorValue": "text=\"Survey name is required.\" >> nth=0" },
    { "elementName": "saveDraftDialogMyAssetsFolder", "selectorType": "playwrights", "selectorValue": "role=treeitem[name*=\"My Assets\"] >> nth=0" },
    { "elementName": "saveDraftDialogSaveButton", "selectorType": "playwrights", "selectorValue": "role=button[name=\"Save draft\"] >> nth=0" },
    { "elementName": "saveDraftSuccessToast", "selectorType": "text", "selectorValue": "Survey saved as draft successfully" },
```

### 3.5 Ordering conflict worth checking (code reading, not verified by a run)

`saveDraft()` skips the dialog for an already-saved survey, and `registerSaveDraftEmptyTitleTest` requires the "Save your survey" dialog to appear.
- Start from scratch: 10a runs early (survey still unsaved) and TC_BS_10 runs later (already saved by 10a, so no dialog). Consistent.
- Start with prompt: TC_BS_10 runs first and saves the survey (dialog flow, title `SaveDraft_<ts>`); TC_BS_10a runs right after on an already-saved survey, and expects the dialog.
  Per the `saveDraft` comment, the dialog may not appear for a saved survey, so 10a's `isSaveDraftDialogVisible` assertion is at risk in that file.

---

## 4. STATE MAP

Legend. "Permanent" means a change not undone by a later step in the same test: SAVE = draft saved, TITLE = survey title changed,
DELETE = questions deleted, PUBLISH = published, LEAVE = leaves Build Survey. Plain builder edits (add/edit/reorder/duplicate a question) are listed as "edits (unsaved)".
Question counts assume every earlier test passed. Expected counts are derived from the code; they were not measured.

Run behaviour that affects the state map (both files): `test.describe.serial(...)`, so after one test fails, Playwright skips every later test in that describe.
One shared `basePage` (browser) is created in the first test and reused by all tests. No test creates a fresh survey after the first.

### 4.1 `tests\survey\start-from-scratch.spec.ts`

Describe: `test.describe.serial('Start from scratch', { tag: '@StartFromScratch' }, ...)`. Serial: yes.

| # | Test (run order) | Permanent changes | State assumed at start |
|---|---|---|---|
| 1 | Start from Scratch: Should display the Start from scratch option on the survey home page | none (creates browser, opens Start from scratch) | n/a, survey home page |
| 2 | Dataset Selection: Should select the dataset and confirm the Choose a dataset screen | none | in dataset step |
| 3 | Panelist Filters: Should enable Search for Panelists after all 5 filters are set | none | Select Panelists step |
| 4 | Response Count: Should enable Proceed to survey builder after selecting a response count | none | Select Panelists step |
| 5 | Survey Builder: Should navigate to the Build Survey page after proceeding | LEAVE (Select Panelists -> Build Survey) | Select Panelists, 250 responses selected |
| 6 | TC_BS_01: First landing shows "Untitled Survey" and the Add question panel | none | new survey: title "Untitled Survey" (asserted), 0 questions, unsaved |
| 7 | `registerSaveDraftEmptyTitleTest` TC_BS_10a: Save draft with empty title requires a survey name | SAVE (draft "testing" in My Assets), TITLE ("testing"), edits: adds one question then deletes it (initial count was 0) | title "Untitled Survey", 0 questions, unsaved (needs the Save-a-copy dialog to appear) |
| 8 | `registerEditSurveyTitleTest` TC_BS_02: Edit survey title | TITLE -> "Automation Test Survey" (`surveyQuestions.surveyTitle`) | saved draft titled "testing", 0 questions |
| 9 | `registerAddSingleChoiceQuestionTest` TC_BS_03a | edits: +1 question (Single Choice, 4 options per snapshot) | 0 questions (empty state; does NOT call `clickAddQuestion` first), title "Automation Test Survey" |
| 10 | `registerAddMultipleChoiceQuestionTest` TC_BS_03b | edits: +1 (Multiple Choice) | 1 question |
| 11 | `registerAddRatingQuestionTest` TC_BS_03c (FAILS in last run) | edits: +1 (Rating "Rate your experience") | 2 questions; failure snapshot confirms 2 questions and the Q3 editor open |
| 12 | `registerAddNPSQuestionTest` TC_BS_03d | edits: +1 (NPS) | 3 questions |
| 13 | `registerAddPointScaleQuestionTest` TC_BS_03e | edits: +1 | 4 questions |
| 14 | `registerAddMultiScaleQuestionTest` TC_BS_03f | edits: +1 | 5 questions (ends at 6) |
| 15 | `registerRequiredStarTest` TC_BS_07 | edits: Q0 Required toggled (ends ON) | >= 1 question |
| 16 | `registerEditQuestionTextTest` TC_BS_25 | edits: Q0 text -> `surveyQuestions.nps.questionText` | >= 1 question |
| 17 | `registerDiscardSaveChangesTest` TC_BS_26 | edits: Q0 text -> `Saved text <ts>` | >= 1 question |
| 18 | `registerEmptyQuestionTextBlocksSaveTest` TC_BS_28 | none (discarded) | >= 1 question |
| 19 | `registerCancelAddQuestionTest` TC_BS_05 | DELETE only if Add question is disabled (10 questions): deletes Q0; otherwise none | 6 questions |
| 20 | `registerDragDropTest` TC_BS_15 | edits: Q0 and Q1 swapped | >= 2 questions |
| 21 | `registerDeleteDuplicateQuestionTest` TC_BS_06 | DELETE Q0 then duplicate Q0 (net 0) | 6 questions (needs < 10 after delete) |
| 22 | `registerOptionBoundaryTest` TC_BS_04 | edits: +1 Single Choice (2 options kept; extra options discarded) | 6 questions |
| 23 | `registerStepperNavigationTest` TC_BS_12 (stepper) | edits: +1 Rating; LEAVE and return (Select Panelists step, then Proceed back to Build Survey) | 7 questions; Select Panelists retained values (250 responses) |
| 24 | TC_BS_08: Max questions (10) disables Add question and Duplicate | edits: tops up with Rating questions to 10 | 8 questions (any count < 10) |
| 25 | `registerReviewModeTest` TC_BS_13/TC_BS_14 | DELETE Q0 via Review Mode (10 -> 9) | 10 questions (`ensureQuestionCount(3)`) |
| 26 | `registerSaveDraftTest` TC_BS_10 | SAVE (survey already saved by #7, so the Save-a-copy dialog is skipped; title stays) | 9 questions, already-saved survey |
| 27 | `registerValidateSurveyTest` TC_BS_23 | validation state change: "Validate survey" is replaced by "Review & publish survey" | 9 questions (`ensureQuestionCount(3)`) |
| 28 | TC_AI_12: No Optiq-AI action buttons visible | none | >= 1 question (`ensureAtLeastOneQuestion`); validated survey |
| 29 | `registerDiscardNewQuestionThenSaveTest` TC_BS_22 | edits: +1 Rating (after a discarded one) | 9 questions (deletes Q0 first if at 10) |
| 30 | `registerDeleteLastThenReAddTest` TC_BS_20 | DELETE last then re-add Rating (net +1, and deletes Q0 first if at 10) | 10 questions |
| 31 | `registerPublishPopupCancelTest` TC_BS_17 | `test.fixme` (skipped) | n/a |
| 32 | `registerCreateFolderFromPublishPopupTest` TC_BS_24 | `test.fixme` (skipped) | n/a |
| 33 | `test.fixme` TC_BS_16/TC_BS_18: Publish survey | `test.fixme` (skipped; would PUBLISH) | n/a |
| 34 | `registerReviewModeDeleteAllTest` TC_BS_27 | DELETE all questions (-> 0) | >= 1 question (Review Mode needs questions) |
| 35 | `registerValidateDisabledUnderThreeTest` TC_BS_09 | none (no deletion needed at 0) | 0 questions; the publish button is the one to check, because #27 already validated the survey |
| 36 | TC_BS_12: Back button returns to the previous step from the builder | LEAVE (Build Survey -> Select Panelists) | on Build Survey |

### 4.2 `tests\survey\start-with-prompt.spec.ts`

Describe: `test.describe.serial('Start with a prompt', { tag: '@StartWithPrompt' }, ...)`. Serial: yes.

| # | Test (run order) | Permanent changes | State assumed at start |
|---|---|---|---|
| 1 | Start with a Prompt: Should display the Start with a prompt option on the survey home page | none (creates browser, opens Start with a prompt) | survey home page |
| 2 | Dataset Selection: Should select the dataset type and dataset | none | dataset-type step |
| 3 | Panelist Filters: Should set dimension selections and search for panelists | none | Select Panelists step |
| 4 | Response Count: Should select a response count | none | panelists searched |
| 5 | TC_AI_01: Select Panelists shows the Optiq heading, prompt textbox, and disables Generate Survey until prompt is entered | none (types a prompt then clears it) | Select Panelists, 250 responses; prompt empty |
| 6 | Generate Survey: Should fill the prompt and reach the Build Survey page | LEAVE Select Panelists (AI generation starts) | Select Panelists, empty prompt |
| 7 | TC_AI_04: Should allow selecting multiple question types on the Customize Questions screen | none (each tile deselected and reselected) | Customize Questions screen; all 6 types selected by default (asserted) |
| 8 | TC_AI_05: Generate questions creates AI questions | creates the AI survey (AI title + AI questions; 5 in the TC_AI_10 snapshot); LEAVE Customize Questions | Customize Questions screen, 0 generated questions; test timeout 240 s |
| 9 | `registerEditSurveyTitleTest` TC_AI_07 (`expectAiTitle: true`) | TITLE -> "Automation Test Survey" | AI-generated survey: non-empty title other than "Untitled Survey" (asserted), unsaved |
| 10 | TC_AI_10: Rephrase with AI clears the loading state and prompt | edits: Q0 text rephrased (expected) | 5 questions, title "Automation Test Survey", unsaved |
| 11 | TC_AI_08: Generate more questions increases the question count | edits: +>=1 AI questions | 5 questions |
| 12 | TC_AI_09: Describe questions to add increases the question count | edits: +>=1 AI questions | 6+ questions |
| 13 | TC_AI_11/TC_BS_08: Add Question/Duplicate/Generate more/Describe are disabled at 10 (max) | none | EXACTLY 10 questions (asserted) |
| 14 | `registerRequiredStarTest` TC_BS_07 | edits: Q0 Required ON | 10 questions |
| 15 | `registerEditQuestionTextTest` TC_BS_25 | edits: Q0 text -> NPS text | 10 questions |
| 16 | `registerDiscardSaveChangesTest` TC_BS_26 | edits: Q0 text -> `Saved text <ts>` | 10 questions |
| 17 | `registerEmptyQuestionTextBlocksSaveTest` TC_BS_28 | none | 10 questions |
| 18 | `registerDeleteDuplicateQuestionTest` TC_BS_06 | DELETE Q0 then duplicate Q0 (net 0) | 10 questions (needs < 10 after delete) |
| 19 | `registerDragDropTest` TC_BS_15 | edits: Q0 and Q1 swapped | 10 questions |
| 20 | `registerCancelAddQuestionTest` TC_BS_05 | DELETE Q0 if Add question is disabled (at 10): yes here, so 10 -> 9 | 10 questions |
| 21 | `registerDiscardNewQuestionThenSaveTest` TC_BS_22 | edits: +1 Rating (9 -> 10) | 9 questions |
| 22 | `registerDeleteLastThenReAddTest` TC_BS_20 | DELETE Q0 (at 10), then add Rating, delete last, re-add (ends at 10) | 10 questions |
| 23 | `registerReviewModeTest` TC_BS_13/TC_BS_14 | DELETE Q0 via Review Mode (10 -> 9) | 10 questions |
| 24 | `registerValidateDisabledUnderThreeTest` TC_BS_09 | DELETE down to 2 questions | 9 questions; the survey is not yet validated, so it checks "Validate survey" |
| 25 | `registerReviewModeDeleteAllTest` TC_BS_27 | DELETE all (-> 0) | 2 questions |
| 26 | `registerEmptyStateTest` TC_BS_01 | none | 0 questions (asserted) |
| 27 | `registerAddSingleChoiceQuestionTest` TC_BS_03a | edits: +1 | 0 questions, empty state (no `clickAddQuestion` first) |
| 28 | `registerAddMultipleChoiceQuestionTest` TC_BS_03b | edits: +1 | 1 question |
| 29 | `registerAddRatingQuestionTest` TC_BS_03c | edits: +1 | 2 questions |
| 30 | `registerAddNPSQuestionTest` TC_BS_03d | edits: +1 | 3 questions |
| 31 | `registerAddPointScaleQuestionTest` TC_BS_03e | edits: +1 | 4 questions |
| 32 | `registerAddMultiScaleQuestionTest` TC_BS_03f | edits: +1 | 5 questions (ends at 6) |
| 33 | `registerStepperNavigationTest` TC_BS_12 (`responseCountTestId: 'select-response-count-250'`) | edits: +1 Rating; LEAVE and return (Select Panelists, then Proceed back to Build Survey) | 6 questions |
| 34 | `registerOptionBoundaryTest` TC_BS_04 | edits: +1 Single Choice (2 options kept) | 7 questions |
| 35 | `registerSaveDraftTest` TC_BS_10 | SAVE (survey is unsaved, so the Save-a-copy dialog appears and the title becomes `SaveDraft_<ts>`; this title change is not asserted) | 8 questions, title "Automation Test Survey", unsaved |
| 36 | `registerSaveDraftEmptyTitleTest` TC_BS_10a | TITLE -> '' then "testing", SAVE (second save). Conflict: see 3.5 | expects an UNSAVED survey (dialog must appear), but #35 just saved it; 8 questions, so the add/delete-question step is skipped |
| 37 | `registerValidateSurveyTest` TC_AI_13 | validation state change ("Validate survey" -> "Review & publish survey") | 8 questions |
| 38 | `registerPublishPopupCancelTest` TC_BS_17 | `test.fixme` (skipped) | n/a |
| 39 | `registerCreateFolderFromPublishPopupTest` TC_AI_14 | `test.fixme` (skipped) | n/a |

No publish happens in either file (all publish tests are `fixme`). No test deletes the whole survey ("Delete survey" button is never clicked).

Parallelism note: both spec files are separate files, so with `workers: 2` (non-CI, see section 5) they can run at the same time in two browsers, both using the same stored auth user
(`storage/auth.json`, user "Automation1"). Whether the surveys collide server-side is not determinable from the code.

---

## 5. CONFIG (`playwright.config.ts`)

```ts
export default defineConfig({
  testDir: './tests',
  globalSetup: require.resolve('./helpers/global-setup.ts'),
  globalTeardown: require.resolve('./playwright/setup/globalTeardown.ts'),
  outputDir: './test-results',
  timeout: 300 * 1000,

  use: {
    baseURL: normalizedBaseURL,
    storageState: 'storage/auth.json',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'on',
    headless: process.env.HEADLESS !== 'false',
  },

  fullyParallel: false,
  retries: process.env.CI ? 2 : 0,
  // LambdaTest runs should be minimal workers to avoid session conflicts
  workers: isLambdaTest ? ltWorkers : process.env.CI ? 1 : 2,
```

| Setting | Value |
|---|---|
| retries | `process.env.CI ? 2 : 0` (0 locally, 2 on CI) |
| workers | LambdaTest: `ltWorkers` (`SM_LT_WORKERS`, default 1); else CI: 1; else local: 2 |
| timeout (per test) | 300 * 1000 = 300,000 ms. TC_AI_05 overrides with `test.setTimeout(240_000)` |
| expect timeout | NOT set. No `expect: { timeout }` key in the config, so the Playwright default of 5,000 ms applies |
| fullyParallel | false |
| projects (non-LambdaTest) | `chromium` (Desktop Chrome, channel `chrome`) and `Microsoft Edge` (Desktop Edge, channel `msedge`) |

Note: with `retries: 0` locally and `describe.serial`, one failure skips the rest of that spec file. With 2 CI retries, a failed serial test re-runs the whole describe from the start in a new worker.
The project list has two browsers, so each spec file runs once per project.

---

## 6. BATCH 2: Customize Questions number field and slider

Result: **not present.**

- `locators\survey\start-with-prompt.locator.json` has no entry for a number field, spinbutton, slider, range, or question-count control.
  Its elements are: `startWithPrompt`, `datasetTypeSelector`, `omnishopperOfferingTile`, `nextDatasetButton`, `datasetSearchToggle`, `datasetSearchInput`,
  `datasetByText`, `dialogElement`, `applyButton`, `chooseDatasetBreadcrumb`, `chooseDataviewBreadcrumb`, `defaultDataset`, `promptTextarea`, `generateSurveyButton`,
  `questionTypeOption`, `generateQuestionsButton`, `questionNumberMarker`, `questionRow`, `rephraseWithAiButton`, `rephraseInput`, `rephraseSendButton`,
  `suggestNewQuestionsButton`, `repromptNewQuestionsButton`, `repromptInput`, `repromptSubmitButton`, `optiqHeading`.
- `page-objects\survey\start-with-prompt.page.ts` has no method for a number field or slider. On the Customize Questions screen it only has the question-type tiles
  (`selectQuestionType`, `isQuestionTypeSelected`) and `clickGenerateQuestions`.
- A grep for `slider`, `number field`, `spinbutton`, `numberOfQuestions`, `range`, `type=`, `amount`, and `quantity` in `page-objects\` and `locators\` found no matches.

The closest existing code (tile selection and Generate questions):

```json
    { "elementName": "questionTypeOption", "selectorType": "css", "selectorValue": "[data-test-id='question-type-${text}']" },
    { "elementName": "generateQuestionsButton", "selectorType": "css", "selectorValue": "[data-test-id='generate-questions']" },
```

```ts
  async clickGenerateQuestions(): Promise<void> {
    try {
      const generateButton = this.webActionHandler.getWebElement(this.getResource('generateQuestionsButton'));
      await this.waitUntilVisible(generateButton, 'Generate questions button');
      await generateButton.click();
    } catch (error) {
      throw new Error(`Failed to click Generate questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Question type tile on the Customize Questions screen, identified by its QuestionType value (e.g. 'SINGLE_CHOICE'). */
  async selectQuestionType(value: string): Promise<void> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(tile, `Question type tile (${value})`);
      await tile.click();
    } catch (error) {
      throw new Error(`Failed to select question type "${value}": ${error instanceof Error ? error.message : error}`);
    }
  }
```
