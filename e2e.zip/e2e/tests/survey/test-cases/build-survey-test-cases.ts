import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { SurveyBuilderPage } from '../../../page-objects/common/survey-builder.page';
import { SelectPanelistPage } from '../../../page-objects/common/select-panelist.page';
import { assertTrue } from '../../../page-objects/common/assert-utils';
import testData from '../../../test-data/dev-test-data.json';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

export interface BuildSurveyTestContext {
  getBasePage: () => BasePage;
}

export interface BuildSurveyTestOptions {
  title?: string;
  tag?: string;
}

export function registerEditSurveyTitleTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_AI_07: Edit the survey title after AI generation', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.setSurveyTitle(testData.surveyQuestions.surveyTitle);
    await surveyBuilderPage.commitSurveyTitle();
    const titleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
    assertTrue(titleDisplay === testData.surveyQuestions.surveyTitle, `Expected survey title to update to "${testData.surveyQuestions.surveyTitle}", got "${titleDisplay}"`);
  });
}

export function registerRequiredStarTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_07: Required star appears when the Required toggle is on', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const index = 0;

    await surveyBuilderPage.setRequired(index, true);
    assertTrue(await surveyBuilderPage.waitForRequiredState(index, true), 'Expected Required star visible after turning Required on');

    await surveyBuilderPage.setRequired(index, false);
    assertTrue(await surveyBuilderPage.waitForRequiredState(index, false), 'Expected Required star hidden after turning Required off');

    await surveyBuilderPage.setRequired(index, true);
    assertTrue(await surveyBuilderPage.waitForRequiredState(index, true), 'Expected Required star visible again after turning Required back on');
  });
}

export function registerEditQuestionTextTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'Edit question: Should update the question text via the pencil icon', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const { questionText: newText } = testData.surveyQuestions.nps;

    await surveyBuilderPage.editQuestionText(0, newText);

    const textDisplay = await surveyBuilderPage.getQuestionTextDisplay(0);
    assertTrue(textDisplay.includes(newText), `Expected question text to update to "${newText}", got "${textDisplay}"`);
  });
}

export function registerDeleteDuplicateQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_06: Delete and duplicate a question via hover row actions', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    const countBeforeDelete = await surveyBuilderPage.getQuestionCount();
    await surveyBuilderPage.deleteQuestionAt(0);
    const countAfterDelete = await surveyBuilderPage.getQuestionCount();
    assertTrue(countAfterDelete === countBeforeDelete - 1, `Expected count ${countBeforeDelete - 1} after delete, got ${countAfterDelete}`);
    assertTrue(countAfterDelete < 10, 'duplicate is disabled at 10 questions');

    const numbersAfterDelete = await surveyBuilderPage.getQuestionNumbers();
    assertTrue(
      numbersAfterDelete.every((number, idx) => number.trim() === `${idx + 1}.`),
      'Expected remaining questions to be renumbered sequentially after delete'
    );

    const originalText = await surveyBuilderPage.getQuestionTextDisplay(0);
    // getQuestionTextDisplay() randomly drops spaces between reads - compare whitespace-insensitively.
    const normalize = (text: string) => text.replace(/\s+/g, '');
    await surveyBuilderPage.duplicateQuestionAt(0);
    const countAfterDuplicate = await surveyBuilderPage.getQuestionCount();
    assertTrue(countAfterDuplicate === countAfterDelete + 1, `Expected count ${countAfterDelete + 1} after duplicate, got ${countAfterDuplicate}`);
    const fullTextsAfter = await Promise.all(
      Array.from({ length: countAfterDuplicate }, (_, i) => surveyBuilderPage.getQuestionTextDisplay(i))
    );

    const numbersAfterDuplicate = await surveyBuilderPage.getQuestionNumbers();
    assertTrue(
      numbersAfterDuplicate.every((number, idx) => number.trim() === `${idx + 1}.`),
      'Expected questions to be renumbered sequentially after duplicate'
    );

    const copyIndexes = fullTextsAfter.reduce<number[]>((acc, text, idx) => (normalize(text) === normalize(originalText) ? [...acc, idx] : acc), []);
    assertTrue(
      copyIndexes.length === 2,
      `Expected exactly 2 questions matching original text "${normalize(originalText).slice(0, 80)}", found ${copyIndexes.length} (indexes: ${copyIndexes})`
    );
  });
}

export function registerDragDropTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_15: Drag and drop reorders questions', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    // getQuestionTextDisplay() randomly drops spaces between reads, and Required toggles append a trailing " *"; normalize both away before comparing.
    const normalize = (text: string) => text.replace(/\s+/g, '').replace(/\*$/, '');

    const textBefore0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textBefore1 = await surveyBuilderPage.getQuestionTextDisplay(1);

    await surveyBuilderPage.dragQuestionRow(0, 1);

    const textAfter0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textAfter1 = await surveyBuilderPage.getQuestionTextDisplay(1);
    assertTrue(
      normalize(textAfter0) === normalize(textBefore1) && normalize(textAfter1) === normalize(textBefore0),
      `Expected questions 0/1 to swap (before: ["${textBefore0}", "${textBefore1}"], after: ["${textAfter0}", "${textAfter1}"])`
    );
  });
}

export function registerCancelAddQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_05: Cancelling Add Question leaves the question count unchanged', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
    if (addQuestionState.disabled) {
      await surveyBuilderPage.deleteQuestionAt(0);
    }

    const countBefore = await surveyBuilderPage.getQuestionCount();
    await surveyBuilderPage.clickAddQuestion();
    await surveyBuilderPage.clickQuestionTypeTile('questionTypeRating');
    await surveyBuilderPage.clickAddQuestion();

    const countAfter = await surveyBuilderPage.getQuestionCount();
    assertTrue(countAfter === countBefore, `Expected question count unchanged after cancel (before ${countBefore}, after ${countAfter})`);
  });
}

export function registerReviewModeTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_13/TC_BS_14a: Review Mode controls, delete selected, exit', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.ensureQuestionCount(3);
    await surveyBuilderPage.enterReviewMode();

    const controlsVisible = await surveyBuilderPage.areReviewControlsVisible();
    assertTrue(controlsVisible, 'Expected Select All, Expand All, Collapse All, Delete, Exit Review Mode buttons to be visible');

    const questionCount = await surveyBuilderPage.getQuestionCount();
    const checkboxCount = await surveyBuilderPage.getReviewCheckboxCount(questionCount);
    assertTrue(checkboxCount === questionCount, `Expected one checkbox per question (${questionCount}), found ${checkboxCount}`);

    await surveyBuilderPage.selectAll();
    for (let index = 0; index < questionCount; index++) {
      assertTrue(await surveyBuilderPage.isQuestionSelected(index), `Expected checkbox ${index} to be ticked after Select All`);
    }
    await surveyBuilderPage.unselectAll();
    for (let index = 0; index < questionCount; index++) {
      assertTrue(!(await surveyBuilderPage.isQuestionSelected(index)), `Expected checkbox ${index} to clear after Unselect All`);
    }

    await surveyBuilderPage.expandAll();
    await surveyBuilderPage.collapseAll();
    await surveyBuilderPage.exitReviewMode();

    await surveyBuilderPage.enterReviewMode();
    const questionCountBeforeDelete = await surveyBuilderPage.getQuestionCount();
    await surveyBuilderPage.selectQuestionInReview(0);
    await surveyBuilderPage.deleteSelectedQuestions();

    const questionCountAfterDelete = await surveyBuilderPage.getQuestionCount();
    assertTrue(
      questionCountAfterDelete === questionCountBeforeDelete - 1,
      `Expected ${questionCountBeforeDelete - 1} questions after deleting one, found ${questionCountAfterDelete}`
    );
    assertTrue(questionCountAfterDelete >= 3, `Expected at least 3 questions to remain for publish (3..10 range), found ${questionCountAfterDelete}`);

    await surveyBuilderPage.exitReviewMode();
    const questionCountAfterExit = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCountAfterExit === questionCountAfterDelete, 'Expected Build Survey view to keep the deletion after exiting Review Mode');
  });
}

export function registerReviewModeDeleteAllTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_14b: Review Mode select all, delete, stay on Build Survey', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.enterReviewMode();
    await surveyBuilderPage.selectAll();
    await surveyBuilderPage.deleteSelectedQuestions();

    const questionCountAfterDelete = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCountAfterDelete === 0, `Expected 0 questions after deleting all, found ${questionCountAfterDelete}`);

    // Deleting ALL questions auto-closes Review Mode; only exit if it's still open.
    const exitButton = await surveyBuilderPage.isExitReviewModeButtonHidden();
    if (!exitButton) {
      await surveyBuilderPage.exitReviewMode();
    }

    const currentUrl = await surveyBuilderPage.getCurrentUrl();
    assertTrue(currentUrl.includes('build-survey'), `Expected to stay on Build Survey after delete-all, url: ${currentUrl}`);
    assertTrue(await surveyBuilderPage.areAddQuestionOptionsVisible(), 'Expected Add Question options visible in the empty Build Survey state');
  });
}

export function registerEmptyStateTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_01: Empty Build Survey state shows Add Question options and 0 rows', { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    const questionCount = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCount === 0, `Expected 0 question rows in the empty state, found ${questionCount}`);
    assertTrue(await surveyBuilderPage.areAddQuestionOptionsVisible(), 'Expected Add Question options visible in the empty Build Survey state');
  });
}

export function registerAddSingleChoiceQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03: Add a Single Choice question', { tag: options?.tag ?? '@SingleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const { questionText, options: choiceOptions } = testData.surveyQuestions.singleChoice;

    await surveyBuilderPage.addSingleChoiceQuestion(questionText, choiceOptions);
  });
}

export function registerAddMultipleChoiceQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_04: Add a Multiple Choice question', { tag: options?.tag ?? '@MultipleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, options: choiceOptions } = testData.surveyQuestions.multipleChoice;

    await surveyBuilderPage.addMultipleChoiceQuestion(questionText, choiceOptions);
  });
}

export function registerAddRatingQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_05: Add a Rating question', { tag: options?.tag ?? '@RatingQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = testData.surveyQuestions.rating;

    await surveyBuilderPage.addRatingQuestion(questionText);
  });
}

export function registerAddNPSQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_07: Add an NPS question', { tag: options?.tag ?? '@NPSQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = testData.surveyQuestions.nps;

    await surveyBuilderPage.addNPSQuestion(questionText);
  });
}

export function registerAddPointScaleQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_08: Add a Point Scale question', { tag: options?.tag ?? '@PointScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = testData.surveyQuestions.pointScale;

    await surveyBuilderPage.addPointScaleQuestion(questionText, rows, columns);
  });
}

export function registerAddMultiScaleQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_09: Add a Multi Scale question', { tag: options?.tag ?? '@MultiScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = testData.surveyQuestions.multiScale;

    await surveyBuilderPage.addMultiScaleQuestion(questionText, rows, columns);
  });
}

export interface StepperNavigationTestOptions extends BuildSurveyTestOptions {
  responseCountTestId?: string;
}

export function registerStepperNavigationTest(ctx: BuildSurveyTestContext, options?: StepperNavigationTestOptions): void {
  test(options?.title ?? 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey', { tag: options?.tag ?? '@StepperNavigation' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
    const EXPECTED_RESPONSE_COUNT_TEST_ID = options?.responseCountTestId ?? 'select-response-count-250'; // Setup used click250Responses()

    try {
      await surveyBuilderPage.clickAddQuestion();
      const { questionText } = testData.surveyQuestions.rating;
      await surveyBuilderPage.addRatingQuestion(questionText);
      const questionNumbersBefore = await surveyBuilderPage.getQuestionNumbers();

      await surveyBuilderPage.clickSelectPanelistsStep();

      assertTrue(
        await selectPanelistPage.isProceedToSurveyBuilderVisible(),
        'proceed-to-survey visible after stepper navigation'
      );
      const currentUrl = await selectPanelistPage.getCurrentUrl();
      assertTrue(currentUrl.includes('select-panelist'), `URL contains select-panelist (got ${currentUrl})`);

      const selectedResponseCountTestId = await selectPanelistPage.getSelectedResponseCountDataTestId();
      assertTrue(
        selectedResponseCountTestId === EXPECTED_RESPONSE_COUNT_TEST_ID,
        `response count retained (expected ${EXPECTED_RESPONSE_COUNT_TEST_ID}, got ${selectedResponseCountTestId})`
      );
      for (const selection of datasetConfig.dimensionSelections) {
        assertTrue(
          await selectPanelistPage.isDimensionSelectionRetained(selection.dimensionTab, selection.items),
          `${selection.dimensionTab} selection retained after stepper navigation (expected to contain ${selection.items.join(', ')})`
        );
      }

      await selectPanelistPage.clickProceedToSurveyBuilder();
      assertTrue(
        await selectPanelistPage.isBuildSurveyPageLoaded(),
        'Build Survey page visible after Proceed'
      );

      const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(
        questionNumbersAfter.length === questionNumbersBefore.length,
        `question count retained (expected ${questionNumbersBefore.length}, got ${questionNumbersAfter.length})`
      );
    } catch (error) {
      throw new Error(`Failed to verify stepper navigation retains data: ${error instanceof Error ? error.message : error}`);
    }
  });
}
