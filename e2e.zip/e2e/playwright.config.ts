import { defineConfig, devices } from '@playwright/test';
import * as dotenv from 'dotenv';
import * as path from 'path';
import { envConfig } from './config/env.config';
import { getLambdaTestBuildName } from './utils/configurationDetails';

dotenv.config({ path: path.resolve(__dirname, '.env') });

const baseURL = envConfig.BASE_URL;
const normalizedBaseURL = baseURL.endsWith('/') ? baseURL : `${baseURL}/`;

const isLambdaTest = process.env.LAMBDATEST === 'true';
// LambdaTest environment variables (all inert/unused unless LAMBDATEST=true)
const ltUser = process.env.SM_LAMBDATEST_USERNAME || process.env.SM_LT_USERNAME;
const ltAccessKey = process.env.SM_LAMBDATEST_ACCESS_KEY || process.env.SM_LT_ACCESS_KEY;
const ltProject = process.env.SM_LT_PROJECT || 'OMNI Discover';
const ltBuild = process.env.SM_LT_BUILD || 'Discover build';
const ltBuildIdentifier =
  process.env.SM_LT_BUILD_IDENTIFIER ||
  process.env.BUILD_NUMBER ||
  process.env.GITHUB_RUN_NUMBER ||
  undefined;

const ltVideo = process.env.SM_LT_VIDEO ? process.env.SM_LT_VIDEO === 'true' : true;
const ltNetwork = process.env.SM_LT_NETWORK ? process.env.SM_LT_NETWORK === 'true' : false;
const ltConsole = process.env.SM_LT_CONSOLE ? process.env.SM_LT_CONSOLE === 'true' : false;

const ltIdleTimeout = process.env.SM_LT_IDLE_TIMEOUT ? Number(process.env.SM_LT_IDLE_TIMEOUT) : 300;

const ltWorkers = process.env.SM_LT_WORKERS ? Number(process.env.SM_LT_WORKERS) : 1;

console.log('isLambdaTest =', isLambdaTest);

if (isLambdaTest) {
  console.log('\n🌐 LambdaTest Cloud Execution Enabled');
  console.log('   Credentials:', ltUser && ltAccessKey ? 'configured' : 'missing');
  console.log('   Project:', ltProject);
  console.log('   Workers:', ltWorkers);

  if (!ltUser || !ltAccessKey) {
    throw new Error(
      'LambdaTest credentials missing! Please set SM_LAMBDATEST_USERNAME/SM_LT_USERNAME and SM_LAMBDATEST_ACCESS_KEY/SM_LT_ACCESS_KEY'
    );
  }
}

export default defineConfig({
  testDir: './tests',
  globalSetup: require.resolve('./helpers/global-setup.ts'),
  globalTeardown: require.resolve('./playwright/setup/globalTeardown.ts'),
  outputDir: './test-results',
  timeout: 300 * 1000,

  use: {
    baseURL: normalizedBaseURL,
    storageState: 'storage/auth.json',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    headless: process.env.HEADLESS !== 'false',
  },

  fullyParallel: false,
  retries: process.env.CI ? 2 : 0,
  // LambdaTest runs should be minimal workers to avoid session conflicts
  workers: isLambdaTest ? ltWorkers : process.env.CI ? 1 : 2,

  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['allure-playwright', { outputFolder: 'allure-results' }],
    ...(isLambdaTest ? [['./playwright/reporters/lt-session-reporter.ts'] as const] : []),
  ],

  projects: isLambdaTest
    ? [
        {
          name: 'lambdatest-chromium',
          use: {
            browserName: 'chromium' as const,
            headless: true,
            viewport: { width: 1920, height: 1080 },
            baseURL: normalizedBaseURL,

            connectOptions: {
              wsEndpoint: `wss://cdp.lambdatest.com/playwright?capabilities=${encodeURIComponent(
                JSON.stringify({
                  browserName: 'pw-chromium',
                  browserVersion: 'latest',

                  'LT:Options': {
                    platform: 'Windows 11',

                    // Build name should include identifier so you can track correctly
                    build: getLambdaTestBuildName(ltBuild, ltBuildIdentifier),

                    name: 'Playwright Automation',

                    user: ltUser,
                    accessKey: ltAccessKey,

                    project: ltProject,

                    network: ltNetwork,
                    video: ltVideo,
                    console: ltConsole,

                    plugin: 'playwright-test',
                    w3c: true,
                    idleTimeout: ltIdleTimeout,
                  },
                })
              )}`,
            },
          },
        },
      ]
    : [
        {
          name: 'chromium',
          use: { ...devices['Desktop Chrome'], channel: 'chrome' },
        },
        {
          name: 'Microsoft Edge',
          use: { ...devices['Desktop Edge'], channel: 'msedge' },
        },
      ],
});