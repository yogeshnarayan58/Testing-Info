import { BasePage, WebActions } from '@gfk/gta';
import { ResourceManager } from '../../utils/resource-manager';
import { ELEMENT_WAIT_TIMEOUT, NAVIGATION_TIMEOUT } from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';

export abstract class CommonPage {
  protected webActionHandler: WebActions;
  protected resourceManager: ResourceManager;
  protected abstract readonly componentName: string;

  constructor(protected basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
  }

  protected getResource(name: string) {
    return this.resourceManager.getResource(name, this.componentName);
  }

  protected async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  protected async clickWhenVisible(resourceName: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.click();
  }

  protected async fillWhenVisible(
    resourceName: string,
    text: string,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.enterText(text);
  }

  protected async isVisibleAfterOneReload(resourceName: string): Promise<boolean> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    if (await element.isVisible(ELEMENT_WAIT_TIMEOUT)) {
      return true;
    }
    const nativePage = (BasePage as any).page as import('playwright').Page; // load-state wait and reload are not exposed by the GTA wrapper
    await nativePage.waitForLoadState('networkidle', { timeout: NAVIGATION_TIMEOUT }).catch(() => undefined);
    await nativePage.reload({ waitUntil: 'domcontentloaded', timeout: NAVIGATION_TIMEOUT });
    return await element.isVisible(ELEMENT_WAIT_TIMEOUT);
  }

  public async getCurrentUrl(): Promise<string> {
    try {
      return await this.webActionHandler.getPageUrl();
    } catch (error) {
      throw new Error(`Failed to get current URL: ${error instanceof Error ? error.message : error}`);
    }
  }

  public async navigateToUrl(targetUrl: string, timeout: number = NAVIGATION_TIMEOUT): Promise<void> {
    try {
      await this.webActionHandler.navigateTo(targetUrl, timeout, 'domcontentloaded');
    } catch (navigationError) {
      console.error(`Navigation to URL failed: ${targetUrl}`, navigationError);
      throw navigationError;
    }
  }

  public buildUrl(baseURL: string, relativePath: string): string {
    const normalizedBaseURL = baseURL.endsWith('/') ? baseURL : `${baseURL}/`;
    return new URL(relativePath, normalizedBaseURL).toString();
  }

  public async navigateToSurvey(): Promise<void> {
    const surveyURL = this.buildUrl(envConfig.BASE_URL, 'survey');
    await this.navigateToUrl(surveyURL);
  }
}
