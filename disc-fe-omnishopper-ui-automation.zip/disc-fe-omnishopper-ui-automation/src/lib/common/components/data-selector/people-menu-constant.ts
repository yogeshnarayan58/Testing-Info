import { PeopleMenuType } from "../../models/data-selector-model";

// IMPORTANT NOTE:
// Please do not use "displayText" in automation script for text comparing
// because the display text varies for each localization which gets translated in UI
// and also it is not required for our automation scripts.

export const PeopleMenu: PeopleMenuType = {
  // Main menu selectorTexts
  BOUGHT: {
    selectorText: "Bought",
    displayText: "Bought",
    tooltipText: "Analyze people that bought specific products"
  },
  SHOPPED_AT: {
    selectorText: "Shopped at",
    displayText: "Shopped at",
    tooltipText: "Analyze people that shopped specific retailers"
  },
  CONVERSION: {
    selectorText: "Conversion",
    displayText: "Conversion",
    tooltipText: "Analyze people that shopped a specific retailer and purchased a specific product but may or may not have purchased the product within the specific retailer"
  },
  CONTRIBUTION: {
    selectorText: "Contribution",
    displayText: "Contribution",
    tooltipText: "Analyze purchasing or shopping within a specific retailer by % volumetrics among user defined heavy/medium/light groups"
  },
  QUANTITY: {
    selectorText: "Quantity",
    displayText: "Quantity",
    tooltipText: "Analyze people that purchased a specific product or shopped a specific retailer within a custom defined range"
  },
  FREQUENCY: {
    selectorText: "Frequency",
    displayText: "Frequency",
    tooltipText: "Analyze people within a custom defined trip/occasion range"
  },
  LOYAL: {
    selectorText: "Loyal",
    displayText: "Loyal",
    tooltipText: "Analyze people that purchased a specific product in a specific retailer within a custom defined Loyalty range"
  },
  DEAL: {
    selectorText: "Deal",
    displayText: "Deal",
    tooltipText: "Analyze people that purchased a specific product or shopped in a specific retailer within a user defined deal range"
  },

  // Sub menu selectorTexts for Bought
  BOUGHT_SUB: {
    selectorText: "Bought",
    displayText: "Bought",
    tooltipText: "Analyze people that purchased a specific product"
  },
  BOUGHT_EACH_OF: {
    selectorText: "Bought each of",
    displayText: "Bought each of",
    tooltipText: "Analyze people that purchased both of 2 specific products"
  },
  BOUGHT_EITHER_OF: {
    selectorText: "Bought either of",
    displayText: "Bought either of",
    tooltipText: "Analyze people that purchased either of 2 specific products"
  },

  // Sub menu selectorTexts for Shopped at
  SHOPPED_AT_SUB: {
    selectorText: "Shopped at",
    displayText: "Shopped at",
    tooltipText: "Analyze people that shopped a specific retailer"
  },
  SHOPPED_AT_EACH_OF: {
    selectorText: "Shopped at each of",
    displayText: "Shopped at each of",
    tooltipText: "Analyze people that shopped both of 2 specific retailers"
  },
  SHOPPED_AT_EITHER_OF: {
    selectorText: "Shopped at either of",
    displayText: "Shopped at either of",
    tooltipText: "Analyze people that shopped either of 2 specific retailers"
  },

  // Sub menu selectorTexts for Conversion
  CONVERTED_SHOPPERS: {
    selectorText: "Bought from Retailer",
    displayText: "Converted shoppers",
    tooltipText: "Analyze people that purchased a specific product within a specific retailer"
  },
  NON_CONVERTED_SHOPPERS: {
    selectorText: "Non converted shoppers",
    displayText: "Non-converted shoppers",
    tooltipText: "Analyze people that shopped a specific retailer and purchased a specific product elsewhere but never purchased the product within the specified retailer"
  },

  // Sub menu selectorTexts for Contribution
  BOUGHT_A_CONTRIBUTION: {
    selectorText: "Bought a contribution",
    displayText: "Bought a contribution",
    tooltipText: "Analyze people purchasing a specific product by % buyers or % volume among user defined heavy, medium and light groups"
  },
  SHOPPED_A_CONTRIBUTION: {
    selectorText: "Shopped a contribution",
    displayText: "Shopped a contribution",
    tooltipText: "Analyze people shopping a specific retailer by % shoppers or % trip volume among user defined heavy, medium and light groups"
  },

  // Sub menu selectorTexts for Quantity
  AVERAGE_PRODUCT_AMOUNT_PER_BUYER: {
    selectorText: "Bought a quantity",
    displayText: "Average product amount per buyer",
    tooltipText: "Analyze people that purchased a specific product in a specific retailer within a custom defined volumetric range"
  },
  AVERAGE_PRODUCT_AMOUNT_PER_OCCASION: {
    selectorText: "Average product amount per occasion",
    displayText: "Average product amount per occasion",
    tooltipText: "Analyze people that on average, purchased a specified amount of a product per occasion at the retailer"
  },
  AVERAGE_BASKET_AMOUNT_PER_SHOPPER: {
    selectorText: "Shopped a quantity",
    displayText: "Average basket amount per shopper",
    tooltipText: "Analyze people that shopped a specific retailer within a custom defined volumetric range"
  },
  AVERAGE_BASKET_AMOUNT_PER_TRIP: {
    selectorText: "Average basket amount per trip",
    displayText: "Average basket amount per trip",
    tooltipText: "Analyze people that on average, spent a specified amount at the retailer per trip"
  },

  // Sub menu selectorTexts for Frequency
  BOUGHT_WITH_A_FREQUENCY: {
    selectorText: "Frequency Buyer",
    displayText: "Bought with a Frequency",
    tooltipText: "Analyze people that purchased a specific product in a specific retailer within a custom defined occasion range"
  },
  SHOPPED_WITH_A_FREQUENCY: {
    selectorText: "Frequency Shopper",
    displayText: "Shopped with a Frequency",
    tooltipText: "Analyze people that shopped a specific retailer within a custom defined trip range"
  },

  // Sub menu selectorTexts for Loyal
  LOYAL_PRODUCT_BUYERS: {
    selectorText: "Loyal Product Buyers",
    displayText: "Product Buyers",
    tooltipText: "Analyze people that purchased a specific product in a specific retailer within a custom defined Loyalty range"
  },
  LOYAL_RETAILER_BUYERS: {
    selectorText: "Loyalty Retailer Buyers",
    displayText: "Retail Buyers",
    tooltipText: "Analyze people that purchased a specific product in a specific retailer within a custom defined Loyalty range"
  },
  LOYAL_RETAILER_SHOPPERS: {
    selectorText: "Loyalty Retailer Shoppers",
    displayText: "Retail Shoppers",
    tooltipText: "Analyze people that shopped in a specific retailer within a custom defined Loyalty range"
  },

  // Sub menu selectorTexts for Deal
  DEAL_BUYERS: {
    selectorText: "Deal Buyer",
    displayText: "Deal Buyers",
    tooltipText: "Analyze people that purchased a specific product within a specific retailer by a user defined deal range"
  }
}