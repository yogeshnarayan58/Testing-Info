import test from "@playwright/test";
import {
  findDataSetByName,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json"
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Geography";

test.describe("Buyer turnover Geography", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });
  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);

      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      // Open additional prompts to ensure madlib is visible
      await dataSelector.clickAdditionalPromptEllipsisIcon();

      // Validate using pattern matching with detailed results
      if (localeData.pivotMadlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).geography;

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(
          new RegExp(expectedMadlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.switchPivotDropdown(pivot);

          // Get Geography pivot data
          const geographyData = getDimensionSelectionsByPivot(pivot, reportTestData);

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            geographyData["Period"]
          );
          console.log("period selected");
          await dataSelector.clickMadlibDimension("Comparison Period");
          await dataSelector.setPeriodMadlibSelection(
            geographyData["Comparison Period"]
          );

          await dataSelector.clickMadlibDimension("Category");
          await dataSelector.setMadlibSelection(
            geographyData["Category"]
          );

          await dataSelector.clickMadlibDimension("Retailer");
          await dataSelector.setMadlibSelection(
            geographyData["Retailer"]
          );
          console.log("Retailers selected");

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            geographyData["Geographies"]
          );
          await dataSelector.waitForMadlibStability();
          await dataSelector.clickMadlibDimension("Product");
          await dataSelector.setMadlibSelection(
            geographyData["Product"]
          );
          await dataSelector.clickAdditionalPromptEllipsisIcon();


          await dataSelector.clickMadlibDimension("Demography");
          await dataSelector.setMadlibSelection(
            geographyData["Demography"]
          );

          await dataSelector.clickMadlibDimension("Facts");
          /* await dataSelector.assertFactsDropdown(
            reportAssertData["dataSummary"]["facts"]["factList"]
          ); */
          await dataSelector.selectClosedDropdown(
            geographyData["Facts"]["selections"]
          );
          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } = await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );
      test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
        test.skip(
          !savedReportTitle,
          "Skipping FMS test - Report not generated. Run with @RunReport first"
        );

        const basePage = await BasePageFactory.createBasePage();
        const findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
    }
  );
});

