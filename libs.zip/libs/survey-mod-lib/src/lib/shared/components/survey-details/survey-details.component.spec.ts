import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA, signal, WritableSignal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { readFileSync } from 'node:fs';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { SurveyDetailsComponent } from './survey-details.component';

vi.mock('@nielsen/crf-data-summary', () => ({ CrfDataSummaryModule: class {} }));

const template = readFileSync('libs/survey-mod-lib/src/lib/shared/components/survey-details/survey-details.component.html', 'utf8');

// Vitest runs JIT without Angular's signal-input metadata transform.
function setInput(fixture: ComponentFixture<SurveyDetailsComponent>, name: string, value: unknown) {
  const current = (fixture.componentInstance as unknown as Record<string, WritableSignal<unknown>>)[name];
  if (typeof current?.set === 'function') {
    current.set(value);
  } else {
    Object.defineProperty(fixture.componentInstance, name, { value: signal(value), configurable: true });
  }
  fixture.changeDetectorRef.markForCheck();
}

function createFixture() {
  const fixture = TestBed.configureTestingModule({ imports: [TranslateModule.forRoot()] })
    .overrideComponent(SurveyDetailsComponent, { set: {
      imports: [CommonModule, TranslateModule], schemas: [NO_ERRORS_SCHEMA],
      template, templateUrl: undefined, styleUrl: undefined,
    } })
    .createComponent(SurveyDetailsComponent);
  const translate = TestBed.inject(TranslateService);
  translate.setTranslation('en', {
    SURVEYMOD_STATUS_PUBLISHED: 'Published', SURVEYMOD_STATUS_CLOSED: 'Closed',
    SURVEYMOD_EXPECTED_RESPONSE: 'expected responses',
    SURVEYMOD_TARGET_AUDIENCE: 'Target audience', SURVEYMOD_QUESTIONNAIRE: 'Questionnaire',
    SURVEYMOD_SURVEY_SAMPLE: 'Survey sample',
    SURVEYMOD_QUESTIONS: 'Questions', SURVEYMOD_QUESTION: 'Question',
    SURVEYMOD_QUESTIONS_TITLE: 'questions', SURVEYMOD_CREDITS_CHARGED: 'Credits charged',
    SURVEYMOD_CREDITS_REMAINING: 'Credits remaining', SURVEYMOD_CREDITS_TITLE: 'credits',
    SURVEYMOD_NOT_AVAILABLE: 'Not available',
    SURVEYMOD_ESTIMATED_FIELDING_TIME: 'Estimated fielding time',
    SURVEYMOD_BUSINESS_DAYS: 'business days',
    SURVEYMOD_ESTIMATED_FIELDING_TIME_DESC: 'Surveys will field for up to 10 days.',
  });
  translate.use('en');
  setInput(fixture, 'variant', 'publish');
  setInput(fixture, 'title', 'BrushLab Marketing Survey');
  setInput(fixture, 'questionCount', 10);
  setInput(fixture, 'responseCount', 580);
  return fixture;
}

describe('SurveyDetailsComponent', () => {
  afterEach(() => TestBed.resetTestingModule());

  it('renders publish details without dates and updates values through inputs', () => {
    const fixture = createFixture();
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelector('h3')?.textContent).toBe('BrushLab Marketing Survey');
    expect(element.querySelector('.survey-meta')).toBeNull();
    expect(element.textContent).toContain('Target audience');
    expect(element.querySelector('[data-test-id="publish-response-count"]')?.textContent).toContain('expected responses');
    expect(element.textContent).not.toContain('SURVEYMOD_');
    expect(element.querySelector('[data-test-id="publish-fielding-time"]')?.textContent).toContain('3-5 business days');
    expect(element.querySelector('.fielding-time-note')?.textContent).toContain('Surveys will field for up to 10 days.');
    expect(element.querySelector('[data-test-id="publish-response-count"]')?.textContent).toContain('580');
    expect(element.querySelector('[data-test-id="publish-credits-charged"]')?.textContent).toContain('Not available');
    setInput(fixture, 'responseCount', 800);
    setInput(fixture, 'creditsCharged', 0);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="publish-response-count"]')?.textContent).toContain('800');
    expect(element.querySelector('[data-test-id="publish-credits-charged"]')?.textContent?.trim()).toBe('0 credits');
  });

  it('renders overview dates and passes saved panelist selections to the summary', () => {
    const fixture = createFixture();
    const selections = [{ id: 'PRDC' }];
    setInput(fixture, 'variant', 'overview');
    setInput(fixture, 'publishedDate', 'August 8, 2026');
    setInput(fixture, 'closedDate', 'August 18, 2026');
    setInput(fixture, 'panelistSummary', { selections });
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelector('h2')?.textContent).toBe('BrushLab Marketing Survey');
    expect(element.querySelector('.fielding-time-note')).toBeNull();
    expect(element.querySelector('[data-test-id="survey-overview-published-date"]')?.textContent).toContain('August 8, 2026');
    expect(element.querySelector('[data-test-id="survey-overview-closed-date"]')?.textContent).toContain('August 18, 2026');
    expect((element.querySelector('crf-data-summary') as HTMLElement & { selections: unknown }).selections).toEqual(selections);
    expect(element.querySelector('[data-test-id="survey-overview-question-count"]')?.textContent).toContain('10');
  });
});
