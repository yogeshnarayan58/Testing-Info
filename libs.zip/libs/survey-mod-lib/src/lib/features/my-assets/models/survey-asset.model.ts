import { SurveyStatusDisplay } from '../constants/survey-status.constant';
import { SurveyGridActionType } from '../constants/my-assets-tabs.constant';

export interface SurveyAccessRight {
  userId?: string;
  availability?: string;
  displayName?: string;
  userInfo?: {
    displayName?: string;
    name?: {
      givenName?: string;
      familyName?: string;
    };
  };
  orderManagementId?: string;
  orderManagementType?: string;
  orderManagementInfo?: {
    id?: string;
    type?: string;
    displayName?: string;
  };
}

export interface SurveyParentAsset {
  assetId: string;
  title?: string;
  parentAsset?: SurveyParentAsset;
}

export interface SurveyGridAsset {
  assetId: string;
  assetType: string;
  title: string;
  launchURL?: string;
  lastModifiedTimestamp: number;
  status?: string;
  folderName?: string;
  sourceId?: string;
  accessLabel?: string;
  isMyFavorite?: boolean;
  responsesCollected?: number;
  responseTarget?: number;
  publishedTimestamp?: number;
  timeLeft?: string;
  creditsUsed?: number;
  initialCreationTimestamp?: number;
  initialCreation?: string;
  creatorId?: string;
  creatorName?: string;
  rights?: SurveyAccessRight[];
  parentAsset?: SurveyParentAsset;
}

export interface AssetCatalogResponse {
  summary?: {
    totalAssets?: number;
  };
  data?: {
    assets?: SurveyGridAsset[];
    summary?: {
      totalAssets?: number;
    };
    properties?: {
      totalAssets?: number;
    };
  };
}

export interface AssetCatalogRequest {
  assets: Array<{ assetType?: string, status?: string }>;
  properties: {
    displayAllRights: boolean;
    fetchDatasetInfo: boolean;
    filterElements: boolean;
    assetElements: boolean;
    userTags: boolean;
    sourceId: boolean;
    timezone: string;
    pageCount: number;
    pageNumber: number;
    dateSortType: string;
    parentAsset?: boolean;
    showImmediateChildren?: boolean;
    startOpenedDate?: string;
    endOpenedDate?: string;
    lastOpenedByMe?: boolean;
    lastAccessedByMe?: boolean;
    restrictFlowChildren?: boolean;
    isFavorite?: boolean;
  };
  filters: Array<{
    typeKey: string;
    exclusions?: Array<{ relationshipType: 'PARENT' } | { availability: string }>;
    relationStatusToBeIgnored?: unknown[];
    elements?: Array<{ availability?: string; id?: string }>;
  }>;
  sort: {
    primarySort: string;
    sortOrder: 'ASC' | 'DESC';
  };
  datasets: unknown[];
}

export interface SurveyGridRow extends SurveyGridAsset {
  statusLabel?: string;
  statusDisplay?: SurveyStatusDisplay;
}

export interface SurveyGridRowUpdate {
  action: SurveyGridActionType;
  row: SurveyGridRow;
}

/**
 * `current-view`: the first block of the current view (initial load, tab/folder/sort change, or Refresh),
 * which the infinite grid always requests from row 0.
 * `pagination`: a later block fetched while scrolling; it does not refresh rows already cached.
 */
export type SurveyGridLoadType = 'current-view' | 'pagination';

export interface SurveyGridRowsLoadedEvent {
  success: boolean;
  loadType: SurveyGridLoadType;
}

export interface CreateFolderRequest {
  assetType: 'DISCOVERFOLDER';
  title: string;
  status: 'OPEN';
  parentAsset?: { assetId: string };
  rights: Array<{
    availability: string;
    orderManagementId: string;
    userId?: string;
  }>;
}

export interface CreateFolderResponse {
  assetId?: string;
  title?: string;
  status?: string;
  assetType?: string;
  [key: string]: unknown;
}