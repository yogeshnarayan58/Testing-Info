﻿import { TranslateModule } from '@ngx-translate/core';
import { DOCUMENT } from '@angular/common';
import { GridTooltipComponent } from './grid-tooltip/grid-tooltip.component';
import { ChangeDetectionStrategy, Component, computed, DestroyRef, inject, input, NgZone, signal } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ClientSideRowModelModule, type ColDef, type GridApi, type GridReadyEvent, type GridSizeChangedEvent, type PostProcessPopupParams } from 'ag-grid-community';
import { MenuModule, SetFilterModule } from 'ag-grid-enterprise';
import type { GridResponse } from '../../models/question-result';
import {
  GRID_BORDER_HEIGHT, GRID_HEADER_HEIGHT, GRID_ROW_HEIGHT,
  GRID_VISIBLE_ROW_LIMIT, HEAT_GRID_LEGEND_STOP_POSITIONS, HEAT_GRID_VISIBLE_ROW_LIMIT,
} from '../../constants/grid.constants';
import { buildGridColumnDefinitions, getGridHeaderRowCount } from '../../utils/grid-columns.util';

@Component({
  selector: 'survey-grid',
  standalone: true,
  imports: [AgGridAngular, TranslateModule],
  templateUrl: './grid.component.html',
  styleUrl: './grid.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GridComponent {
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);
  private readonly zone = inject(NgZone);
  readonly popupParent = this.document.body;
  readonly postProcessPopup = ({ ePopup }: PostProcessPopupParams): void => {
    ePopup.style.zIndex = '1001';
  };
  private renderedGridHeight = 0;
  private readonly gridChromeHeight = signal<number | null>(null);
  readonly response = input.required<GridResponse>();
  readonly isHeatGrid = input(false);
  readonly gridModules = [ClientSideRowModelModule, MenuModule, SetFilterModule];
  readonly gridComponents = { gridTooltip: GridTooltipComponent };
  readonly defaultColDef: ColDef = {
    minWidth: 110,
    tooltipComponent: 'gridTooltip',
    menuTabs: ['generalMenuTab', 'filterMenuTab', 'columnsMenuTab'],
  };
  readonly columnDefinitions = computed(() => buildGridColumnDefinitions(this.response(), this.isHeatGrid()));
  readonly headerRowCount = computed(() => getGridHeaderRowCount(this.response()));
  readonly rowData = computed(() => this.response().objects.data.slice(this.headerRowCount()));
  readonly rowHeight = GRID_ROW_HEIGHT;
  readonly headerHeight = GRID_HEADER_HEIGHT;
  readonly visibleRowLimit = computed(() => this.isHeatGrid() ? HEAT_GRID_VISIBLE_ROW_LIMIT : GRID_VISIBLE_ROW_LIMIT);
  readonly hasScrollableRows = computed(() => this.rowData().length > this.visibleRowLimit());
  readonly gridHeight = computed(() => this.hasScrollableRows() ? this.visibleRowLimit() * this.rowHeight + (this.gridChromeHeight() ?? this.headerRowCount() * this.headerHeight + GRID_BORDER_HEIGHT) : null);

  onGridSizeChanged({ api, clientHeight, clientWidth }: GridSizeChangedEvent): void {
    this.updateGridHeight(api, clientHeight);
    if (!this.isHeatGrid()) return;
    const [first, second] = api.getColumns() ?? [];
    if (!first || !second) return;
    const pinned = clientWidth >= first.getActualWidth() + second.getMinWidth() ? 'left' : null;
    if (first.getPinned() !== pinned) api.setColumnsPinned([first], pinned);
  }

  updateGridHeight(api: GridApi, height = this.renderedGridHeight): void {
    this.renderedGridHeight = height;
    if (!this.hasScrollableRows() || height <= 0) return;
    const { top, bottom } = api.getVerticalPixelRange();
    const viewportHeight = bottom - top;
    if (viewportHeight > 0) this.gridChromeHeight.set(Math.max(0, height - viewportHeight));
  }

  onColumnResized(api: GridApi): void {
    requestAnimationFrame(() => {
      if (!api.isDestroyed()) this.updateGridHeight(api);
    });
  }

  onGridReady({ api }: GridReadyEvent): void {
    const closeMenuOnScroll = (scrollEvent: Event): void => {
      if (!(scrollEvent.target as HTMLElement | null)?.closest?.('.ag-popup')) api.hidePopupMenu();
    };
    this.zone.runOutsideAngular(() => this.document.addEventListener('scroll', closeMenuOnScroll, true));
    this.destroyRef.onDestroy(() => this.document.removeEventListener('scroll', closeMenuOnScroll, true));
  }
  readonly legendGradient = computed(() => {
    const rowProperties = this.response().tableConfig.rowProperties ?? {};
    const hasStyledCells = this.rowData().some(row => Object.values(row).some(cell =>
      cell.cellValue != null && cell.cellValue !== '' && cell.styleId && rowProperties[cell.styleId]?.shade?.color));
    if (!hasStyledCells) return null;
    // The mock rule order runs from low to high, matching the cell palette.
    const legendColors = [...new Set(Object.values(rowProperties).map(rowProperty => rowProperty.shade?.color)
      .filter((color): color is string => !!color))];
    if (legendColors.length === 1) legendColors.push(legendColors[0]);
    const colorStops = legendColors.map((color, index) => {
      const position = legendColors.length === 3
        ? HEAT_GRID_LEGEND_STOP_POSITIONS[index]
        : 15 + index * 85 / (legendColors.length - 1);
      return color + ' ' + position + '%';
    });
    return 'linear-gradient(to right, ' + legendColors[0] + ' 0%, ' + colorStops.join(', ') + ')';
  });
}
