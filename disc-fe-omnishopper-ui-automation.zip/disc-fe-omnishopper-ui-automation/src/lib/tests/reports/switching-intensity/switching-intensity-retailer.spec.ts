import test from "@playwright/test";
import {
  hasPivotInDimensionSelections,
  getDimensionSelectionsByPivot,
  findDataSetByName,
  getTestDataByLocale,
  getDataSummaryByPivot,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import localizationData from "./test-data/localization-data.json";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import assertionData from "./assertion-data/assertion-data.json";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
let reportTestData = findDataSetByName(testData, config.DATASET);
let reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;

const pivot: string = "Retailer";
let savedReportTitle: string = "";
let savedReportUrl: string = "";
test.describe("Switching intensity-Retailer Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  let formatPanel: FormatPanel;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });

  test(
    "Validate the pivot selection",
    {
      tag: "@Pivot List Verification",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.assertPivotDropdown(
        reportAssertData["pivot"]["pivotList"]
      );
    }
  );

  test(
    "Validate People prompt",
    {
      tag: "@PeopleDialog",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);

      await dataSelector.clickAdditionalPromptEllipsisIcon();

      // Get the retailer data
      const retailerPeopleData = getDataSummaryByPivot("Retailer", reportAssertData);
      if (!retailerPeopleData) {
        throw new Error("Pivot not found in assertion dataSummary.");
      }
      await dataSelector.clickMadlibDimension("People");
      await dataSelector.clickMadlibDimension("peopleAddGroupButton");

      await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
      await dataSelector.assertPeopleMenuOptions(
        retailerPeopleData["people"]["menu"]
      );

      await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
      await dataSelector.assertPeopleSubMenuOptions(
        retailerPeopleData["people"]["menu"]
      );

      await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
      await dataSelector.assertPeopleMenuInfoOptions(
        retailerPeopleData["people"]["menu"]
      );

      await dataSelector.peopleDialogClose();
    }
  );
  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.switchPivotDropdown(pivot);
          await dataSelector.clickAdditionalPromptEllipsisIcon();

          // Get Retailer pivot data (second pivot)
          const retailerPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);

          await dataSelector.clickMadlibDimension("Switching Retailer Universe");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Switching Retailer Universe"]
          );

          await dataSelector.clickMadlibDimension("Comparison Retailers");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Comparison Retailers"]
          );

          await dataSelector.clickMadlibDimension("Product");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Product"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            retailerPivotData["Period"]
          );

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Geography"]
          );
          await dataSelector.clickMadlibDimension("Demography");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Demography"]
          );

          await dataSelector.clickMadlibDimension("Shopper Facts People");
          await dataSelector.checkPeopleSelectionGroupExists();
          await dataSelector.clickMadlibDimension("peopleAddGroupButton");
          await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
          await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
          for (const selection of retailerPivotData["Shopper Facts People"].selections) {
          await dataSelector.handlePeopleMenuOptions(selection);
          }

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );
      test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
        test.skip(
          !savedReportTitle,
          "Skipping FMS test - Report not generated. Run with @RunReport first"
        );

        const basePage = await BasePageFactory.createBasePage();
        const findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
      // Appended view and snapshot validations
      test(
        "Validate FullScreen",
        { tag: "@ValidateFullScreen" },
        async () => {
          test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.fullScreenView();
        }
      );

      test(
        "Validate presentationMode",
        { tag: "@PresentationMode" },
        async () => {
          test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.presentationMode();
        }
      );

      test("Validate snapshot", { tag: "@Snapshot" }, async () => {
        test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
        let basePage = await BasePageFactory.createBasePage();
        const commonTC = new CommonTestCase(basePage);
        await commonTC.navigateToReportUrl(savedReportUrl);
        const snapshot = new Snapshot(commonTC.getBasePage());
        await snapshot.waitForReportRunCompletion();
        await snapshot.clickSaveIcon();
        await snapshot.clickSnapshotIcon();
        assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
        await snapshot.shiftingToSnapshot();
      });

      test(
        "Validate PPT export",
        {
          tag: "@ValidatePPTExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
        }
      );

      test(
        "Validate Excel export",
        {
          tag: "@ValidateExcelExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality(
            "Excel",
            "Editable objects",
            "Separately"
          );
        }
      );

      test(
        "Validate Add Blank Report",
        {
          tag: "@ValidateAddBlankReport",
        },
        async () => {
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);

          const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

          let newBasePage = await BasePageFactory.createBasePage();
          let newCommonTestCase = new CommonTestCase(newBasePage);

          await newCommonTestCase.navigateToReportUrl(newUrl);

          let reportFlowPage = new ReportFlowPage(newBasePage);

          await reportFlowPage.clickAddMenuIcon();
          await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);
          await reportFlowPage.validateAddMenuDropdownOptions();
          await reportFlowPage.clickAddBlankReportOption();
          await reportFlowPage.waitForBlankReportIndicator();
          await reportFlowPage.validateBlankReportCreation();
          await reportFlowPage.validateUntitledReportTitle();
          await reportFlowPage.runBlankReport(config.DATASET);

          await reportFlowPage.clickReportByName(newReportTitle);

          const dataSelector = new DataSelector(newBasePage);
          await dataSelector.waitForMadlibStability();
          const madlibText = await dataSelector.getMadlibText();
          assert(madlibText.length).toBeGreaterThan(0);
        }
      );
    }
  );

});