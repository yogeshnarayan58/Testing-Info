import { BasePage, WebActions } from '@gfk/gta';
import { ResourceManager } from '../../utils/resource-manager';
import { NAVIGATION_TIMEOUT } from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';

export class CommonPage {
  protected webActionHandler: WebActions;
  protected resourceManager: ResourceManager;

  constructor(protected basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
  }

  /**
   * Navigates the browser to the specified URL within the given timeout.
   *
   * @param targetUrl - The full URL to navigate to.
   * @param timeout - Optional maximum time to wait for navigation. Defaults to NAVIGATION_TIMEOUT.
   */
  public async navigateToUrl(targetUrl: string, timeout: number = NAVIGATION_TIMEOUT): Promise<void> {
    try {
      await this.webActionHandler.navigateTo(targetUrl, timeout, 'domcontentloaded');
    } catch (navigationError) {
      console.error(`Navigation to URL failed: ${targetUrl}`, navigationError);
      throw navigationError;
    }
  }

  /**
   * Joins a base URL with a relative path, normalizing a missing trailing
   * slash first. Extracted from the endsWith('/') + new URL(path, base)
   * logic that was duplicated in login.page.ts, start-from-scratch.page.ts,
   * and start-with-prompt.page.ts.
   */
  public buildUrl(baseURL: string, relativePath: string): string {
    const normalizedBaseURL = baseURL.endsWith('/') ? baseURL : `${baseURL}/`;
    return new URL(relativePath, normalizedBaseURL).toString();
  }

  /**
   * Navigates to the survey home page. Extracted from the identical
   * buildUrl(envConfig.BASE_URL, 'survey') + navigateToUrl() logic that was
   * duplicated in start-from-scratch.page.ts and start-with-prompt.page.ts.
   */
  public async navigateToSurvey(): Promise<void> {
    const surveyURL = this.buildUrl(envConfig.BASE_URL, 'survey');
    await this.navigateToUrl(surveyURL);
  }

  public getBasePage(): BasePage {
    return this.basePage;
  }
}
