import { describe, expect, it, vi } from 'vitest';
import { ReviewModeService } from './review-mode.service';
import { SurveyService } from './survey.service';

describe('ReviewModeService', () => {
  const createService = (questions: unknown[] = []) => {
    const surveyService = {
      getQuestions: vi.fn().mockReturnValue(questions),
      setQuestions: vi.fn(),
    };
    const service = new ReviewModeService(surveyService as unknown as SurveyService);
    return { service, surveyService };
  };

  it('starts with empty review state', () => {
    const { service } = createService();

    expect(service.expandedState()).toBe(false);
    expect(service.checkedIndices().size).toBe(0);
    expect(service.hasCheckedItems()).toBe(false);
    expect(service.isReviewMode()).toBe(false);
  });

  it('toggles expanded state', () => {
    const { service } = createService();

    service.toggleAllExpanded();
    expect(service.expandedState()).toBe(true);
    service.toggleAllExpanded();
    expect(service.expandedState()).toBe(false);
  });

  it('toggles individual checked questions', () => {
    const { service } = createService();

    service.toggleChecked(1);
    expect(service.isChecked(1)).toBe(true);
    expect(service.hasCheckedItems()).toBe(true);

    service.toggleChecked(1);
    expect(service.isChecked(1)).toBe(false);
  });

  it('selects and clears all questions', () => {
    const { service } = createService([{}, {}, {}]);

    service.toggleAllChecked();
    expect(service.checkedIndices()).toEqual(new Set([0, 1, 2]));
    expect(service.isAllChecked()).toBe(true);

    service.toggleAllChecked();
    expect(service.checkedIndices()).toEqual(new Set());
    expect(service.isAllChecked()).toBe(false);
  });

  it('does not mark an empty question list as all checked', () => {
    const { service } = createService();

    service.toggleAllChecked();

    expect(service.isAllChecked()).toBe(false);
    expect(service.checkedIndices()).toEqual(new Set());
  });

  it('deletes checked questions and clears selection', () => {
    const questions = [{ id: 1 }, { id: 2 }, { id: 3 }];
    const { service, surveyService } = createService(questions);
    service.toggleChecked(1);

    service.deleteCheckedQuestions();

    expect(surveyService.setQuestions).toHaveBeenCalledWith([{ id: 1 }, { id: 3 }]);
    expect(service.checkedIndices()).toEqual(new Set());
  });

  it('exits review mode after deleting all questions', () => {
    const { service } = createService([{}]);
    service.enterReviewMode();
    service.toggleChecked(0);

    service.deleteCheckedQuestions();

    expect(service.isReviewMode()).toBe(false);
  });

  it('toggles individual card collapse state', () => {
    const { service } = createService();

    service.toggleCardCollapsed(2);
    expect(service.isCardCollapsed(2)).toBe(true);
    service.toggleCardCollapsed(2);
    expect(service.isCardCollapsed(2)).toBe(false);
  });

  it('sets all cards collapsed or expanded', () => {
    const { service } = createService([{}, {}]);

    service.setAllCardsCollapsed(true);
    expect(service.collapsedIndices()).toEqual(new Set([0, 1]));

    service.setAllCardsCollapsed(false);
    expect(service.collapsedIndices()).toEqual(new Set());
  });

  it('enters and exits review mode', () => {
    const { service } = createService([{}, {}]);
    service.toggleChecked(0);

    service.enterReviewMode();
    expect(service.isReviewMode()).toBe(true);
    expect(service.collapsedIndices()).toEqual(new Set([0, 1]));

    service.exitReviewMode();
    expect(service.isReviewMode()).toBe(false);
    expect(service.checkedIndices()).toEqual(new Set());
  });
});
