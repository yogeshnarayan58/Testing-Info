import { describe, expect, it } from 'vitest';
import { AiSuggestion, AiSuggestionChange } from '../models/build-survey';
import { buildSpellingHighlights } from './optiq-feedback.util';

const suggestion = (changes?: AiSuggestionChange[]): AiSuggestion => ({
  suggestionId: 's-1',
  action: 'REPHRASE',
  ruleCode: 'WORDING',
  severity: 'OPTIONAL',
  issue: 'Wording',
  rationale: 'Improve wording',
  fieldPath: 'question',
  suggestedText: 'A B C D',
  source: 'AI',
  changes,
});

const replacements: AiSuggestionChange[] = ['a', 'b', 'c', 'd'].map((oldText, index) => ({
  oldText,
  newText: oldText.toUpperCase(),
  start: index * 2,
  end: index * 2 + 1,
}));

describe('buildSpellingHighlights', () => {
  it.each([undefined, [], replacements])(
    'uses full-text comparison when changes are missing, empty, or exceed three: %j',
    changes => {
      expect(buildSpellingHighlights('a b c d', suggestion(changes))).toBeNull();
    }
  );

  it.each([
    ['offsets shifted by an edit before the change', 'usually by meet', [{ oldText: 'by', newText: 'buy', start: 9, end: 11 }]],
    ['end beyond the text', 'usually by meet', [{ oldText: 'by', newText: 'buy', start: 20, end: 22 }]],
    ['end before start', 'usually by meet', [{ oldText: '', newText: 'buy', start: 8, end: 7 }]],
    ['non-integer offsets', 'usually by meet', [{ oldText: 'by', newText: 'buy', start: 8.5, end: 10.5 }]],
    [
      'changes that overlap',
      'usually by meet',
      [
        { oldText: 'by', newText: 'buy', start: 8, end: 10 },
        { oldText: 'y', newText: 'ie', start: 9, end: 10 },
      ],
    ],
  ] as [string, string, AiSuggestionChange[]][])(
    'uses full-text comparison when the BE offsets do not match the text: %s',
    (_reason, originalText, changes) => {
      expect(buildSpellingHighlights(originalText, suggestion(changes))).toBeNull();
    }
  );

  it('renders three BE replacements without checking the rule code', () => {
    expect(buildSpellingHighlights('a b c d', suggestion(replacements.slice(0, 3)))).toEqual([
      { text: 'a', state: 'removed' },
      { text: 'A', state: 'added' },
      { text: ' ', state: 'unchanged' },
      { text: 'b', state: 'removed' },
      { text: 'B', state: 'added' },
      { text: ' ', state: 'unchanged' },
      { text: 'c', state: 'removed' },
      { text: 'C', state: 'added' },
      { text: ' d', state: 'unchanged' },
    ]);
  });

  it('supports insertion, deletion, whitespace replacement and unchanged BE text', () => {
    const changes: AiSuggestionChange[] = [
      { oldText: '', newText: 'the ', start: 0, end: 0 },
      { oldText: 'bad', newText: '', start: 0, end: 3 },
      { oldText: '  ', newText: ' ', start: 3, end: 5 },
    ];
    const highlights = buildSpellingHighlights('bad  end!', suggestion(changes));

    expect(highlights).toEqual([
      { text: 'the ', state: 'added' },
      { text: 'bad', state: 'removed' },
      { text: '  ', state: 'unchanged' },
      { text: ' ', state: 'added' },
      { text: 'end!', state: 'unchanged' },
    ]);
    expect(changes[0].start).toBe(0);
  });

  it('preserves whitespace without applying strikethrough to it', () => {
    const highlights = buildSpellingHighlights(' a b ', suggestion([
      { oldText: ' a b ', newText: 'correct', start: 0, end: 5 },
    ]));

    expect(highlights?.filter(item => item.state === 'removed').map(item => item.text))
      .toEqual(['a', 'b']);
    expect(highlights?.filter(item => item.state === 'unchanged').map(item => item.text).join(''))
      .toBe('   ');
  });
});
