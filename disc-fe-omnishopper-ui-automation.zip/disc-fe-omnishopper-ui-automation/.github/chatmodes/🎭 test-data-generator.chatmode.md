# Test Data Generator Guide - Automated Test Data Generation (DEV/SI/UAT & PRODUCTION)

---

## FIRST QUESTION - Environment Selection (MANDATORY)

**BEFORE DOING ANYTHING, ALWAYS ASK THIS QUESTION FIRST:**

### "Which environment are you generating test data for?"

Choose one:

#### **Option A: Lower Environments (DEV, SI, UAT)** 
- For **DEV** (Development), **SI** (System Integration), or **UAT** (User Acceptance Testing)
- All three use the same input format: Asset file + Dataset files
- Output: `dev-test-data.json` (+ optional `localization-data.json`)
- **Note:** Same file structure works for DEV, SI, and UAT - just update environment URLs in your .env

#### **Option B: PRODUCTION Environment** 
- For production testing (PROD_US, PROD_EU, PROD_APAC, PROD_CALATAM)
- Input: Async payload from production
- Output: `prod-test-data.json` + `.env.production`

**DO NOT proceed until user answers: A or B**

---

## Overview

This generator creates test data files from input JSON files for report automation testing across **all environments**.

### Environment Support

#### **Lower Environments: DEV, SI, UAT** 
- **DEV** - Development environment
- **SI** - System Integration environment
- **UAT** - User Acceptance Testing environment
- All three use asset + dataset files with same structure
- Generate once, use across DEV/SI/UAT by changing BASE_URL in .env

#### **PRODUCTION Environments** 
- For production environment testing (PROD_US, PROD_EU, PROD_APAC, PROD_CALATAM)
- Uses async payload files from production

### Available Outputs

**For Lower Environments (DEV, SI, UAT):**
1. ✅ **dev-test-data.json** - Test data for automation framework (REQUIRED)
   - Same file works for DEV, SI, and UAT
   - Configure environment-specific URLs in .env file
2. ✅ **localization-data.json** - Locale-specific translations and metadata (OPTIONAL)

**For PRODUCTION Environments:**
1. ✅ **prod-test-data.json** - Test data for production automation (REQUIRED)
2. ✅ **.env.production** - Production environment configuration (REQUIRED)

---

## ⚙️ Workflow: Interactive Confirmation Required

**IMPORTANT: Always follow this workflow:**

### Step 1: Environment Selection  (ALREADY ASKED ABOVE)

User has already answered which environment they're targeting (A or B)

---

### Step 2A: For Lower Environments (DEV/SI/UAT) - Output Selection ✅

**If user selected Option A (DEV, SI, or UAT):**

1. **Generator MUST confirm** which output files are needed:
   - Option 1: ✅ Only `dev-test-data.json`?
   - Option 2: ✅✅ Both `dev-test-data.json` AND `localization-data.json`?
2. **User confirms** the selection
3. **User provides input files** (asset + dataset files)
4. **Generator proceeds** with file generation

**Note:** The generated `dev-test-data.json` works for **DEV, SI, and UAT** environments. Update your `.env` file with the appropriate BASE_URL for each environment:
- DEV: Your dev BASE_URL
- SI: Your SI BASE_URL  
- UAT: Your UAT BASE_URL

**DO NOT generate files until user confirms which outputs they need.**

---

### Step 2B: For PRODUCTION - Environment & Dataset 

**If user selected Option B (PRODUCTION):**

1. **Generator MUST ask these questions:**
   -  **Which production environment?** (4 options)
     1. **Production US** - `https://connect.nielseniq.com`
     2. **Production EU** - `https://eu.connect.nielseniq.com`
     3. **Production APAC** - `https://apac.connect.nielseniq.com`
     4. **Production CALATAM** - `https://calatam.connect.nielseniq.com`
   -  **Which dataset is this for?** (User must specify dataset name from async payload)
2. **User answers both questions**
3. **User provides input file** (async payload JSON from production)
4. **Generator creates:**
   - `prod-test-data.json`
   - `.env.production`

**DO NOT generate files until user answers both questions.**

**DO NOT generate any files until user confirms the environment type and answers all required questions.**

---

##  Lower Environments Setup (DEV, SI, UAT)

### ⚙️ Configuration: Select Your Outputs

### Option 1: Generate Only dev-test-data.json ✅
Choose this if:
- You only need test automation data
- Your asset file doesn't have localization data
- You're working with English-only reports
- Testing in DEV, SI, or UAT environment

**Required Input Files:**
- 1 Asset/Metadata file
- 1-3 Dataset files (async payload files)

**Output:** `dev-test-data.json` (works for DEV, SI, and UAT)

---

### Option 2: Generate Both Files ✅✅
Choose this if:
- You need multi-locale support
- Your asset has `localizations` attribute populated
- You're setting up international reports
- Testing in DEV, SI, or UAT environment

**Required Input Files:**
- 1 Asset/Metadata file (MUST have `localizations` attribute)
- 1-3 Dataset files (async payload files)

**Outputs:** 
- `dev-test-data.json` (works for DEV, SI, and UAT)
- `localization-data.json`

---

## Problem Statement - Lower Environments (DEV, SI, UAT)

### Input Requirements

**Maximum 4 input files:**
1. **1 Asset/Metadata File** (required) - Contains asset information (assetId, userTags, localizations, parameters)
   - File names: `asset.json`, `reportSpec.json`, `reportSpecV2.json`, or any `.json` with asset attributes
   
2. **Up to 3 Dataset Files** (at least 1 required) - Async payload files with reportSpec and requestInstance
   - **Panel on Demand Omnishopper Dataset** (optional)
   - **Panel on Demand Homescan Dataset** (optional)
   - **Panel On Demand Multi-Country Dataset** (optional)
   - File names: Any `.json` file (e.g., `tsbg_async.json`, `omni_data.json`, etc.)

**Note:** User may provide 1, 2, or 3 dataset files depending on which datasets are applicable for the asset.

---

## Output 1: localization-data.json (OPTIONAL)

**⚠️ Generate this file ONLY if:**
- User explicitly requests it
- Asset file has `localizations` attribute with data
- Multi-locale testing is required

**Data Source:** Asset file's `"localizations"` attribute

**Structure:** Array of locale objects

**Extraction Rules:**

```javascript
// FROM: asset.json or reportSpec.json
{
  "localizations": [
    {
      "locale": "en-US",
      "title": "Assortment optimizer",
      "description": "Assortment optimizer uses...",
      "parameters": {
        "solutionType": ["PANEL_OD_OMNI", "PANEL_OD_HSCN"],
        "businessQuestions": ["Which products bring the most buyers..."],
        "businessObjectives": ["Which products should I consider..."]
      }
    }
  ]
}

// TO: localization-data.json
[
  {
    "locale": "en-US",                    // FROM: localizations[].locale
    "localeDescription": "en-US",         // FROM: localizations[].locale (same value)
    "title": "Assortment optimizer",      // FROM: localizations[].title
    "description": "Assortment optimizer uses...", // FROM: localizations[].description
    "solutionType": ["PANEL_OD_OMNI", "PANEL_OD_HSCN"], // FROM: localizations[].parameters.solutionType
    "businessQuestions": [...],           // FROM: localizations[].parameters.businessQuestions
    "businessObjectives": [...]           // FROM: localizations[].parameters.businessObjectives
  }
]
```

**Number of Objects:** Depends on number of locales in `localizations` array (one object per locale)

**Skip Generation If:**
```javascript
if (!assetFile.localizations || assetFile.localizations.length === 0) {
  console.log('⚠️ Skipping localization-data.json - no localizations found');
  // Only generate dev-test-data.json
}
```

---

## Output 2: dev-test-data.json (REQUIRED)

**⚠️ Always generate this file** - Required for all test automation

**Data Sources:** Asset file + Async payload files (1-3 dataset files)

### Quick Reference

| Output Field | Source File | Source Attribute | Transformation Rule |
|--------------|-------------|------------------|---------------------|
| `navigationURL` | Asset | `launchURL` | Extract assetId → `/report/flow/US-{assetId}/US-{assetId}` |
| `themes` | Asset | `userTags` | **EXCLUDE** "Report templates" and tags starting with "panel" |
| `dataSets` | Asset | `userTags` | **INCLUDE ONLY** tags starting with "panel" or "Panel" |
| `thumbnailSrc` | Asset | `image` | Use directly |
| `sourceType` | Dataset | `requestInstance.datasetLabel` | If includes "Omni" → "Panel On Demand Omnishopper"<br>If includes "HSCN" → "Panel on Demand Homescan"<br>If includes "MULTI_COUNTRY" → "Panel On Demand Multi-Country" |
| `dataView` | Dataset | `requestInstance.dataViewName` | Use directly |
| `navUrlWithDataSetId` | Both | Multiple | `navigationURL + "/" + datasetId + "/" + dataViewId` |
| `dimensionSelections` | Dataset | `requestInstance.prompts[]` | Array with one object containing all dimensions |

---

## Input File Specifications

### Input File 1: Asset/Metadata File (Required)

**Naming Convention:**
- `asset.json` ✅
- `reportSpec.json` ✅
- `reportSpecV2.json` ✅
- Any `.json` file containing assetId, assetType, userTags, localizations, parameters

**Purpose:** Contains report catalog information and localization data

**Key Attributes:**
```jsonc
// Pseudo-JSON example (comments for illustration only)
{
  "assetId": 2190291,
  "title": "...",
  "launchURL": "report/flow/2190291",
  "image": "https://...",
  "userTags": [
    "Buyers & Shoppers",           // Theme (INCLUDE in themes)
    "Report templates",            // EXCLUDE from themes
    "panel on demand omnishopper", // Dataset tag (INCLUDE in dataSets)
    "panel on demand homescan"     // Dataset tag (INCLUDE in dataSets)
  ],
  "localizations": [ /* for localization-data.json */ ],
  "parameters": { /* ... */ }
}
```

---

### Input Files 2-4: Dataset Files / Async Payload Files (1-3 required)

**Naming Convention:** Can be **ANY** `.json` file name

**Purpose:** Contains report execution data with dimension selections

**Important:** Each file MUST have a **unique** `requestInstance.datasetLabel`

**Key Attributes:**
```jsonc
// Pseudo-JSON example (comments for illustration only)
{
  "reportSpec": { /* report definition */ },
  "requestInstance": {
    "datasetLabel": "Omni Agg SI 5yrs Synd", // UNIQUE key for datasets object
    "datasetId": "155536",
    "dataViewName": "Entire Dataset",
    "dataViewId": "OrderId_4010",
    "productOfferingCode": "PANEL_OD_OMNI",
    "prompts": [                 // ALL dimension selections
      {
        "id": "PRDC",            // Prompt ID
        "label": "Product Universe", // Dimension name (use as key)
        "hidden": false,         // ⚠️ SKIP if hidden: true
        "minSelections": 1,
        "maxSelections": 100,
        "dimIds": [],            // 🔍 For People/Time Stamped Groups - nested prompts
        "promptData": [
          {
            "allSelectedValues": {  // EXTRACT selections from here
              "#US LOC OMNI DEPARTMENT MASTER": ["FOOD"]
            }
          }
        ]
      }
    ],
    "dimensionSelections": [],   // 🔍 For Time Stamped Groups - nested structure
    "locale": "en_US"
  }
}
```

**Extraction Rules for Prompts:**
- ✅ **INCLUDE** prompts where:
  - `label` is NOT empty
  - `promptData[0].allSelectedValues` is NOT empty (array or object)
  - `hidden` is NOT true
- ❌ **SKIP** prompts where:
  - `label === ""` (empty label)
  - `allSelectedValues === []` or `{}` (empty)
  - `hidden === true` ← **CRITICAL: Hidden prompts must be excluded**
- 🔍 **Special Cases:**
  - **Time Stamped Groups** (`id: "PPL"` with `dimIds`) - Extract from `dimensionSelections` and nested prompts
  - **People** (`id: "PPL"` with `dimIds`) - Extract from nested prompts using `dimIds` array
  - **Trip Groups** (`id: "TG"` or `id: "TRIP"` with `dimIds`) - Extract from `dimensionSelections` and nested prompts

### Understanding allSelectedValues Formats

The `allSelectedValues` attribute in `promptData[0]` can have **two different formats**:

#### Format 1: Array Format (Simple Selections)
Used for dimensions like Geography, Demographics where selections are simple values.

```javascript
// Example: Geography dimension
{
  "id": "GEO",
  "label": "Geographies",
  "promptData": [
    {
      "promptSelectionLabel": "Total US",      // This becomes the key
      "allSelectedValues": ["Total US"]        // Array of selected values
    }
  ]
}

// Output in dev-test-data.json:
"Geographies": {
  "selections": {
    "Total US": ["Total US"]    // promptSelectionLabel: allSelectedValues
  },
  "minSelection": "1",
  "maxSelection": "12"
}
```

#### Format 2: Object Format (Hierarchy Selections)
Used for dimensions like Product, Period with hierarchy levels.

```javascript
// Example: Product dimension
{
  "id": "PRDC",
  "label": "Products",
  "promptData": [
    {
      "allSelectedValues": {     // Object with hierarchy → values
        "#US LOC OMNI DEPARTMENT MASTER": ["FOOD"],
        "TOTAL US": ["Total Product", "HEALTH & BEAUTY CARE"]
      }
    }
  ]
}

// Output in dev-test-data.json:
"Products": {
  "selections": {
    "#US LOC OMNI DEPARTMENT MASTER": ["FOOD"],
    "TOTAL US": ["Total Product", "HEALTH & BEAUTY CARE"]
  },
  "minSelection": "1",
  "maxSelection": "500"
}
```

**Extraction Logic:**
1. Check if `allSelectedValues` is an array:
   - If array and NOT empty → Use `promptSelectionLabel` as key
   - If array and empty → SKIP this prompt
2. Check if `allSelectedValues` is an object:
   - If object and has keys → Use directly as selections
   - If object and empty `{}` → SKIP this prompt
3. Otherwise → SKIP (invalid format)

**⚠️ Common Mistake - Why Using `Object.keys()` on Arrays Fails:**

```javascript
// ❌ WRONG - This logic skips array format dimensions!
if (!prompt.promptData[0].allSelectedValues || 
    Object.keys(prompt.promptData[0].allSelectedValues).length === 0) {
  return; // PROBLEM: Object.keys(["Total US"]) returns ["0"] which has length 1
          // But we check .length === 0, so arrays pass through
          // Then we try to use it as object → WRONG output format!
}

// ✅ CORRECT - Check type first, then handle appropriately
const allSelectedValues = prompt.promptData[0].allSelectedValues;

if (Array.isArray(allSelectedValues)) {
  // Handle array format
} else if (typeof allSelectedValues === 'object' && allSelectedValues !== null) {
  // Handle object format
}
```

**Why This Matters:**
- `Object.keys(["Total US"])` returns `["0"]` (array indices as strings)
- Most dimensions use **array format**: Retailers, Facts, Products, Periods, Geography, Demographics
- Only a few use **object format**: Product hierarchies with multiple levels
- Missing type check = wrong extraction for 80% of dimensions!

---

## Detailed Extraction Rules

### 1. Common Section (from Asset File)

#### 1.1 navigationURL
**Source:** `launchURL` attribute  
**Formula:** `/report/flow/US-{assetId}/US-{assetId}`

```javascript
const launchURL = assetFile.launchURL; // "report/flow/2190291"
const assetId = launchURL.split('/').pop(); // "2190291"
const navigationURL = `/report/flow/US-${assetId}/US-${assetId}`;
// Result: "/report/flow/US-2190291/US-2190291"
```

#### 1.2 themes
**Source:** `userTags`  
**Filter:** EXCLUDE tags starting with "panel" and "Report template"

```javascript
const themes = assetFile.userTags.filter(tag => {
  const lowerTag = tag.toLowerCase();
  return !lowerTag.startsWith('panel') && !tag.includes('Report template');
});
```

#### 1.3 dataSets
**Source:** `userTags`  
**Filter:** INCLUDE ONLY tags starting with "panel"

```javascript
const dataSets = assetFile.userTags.filter(tag => {
  return tag.toLowerCase().startsWith('panel');
});
```

#### 1.4 thumbnailSrc
**Source:** `image` attribute  
**Transformation:** Use directly

---

### 2. Dataset Configuration (from Async Payload Files)

Each async payload file creates ONE dataset entry.

#### 2.1 Dataset Key
**Source:** `requestInstance.datasetLabel`

#### 2.2 sourceType
**Source:** `requestInstance.datasetLabel`  
**Logic:**
- Contains "MULTI_COUNTRY" → "Panel On Demand Multi-Country"
- Contains "Omni" (not MULTI_COUNTRY) → "Panel On Demand Omnishopper"
- Contains "HSCN" → "Panel on Demand Homescan"

#### 2.3 navUrlWithDataSetId
**Formula:** `{navigationURL}/{datasetId}/{dataViewId}`

```javascript
const navUrlWithDataSetId = `${navigationURL}/${datasetId}/${dataViewId}`;
// Example: "/report/flow/US-2190291/US-2190291/155536/OrderId_4010"
```

---

### 3. Dimension Selections Extraction

**Structure:** Array containing ONE object with all dimensions

**CRITICAL: Selection Key Extraction Logic**

Selection keys MUST be extracted from `dimensionSelections` → `children` array, NOT from `promptData`:

1. **Standard dimensions (Product, Retailer, Geography, etc.):**
   - Navigate: `dimensionSelections.find(ds => ds.id === promptId).children[0].children[0].label`
   - This gives you the actual characteristic/group label to use as the key
   
2. **Hierarchical dimensions (Facts, Periods):**
   - Navigate **one level deeper** to get the actual label
   - Facts: `children[0].children[0].children[0].children[0].label` (e.g., "Units" not "Fact Groups")
   - Periods: `children[0].children[0].children[0].label` (e.g., "Years" not "Custom Folder")

**Examples:**

```javascript
// Facts dimension - go deeper to get "Units"
// Path: dimensionSelections → FCT → children[0] ("Selection") → children[0] ("Fact Groups") 
//       → children[0] ("Units") → children[0] ("None") → children[0] (actual fact)
// Use label from the deepest meaningful level: "Units"

// Periods dimension - go deeper to get "Years"  
// Path: dimensionSelections → PRD → children[0] ("Untitled Selection") → children[0] ("Custom Folder")
//       → children[0] ("Years") → children[0] (actual period)
// Use label from: "Years"

// Product dimension - use first characteristic label
// Path: dimensionSelections → PRDC → children[0] → children[0].label
// Use: "#US LOC OMNI DEPARTMENT MASTER"
```

**IMPORTANT:** Always clean selection keys by removing number prefixes (e.g., "6 Channel" → "Channel", "8 #US LOC..." → "#US LOC...")

```javascript
// Helper function to clean selection keys
function cleanSelectionKey(key) {
  // Remove patterns like "6 ", "8 ", etc. at the start
  return key.replace(/^\d+\s+/, '');
}

function getSelectionKeyFromDimensionSelections(promptId, dimensionSelections, promptLabel) {
  // Find the dimension selection for this prompt
  const dimSelection = dimensionSelections.find(ds => ds.id === promptId);
  if (!dimSelection || !dimSelection.children || dimSelection.children.length === 0) {
    return null;
  }

  // Special handling for Facts (needs to go 4 levels deep)
  if (promptId === 'FCT' || promptLabel === 'Facts') {
    const level1 = dimSelection.children[0]; // "Selection" or view
    if (level1?.children?.[0]?.children?.[0]?.label) {
      return level1.children[0].children[0].label; // "Units", "Dollars", etc.
    }
  }

  // Special handling for Periods (needs to go 3 levels deep)
  if (promptId === 'PRD' || promptLabel === 'Periods') {
    const level1 = dimSelection.children[0]; // "Untitled Selection" or view
    if (level1?.children?.[0]?.children?.[0]?.label) {
      return level1.children[0].children[0].label; // "Years", "Quarters", etc.
    }
  }

  // Standard dimensions: use first child's label
  const firstChild = dimSelection.children[0];
  if (firstChild?.children?.[0]?.label) {
    return firstChild.children[0].label;
  }

  return null;
}

function extractDimensionSelections(prompts, dimensionSelections) {
  const dimensionsObject = {};
  
  prompts.forEach(prompt => {
    // SKIP CONDITIONS for top-level prompts only:
    if (!prompt.label || prompt.label === '') return;        // Empty label
    if (prompt.hidden === true && !prompt.dimIds) return;    // Hidden without nested structure
    
    // Check for special dimensions (People, Time Stamped Groups, Trip Groups)
    if (prompt.dimIds && prompt.dimIds.length > 0) {
      // Special handling for nested dimensions
      const nestedResult = extractNestedDimensions(
        prompt, 
        prompts, 
        dimensionSelections
      );
      
      // Only include if nested dimensions have actual data
      if (nestedResult.selections && 
          (Array.isArray(nestedResult.selections) && nestedResult.selections.length > 0)) {
        dimensionsObject[prompt.label] = {
          ...nestedResult,
          "minSelection": prompt.minSelections.toString(),
          "maxSelection": prompt.maxSelections.toString()
        };
      }
      return;
    }
    
    // Standard dimension extraction
    if (!prompt.promptData || !prompt.promptData[0]) {
      return; // Skip - no promptData
    }
    
    const allSelectedValues = prompt.promptData[0].allSelectedValues;
    
    // Handle both array format and object format for allSelectedValues
    let selections = {};
    
    // Get the selection key from dimensionSelections (CRITICAL)
    const selectionKey = getSelectionKeyFromDimensionSelections(
      prompt.id, 
      dimensionSelections, 
      prompt.label
    );
    
    if (Array.isArray(allSelectedValues)) {
      // Array format (e.g., ["Total US", "Total Panel"])
      if (allSelectedValues.length === 0) return; // Skip empty arrays
      
      // Use the key from dimensionSelections, fallback to promptSelectionLabel
      const key = selectionKey || prompt.promptData[0].promptSelectionLabel || "selections";
      const cleanedKey = cleanSelectionKey(key);
      selections[cleanedKey] = allSelectedValues;
    } else if (typeof allSelectedValues === 'object' && allSelectedValues !== null) {
      // Object format (e.g., {"TOTAL US": ["FOOD"]})
      if (Object.keys(allSelectedValues).length === 0) return; // Skip empty objects
      
      // For object format, use the key from dimensionSelections if available
      // Otherwise clean the keys from allSelectedValues
      if (selectionKey) {
        const cleanedKey = cleanSelectionKey(selectionKey);
        // Aggregate all values under the selection key
        const allValues = Object.values(allSelectedValues).flat();
        selections[cleanedKey] = allValues;
      } else {
        // Fallback: Clean keys in object format
        Object.keys(allSelectedValues).forEach(key => {
          const cleanedKey = cleanSelectionKey(key);
          selections[cleanedKey] = allSelectedValues[key];
        });
      }
    } else {
      return; // Skip - invalid format
    }
    
    dimensionsObject[prompt.label] = {
      "selections": selections,
      "minSelection": prompt.minSelections.toString(),
      "maxSelection": prompt.maxSelections.toString()
    };
  });
  
  return [dimensionsObject];
}
```

---

### 4. Special Case: Time Stamped Groups / People Dimension

**Prompts to identify:**
- Time Stamped Groups: `id: "PPL"` with `dimIds` array
- People: `id: "PPL"` with `dimIds` array

**Key Indicator:** Prompt has `dimIds` attribute (array of nested prompt IDs)

**Example dimIds:**
```javascript
"dimIds": ["BUYGP", "SHPGP", "RTL_PPL", "PPL_PRD"]
// BUYGP = Buyer Group (Product selections)
// SHPGP = Shopper Group (Retailer selections for "Shopped at")
// RTL_PPL = Retailer for "Bought from Retailer"
// PPL_PRD = People Period (Time Period selections)
```

**Extraction Algorithm:**

```javascript
function extractNestedDimensions(pplPrompt, allPrompts, dimensionSelections) {
  const dimIds = pplPrompt.dimIds; // ["BUYGP", "SHPGP", "RTL_PPL", "PPL_PRD"]
  
  // Step 1: Find dimensionSelections entry for this prompt
  const dimSelection = dimensionSelections.find(ds => ds.id === pplPrompt.id);
  if (!dimSelection || !dimSelection.children) {
    return { "selections": [] };
  }
  
  // Step 2: Extract the time-stamped selection structure
  const selections = [];
  
  // The structure comes from dimensionSelections, not promptData
  // Look for nested structures like "Bought", "Bought from Retailer", etc.
  dimSelection.children.forEach(child => {
    const selectionType = child.label; // e.g., "Bought", "Bought from Retailer"
    
    // Build nested structure based on dimIds
    const nestedStructure = {};
    
    dimIds.forEach(dimId => {
      const relatedPrompt = allPrompts.find(p => p.id === dimId);
      if (!relatedPrompt) return;
      // NOTE: DON'T skip hidden prompts - they contain the actual data for nested dimensions
      
      // Map dimId to dimension name
      const dimensionName = getDimensionName(dimId);
      
      // Extract selections from the related prompt (even if hidden)
      if (relatedPrompt.promptData && 
          relatedPrompt.promptData[0] && 
          relatedPrompt.promptData[0].allSelectedValues) {
        
        // Handle both array and object format
        let selections = {};
        const allSelectedValues = relatedPrompt.promptData[0].allSelectedValues;
        
        // Get the selection key from dimensionSelections (CRITICAL)
        const selectionKey = getSelectionKeyFromDimensionSelections(
          dimId, 
          dimensionSelections, 
          dimensionName
        );
        
        if (Array.isArray(allSelectedValues)) {
          if (allSelectedValues.length > 0) {
            // Use key from dimensionSelections, fallback to promptSelectionLabel
            const key = selectionKey || relatedPrompt.promptData[0].promptSelectionLabel;
            const cleanedKey = cleanSelectionKey(key);
            selections[cleanedKey] = allSelectedValues;
          }
        } else if (typeof allSelectedValues === 'object' && allSelectedValues !== null) {
          if (Object.keys(allSelectedValues).length > 0) {
            // For nested dimensions with object format, preserve the structure
            if (selectionKey) {
              const cleanedKey = cleanSelectionKey(selectionKey);
              const allValues = Object.values(allSelectedValues).flat();
              selections[cleanedKey] = allValues;
            } else {
              // Fallback: Clean keys in object format
              Object.keys(allSelectedValues).forEach(key => {
                const cleanedKey = cleanSelectionKey(key);
                selections[cleanedKey] = allSelectedValues[key];
              });
            }
          }
        }
        
        nestedStructure[dimensionName] = {
          "selections": selections,
          "minSelection": relatedPrompt.minSelections.toString(),
          "maxSelection": relatedPrompt.maxSelections.toString()
        };
      }
    });
    
    // Double-nest structure (framework requirement)
    const doubleNested = {};
    doubleNested[selectionType] = nestedStructure;
    
    const outerNested = {};
    outerNested[selectionType] = doubleNested;
    
    selections.push(outerNested);
  });
  
  return {
    "selections": selections
  };
}

// Map dimIds to dimension names
function getDimensionName(dimId) {
  const mapping = {
    'BUYGP': 'Product',
    'SHPGP': 'Retailer',     // for "Shopped at"
    'RTL_PPL': 'Retailer',   // for "Bought from Retailer"
    'PPL_PRD': 'Time Period'
  };
  return mapping[dimId] || dimId;
}
```

**Example Output Structure:**

```json
"People": {
  "selections": [
    {
      "Bought": {
        "Bought": {
          "Product": {
            "selections": {
              "TOTAL US": ["HEALTH & BEAUTY CARE"]
            },
            "minSelection": "1",
            "maxSelection": "100"
          }
        }
      }
    }
  ],
  "minSelection": "1",
  "maxSelection": "1"
}
```

**Or with Retailer:**

```json
"Time stamped groups": {
  "selections": [
    {
      "Bought from Retailer": {
        "Bought from Retailer": {
          "Product": {
            "selections": {
              "TOTAL US": ["Total Product"]
            },
            "minSelection": "1",
            "maxSelection": "1"
          },
          "Retailer": {
            "selections": {
              "Total": ["Walmart"]
            },
            "minSelection": "1",
            "maxSelection": "5"
          },
          "Time Period": {
            "selections": {
              "Quarters": ["OND 23 - w/e 12/30/23"]
            },
            "minSelection": "1",
            "maxSelection": "13"
          }
        }
      }
    }
  ]
}
```

**Key Points:**
1. The outer key (e.g., "Bought", "Bought from Retailer") comes from `dimensionSelections` array
2. The structure uses double-nesting (key appears twice)
3. Inner dimensions (Product, Retailer, Time Period) come from prompts referenced in `dimIds`
4. Each dimension in `dimIds` maps to a specific prompt that provides the selections
5. **CRITICAL:** DO NOT skip prompts where `hidden: true` - these hidden prompts contain the actual selection data for nested dimensions (BUYGP, SHPGP, RTL_PPL, PPL_PRD, TRIP_PRDC, etc.)

---

### 5. Special Case: Trip Groups Dimension

**Prompts to identify:**
- Trip Groups: `id: "TG"` or similar with `dimIds` array

**Key Indicator:** Prompt has `dimIds` attribute (array of nested prompt IDs)

**Structure Pattern:** Triple-nesting with selection type → sub-type → dimensions

**Example dimIds:**
```javascript
"dimIds": ["TGGP", "TG_PRD", "TG_RTL"]
// TGGP = Trip Group Product selections
// TG_PRD = Trip Group Period
// TG_RTL = Trip Group Retailer
```

**Extraction Algorithm for Trip Groups:**

```javascript
function extractTripGroupsDimension(tgPrompt, allPrompts, dimensionSelections) {
  const dimIds = tgPrompt.dimIds; // ["TGGP", etc.]
  
  // Step 1: Find dimensionSelections entry for this prompt
  const dimSelection = dimensionSelections.find(ds => ds.id === tgPrompt.id);
  if (!dimSelection || !dimSelection.children) {
    return { "selections": [] };
  }
  
  // Step 2: Extract the trip group structure
  const selections = [];
  
  dimSelection.children.forEach(child => {
    const outerType = child.label; // e.g., "Product Focused"
    
    // Trip Groups have an additional nesting level
    child.children?.forEach(subChild => {
      const middleType = subChild.label; // e.g., "Product in basket"
      
      // Build nested structure based on dimIds
      const nestedStructure = {};
      
      dimIds.forEach(dimId => {
        const relatedPrompt = allPrompts.find(p => p.id === dimId);
        if (!relatedPrompt || relatedPrompt.hidden === true) return;
        
        // Map dimId to dimension name
        const dimensionName = getTripGroupDimensionName(dimId);
        
        // Extract selections from the related prompt
        if (relatedPrompt.promptData && 
            relatedPrompt.promptData[0] && 
            relatedPrompt.promptData[0].allSelectedValues) {
          
          nestedStructure[dimensionName] = {
            "selections": relatedPrompt.promptData[0].allSelectedValues,
            "minSelection": relatedPrompt.minSelections.toString(),
            "maxSelection": relatedPrompt.maxSelections.toString()
          };
        }
      });
      
      // Triple-nest structure (Trip Groups specific)
      const tripleNested = {};
      tripleNested[middleType] = nestedStructure;
      
      const doubleNested = {};
      doubleNested[outerType] = tripleNested;
      
      selections.push(doubleNested);
    });
  });
  
  return {
    "selections": selections,
    "minSelection": tgPrompt.minSelections.toString(),
    "maxSelection": tgPrompt.maxSelections.toString()
  };
}

// Map Trip Groups dimIds to dimension names
function getTripGroupDimensionName(dimId) {
  const mapping = {
    'TGGP': 'Product',
    'TG_PRD': 'Time Period',
    'TG_RTL': 'Retailer'
  };
  return mapping[dimId] || dimId;
}
```

**Example Output Structure for Trip Groups:**

```json
"Trip Groups": {
  "selections": [
    {
      "Product Focused": {
        "Product in basket": {
          "Product": {
            "selections": {
              "TOTAL US": ["HEALTH & BEAUTY CARE"]
            },
            "minSelection": "1",
            "maxSelection": "1"
          }
        }
      }
    }
  ],
  "minSelection": "1",
  "maxSelection": "20"
}
```

**Structural Comparison:**

| Dimension Type | Nesting Levels | Pattern |
|----------------|----------------|---------|
| **Standard** | Single | `{dimension: {selections, min, max}}` |
| **People / Time Stamped** | Double | `{type: {type: {dimensions}}}` |
| **Trip Groups** | Triple | `{outerType: {middleType: {dimensions}}}` |

**Key Differences:**
1. **Trip Groups** has THREE levels: Outer Type → Middle Type → Dimensions
2. **People/Time Stamped Groups** has TWO levels: Type → Type (repeated) → Dimensions
3. Trip Groups extracts from `dimensionSelections.children[].children[]` (nested children)
4. Both outer level (`minSelection`/`maxSelection`) comes from the main prompt, not nested prompts

---

## Complete Example: Real Data Extraction

### Example 0: Standard Dimensions with Array Format

**Most dimensions use array format** - this is the most common case!

**⚠️ IMPORTANT:** Selection keys are extracted from `dimensionSelections.children` and cleaned to remove number prefixes.

```json
// FROM: requestInstance.prompts - Retailers dimension
{
  "id": "RTLR",
  "label": "Retailers",
  "minSelections": 1,
  "maxSelections": 25,
  "promptData": [{
    "allSelectedValues": ["Dollar Store", "Drug Store"]  // ARRAY format - values
  }]
}

// FROM: requestInstance.dimensionSelections - Retailers structure
{
  "id": "RTLR",
  "children": [{
    "children": [{
      "label": "6 Channel"  // Selection key (will be cleaned to "Channel")
    }]
  }]
}

// FROM: requestInstance.prompts - Products dimension
{
  "id": "PRDC",
  "label": "Products",
  "minSelections": 1,
  "maxSelections": 500,
  "promptData": [{
    "allSelectedValues": ["AFTER SHAVE", "ANTIBIOTIC"]  // ARRAY format - values
  }]
}

// FROM: requestInstance.dimensionSelections - Products structure
{
  "id": "PRDC",
  "children": [{
    "children": [{
      "label": "8 #US LOC OMNI CATEGORY MASTER"  // Will be cleaned to "#US LOC OMNI CATEGORY MASTER"
    }]
  }]
}

// FROM: requestInstance.prompts - Facts dimension
{
  "id": "FCT",
  "label": "Facts",
  "minSelections": 1,
  "maxSelections": 20,
  "promptData": [{
    "allSelectedValues": ["Units per Buyer"]  // ARRAY format - values
  }]
}

// FROM: requestInstance.dimensionSelections - Facts structure (4 levels deep)
{
  "id": "FCT",
  "children": [{
    "children": [{
      "children": [{
        "label": "Units"  // Deep level extraction (not "Fact Groups")
      }]
    }]
  }]
}

// FROM: requestInstance.prompts - Periods dimension
{
  "id": "PRD",
  "label": "Periods",
  "minSelections": 1,
  "maxSelections": 39,
  "promptData": [{
    "allSelectedValues": ["Cal Yr 2022 - w/e 12/31/22"]  // ARRAY format - values
  }]
}

// FROM: requestInstance.dimensionSelections - Periods structure (3 levels deep)
{
  "id": "PRD",
  "children": [{
    "children": [{
      "children": [{
        "label": "Years"  // Deep level extraction (not "Custom Folder")
      }]
    }]
  }]
}
```

**Output in dev-test-data.json:**

```json
{
  "Retailers": {
    "selections": {
      "Channel": ["Dollar Store", "Drug Store"]  // ✅ Key from dimensionSelections ("6 " cleaned)
    },
    "minSelection": "1",
    "maxSelection": "25"
  },
  "Products": {
    "selections": {
      "#US LOC OMNI CATEGORY MASTER": ["AFTER SHAVE", "ANTIBIOTIC"]  // ✅ Key cleaned ("8 " removed)
    },
    "minSelection": "1",
    "maxSelection": "500"
  },
  "Facts": {
    "selections": {
      "Units": ["Units per Buyer"]  // ✅ Deep extraction (4 levels) - "Units" not "Fact Groups"
    },
    "minSelection": "1",
    "maxSelection": "20"
  },
  "Periods": {
    "selections": {
      "Years": ["Cal Yr 2022 - w/e 12/31/22"]  // ✅ Deep extraction (3 levels) - "Years" not "Custom Folder"
    },
    "minSelection": "1",
    "maxSelection": "39"
  }
}
```

**Extraction Summary:**
- **Keys:** From `dimensionSelections.children` hierarchy (different depths per dimension type)
- **Values:** From `promptData[0].allSelectedValues` (array or object format)
- **Cleaning:** `key.replace(/^\d+\s+/, '')` removes number prefixes like "6 ", "8 "
- **Facts/Periods:** Require deeper navigation (3-4 levels) to get meaningful labels

---

### Example 1: People Dimension (tpkf_async.json)

```json
// FROM requestInstance.prompts
{
  "id": "PPL",
  "label": "People",
  "dimIds": ["BUYGP", "SHPGP", "RTL_PPL"],  // Nested prompt references
  "promptData": [
    {
      "allSelectedValues": []  // Empty - selections are in nested prompts
    }
  ]
}

// FROM requestInstance.prompts (nested prompt)
{
  "id": "BUYGP",
  "label": "Buyer Group",
  "hidden": true,  // ⚠️ This is hidden but needed for People dimension
  "promptData": [
    {
      "allSelectedValues": {
        "TOTAL US": ["HEALTH & BEAUTY CARE"]
      }
    }
  ]
}

// FROM requestInstance.dimensionSelections
{
  "id": "PPL",
  "children": [
    {
      "label": "Bought",  // This is the time-stamped selection type
      // ... structure details
    }
  ]
}
```

### Output: dev-test-data.json

```json
{
  "common": { /* ... */ },
  "datasets": {
    "Omni Agg SI 5yrs Synd": {
      "sourceType": "Panel On Demand Omnishopper",
      "dataView": "Entire Dataset",
      "navigationURL": "/report/flow/US-2789227/US-2789227",
      "navUrlWithDataSetId": "/report/flow/US-2789227/US-2789227/155536/OrderId_4010",
      "dimensionSelections": [
        {
          "Product Universe": { /* ... */ },
          "Facts": { /* ... */ },
          "People": {
            "selections": [
              {
                "Bought": {
                  "Bought": {
                    "Product": {
                      "selections": {
                        "TOTAL US": ["HEALTH & BEAUTY CARE"]
                      },
                      "minSelection": "1",
                      "maxSelection": "100"
                    }
                  }
                }
              }
            ],
            "minSelection": "1",
            "maxSelection": "1"
          }
        }
      ]
    }
  }
}
```

---

### Example 2: Trip Groups Dimension

```json
// FROM requestInstance.prompts
{
  "id": "TG",
  "label": "Trip Groups",
  "dimIds": ["TGGP"],  // Trip Group Product
  "minSelections": 1,
  "maxSelections": 20,
  "promptData": [
    {
      "allSelectedValues": []  // Empty - selections are in nested prompts
    }
  ]
}

// FROM requestInstance.prompts (nested prompt)
{
  "id": "TGGP",
  "label": "Trip Group Product",
  "hidden": true,  // ⚠️ Hidden but needed for Trip Groups
  "promptData": [
    {
      "allSelectedValues": {
        "TOTAL US": ["HEALTH & BEAUTY CARE"]
      }
    }
  ]
}

// FROM requestInstance.dimensionSelections
{
  "id": "TG",
  "children": [
    {
      "label": "Product Focused",  // Outer type
      "children": [
        {
          "label": "Product in basket"  // Middle type
        }
      ]
    }
  ]
}
```

**Output: dev-test-data.json**

```json
{
  "common": { /* ... */ },
  "datasets": {
    "Omni Agg SI 3yrs Synd": {
      "sourceType": "Panel On Demand Omnishopper",
      "dataView": "Entire Dataset br05S",
      "navUrlWithDataSetId": "/report/flow/US-2336255/US-2336255/155535/OrderId_4011",
      "dimensionSelections": [
        {
          "Trip Groups": {
            "selections": [
              {
                "Product Focused": {
                  "Product in basket": {
                    "Product": {
                      "selections": {
                        "TOTAL US": ["HEALTH & BEAUTY CARE"]
                      },
                      "minSelection": "1",
                      "maxSelection": "1"
                    }
                  }
                }
              }
            ],
            "minSelection": "1",
            "maxSelection": "20"
          }
        }
      ]
    }
  }
}
```

---

## Summary of Critical Rules

### ❌ SKIP Prompts Where:
1. `label === ""` (empty string)
2. `allSelectedValues === {}` or `[]` (no selections) **AND** no `dimIds` (not a nested dimension parent)
3. `hidden === true` **AND** no `dimIds` (not a nested dimension parent)
   - ⚠️ **Exception**: DO NOT skip if prompt has `dimIds` array (it's a nested dimension parent)

### ✅ INCLUDE Prompts Where:
1. `label` is NOT empty
2. Has `dimIds` array (nested dimension parent - include even if allSelectedValues is empty)
3. `allSelectedValues` has data (array with elements OR object with keys) and not hidden
4. Is referenced in another prompt's `dimIds` array (nested child - include even if hidden)

**Important Note on Nested Dimensions:**
- **Parents with `dimIds`** (e.g., People, Trip Groups) → Always check, even if their own `allSelectedValues` is empty
- **Children in `dimIds`** (e.g., BUYGP, TRIP_PRDC) → Always extract, even if hidden
- Only include parent dimension if at least one child has data

### 🔍 Special Handling:
1. **People / Time Stamped Groups (Double-Nesting):**
   - Check for `dimIds` array in prompt
   - Extract from `dimensionSelections` for structure
   - Extract from nested prompts (via `dimIds`) for actual selections
   - Use double-nesting pattern: `{type: {type: {dimensions}}}`
   - Hidden prompts in `dimIds` MUST be processed for nested dimensions

2. **Trip Groups (Triple-Nesting):**
   - Check for `dimIds` array in prompt
   - Extract from `dimensionSelections.children[].children[]` for structure
   - Extract from nested prompts (via `dimIds`) for actual selections
   - Use triple-nesting pattern: `{outerType: {middleType: {dimensions}}}`
   - Outer prompt provides `minSelection`/`maxSelection` for the entire dimension
   - Hidden prompts in `dimIds` MUST be processed for nested dimensions

3. **Extraction Source Priority:**
   - For nested dimensions (People, Time Stamped Groups, Trip Groups):
     - Structure: From `dimensionSelections` array
     - Selections: From prompts referenced in `dimIds`
   - For standard dimensions:
     - Everything from `promptData[0].allSelectedValues`

---

## 🚀 PRODUCTION Environment Setup

### Input File Specification

#### Async Payload JSON File (Required)

**Naming Convention:** Can be **ANY** `.json` file name (e.g., `assortment-optimizer-async.json`, `prod-payload.json`)

**Purpose:** Contains report execution data from production environment

**Key Attributes:**
```jsonc
// Pseudo-JSON example (comments for illustration only)
{
  "attributes": {
    "reportName": "Assortment optimizer",
    "assetId": "US-2981952",
    "reportAssetId": "US-2981952"
  },
  "reportSpec": {
    "portfolioId": "6536E2FFB89B8EB058731D40885072A0",
    /* ... */
  },
  "requestInstance": {
    "datasetLabel": "POD_Homescan_US_LT99",  // Production dataset label
    "datasetId": "508828",
    "dataViewName": "POD_Homescan_US_LT9",
    "dataViewId": "OrderId_40706",
    "productOfferingCode": "PANEL_OD_HSCN",
    "locale": "en_US",
    "prompts": [ /* dimension selections */ ]
  }
}
```

---

### Output 1: .env.production (REQUIRED)

**⚠️ Always generate this file** - Required for production environment configuration

**Data Source:** User's selection from 4 production environments

**Format:** Standard .env file format

**Content:**
```bash
# Production Environment Configuration
# Generated on: {current_date}
# Selected Environment: {PROD_US|PROD_EU|PROD_APAC|PROD_CALATAM}

BASE_URL={selected_environment_url}
ENVIRONMENT={PROD_US|PROD_EU|PROD_APAC|PROD_CALATAM}
DATASET={user_provided_dataset_name}
LOCALE=en_US
```

**Production Environment Options:**

1. **Production US** (`PROD_US`)
   - `BASE_URL=https://connect.nielseniq.com`
   - Datasets (2):
     - HS: `POD_Homescan_US_LT99`
     - OMNI: `US Exp Osh - NDH Synd Full View - 444 5 yr`

2. **Production EU** (`PROD_EU`)
   - `BASE_URL=https://eu.connect.nielseniq.com`
   - Common datasets: `POD_Homescan_GB`

3. **Production APAC** (`PROD_APAC`)
   - `BASE_URL=https://apac.connect.nielseniq.com`
   - Common datasets: `POD_Homescan_Australia_L9`

4. **Production CALATAM** (`PROD_CALATAM`)
   - `BASE_URL=https://calatam.connect.nielseniq.com`
   - Common datasets: `CANADA_HOMESCAN_CPS`

**Example Output:**
```bash
# Production Environment Configuration
# Generated on: January 22, 2026
# Selected Environment: PROD_US

BASE_URL=https://connect.nielseniq.com
ENVIRONMENT=PROD_US
DATASET=POD_Homescan_US_LT99
LOCALE=en_US
```

---

### Output 2: prod-test-data.json (REQUIRED)

**⚠️ Always generate this file** - Required for production test automation

**Data Source:** Async payload JSON file (requestInstance and reportSpec)

**Structure:**  
- For **DEV/SI/UAT** (`dev-test-data.json`): Top-level keys include a `common` section plus one or more dataset sections (for example: `POD_Homescan_US_LT99`, etc.).  
- For **PRODUCTION** (`prod-test-data.json`): There is **no `common` section**. The file contains only per-dataset sections (e.g., `POD_Homescan_US_LT99`, etc.).  
- Each dataset section in PROD has the **same internal shape** as the corresponding dataset section in DEV: it includes `navigationURL`, `sourceType`, `dataView`, `navUrlWithDataSetId`, and `dimensionSelections`.

**Quick Reference:**

| Output Field | Source in Async Payload | Transformation Rule |
|--------------|-------------------------|---------------------|
| `navigationURL` | `attributes.assetId` | Extract assetId → `/report/flow/{assetId}/{assetId}` |
| `sourceType` | `requestInstance.datasetLabel` | Derive from datasetLabel via pattern matching (Homescan/HSCN → "Panel on Demand Homescan", Omni → "Panel On Demand Omnishopper", Multi/MULTI_COUNTRY → "Panel On Demand Multi-Country") |
| `dataView` | `requestInstance.dataViewName` | Use directly |
| `navUrlWithDataSetId` | Multiple fields | `navigationURL + "/" + datasetId + "/" + dataViewId` |
| `dimensionSelections` | `requestInstance.prompts[]` | Extract non-hidden, non-empty prompts (unless hidden prompt is needed for nested dimensions) |

**Extraction Rules:**

#### navigationURL
```javascript
const assetId = asyncPayload.attributes.assetId || asyncPayload.attributes.reportAssetId;
// Example: "US-2981952"
const navigationURL = `/report/flow/${assetId}/${assetId}`;
// Result: "/report/flow/US-2981952/US-2981952"
```

#### sourceType
Based on user's dataset name answer:
- Contains "Homescan" or "HSCN" → `"Panel on Demand Homescan"`
- Contains "Omnishopper" or "Omni" → `"Panel On Demand Omnishopper"`
- Contains "Multi" or "MULTI_COUNTRY" → `"Panel On Demand Multi-Country"`
- Otherwise → Use user's dataset name as-is

#### Dimension Selections
**Follow same rules as DEV/SI/UAT:**
- ✅ INCLUDE **ALL** prompts with non-empty labels and non-empty `allSelectedValues`
- ❌ SKIP prompts with `hidden: true`, empty labels, or empty selections **unless** the hidden prompt is explicitly required by People/Time Stamped Groups (e.g., referenced via `dimIds` or nested selection requirements)
- Handle both array format and object format for `allSelectedValues`
- Generator extracts **ALL valid dimensions** from `requestInstance.prompts[]` array

**⚠️ Note:** Examples below show only 2 dimensions for brevity. Your actual async payload may have 8-15+ dimensions (Product, Retailer, Facts, Periods, Geography, Demographics, People, Trip Groups, etc.) - **all will be extracted**.

**Example prod-test-data.json:**
```json
{
  "navigationURL": "/report/flow/US-2981952/US-2981952",
  "datasets": {
    "POD_Homescan_US_LT99": {
      "sourceType": "Panel on Demand Homescan",
      "dataView": "POD_Homescan_US_LT9",
      "navUrlWithDataSetId": "/report/flow/US-2981952/US-2981952/508828/OrderId_40706",
      "dimensionSelections": [
        {
          "Universe": {
            "selections": {
              "Total US": ["Total US"]
            },
            "minSelection": "1",
            "maxSelection": "1"
          },
          "Retailer": {
            "selections": {
              "Total US": ["Total US Hdq"]
            },
            "minSelection": "1",
            "maxSelection": "10"
          }
        }
      ]
    }
  }
}
```

---

## Validation Checklist

### For Lower Environments (DEV, SI, UAT):
- [ ] Asset file has `assetId`
- [ ] All dataset files have unique `datasetLabel`
- [ ] `navigationURL` format: `/report/flow/US-{assetId}/US-{assetId}`
- [ ] `themes` excludes "panel" tags and "Report template"
- [ ] `dataSets` includes only "panel" tags
- [ ] `dimensionSelections` is an array with one object
- [ ] Hidden prompts (hidden: true) are skipped UNLESS needed for People/Time Stamped Groups
- [ ] People/Time Stamped Groups use double-nesting structure
- [ ] `minSelection` and `maxSelection` are strings
- [ ] No prompts with empty labels included
- [ ] No prompts with empty selections included
- [ ] **Note:** Same `dev-test-data.json` file works for DEV, SI, and UAT - configure BASE_URL per environment in .env

### For PRODUCTION:
- [ ] `.env.production` has correct BASE_URL for selected environment (US/EU/APAC/CALATAM)
- [ ] `.env.production` has correct ENVIRONMENT name
- [ ] `.env.production` has user-provided DATASET name
- [ ] `prod-test-data.json` has correct assetId from async payload
- [ ] `navigationURL` format: `/report/flow/{assetId}/{assetId}` (no "US-" prefix duplication)
- [ ] Dataset key matches user-provided dataset name
- [ ] `sourceType` correctly determined from dataset name
- [ ] `dimensionSelections` is an array with one object
- [ ] Hidden prompts (hidden: true) are skipped UNLESS needed for People/Time Stamped Groups
- [ ] People/Time Stamped Groups use double-nesting structure (same as DEV)
- [ ] `minSelection` and `maxSelection` are strings
- [ ] No prompts with empty labels included
- [ ] No prompts with empty selections included
- [ ] Both array and object formats handled for `allSelectedValues`

---

## ⚠️ IMPORTANT: Manual Verification Required

**Note:** The same reports exist across **DEV, SI, UAT, and PRODUCTION** environments with identical dimension structures. The validation checklist and manual verification steps apply equally to **all environments**.

**After generating the output files (dev-test-data.json for DEV/SI/UAT OR prod-test-data.json for PRODUCTION), please review and modify if needed:**

### Complex Dimension Selections May Need Adjustment (Applies to ALL Environments)

The following dimension types often require manual verification and correction in **all environments (DEV, SI, UAT, and PRODUCTION)** test data:

1. **Time Stamped Groups Selections**
   - Verify the double-nesting structure matches your test requirements
   - Check if the selection type (e.g., "Bought", "Bought from Retailer") is correct
   - Ensure inner dimensions (Product, Retailer, Time Period) have the right selections
   - **Note:** Same structure in dev-test-data.json and prod-test-data.json

2. **People Selections**
   - Confirm the nested structure aligns with your test scenario
   - Verify buyer/shopper group selections are appropriate
   - Check time period selections match your test data expectations
   - **Note:** Same structure in dev-test-data.json and prod-test-data.json

3. **Trip Groups Selections**
   - Validate the triple-nesting structure (outerType → middleType → dimensions)
   - Verify selection types (e.g., "Product Focused" → "Product in basket")
   - Ensure all nested dimensions have correct selections
   - **Note:** Same structure in dev-test-data.json and prod-test-data.json

**Why Manual Review is Necessary:**
- Automated extraction may miss context-specific requirements
- Nested structures can vary between reports (but are consistent across environments)
- Selection values might need adjustment for specific test scenarios
- Min/max selections might require tuning based on test needs
- **Same reports, same dimensions** → Same manual review needed for both DEV and PROD

**Recommendation:** Always compare the generated output with the original input file (asset.json for DEV, async payload for PROD) to ensure accuracy, especially for nested dimension structures.

---

## 🎯 Report-Specific Examples: DEV vs PROD

**CRITICAL NOTE:** The **same reports exist in both DEV and PRODUCTION** environments with **identical dimension structures**. Only the data sources and environment URLs differ.

### Common Reports Across DEV and PROD

These reports are available in all environments (DEV, SI, UAT, and all PROD regions):

1. **Assortment Optimizer** (assetId: varies by environment)
2. **Consumer Trends** reports (Product, Retailer, Shopper, Demographics)
3. **Trade Planner** reports (Table views with different pivots)
4. **Leakage Analysis**
5. **Retailer Competitive Advantage**
6. **Time-Based Spending Groups (TSBG)**
7. **Top Line Performance Kanban (TLPK)**

### Example 1: Assortment Optimizer Report

#### DEV Environment Input Files

**File 1: asset.json** (DEV Catalog)
```json
{
  "assetId": 2190291,
  "title": "Assortment optimizer",
  "launchURL": "report/flow/2190291",
  "image": "https://dcv-reporting-images-si.gfk.com/...",
  "userTags": [
    "Buyers & Shoppers",
    "panel on demand omnishopper",
    "panel on demand homescan"
  ],
  "localizations": [...]
}
```

**File 2: omni_dataset.json** (DEV Async Payload)
```json
{
  "reportSpec": {...},
  "requestInstance": {
    "datasetLabel": "Omni Agg SI 5yrs Synd",
    "datasetId": "155536",
    "dataViewName": "Entire Dataset",
    "productOfferingCode": "PANEL_OD_OMNI",
    "prompts": [
      {
        "id": "PRDC",
        "label": "Product Universe",
        "promptData": [{
          "allSelectedValues": {
            "TOTAL US": ["HEALTH & BEAUTY CARE"]
          }
        }]
      },
      {
        "id": "RTLR",
        "label": "Retailers",
        "promptData": [{
          "allSelectedValues": ["Dollar Store", "Drug Store"]
        }]
      }
    ]
  }
}
```

**DEV Output: dev-test-data.json**
```json
{
  "common": {
    "navigationURL": "/report/flow/US-2190291/US-2190291",
    "themes": ["Buyers & Shoppers"],
    "dataSets": ["panel on demand omnishopper", "panel on demand homescan"],
    "thumbnailSrc": "https://dcv-reporting-images-si.gfk.com/..."
  },
  "datasets": {
    "Omni Agg SI 5yrs Synd": {
      "sourceType": "Panel On Demand Omnishopper",
      "dataView": "Entire Dataset",
      "navUrlWithDataSetId": "/report/flow/US-2190291/US-2190291/155536/OrderId_4010",
      "dimensionSelections": [
        {
          "Product Universe": {
            "selections": {
              "TOTAL US": ["HEALTH & BEAUTY CARE"]
            },
            "minSelection": "1",
            "maxSelection": "100"
          },
          "Retailers": {
            "selections": {
              "Channel": ["Dollar Store", "Drug Store"]
            },
            "minSelection": "1",
            "maxSelection": "25"
          }
        }
      ]
    }
  }
}
```

---

#### PRODUCTION Environment Input File

**File: assortment-optimizer-prod.json** (PROD US Async Payload)
```json
{
  "attributes": {
    "reportName": "Assortment optimizer",
    "assetId": "US-2981952",
    "reportAssetId": "US-2981952"
  },
  "reportSpec": {
    "portfolioId": "6536E2FFB89B8EB058731D40885072A0",
    ...
  },
  "requestInstance": {
    "datasetLabel": "POD_Homescan_US_LT99",
    "datasetId": "508828",
    "dataViewName": "POD_Homescan_US_LT9",
    "dataViewId": "OrderId_40706",
    "productOfferingCode": "PANEL_OD_HSCN",
    "locale": "en_US",
    "prompts": [
      {
        "id": "PRDC",
        "label": "Product Universe",
        "promptData": [{
          "allSelectedValues": {
            "TOTAL US": ["HEALTH & BEAUTY CARE"]
          }
        }]
      },
      {
        "id": "RTLR",
        "label": "Retailers",
        "promptData": [{
          "allSelectedValues": ["Dollar Store", "Drug Store"]
        }]
      }
    ]
  }
}
```

**PROD Output 1: .env.production**
```bash
# Production Environment Configuration
# Generated on: February 3, 2026
# Selected Environment: PROD_US

BASE_URL=https://connect.nielseniq.com
ENVIRONMENT=PROD_US
DATASET=POD_Homescan_US_LT99
LOCALE=en_US
```

**PROD Output 2: prod-test-data.json**
```json
{
  "navigationURL": "/report/flow/US-2981952/US-2981952",
  "datasets": {
    "POD_Homescan_US_LT99": {
      "sourceType": "Panel on Demand Homescan",
      "dataView": "POD_Homescan_US_LT9",
      "navUrlWithDataSetId": "/report/flow/US-2981952/US-2981952/508828/OrderId_40706",
      "dimensionSelections": [
        {
          "Product Universe": {
            "selections": {
              "TOTAL US": ["HEALTH & BEAUTY CARE"]
            },
            "minSelection": "1",
            "maxSelection": "100"
          },
          "Retailers": {
            "selections": {
              "Channel": ["Dollar Store", "Drug Store"]
            },
            "minSelection": "1",
            "maxSelection": "25"
          }
        }
      ]
    }
  }
}
```

**Key Differences Between DEV and PROD:**

| Aspect | DEV | PRODUCTION |
|--------|-----|------------|
| **Input Files** | Asset + Dataset files (2-4 files) | Single async payload file |
| **Asset ID** | From asset.json → `2190291` | From async payload → `US-2981952` |
| **Top-level JSON structure** | `{ "navigationURL", "common", "datasets" }` | `{ "navigationURL", "datasets" }` (no `common` section) |
| **Environment URLs** | Configure in existing .env | Generate new `.env.production` |
| **Dimension Structure (inside each dataset)** | ✅ `dimensionSelections` structure (identical to DEV) | ✅ `dimensionSelections` structure (identical to DEV) |
| **Common Section** | ✅ Has themes, dataSets, thumbnailSrc | ❌ No common section (not from catalog) |

---

### Example 2: Consumer Trends (Product) Report - Same Dimensions Across Environments

#### DEV Dimension Structure
```json
"dimensionSelections": [
  {
    "Product Universe": {
      "selections": {
        "#US LOC OMNI CATEGORY MASTER": ["HEALTH & BEAUTY CARE"]
      },
      "minSelection": "1",
      "maxSelection": "500"
    },
    "Retailers": {
      "selections": {
        "Channel": ["Walmart", "Target"]
      },
      "minSelection": "1",
      "maxSelection": "25"
    },
    "Facts": {
      "selections": {
        "Units": ["Units per Buyer", "Units per Trip"]
      },
      "minSelection": "1",
      "maxSelection": "20"
    },
    "Periods": {
      "selections": {
        "Years": ["Cal Yr 2023 - w/e 12/30/23"]
      },
      "minSelection": "1",
      "maxSelection": "39"
    }
  }
]
```

#### PRODUCTION Dimension Structure
```json
"dimensionSelections": [
  {
    "Product Universe": {
      "selections": {
        "#US LOC OMNI CATEGORY MASTER": ["HEALTH & BEAUTY CARE"]
      },
      "minSelection": "1",
      "maxSelection": "500"
    },
    "Retailers": {
      "selections": {
        "Channel": ["Walmart", "Target"]
      },
      "minSelection": "1",
      "maxSelection": "25"
    },
    "Facts": {
      "selections": {
        "Units": ["Units per Buyer", "Units per Trip"]
      },
      "minSelection": "1",
      "maxSelection": "20"
    },
    "Periods": {
      "selections": {
        "Years": ["Cal Yr 2024 - w/e 12/30/24"]
      },
      "minSelection": "1",
      "maxSelection": "39"
    }
  }
]
```

**✅ Result:** Dimension structure is **100% identical** - only the actual period values differ (2023 vs 2024).

---

### Example 3: Time-Based Spending Groups (TSBG) - Complex Nested Structure

**CRITICAL:** This report has **People dimension** with nested structure - **same complexity in both DEV and PROD**.

#### DEV Input (tsbg_async.json)
```json
{
  "requestInstance": {
    "datasetLabel": "Omni Agg SI 5yrs Synd",
    "prompts": [
      {
        "id": "PPL",
        "label": "People",
        "dimIds": ["BUYGP", "PPL_PRD"],
        "promptData": [{ "allSelectedValues": [] }]
      },
      {
        "id": "BUYGP",
        "label": "Buyer Group",
        "hidden": true,
        "promptData": [{
          "allSelectedValues": {
            "TOTAL US": ["HEALTH & BEAUTY CARE"]
          }
        }]
      },
      {
        "id": "PPL_PRD",
        "label": "People Period",
        "hidden": true,
        "promptData": [{
          "allSelectedValues": {
            "Quarters": ["JFM 23 - w/e 4/1/23"]
          }
        }]
      }
    ],
    "dimensionSelections": [
      {
        "id": "PPL",
        "children": [{
          "label": "Bought"
        }]
      }
    ]
  }
}
```

#### PROD Input (tsbg_prod.json)
```json
{
  "attributes": {
    "assetId": "US-2789227"
  },
  "requestInstance": {
    "datasetLabel": "POD_Omnishopper_US_Prod",
    "prompts": [
      {
        "id": "PPL",
        "label": "People",
        "dimIds": ["BUYGP", "PPL_PRD"],
        "promptData": [{ "allSelectedValues": [] }]
      },
      {
        "id": "BUYGP",
        "label": "Buyer Group",
        "hidden": true,
        "promptData": [{
          "allSelectedValues": {
            "TOTAL US": ["HEALTH & BEAUTY CARE"]
          }
        }]
      },
      {
        "id": "PPL_PRD",
        "label": "People Period",
        "hidden": true,
        "promptData": [{
          "allSelectedValues": {
            "Quarters": ["JFM 24 - w/e 4/1/24"]
          }
        }]
      }
    ],
    "dimensionSelections": [
      {
        "id": "PPL",
        "children": [{
          "label": "Bought"
        }]
      }
    ]
  }
}
```

#### Both DEV and PROD Output Structure (Identical)
```json
"People": {
  "selections": [
    {
      "Bought": {
        "Bought": {
          "Product": {
            "selections": {
              "TOTAL US": ["HEALTH & BEAUTY CARE"]
            },
            "minSelection": "1",
            "maxSelection": "100"
          },
          "Time Period": {
            "selections": {
              "Quarters": ["JFM 23 - w/e 4/1/23"]  // DEV: 2023, PROD: 2024
            },
            "minSelection": "1",
            "maxSelection": "13"
          }
        }
      }
    }
  ],
  "minSelection": "1",
  "maxSelection": "1"
}
```

**✅ Extraction Algorithm:** **Exactly the same** for DEV and PROD
- Both check for `dimIds` array
- Both extract from `dimensionSelections` for structure
- Both process hidden prompts (BUYGP, PPL_PRD)
- Both use double-nesting pattern

---

### Example 4: Production Environment Variations (Same Report, Different Regions)

**Assortment Optimizer in 4 Production Regions:**

#### 1. PROD_US
```bash
# .env.production
BASE_URL=https://connect.nielseniq.com
ENVIRONMENT=PROD_US
DATASET=POD_Homescan_US_LT99
```
```json
// prod-test-data.json
{
  "navigationURL": "/report/flow/US-2981952/US-2981952",
  "datasets": {
    "POD_Homescan_US_LT99": {
      "sourceType": "Panel on Demand Homescan",
      ...
    }
  }
}
```

#### 2. PROD_EU
```bash
# .env.production
BASE_URL=https://eu.connect.nielseniq.com
ENVIRONMENT=PROD_EU
DATASET=POD_Homescan_GB
```
```json
// prod-test-data.json
{
  "navigationURL": "/report/flow/GB-2981952/GB-2981952",
  "datasets": {
    "POD_Homescan_GB": {
      "sourceType": "Panel on Demand Homescan",
      ...
    }
  }
}
```

#### 3. PROD_APAC
```bash
# .env.production
BASE_URL=https://apac.connect.nielseniq.com
ENVIRONMENT=PROD_APAC
DATASET=POD_Homescan_Australia_L9
```
```json
// prod-test-data.json
{
  "navigationURL": "/report/flow/AU-2981952/AU-2981952",
  "datasets": {
    "POD_Homescan_Australia_L9": {
      "sourceType": "Panel on Demand Homescan",
      ...
    }
  }
}
```

#### 4. PROD_CALATAM
```bash
# .env.production
BASE_URL=https://calatam.connect.nielseniq.com
ENVIRONMENT=PROD_CALATAM
DATASET=CANADA_HOMESCAN_CPS
```
```json
// prod-test-data.json
{
  "navigationURL": "/report/flow/CA-2981952/CA-2981952",
  "datasets": {
    "CANADA_HOMESCAN_CPS": {
      "sourceType": "Panel on Demand Homescan",
      ...
    }
  }
}
```

**Pattern:** Same report, same dimensions, only BASE_URL and dataset names differ by region.

---

### Summary: DEV vs PROD Comparison

| Feature | DEV/SI/UAT | PRODUCTION |
|---------|------------|------------|
| **Reports Available** | All 25+ report types | Same 25+ report types |
| **Dimension Structure** | Standard + Nested (People, Trip Groups) | **Identical** structure |
| **Extraction Logic** | Same algorithm for all dimensions | **Exactly same** algorithm |
| **Input Format** | Asset + Dataset files | Async payload only |
| **Output Files** | `dev-test-data.json` | `prod-test-data.json` + `.env.production` |
| **Manual Review Needed** | ✅ Complex dimensions (People, Trip Groups) | ✅ **Same** complex dimensions |
| **Environment URLs** | Configure in existing .env | Generate new `.env.production` |
| **Test Framework Support** | ✅ Full support | ✅ Full support (same test files) |

**CRITICAL TAKEAWAY:** 
- ✅ Same reports → Same dimensions → Same test logic
- ✅ Only environment URLs and dataset names differ
- ✅ Same extraction algorithm works for both DEV and PROD
- ✅ Same manual verification needed for nested structures
- ✅ Test automation code remains unchanged between environments

---

## Usage Examples

### Generate Only dev-test-data.json

```javascript
const assetFile = require('./asset.json');
const omniDataset = require('./tsbg_async.json');

const results = generateTestData(
  assetFile,
  [omniDataset],
  {
    generateLocalizationData: false,  // Do NOT generate localization-data.json
    outputDir: './test-data'
  }
);
```

### Generate Both Files

```javascript
const assetFile = require('./asset.json');
const omniDataset = require('./tsbg_async.json');

const results = generateTestData(
  assetFile,
  [omniDataset],
  {
    generateLocalizationData: true,  // YES, generate localization-data.json
    outputDir: './test-data'
  }
);
```

---

**End of Guide**
