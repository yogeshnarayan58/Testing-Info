/** A single configurable action shown in the selection action bar. */
export interface SurveyActionItem<T = unknown, TId extends string = string> {
  id: TId;
  label: string;
  iconName: string;
  /** Decides whether the action is shown for the current selection; visible when omitted. */
  isVisible?: (selectedItems: readonly T[]) => boolean;
}

export interface SurveyActionItemClickEvent<T = unknown, TId extends string = string> {
  actionId: TId;
  items: readonly T[];
}
