import { SurveyLocalizationData } from '../interfaces/iLocalizationData';

export function getTestDataByLocale<T extends SurveyLocalizationData>(locale: string, data: T[]): T {
  const entry = data.find((item) => item.locale === locale);
  if (!entry) {
    throw new Error(`Locale '${locale}' not found`);
  }
  return entry;
}
