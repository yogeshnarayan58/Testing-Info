import { describe, expect, it, vi } from 'vitest';
import { MY_ASSETS_TABS } from './features/my-assets/constants/my-assets-tabs.constant';
import { myAssetsRoutes, SURVEY_MOD_ROUTES } from './survey-mod.routes';

vi.mock('./features/survey-model-validator/components/generate-survey/generate-survey.component', () => ({
  GenerateSurveyComponent: class GenerateSurveyComponent {},
}));

vi.mock('./shared/common/guards/published-survey-results.guard', () => ({
  redirectPublishedSurveyEditsGuard: vi.fn(),
  redirectUnpublishedSurveyResultsGuard: vi.fn(),
}));

describe('survey routes', () => {
  it('loads the validator directly without the deleted shell', async () => {
    const route = SURVEY_MOD_ROUTES.find(candidate => candidate.path === 'model-validator');
    const { GenerateSurveyComponent } = await import('./features/survey-model-validator/components/generate-survey/generate-survey.component');

    expect(route).toMatchObject({ pathMatch: 'full', loadComponent: expect.any(Function) });
    expect(route).not.toHaveProperty('children');
    if (!route?.loadComponent) throw new Error('Missing validator loader');
    expect(await route.loadComponent()).toBe(GenerateSurveyComponent);
  });

  it('registers My Assets routes before the scratch-flow fallback without duplicate paths', () => {
    const fallbackIndex = SURVEY_MOD_ROUTES.findIndex(route => route.data?.['flowType'] === 'scratch');
    expect(fallbackIndex).toBeGreaterThan(0);
    for (const route of myAssetsRoutes) {
      const index = SURVEY_MOD_ROUTES.indexOf(route);
      expect(index).toBeGreaterThan(0);
      expect(index).toBeLessThan(fallbackIndex);
    }
    const paths = SURVEY_MOD_ROUTES.filter(route => route.path).map(route => route.path);
    expect(new Set(paths).size).toBe(paths.length);
  });

  it('loads the homepage at the survey root', () => {
    expect(SURVEY_MOD_ROUTES[0]).toMatchObject({
      path: '',
      pathMatch: 'full',
      loadComponent: expect.any(Function),
    });
    expect(SURVEY_MOD_ROUTES[0]).not.toHaveProperty('redirectTo');
  });

  it.each([
    [`${MY_ASSETS_TABS.MY_ASSETS}/folder/:folderId`, MY_ASSETS_TABS.MY_ASSETS],
    [`${MY_ASSETS_TABS.SHARED_WITH_ME}/folder/:folderId`, MY_ASSETS_TABS.SHARED_WITH_ME],
    [`${MY_ASSETS_TABS.TRASH}/folder/:folderId`, MY_ASSETS_TABS.TRASH],
  ])('registers folder route %s for tab %s', (path, tabId) => {
    expect(myAssetsRoutes).toContainEqual(expect.objectContaining({
      path,
      pathMatch: 'full',
      data: { tabId },
      loadComponent: expect.any(Function),
    }));
  });
});