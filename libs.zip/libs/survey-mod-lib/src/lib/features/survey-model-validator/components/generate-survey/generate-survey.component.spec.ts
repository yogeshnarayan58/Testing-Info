/// <reference types="vite/client" />

import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of, Subject, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { QuestionTypes } from '../../../build-survey/models/build-survey';
import { SurveyModelValidatorService } from '../../services/survey-model-validator.service';
import { GenerateSurveyComponent } from './generate-survey.component';
import generateSurveyTemplate from './generate-survey.component.html?raw';

@Pipe({
  name: 'translate',
  standalone: true,
})
class MockTranslatePipe implements PipeTransform {
  transform(key: any): any {
    return key;
  }
}

const createMockTranslateService = () => {
  const mockSubject = {
    subscribe: () => ({ unsubscribe: () => {} }),
    unsubscribe: () => {},
  };
  const translations: { [key: string]: string } = {
    'SURVEYMOD_QUESTION': 'Question',
    'SURVEYMOD_FOLDER_CREATION_FAILED': 'Failed to create folder. Please try again.',
    'SURVEYMOD_ERROR': 'Error',
  };
  return {
    instant: (key: string) => translations[key] ?? key ?? '',
    get: (key: string) => of(key),
    setDefaultLanguage: () => {},
    use: () => of({}),
    onLangChange: mockSubject,
    onTranslationChange: mockSubject,
    defaultLanguage: 'en',
    currentLanguage: 'en',
  };
};

describe('GenerateSurveyComponent', () => {
  let mockTranslateService: any;

  const createComponent = (render = false) => {
    mockTranslateService = createMockTranslateService();
    const validatorService = {
      extractPrompts: vi.fn().mockReturnValue(of({
        generateQuestionSystemPrompt: 'Loaded generation prompt',
        validateSurveySystemPrompt: 'Loaded validation prompt',
      })),
      generateQuestions: vi.fn(),
      generateAndValidateSurvey: vi.fn(),
      validateSurveyWithPrompt: vi.fn(),
      validateQuestions: vi.fn().mockReturnValue({ valid: true, issueCount: 0, issues: [] }),
    };

    const imports = render ? [TranslateModule.forRoot()] : [];
    const providers = [
      { provide: TranslateService, useValue: mockTranslateService },
      { provide: SurveyModelValidatorService, useValue: validatorService },
    ];

    TestBed.configureTestingModule({
      imports,
      providers,
    });

    const template = render ? generateSurveyTemplate : '<div></div>';
    const componentImports = render ? [NgTemplateOutlet, MockTranslatePipe] : [MockTranslatePipe];

    TestBed.overrideComponent(GenerateSurveyComponent, {
      set: {
        template,
        templateUrl: undefined,
        styleUrl: undefined,
        imports: componentImports,
        schemas: render ? [NO_ERRORS_SCHEMA] : undefined,
      },
    });

    const fixture = TestBed.createComponent(GenerateSurveyComponent);
    const component = fixture.componentInstance;

    if (render) {
      fixture.detectChanges();
    }

    return { component, validatorService, fixture };
  };

  const fillGenerationFields = (component: GenerateSurveyComponent) => {
    component.product = 'ABRASIVE CLEANSERS';
    component.retailer = 'Total Outlets';
    component.demographic = 'Total Panel';
    component.geography = 'Total US';
    component.period = 'Latest 52 Weeks';
    component.userPrompt = 'Generate few questions on the effectiveness of the product(s)';
    component.generationSystemPrompt.set('Generation system prompt');
    component.validationSystemPrompt.set('Validation system prompt');
  };

  const fillValidationCriteria = (component: GenerateSurveyComponent) => {
    component.product = 'Abrasive cleaners';
    component.retailer = 'All retailers';
    component.demographic = 'Adults 18-45';
    component.geography = 'United States';
    component.period = 'Last 30 days';
  };

  it.each([
    { field: 'generationSystemPrompt', label: 'Generation system prompt' },
    { field: 'validationSystemPrompt', label: 'Validation system prompt' },
  ] as const)('blocks the combined request when $label is blank', ({ field, label }) => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    component.onTabChange('both');
    component[field].set('   ');

    expect(component.isActionDisabled).toBe(true);
    component.onGenerateQuestions({ questionCount: 2, questionTypes: [] });

    expect(validatorService.generateAndValidateSurvey).not.toHaveBeenCalled();
    expect(component.errorMessage()).toBe(`${label} is required.`);
    component[field].set('Custom prompt');
    expect(component.isActionDisabled).toBe(false);
  });

  it.each(['generate', 'both'] as const)('dispatches the %s action through the question generator', (tab) => {
    const { component } = createComponent();
    fillGenerationFields(component);
    component.onTabChange(tab);
    const generator = { questionCount: 3, onGenerateQuestions: vi.fn() };
    Reflect.set(component, 'questionGenerator', generator);

    component.onAction();

    expect(generator.onGenerateQuestions).toHaveBeenCalledOnce();
  });

  it('safely ignores a generation action before the child generator is available', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);

    expect(() => component.onAction()).not.toThrow();
    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
    expect(validatorService.generateAndValidateSurvey).not.toHaveBeenCalled();
  });

  it('dispatches the validation action without generating questions', () => {
    const { component, validatorService } = createComponent();
    component.onTabChange('validate');
    fillValidationCriteria(component);
    validatorService.validateSurveyWithPrompt.mockReturnValue(of({ result: [] }));

    component.onAction();

    expect(validatorService.validateSurveyWithPrompt).toHaveBeenCalledOnce();
    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
    expect(validatorService.generateAndValidateSurvey).not.toHaveBeenCalled();
  });

  it('imports JSON questions as the edited final list with generated IDs and order', () => {
    const { component } = createComponent();
    component.onTabChange('validate');
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();
    component.bulkJsonText.set(JSON.stringify([
      {
        question: 'How likely are you to recommend us?',
        type: QuestionTypes.NetPromoterScore,
        npsLeftLabel: 'Not at all likely',
        npsRightLabel: 'Extremely likely',
        isRequired: true,
      },
      {
        question: 'How often do you use the product?',
        type: QuestionTypes.MultiplePointScale,
        rowOptions: ['Feature A'],
        columnOptions: ['Never', 'Often'],
        isRequired: false,
      },
    ]));

    component.importBulkQuestionsFromJson();

    expect(component.validationQuestions()).toHaveLength(2);
    expect(component.validationQuestions()).toEqual([
      expect.objectContaining({
        id: 'q_1', order: 1, type: QuestionTypes.NetPromoterScore,
        npsLeftLabel: 'Not at all likely', npsRightLabel: 'Extremely likely', isRequired: true,
      }),
      expect.objectContaining({
        id: 'q_2', order: 2, type: QuestionTypes.MultiplePointScale,
        rowOptions: ['Feature A'], columnOptions: ['Never', 'Often'], isRequired: false,
      }),
    ]);
    expect(component.bulkQuestionError()).toBeNull();
    expect(component.bulkQuestionDrafts()).toEqual([]);
  });

  it('opens with editable existing questions and applies edits and removals only after confirmation', () => {
    const { component } = createComponent();
    component.addValidationQuestion();
    component.updateValidationQuestion(0, 'question', 'Original first question');
    component.updateValidationQuestion(1, 'question', 'Original second question');
    const originalQuestions = component.validationQuestions();

    component.openBulkQuestionDialog();

    expect(component.bulkQuestionDrafts()).toEqual(originalQuestions);
    component.updateBulkQuestionDraft(0, 'question', 'Edited first question');
    component.removeBulkQuestionDraft(1);
    expect(component.validationQuestions()).toEqual(originalQuestions);
    component.commitBulkQuestions();

    expect(component.validationQuestions()).toEqual([
      expect.objectContaining({ id: 'q_1', order: 1, question: 'Edited first question' }),
    ]);
  });

  it('discards edits and removals of existing questions when the bulk popup is cancelled', () => {
    const { component } = createComponent();
    component.addValidationQuestion();
    const originalQuestions = component.validationQuestions();
    component.openBulkQuestionDialog();
    component.updateBulkQuestionDraft(0, 'question', 'Unsaved edit');
    component.removeBulkQuestionDraft(1);

    component.closeBulkQuestionDialog();

    expect(component.validationQuestions()).toEqual(originalQuestions);
  });

  it('keeps Bulk Update available at 10 questions for editing and removing existing questions', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    const question = component.validationQuestions()[0];
    component.validationQuestions.set(Array.from({ length: 10 }, (_, index) => ({
      ...question,
      id: `q_${index + 1}`,
      order: index + 1,
      question: `Question ${index + 1}`,
    })));
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;
    const bulkUpdateButton = Array.from(element.querySelectorAll<HTMLElement>('niq-button')).find((button) =>
      button.textContent?.trim() === 'Bulk Update',
    );

    expect(bulkUpdateButton).toBeDefined();
    expect(Reflect.get(bulkUpdateButton!, 'disabled')).not.toBe(true);
    bulkUpdateButton!.click();
    fixture!.detectChanges();
    expect(component.bulkQuestionDrafts()).toHaveLength(10);
  });

  it('rejects invalid JSON or invalid question fields without appending any questions', () => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.bulkJsonText.set('[not valid json');

    component.importBulkQuestionsFromJson();

    expect(component.validationQuestionCount).toBe(1);
    expect(component.bulkQuestionError()).toContain('valid JSON');
    component.bulkJsonText.set(JSON.stringify([{
      question: 'A question without required status', type: QuestionTypes.SingleChoice,
    }]));

    component.importBulkQuestionsFromJson();

    expect(component.validationQuestionCount).toBe(1);
    expect(component.bulkQuestionError()).toContain('isRequired');
  });

  it('rejects a JSON array larger than the total question limit without partial import', () => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.bulkJsonText.set(JSON.stringify(Array.from({ length: 11 }, (_, index) => ({
      question: `Imported question ${index + 1}`,
      type: QuestionTypes.SingleChoice,
      isRequired: false,
    }))));

    component.importBulkQuestionsFromJson();

    expect(component.validationQuestionCount).toBe(1);
    expect(component.bulkQuestionError()).toContain('10 questions total');
  });

  it.each([
    { input: '[not valid json', message: 'valid JSON' },
    { input: JSON.stringify({ question: 'Not an array' }), message: 'non-empty array' },
    { input: '[]', message: 'non-empty array' },
    { input: JSON.stringify([{ question: 'No type', isRequired: true }]), message: 'question type' },
    { input: JSON.stringify([{ question: 'No required flag', type: QuestionTypes.SingleChoice }]), message: 'isRequired' },
    { input: JSON.stringify([{ question: 'Wrong flag', type: QuestionTypes.SingleChoice, isRequired: 'false' }]), message: 'isRequired' },
    { input: JSON.stringify([{ question: 'Wrong options', type: QuestionTypes.SingleChoice, options: [1], isRequired: false }]), message: 'options' },
    { input: JSON.stringify([{ question: 'Unknown field', type: QuestionTypes.SingleChoice, isRequired: false, id: 'custom' }]), message: 'unsupported field' },
    { input: JSON.stringify(Array.from({ length: 11 }, (_, index) => ({
      question: `Question ${index + 1}`, type: QuestionTypes.SingleChoice, isRequired: false,
    }))), message: '10 questions total' },
  ])('disables JSON import for invalid input: $message', ({ input, message }) => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();
    component.bulkJsonText.set(input);

    expect(component.isBulkJsonImportDisabled).toBe(true);
    expect(component.bulkJsonValidationError).toContain(message);
  });

  it('enables JSON import only after every question passes validation', () => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();
    component.bulkJsonText.set('');
    expect(component.isBulkJsonImportDisabled).toBe(true);
    expect(component.bulkJsonValidationError).toBeNull();
    component.bulkJsonText.set('   ');
    expect(component.isBulkJsonImportDisabled).toBe(true);
    expect(component.bulkJsonValidationError).toBeNull();
    component.bulkJsonText.set(JSON.stringify([{
      question: 'Valid question', type: QuestionTypes.SingleChoice, isRequired: false,
    }]));

    expect(component.isBulkJsonImportDisabled).toBe(false);
    expect(component.bulkJsonValidationError).toBeNull();
  });

  it('renders the JSON paste mode and imports questions from the popup', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    component.openBulkQuestionDialog();
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;
    const pasteButton = Array.from(element.querySelectorAll<HTMLElement>('niq-button')).find((button) =>
      button.textContent?.trim() === 'Bulk Edit',
    );
    expect(pasteButton).toBeDefined();
    pasteButton!.click();
    fixture!.detectChanges();
    const jsonInput = element.querySelector<HTMLTextAreaElement>('#bulk-question-json');
    expect(jsonInput).not.toBeNull();
    const typeHint = element.querySelector('.bulk-question-type-hint');
    const typeDropdown = element.querySelector('#bulk-question-type-template');
    expect(typeHint?.textContent).toContain('Select a type to add a question with example answers.');
    expect(typeHint?.parentElement?.classList.contains('bulk-json-heading-row')).toBe(true);
    expect(typeDropdown?.parentElement?.classList.contains('bulk-json-toolbar')).toBe(true);
    expect(JSON.parse(jsonInput!.value)).toEqual([
      expect.objectContaining({
        question: 'How would you rate the overall performance of the product?',
        type: QuestionTypes.SingleChoice,
        options: ['Excellent', 'Good', 'Fair', 'Poor'],
        isRequired: true,
      }),
    ]);
    const importButton = Array.from(element.querySelectorAll<HTMLElement>('niq-button')).find((button) =>
      button.textContent?.trim() === 'Save',
    );
    expect(importButton).toBeDefined();
    expect(Reflect.get(importButton!, 'disabled')).toBe(false);
    jsonInput!.value = JSON.stringify([{
      question: 'Which feature do you use most?',
      type: QuestionTypes.MultipleChoice,
      options: ['Feature A', 'Feature B'],
      isRequired: false,
    }]);
    jsonInput!.dispatchEvent(new Event('input', { bubbles: true }));
    fixture!.detectChanges();
    expect(Reflect.get(importButton!, 'disabled')).toBe(false);
    importButton!.click();
    fixture!.detectChanges();

    expect(component.validationQuestions()[0]).toMatchObject({
      id: 'q_1', type: QuestionTypes.MultipleChoice, isRequired: false,
      options: ['Feature A', 'Feature B'],
    });
  });

  it('resets the type selector so the same sample can be inserted consecutively', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();
    fixture!.detectChanges();
    const element = fixture!.nativeElement as HTMLElement;
    const typeSelector = element.querySelector<HTMLSelectElement>('#bulk-question-type-template')!;

    for (let insertion = 0; insertion < 2; insertion++) {
      typeSelector.value = QuestionTypes.MultipleChoice;
      typeSelector.dispatchEvent(new Event('change', { bubbles: true }));
      fixture!.detectChanges();
      expect(typeSelector.value).toBe('');
    }

    expect(JSON.parse(component.bulkJsonText())).toHaveLength(3);
  });

  it('validates JSON and updates form drafts when returning from JSON mode', () => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();
    component.bulkJsonText.set(JSON.stringify([
      { question: 'Edited first question', type: QuestionTypes.SingleChoice, isRequired: true },
      { question: 'Added second question', type: QuestionTypes.MultipleChoice, isRequired: false },
    ]));

    component.toggleBulkEntryMode();

    expect(component.bulkEntryMode()).toBe('form');
    expect(component.bulkQuestionDrafts()).toMatchObject([
      { question: 'Edited first question', type: QuestionTypes.SingleChoice, isRequired: true },
      { question: 'Added second question', type: QuestionTypes.MultipleChoice, isRequired: false },
    ]);

    component.toggleBulkEntryMode();
    component.bulkJsonText.set('[invalid');
    component.toggleBulkEntryMode();

    expect(component.bulkEntryMode()).toBe('json');
    expect(component.bulkQuestionError()).toContain('valid JSON');
  });

  it('renders the model type in a newly added validation question select', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    const existingQuestion = component.validationQuestions()[0];
    component.validationQuestions.set([...component.validationQuestions(), {
      ...existingQuestion,
      id: 'q_2',
      order: 2,
      question: 'Which brands have you purchased?',
      type: QuestionTypes.MultipleChoice,
    }]);
    fixture!.detectChanges();
    const element = fixture!.nativeElement as HTMLElement;
    const typeSelect = element.querySelector<HTMLSelectElement>('#type-1')!;

    expect(typeSelect.selectedOptions[0].textContent).toBe('SURVEYMOD_MULTIPLE_CHOICE');
  });

  it('renders the model type in a newly added bulk draft select', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    component.openBulkQuestionDialog();
    component.updateBulkQuestionDraft(0, 'type', QuestionTypes.MultipleChoice);
    fixture!.detectChanges();
    const element = fixture!.nativeElement as HTMLElement;
    const typeSelect = element.querySelector<HTMLSelectElement>('#bulk-type-0')!;

    expect(typeSelect.selectedOptions[0].textContent).toBe('SURVEYMOD_MULTIPLE_CHOICE');
  });

  it.each([
    [QuestionTypes.SingleChoice, 'Which product feature do you value most?', ['Quality', 'Price', 'Design', 'Ease of use']],
    [QuestionTypes.MultipleChoice, 'Which of these brands have you purchased recently?', ['Brand A', 'Brand B', 'Brand C', 'Other']],
    [QuestionTypes.StarRating, 'How would you rate your overall experience?', undefined],
    [QuestionTypes.NetPromoterScore, 'How likely are you to recommend us to a friend or colleague?', undefined],
    [QuestionTypes.SinglePointScale, 'How satisfied are you with each product feature?', undefined],
    [QuestionTypes.MultiplePointScale, 'How often do you use each product feature?', undefined],
  ] as const)('adds the matching %s sample question to the editable JSON', (type, questionText, options) => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();

    component.addBulkQuestionTemplate(type);

    const questions = JSON.parse(component.bulkJsonText()) as Array<Record<string, unknown>>;
    expect(questions).toHaveLength(2);
    expect(questions[1]).toMatchObject({ question: questionText, type });
    if (options) expect(questions[1]['options']).toEqual(options);
    expect(component.validationQuestionCount).toBe(1);
  });

  it('disables the JSON question type selector when the JSON list reaches 10', () => {
    const { component } = createComponent();
    component.openBulkQuestionDialog();
    component.toggleBulkEntryMode();

    for (let index = 0; index < 9; index++) {
      component.addBulkQuestionTemplate(QuestionTypes.SingleChoice);
    }

    expect(JSON.parse(component.bulkJsonText())).toHaveLength(10);
    expect(component.isBulkQuestionTemplateDisabled).toBe(true);
  });

  it('removes only the selected question while retaining the remaining question details', () => {
    const { component } = createComponent();
    component.addValidationQuestion();
    component.addValidationQuestion();
    const original = component.validationQuestions();

    component.removeValidationQuestion(1);

    expect(component.validationQuestions()).toEqual([
      original[0],
      { ...original[2], id: 'q_2', order: 2 },
    ]);
    expect(component.validationQuestionCount).toBe(2);
  });

  it.each([
    { type: 'UNRECOGNIZED_TYPE', label: 'UNRECOGNIZED_TYPE' },
    { type: undefined, label: 'Question' },
  ])('uses "$label" for an unrecognized or missing question type', ({ type, label }) => {
    const { component } = createComponent();

    expect(component.typeLabel(type)).toBe(label);
  });

  it('uses workflow buttons with an accessible pressed state instead of broken tab relationships', () => {
    const { component, fixture } = createComponent(true);
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;
    const buttons = element.querySelectorAll<HTMLButtonElement>('.workflow-tab');

    expect(buttons[0].getAttribute('aria-pressed')).toBe('true');
    expect(element.querySelector('[role="tab"], [role="tablist"], [aria-controls]')).toBeNull();
    buttons[1].click();
    fixture!.detectChanges();
    expect(component.activeTab()).toBe('validate');
    expect(buttons[0].getAttribute('aria-pressed')).toBe('false');
    expect(buttons[1].getAttribute('aria-pressed')).toBe('true');
  });

  it('updates supported scalar fields without changing question IDs or answer lists', () => {
    const { component } = createComponent();
    const original = component.validationQuestions()[0];

    component.updateValidationQuestion(0, 'question', 'How likely are you to recommend this product?');
    component.updateValidationQuestion(0, 'type', QuestionTypes.NetPromoterScore);
    component.updateValidationQuestion(0, 'isRequired', false);
    component.updateValidationQuestion(0, 'reviewRequired', false);
    component.updateValidationQuestion(0, 'npsLeftLabel', 'Not likely');
    component.updateValidationQuestion(0, 'npsRightLabel', 'Very likely');

    expect(component.validationQuestions()[0]).toEqual({
      ...original,
      question: 'How likely are you to recommend this product?',
      type: QuestionTypes.NetPromoterScore,
      isRequired: false,
      reviewRequired: false,
      npsLeftLabel: 'Not likely',
      npsRightLabel: 'Very likely',
    });
  });

  it('retains editor rows when question content changes', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    fillValidationCriteria(component);
    component.addValidationQuestion();
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;
    const rows = element.querySelectorAll('.question-editor');

    component.updateValidationQuestion(0, 'question', 'Edited first question');
    component.updateValidationQuestion(1, 'question', 'Edited second question');
    fixture!.detectChanges();

    const updatedRows = element.querySelectorAll('.question-editor');
    expect(updatedRows[0]).toBe(rows[0]);
    expect(updatedRows[1]).toBe(rows[1]);
    expect(component.isActionDisabled).toBe(false);
  });

  it.each(['generate', 'both'] as const)('renders local structural warnings in %s results', (tab) => {
    const { component, fixture } = createComponent(true);
    component.onTabChange(tab);
    const result = {
      surveyTitle: 'Survey', questions: [], validation: null,
      localValidation: { valid: false, issueCount: 1, issues: [] }, responseJson: '{}',
    };
    if (tab === 'both') component.combinedWorkflowResult.set(result);
    else component.generateWorkflowResult.set(result);
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;

    expect(element.querySelector('.validation-summary.invalid')?.textContent).toContain('1 local structure issue(s) found.');
    if (tab === 'both') {
      expect(element.querySelector('.action-note')?.textContent).toContain('One combined generation and validation call');
    }
  });

  it('edits single-point scale rows and columns and sends the same fields for validation', () => {
    const { component, fixture, validatorService } = createComponent(true);
    component.onTabChange('validate');
    fillValidationCriteria(component);
    component.updateValidationQuestion(0, 'type', QuestionTypes.SinglePointScale);
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;
    const rows = element.querySelector<HTMLTextAreaElement>('#rows-0')!;
    const columns = element.querySelector<HTMLTextAreaElement>('#columns-0')!;
    expect(rows).not.toBeNull();
    expect(columns).not.toBeNull();
    expect(element.querySelector('#options-0')).toBeNull();
    rows.value = 'Cleaning performance';
    rows.dispatchEvent(new Event('input'));
    columns.value = 'Excellent\nPoor';
    columns.dispatchEvent(new Event('input'));
    validatorService.validateSurveyWithPrompt.mockReturnValue(of({ result: [] }));

    component.onValidateQuestions();

    expect(validatorService.validateSurveyWithPrompt).toHaveBeenCalledWith({
      survey: expect.objectContaining({
        questions: [expect.objectContaining({
          type: QuestionTypes.SinglePointScale,
          rowOptions: ['Cleaning performance'], columnOptions: ['Excellent', 'Poor'],
        })],
      }),
    });
    fixture!.detectChanges();
    expect(element.querySelector('.matrix-preview')?.textContent).toContain('Cleaning performance');
    expect(element.querySelector('.matrix-preview')?.textContent).toContain('Excellent');
  });

  it.each(['generate', 'validate', 'both'] as const)('renders multiple unnumbered questions in %s results', (tab) => {
    const { component, fixture } = createComponent(true);
    component.onTabChange(tab);
    const questions = ['First question?', 'Second question?'].map((question) => ({
      question, type: QuestionTypes.SingleChoice, isRequired: true, options: ['Yes', 'No'],
    }));
    const result = { surveyTitle: 'Survey', questions, validation: null, localValidation: null, responseJson: '{}' };
    if (tab === 'generate') component.generateWorkflowResult.set(result);
    else if (tab === 'validate') component.validateWorkflowResult.set(result);
    else component.combinedWorkflowResult.set(result);
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;

    expect(element.querySelectorAll('.question-result-card')).toHaveLength(2);
    expect(Array.from(element.querySelectorAll('.result-number'), (number) => number.textContent?.trim())).toEqual(['1', '2']);
  });

  it.each(['SKIPPED', 'UNAVAILABLE'] as const)('keeps generated questions visible when validation is %s', (status) => {
    const { component, fixture, validatorService } = createComponent(true);
    fillGenerationFields(component);
    component.onTabChange('both');
    const question = {
      id: 'q_1', order: 1, question: 'How effective is the product?',
      type: QuestionTypes.SingleChoice, isRequired: true, options: ['Very', 'Not at all'],
    };
    validatorService.generateAndValidateSurvey.mockReturnValue(of({
      title: 'Generated survey', validation: { status }, result: [question],
    }));

    component.onGenerateQuestions({ questionCount: 1, questionTypes: [] });
    fixture!.detectChanges();
    const result = component.combinedWorkflowResult()!;
    const element: HTMLElement = fixture!.nativeElement;

    expect(element.querySelector('.question-result-heading')?.textContent).toContain(question.question);
    expect(element.querySelector('.run-summary')?.textContent).toContain(status === 'SKIPPED' ? 'validation skipped' : 'validation unavailable');
    expect(element.querySelector('.question-feedback')?.textContent).toContain(status === 'SKIPPED' ? 'Validation skipped' : 'Validation unavailable');
    expect(component.reviewedCount(result)).toBe(0);
    expect(component.unreviewedCount(result)).toBe(1);
    expect(element.querySelector('.result-status.approved, .no-suggestions')).toBeNull();
    expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
    expect(component.isGenerating()).toBe(false);
    expect(component.isValidating()).toBe(false);
  });

  it('loads the system prompt on initialization and leaves it editable', () => {
    const { component, validatorService } = createComponent();

    component.ngOnInit();

    expect(validatorService.extractPrompts).toHaveBeenCalledOnce();
    expect(component.systemPrompt()).toBe('Loaded generation prompt');
    component.onSystemPromptChange('Edited generation prompt');
    component.onTabChange('validate');
    expect(component.systemPrompt()).toBe('Loaded validation prompt');
    component.onSystemPromptChange('Edited validation prompt');
    component.onTabChange('both');
    expect(component.systemPrompt()).toBe('Edited generation prompt');
    expect(component.validationSystemPrompt()).toBe('Edited validation prompt');
  });

  it('does not overwrite typing with a late system-prompt response', () => {
    const { component, validatorService } = createComponent();
    const pending = new Subject<{ generateQuestionSystemPrompt: string; validateSurveySystemPrompt: string }>();
    validatorService.extractPrompts.mockReturnValue(pending.asObservable());
    component.ngOnInit();
    component.onSystemPromptChange('My own prompt');

    pending.next({ generateQuestionSystemPrompt: 'Server generation prompt', validateSurveySystemPrompt: 'Server validation prompt' });

    expect(component.systemPrompt()).toBe('My own prompt');
    expect(component.validationSystemPrompt()).toBe('Server validation prompt');
  });

  it('allows manual entry if loading the system prompt fails', () => {
    const { component, validatorService } = createComponent();
    validatorService.extractPrompts.mockReturnValue(throwError(() => new Error('Unavailable')));
    component.ngOnInit();

    expect(component.errorMessage()).toContain('You can enter it manually');
    component.onSystemPromptChange('Manual prompt');
    expect(component.systemPrompt()).toBe('Manual prompt');
  });

  it.each(['generate', 'both'] as const)('disables %s until all required generation fields are filled', (tab) => {
    const { component } = createComponent();
    component.onTabChange(tab);
    expect(component.isActionDisabled).toBe(true);
    fillGenerationFields(component);
    expect(component.isActionDisabled).toBe(false);

    for (const field of ['product', 'retailer', 'geography', 'demographic', 'period', 'userPrompt'] as const) {
      const previous = component[field];
      component[field] = '   ';
      expect(component.isActionDisabled).toBe(true);
      component[field] = previous;
    }
  });

  it('disables validation for missing text, missing identifiers, duplicate IDs or an empty list', () => {
    const { component, validatorService } = createComponent();
    component.onTabChange('validate');
    fillValidationCriteria(component);
    expect(component.isActionDisabled).toBe(false);
    const validQuestion = component.validationQuestions()[0];
    component.validationQuestions.set([{ ...validQuestion, question: '   ' }]);
    expect(component.isActionDisabled).toBe(true);
    component.onAction();
    expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
    component.validationQuestions.set([{ ...validQuestion, id: '' }]);
    expect(component.isActionDisabled).toBe(true);
    component.validationQuestions.set([validQuestion, { ...validQuestion }]);
    expect(component.isActionDisabled).toBe(true);
    component.validationQuestions.set([]);
    expect(component.isActionDisabled).toBe(true);
  });

  it('disables validation and blocks submission when any panelist criterion is missing', () => {
    const { component, validatorService, fixture } = createComponent(true);
    component.onTabChange('validate');
    component.product = '';
    fixture!.detectChanges();
    const element = fixture!.nativeElement as HTMLElement;
    const validateButton = Array.from(element.querySelectorAll<HTMLElement>('niq-button')).find((button) =>
      button.textContent?.trim() === 'Validate questions',
    )!;
    const criteriaFields = element.querySelectorAll('niq-text-field.selection-field');

    expect(Array.from(criteriaFields).every((field) => field.hasAttribute('required'))).toBe(true);
    expect(Reflect.get(validateButton, 'disabled')).toBe(true);
    fillValidationCriteria(component);
    expect(component.isActionDisabled).toBe(false);
    fixture!.detectChanges();
    const requiredFields = ['product', 'retailer', 'demographic', 'geography', 'period'] as const;

    for (const field of requiredFields) {
      const originalValue = component[field];
      component[field] = '   ';
      fixture!.detectChanges();

      expect(component.isActionDisabled).toBe(true);
      component.onValidateQuestions();
      expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
      expect(component.errorMessage()).toBe(`${field} is required.`);

      component[field] = originalValue;
      fixture!.detectChanges();
    }
  });

  it('marks the user prompt as required in generation workflows', () => {
    const { component, fixture } = createComponent(true);
    const element: HTMLElement = fixture!.nativeElement;

    fixture!.detectChanges();
    expect(element.querySelector<HTMLTextAreaElement>('#user-prompt')?.required).toBe(true);

    component.onTabChange('both');
    fixture!.detectChanges();
    expect(element.querySelector<HTMLTextAreaElement>('#user-prompt')?.required).toBe(true);
  });

  it.each(['generate', 'both'] as const)('allows 10 questions but rejects 11 in %s', (tab) => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    component.onTabChange(tab);
    validatorService.generateQuestions.mockReturnValue(of({ title: 'Survey', result: [] }));
    validatorService.generateAndValidateSurvey.mockReturnValue(of({
      title: 'Survey', validation: { status: 'COMPLETED' }, result: [],
    }));
    validatorService.validateSurveyWithPrompt.mockReturnValue(of({ result: [] }));

    component.onGenerateQuestions({ questionCount: 10, questionTypes: [] });
    expect(component.maxQuestionCount).toBe(10);
    if (tab === 'both') {
      expect(validatorService.generateAndValidateSurvey).toHaveBeenCalledOnce();
      expect(validatorService.generateQuestions).not.toHaveBeenCalled();
    } else {
      expect(validatorService.generateQuestions).toHaveBeenCalledOnce();
    }

    component.onGenerateQuestions({ questionCount: 11, questionTypes: [] });
    expect(validatorService.generateQuestions).toHaveBeenCalledTimes(tab === 'generate' ? 1 : 0);
    expect(validatorService.generateAndValidateSurvey).toHaveBeenCalledTimes(tab === 'both' ? 1 : 0);
    expect(component.errorMessage()).toContain('between 1 and 10');
  });

  it('visibly disables Add question at 10 questions and re-enables it after removal', () => {
    const { component, fixture } = createComponent(true);
    component.onTabChange('validate');
    while (component.validationQuestionCount < 10) component.addValidationQuestion();
    fixture!.detectChanges();
    const element: HTMLElement = fixture!.nativeElement;
    const addButton = Array.from(element.querySelectorAll('niq-button')).find((button) =>
      button.textContent?.trim() === 'Add question',
    )!;

    expect(addButton).toBeDefined();
    expect(Reflect.get(addButton, 'disabled')).toBe(true);
    expect(Reflect.get(addButton, 'state')).toBe('disabled');

    component.removeValidationQuestion(9);
    fixture!.detectChanges();
    expect(Reflect.get(addButton, 'disabled')).toBe(false);
    expect(Reflect.get(addButton, 'state')).toBe('default');
  });

  it('stops adding at 10 validation questions and disables submission for 11', () => {
    const { component, validatorService } = createComponent();
    component.onTabChange('validate');
    fillValidationCriteria(component);
    const question = component.validationQuestions()[0];
    const questions = Array.from({ length: 10 }, (_, index) => ({
      ...question, id: `q_${index + 1}`, order: index + 1,
    }));
    component.validationQuestions.set(questions);
    expect(component.isActionDisabled).toBe(false);
    component.addValidationQuestion();
    expect(component.validationQuestionCount).toBe(10);

    component.validationQuestions.set([...questions, { ...question, id: 'q_11', order: 11 }]);
    expect(component.isActionDisabled).toBe(true);
    component.onValidateQuestions();
    expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
    expect(component.errorMessage()).toContain('between 1 and 10');
  });

  it('rejects a combined response larger than 10 questions', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    component.onTabChange('both');
    const question = { question: 'Question?', type: 'SINGLE_CHOICE', isRequired: true };
    validatorService.generateAndValidateSurvey.mockReturnValue(of({
      title: 'Survey',
      validation: { status: 'COMPLETED' },
      result: Array(11).fill(question),
    }));

    component.onGenerateQuestions({ questionCount: 10, questionTypes: [] });

    expect(validatorService.generateAndValidateSurvey).toHaveBeenCalledOnce();
    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
    expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
    expect(component.errorMessage()).toContain('more than 10 questions');
    expect(component.isGenerating()).toBe(false);
  });

  it('preserves a missing isRequired flag for structural response validation', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    validatorService.generateQuestions.mockReturnValue(of({
      result: [{ question: 'How would you rate this?', type: QuestionTypes.StarRating }],
    }));
    validatorService.validateQuestions.mockReturnValue({
      valid: false,
      issueCount: 1,
      issues: [{ questionIndex: 0, field: 'isRequired', message: 'isRequired flag must be a boolean.' }],
    });

    component.onGenerateQuestions({ questionCount: 1, questionTypes: [QuestionTypes.StarRating] });

    expect(validatorService.validateQuestions).toHaveBeenCalledWith([
      expect.objectContaining({ isRequired: undefined }),
    ]);
    expect(component.generateWorkflowResult()?.localValidation?.valid).toBe(false);
  });

  it('disables submission during an in-flight request', () => {
    const { component } = createComponent();
    fillGenerationFields(component);
    component.isGenerating.set(true);
    expect(component.isActionDisabled).toBe(true);
    component.isGenerating.set(false);
    component.onTabChange('validate');
    component.isValidating.set(true);
    expect(component.isActionDisabled).toBe(true);
  });

  it('starts with default panelist criteria and retains each editable system prompt across tabs', () => {
    const { component, validatorService } = createComponent();

    expect(component.systemPrompt()).toBe('');
    expect(component.userPrompt).toBe('');
    expect([component.product, component.retailer, component.demographic, component.geography, component.period])
      .toEqual(['Food', 'Dollar store', 'Total Panel', 'Total US', 'Cal Yr 2024 - w/e 12/28/24']);
    component.onSystemPromptChange('Use neutral language.');
    component.onTabChange('validate');
    expect(component.systemPrompt()).toBe('');
    component.onSystemPromptChange('Review each question.');
    component.onTabChange('both');
    expect(component.systemPrompt()).toBe('Use neutral language.');
    expect(component.validationSystemPrompt()).toBe('Review each question.');
    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
  });

  it('retains separate workflow results and ignores tab changes while busy', () => {
    const { component } = createComponent();
    const generateResult = {
      surveyTitle: 'Generated survey',
      questions: [],
      validation: null,
      localValidation: null,
      responseJson: '{"generation":true}',
    };
    component.generateWorkflowResult.set(generateResult);
    component.validateWorkflowResult.set({ ...generateResult, surveyTitle: 'Validated survey' });
    component.isGenerating.set(true);

    component.onTabChange('validate');

    expect(component.activeTab()).toBe('generate');
    expect(component.generateWorkflowResult()).toEqual(generateResult);

    component.isGenerating.set(false);
    component.onTabChange('validate');

    expect(component.activeTab()).toBe('validate');
    expect(component.generateWorkflowResult()).toEqual(generateResult);
    expect(component.validateWorkflowResult()?.surveyTitle).toBe('Validated survey');
  });

  it('does not call generate while already generating', () => {
    const { component, validatorService } = createComponent();
    component.isGenerating.set(true);

    component.onGenerateQuestions({ questionCount: 5, questionTypes: [QuestionTypes.Text] });

    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
  });

  it.each(['isGenerating', 'isValidating'] as const)('does not submit validation while %s', (loadingState) => {
    const { component, validatorService } = createComponent();
    component.onTabChange('validate');
    component[loadingState].set(true);

    component.onValidateQuestions();

    expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
    expect(component[loadingState]()).toBe(true);
  });

  it.each([
    { error: new Error('Validation unavailable'), message: 'Validation unavailable' },
    { error: { status: 503 }, message: 'Failed to validate questions.' },
  ])('clears validation loading and displays "$message" on failure', ({ error, message }) => {
    const { component, validatorService } = createComponent();
    component.onTabChange('validate');
    fillValidationCriteria(component);
    validatorService.validateSurveyWithPrompt.mockReturnValue(throwError(() => error));

    component.onValidateQuestions();

    expect(component.errorMessage()).toBe(message);
    expect(component.isValidating()).toBe(false);
    expect(component.validateWorkflowResult()).toBeNull();
    expect(component.isActionDisabled).toBe(false);
  });

  it('requires every generation context field and the user prompt', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    component.product = '   ';

    component.onGenerateQuestions({ questionCount: 5, questionTypes: [] });

    expect(component.errorMessage()).toBe('product is required.');
    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
  });

  it('sends the editable generation system prompt through the prompt-aware generation payload', () => {
    const { component, validatorService } = createComponent();
    validatorService.generateQuestions.mockReturnValue(of({ result: [{ question: 'Q1', type: QuestionTypes.SingleChoice, isRequired: true, options: ['Yes', 'No'] }] }));

    component.onProductChange('  Snacks  ');
    component.onRetailerChange('  All Retailers  ');
    component.onDemographicChange('  Adults 18-45  ');
    component.onGeographyChange('  United States  ');
    component.onPeriodChange('  Last 30 days  ');
    component.onUserPromptChange('  Explore customer loyalty  ');
    component.onSystemPromptChange('Use balanced scales.');

    component.onGenerateQuestions({ questionCount: 4, questionTypes: [QuestionTypes.Text] });

    expect(validatorService.generateQuestions).toHaveBeenCalledWith({
      prompt: {
        demographic: 'Adults 18-45',
        geography: 'United States',
        period: 'Last 30 days',
        product: 'Snacks',
        questionCount: 4,
        questionTypes: [QuestionTypes.Text],
        retailer: 'All Retailers',
        systemPrompt: 'Use balanced scales.',
        userPrompt: 'Explore customer loyalty',
      },
    });
    expect(validatorService.validateQuestions).toHaveBeenCalledWith([
      { question: 'Q1', type: QuestionTypes.SingleChoice, isRequired: true, options: ['Yes', 'No'] },
    ]);
    expect(component.generateWorkflowResult()?.responseJson).toContain('"question": "Q1"');
    expect(component.generateWorkflowResult()?.localValidation).toEqual({ valid: true, issueCount: 0, issues: [] });
    expect(component.isGenerating()).toBe(false);
  });

  it('sets an error message when generation fails', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    validatorService.generateQuestions.mockReturnValue(throwError(() => new Error('Boom')));

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [] });

    expect(component.errorMessage()).toBe('Boom');
    expect(component.isGenerating()).toBe(false);
  });

  it('keeps loading state true until the request resolves', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    const pending = new Subject<{ result: unknown[] }>();
    validatorService.generateQuestions.mockReturnValue(pending.asObservable());

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [QuestionTypes.Text] });

    expect(component.isGenerating()).toBe(true);

    pending.next({ result: [] });
    pending.complete();

    expect(component.isGenerating()).toBe(false);
  });

  it('preserves question identity and sends required validation context', () => {
    const { component, validatorService } = createComponent();
    fillValidationCriteria(component);
    component.onTabChange('validate');
    component.onSystemPromptChange('Validate questions for neutral wording.');
    component.validationQuestions.set([{
      id: 'source-question-8',
      order: 8,
      question: 'How useful is this product?',
      type: QuestionTypes.SingleChoice,
      options: ['Very useful', 'Not useful'],
      isRequired: false,
      reviewRequired: false,
    }]);
    validatorService.validateSurveyWithPrompt.mockReturnValue(of({ result: [] }));

    component.onValidateQuestions();

    expect(validatorService.validateSurveyWithPrompt).toHaveBeenCalledWith({
      survey: {
        systemPrompt: 'Validate questions for neutral wording.',
        product: 'Abrasive cleaners',
        retailer: 'All retailers',
        demographic: 'Adults 18-45',
        geography: 'United States',
        period: 'Last 30 days',
        questions: [{
          id: 'source-question-8',
          order: 8,
          question: 'How useful is this product?',
          type: QuestionTypes.SingleChoice,
          options: ['Very useful', 'Not useful'],
          rowOptions: [],
          columnOptions: [],
          npsLeftLabel: '',
          npsRightLabel: '',
          isRequired: false,
          reviewRequired: false,
        }],
      },
    });
    expect(component.validateWorkflowResult()?.questions[0]).toMatchObject({ id: 'source-question-8', order: 8 });
  });

  it('matches validation results by ID and falls back to order when a result ID is missing', () => {
    const { component } = createComponent();
    const question = component.validationQuestions()[0];
    const idMatchedResult = {
      id: question.id,
      order: 7,
      question: question.question,
      status: 'APPROVED' as const,
    };
    const result = {
      surveyTitle: '',
      questions: [question],
      validation: { result: [idMatchedResult] },
      localValidation: null,
      responseJson: '',
    };

    expect(component.getValidationForQuestion(result, question, 0)).toBe(idMatchedResult);
    const orderFallbackResult = { ...idMatchedResult, id: '', order: question.order };
    expect(component.getValidationForQuestion({
      ...result,
      validation: { result: [orderFallbackResult] },
    }, question, 0)).toBe(orderFallbackResult);
  });

  it('normalizes structured and legacy string suggestions for the results view', () => {
    const { component } = createComponent();

    expect(component.suggestionDetails({
      suggestionId: 'q-1-ai1',
      severity: 'OPTIONAL',
      ruleCode: 'CLARITY_REPHRASE',
      issue: 'The question does not identify the product.',
      rationale: 'Identifying the product makes the question actionable.',
      suggestedText: 'How would you rate abrasive cleansers?',
      fieldPath: 'question',
      source: 'AI',
      action: 'REPHRASE',
    })).toEqual({
      suggestionId: 'q-1-ai1',
      severity: 'OPTIONAL',
      ruleCode: 'CLARITY_REPHRASE',
      issue: 'The question does not identify the product.',
      rationale: 'Identifying the product makes the question actionable.',
      suggestedText: 'How would you rate abrasive cleansers?',
      fieldPath: 'question',
      source: 'AI',
      action: 'REPHRASE',
    });
    expect(component.suggestionDetails('Keep the question concise.')).toEqual({
      issue: 'Keep the question concise.',
    });
    expect(component.formatSuggestionLabel('CLARITY_REPHRASE')).toBe('Clarity Rephrase');
  });

  it.each([
    ['validate', 'REPHRASE', 'Rephrase'],
    ['validate', 'REMOVE', 'Remove'],
    ['validate', 'REVIEW', 'Review'],
    ['both', 'REPHRASE', 'Rephrase'],
    ['both', 'REMOVE', 'Remove'],
    ['both', 'REVIEW', 'Review'],
  ] as const)('renders suggestion feedback in %s results with the %s action', (tab, action, label) => {
    const { component, fixture } = createComponent(true);
    component.onTabChange(tab);
    const question = component.validationQuestions()[0];
    const suggestion = {
      suggestionId: 'q_1-ai1',
      severity: 'OPTIONAL' as const,
      ruleCode: 'RESEARCH_QUALITY',
      issue: 'The response options are broad.',
      rationale: 'A more balanced scale would improve interpretability.',
      suggestedText: 'Very satisfied, satisfied, neutral, dissatisfied, very dissatisfied.',
      fieldPath: 'options',
      source: 'AI' as const,
      action,
    };
    const legacySuggestion = 'Keep the question concise.';
    const validationQuestion = { ...question, status: 'APPROVED' as const, suggestions: [legacySuggestion, suggestion] };
    const result = {
      surveyTitle: 'Survey',
      questions: [question],
      validation: tab === 'validate'
        ? { result: [validationQuestion] }
        : {
          title: 'Survey',
          result: [validationQuestion],
          validation: { status: 'COMPLETED' as const },
        },
      localValidation: null,
      responseJson: '{}',
    };
    if (tab === 'validate') component.validateWorkflowResult.set(result);
    else component.combinedWorkflowResult.set(result);
    fixture!.detectChanges();

    const element = fixture!.nativeElement as HTMLElement;
    const suggestions = element.querySelectorAll('.suggestion-item');
    expect(suggestions).toHaveLength(2);
    expect(suggestions[0].querySelector('.suggestion-rationale')?.textContent).toBe(legacySuggestion);
    expect(suggestions[1].querySelector('.suggestion-rationale')?.textContent).toBe(suggestion.rationale);
    expect(suggestions[1].querySelector('.suggested-wording p')?.textContent).toBe(suggestion.suggestedText);
    expect(suggestions[1].textContent).not.toContain(suggestion.issue);
    expect(element.querySelector('.suggestion-issue')).toBeNull();
    const actionBadge = element.querySelector('.recommended-action');
    expect(actionBadge?.textContent?.trim()).toBe(label);
    expect(actionBadge?.tagName.toLowerCase()).toBe('span');
    expect(actionBadge?.getAttribute('aria-label')).toBe(`Recommended action: ${label}`);
    expect(actionBadge?.parentElement?.classList.contains('suggestion-action-row')).toBe(true);
  });

  it('passes the generation title, context, and numbered questions into combined validation', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    const generatedQuestion = {
      id: 'q_1',
      order: 1,
      question: 'How effective is the product?',
      type: QuestionTypes.SingleChoice,
      options: ['Very effective', 'Not effective'],
      isRequired: true,
    };
    validatorService.generateAndValidateSurvey.mockReturnValue(of({
      title: 'Generated title',
      validation: { status: 'COMPLETED' },
      result: [{ ...generatedQuestion, status: 'APPROVED', suggestions: [] }],
    }));
    component.generationSystemPrompt.set('Generation system prompt');
    component.validationSystemPrompt.set('Validation system prompt');
    component.onTabChange('both');

    component.onGenerateQuestions({ questionCount: 1, questionTypes: [QuestionTypes.SingleChoice] });

    expect(validatorService.generateQuestions).not.toHaveBeenCalled();
    expect(validatorService.validateSurveyWithPrompt).not.toHaveBeenCalled();
    expect(validatorService.generateAndValidateSurvey).toHaveBeenCalledWith({
      prompt: {
        demographic: 'Total Panel',
        geography: 'Total US',
        period: 'Latest 52 Weeks',
        product: 'ABRASIVE CLEANSERS',
        questionCount: 1,
        questionTypes: [QuestionTypes.SingleChoice],
        retailer: 'Total Outlets',
        userPrompt: 'Generate few questions on the effectiveness of the product(s)',
        generateQuestionSystemPrompt: 'Generation system prompt',
        validateSurveySystemPrompt: 'Validation system prompt',
      },
    });
    expect(component.combinedWorkflowResult()?.validation?.result[0].status).toBe('APPROVED');
    expect(component.combinedWorkflowResult()?.validation?.validation?.status).toBe('COMPLETED');
  });

  it('omits empty question types so the combined endpoint uses its all-types default', () => {
    const { component, validatorService } = createComponent();
    fillGenerationFields(component);
    validatorService.generateAndValidateSurvey.mockReturnValue(of({
      title: 'Generated title', validation: { status: 'COMPLETED' }, result: [],
    }));
    component.onTabChange('both');

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [] });

    expect(validatorService.generateAndValidateSurvey.mock.calls[0][0].prompt).not.toHaveProperty('questionTypes');
  });

});
