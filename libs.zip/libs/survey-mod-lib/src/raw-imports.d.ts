// Vite's `?raw` suffix imports a file's contents as a string (used by specs to load component templates).
declare module '*?raw' {
  const content: string;
  export default content;
}
