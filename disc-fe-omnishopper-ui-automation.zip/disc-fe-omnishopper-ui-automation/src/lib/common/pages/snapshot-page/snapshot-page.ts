import { BasePage, WebActions } from "@gfk/gta";
import * as snapshotResources from "./snapshot-page-resources.json";
import { ELEMENT_WAIT_TIMEOUT, MAX_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { ResourceManager } from "../../utils/resource-manager";
import { CommonTestCase } from "../common-test-case/common-test-case";

// Register the DataSelector resources
const SNAPSHOT = "Snapshot";

export class Snapshot extends CommonTestCase {
  webActionHandler: WebActions;
  resourceManager: ResourceManager;
  constructor(basePage: BasePage) {
    super(basePage);
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});

    // Register multiple resources for the same component
    this.resourceManager.registerResources(SNAPSHOT, snapshotResources);
  }

  /**
   * Waits for the report run process to complete by monitoring the visibility
   * of the cancel button during spinner activity. Handles timeout scenarios.
   */
  public async waitForReportRunCompletion(): Promise<void> {
    const cancelButton = await super.getWebelement("inProgressCancel", SNAPSHOT);

    try {
      // Snapshot is often invoked on an already-completed report; avoid long waits
      // by checking briefly whether a run is currently in progress.
      const runStarted = await cancelButton
        .waitFor(ELEMENT_WAIT_TIMEOUT, "visible")
        .then(() => true)
        .catch((err) => {
          const name = (err as any)?.name ? String((err as any).name).toLowerCase() : "";
          const msg = err instanceof Error ? err.message : String(err);
          if (name.includes("timeout") || msg.toLowerCase().includes("timeout")) {
            return false;
          }
          throw err;
        });

      if (!runStarted) {
        console.info("No active report run detected; continuing snapshot flow.");
        return;
      }
      // If the run indicator is visible, wait for it to disappear.
      await cancelButton.waitFor(MAX_TEST_TIMEOUT, "hidden");

      console.info("Report run completed!");
    } catch (error) {
      console.error(
        "Cancel button did not disappear within the expected duration:",
        error
      );
      throw new Error("Report run did not complete within the timeout period.");
    }
  }

  /**
   * Clicks the save icon after ensuring it is visible.
   * Throws an error if the icon is not found or not clickable within timeout.
   */
  public async clickSaveIcon(): Promise<void> {
    const saveIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "saveIcon",
        SNAPSHOT
      )
    );
    try {
      await saveIcon.waitFor();
      await saveIcon.click();
    } catch (error) {
      throw new Error(
        "Failed to click Save icon: element not visible or clickable."
      );
    }
  }

  /**
   * Clicks the snapshot icon after ensuring it is visible.
   * Throws an error if the icon is not found or not clickable within timeout.
   */
  public async clickSnapshotIcon(): Promise<void> {
    try {
      await super.clickWebelement("snapshotMenuItem", SNAPSHOT);
      return;
    } catch {
      // Re-open the save menu in case it auto-closed before selecting snapshot.
      await this.clickSaveIcon();
      try {
        await super.clickWebelement("snapshotMenuItem", SNAPSHOT);
        return;
      } catch (err) {
        console.debug("snapshotMenuItem not found after reopening save menu, trying fallback selectors.", err);
      }
    }

    try {
      await super.clickWebelement("snapshotMenuItemFallback", SNAPSHOT);
      return;
    } catch (error) {
      console.warn("snapshotMenuItemFallback selector failed, trying snapshotIcon:", error);
    }

    try {
      await super.clickWebelement("snapshotIcon", SNAPSHOT);
    } catch (error) {
      throw new Error(
        "Failed to click Snapshot icon: element not visible or clickable."
      );
    }
  }

  /**
   * Switches to the next tab to handle snapshot-related workflows.
   * Logs the tab switch or throws if switching fails.
   */
  public async shiftingToSnapshot(): Promise<string> {
    try {
      this.webActionHandler.switchTabsRight(ELEMENT_WAIT_TIMEOUT);
      let newUrl: string = await this.webActionHandler.getPageUrl();
      console.info("Switched to the next tab successfully.");
      return newUrl;
    } catch (error) {
      throw new Error("Failed to switch to the snapshot tab.");
    }
  }

  /**
   * Checks whether the Robustness footer is visible in the DOM.
   *
   * @returns `true` if visible; otherwise, `false`.
   */
  public async isRobustnessFooterVisible(): Promise<boolean> {
    try {
      const footerElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(
          "omni-robustness-footer",
          SNAPSHOT
        )
      );
      await footerElement.waitFor();
      return await footerElement.isVisible();
    } catch {
      return false;
    }
  }

  /**
   * Checks whether the Robustness footer is visible in the DOM.
   *
   * @returns `true` if visible; otherwise, `false`.
   */
  public async issuccessPopupVisible(): Promise<boolean> {
    try {
      const footerElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(
          "successPopup",
          SNAPSHOT
        )
      );
      await footerElement.waitFor(MAX_TEST_TIMEOUT, 'visible');
      return await footerElement.isVisible();
    } catch {
      return false;
    }
  }  
}
