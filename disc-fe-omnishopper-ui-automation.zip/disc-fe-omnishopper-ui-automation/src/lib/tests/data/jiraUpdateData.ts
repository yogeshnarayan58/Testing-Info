export type JiraMapping = Record<string, Record<string, string>>;

export const jiraUpdateData: JiraMapping = {
  "Leakage Analysis": {
    '@QuickLook': 'RBOC-156410',
    '@Insights': 'RBOC-156411',
    '@MadlibValidation': 'RBOC-156412',
    '@RunReport': 'RBOC-156413',
    '@FormatPanelDefaultVerification': 'RBOC-156414',
    '@ValidateFullScreen': 'RBOC-156415',
    '@ValidateExcelExport': 'RBOC-156416',
    '@ValidateAddBlankReport': 'RBOC-156417'
  },
  "Sourcerer": {
    '@QuickLook': 'RBOC-157340',
    '@Insights': 'RBOC-157341',
    '@MadlibValidation': 'RBOC-157342',
    '@RunReport': 'RBOC-157343',
    '@FormatPanelDefaultVerification': 'RBOC-157344',
    '@ValidateFullScreen': 'RBOC-157345',
    '@ValidateExcelExport': 'RBOC-157346',
    '@ValidateAddBlankReport': 'RBOC-157347'
  },
  "Assortment Optimizer": {
    '@QuickLook': 'RBOC-157669',
    '@Insights': 'RBOC-157670',
    '@MadlibValidation': 'RBOC-157671',
    '@RunReport': 'RBOC-157672',
    '@FormatPanelDefaultVerification': 'RBOC-157673',
    '@ValidateFullScreen': 'RBOC-157674',
    '@ValidateExcelExport': 'RBOC-157675',
    '@ValidateAddBlankReport': 'RBOC-157676'
  },
  "Consumer performance competitive mapping": {
    '@QuickLook': 'RBOC-157689',
    '@Insights': 'RBOC-157690',
    '@MadlibValidation': 'RBOC-157691',
    '@RunReport': 'RBOC-157692',
    '@FormatPanelDefaultVerification': 'RBOC-157693',
    '@ValidateFullScreen': 'RBOC-157694',
    '@ValidateExcelExport': 'RBOC-157695',
    '@ValidateAddBlankReport': 'RBOC-157696'
  },
  "Consumer Trends": {
    '@QuickLook': 'RBOC-157348',
    '@Insights': 'RBOC-157349',
    '@MadlibValidation': 'RBOC-157350',
    '@RunReport': 'RBOC-157351',
    '@FormatPanelDefaultVerification': 'RBOC-157352',
    '@ValidateFullScreen': 'RBOC-157353',
    '@ValidateExcelExport': 'RBOC-157354',
    '@ValidateAddBlankReport': 'RBOC-157355'
  },
  "Combination purchase analysis": {
    '@QuickLook': 'RBOC-157819',
    '@Insights': 'RBOC-157820',
    '@MadlibValidation': 'RBOC-157821',
    '@RunReport': 'RBOC-157822',
    '@FormatPanelDefaultVerification': 'RBOC-157823',
    '@ValidateFullScreen': 'RBOC-157824',
    '@ValidateExcelExport': 'RBOC-157825',
    '@ValidateAddBlankReport': 'RBOC-157826'
  },

  "Consumer Distribution Analysis": {
    '@QuickLook': 'RBOC-157373',
    '@Insights': 'RBOC-157374',
    '@MadlibValidation': 'RBOC-157375',
    '@RunReport': 'RBOC-157376',
    '@FormatPanelDefaultVerification': 'RBOC-157377',
    '@ValidateFullScreen': 'RBOC-157378',
    '@ValidateExcelExport': 'RBOC-157379',
    '@ValidateAddBlankReport': 'RBOC-157380'
  },
  "Consumer product ranking": {
    '@QuickLook': 'RBOC-157332',
    '@Insights': 'RBOC-157333',
    '@MadlibValidation': 'RBOC-157334',
    '@RunReport': 'RBOC-157335',
    '@FormatPanelDefaultVerification': 'RBOC-157336',
    '@ValidateFullScreen': 'RBOC-157337',
    '@ValidateExcelExport': 'RBOC-157338',
    '@ValidateAddBlankReport': 'RBOC-157339'
  },
  "Time Stamped Groups": {
    '@QuickLook': 'RBOC-156440',
    '@Insights': 'RBOC-156441',
    '@MadlibValidation': 'RBOC-156442',
    '@RunReport': 'RBOC-156443',
    '@FormatPanelDefaultVerification': 'RBOC-156444',
    '@ValidateFullScreen': 'RBOC-156445',
    '@ValidateExcelExport': 'RBOC-156446',
    '@ValidateAddBlankReport': 'RBOC-156447'
  },
  "trade-planner-key-facts" : {
    '@QuickLook': 'RBOC-157785',
    '@Insights': 'RBOC-157786',
    '@MadlibValidation': 'RBOC-157787',
    '@RunReport': 'RBOC-157788',
    '@FormatPanelDefaultVerification': 'RBOC-157789',
    '@ValidateFullScreen': 'RBOC-157790',
    '@ValidateExcelExport': 'RBOC-157791',
    '@ValidateAddBlankReport': 'RBOC-157792'
  },
  "Multi Geo Shifting": {
    '@QuickLook': 'RBOC-157677',
    '@Insights': 'RBOC-157678',
    '@MadlibValidation': 'RBOC-157679',
    '@RunReport': 'RBOC-157680',
    '@FormatPanelDefaultVerification': 'RBOC-157681',
    '@ValidateFullScreen': 'RBOC-157682',
    '@ValidateExcelExport': 'RBOC-157683',
    '@ValidateAddBlankReport': 'RBOC-157684'
  },
  "Trade planner retailer share components" : {
    '@QuickLook': 'RBOC-157802',
    '@Insights': 'RBOC-157803',
    '@MadlibValidation': 'RBOC-157804',
    '@RunReport': 'RBOC-157805',
    '@FormatPanelDefaultVerification': 'RBOC-157806',
    '@ValidateFullScreen': 'RBOC-157807',
    '@ValidateExcelExport': 'RBOC-157808',
    '@ValidateAddBlankReport': 'RBOC-157809'
  },
  "Trade planner table" : {
    '@QuickLook': 'RBOC-176409',
    '@Insights': 'RBOC-176410',
    '@MadlibValidation': 'RBOC-176411',
    '@RunReport': 'RBOC-176412',
    '@FormatPanelDefaultVerification': 'RBOC-176413',
    '@ValidateFullScreen': 'RBOC-176414',
    '@ValidateExcelExport': 'RBOC-176415',
    '@ValidateAddBlankReport': 'RBOC-176416'
  },
  "Consumer multi country map" : {
    '@QuickLook': 'RBOC-191829',
    '@Insights': 'RBOC-191830',
    '@MadlibValidation': 'RBOC-191831',
    '@RunReport': 'RBOC-191832',
    '@FormatPanelDefaultVerification': 'RBOC-191833',
    '@ValidateFullScreen': 'RBOC-191834',
    '@ValidateExcelExport': 'RBOC-191835',
    '@ValidateAddBlankReport': 'RBOC-191836'
  },
}