import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { assert } from "@gfk/gta";
import { findDataSetByName, hasPivotInDimensionSelections, getDimensionSelectionsByPivot, getTestDataByLocale } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";

test.describe("Demographic Profile - Retailer Pivot", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      if (localeData.pivotMadlibText) {
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).retailer;

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        assert(actualMadlibText).toMatch(
          new RegExp(expectedMadlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Validate run report",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          const retailerPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
          if (!retailerPivotData) {
            throw new Error("Pivot not found in test data: Retailer");
          }
          await dataSelector.switchPivotDropdown(pivot);

          await dataSelector.clickMadlibDimension("Retailer Universe");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Retailer Universe"]
          );

          await dataSelector.clickMadlibDimension("Retailer");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Retailer"]
          );

          await dataSelector.clickMadlibDimension("Product");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Product"]
          );

          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.selectClosedDropdown(
            retailerPivotData["Facts"]["selections"]
          );

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            retailerPivotData["Geography"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            retailerPivotData["Period"]
          );

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );
      test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
        test.skip(
          !savedReportTitle,
          "Skipping FMS test - Report not generated. Run with @RunReport first"
        );

        const basePage = await BasePageFactory.createBasePage();
        const findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
    });
});

