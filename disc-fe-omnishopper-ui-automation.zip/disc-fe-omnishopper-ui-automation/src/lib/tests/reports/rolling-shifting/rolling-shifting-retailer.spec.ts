import test from "@playwright/test";
import {
  findDataSetByName,
  getTestDataByLocale,
  getDimensionSelectionsByPivot,
  hasPivotInDimensionSelections,
  getPivotDataIndexByName
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import localizationData from "./test-data/localization-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import prodTestData from "./test-data/prod-test-data.json";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
let pivotIndex: number;
const pivot: string = "Retailer";

test.describe("Rolling Shifting - Retailer Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  let formatPanel: FormatPanel;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    pivotIndex = getPivotDataIndexByName(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);

      await commonTestCase.navigateToReportUrl(reportUrl);

      let commonBasePage = await commonTestCase.getBasePage();
      dataSelector = new DataSelector(commonBasePage);

      await dataSelector.switchPivotDropdown(pivot);
      // Get the actual madlib text
      const actualMadlibText = await dataSelector.getMadlibText();
      const expectedMadlibText = (localeData.pivotMadlibText as any).retailer;

      // Use toMatch for clearer error messages showing exact mismatch
      assert(actualMadlibText).toMatch(
        new RegExp(expectedMadlibText, "i")
      );
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Validate run report",
        { tag: "@RunReport" },
        async () => {

          // Set timeout to 5 minutes (300,000 ms) for this run report test
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);

          const retailerPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
          if (!retailerPivotData) {
            throw new Error("Pivot not found in test data: Retailer");
          }

          await dataSelector.switchPivotDropdown(pivot);

          await dataSelector.clickAdditionalPromptEllipsisIcon();
          await dataSelector.waitForMadlibStability();

          await dataSelector.clickMadlibDimension("Shifting Universe Retailer");
          await dataSelector.setMadlibSelection(retailerPivotData["Shifting Universe Retailer"]);

          await dataSelector.clickMadlibDimension("Comparison Retailers");
          await dataSelector.setMadlibSelection(retailerPivotData["Comparison Retailers"]);

          await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);

          await dataSelector.clickMadlibDimension("Product");
          await dataSelector.setMadlibSelection(retailerPivotData["Product"]);

          await dataSelector.clickMadlibDimension("Periods");
          await dataSelector.setPeriodMadlibSelection(retailerPivotData["Periods"] as any);

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(retailerPivotData["Geography"]);

          await dataSelector.clickMadlibDimension("Demographic");
          await dataSelector.setMadlibSelection(retailerPivotData["Demographic"]);

          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.selectClosedDropdown(retailerPivotData["Facts"]["selections"]);

          let dsBasePage = dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;

        }
      );

      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping openCurrentReportFMS - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);
        await findMyStuff.clickFindMyStuff();
        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("FMS execution successful");
      });

    });
});