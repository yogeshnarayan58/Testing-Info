import { Component, computed, input } from '@angular/core';
import { TagModule } from '@nielseniq/athena-core';
import { SuggestionTag } from '../../../models/build-survey';

@Component({
  selector: 'survey-suggestion-tags',
  standalone: true,
  imports: [TagModule],
  template: `
    <div class="question-suggestion-tags">
      @if (suggestionCounts(); as counts) {
      @if(counts.mandatoryCount > 0) {
      <niq-tag [iconName]="'error'" [size]="'x-small'" variant="error"
        [label]="requiredLabel()"
        [tooltipLabel]="requiredLabel()">
      </niq-tag>
      } @if (counts.optionalCount > 0) {
      <niq-tag [iconName]="'triangle-alert'" [size]="'x-small'" variant="warning" data-test-id="suggestion-tag-recommendation"
        [label]="recommendationLabel()"
        [tooltipLabel]="recommendationLabel()">
      </niq-tag>
      }
    }
    </div>
  `,
  styleUrl: './suggestion-tags.component.scss'
})
export class SuggestionTagsComponent {
  suggestionCounts = input<SuggestionTag | null>(null);

  readonly requiredLabel = computed(() => {
    const count = this.suggestionCounts()?.mandatoryCount ?? 0;
    return `${count} required change`;
  });

  readonly recommendationLabel = computed(() => {
    const count = this.suggestionCounts()?.optionalCount ?? 0;
    return `${count} recommendation`;
  });
}
