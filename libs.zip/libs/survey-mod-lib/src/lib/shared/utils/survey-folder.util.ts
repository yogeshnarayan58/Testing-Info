import type { Asset } from '@nielsen/crf-lp-common';

// Same virtual root identity used by the shared report SaveACopyService.
// This ID belongs to the folder tree only; it must never reach an API.
export const MY_ASSETS_ROOT = {
  assetId: 'Infinity',
  assetType: 'DISCOVERFOLDER',
  title: 'My Assets',
} as const satisfies Asset;

export function withMyAssetsRoot(folders: Asset[]): Asset[] {
  return [
    { ...MY_ASSETS_ROOT },
    ...folders.filter(folder => folder.assetId !== MY_ASSETS_ROOT.assetId)
      .map(folder => ({ ...folder, parentAsset: folder.parentAsset ?? { ...MY_ASSETS_ROOT } })),
  ];
}

export function toParentFolder(folder: Asset | null | undefined): Asset | undefined {
  return folder?.assetId === MY_ASSETS_ROOT.assetId ? undefined : folder ?? undefined;
}

export function toApiFolderId(folderId: string | undefined): string {
  return folderId === MY_ASSETS_ROOT.assetId ? '' : folderId ?? '';
}
