import { GRID_TEXT } from '../../../constants/grid.constants';
import { TranslateModule } from '@ngx-translate/core';
import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import type { ITooltipAngularComp } from 'ag-grid-angular';
import type { ITooltipParams } from 'ag-grid-community';
import type { GridCell, GridTooltipValue } from '../../../models/question-result';

@Component({
  selector: 'survey-grid-tooltip',
  standalone: true,
  imports: [TranslateModule],
  host: { role: 'tooltip' },
  templateUrl: './grid-tooltip.component.html',
  styleUrl: './grid-tooltip.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GridTooltipComponent implements ITooltipAngularComp {
  readonly gridText = GRID_TEXT;
  readonly tooltipText = signal<string>('');
  readonly isMasked = signal<boolean>(false);
  readonly headerText = signal<string>('');
  readonly maskReason = signal<string>('');

  agInit(tooltipParams: ITooltipParams<Record<string, GridCell>, GridTooltipValue | string | number, unknown>): void {
    const tooltipContent: GridTooltipValue = tooltipParams.value != null && typeof tooltipParams.value === 'object'
      ? tooltipParams.value : { value: tooltipParams.value };
    this.isMasked.set(tooltipParams.location === 'cell' && !!tooltipContent.masked);
    this.headerText.set(tooltipContent.header ?? '');
    this.maskReason.set(tooltipContent.message ?? '');
    this.tooltipText.set(tooltipContent.value == null ? '' : String(tooltipContent.value));
  }
}
