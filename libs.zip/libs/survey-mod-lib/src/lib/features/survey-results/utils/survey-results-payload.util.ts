import { v4 as uuidv4 } from 'uuid';
import barConfig from '../../../../../assets/payload/bar.json';
import columnConfig from '../../../../../assets/payload/column.json';
import gridConfig from '../../../../../assets/payload/grid.json';
import pieConfig from '../../../../../assets/payload/pie.json';
import { QuestionTypes } from '../../build-survey/models/build-survey';
import type { SavedSurveyDetails } from '../../build-survey/models/build-survey';
import { DataSummaryService, type ReportDataSummary } from '../utils-datasummary/data-summary.service';
import {
  RESULTS_DASHBOARD_CHART_TYPE_VALUES,
  type ResultsDashboardChartType,
  SURVEY_RESULTS_UI_CONFIG_CHART_TYPES_BY_QUESTION_TYPE,
  SURVEY_RESULTS_UI_CONFIG_OPTIONS,
} from '../models/survey-results';

type UiConfigOption = typeof SURVEY_RESULTS_UI_CONFIG_OPTIONS[number];
type ChartTemplate = typeof barConfig | typeof columnConfig | typeof pieConfig | typeof gridConfig;
type ObjectChartType = 'bar' | 'column' | 'pie' | 'grid';
type ResultsUiConfig = Record<string, unknown> & { id: string };
type ResultsObject = {
  valid: boolean;
  id: string;
  type: ObjectChartType;
  name: string;
  specId: string;
  title: string;
};
type ResultsContainer = {
  valid: boolean;
  id: string;
  type: string;
  positionX: number;
  positionY: number;
  width: number;
  height: number;
  pageId: string;
  objectId: string;
  connectToId: string;
  children: [];
  pages: [];
  order: number;
};
type ResultsDataSummary = ReportDataSummary | Record<string, never>;
type ResultsReportSpec = {
  id: string;
  uiConfigs: ResultsUiConfig[];
  objects: ResultsObject[];
  containers: ResultsContainer[];
  dataSummary: ResultsDataSummary;
};
type QuestionComponent = {
  uiConfig: ResultsUiConfig;
  objectType: ObjectChartType;
};

const CHART_DEFINITIONS: Record<ResultsDashboardChartType, { template: ChartTemplate; objectType: ObjectChartType }> = {
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.bar]: { template: barConfig, objectType: 'bar' },
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.column]: { template: columnConfig, objectType: 'column' },
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.pie]: { template: pieConfig, objectType: 'pie' },
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.heatmap]: { template: gridConfig, objectType: 'grid' },
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.table]: { template: gridConfig, objectType: 'grid' },
};

const SCALE_QUESTION_TYPES: ReadonlyArray<string> = [
  QuestionTypes.StarRating,
  QuestionTypes.SinglePointScale,
  QuestionTypes.MultiplePointScale,
];

export interface SurveyResultsQuestionPayload {
  id: string;
  title: string;
  type: string;
  attributes: Record<string, never>;
  reportSpec: {
    id: string;
    specs: ResultsReportSpec[];
  };
}

/** Copies a chart template with its generated ID and keeps the matching object type. */
function createQuestionComponent(option: UiConfigOption, questionNumber: number, componentNumber: number = 1): QuestionComponent {
  const definition = CHART_DEFINITIONS[option.value];
  if (!definition) {
    throw new Error(`Missing survey results chart configuration for: ${option.value}`);
  }

  return {
    uiConfig: {
      ...structuredClone(definition.template),
      id: `q${questionNumber}_c${componentNumber}_${option.id}`,
    },
    objectType: definition.objectType,
  };
}

/** Counts answer rows for rating and scale questions, using one when rows are missing or empty. */
function getScaleRowCount(question: Record<string, unknown>): number {
  const answerSpec = question['answerSpec'];
  if (typeof answerSpec !== 'object' || answerSpec === null || !('rows' in answerSpec)) {
    return 1;
  }

  const rows = answerSpec.rows;
  return Array.isArray(rows) && rows.length > 0 ? rows.length : 1;
}

/** Selects valid chart options; rating and scale questions get heatmaps once and other charts per row. */
function buildQuestionComponents(type: string, question: Record<string, unknown>, questionNumber: number): QuestionComponent[] {
  const allowedChartTypes = Object.entries(SURVEY_RESULTS_UI_CONFIG_CHART_TYPES_BY_QUESTION_TYPE)
    .find(([questionType]) => questionType === type)?.[1];
  if (!allowedChartTypes) {
    return [];
  }

  const validOptions = SURVEY_RESULTS_UI_CONFIG_OPTIONS
    .filter(option => allowedChartTypes.includes(option.value));

  if (!SCALE_QUESTION_TYPES.includes(type)) {
    return validOptions.map(option => createQuestionComponent(option, questionNumber));
  }

  const heatmapOptions = validOptions.filter(option => option.value === RESULTS_DASHBOARD_CHART_TYPE_VALUES.heatmap);
  const rowOptions = validOptions.filter(option => option.value !== RESULTS_DASHBOARD_CHART_TYPE_VALUES.heatmap);
  const heatmapConfigs = heatmapOptions.map(option => createQuestionComponent(option, questionNumber));
  const rowConfigs = Array.from({ length: getScaleRowCount(question) }, (_, rowIndex) =>
    rowOptions.map(option => createQuestionComponent(option, questionNumber, rowIndex + 1)),
  ).flat();

  return [...heatmapConfigs, ...rowConfigs];
}

/** Builds the dynamic results payload for each saved question. */
export function buildSurveyResultsPayload(
  questions: ReadonlyArray<Record<string, unknown>>,
  dataSummary: ResultsDataSummary = {},
): SurveyResultsQuestionPayload[] {
  return questions.map((question, index) => {
    const { id, type, prompt } = question;
    const title = typeof prompt === 'object' && prompt !== null && 'text' in prompt
      ? prompt.text
      : undefined;

    if (typeof id !== 'string' || !id.trim()
      || typeof title !== 'string' || !title.trim()
      || typeof type !== 'string' || !type.trim()) {
      throw new Error(`Cannot build survey results payload: question ${index + 1} requires an id, prompt.text, and type.`);
    }

    const components = buildQuestionComponents(type, question, index + 1);
    const specId: string = 'spec-1';

    return {
      id,
      title,
      type,
      attributes: {},
      reportSpec: {
        id: uuidv4(),
        specs: [
          {
            id: specId,
            uiConfigs: components.map(component => component.uiConfig),
            objects: components.map(({ uiConfig, objectType }) => ({
              valid: true,
              id: uiConfig.id,
              type: objectType,
              name: 'Table-1',
              specId,
              title: '',
            })),
            containers: components.map(({ uiConfig }, componentIndex) => ({
              valid: true,
              id: uuidv4(),
              type: 'simple',
              positionX: 0,
              positionY: 0,
              width: 100,
              height: 100,
              pageId: '',
              objectId: uiConfig.id,
              connectToId: '',
              children: [],
              pages: [],
              order: componentIndex + 1,
            })),
            dataSummary,
          }
        ],
      },
    };
  });
}

/** Builds a survey payload, generating its shared summary and clearing stale state when needed. */
export function buildSurveyResultsPayloadWithDataSummary(
  survey: SavedSurveyDetails | null,
  dataSummaryService: DataSummaryService,
  surveyId: string | null = null,
): SurveyResultsQuestionPayload[] | null {
  if (!survey || (surveyId && survey.surveyId !== surveyId)) {
    clearSurveyResultsDataSummary(dataSummaryService);
    return null;
  }

  const dataSummary = dataSummaryService.generateDataSummary(survey) ?? {};
  return buildSurveyResultsPayload(survey.questions, dataSummary);
}

/** Clears the shared summary when the Results page is destroyed. */
export function clearSurveyResultsDataSummary(dataSummaryService: DataSummaryService): void {
  dataSummaryService.clearDataSummary();
}
