import { BasePage, WebActions, assert } from "@gfk/gta";
import { ResourceManager } from "../../utils/resource-manager";
import * as commonCasesResources from "../common-test-case/common-test-cases-resource.json";
import {
  MAX_TEST_TIMEOUT,
  NAVIGATION_TIMEOUT,
  RUN_TEST_TIMEOUT,
  SMALL_TIMEOUT,
  DATASET_PROCESSING_DELAY,
  UI_STATE_UPDATE_DELAY,
} from "../../../constants/time-out-constants";
import { WebElement } from "@gfk/gta/dist/core/web/webElement";
import { expect, Page, TestInfo } from "@playwright/test";
import { config } from "../../../playwright/config";
import * as path from "path";
import * as fs from "fs";


const COMMON_COMPONENT_NAME = "Common cases";
export class CommonTestCase {
  webActionHandler: WebActions;
  resourceManager: ResourceManager;

  constructor(protected basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    // Initialize ResourceManager with component resources
    this.resourceManager = new ResourceManager({});

    // Register multiple resources for the same component
    this.resourceManager.registerResources(
      COMMON_COMPONENT_NAME,
      commonCasesResources
    );
  }

  public async clickRunButton(): Promise<void> {
    try {

      //check for walkme shoutout message
      const walkmeShoutout = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("walkmeShoutout", COMMON_COMPONENT_NAME)
      );

      const isWalkmeShoutoutVisible = await walkmeShoutout.isVisible().catch(() => false);

      if (isWalkmeShoutoutVisible) {
        const walkmeShoutoutCloseButton = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("walkmeShoutoutCloseButton", COMMON_COMPONENT_NAME)
        );
        
         await walkmeShoutoutCloseButton.waitFor(SMALL_TIMEOUT, "visible");
         await walkmeShoutoutCloseButton.click();
         await walkmeShoutout.waitFor(SMALL_TIMEOUT, "hidden");
      }

      const runButtonDisable = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("runButtonDisable", COMMON_COMPONENT_NAME)
      );
      const runButtonEnable = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("runButtonEnable", COMMON_COMPONENT_NAME)
      );

      // Wait for the disabled button to become hidden (button becomes enabled)
      await runButtonDisable.waitFor(MAX_TEST_TIMEOUT, "hidden");

      // Wait for the enabled button to be visible and clickable
      await runButtonEnable.waitFor(MAX_TEST_TIMEOUT, "visible");

      // Click the enabled Run button
      await runButtonEnable.click();

      console.log("Successfully clicked Run button");
    } catch (error) {
      console.error("Failed to click Run button:", error);
      throw new Error("Timeout while waiting for Run button to be clickable.");
    }
  }

  /**
   * Waits for the report run process to complete by monitoring the visibility
   * of the cancel button during spinner activity. Handles timeout scenarios.
   */
  public async waitForReportRunCompletion(): Promise<void> {
    const cancelButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "inProgressCancel",
        COMMON_COMPONENT_NAME
      )
    );

    try {
      // First wait until the cancel button becomes visible (indicates run started)
      await cancelButton.waitFor(MAX_TEST_TIMEOUT, "visible");
      // Then wait until the cancel button disappears (indicates run completed used Run test timeout which is longer than Max test timeout)
      await cancelButton.waitFor(RUN_TEST_TIMEOUT, "hidden");
    } catch (error) {
      console.error(
        "Cancel button did not disappear within the expected duration:",
        error
      );
      throw new Error("Report run did not complete within the timeout period.");
    }

    // Immediately check for backend/UI error banner after run completion
    const runErrorMessage = await this.checkForErrors();

    if (runErrorMessage) {
      // Stop the test early if an error occurred during report generation
      throw new Error(`Report run failed; aborting test. Error: ${runErrorMessage}`);
    }
    console.info("Report run completed!");
  }

  /**
   * Initiates the process to make a copy of a report.
   * This involves checking for save dropdown visibility and clicking the appropriate
   * 'Make a Copy' icon, updating the report title, selecting the save location, and saving the new report.
   * After the save operation, it waits for the page to re-render and then retrieves
   * the URL of the new report.
   * Finally, it closes the browser tab and returns an object containing both the
   * new report's title and its URL.
   *
   * @returns {Promise<{ newReportTitle: string, newUrl: string }>}
   */
  public async makeAcopy(): Promise<{
    newReportTitle: string;
    newUrl: string;
  }> {
    // Check if save dropdown menu is visible
    const saveDropdownMenu = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("saveDropdownMenu", COMMON_COMPONENT_NAME)
    );

    try {
      // Try to check if save dropdown is visible (with a short timeout)
      await saveDropdownMenu.waitFor(SMALL_TIMEOUT, "visible");

      // If dropdown is visible, use dropdown flow
      await this.clickSaveDropdownMenu();
      await this.clickMakeAcopyIcon();
    } catch (error) {
      // If dropdown is not visible, use the regular save icon flow
      console.log("Save dropdown not visible, using regular save icon flow");
      await this.clickSaveIcon();
    }

    let newReportTitle = await this.updateReportTitle();
    await this.clickMyAssets();
    await this.clickSaveButton();
    await this.webActionHandler.delay(SMALL_TIMEOUT); //Todo: Added a delay after clicking the 'Save' button to accommodate page re-rendering; need to find an alternative approach
    let newUrl = await this.webActionHandler.getPageUrl();
    await this.webActionHandler.closeBrowserTab();
    return { newReportTitle, newUrl };
  }



  /**
   * Clicks the save icon after ensuring it is visible.
   * Throws an error if the icon is not found or not clickable within timeout.
   */
  public async saveReport(): Promise<{
    newReportTitle: string;
    newUrl: string;
  }> {
    await this.clickSaveReportIcon();
    let newReportTitle = await this.updateReportTitle();
    await this.clickMyAssets();
    await this.clickSaveButton();
    const cancelButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "inProgressCancel",
        COMMON_COMPONENT_NAME
      )
    );
    
    try {
      await cancelButton.waitFor(RUN_TEST_TIMEOUT, "visible");
      // Then wait until the cancel button disappears (indicates save completed)
      await cancelButton.waitFor(RUN_TEST_TIMEOUT, "hidden");
    } catch (error) {
      console.log("inProgressCancel button not found, continuing with save...");
    }
    
    await this.webActionHandler.delay(SMALL_TIMEOUT);
    let newUrl = await this.webActionHandler.getPageUrl();
    await this.webActionHandler.closeBrowserTab();
    return { newReportTitle, newUrl };
  }
  /**
   * Clicks the "Make a copy" icon after ensuring it is visible and enabled.
   * Throws an error if the icon is not found, not visible, or not clickable within the timeout.
   */
  // public async clickMakeAcopyIcon(): Promise<void> {
  //   // Wait for and click the "Save" icon
  //   await this.clickSaveIcon();

  //   // Locate the "Make a copy" icon
  //   const makeAcopyIcon = this.webActionHandler.getWebElement(
  //     this.resourceManager.getResource("makeAcopy", COMMON_COMPONENT_NAME)
  //   ); // TODO: "Make a copy" element lacks a data-test-id; consider adding one for reliable test targeting in the future #refactor-data-test-id

  //   try {
  //     // Wait for the icon to be visible and enabled
  //     await makeAcopyIcon.waitFor();

  //     // Click the icon
  //     await makeAcopyIcon.click();
  //   } catch (error) {
  //     throw new Error(
  //       "Failed to click 'Make a copy' icon: element not visible or clickable."
  //     );
  //   }
  // }

  /**
   * Clicks the save dropdown menu to reveal save options.
   * Throws an error if the dropdown is not found or not clickable within timeout.
   */
  public async clickSaveDropdownMenu(): Promise<void> {
    const saveDropdownMenu = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("saveDropdownMenu", COMMON_COMPONENT_NAME)
    );
    try {
      await saveDropdownMenu.waitFor();
      await saveDropdownMenu.click();
    } catch (error) {
      throw new Error(
        "Failed to click Save dropdown menu: element not visible or clickable."
      );
    }
  }

  /**
   * Clicks the make a copy icon using the data-test-id selector.
   * Throws an error if the icon is not found, not visible, or not clickable within the timeout.
   */
  public async clickMakeAcopyIcon(): Promise<void> {
    const makeAcopyIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("makeAcopyIcon", COMMON_COMPONENT_NAME)
    );

    try {
      // Wait for the icon to be visible and enabled
      await makeAcopyIcon.waitFor();

      // Click the icon
      await makeAcopyIcon.click();
    } catch (error) {
      throw new Error(
        "Failed to click 'Make a copy' icon: element not visible or clickable."
      );
    }
  }

  /**
   * Clicks the save icon after ensuring it is visible.
   * Throws an error if the icon is not found or not clickable within timeout.
   */
  public async clickSaveIcon(): Promise<void> {
    const saveIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("saveIcon", COMMON_COMPONENT_NAME)
    );
    try {
      await saveIcon.waitFor();
      await saveIcon.click();
    } catch (error) {
      throw new Error(
        "Failed to click Save icon: element not visible or clickable."
      );
    }
  }

  public async clickSaveReportIcon(): Promise<void> {
    const saveIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("saveReportIcon", COMMON_COMPONENT_NAME)
    );
    try {
      // Wait for save icon with extended timeout (report needs to fully render)
      await saveIcon.waitFor(MAX_TEST_TIMEOUT, "visible");
      await saveIcon.click();
    } catch (error) {
      throw new Error(
        "Failed to click Save icon (resource: saveReportIcon): element not visible or clickable."
      );
    }
  }


  /**
   * Retrieves and updates the report title input field with a new value.
   * @param prefix - The prefix to prepend to the existing report title.
   * @returns The updated report title.
   */
  public async updateReportTitle(): Promise<string> {
    const reportTitleInput = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "reportTitleInput",
        COMMON_COMPONENT_NAME
      )
    );

    // Wait for the report title input to be visible
    await reportTitleInput.waitFor();

    // Retrieve the current value of the report title
    const originalTitle = await reportTitleInput.getValue();

    // Construct the new report title
    const newReportTitle = `Playwright automation - ${originalTitle}`;

    // Enter the new report title into the input field
    await reportTitleInput.enterText(newReportTitle);

    return newReportTitle;
  }

  /**
   * Clicks on the "My assets" element after ensuring it is visible and clickable.
   * Throws an error if the element is not found or not clickable within the specified timeout.
   */
  public async clickMyAssets(): Promise<void> {
    const myAssetsElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("My assets", COMMON_COMPONENT_NAME)
    ); // TODO: "My assets" element lacks a data-test-id; consider adding one for reliable test targeting in the future #refactor-data-test-id

    try {
      // Wait for the "My assets" element to be visible
      await myAssetsElement.waitFor();

      // Click on the "My assets" element
      await myAssetsElement.click();
    } catch (error) {
      throw new Error(
        "Failed to click 'My assets' element: element not visible or clickable."
      );
    }
  }

  /**
   * Clicks on the "Save" button after ensuring it is visible and clickable.
   * Throws an error if the element is not found or not clickable within the specified timeout.
   */
  public async clickSaveButton(): Promise<void> {
    const saveButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("Save button", COMMON_COMPONENT_NAME)
    );

    try {
      // Wait for the "Save" button to be visible
      await saveButton.waitFor();

      // Click on the "Save" button
      await saveButton.click();
    } catch (error) {
      throw new Error(
        "Failed to click 'Save' button: element not visible or clickable."
      );
    }
  }

  /**
   * Navigates the browser to the specified URL within the given timeout.
   *
   * @param targetUrl - The full URL to navigate to.
   * @param timeout - Optional maximum time to wait for navigation. Defaults to NAVIGATION_TIMEOUT.
   */
  public async navigateToUrl(
    targetUrl: string,
    timeout: number = NAVIGATION_TIMEOUT
  ): Promise<void> {
    try {
      await this.webActionHandler.navigateTo(targetUrl, timeout, "domcontentloaded");
    } catch (navigationError) {
      console.error(`Navigation to URL failed: ${targetUrl}`, navigationError);
      throw navigationError;
    }
  }

 /**
   * Navigates to report URL and retries once if an error banner appears.
   */
  public async navigateToReportUrl(targetUrl: string): Promise<void> {
    console.log(`Navigating to report URL: ${targetUrl}`);

    await this.navigateToUrl(targetUrl, MAX_TEST_TIMEOUT);

    const madlibContent = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("Madlib content", COMMON_COMPONENT_NAME)
    );
    await madlibContent.waitFor(MAX_TEST_TIMEOUT, "visible");

    const initialErrorMessage = await this.checkForErrors();
    if (initialErrorMessage) {
      console.warn("Error banner detected after navigation. Retrying once...");
      await this.navigateToUrl(targetUrl, MAX_TEST_TIMEOUT);
      await madlibContent.waitFor(MAX_TEST_TIMEOUT, "visible");
      await this.webActionHandler.delay(SMALL_TIMEOUT);

      const retryErrorMessage = await this.checkForErrors();
      if (retryErrorMessage) {
        throw new Error(`Report page failed to load correctly: ${retryErrorMessage}`);
      }
    }

    console.log("Report page loaded successfully");
  }


  /**
 * Sends Enter key press to the current focused element.
 * Uses the WebActions keyPressOnPage method from the GTA library.
 * 
 * @throws {Error} Throws an error if the key press action fails
 * @returns {Promise<void>}
 */
  public async pressEnterKey(): Promise<void> {
    try {
      // Use the GTA library's keyPressOnPage method to press Enter
      await this.webActionHandler.keyPressOnPage("Enter");
      console.log("Successfully pressed Enter key");
    } catch (error) {
      console.error("Failed to press Enter key:", error);
      throw new Error(`Failed to press Enter key: ${(error as Error).message}`);
    }
  }

  /**
   * Returns the base page instance.
   * @returns {BasePage} The base page instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }

  //***Webelement
  public async getWebelement(elementName: string, componentName: string): Promise<WebElement> {
    try {
      const element = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(elementName, componentName)
      );
      return element;
    } catch (error) {
      throw new Error(`Failed to get WebElement for '${elementName}': ${(error as Error).message}`);
    }
  }

  /**
   * Enhanced click web element with comprehensive validation
   * @param elementName - The name of the element to click
   * @param componentName - The component name where the element is defined
   * @param options - Optional configuration for click behavior
   */
  public async clickWebelement(
    elementName: string,
    componentName: string,
    options?: {
      waitForElement?: boolean;
      timeout?: number;
    }
  ): Promise<void> {
    const {
      waitForElement = true,
      timeout = NAVIGATION_TIMEOUT
    } = options || {};

    try {
      // 1. Validate that the element exists in resources
      const resource = this.resourceManager.getResource(elementName, componentName);
      if (!resource) {
        throw new Error(`Element '${elementName}' not found in component '${componentName}' resources`);
      }

      console.log(`Clicking element: ${elementName} in component: ${componentName}`);

      // 2. Get the web element
      const element = this.webActionHandler.getWebElement(resource);

      // 3. Wait for element if requested (this ensures element is ready for interaction)
      if (waitForElement) {
        await element.waitFor(timeout);
      }

      // 4. Perform the click (Playwright will automatically validate visibility and enabled state)
      await element.click();

      console.log(`Successfully clicked element: ${elementName}`);

    } catch (error) {
      const errorMessage = `Failed to click element '${elementName}' in component '${componentName}': ${error instanceof Error ? error.message : String(error)}`;
      console.error(errorMessage);
      throw new Error(errorMessage);
    }
  }
  public async clickShareIcon(): Promise<void> {
    const shareIconBtn = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("shareIconBtn", COMMON_COMPONENT_NAME)
    );
    console.log("Share Icon Button found");
    try {
      await shareIconBtn.waitFor();
      await shareIconBtn.click();
    } catch (error) {
      throw new Error(
        "Failed to click Share icon: element not visible or clickable."
      );
    }
  }

  /**
   * Validates the full screen (expand) view by clicking the expand icon,
   * waiting for the expanded UI to appear, asserting presence of key elements,
   * and then closing the expanded view.
   */
  public async fullScreenView(): Promise<void> {
    try {
      const expand = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("expandIcon", COMMON_COMPONENT_NAME)
      );

      await expand.waitFor();
      await expand.click();

      const closeIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("closeExpandViewIcon", COMMON_COMPONENT_NAME)
      );

      const storyButtonEl = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("storyTextButton", COMMON_COMPONENT_NAME)
      );

      await closeIcon.waitFor(MAX_TEST_TIMEOUT);
      await storyButtonEl.waitFor(MAX_TEST_TIMEOUT);

      const storyVisible = await storyButtonEl.isVisible();
      const closeVisible = await closeIcon.isVisible();

      assert(storyVisible).toBeTruthy();
      assert(closeVisible).toBeTruthy();

      await closeIcon.click();
    } catch (error) {
      console.error("Failed while validating full screen view:", error);
      throw error;
    }
  }

  /**
   * Enters presentation mode by clicking the presentation icon,
   * validating the pagination, dataset info and branding icon, then exits.
   */
  public async presentationMode(): Promise<void> {
    try {
      const presentationIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("presentationIcon", COMMON_COMPONENT_NAME)
      );

      await presentationIcon.waitFor();
      await presentationIcon.click();

      const pagination = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("presentationPagination", COMMON_COMPONENT_NAME)
      );

      const datasetInfo = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("datasetInfo", COMMON_COMPONENT_NAME)
      );

      const niqIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("niqIcon", COMMON_COMPONENT_NAME)
      );

      await pagination.waitFor(MAX_TEST_TIMEOUT);
      await datasetInfo.waitFor(MAX_TEST_TIMEOUT);
      await niqIcon.waitFor(MAX_TEST_TIMEOUT);

      const paginationVisible = await pagination.isVisible();
      const datasetVisible = await datasetInfo.isVisible();
      const niqVisible = await niqIcon.isVisible();

      assert(paginationVisible).toBeTruthy();
      assert(datasetVisible).toBeTruthy();
      assert(niqVisible).toBeTruthy();

      const exitBtn = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("exitButton", COMMON_COMPONENT_NAME)
      );

      await exitBtn.waitFor();
      await exitBtn.click();
    } catch (error) {
      console.error("Validation failed in Presentation Mode!:", error);
      throw error;
    }
  }

  /**
   * Validates the story save flow from presentation mode.
   * Steps:
   *  - open presentation
   *  - click save story
   *  - enter story name
   *  - confirm (OK)
   *  - assert success toast
   */
  public async storyValidation(): Promise<void> {
    try {
      const presentationIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("presentationIcon", COMMON_COMPONENT_NAME)
      );
      await presentationIcon.waitFor(MAX_TEST_TIMEOUT);
      await presentationIcon.click();

      const saveStoryIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("saveStoryIcon", COMMON_COMPONENT_NAME)
      );
      await saveStoryIcon.waitFor(MAX_TEST_TIMEOUT);
      await saveStoryIcon.click();

      const storyInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("storyNameInput", COMMON_COMPONENT_NAME)
      );
      await storyInput.waitFor(MAX_TEST_TIMEOUT);
      await storyInput.enterText("playwright -story");

      const okButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("storyOkButton", COMMON_COMPONENT_NAME)
      );
      await okButton.waitFor(MAX_TEST_TIMEOUT);
      await okButton.click();

      const toast = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("storySuccessToast", COMMON_COMPONENT_NAME)
      );
      await toast.waitFor(MAX_TEST_TIMEOUT);
      const visible = await toast.isVisible();
      assert(visible).toBeTruthy();
    } catch (error) {
      console.error("Story validation failed:", error);
      throw error;
    }
  }
  /**
   * Checks for an error banner and returns its message if present.
   * @returns error message string if error banner displayed, otherwise empty string.
   */
  public async checkForErrors(): Promise<string> {
    try {
      const errorBanner = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("errorBanner", COMMON_COMPONENT_NAME)
      );
      await errorBanner.waitFor(SMALL_TIMEOUT, "visible");
      const isVisible = await errorBanner.isVisible();
      if (isVisible) {
        const errorMessageElement = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("errorTextMessage", COMMON_COMPONENT_NAME)
        );
        const errorMessage = await errorMessageElement.getText();
        console.error(`Error banner displayed with message: ${errorMessage}`);
        return errorMessage;
      } else {
        return "";
      }
    } catch (err) {
      // Banner not found or not visible within timeout
      return "";
    }
  }

  /**
   * Compares the current page screenshot with the baseline for visual regression testing.
   * 
   * This method implements a meaningful folder hierarchy for organizing baseline screenshots:
   * - Browser level (chromium/firefox/webkit)
   * - Report folder (automatically determined from test file path)
   * - Dataset level (from config.DATASET)
   * - Environment level (from config.ENV - DEV/SI/UAT)
   * 
   * Folder structure: baseline-screenshots/{reportName}/{browser}/{dataset}/{environment}/{testCaseName}.png
   * 
   * SIMPLIFIED VERSION (RECOMMENDED - keeps element selector, removes reportName):
   * The reportName is auto-detected from your test file name (e.g., assortment-optimizer.spec.ts -> "assortment-optimizer")
   * 
   * @example
   * ```typescript
   * // Just 3 parameters - element selector is KEPT (critical!)
   * await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q1-toggle-0", "lib-sop-assortment-optimizer");
   * await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q2", "lib-sop-assortment-optimizer");
   * ```
   * 
   * EXTENDED VERSION (for overriding reportName or custom maxDiffPixels):
   * 
   * @example
   * ```typescript
   * // If you need to override the auto-detected report name or customize tolerance
   * await commonTestCase.compareScreenshotAfterRun("custom-report", testInfo, "after-run", 150, "lib-custom-element");
   * ```
   */
  public async compareScreenshotAfterRun(
    testInfo: TestInfo,
    testCaseName: string,
    elementSelector: string
  ): Promise<void>;

  public async compareScreenshotAfterRun(
    reportNameOrTestInfo: string | TestInfo,
    testInfoOrTestCaseName: TestInfo | string,
    testCaseNameOrElementSelector?: string,
    maxDiffPixels: number = 100,
    elementSelector?: string
  ): Promise<void> {
    // Handle overloaded parameters - declare outside try for catch block scope
    let reportName: string = "unknown-report";
    let testCaseName: string = "unknown-test";
    let testInfo: TestInfo;
    let actualElementSelector: string = "";
    let actualMaxDiffPixels: number = 100;

    try {
      // Determine which overload was called based on first parameter type
      if (typeof reportNameOrTestInfo === "string") {
        // Extended signature: (reportName, testInfo, testCaseName, maxDiffPixels?, elementSelector?)
        reportName = reportNameOrTestInfo;
        testInfo = testInfoOrTestCaseName as TestInfo;
        testCaseName = testCaseNameOrElementSelector || "after-run";
        actualElementSelector = elementSelector || "";
        actualMaxDiffPixels = maxDiffPixels;
      } else {
        // Simplified signature: (testInfo, testCaseName, elementSelector)
        // Auto-detect reportName from test file path
        testInfo = reportNameOrTestInfo;
        testCaseName = testInfoOrTestCaseName as string;
        actualElementSelector = testCaseNameOrElementSelector || "";
        
        // Auto-detect reportName from test file path
        // e.g., assortment-optimizer.spec.ts -> "assortment-optimizer"
        const testFilePath = testInfo.file || "";
        const fileNameMatch = testFilePath.match(/([a-z0-9-]+)\.spec\.ts$/i);
        reportName = fileNameMatch ? fileNameMatch[1] : "unknown-report";
        
        console.log(`📂 Auto-detected report name from test path: ${reportName}`);
      }

      // Wait for page stability after state change
      // This ensures all animations and DOM updates are complete
      await this.webActionHandler.delay(DATASET_PROCESSING_DELAY);

      // Get browser name from testInfo (chromium, firefox, webkit)
      const browserName = testInfo.project.name || "chromium";

      // Get dataset from config and sanitize for folder name (remove special characters)
      const dataset = config.DATASET.replace(/[^a-zA-Z0-9-_]/g, "-").toLowerCase();

      // Get environment from config (DEV, SI, UAT)
      const environment = config.ENV.toLowerCase();

      // Construct the meaningful folder structure path
      // Format: baseline-screenshots/{reportName}/{browser}/{dataset}/{environment}/{runtimeProfile}/
      // Keep dataset short to avoid Windows filename length limit (260 chars)
      const datasetShort = dataset.split(/[-_]/)[0].toLowerCase(); // Take first part only: "omni-agg-si" → "omni"
      
      // Sanitize dynamic inputs to prevent path traversal and file system attacks
      // Only allow alphanumeric, hyphens, and underscores in path components
      const sanitizedReportName = reportName.replace(/[^a-zA-Z0-9-_]/g, "-").toLowerCase();
      const sanitizedBrowserName = browserName.replace(/[^a-zA-Z0-9-_]/g, "-").toLowerCase();
      const sanitizedTestCaseName = testCaseName.replace(/[^a-zA-Z0-9-_]/g, "-").toLowerCase();
      const sanitizedEnvironment = environment.replace(/[^a-zA-Z0-9-_]/g, "-").toLowerCase();
      
      // Extract the internal Playwright Page object from GTA's WebActions
      // This is necessary because GTA framework doesn't expose the page publicly
      // We use type assertion to access the private 'page' property
      const page: Page = (this.webActionHandler as any).page;

      if (!page) {
        throw new Error("Failed to extract Playwright Page object from WebActions");
      }

      const runtimeMode = process.env.LAMBDATEST === "true" ? "lt" : "local";
      const viewport = page.viewportSize() ?? (await page.evaluate(() => ({
        width: window.innerWidth,
        height: window.innerHeight,
      })));
      const runtimeProfile = `${runtimeMode}-${viewport.width}x${viewport.height}`;
      const sanitizedRuntimeProfile = runtimeProfile.replace(/[^a-zA-Z0-9-_]/g, "-").toLowerCase();

      const screenshotPath = path.join(
        "baseline-screenshots",
        sanitizedReportName,
        sanitizedBrowserName,
        datasetShort,
        sanitizedEnvironment,
        sanitizedRuntimeProfile,
        `${sanitizedTestCaseName}.png`
      );

      console.log(`📸 Taking screenshot for visual comparison...`);
      console.log(`   Report: ${reportName}`);
      console.log(`   Browser: ${browserName}`);
      console.log(`   Dataset: ${dataset}`);
      console.log(`   Environment: ${environment}`);
      console.log(`   Runtime Profile: ${runtimeProfile}`);
      console.log(`   Test Case: ${testCaseName}`);
      console.log(`   Element Selector: ${actualElementSelector || "full-page"}`);
      console.log(`   Path: ${screenshotPath}`);

      // If elementSelector is provided, capture only that element
      // Otherwise, capture the full page
      const shouldAutoCreateBaseline =
        testInfo.config.updateSnapshots === "all" || testInfo.config.updateSnapshots === "missing";
      if (actualElementSelector) {
        const element = page.locator(actualElementSelector);
        
        // Verify element exists before taking screenshot
        const isVisible = await element.isVisible().catch(() => false);
        if (!isVisible) {
          throw new Error(`Element selector "${actualElementSelector}" is not visible or does not exist`);
        }

        console.log(`   Capturing element screenshot: ${actualElementSelector}`);
        
        // Get element's bounding box to determine if it's larger than viewport
        const boundingBox = await element.boundingBox();
        if (!boundingBox) {
          throw new Error(`Could not determine bounding box for element "${actualElementSelector}"`);
        }

        console.log(`   Element dimensions: ${boundingBox.width}x${boundingBox.height}`);
        
        // Set viewport dynamically based on current browser viewport + element size
        const originalViewport = page.viewportSize();
        const currentBrowserViewport = await page.evaluate(() => ({
          width: window.innerWidth,
          height: window.innerHeight,
        }));
        const baseViewport = originalViewport ?? currentBrowserViewport;
        
        // Temporarily resize viewport to capture full element
        await page.setViewportSize({
          width: Math.round(Math.max(boundingBox.width + 20, baseViewport.width)),
          height: Math.round(Math.max(boundingBox.height + 100, baseViewport.height))
        });

        try {
          // Scroll element to top to capture from beginning
          await element.evaluate((el) => {
            el.scrollTop = 0;
            el.scrollLeft = 0;
          });

          // Small delay for scroll to settle
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

          // Auto-create baseline snapshot on first run for this browser/runtime profile
          const expectedSnapshotPath = testInfo.snapshotPath(screenshotPath);
          if (shouldAutoCreateBaseline && !fs.existsSync(expectedSnapshotPath)) {
            fs.mkdirSync(path.dirname(expectedSnapshotPath), { recursive: true });
            await element.screenshot({
              path: expectedSnapshotPath,
              animations: "disabled",
              scale: "css",
              caret: "hide",
            });
            console.log(`🆕 Baseline created: ${expectedSnapshotPath}`);
          }

          // Now capture the element
          await expect(element).toHaveScreenshot(screenshotPath, {
            maxDiffPixels: actualMaxDiffPixels,
            maxDiffPixelRatio: 0.02,
            timeout: MAX_TEST_TIMEOUT,
            animations: "disabled",
            scale: "css",
            caret: "hide",
          });
        } finally {
          // Restore original/current viewport even when assertion fails
          const restoreViewport = originalViewport ?? currentBrowserViewport;
          if (restoreViewport?.width && restoreViewport?.height) {
            await page.setViewportSize(restoreViewport);
          }
        }
      } else {
        // Auto-create baseline snapshot on first run for this browser/runtime profile
        const expectedSnapshotPath = testInfo.snapshotPath(screenshotPath);
        if (shouldAutoCreateBaseline && !fs.existsSync(expectedSnapshotPath)) {
          fs.mkdirSync(path.dirname(expectedSnapshotPath), { recursive: true });
          await page.screenshot({
            path: expectedSnapshotPath,
            fullPage: true,
            animations: "disabled",
            scale: "css",
            caret: "hide",
          });
          console.log(`🆕 Baseline created: ${expectedSnapshotPath}`);
        }

        // Perform full page screenshot comparison
        await expect(page).toHaveScreenshot(screenshotPath, {
          fullPage: true,
          maxDiffPixels: actualMaxDiffPixels,
          maxDiffPixelRatio: 0.02,
          timeout: MAX_TEST_TIMEOUT,
          animations: "disabled",
          scale: "css",
          caret: "hide",
        });
      }

      console.log(`✅ Screenshot comparison passed for ${reportName} - ${testCaseName}`);
    } catch (error) {
      console.error(`❌ Screenshot comparison failed for ${reportName}:`, error);
      throw new Error(
        `Visual regression test failed for ${reportName} (${testCaseName}): ${
          error instanceof Error ? error.message : String(error)
        }`
      );
    }
  }
}