import { DimensionSelection, Prompt } from '@nielsen/crf-common';
import { cloneDeep } from 'lodash-es';

export function resolveDatasetName(datasetDetails: any): string {
  return datasetDetails?.title || datasetDetails?.label || datasetDetails?.description || datasetDetails?.id || 'Selected Dataset';
}

/** Prompt restore prioritizes explicit prompt cache, then panel copy, then requestInstance fallback. */
export function getRestoredPrompts(cachedState: any): Prompt[] {
  if (cachedState.dataPrompts?.length) {
    return cloneDeep(cachedState.dataPrompts) || [];
  }

  if (cachedState.panelDataPrompts?.length) {
    return cloneDeep(cachedState.panelDataPrompts) || [];
  }

  return cloneDeep(cachedState.requestInstance?.prompts ?? []) || [];
}

/** Selection restore prioritizes normalized cached selections over request payload fallback. */
export function getRestoredSelections(cachedState: any): DimensionSelection[] {
  if (cachedState.selections?.length) {
    return cloneDeep(cachedState.selections) || [];
  }

  return cloneDeep(cachedState.requestInstance?.dimensionSelections ?? []) || [];
}
