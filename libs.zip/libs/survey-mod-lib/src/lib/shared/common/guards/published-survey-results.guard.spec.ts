import { createEnvironmentInjector, Injector, runInInjectionContext } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, convertToParamMap, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { Observable, of, throwError } from 'rxjs';
import { FLOW_TYPES } from '../../../core/config/config';
import { SurveyStatusType } from '../../../features/build-survey/models/build-survey';

vi.mock('../../../features/build-survey/services/survey.service', () => ({
  SurveyService: class {},
}));

import { SurveyService } from '../../../features/build-survey/services/survey.service';
import {
  redirectPublishedSurveyEditsGuard,
  redirectUnpublishedSurveyResultsGuard,
} from './published-survey-results.guard';

describe('redirectPublishedSurveyEditsGuard', () => {
  const surveyService = {
    ensureSurveyLoaded: vi.fn(),
    loadedSurveyDetails: vi.fn(),
    clearSurveyId: vi.fn(),
  };

  const router = {
    createUrlTree: vi.fn((commands: unknown[]) => ({ commands } as unknown as UrlTree)),
    parseUrl: vi.fn((url: string) => ({ url } as unknown as UrlTree)),
  };

  beforeEach(() => {
    vi.clearAllMocks();
    surveyService.ensureSurveyLoaded.mockReturnValue(of(null));
    surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.DRAFT } });
  });

  const executeGuard = async (
    surveyId: string | null,
    flowType: string = FLOW_TYPES.SCRATCH,
    url: string = '/survey/build-survey/svy_123',
    guard: CanActivateFn = redirectPublishedSurveyEditsGuard,
  ): Promise<boolean | UrlTree> => {
    const route = {
      paramMap: convertToParamMap(surveyId ? { surveyId } : {}),
      parent: { data: { flowType } },
    } as unknown as ActivatedRouteSnapshot;

    const state = { url } as RouterStateSnapshot;

    const injector = createEnvironmentInjector(
      [
        { provide: SurveyService, useValue: surveyService },
        { provide: Router, useValue: router },
      ],
      Injector.NULL as never,
    );

    const result = runInInjectionContext(injector, () => guard(route, state));

    if (!(result instanceof Observable)) {
      return result as boolean | UrlTree;
    }

    return await new Promise<boolean | UrlTree>((resolve, reject) => {
      (result as Observable<boolean | UrlTree>).subscribe({
        next: resolve,
        error: reject,
      });
    });
  };

  it('allows route when survey id is missing', async () => {
    const result = await executeGuard(null);

    expect(result).toBe(true);
    expect(surveyService.ensureSurveyLoaded).not.toHaveBeenCalled();
  });

  it('allows edit route for non-published survey', async () => {
    surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.DRAFT } });

    const result = await executeGuard('svy_123');

    expect(result).toBe(true);
  });

  it('redirects published survey to scratch results route', async () => {
    surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.PUBLISHED } });

    const result = await executeGuard('svy_123', FLOW_TYPES.SCRATCH);

    expect(router.createUrlTree).toHaveBeenCalledWith(['/survey', 'results', 'svy_123']);
    expect(result).toEqual({ commands: ['/survey', 'results', 'svy_123'] });
  });

  it('redirects published survey to aiflow results route', async () => {
    surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.PUBLISHED } });

    const result = await executeGuard('svy_123', FLOW_TYPES.AIFLOW, '/survey/aiflow/build-survey/svy_123');

    expect(router.createUrlTree).toHaveBeenCalledWith(['/survey', 'aiflow', 'results', 'svy_123']);
    expect(result).toEqual({ commands: ['/survey', 'aiflow', 'results', 'svy_123'] });
  });

  it('fails open when survey loading fails', async () => {
    surveyService.ensureSurveyLoaded.mockReturnValue(throwError(() => new Error('load failed')));

    const result = await executeGuard('svy_123');

    expect(result).toBe(true);
  });

  describe('redirectUnpublishedSurveyResultsGuard', () => {
    const runResultsGuard = (surveyId: string | null, flowType: string = FLOW_TYPES.SCRATCH, url = '/survey/results/svy_123') =>
      executeGuard(surveyId, flowType, url, redirectUnpublishedSurveyResultsGuard);

    it('allows results route for published survey', async () => {
      surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.PUBLISHED } });

      const result = await runResultsGuard('svy_123');

      expect(result).toBe(true);
    });

    it('redirects non-published survey to its launch URL', async () => {
      surveyService.loadedSurveyDetails.mockReturnValue({
        assetInfo: { status: SurveyStatusType.DRAFT, launchURL: 'survey/aiflow/build-survey/svy_123' },
      });

      const result = await runResultsGuard('svy_123');

      expect(result).toEqual({ url: '/survey/aiflow/build-survey/svy_123' });
    });

    it('redirects non-published survey with no launch URL to a computed one', async () => {
      const result = await runResultsGuard('svy_123');

      expect(result).toEqual({ url: '/survey/build-survey/svy_123' });
    });

    it('redirects to a computed aiflow launch URL when none is stored', async () => {
      const result = await runResultsGuard('svy_123', FLOW_TYPES.AIFLOW, '/survey/aiflow/results/svy_123');

      expect(result).toEqual({ url: '/survey/aiflow/build-survey/svy_123' });
    });

    it('redirects to build-survey when the computed launch URL would loop back to results', async () => {
      surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.LIVE } });

      const result = await runResultsGuard('svy_123');

      expect(result).toEqual({ commands: ['/survey', 'build-survey', 'svy_123'] });
      expect(router.parseUrl).not.toHaveBeenCalled();
    });

    it.each(['https://evil.com/x', 'javascript://x', 'survey/results/svy_123'])(
      'redirects to build-survey for unsafe or looping launch URL %s',
      async (launchURL) => {
        surveyService.loadedSurveyDetails.mockReturnValue({ assetInfo: { status: SurveyStatusType.LIVE, launchURL } });

        const result = await runResultsGuard('svy_123');

        expect(result).toEqual({ commands: ['/survey', 'build-survey', 'svy_123'] });
        expect(router.parseUrl).not.toHaveBeenCalled();
      },
    );

    it('allows results route when survey loading fails', async () => {
      surveyService.ensureSurveyLoaded.mockReturnValue(throwError(() => new Error('load failed')));

      const result = await runResultsGuard('svy_123');

      expect(result).toBe(true);
      expect(surveyService.clearSurveyId).toHaveBeenCalled();
    });

    it('allows results route when survey id is missing', async () => {
      const result = await runResultsGuard(null);

      expect(surveyService.ensureSurveyLoaded).not.toHaveBeenCalled();
      expect(result).toBe(true);
    });
  });
});
