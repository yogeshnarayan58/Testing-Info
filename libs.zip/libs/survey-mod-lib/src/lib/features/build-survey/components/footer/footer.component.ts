import { Component, computed, inject, input, output } from '@angular/core';
import { ButtonModule, IconModule, SpinnerModule } from '@nielseniq/athena-core';
import {
  SurveyAIValidationState,
  SURVEY_VALIDATION_STATE,
} from '../../models/build-survey';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'build-survey-footer',
  imports: [IconModule, ButtonModule, SpinnerModule, TranslateModule],
  providers: [TranslateService],
  standalone: true,
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  isPublishDisable = input(false);
  surveyAIValidationState = input<SurveyAIValidationState | null>();
  private readonly translate = inject(TranslateService);
  readonly SURVEY_VALIDATION_STATE  = SURVEY_VALIDATION_STATE 

  publish = output<void>();
  goBack = output<void>();
  validateSurvey = output<void>();

  readonly surveyAIValidationInProgress = computed(
    () => this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS
  );

  readonly buttonLabel = computed(() => {
    switch (this.surveyAIValidationState()) {
      case SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW:
        return 'SURVEYMOD_REVALIDATE_SURVEY';

      case SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH:
        return 'SURVEYMOD_REVIEW_PUBLISH_SURVEY';

      default:
        return 'SURVEYMOD_VALIDATE_SURVEY';
    }
  });

  onValidationAction(): void {
    if (this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH) {
      this.publish.emit();
    } else {
      this.validateSurvey.emit();
    }
  }
}
