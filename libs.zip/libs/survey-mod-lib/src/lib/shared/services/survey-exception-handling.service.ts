import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { errorConfig } from '@nielsen/crf-lp-common';
import { BehaviorSubject } from 'rxjs';

export interface SurveyErrorHandlingOptions {
  /** Set to false when the component already shows the failure inline. */
  displayToastOnError?: boolean;
}

export const DEFAULT_ERROR_CODE = 'ER0001';

@Injectable({ providedIn: 'root' })
export class SurveyExceptionHandlingService {
  public errorResponseSubject: BehaviorSubject<errorConfig> = new BehaviorSubject<errorConfig>({});
  public interceptorErrorSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor() {
    this.interceptorErrorSubject.subscribe(response => {
      if (response) {
        response.afterToastSubject.subscribe((afterError: any) => {});
      }
    });
  }

  public handleError(errorOptions: errorConfig) {
    this.errorResponseSubject.next(errorOptions);
  }

  /** Builds the error options from a failed survey API call and emits them. */
  public handleApiError(error: unknown, options: SurveyErrorHandlingOptions = {}): void {
    const displayToastOnError = options.displayToastOnError ?? true;

    if (!displayToastOnError) {
      this.handleError({ displayToastOnError: false });
      return;
    }

    const httpError = error as HttpErrorResponse | undefined;
    const errorCode = httpError?.error?.errorCode ?? DEFAULT_ERROR_CODE;

    if (!errorCode) {
      this.handleError({ displayToastOnError: true });
      return;
    }

    const transactionId: string | undefined = httpError?.headers?.get?.('x-nlsn-tnxn-id')?.split(',')[0];

    this.handleError({
      displayToastOnError: true,
      errorCodeConfig: {
        errorCode: String(errorCode),
        params: [],
        transactionId
      }
    });
  }
}
