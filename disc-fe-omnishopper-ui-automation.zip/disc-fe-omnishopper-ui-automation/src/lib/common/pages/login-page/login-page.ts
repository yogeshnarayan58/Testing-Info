/**
 * @fileoverview Login page implementation for the Omnishopper application.
 * Handles authentication flow using the Page Object Model pattern.
 *
 * This module provides credential validation and login functionality,
 * abstracting away the UI interaction details from test code.
 */
import { BasePage, WebActions } from "@gfk/gta";
import loginPageResources from "./loginPageResources.json";
import { MAX_TEST_TIMEOUT, NAVIGATION_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ResourceManager } from "../../utils/resource-manager";
import { ElementResource } from "../../interfaces/iElementResource";

const LOGIN_PAGE_COMPONENT_NAME = "loginPage";
const loginPageElements = loginPageResources as ElementResource;

/**
 * Validates credentials before attempting login
 */
function validateCredentials(username: string, password: string): void {
  // Ensure template placeholder values have been replaced with actual credentials
  if (!(username && password)) {
    throw new Error(
      'Default credentials detected. Please replace "USER_NAME" and "PASS_WORD" in the .env file with actual automation service account credentials.'
    );
  }
}
// Get credentials
const USERNAME = process.env.USER_NAME || "";
const PASSWORD = process.env.PASS_WORD || "";
validateCredentials(USERNAME, PASSWORD);

/**
 * Page object representing the login page of the application.
 * Handles authentication flow and related operations.
 */
export class LoginPage {
  private webActionHandler: WebActions;
  private resourceManager: ResourceManager;

  /**
   * Creates an instance of LoginPage.
   * @param {BasePage} basePage - The base page object containing common functionality
   */
  constructor(private basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
    this.resourceManager.registerResources(
      LOGIN_PAGE_COMPONENT_NAME,
      loginPageElements
    );
  }
  /**
 * Accept Terms & Conditions only if terms checkbox is visible
 */
private async acceptTermsIfPresent(): Promise<void> {
  console.log("Checking for Terms & Conditions page...");

  try {
    const checkbox = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("termsAcceptCheckbox", LOGIN_PAGE_COMPONENT_NAME)
    );
    
    await checkbox.waitFor(SMALL_TIMEOUT, "visible");
    console.log("Terms & Conditions page detected - checkbox is visible");

    // Click checkbox
    await checkbox.click(true);
    console.log("Terms checkbox clicked");

    // Click accept button
    const acceptButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("termsAcceptButton", LOGIN_PAGE_COMPONENT_NAME)
    );
    await acceptButton.waitFor(MAX_TEST_TIMEOUT);
    await acceptButton.click();
    console.log("Terms accepted successfully.");
    
  } catch (error) {
    // Terms page not shown or already accepted
    console.log("Terms page not shown or already accepted, continuing login...");
  }
}
  /**
   * Performs login with credentials from environment
   */
  public async login(url: string): Promise<void> {
    try {
      console.log("Starting login process...");

      // await getPage().goto(BASE_URL);
      await this.webActionHandler.navigateTo(url, NAVIGATION_TIMEOUT, "domcontentloaded");

      // await fill(USERNAME_INPUT(), USERNAME);
      await this.webActionHandler
        .getWebElement(this.resourceManager.getResource("userName"))
        .enterText(USERNAME);
      const submitButton = await this.webActionHandler.getWebElement(
        this.resourceManager.getResource(
          "submitButton",
          LOGIN_PAGE_COMPONENT_NAME
        )
      );

      // await clickAndNavigate(NEXT_BUTTON());
      await submitButton.click();

      // await fill(PASSWORD_INPUT(), PASSWORD);
      await this.webActionHandler
        .getWebElement(this.resourceManager.getResource("password"))
        .enterText(PASSWORD);

      // await click(LOGIN_BUTTON());
      await submitButton.click();
      
      // If Terms & Conditions page comes, accept it
      await this.acceptTermsIfPresent();

      // Wait for navigation to complete after terms acceptance (if terms were shown)
      await this.webActionHandler.delay(SMALL_TIMEOUT);

      //Todo: have some method verify the login
      const analyseDataButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("analyseMyData")
      );
      await analyseDataButton.waitFor();

      await this.webActionHandler.getStorageState("storage/auth.json");

      await this.webActionHandler.closeBrowser();

      console.log("Login process completed successfully.");
    } catch (error: any) {
      console.error("Login process failed:", error?.message || error);
      throw new Error(`Login failed: ${error?.message || error}`);
    } finally {
      // Ensure the browser is closed even if an error occurs
      await this.webActionHandler.closeBrowser();
    }
  }
}