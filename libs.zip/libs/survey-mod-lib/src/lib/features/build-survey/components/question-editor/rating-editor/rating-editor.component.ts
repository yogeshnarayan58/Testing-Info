import { Component, computed, ElementRef, model, output } from '@angular/core';
import { ButtonModule, IconButtonModule, IconModule, TextFieldModule, ToggleModule, TooltipModule } from '@nielseniq/athena-core';
import { BaseQuestionEditorDirective } from '../base-question-editor.directive';
import { SuggestionTagsComponent } from '../suggestion-tags/suggestion-tags.component';
import { TranslateModule } from '@ngx-translate/core';
import { MAXIMUM_OPTIONS_ALLOWED } from '../../../models/build-survey';

@Component({
  selector: 'survey-rating-editor',
  standalone: true,
  imports: [ButtonModule, IconButtonModule, TextFieldModule, IconModule, ToggleModule, TooltipModule, SuggestionTagsComponent, TranslateModule],
  templateUrl: './rating-editor.component.html',
  styleUrls: ['./rating-editor.component.scss'],
})
export class RatingEditorComponent extends BaseQuestionEditorDirective {
  /** Notifies the parent that the form changed so it can run validation/preview side effects. */
  formChange = output<void>();
  rowOptions = model<string[]>(['']);
  readonly starScale = [1, 2, 3, 4, 5];
  readonly minRows = 1;
  readonly isAtMaxRows = computed(() => this.rowOptions().length >= MAXIMUM_OPTIONS_ALLOWED);
  readonly isAtMinRows = computed(() => this.rowOptions().length <= this.minRows);

  constructor(elementRef: ElementRef<HTMLElement>) {
    super(elementRef);
  }

  /**
   * Handles input change event.
   * @param value - The new value of the input.
   */
  onInputChange(value: string | number): void {
    this.question.set(String(value ?? ''));
    this.formChange.emit();
  }

  onRowEdit(index: number, value: string | number): void {
    const rows = this.rowOptions();
    if (index < 0 || index >= rows.length) return;

    const updatedRows = [...rows];
    updatedRows[index] = String(value ?? '');
    this.rowOptions.set(updatedRows);
    this.formChange.emit();
  }

  addRow(): void {
    if (!this.isAtMaxRows()) {
      this.rowOptions.set([...this.rowOptions(), '']);
      this.formChange.emit();
    }
  }

  removeRow(index: number): void {
    const rows = this.rowOptions();
    if (!Number.isInteger(index) || index < 0 || index >= rows.length || rows.length <= this.minRows) {
      return;
    }

    this.rowOptions.set(rows.filter((_, rowIndex) => rowIndex !== index));
    this.formChange.emit();
  }

  toggleChange(event: Event): void {
    this.isRequired.set((event.target as HTMLInputElement).checked ?? false);
    this.formChange.emit();
  }
}
