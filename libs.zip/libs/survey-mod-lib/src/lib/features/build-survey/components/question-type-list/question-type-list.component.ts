import { Component, input, model } from '@angular/core';
import {
  IconModule,
  ButtonModule
} from '@nielseniq/athena-core';
import { QuestionType, QuestionTypeOptions } from '../../models/build-survey';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-question-type-list',
  imports: [IconModule, ButtonModule, TranslateModule],
  standalone: true,
  templateUrl: './question-type-list.component.html',
  styleUrls: ['./question-type-list.component.scss']
})
export class QuestionTypeListComponent {
  title = input('Add question');
  selectedType = model<QuestionType | ''>('');
  context = input<'editor' | 'preview'>('editor');
  mode = input<'single' | 'multi'>('single');
  questionTypeOptions = input(QuestionTypeOptions);
  selectedTypes = model<QuestionType[]>([]);
  
  hoveredType: string | null = null;

  isSelected(value: QuestionType): boolean {
    return this.mode() === 'multi'
      ? this.selectedTypes().includes(value)
      : this.selectedType() === value;
  }

  selectQuestionType(type: QuestionType) {
    if (this.mode() === 'multi') {
      const updated = this.isSelected(type)
        ? this.selectedTypes().filter(item => item !== type)
        : [...this.selectedTypes(), type];
      this.selectedTypes.set(updated);
      return;
    }
    this.selectedType.set(type);
  }
}
