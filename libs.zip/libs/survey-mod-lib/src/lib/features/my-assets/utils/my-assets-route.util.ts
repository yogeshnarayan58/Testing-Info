import { MY_ASSETS_TABS, MyAssetsTabId } from '../constants/my-assets-tabs.constant';

/** Preserves the current host prefix, such as /survey or /my-assets/survey. */
export function getMyAssetsRoutePrefix(url: string, tabId: MyAssetsTabId): string[] {
	const segments = url.split(/[?#]/, 1)[0].split('/').filter(Boolean);
	const supportedTabs = Object.values(MY_ASSETS_TABS) as MyAssetsTabId[];
	const tabIndex = segments.reduce(
		(lastIndex, segment, index) => supportedTabs.includes(segment as MyAssetsTabId) ? index : lastIndex,
		-1
	);
	return tabIndex >= 0 ? segments.slice(0, tabIndex) : ['survey'];
}

/** Builds the destination tab URL without switching to a different host prefix. */
export function getMyAssetsTabUrl(url: string, tabId: MyAssetsTabId): string {
	return `/${[...getMyAssetsRoutePrefix(url, tabId), tabId].join('/')}`;
}

/** Opens a folder under the selected tab, encoding its ID as a single URL segment. */
export function getMyAssetsFolderUrl(url: string, tabId: MyAssetsTabId, folderId: string): string {
	return `${getMyAssetsTabUrl(url, tabId)}/folder/${encodeURIComponent(folderId)}`;
}