import { describe, expect, it } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { QuestionTypes } from '../../models/build-survey';
import { QuestionTypeListComponent } from './question-type-list.component';

describe('QuestionTypeListComponent', () => {
  it('checks selection in single mode', () => {
    const component = TestBed.runInInjectionContext(() => new QuestionTypeListComponent());
    component.selectedType.set(QuestionTypes.Text);

    expect(component.isSelected(QuestionTypes.Text)).toBe(true);
    expect(component.isSelected(QuestionTypes.SingleChoice)).toBe(false);
  });

  it('adds and removes types in multi mode', () => {
    const component = TestBed.runInInjectionContext(() => new QuestionTypeListComponent());
    component.mode = (() => 'multi') as typeof component.mode;

    component.selectQuestionType(QuestionTypes.Text);
    expect(component.selectedTypes()).toEqual([QuestionTypes.Text]);

    component.selectQuestionType(QuestionTypes.Text);
    expect(component.selectedTypes()).toEqual([]);
  });

  it('updates the selected type in single mode', () => {
    const component = TestBed.runInInjectionContext(() => new QuestionTypeListComponent());

    component.selectQuestionType(QuestionTypes.SingleChoice);

    expect(component.selectedType()).toBe(QuestionTypes.SingleChoice);
  });
});
