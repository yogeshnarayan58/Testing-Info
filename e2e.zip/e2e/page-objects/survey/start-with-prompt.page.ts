import { BasePage } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { ELEMENT_WAIT_TIMEOUT, SMALL_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';
import startWithPromptPageResources from '../../locators/survey/start-with-prompt.locator.json';
import { searchAndSelectDataset as searchAndSelectDatasetHelper } from '../common/dataset-selection.helper';

const START_WITH_PROMPT_PAGE_COMPONENT_NAME = 'startWithPromptPage';

export const OMNISHOPPER_OFFERING_DATA_TEST_ID = 'rv-dataset-type-selector1';

export class StartWithPromptPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      START_WITH_PROMPT_PAGE_COMPONENT_NAME,
      startWithPromptPageResources
    );
  }

  async clickStartWithPrompt(): Promise<void> {
    try {
      const startWithPrompt = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('startWithPrompt', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await startWithPrompt.waitFor(SMALL_TIMEOUT);
      await startWithPrompt.click();
    } catch (error) {
      throw new Error(`Failed to click Start with a prompt: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDatasetTypeSelectorVisible(index = 0): Promise<boolean> {
    try {
      const datasetTypeSelector = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('datasetTypeSelector', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeSelector.waitFor(SMALL_TIMEOUT);
      return datasetTypeSelector.isVisible();
    } catch (error) {
      throw new Error(`Failed to check dataset type selector visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectDatasetType(offeringDataTestId: string): Promise<void> {
    try {
      const datasetTypeOption = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('omnishopperOfferingTile', offeringDataTestId, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeOption.waitFor(SMALL_TIMEOUT);

      const tileClass = await datasetTypeOption.getAttribute('class').catch(() => null);
      const isAlreadySelected = (tileClass ?? '').includes('dataset-type-wrapper-selected');
      if (!isAlreadySelected) {
        await datasetTypeOption.click();
      }

      const nextDatasetButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('nextDatasetButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await nextDatasetButton.waitFor(SMALL_TIMEOUT);
      await nextDatasetButton.click();
    } catch (error) {
      throw new Error(`Failed to select dataset type "${offeringDataTestId}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async searchAndSelectDataset(searchTerm: string, datasetLabel: string): Promise<boolean> {
    try {
      return await searchAndSelectDatasetHelper(
        this.webActionHandler,
        this.resourceManager,
        START_WITH_PROMPT_PAGE_COMPONENT_NAME,
        searchTerm,
        datasetLabel,
        {
          datasetResourceKey: 'datasetByText',
          searchToggleResourceKey: 'datasetSearchToggle',
          searchInputResourceKey: 'datasetSearchInput'
        }
      );
    } catch (error) {
      throw new Error(`Failed to search and select dataset "${datasetLabel}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async applyDataset(): Promise<void> {
    try {
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const applyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('applyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();

      const dialogElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dialogElement', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );

      const isChooseViewDialogShown = await dialogElement.isVisible().catch(() => false);
      if (!isChooseViewDialogShown) {
        return;
      }

      await dialogElement.waitFor(SMALL_TIMEOUT);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();
    } catch (error) {
      throw new Error(`Failed to apply dataset: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillPromptAndGenerate(promptText: string): Promise<void> {
    try {
      const promptTextarea = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('promptTextarea', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await promptTextarea.waitFor(SMALL_TIMEOUT);
      await promptTextarea.enterText(promptText);

      const generateSurveyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('generateSurveyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await generateSurveyButton.waitForEnabled(ELEMENT_WAIT_TIMEOUT);
      await generateSurveyButton.click();
    } catch (error) {
      throw new Error(`Failed to fill prompt and generate survey: ${error instanceof Error ? error.message : error}`);
    }
  }
}