import {
  ApplicationConfig,
  APP_INITIALIZER,
  EnvironmentProviders,
  importProvidersFrom,
  Provider,
  provideZoneChangeDetection
} from '@angular/core';
import { DatePipe } from '@angular/common';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations';
import { HTTP_INTERCEPTORS, HttpClient, provideHttpClient, withInterceptorsFromDi, withXsrfConfiguration } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { MultiTranslateHttpLoader } from 'ngx-translate-multi-http-loader';
import { CoreHttpModule, EnvironmentConfig, AuthInterceptor, CacheInterceptor } from '@nielseniq/crf-discover-fe-core';
import { COMMON_ENVIRONMENT, EnvironmentService, environment as commonComponentsEnv } from '@nielsen/crf-rv-common';
import { AppInfoService } from '@nielsen/crf-common';
import { CrfLpCommonModule, UserService } from '@nielsen/crf-lp-common';
import { catchError, switchMap, take } from 'rxjs';
import { translatationBundleLoader } from '@nielseniq/crf-translate';

import { routes } from './app.routes';
import { StackRegionInterceptor, MyConfigsInterceptor } from '@nielsen/crf-survey-mod';
import { environment } from './environments/environment';
import { JsonPathService } from 'src/utils/jsonPath.service';
import { locales } from 'src/utils/translations';

export function HttpLoaderFactory(http: HttpClient) {
  return new MultiTranslateHttpLoader(http, [
    { prefix: 'assets/i18n/@nielsen/global-translate/', suffix: '.json' },
    { prefix: 'assets/i18n/@nielsen/reporting-templates-translate/', suffix: '.json' },
    { prefix: 'assets/i18n/@nielseniq/athena-core/', suffix: '.json' },
  ]);
}

export function environmentConfigFactory(): EnvironmentConfig {
  return new EnvironmentConfig(environment);
}

export function setCommonComponentsEnvironment() {
  return { ...commonComponentsEnv, ...environment };
}

export function environmentService(): EnvironmentService {
  return new EnvironmentService(environment);
}

interface LocalCookieConfig {
  cookies?: string;
}

export function setupLocal(environmentConfig: EnvironmentConfig): () => Promise<void> {
  return async () => {
    try {
      const configUrl = new URL('local-cookies.json', document.baseURI);
      const response = await fetch(configUrl, { cache: 'no-store' });
      if (!response.ok) {
        return;
      }

      const localCookieConfig = await response.json() as LocalCookieConfig;
      const cookies = localCookieConfig.cookies?.trim();
      if (!cookies) {
        return;
      }

      Object.assign(environmentConfig, { local: { cookies } });
      cookies.split(';').forEach((cookiePair) => {
        document.cookie = `${cookiePair.trim()}; path=/`;
      });
    } catch {
      // Local cookie configuration is optional and intentionally not committed.
    }
  };
}

export function initializeTranslations(
  translate: TranslateService,
  userService: UserService
): () => ReturnType<TranslateService['use']> {
  return () => {
    translate.addLangs(Object.values(locales));
    translate.setDefaultLang('en-US');

    // Fetch user data and apply their locale preference
    return userService.getUserData().pipe(
      take(1),
      switchMap((user) => {
        // Use user's locale if it's a supported locale, otherwise fall back to en-US
        const userLocale = user?.locale;
        const localeToUse = userLocale && Object.values(locales).includes(userLocale)
          ? userLocale
          : locales.EN_US;
        return translate.use(localeToUse);
      }),
      catchError((error) => {
        console.warn('Failed to fetch user locale, using default en-US', error);
        return translate.use('en-US');
      })
    );
  };
}

export function getAppConfigProviders(): Array<Provider | EnvironmentProviders> {
  return [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideAnimations(),
    provideHttpClient(
      withInterceptorsFromDi(),
      withXsrfConfiguration({ cookieName: undefined, headerName: 'X-XSRF-TOKEN' }),
    ),
    importProvidersFrom(
      CoreHttpModule.forRoot(),
      StoreModule.forRoot({}, {
        runtimeChecks: {
          strictStateImmutability: false,
          strictActionImmutability: false,
        },
      }),
      StoreDevtoolsModule.instrument({ maxAge: 25 }),
      EffectsModule.forRoot([]),
      TranslateModule.forRoot({
			loader: {
				provide: TranslateLoader,
				useFactory: translatationBundleLoader,
				deps: [HttpClient, JsonPathService]
			}
		}),
      CrfLpCommonModule,
    ),
    { provide: EnvironmentConfig, useFactory: environmentConfigFactory, deps: [] },
    { provide: EnvironmentService, useFactory: environmentService, deps: [] },
    { provide: Window, useValue: window },
    DatePipe,
    {
      provide: COMMON_ENVIRONMENT,
      useFactory: setCommonComponentsEnvironment,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: setupLocal,
      deps: [EnvironmentConfig],
      multi: true,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: initializeTranslations,
      deps: [TranslateService, UserService],
      multi: true,
    },
    AppInfoService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useExisting: MyConfigsInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: StackRegionInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CacheInterceptor,
      multi: true,
    },
  ];
}

export const appConfig: ApplicationConfig = {
  providers: getAppConfigProviders(),
};
