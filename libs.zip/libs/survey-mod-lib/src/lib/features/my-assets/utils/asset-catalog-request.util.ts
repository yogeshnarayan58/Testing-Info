import { AssetCatalogRequest } from '../models/survey-asset.model';
import { ASSET_AVAILABILITY, ASSET_TYPE, MY_ASSETS_TABS, MyAssetsTabId } from '../constants/my-assets-tabs.constant';
import { createAssetCatalogProperties, createRootAssetFilters } from './survey-status.util';

export interface AssetCatalogRequestOptions {
  tab: MyAssetsTabId;
  pageCount: number;
  pageNumber: number;
  primarySort: string;
  sortOrder: 'ASC' | 'DESC';
  timezone: string;
  /** When set, the request returns only the immediate children of this folder. */
  folderId?: string;
}

/** Formats a date as MM/DD/YYYY followed by the given time. */
function formatDate(date: Date, time: string): string {
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${month}/${day}/${date.getFullYear()} ${time}`;
}

/** Start of the recent window: 31 days ago at midnight. */
function getRecentStartDate(): string {
  const date = new Date();
  date.setDate(date.getDate() - 31);
  return formatDate(date, '00:00:00');
}

/** End of the recent window: today at 23:59. */
function getRecentEndDate(): string {
  return formatDate(new Date(), '23:59:00');
}

/** Single builder for every asset catalog payload (tab lists and folder children). */
export function buildAssetCatalogRequest(options: AssetCatalogRequestOptions): AssetCatalogRequest {
  const { tab, pageCount, pageNumber, primarySort, sortOrder, timezone, folderId } = options;
  const isFolder = !!folderId;
  const isRecent = !isFolder && tab === MY_ASSETS_TABS.RECENT;
  const isFavorite = !isFolder && tab === MY_ASSETS_TABS.MY_FAVORITES;
  const isTrash = tab === MY_ASSETS_TABS.TRASH;
  const isShared = tab === MY_ASSETS_TABS.SHARED_WITH_ME;
  const isFlat = isRecent || isFavorite;

  const properties = createAssetCatalogProperties(
    pageCount,
    pageNumber,
    isRecent ? 'OPENED' : 'MODIFIED',
    {
      timezone,
      ...(isFolder ? { parentAsset: true, showImmediateChildren: true } : {}),
      ...(isRecent ? {
        startOpenedDate: getRecentStartDate(),
        endOpenedDate: getRecentEndDate(),
        lastOpenedByMe: true,
        lastAccessedByMe: false,
        restrictFlowChildren: true,
      } : {}),
      ...(isFavorite ? { isFavorite: true } : {}),
    }
  );

  let availability: readonly string[] = ASSET_AVAILABILITY.OWNED;
  if (isFolder) {
    availability = isShared ? ASSET_AVAILABILITY.SHARED_AND_OWNED : ASSET_AVAILABILITY.OWNED;
  } else if (isShared) {
    availability = ASSET_AVAILABILITY.SHARED;
  } else if (isFlat) {
    availability = ASSET_AVAILABILITY.SHARED_AND_OWNED;
  }

  const filters: AssetCatalogRequest['filters'] = isFolder
    ? [{ typeKey: 'HIER', elements: [{ id: folderId }] }]
    : isFlat ? [] : createRootAssetFilters();

  if (isTrash && !isFolder) {
    filters[0].relationStatusToBeIgnored = ['TRASHED'];
  }

  filters.push({
    typeKey: 'AVL',
    elements: availability.map((right) => ({ availability: right })),
    ...(!isFolder && tab === MY_ASSETS_TABS.MY_ASSETS
      ? { exclusions: [{ availability: 'PUBLISHED' }] }
      : {}),
  });

  return {
    assets: [
      { assetType: ASSET_TYPE.DISCOVERSURVEY },
      ...(!isFlat ? [
        { assetType: ASSET_TYPE.DISCOVERFOLDER },
        { assetType: ASSET_TYPE.DISCOVERSHAREDFOLDER },
      ] : []),
      ...(isTrash ? [{ status: 'TRASHED' }] : []),
    ],
    properties,
    filters,
    sort: { primarySort, sortOrder },
    datasets: [],
  };
}
