import { TestBed } from '@angular/core/testing';
import { SecurityContext } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { DefaultUrlSerializer, Router } from '@angular/router';
import { ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { SurveyService } from '../../build-survey/services/survey.service';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { IGetRowsParams } from 'ag-grid-community';
import { of, Subject, throwError } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ASSET_TYPE, MY_ASSETS_GRID_PAGE_SIZE, MY_ASSETS_TABS } from '../constants/my-assets-tabs.constant';
import { SurveyGridRow, SurveyGridRowsLoadedEvent } from '../models/survey-asset.model';
import { SurveyAssetApiService } from './survey-asset-api.service';
import { SurveyGridHandlerService } from './survey-grid-handler.service';

vi.mock('@nielsen/crf-lp-common', () => ({
  GridDataSourceService: class {},
}));

vi.mock('@nielseniq/athena-core', () => ({
  ToastService: class {},
}));

vi.mock('../../build-survey/services/survey.service', () => ({
  SurveyService: class {},
}));

vi.mock('../../../shared/services/survey-common.service', () => ({
  SurveyCommonService: class {},
}));

describe('SurveyGridHandlerService', () => {
  let service: SurveyGridHandlerService;
  let fetchSurveyAssets: ReturnType<typeof vi.fn>;
  let fetchFolderChildren: ReturnType<typeof vi.fn>;
  let updateFavorite: ReturnType<typeof vi.fn>;
  let sanitize: ReturnType<typeof vi.fn>;
  let navigate: ReturnType<typeof vi.fn>;
  let navigateByUrl: ReturnType<typeof vi.fn>;
  let router: { url: string; navigate: ReturnType<typeof vi.fn>; navigateByUrl: ReturnType<typeof vi.fn> };
  let setDuplicateFromId: ReturnType<typeof vi.fn>;
  let resetSurvey: ReturnType<typeof vi.fn>;
  let resetSession: ReturnType<typeof vi.fn>;
  let insertToast: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    fetchSurveyAssets = vi.fn();
    fetchFolderChildren = vi.fn();
    updateFavorite = vi.fn();
    sanitize = vi.fn((_context: SecurityContext, value: string) => value);
    navigate = vi.fn();
    navigateByUrl = vi.fn();
    router = { url: '/survey/my-assets', navigate, navigateByUrl };
    setDuplicateFromId = vi.fn();
    resetSurvey = vi.fn();
    resetSession = vi.fn();
    insertToast = vi.fn();

    TestBed.configureTestingModule({
      providers: [
        SurveyGridHandlerService,
        { provide: SurveyAssetApiService, useValue: { fetchSurveyAssets, fetchFolderChildren, updateFavorite } },
        { provide: DomSanitizer, useValue: { sanitize } },
        { provide: Router, useValue: router },
        { provide: SurveyService, useValue: { setDuplicateFromId, reset: resetSurvey } },
        { provide: SurveyCommonService, useValue: { resetState: resetSession } },
        { provide: ToastService, useValue: { InsertToast: insertToast } },
      ],
    });
    service = TestBed.inject(SurveyGridHandlerService);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    TestBed.resetTestingModule();
  });

  function rowsParams(startRow = 0, endRow = 100): IGetRowsParams {
    return { startRow, endRow, sortModel: [], failCallback: vi.fn() } as unknown as IGetRowsParams;
  }

  function row(overrides: Partial<SurveyGridRow> = {}): SurveyGridRow {
    return {
      assetId: 'asset-1',
      assetType: ASSET_TYPE.DISCOVERSURVEY,
      title: 'Survey title',
      lastModifiedTimestamp: 1,
      sourceId: 'survey-1',
      launchURL: '/survey/launch',
      ...overrides,
    };
  }

  it('exposes the configured page size', () => {
    expect(service.pageSize).toBe(MY_ASSETS_GRID_PAGE_SIZE);
  });

  it('keeps loading active until all pending grid requests finish', () => {
    const first = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    const second = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    fetchSurveyAssets.mockReturnValueOnce(first).mockReturnValueOnce(second);
    expect(service.isLoading()).toBe(false);
    service.getRows(rowsParams(), 100, {}).subscribe();
    service.getRows(rowsParams(100, 200), 100, {}).subscribe();
    expect(service.isLoading()).toBe(true);
    first.next({ assets: [], totalCount: 0 });
    first.complete();
    expect(service.isLoading()).toBe(true);
    second.error(new Error('Load failed'));
    expect(service.isLoading()).toBe(false);
  });

  it('clears loading when a folder request is cancelled', () => {
    fetchFolderChildren.mockReturnValue(new Subject());
    service.setActiveFolder('first');
    service.getRows(rowsParams(), 100, {}).subscribe();
    expect(service.isLoading()).toBe(true);
    service.setActiveFolder('second');
    expect(service.isLoading()).toBe(false);
  });

  it('fetches and enriches rows using the current tab from grid context', () => {
    const assets = [
      { ...row(), status: 'DRAFT' },
      { ...row({ assetId: 'asset-2' }), status: 'custom_status' },
      { ...row({ assetId: 'folder-1', assetType: ASSET_TYPE.DISCOVERFOLDER }), status: 'DRAFT' },
      row({ assetId: 'asset-3' }),
    ];
    fetchSurveyAssets.mockReturnValue(of({ assets, totalCount: 4 }));
    let result: [SurveyGridRow[], number] | undefined;

    service.getRows(rowsParams(100, 200), 100, { currentTab: MY_ASSETS_TABS.RECENT }).subscribe((value) => {
      result = value;
    });

    expect(fetchSurveyAssets).toHaveBeenCalledWith(100, 200, [], 100, MY_ASSETS_TABS.RECENT);
    expect(result?.[1]).toBe(4);
    expect(result?.[0]).toEqual([
      expect.objectContaining({
        statusDisplay: expect.objectContaining({ label: 'Draft', variant: 'info', icon: 'edit' }),
        statusLabel: 'Draft',
      }),
      expect.objectContaining({
        statusDisplay: expect.objectContaining({ label: 'Custom Status', variant: 'default' }),
        statusLabel: 'Custom Status',
      }),
      expect.objectContaining({ statusDisplay: undefined, statusLabel: '--' }),
      expect.objectContaining({ statusDisplay: undefined, statusLabel: '--' }),
    ]);
  });

  it.each([
    [null, MY_ASSETS_TABS.MY_ASSETS],
    [{ currentTab: 'invalid-tab' }, MY_ASSETS_TABS.MY_ASSETS],
    [{ currentTab: MY_ASSETS_TABS.SHARED_WITH_ME }, MY_ASSETS_TABS.SHARED_WITH_ME],
  ])('uses the expected default or valid tab for context %s', (context, expectedTab) => {
    fetchSurveyAssets.mockReturnValue(of({ assets: [], totalCount: 0 }));

    service.getRows(rowsParams(), 100, context).subscribe();

    expect(fetchSurveyAssets).toHaveBeenCalledWith(0, 100, [], 100, expectedTab);
  });

  it('returns the successful empty response count without creating rows', () => {
    fetchSurveyAssets.mockReturnValue(of({ assets: [], totalCount: 12 }));
    let result: [SurveyGridRow[], number] | undefined;

    service.getRows(rowsParams(), 100, null).subscribe((value) => {
      result = value;
    });

    expect(result).toEqual([[], 12]);
  });

  it('loads and pages the selected folder immediate children', () => {
    const assets = [
      { ...row({ assetId: 'child-1', assetType: ASSET_TYPE.DISCOVERFOLDER }) },
      { ...row({ assetId: 'child-2' }), status: 'DRAFT' },
    ];
    fetchFolderChildren.mockReturnValue(of({ assets, totalCount: 2 }));
    service.setActiveFolder('folder-1');
  let result: [SurveyGridRow[], number] | undefined;

    service.getRows(rowsParams(1, 2), 100, { currentTab: MY_ASSETS_TABS.MY_ASSETS }).subscribe((value) => {
      result = value;
    });

    expect(fetchFolderChildren).toHaveBeenCalledWith('folder-1', 1, 100, [], MY_ASSETS_TABS.MY_ASSETS);
    expect(result?.[0]).toEqual([
      expect.objectContaining({ assetId: 'child-1', statusLabel: '--' }),
      expect.objectContaining({ assetId: 'child-2', statusLabel: 'Draft' }),
    ]);
    expect(result?.[1]).toBe(2);
    expect(fetchSurveyAssets).not.toHaveBeenCalled();
  });

  it.each(['empty', 'error'] as const)(
    'cancels a pending child load before its stale %s result can hide the parent rows',
    (outcome) => {
      const childResponse = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
      const parentResponse = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
      fetchFolderChildren.mockReturnValueOnce(childResponse).mockReturnValueOnce(parentResponse);
      const childResult = vi.fn();
      const parentResult = vi.fn();
      const loaded = vi.fn();
      service.rowsLoaded$.subscribe(loaded);
      service.setActiveFolder('child');
      const childParams = rowsParams();
      const childSubscription = service.getRows(childParams, 100, null).subscribe(childResult);

      service.setActiveFolder('parent');

      // Cancel the child load before the parent load starts.
      expect(childSubscription.closed).toBe(true);
      expect(childResponse.observed).toBe(false);
      expect(childParams.failCallback).toHaveBeenCalledOnce();
      if (outcome === 'empty') {
        childResponse.next({ assets: [], totalCount: 0 });
      } else {
        childResponse.error(new Error('Stale child request failed'));
      }
      expect(childResult).not.toHaveBeenCalled();
      expect(loaded).not.toHaveBeenCalled();
      expect(insertToast).not.toHaveBeenCalled();
      expect(service.loadFailed).toBe(false);

      const parentParams = rowsParams();
      service.getRows(parentParams, 100, null).subscribe(parentResult);
      parentResponse.next({ assets: [row({ assetId: 'child' })], totalCount: 1 });
      parentResponse.complete();

      expect(parentResult).toHaveBeenCalledWith([
        [expect.objectContaining({ assetId: 'child' })], 1,
      ]);
      expect(loaded).toHaveBeenCalledExactlyOnceWith({ success: true, loadType: 'current-view' });
      expect(parentParams.failCallback).not.toHaveBeenCalled();
    }
  );

  it('cancels older parent requests even when navigation returns to the same folder', () => {
    const response = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    fetchFolderChildren.mockReturnValue(response);
    service.setActiveFolder('parent');
    const result = vi.fn();
    const subscription = service.getRows(rowsParams(), 100, null).subscribe(result);

    service.setActiveFolder('child');
    service.setActiveFolder('parent');
    response.next({ assets: [], totalCount: 0 });

    expect(subscription.closed).toBe(true);
    expect(result).not.toHaveBeenCalled();
  });

  it('cancels root loads when entering a folder and folder loads when returning to the root', () => {
    const rootResponse = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    const folderResponse = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    fetchSurveyAssets.mockReturnValue(rootResponse);
    fetchFolderChildren.mockReturnValue(folderResponse);
    const rootSubscription = service.getRows(rowsParams(), 100, null).subscribe();

    service.setActiveFolder('folder');
    expect(rootSubscription.closed).toBe(true);
    const folderSubscription = service.getRows(rowsParams(), 100, null).subscribe();
    service.setActiveFolder(null);

    expect(folderSubscription.closed).toBe(true);
    expect(rootResponse.observed).toBe(false);
    expect(folderResponse.observed).toBe(false);
  });

  it('keeps pagination requests active when the folder has not changed', () => {
    const response = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    fetchFolderChildren.mockReturnValue(response);
    service.setActiveFolder('parent');
    const result = vi.fn();
    const subscription = service.getRows(rowsParams(100, 200), 100, null).subscribe(result);

    service.setActiveFolder('parent');
    response.next({ assets: [row()], totalCount: 101 });

    expect(subscription.closed).toBe(false);
    expect(result).toHaveBeenCalledOnce();
    subscription.unsubscribe();
  });

  it('releases a grid loading slot when the grid unsubscribes before receiving a response', () => {
    const response = new Subject<{ assets: SurveyGridRow[]; totalCount: number }>();
    fetchFolderChildren.mockReturnValue(response);
    service.setActiveFolder('parent');
    const params = rowsParams();
    const loaded = vi.fn();
    service.rowsLoaded$.subscribe(loaded);
    const subscription = service.getRows(params, 100, null).subscribe();

    subscription.unsubscribe();
    service.setActiveFolder('child');

    expect(params.failCallback).toHaveBeenCalledOnce();
    expect(response.observed).toBe(false);
    expect(loaded).not.toHaveBeenCalled();
    expect(insertToast).not.toHaveBeenCalled();
  });

  it('returns the grid fallback when the asset request fails', () => {
    fetchSurveyAssets.mockReturnValue(throwError(() => new Error('request failed')));
    let result: [SurveyGridRow[], number] | undefined;

    service.getRows(rowsParams(), 100, null).subscribe((value) => {
      result = value;
    });

    expect(result).toEqual([[], 0]);
  });

  it('returns the grid fallback when loading folder children fails', () => {
    fetchFolderChildren.mockReturnValue(throwError(() => new Error('request failed')));
    service.setActiveFolder('folder-1');
    let result: [SurveyGridRow[], number] | undefined;

    service.getRows(rowsParams(), 100, { currentTab: MY_ASSETS_TABS.SHARED_WITH_ME }).subscribe((value) => {
      result = value;
    });

    expect(result).toEqual([[], 0]);
    expect(service.loadFailed).toBe(true);
    expect(insertToast).toHaveBeenCalledWith('error', 'Something went wrong, please try again.', expect.any(Object));
    expect(fetchSurveyAssets).not.toHaveBeenCalled();
  });

  it('reports whether each grid and folder load succeeded and whether it paginated', () => {
    const loads: SurveyGridRowsLoadedEvent[] = [];
    service.rowsLoaded$.subscribe((event) => loads.push(event));
    fetchSurveyAssets.mockReturnValueOnce(of({ assets: [], totalCount: 0 }))
      .mockReturnValueOnce(throwError(() => new Error('request failed')));
    fetchFolderChildren.mockReturnValueOnce(of({ assets: [], totalCount: 0 }))
      .mockReturnValueOnce(throwError(() => new Error('request failed')));

    service.getRows(rowsParams(), 100, null).subscribe();
    service.getRows(rowsParams(100, 200), 100, null).subscribe();
    service.setActiveFolder('folder-1');
    service.getRows(rowsParams(100, 200), 100, null).subscribe();
    service.getRows(rowsParams(), 100, null).subscribe();

    expect(loads).toEqual([
      { success: true, loadType: 'current-view' },
      { success: false, loadType: 'pagination' },
      { success: true, loadType: 'pagination' },
      { success: false, loadType: 'current-view' },
    ]);
  });

  it('ignores unsupported actions and invalid rows', () => {
    service.onMenuAction({ optionType: 'unknown', row: row() });
    service.onMenuAction({ optionType: 'favorite', row: null });
    service.onMenuAction({ optionType: 'favorite', row: { assetId: 12 } });

    expect(updateFavorite).not.toHaveBeenCalled();
    expect(navigate).not.toHaveBeenCalled();
  });

  it('routes a valid survey URL without reloading the current window', () => {
    const assign = vi.fn();
    vi.stubGlobal('window', { location: { assign } });

    service.onMenuAction({ optionType: 'open', row: row() });

    expect(sanitize).toHaveBeenCalledWith(SecurityContext.URL, '/survey/launch');
    expect(navigateByUrl).toHaveBeenCalledWith('/survey/launch');
    expect(assign).not.toHaveBeenCalled();
  });

  it('routes an absolute internal URL relative to the application base path', () => {
    const assign = vi.fn();
    vi.stubGlobal('window', { location: { assign } });
    const baseURI = new URL('/app/', document.baseURI).toString();
    vi.spyOn(document, 'baseURI', 'get').mockReturnValue(baseURI);

    service.onMenuAction({
      optionType: 'open',
      row: row({ launchURL: new URL('survey/results?surveyId=survey-1#details', baseURI).toString() }),
    });

    expect(navigateByUrl).toHaveBeenCalledWith('/survey/results?surveyId=survey-1#details');
    expect(assign).not.toHaveBeenCalled();
  });

  it('clears the session and loaded survey before opening each survey sequentially', () => {
    const actions: string[] = [];
    resetSession.mockImplementation(() => actions.push('reset session'));
    resetSurvey.mockImplementation(() => actions.push('reset survey'));
    navigateByUrl.mockImplementation((url: string) => {
      actions.push(url);
      return Promise.resolve(true);
    });

    service.onMenuAction({
      optionType: 'open',
      row: row({ sourceId: 'survey-a', launchURL: '/survey/build-survey/survey-a' }),
    });
    router.url = '/survey/my-assets';
    service.onMenuAction({
      optionType: 'open',
      row: row({ sourceId: 'survey-b', launchURL: '/survey/build-survey/survey-b' }),
    });

    expect(actions).toEqual([
      'reset session',
      'reset survey',
      '/survey/build-survey/survey-a',
      'reset session',
      'reset survey',
      '/survey/build-survey/survey-b',
    ]);
  });

  it('ignores external survey URLs without reloading the page', () => {
    const assign = vi.fn();
    vi.stubGlobal('window', { location: { assign } });

    service.onMenuAction({
      optionType: 'open',
      row: row({ launchURL: 'https://example.com/survey/results/survey-1' }),
    });

    expect(navigateByUrl).not.toHaveBeenCalled();
    expect(assign).not.toHaveBeenCalled();
    expect(resetSession).not.toHaveBeenCalled();
    expect(resetSurvey).not.toHaveBeenCalled();
  });

  it.each([
    ['FAILED', '/survey/results/survey-1?mode=view&return=results#details', '/survey/build-survey/survey-1?mode=view&return=results#details'],
    ['Failed', '/survey/aiflow/results?surveyId=survey-1#summary', '/survey/aiflow/build-survey?surveyId=survey-1#summary'],
    ['failed', '/survey/results/survey-1?token=a%2Fb#details', '/survey/build-survey/survey-1?token=a%2Fb#details'],
    ['FAILED', '/survey/results?next=/results#results', '/survey/build-survey?next=/results#results'],
    ['FAILED', '/survey/build-survey?surveyId=survey-1', '/survey/build-survey?surveyId=survey-1'],
    ['FAILED', '/survey/results-summary?next=results', '/survey/results-summary?next=results'],
    ['PUBLISHED', '/survey/results?surveyId=survey-1', '/survey/results?surveyId=survey-1'],
    [undefined, '/survey/results?surveyId=survey-1', '/survey/results?surveyId=survey-1'],
  ])('opens status %s with only the results route updated when failed: %s', (status, launchURL, expectedUrl) => {
    const assign = vi.fn();
    vi.stubGlobal('window', { location: { assign } });
    const survey = row({ status, launchURL });

    service.onMenuAction({ optionType: 'open', row: survey });

    expect(navigateByUrl).toHaveBeenCalledWith(expectedUrl);
    expect(assign).not.toHaveBeenCalled();
    expect(survey.launchURL).toBe(launchURL);
  });

  it('opens failed surveys in the builder in a new tab and clears the opener', () => {
    const openedWindow = { opener: window };
    const open = vi.fn().mockReturnValue(openedWindow);
    vi.stubGlobal('window', { open });

    service.onMenuAction({
      optionType: 'open-new-tab',
      row: row({ status: 'FAILED', launchURL: '/survey/aiflow/results?surveyId=survey-1#details' }),
    });

    expect(open).toHaveBeenCalledWith(
      new URL('/survey/aiflow/build-survey?surveyId=survey-1#details', document.baseURI).toString(),
      '_blank',
    );
    expect(openedWindow.opener).toBeNull();
  });

  it('navigates into folder rows rather than opening them as surveys', () => {
    const folder = row({ assetId: 'folder-1', assetType: ASSET_TYPE.DISCOVERFOLDER });
    service.onMenuAction({ optionType: 'open', row: folder });

    expect(navigateByUrl).toHaveBeenCalledWith('/survey/my-assets/folder/folder-1', {
      state: {
        folderAsset: folder,
        folderBreadcrumbs: [
          { label: 'My assets', url: '/survey/my-assets' },
          { label: 'Survey title', url: '/survey/my-assets/folder/folder-1' },
        ],
      },
    });
    expect(resetSession).not.toHaveBeenCalled();
    expect(resetSurvey).not.toHaveBeenCalled();
  });

  it('does not navigate into folders from Favorites', () => {
    router.url = '/survey/my-favorites';

    service.onMenuAction({ optionType: 'open', row: row({ assetType: ASSET_TYPE.DISCOVERFOLDER }) });

    expect(navigate).not.toHaveBeenCalled();
    expect(navigateByUrl).not.toHaveBeenCalled();
  });

  it('keeps the active tab when opened through the Landing Page mount', () => {
    router.url = '/my-assets/survey/shared-with-me';
    const folder = row({ assetId: 'shared-folder', assetType: ASSET_TYPE.DISCOVERSHAREDFOLDER });

    service.onMenuAction({ optionType: 'open', row: folder });

    expect(navigateByUrl).toHaveBeenCalledWith('/my-assets/survey/shared-with-me/folder/shared-folder', expect.any(Object));
  });

  it.each([
    ['/survey/shared-with-me?view=grid', '/survey/shared-with-me/folder/shared-folder'],
    ['/my-assets/survey/shared-with-me#details', '/my-assets/survey/shared-with-me/folder/shared-folder'],
  ])('keeps the active tab when opening a folder from %s', (currentUrl, expectedFolderUrl) => {
    router.url = currentUrl;
    const folder = row({ assetId: 'shared-folder', assetType: ASSET_TYPE.DISCOVERSHAREDFOLDER });

    service.onMenuAction({ optionType: 'open', row: folder });

    expect(navigateByUrl).toHaveBeenCalledWith(expectedFolderUrl, expect.any(Object));
  });

  it('extends existing breadcrumb navigation state when opening a nested folder', () => {
    service.setActiveFolder('parent-id');
    const parentBreadcrumbs = [
      { label: 'My assets', url: '/survey/my-assets' },
      { label: 'Parent folder', url: '/survey/my-assets/folder/parent-id' },
    ];
    vi.stubGlobal('history', { state: { folderBreadcrumbs: parentBreadcrumbs } });
    const nestedFolder = row({ assetId: 'child-id', title: 'Child folder', assetType: ASSET_TYPE.DISCOVERFOLDER });

    service.onMenuAction({ optionType: 'open', row: nestedFolder });

    expect(navigateByUrl).toHaveBeenCalledWith('/survey/my-assets/folder/child-id', {
      state: {
        folderAsset: nestedFolder,
        folderBreadcrumbs: [
          ...parentBreadcrumbs,
          { label: 'Child folder', url: '/survey/my-assets/folder/child-id' },
        ],
      },
    });
    vi.unstubAllGlobals();
  });

  it.each([{}, { folderBreadcrumbs: [] }])('omits incomplete child navigation state after a direct folder link: %s', (state) => {
    vi.stubGlobal('history', { state });
    router.url = '/survey/my-assets/folder/parent-id';
    service.setActiveFolder('parent-id');
    const child = row({ assetId: 'child-id', assetType: ASSET_TYPE.DISCOVERFOLDER });

    service.onMenuAction({ optionType: 'open', row: child });

    expect(navigateByUrl).toHaveBeenCalledWith('/survey/my-assets/folder/child-id', { state: {} });
    expect(navigate).not.toHaveBeenCalled();
  });

  it.each(['folder/id 1', 'folder%id', 'folder?#'])('preserves the original folder ID %s in the serialized URL', (assetId) => {
    const folder = row({ assetId, assetType: ASSET_TYPE.DISCOVERFOLDER });

    service.onMenuAction({ optionType: 'open', row: folder });

    const expectedUrl = `/survey/my-assets/folder/${encodeURIComponent(assetId)}`;
    expect(navigateByUrl).toHaveBeenCalledWith(expectedUrl, expect.objectContaining({
      state: expect.objectContaining({ folderAsset: folder }),
    }));
    expect(navigate).not.toHaveBeenCalled();
    const parsedUrl = new DefaultUrlSerializer().parse(navigateByUrl.mock.calls[0][0]);
    expect(parsedUrl.root.children['primary'].segments.at(-1)?.path).toBe(assetId);
  });

  it.each([
    [row({ launchURL: undefined }), 'missing URL'],
    [row({ sourceId: undefined }), 'missing source id'],
    [row({ launchURL: 'javascript:alert(1)' }), 'unsupported protocol'],
  ])('does not open a survey with %s', (invalidRow) => {
    const assign = vi.fn();
    vi.stubGlobal('window', { location: { assign } });

    service.onMenuAction({ optionType: 'open', row: invalidRow });

    expect(navigateByUrl).not.toHaveBeenCalled();
    expect(assign).not.toHaveBeenCalled();
    expect(resetSession).not.toHaveBeenCalled();
    expect(resetSurvey).not.toHaveBeenCalled();
  });

  it('does not open a URL rejected by the sanitizer', () => {
    sanitize.mockReturnValue('unsafe:blocked');
    const assign = vi.fn();
    vi.stubGlobal('window', { location: { assign } });

    service.onMenuAction({ optionType: 'open', row: row() });

    expect(navigateByUrl).not.toHaveBeenCalled();
    expect(assign).not.toHaveBeenCalled();
    expect(resetSession).not.toHaveBeenCalled();
    expect(resetSurvey).not.toHaveBeenCalled();
  });

  it('opens a valid survey in a new tab and clears its opener', () => {
    const openedWindow = { opener: window };
    const open = vi.fn().mockReturnValue(openedWindow);
    vi.stubGlobal('window', { open });

    service.onMenuAction({ optionType: 'open-new-tab', row: row() });

    expect(open).toHaveBeenCalledWith(new URL('/survey/launch', document.baseURI).toString(), '_blank');
    expect(openedWindow.opener).toBeNull();
    expect(resetSession).not.toHaveBeenCalled();
    expect(resetSurvey).not.toHaveBeenCalled();
  });

  it('does not open a new tab when the launch URL is unsafe', () => {
    sanitize.mockReturnValue(null);
    const open = vi.fn();
    vi.stubGlobal('window', { open });

    service.onMenuAction({ optionType: 'open-new-tab', row: row() });

    expect(open).not.toHaveBeenCalled();
  });

  it('duplicates standard and AI flow surveys using the matching route', () => {
    service.onMenuAction({ optionType: 'duplicate', row: row({ sourceId: '  survey-1  ' }) });
    service.onMenuAction({ optionType: 'duplicate', row: row({ sourceId: 'survey-2', launchURL: '/aiflow/build' }) });
    service.onMenuAction({ optionType: 'duplicate', row: row({ sourceId: '   ' }) });

    expect(setDuplicateFromId).toHaveBeenNthCalledWith(1, 'survey-1');
    expect(setDuplicateFromId).toHaveBeenNthCalledWith(2, 'survey-2');
    expect(setDuplicateFromId).toHaveBeenCalledTimes(2);
    expect(navigate).toHaveBeenNthCalledWith(1, ['/survey/build-survey']);
    expect(navigate).toHaveBeenNthCalledWith(2, ['/survey/aiflow/build-survey']);
  });

  it('updates favorite state, emits a row update, and shows success feedback', () => {
    updateFavorite.mockReturnValue(of({}));
    const updates: unknown[] = [];
    service.rowUpdated$.subscribe((update) => updates.push(update));
    const survey = row({ isMyFavorite: false });

    service.onMenuAction({ optionType: 'favorite', row: survey });

    expect(updateFavorite).toHaveBeenCalledWith('asset-1', true);
    expect(survey.isMyFavorite).toBe(true);
    expect(updates).toEqual([{ action: 'favorite', row: survey }]);
    expect(insertToast).toHaveBeenCalledWith('success', 'Your asset Survey title has been added to favorites', {
      dismissAfter: ToastTime.DISMISSAFTER,
      size: 'large',
    });
  });

  it('shows error feedback and leaves the favorite state unchanged when the API fails', () => {
    updateFavorite.mockReturnValue(throwError(() => new Error('request failed')));
    const survey = row({ isMyFavorite: true });

    service.onMenuAction({ optionType: 'favorite', row: survey });

    expect(survey.isMyFavorite).toBe(true);
    expect(insertToast).toHaveBeenCalledWith('error', 'Failed to update favorite. Please try again.', {
      dismissAfter: ToastTime.DISMISSAFTER,
      size: 'large',
    });
  });

  it('handles the info action without logging', () => {
    const log = vi.spyOn(console, 'log').mockImplementation(() => undefined);

    service.onMenuAction({ optionType: 'info', row: row() });

    expect(log).not.toHaveBeenCalled();
  });

  it.each([
    ['edit', 'edit'],
    ['trash', 'delete'],
  ] as const)('updates the current URL for the %s action', (action, mode) => {
    const replaceState = vi.fn();
    vi.stubGlobal('window', {
      location: { href: 'https://example.test/assets?filter=mine' },
      history: { replaceState },
    });

    service.onMenuAction({ optionType: action, row: row() });

    const updatedUrl = new URL(replaceState.mock.calls[0][2]);
    expect(replaceState).toHaveBeenCalledWith({}, '', expect.any(String));
    expect(updatedUrl.searchParams.get('filter')).toBe('mine');
    expect(updatedUrl.searchParams.get('surveyId')).toBe('asset-1');
    expect(updatedUrl.searchParams.get('mode')).toBe(mode);
  });
});