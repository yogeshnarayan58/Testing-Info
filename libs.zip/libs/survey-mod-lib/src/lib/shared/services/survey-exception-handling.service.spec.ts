import { TestBed } from '@angular/core/testing';
import { HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { skip } from 'rxjs';
import { beforeEach, describe, expect, it } from 'vitest';
import { SurveyExceptionHandlingService } from './survey-exception-handling.service';

describe('SurveyExceptionHandlingService', () => {
  let service: SurveyExceptionHandlingService;
  let emitted: unknown[];

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SurveyExceptionHandlingService);
    emitted = [];
    // Skip the BehaviorSubject's seed value so only emissions from handleApiError are recorded.
    service.errorResponseSubject.pipe(skip(1)).subscribe(value => emitted.push(value));
  });

  it('suppresses the toast when displayToastOnError is false', () => {
    service.handleApiError(new HttpErrorResponse({ status: 500 }), { displayToastOnError: false });

    expect(emitted).toEqual([{ displayToastOnError: false }]);
  });

  it('falls back to the default error code when the error has no errorCode', () => {
    service.handleApiError(new HttpErrorResponse({ status: 500, error: {} }));

    expect(emitted).toEqual([{
      displayToastOnError: true,
      errorCodeConfig: { errorCode: 'ER0001', params: [], transactionId: undefined }
    }]);
  });

  it('emits the generic toast when the errorCode is empty', () => {
    service.handleApiError(new HttpErrorResponse({ status: 500, error: { errorCode: '' } }));

    expect(emitted).toEqual([{ displayToastOnError: true }]);
  });

  it('emits errorCodeConfig with the first transaction id when an errorCode exists', () => {
    const headers = new HttpHeaders({ 'x-nlsn-tnxn-id': 'txn-1, txn-2' });
    service.handleApiError(new HttpErrorResponse({ status: 400, headers, error: { errorCode: 'ER0001' } }));

    expect(emitted).toEqual([{
      displayToastOnError: true,
      errorCodeConfig: { errorCode: 'ER0001', params: [], transactionId: 'txn-1' }
    }]);
  });

  it('does not throw when the transaction id header is missing', () => {
    service.handleApiError(new HttpErrorResponse({ status: 400, error: { errorCode: 'ER0001' } }));

    expect(emitted).toEqual([{
      displayToastOnError: true,
      errorCodeConfig: { errorCode: 'ER0001', params: [], transactionId: undefined }
    }]);
  });
});
