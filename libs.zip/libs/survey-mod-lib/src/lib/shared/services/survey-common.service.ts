import { toParentFolder, withMyAssetsRoot } from '../utils/survey-folder.util';
import { computed, inject, Injectable, signal, Signal, WritableSignal } from '@angular/core';
import type { DimensionSelection, Prompt } from '@nielsen/crf-common';
import { ACAssetManageApiService, ACFetchApiService, Asset, AssetTypes } from '@nielsen/crf-lp-common';
import { ToastService } from '@nielseniq/athena-core';
import { finalize, Subject, take, takeUntil } from 'rxjs';
import { ReDataSetConfig } from '@nielsen/crf-rv-common';
import { EnvironmentConfig, ToastTime } from '@nielseniq/crf-discover-fe-core';
import { cloneDeep } from 'lodash-es';
import type { CreateFolderComponent, SaveACopyComponent } from '@nielsen/crf-ui-components';
import { FLOW_TYPES, FlowFlags, FlowType, SURVEY_FLOW_STEPS, SurveyFlowStep } from '../../core/config/config';
import { TranslateService } from '@ngx-translate/core';

export interface SurveyUserContext {
  userId: string;
  clientId: string;
  emailId: string;
  applicationId: string;
  locale: string;
}

export interface SelectPanelistUiState {
  reportData: boolean;
  householdCount: string;
  selectedResponses: number | null;
}

export interface SurveySessionState {
  userPrompt: string;
  selectPanelistUiState: SelectPanelistUiState;
  dataViewId: string | null;
  selectedDatasetConfig: ReDataSetConfig | null;
  selectedDatasetDisplay: string;
  refreshedDate: string | null;
  panelistDataSelectorState: any | null;
  questions: any[];
}

const DEFAULT_SELECT_PANELIST_UI_STATE: SelectPanelistUiState = {
  reportData: false,
  householdCount: '0',
  selectedResponses: null,
};

@Injectable({
  providedIn: 'root'
})
export class SurveyCommonService {
  private readonly folderApi = inject(ACFetchApiService);
  private readonly assetManageApi = inject(ACAssetManageApiService);
  private readonly toastService = inject(ToastService);
  private readonly translate = inject(TranslateService)
  environmentConfig = inject(EnvironmentConfig)
  isPanelOpen = signal(false);
  panelistCompleted = signal(false);
  readonly dataViewId = signal<string | null>(null);
  //flowType = signal<FlowType>(FLOW_TYPES.SCRATCH);
  private readonly activeFlowState = signal<FlowType | null>(FLOW_TYPES.SCRATCH);
  private readonly selectedDatasetConfigState = signal<any>(null);
  private readonly panelistDataSelectorState = signal<any>(null);
  private readonly selectedDatasetDisplayState = signal<string>('');
  private readonly refreshedDateState = signal<string | null>(null);
  private readonly datasetPickerOpenTrigger = signal(0);
  private readonly datasetFooterVisibleState = signal(false);
  readonly datasetFooterVisible = this.datasetFooterVisibleState.asReadonly();
  private readonly activeSurveyStepState = signal<SurveyFlowStep>(SURVEY_FLOW_STEPS.SELECT_PANELIST);
  readonly activeSurveyStep = this.activeSurveyStepState.asReadonly();
  private readonly panelistDimensionalValue = signal<Record<string, string[]>>({});
  private readonly userPromptValue = signal<string>('');
  private readonly userContextState = signal<SurveyUserContext | null>(null);
  private readonly selectPanelistUiState = signal<SelectPanelistUiState>({
    ...DEFAULT_SELECT_PANELIST_UI_STATE,
  });

  private readonly surveyLoadingState = signal(false);
  private readonly dataSelectorLoadingState = signal(false);
  readonly surveyLoading = this.surveyLoadingState.asReadonly();
  readonly dataSelectorLoading = this.dataSelectorLoadingState.asReadonly();

  // Multi-level I/O state signals for component coordination (Requirement #5)
  private readonly datasetSelectedState = signal<string | null>(null);
  private readonly panelToggledState = signal<boolean | null>(null);
  private readonly criteriaChangedTrigger = signal(0);

  readonly flowType = computed<FlowFlags>(() => {
    const activeFlow = this.activeFlowState();

    return {
      [FLOW_TYPES.IMPORT]: activeFlow === FLOW_TYPES.IMPORT,
      [FLOW_TYPES.SCRATCH]: activeFlow === FLOW_TYPES.SCRATCH,
      [FLOW_TYPES.AIFLOW]: activeFlow === FLOW_TYPES.AIFLOW,
      [FLOW_TYPES.TEMPLATE]: activeFlow === FLOW_TYPES.TEMPLATE,
    };
  });


  setPanelOpen(value: boolean) {
    this.isPanelOpen.set(value);
  }

  setFlowType(flowType: FlowType | null | undefined) {
    this.activeFlowState.set(flowType ?? FLOW_TYPES.SCRATCH);
  }

  setSelectedDatasetConfig(config: ReDataSetConfig | null) {
    if (!config) {
      this.selectedDatasetConfigState.set(null);
      return;
    }

    const clonedConfig = cloneDeep(config);
    this.selectedDatasetConfigState.set(clonedConfig);
  }

  getSelectedDatasetConfig(): ReDataSetConfig | null {
    return this.selectedDatasetConfigState();
  }

  setPanelistDataSelectorState(state: any | null) {
    if (!state) {
      this.panelistDataSelectorState.set(null);
      return;
    }

    const clonedState = cloneDeep(state);
    this.panelistDataSelectorState.set(clonedState);
  }

  getPanelistDataSelectorState(): any | null {
    return this.panelistDataSelectorState();
  }

  setSelectPanelistUiState(partialState: Partial<SelectPanelistUiState>) {
    this.selectPanelistUiState.update((state) => ({ ...state, ...partialState }));
  }

  getSelectPanelistUiState(): SelectPanelistUiState {
    return this.selectPanelistUiState();
  }

  hasCompletedPanelistSearch(): boolean {
    return this.selectPanelistUiState().reportData;
  }

  setSelectedDatasetDisplay(value: string) {
    this.selectedDatasetDisplayState.set(value);
  }

  getSelectedDatasetDisplay(): string {
    return this.selectedDatasetDisplayState();
  }

  setRefreshedDate(value: string | null) {
    this.refreshedDateState.set(value);
  }

  getRefreshedDate(): string | null {
    return this.refreshedDateState();
  }

  requestDatasetPickerOpen(): void {
    this.datasetPickerOpenTrigger.update(count => count + 1);
  }

  getDatasetPickerOpenTrigger(): number {
    return this.datasetPickerOpenTrigger();
  }

  setDatasetFooterVisible(visible: boolean): void {
    this.datasetFooterVisibleState.set(visible);
  }

  setActiveSurveyStep(step: SurveyFlowStep): void {
    this.activeSurveyStepState.set(step);
  }


  setPanelistDimensionalValue(promptSelections: Record<string, string[]>) {
    const normalized = promptSelections ?? {};
    this.panelistDimensionalValue.set(normalized);
  }

  getPanelistDimensionalValue(): Record<string, string[]> {
    return this.panelistDimensionalValue();
  }

  setUserPrompt(userPrompt: string) {
    const normalizedPrompt = userPrompt ?? '';
    this.userPromptValue.set(normalizedPrompt);
  }

  getUserPrompt(): string {
    return this.userPromptValue();
  }

  setDataViewId(value: string | null): void {
    const normalized = value?.trim() || null;
    this.dataViewId.set(normalized);
  }

  getDataViewId(): string | null {
    return this.dataViewId();
  }

  setDataselectorLoading(isLoading: boolean): void {
    this.dataSelectorLoadingState.set(isLoading);
  }

  setSurveyLoading(isLoading: boolean): void {
    this.surveyLoadingState.set(isLoading);
  }

  hydrateSurveySessionState(partialState: Partial<SurveySessionState>): void {
    if (!partialState) {
      return;
    }

    this.surveyLoadingState.set(false);

    if (partialState.userPrompt !== undefined) {
      this.userPromptValue.set(partialState.userPrompt ?? '');
    }

    if (partialState.selectPanelistUiState !== undefined) {
      this.selectPanelistUiState.set({
        ...DEFAULT_SELECT_PANELIST_UI_STATE,
        ...partialState.selectPanelistUiState
      });
    }

    if (partialState.dataViewId !== undefined) {
      this.dataViewId.set(partialState.dataViewId?.trim() || null);
    }

    if (partialState.selectedDatasetConfig !== undefined) {
      this.selectedDatasetConfigState.set(cloneDeep(partialState.selectedDatasetConfig ?? null));
    }

    if (partialState.selectedDatasetDisplay !== undefined) {
      this.selectedDatasetDisplayState.set(partialState.selectedDatasetDisplay ?? '');
    }

    if (partialState.refreshedDate !== undefined) {
      this.refreshedDateState.set(partialState.refreshedDate ?? null);
    }

    if (partialState.panelistDataSelectorState !== undefined) {
      this.panelistDataSelectorState.set(cloneDeep(partialState.panelistDataSelectorState ?? null));
    }
  }

  setUserContext(context: Partial<SurveyUserContext>): void {
    const current = this.userContextState() ?? this.resolveUserContext();
    this.userContextState.set({ ...current, ...context });
  }

  getUserContext(): SurveyUserContext {
    const existing = this.userContextState();
    if (existing) {
      return existing;
    }
    const resolved = this.resolveUserContext();
    this.userContextState.set(resolved);
    return resolved;
  }

  private resolveUserContext(): SurveyUserContext {
    return {
      userId: this.environmentConfig.userId,
      clientId: '',
      emailId: '',
      applicationId: this.environmentConfig.appId,
      locale: 'en-US',
    };
  }

  // Multi-level I/O coordination methods (Requirement #5)
  notifyDatasetSelected(datasetName: string): void {
    this.datasetSelectedState.set(datasetName);
  }

  getLastDatasetSelected(): string | null {
    return this.datasetSelectedState();
  }

  notifyPanelToggled(isOpen: boolean): void {
    this.panelToggledState.set(isOpen);
  }

  getLastPanelToggledState(): boolean | null {
    return this.panelToggledState();
  }

  notifyCriteriaChanged(): void {
    this.criteriaChangedTrigger.update(count => count + 1);
  }

  getCriteriaChangedTrigger(): number {
    return this.criteriaChangedTrigger();
  }

  resetState(): void {
    this.isPanelOpen.set(false);
    this.panelistCompleted.set(false);
    this.activeFlowState.set(FLOW_TYPES.SCRATCH);
    this.selectedDatasetConfigState.set(null);
    this.panelistDataSelectorState.set(null);
    this.dataViewId.set(null);
    this.selectedDatasetDisplayState.set('');
    this.refreshedDateState.set(null);
    this.datasetFooterVisibleState.set(false);
    this.panelistDimensionalValue.set({});
    this.userPromptValue.set('');
    this.userContextState.set(null);
    this.selectPanelistUiState.set({ ...DEFAULT_SELECT_PANELIST_UI_STATE });
    this.datasetSelectedState.set(null);
    this.panelToggledState.set(null);
    this.criteriaChangedTrigger.set(0);
    this.activeSurveyStepState.set(SURVEY_FLOW_STEPS.SELECT_PANELIST);
  }

  /**
   * Merges incoming dimension selections with existing selections.
   * Filters out existing selections that have no incoming children, and updates matching selections.
   * Used to consolidate dimension selection logic from select-panelist module.
   * 
   * @param incomingSelections - New selections to merge (can be empty or null)
   * @param existingSelections - Current selections to merge with (optional)
   * @returns Merged array of DimensionSelection objects with updated selections
   */
    mergeSelections(
    incomingSelections: DimensionSelection[],
    existingSelections: DimensionSelection[] | undefined,
    currentPromptId?: string
  ): DimensionSelection[] {
    const incomingByID = new Map((incomingSelections || []).map(s => [s?.id, s]));
    const result = (existingSelections || []).filter(sel => {
      const incoming = incomingByID.get(sel?.id);
      if (!incoming) {
        return true;
      }
      if (currentPromptId) {
        if (sel?.id !== currentPromptId) {
          return (sel?.children?.length ?? 0) > 0 || (incoming.children?.length ?? 0) > 0;
        }
      }
      return (incoming.children?.length ?? 0) > 0;
    });
    incomingByID.forEach((sel, id) => {
      if ((sel?.children?.length ?? 0) > 0) {
        const idx = result.findIndex(s => s?.id === id);
        if (idx >= 0) {
          result[idx] = sel;
        } else {
          result.push(sel);
        }
      }
    });
    return result;
  }

  /**
   * Extracts prompt selection labels from an array of prompts.
   * Builds a map of prompt identifiers to their selection labels.
   * Used to prepare dimension values for select-panelist module operations.
   * 
   * @param prompts - Array of Prompt objects containing promptData and selection information
   * @returns Record mapping prompt dimId/id to array of promptSelectionLabels
   */
  extractPromptSelectionLabels(prompts: Prompt[]): Record<string, string[]> {
    const promptSelectionMap: Record<string, string[]> = {};
    (prompts || []).forEach((prompt: any) => {
      const key = prompt?.dimId ?? prompt?.id;
      if (!key) return;
      const labels = (prompt?.promptData || [])
        .map((data: any) => data?.promptSelectionLabel)
        .filter((label: string) => !!label);
      if (labels.length) {
        promptSelectionMap[key] = labels;
      }
    });
    return promptSelectionMap;
  }

  // Loads folders and opens the location dialog.
  loadAndOpenFolderDialog(locationDialog: SaveACopyComponent<Asset> | undefined, title: string, folders: WritableSignal<Asset[]>, isLoadingFolders: WritableSignal<boolean>, isSavingDraft: Signal<boolean>, resetTitle: boolean = true): void {
    if (isSavingDraft() || isLoadingFolders()) return;
    isLoadingFolders.set(true);
    this.folderApi.getMyFolders([AssetTypes.FOLDER]).pipe(
      take(1),
      finalize(() => isLoadingFolders.set(false)),
    ).subscribe({
      next: response => {
        folders.set(withMyAssetsRoot(response.data?.assets ?? []));
        if (resetTitle && locationDialog) {
          locationDialog.defaultTitle = title;
        }
        locationDialog?.emptyAssetSelection();
        locationDialog?.open();
      },
      error: () => {
        this.toastService.InsertToast('error', this.translate.instant('SURVEYMOD_FAILED_TO_LOAD_FOLDERS'), {
          dismissAfter: ToastTime.DISMISSAFTER, size: 'large', containerClass: 'survey-action-toast',
        });
      },
    });
  }

  // Opens the create-folder dialog.
  openCreateFolderDialog(locationDialog: SaveACopyComponent<Asset> | undefined, createFolderDialog: CreateFolderComponent | undefined): void {
    locationDialog?.close();
    createFolderDialog?.resetForm();
    createFolderDialog?.updateLoader();
    createFolderDialog?.open();
  }

  // Returns to the location dialog and cancels pending folder creation.
  reopenFolderDialog(locationDialog: SaveACopyComponent<Asset> | undefined, createFolderDialog: CreateFolderComponent | undefined, title: string, folders: WritableSignal<Asset[]>, isLoadingFolders: WritableSignal<boolean>, isSavingDraft: Signal<boolean>, folderDialogClosed: Subject<void>): void {
    folderDialogClosed.next();
    createFolderDialog?.updateLoader();
    this.loadAndOpenFolderDialog(locationDialog, title, folders, isLoadingFolders, isSavingDraft, false);
  }

  // Creates a folder in the selected parent.
  createFolderInSelectedLocation(locationDialog: SaveACopyComponent<Asset> | undefined, createFolderDialog: CreateFolderComponent | undefined, folderDialogClosed: Subject<void>, result: { title: string }): void {
    this.assetManageApi.createAssetFolder(AssetTypes.FOLDER, result.title, toParentFolder(locationDialog?.folder)).pipe(
      take(1),
      takeUntil(folderDialogClosed),
      finalize(() => createFolderDialog?.updateLoader()),
    ).subscribe({
      next: () => createFolderDialog?.close(),
      error: () => {
        this.toastService.InsertToast('error', this.translate.instant('SURVEYMOD_FOLDER_CREATION_FAILED'), {
          dismissAfter: ToastTime.DISMISSAFTER, size: 'large', containerClass: 'survey-action-toast',
        });
      },
    });
  }

}