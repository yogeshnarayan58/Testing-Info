# E2E flakiness investigation (LOCAL — do not commit / do not `git add`)

## Evidence used and its limits

- `e2e/test-results/` only holds the **latest run (2 Nov, 11:28)**. Its only `error-context.md` + `test-failed-1.png` is for **Panelist Filters**. The other three folders there contain videos only (not read).
- "Last 3 runs" for the other tests come from `e2e/allure-results/*-result.json` (message + trace), the `*-attachment.png` screenshots and `*-attachment.md` error-contexts. Run time is derived from the epoch `stop` values (approx., IST):
  - 30 Oct ~17:50, 30 Oct ~18:05 (TC_SP_03 x2)
  - 31 Oct ~15:55 and ~16:48 (TC_BS_07, TC_SP_03, Response Count, Panelist Filters)
  - 2 Nov 11:28 (Panelist Filters, `test-results/`)
- Not readable here (no terminal / binary): `trace.zip`, `.webm` videos. Anything marked *(inferred)* is not confirmed by a screenshot or trace.
- No code, locator JSON or template was changed.

| Test | Failures in last 3 runs | Same cause each time? |
|---|---|---|
| TC_BS_07 (Prompt flow) | 31 Oct (x2), older ones back to 26 Oct | Yes since 31 Oct; earlier runs failed with a different message (see 1) |
| TC_SP_03 | 30 Oct (x2), 31 Oct | Yes, identical |
| Response Count (Prompt flow) | 31 Oct | Single occurrence in history |
| Panelist Filters (Prompt flow) | 26-29 Oct (older name), 31 Oct, 2 Nov | Yes, identical |

---

## 1. TC_BS_07: Required star appears when the Required toggle is on (Start with a prompt)

**What the page showed**
- No screenshot was attached for the 31 Oct runs that I could tie to a run. From the Playwright log: after clicking *Save changes* on question 0 the editor stayed open, because `.save-changes-action:visible` resolved "visible" 33 times over 15 s.
- The fallback then found no *Add option* button (so question 0 is not a Choice type) and the Discard fallback also failed.
- An older failed run (error-context `0d37611d…md`) shows question 0 ("How satisfied are you with the appliance you purchased from Dollar Store?") still in edit mode with the *Required* switch, *Discard changes* and *Save changes* buttons present, and the Optiq side panel open.

**Failing locator / wait**
- `survey-builder.page.ts` `saveQuestionChanges(0)` (line ~1287): `.question-row >> nth=0 >> .save-changes-action:visible` `waitFor('hidden')`, 15 s timeout.
- Called from `setRequired(0, false)` (the 2nd step of the test; the first `setRequired(0, true)` passed). Final error: `Required state for question 0 did not reach false within 10000ms`.
- Why: the page object assumes Save closes the editor. For AI-generated question 0 it does not always, and the fallbacks (outside click on `.survey-title`, Discard) also fail. The Required toggle is also located through `[data-test-id='-input-checkbox']`, an empty-prefix ID shared by every question (see the D item in the locator investigation).

**Root cause category**: test-state dependency (AI-generated question 0 has a non-deterministic type / initial Required state) + fragile locator (class + `nth` + empty-prefix toggle ID). Whether the Save click itself is ignored by the app is *(inferred, needs trace)*.

**Proposed fix**
- E2E: switch to the new per-question IDs that were added to the templates: `required-toggle-${n}`, `question-row-${n}`, `edit-question-${n}`, `save-question-changes`, `question-required-marker-${n}`. Scope Save to the open row, wait on the star state (not on Save becoming hidden), and add a trace/screenshot capture of the row on failure.
- Make the test deterministic: pick/create a known question type (e.g. Single Choice) before toggling instead of relying on AI-generated question 0.
- App change: **already done** (new `data-test-id`s in the editor templates, not yet used by the e2e). No further app change needed unless the trace shows Save really is not closing the editor (then it is an app bug).

**Risk if left unfixed**: the Prompt-flow build-survey chain is `serial`, so TC_BS_07 failing blocks or poisons every later build-survey test (edit text, discard, delete/duplicate, drag, review mode, validate, publish) in that flow. Probability of failure is high (6 failures since 26 Oct).

---

## 2. TC_SP_03: Cancelling the Product Offering modal applies no dataset

**What the page showed**: a completely blank light-grey page (screenshots from 30 Oct and 31 Oct are identical): no header, no survey cards. The app shell never rendered.

**Failing locator / wait**
- `start-from-scratch.page.ts:26-27` `clickStartFromScratch()`: `waitFor(SMALL_TIMEOUT)` (5 s) then `click()` (15 s) on `[data-testid='quick-survey-quick-2']`, called from `select-panelist.spec.ts:37`.
- `navigateToSurvey()` took ~2.6-5 s and returned before the survey home was rendered; the card never appeared within 20 s total. The locator itself is a valid stable ID (category A), so the locator is not the problem.

**Root cause category**: DEV environment (blank page / app or auth bootstrap not completing) + missing wait (navigation only waits for load, not for the survey-home to render, and there is no recovery such as a reload).

**Proposed fix**: e2e only.
- After `navigateToSurvey()` wait for the shell/home to be ready (card visible, up to the NAVIGATION_TIMEOUT used by `isStartFromScratchVisible`), and if the page is blank do one `page.reload()` and retry.
- Use `isStartFromScratchVisible()` (already uses NAVIGATION_TIMEOUT) before clicking, as the "serial" Setup test in the same spec already does.
- Check the 3 identical blank screenshots against DEV availability / auth-token expiry (`storage/`) at those times. Test is not serial and has no setup, so it opens a fresh browser and always depends on the first load.

**Risk if left unfixed**: false red on every cold-start run (3/3 recent runs). Masks real regressions in the modal-cancel behaviour, which has no other coverage.

---

## 3. Response Count: Should select a response count (Start with a prompt)

**What the page showed** (31 Oct screenshot + error-context `9bb34f7a…md`): Select Panelists page, "Let's get you started with Optiq!". The sentence reads *Buyers of APPLIANCES within Dollar Store in Total US by **Total Panel** during **Sep 25 - 5 w/e 09/27/25*** with a blue, enabled **Search for Panelists** button. There is **no eligibility message and no "Expected responses" block**, so no `250 Responses` button exists. "CHANGE DATASET" is present; the dimension values are the defaults, not the test's selections.

**Failing locator / wait**
- `select-panelist.page.ts:317-318` `click250Responses()`: `waitFor()` 15 s then `click()` on `text=250 Responses` (locator `250ResponsesButton`), called from `start-with-prompt.spec.ts:67`.
- It waits on visible *text*. That text only exists after "Search for Panelists" has run and returned an eligible household count ≥ 250 (`filteredResponseCounts` in `select-panelist.component.html` filters the options by eligible count).

**Root cause category**: test-state dependency. The test relies on the previous serial test ("Panelist Filters") having applied the filters and run the search; the screenshot shows default filters and no search result. Secondary: DEV environment (search result/eligible count may be slow or below 250) and a fragile text locator.

**Proposed fix**
- E2E only: switch to `[data-test-id='select-response-count-250']` (already emitted by the app, listed under "Switch now"), and before it wait for the search result (e.g. eligibility/response block) after `clickSearchForPanelists()`. Fail early with a clear message if 250 is not offered (eligible count < 250) and choose the largest available count instead of hard-coding 250.
- Optional app change: add `data-test-id` to the eligibility message and `.responses-frame` in `select-panelist.component.html` so the test can wait on the search result deterministically.
- Strengthen "Panelist Filters" (see 4): it currently only asserts the Search button is visible, so it can pass without the search having run.

**Risk if left unfixed**: Generate Survey, TC_AI_04 and every later Prompt-flow test depends on a selected response count, so this single failure cascades. Cause is hidden because the earlier test may report green.

---

## 4. Panelist Filters: Should set dimension selections and search for panelists (Start with a prompt)

**What the page showed** (`test-results/.../test-failed-1.png`, 2 Nov, and `playwright-report` copy): Select Panelists with the right-hand **Demographic** data-summary panel open, badge **199/1**, red banner **"Please remove 198"**, and a long list of numbered selection groups ("Babies Age 0 to 3", "Cat Owner", "Census Regions Demo", … "35 Groups", 2 pages). The summary sentence has "by ALL Babies Age 0 to 3, ALL Cat Owner, ALL Census …" in red, and **Search for Panelists** is greyed out. "Last refreshed: Oct 28, 2026".

**Failing locator / wait**
- `select-panelist.page.ts:110-111` `replaceFilledTileDimensionSelection()`: `removeIcon.waitFor()` then `removeIcon.click()` on `[data-test-id='ds-removeIcon']` (locator `removeIcon`).
- Playwright strict-mode violation: the selector resolved to **20 elements** (every selection group in the open panel carries the same `ds-removeIcon` and `id="DS.DROPDOWN.SELECTION_GROUP.REMOVE_EXPOSED"`). `waitFor()` succeeds on the first of 20, `click()` then throws.

**Root cause category**: fragile locator (non-unique ID) + external package (`@nielsen/crf-data-summary` renders the non-unique ID) + test-state dependency (DEV default demographic selection was pre-populated with 199 groups, which creates the 20 icons and the "Please remove 198" error state). Same failure on 31 Oct and in the earlier test name from 26-29 Oct.

**Proposed fix**
- E2E only: scope the remove action to one selection group (the existing `lastRemoveIcon` / `getSelectPanelistElement('lastRemoveIcon')` used in `removeDimensionSelectionItem()` or a `.first()`), and better, clear the whole dimension via the panel's delete/clear action instead of removing items one at a time. Reset to a known state first (new session / "clear all") so the default 199-group selection cannot appear.
- Needs the library owner: ask `@nielsen/crf-data-summary` for per-group IDs (e.g. `ds-removeIcon_${groupIndex}`); not doable in this repo.
- Add an assertion that the Search button is **enabled** and the search produced a result; today the test only checks the button is visible, so it can pass while filters were wrong (this feeds failure 3).

**Risk if left unfixed**: Prompt flow (and Start-from-scratch flow, which shares the page object) cannot get past filter setup whenever the demographic default is large, so the whole data-selection, response-count and generate-survey chain is unreachable. Fails every run (3/3).

---

## Cross-cutting notes

- Three of the four failures are in the **select-panelist** step of a `serial` flow; one failure turns every following test red/skipped, which inflates the apparent flakiness.
- The `report-btn-run` data-cy vs `id` mismatch was deliberately left out as requested; it affects `searchForPanelistsButton` (3 and 4 above wait on it).
- New `data-test-id`s from `TESTID_ADDED.md` unblock the fixes for 1 and 3 (`required-toggle-${n}`, `save-question-changes`, `select-response-count-250` already existed).
