import test from "@playwright/test";
import {
    findDataSetByName,
    getTestDataByLocale
} from "../../../common/utils/helper-service";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { config } from "../../../playwright/config";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { getDataElement } from "../../test-cases/common-test-cases-helper-service";
import { assert } from "@gfk/gta";
import { MAX_TEST_TIMEOUT, RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { ExportComponent } from "../../../common/components/export/export";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";

if (reportTestData) {
    test.describe("Consumer product ranking", () => {
        let dataSelector: DataSelector;
        let commonTestCase: CommonTestCase;
        let formatPanel: FormatPanel;

        test(
            "QuickLook: Should display correct preview information when template is selected",
            {
                tag: "@QuickLook",
            },
            async () => {
                let basePage = await BasePageFactory.createBasePage();
                let landingPage = new LandingPage(basePage);
                await landingPage.navigateToUrl(config.BASE_URL);
                await landingPage.clickAnalyseMyData();
                await landingPage.clickChooseATemplate();
                let chooseAtemplatePage = new ChooseAtemplatePage(
                    landingPage.getBasePage()
                );
                await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
                await chooseAtemplatePage.hoverThumbnailBySrc(
                    devTestData.common.thumbnailSrc
                );
                await chooseAtemplatePage.clickQuickLookInfoButton();
                let quickLookPage = new QuickLookPage(
                    chooseAtemplatePage.getBasePage()
                );
                const previewDescriptionValue = await quickLookPage.getPreviewDescription();
                assert(previewDescriptionValue).toBe(localeData.description);
                const themesValue = await quickLookPage.getPreviewThemes();
                assertionData.common.themes.forEach((expectedTheme: string) => {
                    assert(themesValue).toContain(expectedTheme);
                });
                const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
                assertionData.common.dataSets.forEach((expectedDataset: string) => {
                    assert(previewDatasetsValue).toContain(expectedDataset);
                });
            }
        );

        test(
            "Insights Panel: Should validate business questions and report metadata",
            {
                tag: "@Insights",
            },
            async () => {
                let basePage = await BasePageFactory.createBasePage();
                const insightsPanel = new InsightsPanel(basePage);
                await insightsPanel.navigateToUrl(reportUrl);
                await insightsPanel.clickInsightsIcon();
                const isTitleVisible =
                    await insightsPanel.isReportInsightsTitleVisible();
                assert(isTitleVisible).toBeTruthy();
                const isCloseIconVisible =
                    await insightsPanel.isReportInsightsPanelCloseIconVisible();
                assert(isCloseIconVisible).toBeTruthy();
                const insightsReportTitle =
                    await insightsPanel.getInsightsReportTitle();
                assert(insightsReportTitle?.trim()).toBe(localeData.title);
                const description = await insightsPanel.getInsightsPanelDescription();
                assert(description?.trim()).toBe(localeData.description);
                const isBusinessTitleVisible =
                    await insightsPanel.isBusinessQuestionsTitleVisible();
                assert(isBusinessTitleVisible).toBeTruthy();
                await insightsPanel.validateBusinessQuestions(
                    localeData.businessQuestions
                );
                await insightsPanel.closeInsightsPanel();
            }
        );

        test(
            "Madlib Validation: Should validate madlib text content matches expected pattern",
            {
                tag: "@MadlibValidation",
            },
            async () => {
                let basePage = await BasePageFactory.createBasePage();
                commonTestCase = new CommonTestCase(basePage);
                await commonTestCase.navigateToReportUrl(reportUrl);
                let commonBasePage = commonTestCase.getBasePage();
                dataSelector = new DataSelector(commonBasePage);
                if (localeData.madlibText) {
                    const actualMadlibText = await dataSelector.getMadlibText();
                    console.log("Actual Madlib Text:", actualMadlibText);
                    console.log("Expected Pattern:", localeData.madlibText);
                    assert(actualMadlibText).toMatch(
                        new RegExp(localeData.madlibText, "i")
                    );

                    console.log(
                        " Madlib validation passed for locale:",
                        localeData.locale
                    );
                } else {
                    console.warn(
                        `No madlib text pattern defined for locale: ${localeData.locale}`
                    );
                }
            }
        );
        test.describe.serial(
            "Run, PPT Export, Excel Export",
            { tag: ["@Report_E2E_Flow"] },
            () => {
                test(
                    "Report Generation: Validates dimension selection and successful execution",
                    {
                        tag: "@RunReport",
                    },
                    async () => {
                        test.setTimeout(RUN_TEST_TIMEOUT + MAX_TEST_TIMEOUT);
                        let basePage = await BasePageFactory.createBasePage();
                        commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(reportUrl);
                        let commonBasePage = commonTestCase.getBasePage();
                        dataSelector = new DataSelector(commonBasePage);
                        await dataSelector.clickAdditionalPromptEllipsisIcon();

                        await dataSelector.clickMadlibDimension("Universe");
                        await dataSelector.setMadlibSelection(
                            reportTestData.dimensionSelections[0]["Universe"]
                        );

                        await dataSelector.clickMadlibDimension("Retailer");
                        await dataSelector.setMadlibSelection(
                            reportTestData.dimensionSelections[0]["Retailer"]
                        );

                        await dataSelector.clickMadlibDimension("Demographic");
                        await dataSelector.setMadlibSelection(
                            reportTestData.dimensionSelections[0]["Demographic"]
                        );

                        await dataSelector.clickMadlibDimension("Buyer Group");
                        await dataSelector.setMadlibSelection(
                            reportTestData.dimensionSelections[0]["Buyer Group"]
                        );
                        await dataSelector.clickMadlibDimension("Additional attributes");
                        await dataSelector.multiSelectDropDown(
                            reportTestData.dimensionSelections[0]["Additional attributes"]["selections"]
                        );
                        await dataSelector.clickMadlibDimension("blankSpace");
                         
                        await dataSelector.clickMadlibDimension("Shopper Group");
                        await dataSelector.setMadlibSelection(
                            reportTestData.dimensionSelections[0]["Shopper Group"]
                        );
                        await dataSelector.clickMadlibDimension("Period");
                        await dataSelector.setPeriodMadlibSelection(
                            reportTestData.dimensionSelections[0]["Period"]
                        );
                         await dataSelector.clickMadlibDimension("Facts");
                        await dataSelector.multiSelectDropDown(
                        // reportAssertData["dataSummary"]["Facts"]["factList"]
                        reportTestData.dimensionSelections[0]["Facts"]["selections"]["value"]
                        );
                        await dataSelector.clickMadlibDimension("blankSpace");
                        await dataSelector.clickMadlibDimension("Geography");
                        await dataSelector.setMadlibSelection(
                            reportTestData.dimensionSelections[0]["Geography"]
                        );

                        let dsBasePage = await dataSelector.getBasePage();
                        commonTestCase = new CommonTestCase(dsBasePage);
                        await commonTestCase.clickRunButton();
                        await commonTestCase.waitForReportRunCompletion();
                        console.log("run complete in spec");
                        const { newReportTitle, newUrl } =
                            await commonTestCase.saveReport();
                        savedReportTitle = newReportTitle;
                        savedReportUrl = newUrl;
                        console.log("savedReportTitle:", savedReportTitle);
                        console.log("savedReportUrl:", savedReportUrl);
                    }
                );
                test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
                    test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

                    let basePage = await BasePageFactory.createBasePage();
                    let findMyStuff = new FindMyStuff(basePage);
                    await findMyStuff.navigateToUrl(config.BASE_URL);

                    await findMyStuff.openCurrentReportFMS(savedReportTitle);

                    console.log("Open current report from FMS - Report visible in UI");
                });
                test(
                    "Validate FullScreen",
                    {
                        tag: "@ValidateFullScreen",
                    },
                    async () => {
                        let basePage = await BasePageFactory.createBasePage();
                        commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(savedReportUrl || reportUrl);
                        await commonTestCase.fullScreenView();
                    }
                );

                test(
                    "Validate presentationMode",
                    {
                        tag: "@PresentationMode",
                    },
                    async () => {
                        let basePage = await BasePageFactory.createBasePage();
                        commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(savedReportUrl || reportUrl);
                        await commonTestCase.presentationMode();
                    }
                );

                test(
                    "Validate snapshot",
                    { tag: "@Snapshot" },
                    async () => {
                        let basePage = await BasePageFactory.createBasePage();
                        const commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(savedReportUrl);
                        let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
                        await snapshot.waitForReportRunCompletion();
                        await snapshot.clickSaveIcon();
                        await snapshot.clickSnapshotIcon();
                        console.log("Snapshot clicked");
                        assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
                        let snapshotUrl: string = await snapshot.shiftingToSnapshot();
                        console.log("Snapshot shifted to right:", snapshotUrl);
                    }
                );

                test(
                    "Validate PPT export",
                    {
                        tag: "@ValidatePPTExport",
                    },
                    async () => {
                        let exportComponent: ExportComponent;
                        let basePage = await BasePageFactory.createBasePage();
                        commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(savedReportUrl);
                        let commonBasePage = await commonTestCase.getBasePage();
                        exportComponent = new ExportComponent(commonBasePage);
                        await exportComponent.validateExportFunctionality(
                            "PowerPoint",
                            "Editable objects",
                            "Separately"
                        );
                    }
                );

                test(
                    "Validate Excel export",
                    {
                        tag: "@ValidateExcelExport",
                    },
                    async () => {
                        let exportComponent: ExportComponent;
                        let basePage = await BasePageFactory.createBasePage();
                        commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(savedReportUrl);
                        let commonBasePage = await commonTestCase.getBasePage();
                        exportComponent = new ExportComponent(commonBasePage);
                        await exportComponent.validateExportFunctionality(
                            "Excel",
                            "Editable objects",
                            "Separately"
                        );
                    }
                );

                test(
                    "Validate Add Blank Report",
                    {
                        tag: "@ValidateAddBlankReport",
                    },
                    async () => {
                        let basePage = await BasePageFactory.createBasePage();
                        commonTestCase = new CommonTestCase(basePage);
                        await commonTestCase.navigateToReportUrl(savedReportUrl);

                        const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

                        let newBasePage = await BasePageFactory.createBasePage();
                        let newCommonTestCase = new CommonTestCase(newBasePage);

                        await newCommonTestCase.navigateToReportUrl(newUrl);

                        let reportFlowPage = new ReportFlowPage(newBasePage);

                        await reportFlowPage.clickAddMenuIcon();

                        await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);

                        await reportFlowPage.validateAddMenuDropdownOptions();

                        await reportFlowPage.clickAddBlankReportOption();

                        await reportFlowPage.waitForBlankReportIndicator();

                        await reportFlowPage.validateBlankReportCreation();

                        await reportFlowPage.validateUntitledReportTitle();

                        await reportFlowPage.runBlankReport(config.DATASET);

                        await reportFlowPage.clickReportByName(newReportTitle);

                        const dataSelector = new DataSelector(newBasePage);
                        await dataSelector.waitForMadlibStability();
                        const madlibText = await dataSelector.getMadlibText();

                        assert(madlibText.length).toBeGreaterThan(0);
                    }
                );
            }
        );
    });
} else {
    console.warn(
        `::warning title=Missing Test Data::Test suite "Data-driven tests" skipped because required test data was not found.`
    );
}