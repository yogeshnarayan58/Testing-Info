import { BasePage, assert } from "@gfk/gta";
import * as nlsnPinMenuResources from "./nlsn-pin-menu-resource.json";
import {  SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../pages/common-test-case/common-test-case";
import { getPage } from "../../utils/page-utils";

const NLSN_PIN_MENU_COMPONENT_NAME = "NlsnPinMenu";

export class NlsnPinMenuComponent extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      NLSN_PIN_MENU_COMPONENT_NAME,
      nlsnPinMenuResources
    );
  }

  /**
   * Get the BasePage instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }

  /**
   * Replace template placeholders in question texts using {{placeholder}} syntax
   * @param questions Array of question texts with {{placeholder}} templates
   * @param replacements Map of placeholder names to replacement values
   * @returns Updated array with all placeholders replaced
   */
  public replaceTemplatePlaceholders(
    questions: string[],
    replacements: Record<string, string>
  ): string[] {
    return questions.map((question) => {
      let updatedQuestion = question;
      Object.entries(replacements).forEach(([placeholder, value]) => {
        const pattern = new RegExp(`\\{\\{${placeholder}\\}\\}`, "g");
        updatedQuestion = updatedQuestion.replace(pattern, value);
      });
      return updatedQuestion;
    });
  }

  /**
   * Get the current view count text (e.g., "View 1 of 5")
   * @returns The view count text
   */
  public async getViewCountText(): Promise<string> {
    try {
      const viewCountElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("pinMenuViewCount", NLSN_PIN_MENU_COMPONENT_NAME)
      );
      await viewCountElement.waitFor();
      const text = await viewCountElement.getText();
      return text?.trim() || "";
    } catch (error) {
      throw new Error(`Failed to get view count text: ${error}`);
    }
  }

  /**
   * Get the current question index from view count (e.g., 0 from "View 1 of 5")
   * Note: Returns 0-based index even though UI displays 1-based (View 1 = index 0)
   * @returns The current question index as a number (0-based)
   */
  public async getCurrentQuestionNumber(): Promise<number> {
    const viewCountText = await this.getViewCountText();
    const match = viewCountText.match(/View (\d+) of/);
    if (!match) {
      throw new Error(`Failed to extract question number from: "${viewCountText}"`);
    }
    return parseInt(match[1], 10) - 1; // Convert to 0-based index
  }

  /**
   * Get the total number of questions from view count (e.g., "5" from "View 1 of 5")
   * @returns The total number of questions
   */
  public async getTotalQuestions(): Promise<number> {
    const viewCountText = await this.getViewCountText();
    const match = viewCountText.match(/of (\d+)/);
    if (!match) {
      throw new Error(`Failed to extract total questions from: "${viewCountText}"`);
    }
    return parseInt(match[1], 10);
  }

  /**
   * Get the selected question text
   * @returns The selected question text
   */
  public async getSelectedQuestionText(): Promise<string> {
    try {
      const selectedQuestionElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("pinMenuSelectedQuestion", NLSN_PIN_MENU_COMPONENT_NAME)
      );
      await selectedQuestionElement.waitFor();
      const text = await selectedQuestionElement.getText();
      return text?.trim() || "";
    } catch (error) {
      throw new Error(`Failed to get selected question text: ${error}`);
    }
  }

  /**
   * Check if the dropdown is open
   * @returns True if dropdown is open, false otherwise
   */
  public async isDropdownOpen(): Promise<boolean> {
    try {
      const dropdownList = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("pinMenuDropdownList", NLSN_PIN_MENU_COMPONENT_NAME)
      );
      return await dropdownList.isVisible();
    } catch (error) {
      return false;
    }
  }

  /**
   * Open the dropdown by clicking the header
   */
  public async openDropdown(): Promise<void> {
    try {
      const isOpen = await this.isDropdownOpen();
      if (isOpen) {
        console.log("Dropdown is already open");
        return;
      }

      const headerElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("pinMenuHeader", NLSN_PIN_MENU_COMPONENT_NAME)
      );
      await headerElement.waitFor();
      await headerElement.click();
      
      // Wait for dropdown to open
      await this.webActionHandler.delay(SMALL_TIMEOUT);
      
      // Verify dropdown opened
      const dropdownList = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("pinMenuDropdownList", NLSN_PIN_MENU_COMPONENT_NAME)
      );
      await dropdownList.waitFor();
      
      console.log("Successfully opened dropdown");
    } catch (error) {
      throw new Error(`Failed to open dropdown: ${error}`);
    }
  }

  /**
   * Close the dropdown by clicking the header
   */
  public async closeDropdown(): Promise<void> {
    try {
      const isOpen = await this.isDropdownOpen();
      if (!isOpen) {
        console.log("Dropdown is already closed");
        return;
      }

      const headerElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("pinMenuHeader", NLSN_PIN_MENU_COMPONENT_NAME)
      );
      await headerElement.click();
      
      // Wait for dropdown to close
      await this.webActionHandler.delay(SMALL_TIMEOUT);
      
      console.log("Successfully closed dropdown");
    } catch (error) {
      throw new Error(`Failed to close dropdown: ${error}`);
    }
  }

  /**
   * Get all question texts from the dropdown
   * 
   * Note: The dropdown may contain multiple question views. For example, Assortment Optimizer 
   * has 5 views total (View 1 of 5): 4 analysis questions plus "Table View". Use maxQuestions 
   * parameter to limit retrieval to a specific number of questions when needed, or omit it to get all items.
   * 
   * @param maxQuestions Optional: Maximum number of questions to retrieve (if omitted, gets total from UI)
   * @returns Array of question texts
   */
  public async getAllQuestionTexts(maxQuestions?: number): Promise<string[]> {
    try {
      // Ensure dropdown is open
      await this.openDropdown();

      // Use provided limit or get total from UI
      const questionsToRetrieve = maxQuestions ?? await this.getTotalQuestions();
      
      const questionTexts: string[] = [];
      // Loop through each question and get its text using 0-based indexing
      for (let i = 0; i < questionsToRetrieve; i++) {
        // Use getDynamicResource with index as the dynamic value
        const questionTextElement = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource("pinMenuItemTextByIndex", i.toString(), NLSN_PIN_MENU_COMPONENT_NAME)
        );
        const text = await questionTextElement.getText();
        questionTexts.push(text?.trim() || "");
      }

      return questionTexts;
    } catch (error) {
      throw new Error(`Failed to get all question texts: ${error}`);
    }
  }

  /**
   * Switch to a specific question by index (0-based)
   * @param questionIndex The question index to switch to (0-based: 0 = first question)
   */
  public async switchToQuestion(questionIndex: number): Promise<void> {
    try {
      // Ensure dropdown is open
      await this.openDropdown();

      // Use getDynamicResource with questionIndex as the dynamic value
      const questionItem = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource("pinMenuItemByIndex", questionIndex.toString(), NLSN_PIN_MENU_COMPONENT_NAME)
      );
      
      await questionItem.waitFor();
      await questionItem.click();
      
      // Wait for selection to update
      await this.webActionHandler.delay(SMALL_TIMEOUT);
      
      console.log(`Successfully switched to question index ${questionIndex}`);
    } catch (error) {
      throw new Error(`Failed to switch to question index ${questionIndex}: ${error}`);
    }
  }

  /**
   * Switch to a specific question by question number (1-based, user-friendly)
   * @param questionNumber The question number to switch to (1-based: 1 = first question, 3 = third question)
   * @example await pinMenu.switchToQuestionNumber(3); // Switches to the 3rd question
   */
  public async switchToQuestionNumber(questionNumber: number): Promise<void> {
    if (questionNumber < 1) {
      throw new Error(`Invalid question number: ${questionNumber}. Question numbers must be >= 1`);
    }
    
    const questionIndex = questionNumber - 1; // Convert to 0-based index
    await this.switchToQuestion(questionIndex);
    console.log(`Switched to question number ${questionNumber}`);
  }

  /**
   * Pin a specific question by question number (1-based, user-friendly)
   * @param questionNumber The question number to pin (1-based: 1 = first question, 3 = third question)
   * @example await pinMenu.pinQuestionNumber(3); // Pins the 3rd question
   */
  public async pinQuestionNumber(questionNumber: number): Promise<void> {
    if (questionNumber < 1) {
      throw new Error(`Invalid question number: ${questionNumber}. Question numbers must be >= 1`);
    }
    
    const questionIndex = questionNumber - 1; // Convert to 0-based index
    
    try {
      // Ensure dropdown is open
      await this.openDropdown();

      // Use getDynamicResource with questionIndex as the dynamic value
      const pinButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource("pinMenuItemPinByIndex", questionIndex.toString(), NLSN_PIN_MENU_COMPONENT_NAME)
      );
      
      await pinButton.waitFor();
      await pinButton.click();
      
      // Wait for pin action to complete
      await this.webActionHandler.delay(SMALL_TIMEOUT);
      
      console.log(`Pinned question number ${questionNumber}`);
    } catch (error) {
      throw new Error(`Failed to pin question number ${questionNumber}: ${error}`);
    }
  }

  /**
   * Validate the default selected question
   * @param expectedQuestionIndex Expected question index (0-based: 0 = first question)
   * @param expectedQuestionText Expected question text
   */
  public async validateDefaultSelection(
    expectedQuestionIndex: number,
    expectedQuestionText: string
  ): Promise<void> {
    try {
      // Get current question index
      const actualQuestionIndex = await this.getCurrentQuestionNumber();
      assert(actualQuestionIndex).toBe(expectedQuestionIndex);
      console.log(`✓ Default question index validated: ${actualQuestionIndex}`);

      // Get selected question text
      const actualQuestionText = await this.getSelectedQuestionText();
      assert(actualQuestionText).toBe(expectedQuestionText);
      console.log(`✓ Default question text validated: "${actualQuestionText}"`);
      
    } catch (error) {
      throw new Error(`Failed to validate default selection: ${error}`);
    }
  }

  /**
   * Validate all question texts in the dropdown
   * @param expectedQuestions Array of expected question texts
   */
  public async validateAllQuestions(expectedQuestions: string[]): Promise<void> {
    try {
      // Retrieve exactly as many questions as we have expected values to validate
      const actualQuestions = await this.getAllQuestionTexts(expectedQuestions.length);
      
      // Validate count
      assert(actualQuestions.length).toBe(expectedQuestions.length);
      console.log(`✓ Total questions count validated: ${actualQuestions.length}`);

      // Validate each question text
      for (let i = 0; i < expectedQuestions.length; i++) {
        assert(actualQuestions[i]).toBe(expectedQuestions[i]);
        console.log(`✓ Question ${i + 1} validated: "${actualQuestions[i]}"`);
      }
      
    } catch (error) {
      throw new Error(`Failed to validate all questions: ${error}`);
    }
  }

  /**
   * Validate that the view count matches expected format and values
   * @param expectedCurrentIndex Expected current question index (0-based: 0 = "View 1")
   * @param expectedTotal Expected total number of questions
   */
  public async validateViewCount(expectedCurrentIndex: number, expectedTotal: number): Promise<void> {
    try {
      const viewCountText = await this.getViewCountText();
      // UI displays 1-based, so add 1 to the 0-based index
      const expectedText = `View ${expectedCurrentIndex + 1} of ${expectedTotal}`;
      
      assert(viewCountText).toBe(expectedText);
      console.log(`✓ View count validated: "${viewCountText}"`);
      
    } catch (error) {
      throw new Error(`Failed to validate view count: ${error}`);
    }
  }

  // public async getAllFacts(expectedData: any):Promise<string[]>{

  //   try {
  //     //Open Facts Dropdown
  //     const factsElement = this.webActionHandler.getWebElement(
  //       this.resourceManager.getResource("factsInternalDropdown", NLSN_PIN_MENU_COMPONENT_NAME)
  //     );
  //      await factsElement.waitFor();
  //      await factsElement.click();

      
  //     const factsTexts: string[] = [];
  //     // Loop through each question and get its text using 0-based indexing
  //     for (let i = 0; i < expectedData.length; i++) {
  //       // Use getDynamicResource with index as the dynamic value (i+1 for 1-based CSS nth-child)
  //       const factsTextElement = this.webActionHandler.getWebElement(
  //         this.resourceManager.getDynamicResource("factsInternalDropdownOptions", (i+1).toString(), NLSN_PIN_MENU_COMPONENT_NAME)
  //       );
  //       const text = await factsTextElement.getText();
  //       factsTexts.push(text?.trim() || "");
  //     }

  //     return factsTexts;
  //   } catch (error) {
  //     throw new Error(`Failed to get all facts texts: ${error}`);
  //   }

  // }

  // /**
  //  * Validate all question texts in the dropdown
  //  * @param expectedData Array of expected question texts
  //  */
  // public async validateAllFacts(expectedData: string[]): Promise<void> {
  //   try {
  //     // Retrieve exactly as many questions as we have expected values to validate
  //     const actualFacts = await this.getAllFacts(expectedData);
      
  //     // Validate count
  //     assert(actualFacts.length).toBe(expectedData.length);
  //     console.log(`Total facts count validated: ${actualFacts.length}`);

  //     // Validate each question text
  //     for (let i = 0; i < expectedData.length; i++) {
  //       assert(actualFacts[i]).toBe(expectedData[i]);
  //       console.log(`Facts ${i + 1} validated: "${actualFacts[i]}"`);
  //     }
      
  //   } catch (error) {
  //     throw new Error(`Failed to validate all facts: ${error}`);
  //   }
  // }

 

  // public async clickDimension(dimension: string): Promise<void> {
  //   try {
  //     // Retrieve the web element corresponding to the specified dimension
  //     const dimensionElement = this.webActionHandler.getWebElement(
  //       this.resourceManager.getResource(dimension, NLSN_PIN_MENU_COMPONENT_NAME)
  //     );     

  //     // Wait until the element is visible and ready for interaction
  //     await dimensionElement.waitFor();
  //     // Click the dimension element
  //     await dimensionElement.click();
  //   } catch (error) {
  //     console.error(`Failed to click  dimension`, error);
  //     const errorMessage = error instanceof Error ? error.message : String(error);
  //     throw new Error(`Error interacting with dimension  ${errorMessage}`);
  //   }
  // }

  // public async switchToOption(indexnumber: number, dimension: any): Promise<void> {
  //   try {
      
  //     const dataItem = this.webActionHandler.getWebElement(
  //         this.resourceManager.getDynamicResource("factsInternalDropdownOptions", indexnumber.toString(), NLSN_PIN_MENU_COMPONENT_NAME)
  //       );
  //     console.log(`data item${dataItem}.getText()` );
  //     await dataItem.waitFor();
  //     await dataItem.click();
      
  //     // Wait for selection to update
  //     await this.webActionHandler.delay(SMALL_TIMEOUT);
      
  //     console.log(`Successfully switched to option ${indexnumber}`);
  //   } catch (error) {
  //     throw new Error(`Failed to switch to option ${indexnumber}: ${error}`);
  //   }
  // }
 
}
