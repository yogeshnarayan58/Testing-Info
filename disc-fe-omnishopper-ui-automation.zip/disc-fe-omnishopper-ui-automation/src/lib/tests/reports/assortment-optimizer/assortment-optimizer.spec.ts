import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { NlsnPinMenuComponent } from "../../../common/components/nlsn-pin-menu/nlsn-pin-menu";
import { AssortmentOptimizerComponent } from "./assortment-optimizer";
import {
  findDataSetByName,
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import assertionData from "./assertion-data/assertion-data.json";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";

if (reportTestData) {
  test.describe("Assortment Optimizer", () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;
    let formatPanel: FormatPanel;

    test(
      "QuickLook: Should display correct preview information when template is selected",
      {
        tag: "@QuickLook",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        let landingPage = new LandingPage(basePage);
        await landingPage.navigateToUrl(config.BASE_URL);
        await landingPage.clickAnalyseMyData();
        await landingPage.clickChooseATemplate();
        let chooseAtemplatePage = new ChooseAtemplatePage(
          landingPage.getBasePage()
        );
        await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
        await chooseAtemplatePage.hoverThumbnailBySrc(
          testData.common.thumbnailSrc
        );
        await chooseAtemplatePage.clickQuickLookInfoButton();
        let quickLookPage = new QuickLookPage(
          chooseAtemplatePage.getBasePage()
        );
        const previewDescriptionValue = await quickLookPage.getPreviewDescription();
        assert(previewDescriptionValue).toBe(localeData.description);
        const themesValue = await quickLookPage.getPreviewThemes();
        assertionData.common.themes.forEach((expectedTheme: string) => {
          assert(themesValue).toContain(expectedTheme);
        });
        const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
        assertionData.common.dataSets.forEach((expectedDataset: string) => {
          assert(previewDatasetsValue).toContain(expectedDataset);
        });
      }
    );

    test(
      "Insights Panel: Should validate business questions and report metadata",
      {
        tag: "@Insights",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        const insightsPanel = new InsightsPanel(basePage);
        await insightsPanel.navigateToUrl(reportUrl);
        await insightsPanel.clickInsightsIcon();
        const isTitleVisible =
          await insightsPanel.isReportInsightsTitleVisible();
        assert(isTitleVisible).toBeTruthy();
        const isCloseIconVisible =
          await insightsPanel.isReportInsightsPanelCloseIconVisible();
        assert(isCloseIconVisible).toBeTruthy();
        const insightsReportTitle =
          await insightsPanel.getInsightsReportTitle();
        assert(insightsReportTitle?.trim()).toBe(localeData.title);
        const description = await insightsPanel.getInsightsPanelDescription();
        assert(description?.trim()).toBe(localeData.description);
        const isBusinessTitleVisible =
          await insightsPanel.isBusinessQuestionsTitleVisible();
        assert(isBusinessTitleVisible).toBeTruthy();
        await insightsPanel.validateBusinessQuestions(
          localeData.businessQuestions
        );
        await insightsPanel.closeInsightsPanel();
      }
    );
    test(
      "Madlib Validation: Should validate madlib text content matches expected pattern",
      {
        tag: "@MadlibValidation",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(reportUrl);
        let commonBasePage = commonTestCase.getBasePage();
        dataSelector = new DataSelector(commonBasePage);

        if (localeData.madlibText) {

          const actualMadlibText = await dataSelector.getMadlibText();
          console.log("Actual Madlib Text:", actualMadlibText);
          console.log("Expected Pattern:", localeData.madlibText);

          assert(actualMadlibText).toMatch(
            new RegExp(localeData.madlibText, "i")
          );

          console.log(
            " Madlib validation passed for locale:",
            localeData.locale
          );
        } else {
          console.warn(
            `No madlib text pattern defined for locale: ${localeData.locale}`
          );
        }
      }
    );

    test(
      "Validate default format panel",
      {
        tag: "@Format Panel Default Verification",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        formatPanel = new FormatPanel(basePage);
        await formatPanel.navigateToUrlAndCheckMadlibVisbility(reportUrl);
        await formatPanel.openFormatPanel();
        await formatPanel.testDefaultFormatPanel(
          assertionData["formatPanel"]["default"]
        );
        await formatPanel.closeFormatPanel();
      }
    );

    test.describe.serial(
      "Run, PPT Export, Excel Export",
      { tag: ["@Report_E2E_Flow"] },
      () => {
        test(
          "Report Generation: Validates dimension selection and successful execution",
          {
            tag: "@RunReport",
          },
          async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);
            await dataSelector.clickAdditionalPromptEllipsisIcon();

            await dataSelector.clickMadlibDimension("Universe");
            // await dataSelector.removeSelections();
            // await dataSelector.clickAddIcon();
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Universe"]
            );

            await dataSelector.clickMadlibDimension("Products_PRDC_O");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Products_PRDC_O"]
            );

            await dataSelector.clickMadlibDimension("Retailer");
            // await dataSelector.removeSelections();
            // await dataSelector.clickAddIcon();
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Retailer"]
            );
            await dataSelector.clickMadlibDimension("Period");
            // await dataSelector.removeSelections();
            // await dataSelector.clickAddIcon();
            await dataSelector.setPeriodMadlibSelection(
              reportTestData.dimensionSelections[0]["Period"]
            );
            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Geography"]
            );
            await dataSelector.clickMadlibDimension("Demography");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Demography"]
            );
            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.selectClosedDropdown(
              reportTestData.dimensionSelections[0]["Facts"]["selections"]
            );
            await dataSelector.clickMadlibDimension("Buyer Group");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Buyer Group"]
            );
            // await dataSelector.clickMadlibDimension("Shopper Group");
            // await dataSelector.setMadlibSelection(
            //   reportTestData.dimensionSelections[0]["Shopper Group"]
            // );


            let dsBasePage = await dataSelector.getBasePage();
            commonTestCase = new CommonTestCase(dsBasePage);
            await commonTestCase.clickRunButton();
            await commonTestCase.waitForReportRunCompletion();
            console.log("run complete in spec");
            const { newReportTitle, newUrl } =
              await commonTestCase.saveReport();
            savedReportTitle = newReportTitle;
            savedReportUrl = newUrl;
            console.log("savedReportTitle:", savedReportTitle);
            console.log("savedReportUrl:", savedReportUrl);
          }
        );
        test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
          test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

          let basePage = await BasePageFactory.createBasePage();
          let findMyStuff = new FindMyStuff(basePage);
          await findMyStuff.navigateToUrl(config.BASE_URL);

          await findMyStuff.openCurrentReportFMS(savedReportTitle);

          console.log("Open current report from FMS - Report visible in UI");
        });

        test(
          "Pin Menu: Should validate default question and all dropdown options",
          {
            tag: "@PinMenuValidation",
          },
          async () => {
            // If RunReport fails, savedReportUrl will be empty and this test will skip
            test.skip(!savedReportUrl, 'Skipping Pin Menu - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            const pinMenu = new NlsnPinMenuComponent(basePage);
            await pinMenu.navigateToUrl(savedReportUrl);

            // Get dynamic fact value from test data for question text validation
            const factValue = reportTestData?.dimensionSelections?.[0]?.["Facts"]?.selections?.closedPromptFactDropdown?.[0] || "EQ2";
            
            // Create template replacements map for {{placeholder}} syntax
            const templateReplacements = { "factValue": factValue };
            
            // Apply template replacements to pin menu questions
            const dynamicPinMenuQuestions = pinMenu.replaceTemplatePlaceholders(
              localeData.pinMenuQuestions || [],
              templateReplacements
            );

            // Validate default selection (should be index 0 = first question)
            console.log("Validating default pin menu selection...");
            await pinMenu.validateDefaultSelection(0, dynamicPinMenuQuestions[0] || "");

            // Validate all questions in dropdown with dynamic replacements
            console.log("Validating all pin menu questions...");
            await pinMenu.validateAllQuestions(dynamicPinMenuQuestions);

            // Validate view count text (index 0 displays as "View 1")
            const totalQuestions = await pinMenu.getTotalQuestions();
            console.log(`Validating view count: View 1 of ${totalQuestions}`);
            await pinMenu.validateViewCount(0, totalQuestions);

            await pinMenu.switchToQuestionNumber(5); // Switches to question 5 (Table View)

            // Additional use case
            // Note: This method is fully implemented in NlsnPinMenuComponent and can be
            // reused in any report that has the nlsn-pin-menu dropdown component.
            // Use case: Pin a specific question by question number (1-based)
            // await pinMenu.pinQuestionNumber(3); // Pins question 3 (3rd question)
            // await pinMenu.pinQuestionNumber(1); // Pins question 1 (1st question)

            console.log("Pin menu validation completed successfully");
          }
        );

        test(
          "Report Specific Validations: Toggle switching, screenshot comparisons, and multi-question navigation",
          {
            tag: "@ReportSpecificValidations",
          },
          async ({ }, testInfo) => {
            test.skip(!savedReportUrl, 'Skipping Report Specific Validations - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            // Set timeout for this test using constant: 5 minutes for all questions and toggles
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            const toggleComponent = new AssortmentOptimizerComponent(basePage);
            const pinMenu = new NlsnPinMenuComponent(basePage);
            const testCommonTestCase = new CommonTestCase(basePage);
            await toggleComponent.navigateToUrl(savedReportUrl);

            // ============================================================================
            // Question 1 - Toggle Switching and Screenshot Comparison
            // ============================================================================
            console.log("Testing Question 1...");
            // Note: Report loads on Question 1 by default, so no need to navigate
            console.log("Navigated to Question 1");

            // Validate toggle values before switching
            const q1ToggleValues = localeData.toggleValues?.question1;
            assert(q1ToggleValues).toBeTruthy(); // Ensure toggle data is defined
            assert(q1ToggleValues?.length).toBe(2); // Q1 should have 2 toggles
            await toggleComponent.validateToggleValues(1, q1ToggleValues!);

            // Toggle 0 (first toggle)
            await toggleComponent.switchToggle(1, 0);
            console.log("✓ Question 1 - Toggle 0 switched successfully");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q1-toggle-0", "lib-sop-assortment-optimizer");

            // Toggle 1 (second toggle)
            await toggleComponent.switchToggle(1, 1);
            console.log("✓ Question 1 - Toggle 1 switched successfully");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q1-toggle-1", "lib-sop-assortment-optimizer");

            // ============================================================================
            // Question 2 - Screenshot Comparison
            // ============================================================================
            console.log("Testing Question 2...");
            await pinMenu.switchToQuestionNumber(2);
            // WebActionHandler.delay is built-in wait - waits for animations and DOM updates
            await pinMenu.webActionHandler.delay(SMALL_TIMEOUT);
            console.log("Navigated to Question 2");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q2", "lib-sop-assortment-optimizer");

            // ============================================================================
            // Question 3 - Screenshot Comparison
            // ============================================================================
            console.log("Testing Question 3...");
            await pinMenu.switchToQuestionNumber(3);
            // Short delay for DOM update
            await pinMenu.webActionHandler.delay(SMALL_TIMEOUT);
            console.log("Navigated to Question 3");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q3", "lib-sop-assortment-optimizer");

            // ============================================================================
            // Question 4 - Toggle Switching and Screenshot Comparison
            // ============================================================================
            console.log("Testing Question 4...");
            await pinMenu.switchToQuestionNumber(4);
            // WebActionHandler.delay waits for animations and DOM updates
            await pinMenu.webActionHandler.delay(SMALL_TIMEOUT);
            console.log("Navigated to Question 4");

            // Validate toggle values before switching
            const q4ToggleValues = localeData.toggleValues?.question4;
            assert(q4ToggleValues).toBeTruthy(); // Ensure toggle data is defined
            assert(q4ToggleValues?.length).toBe(3); // Q4 should have 3 toggles
            await toggleComponent.validateToggleValues(4, q4ToggleValues!);

            // Toggle 0 (first toggle)
            await toggleComponent.switchToggle(4, 0);
            console.log("✓ Question 4 - Toggle 0 switched successfully");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q4-toggle-0", "lib-sop-assortment-optimizer");

            // Toggle 1 (second toggle)
            await toggleComponent.switchToggle(4, 1);
            console.log("✓ Question 4 - Toggle 1 switched successfully");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q4-toggle-1", "lib-sop-assortment-optimizer");

            // Toggle 2 (third toggle)
            await toggleComponent.switchToggle(4, 2);
            console.log("✓ Question 4 - Toggle 2 switched successfully");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q4-toggle-2", "lib-sop-assortment-optimizer");

            // ============================================================================
            // Question 5 - Table View Validation
            // ============================================================================
            console.log("Testing Question 5...");
            await pinMenu.switchToQuestionNumber(5);
            // Short delay for DOM update
            await pinMenu.webActionHandler.delay(SMALL_TIMEOUT);
            console.log("Navigated to Question 5 (Table View)");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q5", "lib-sop-assortment-optimizer");

            console.log("Report specific validations completed successfully");
          }
        );

        test(
          "Validate FullScreen",
          {
            tag: "@ValidateFullScreen",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.fullScreenView();
          }
        );

        test(
          "Validate presentationMode",
          {
            tag: "@PresentationMode",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.presentationMode();
          }
        );


        test(
          "Validate snapshot",
          { tag: "@Snapshot" },
          async () => {
            test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            const commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
            await snapshot.waitForReportRunCompletion();
            await snapshot.clickSaveIcon();
            await snapshot.clickSnapshotIcon();
            console.log("Snapshot clicked");
            assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
            let snapshotUrl: string = await snapshot.shiftingToSnapshot();
            console.log("Snapshot shifted to right:", snapshotUrl);
          }
        );

        test(
          "Validate PPT export",
          {
            tag: "@ValidatePPTExport",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping PPT Export - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
          }
        );

        test(
          "Validate Excel export",
          {
            tag: "@ValidateExcelExport",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping Excel Export - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality(
              "Excel",
              "Editable objects",
              "Separately"
            );
          }
        );
        test(
          "Validate Add Blank Report",
          {
            tag: "@ValidateAddBlankReport",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping Add Blank Report - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
               test.setTimeout(RUN_TEST_TIMEOUT);
               
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);

            // Make a copy of the current report
            const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

            // Create a new CommonTestCase for the new report flow  
            let newBasePage = await BasePageFactory.createBasePage();
            let newCommonTestCase = new CommonTestCase(newBasePage);

            // Navigate to the new URL using CommonTestCase
            await newCommonTestCase.navigateToReportUrl(newUrl);

            // Create ReportFlowPage with the same base page
            let reportFlowPage = new ReportFlowPage(newBasePage);

            // Test the correct workflow: Add Menu -> Add Blank Report
            await reportFlowPage.clickAddMenuIcon();

            // Wait briefly for dropdown to appear
            await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);

            // Validate all three dropdown options are present
            await reportFlowPage.validateAddMenuDropdownOptions();

            // Click "Add blank report" option directly from dropdown
            await reportFlowPage.clickAddBlankReportOption();

            // Wait for blank report to be created
            await reportFlowPage.waitForBlankReportIndicator();

            // Validate that blank report was created successfully
            await reportFlowPage.validateBlankReportCreation();

            // Validate that the report title shows 'Untitled'
            await reportFlowPage.validateUntitledReportTitle();

            // Run the complete blank report workflow (dataset selector, apply dataset, madlib selections, and report execution)
            await reportFlowPage.runBlankReport(config.DATASET);

            // Switch back to the original report tab
            await reportFlowPage.clickReportByName(newReportTitle);

            // Wait for the madlib to stabilize and validate it's loaded properly
            const dataSelector = new DataSelector(newBasePage);
            await dataSelector.waitForMadlibStability();
            const madlibText = await dataSelector.getMadlibText();

            // Assert that madlib text is not empty and contains expected content
            assert(madlibText.length).toBeGreaterThan(0);
          }
        );
      }
    );
  });
} else {
  console.warn(
    `::warning title=Missing Test Data::Test suite "Data-driven tests" skipped because required test data was not found.`
  );
}