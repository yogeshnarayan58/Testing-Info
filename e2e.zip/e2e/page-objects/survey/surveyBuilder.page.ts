import { BasePage, WebActions } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import {
  ELEMENT_WAIT_TIMEOUT,
  UI_STATE_UPDATE_DELAY,
  PANEL_TRANSITION_DELAY,
  SMALL_TIMEOUT,
  MEDIUM_TIMEOUT,
  NAVIGATION_TIMEOUT
} from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';
import surveyBuilderPageResources from '../../locators/survey/surveyBuilder.locator.json';
import devTestData from '../../test-data/dev-test-data.json';

const SURVEY_BUILDER_PAGE_COMPONENT_NAME = 'surveyBuilderPage';

export class SurveyBuilderPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      SURVEY_BUILDER_PAGE_COMPONENT_NAME,
      surveyBuilderPageResources
    );
  }

  /** Throws (unlike `waitFor()`, which does not throw on timeout in this framework) if `element` isn't visible within `timeoutMs`. */
  private async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  private getResource(name: string) {
    return this.resourceManager.getResource(name, SURVEY_BUILDER_PAGE_COMPONENT_NAME);
  }

  /** Races `action` against `timeoutMs` so calls with no native timeout param in this framework's WebElement
   *  wrapper (hover/click/enterText - confirmed via webElement.js: they delegate to Playwright's
   *  locator.hover()/click()/fill() with no `timeout` option) can't hang past it - e.g. on Playwright's own
   *  default actionTimeout, which playwright.config.ts leaves unset (0/unbounded), so an unreachable/occluded
   *  element otherwise hangs until the suite's 300s test timeout instead of failing fast with a clear cause. */
  private async withTimeout<T>(action: Promise<T>, timeoutMs: number, step: string): Promise<T> {
    let timer!: ReturnType<typeof setTimeout>;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${step} timed out after ${timeoutMs}ms`)), timeoutMs);
    });
    try {
      return await Promise.race([action, timeoutPromise]);
    } finally {
      clearTimeout(timer);
    }
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then clicks it. */
  private async clickWhenVisible(resourceName: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.click();
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then fills it. */
  private async fillWhenVisible(resourceName: string, text: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.enterText(text);
  }

  // Question type selection
  private async clickQuestionTypeResource(resourceName: string): Promise<void> {
    await this.clickWhenVisible(resourceName, `Question-type tile "${resourceName}"`, MEDIUM_TIMEOUT);
  }

  // Shared field helpers (operate on the currently expanded/editing question)
  private async fillQuestionText(questionIndex: number, text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('questionTextInput', String(questionIndex), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await this.waitUntilVisible(questionText, 'Question text input');
    await questionText.enterText(text);
  }

  /** Fills Option N / Row N / Column N fields by their visible role label, e.g. 'Option 1', 'Row 2'. */
  private async fillLabeledField(label: string, value: string): Promise<void> {
    const field = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('optionInputByLabel', label, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await this.waitUntilVisible(field, `Field "${label}"`);
    await field.enterText(value);
  }

  /** Fills Rating's question-text field — locator is unscoped by question index (interim `:visible`-based mitigation). */
  private async fillRatingQuestionText(text: string): Promise<void> {
    await this.fillWhenVisible('ratingQuestionTextInput', text, 'Rating question text input');
  }

  /**
   * Computes the questionIndex for a new question the same way the app itself does:
   * `surveyService.getQuestions().length + 1` (see question-editor.component.ts's
   * `upcomingQuestionNumber`). Counts the rendered `.question-number` markers on
   * already-saved questions rather than trusting any hardcoded literal, since the
   * persisted survey's question count is not stable across runs.
   */
  private async getNextQuestionIndex(): Promise<number> {
    const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    return markers.length + 1;
  }

  /** Counts rendered `.question-number` markers, for TC_BS_REVIEW_MODE's delete-count assertion. */
  async getQuestionCount(): Promise<number> {
    try {
      const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
      return markers.length;
    } catch (error) {
      throw new Error(`Failed to get question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Re-expands the question card after it collapses/saves on field-fill.
   *  `editQuestionButton` ([niqtooltip='Edit']) matches one icon per question, so once 2+ questions
   *  exist it's a Playwright strict-mode violation; scope to the LAST match (the question just added). */
  private async reopenCollapsedQuestion(): Promise<void> {
    const questionCount = await this.getQuestionCount();
    const editButtonResource = this.getResource('editQuestionButton');
    const editButton = this.webActionHandler.getWebElement({
      ...editButtonResource,
      selectorType: 'playwrights',
      selectorValue: `${editButtonResource.selectorValue} >> nth=${Math.max(questionCount - 1, 0)}`
    });
    await this.waitUntilVisible(editButton, 'Edit question button');
    await editButton.click();
  }

  async addOptionToQuestion(): Promise<void> {
    try {
      await this.clickWhenVisible('addOptionButton', 'Add option button');
    } catch (error) {
      throw new Error(`Failed to add option to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers the Add-menu trigger wrapper (`.matrix-action-area`) so the Row/Column buttons render — confirmed via source (scale-editor.component.html). */
  private async hoverScaleAddMenuTrigger() {
    const addMenuTrigger = this.webActionHandler.getWebElement(this.getResource('scaleAddMenuTrigger'));
    await this.waitUntilVisible(addMenuTrigger, 'Scale add-menu trigger');
    await addMenuTrigger.hover();
    return addMenuTrigger;
  }

  /** Shared by Point Scale and Multi Scale — both use the same survey-scale-editor matrix-actions mechanism. */
  async addRowToQuestion(): Promise<void> {
    try {
      const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
      const addRow = addMenuTrigger.getWebElement(this.getResource('addRowButton'));
      await this.waitUntilVisible(addRow, 'Add row button');
      await addRow.click();
    } catch (error) {
      throw new Error(`Failed to add row to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Shared by Point Scale and Multi Scale — both use the same survey-scale-editor matrix-actions mechanism. */
  async addColumnToQuestion(): Promise<void> {
    try {
      const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
      const addColumn = addMenuTrigger.getWebElement(this.getResource('addColumnButton'));
      await this.waitUntilVisible(addColumn, 'Add column button');
      await addColumn.click();
    } catch (error) {
      throw new Error(`Failed to add column to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** The Add Question panel (`.inline-add-editor`) renders its own always-edit `survey-question-editor`, so its
   *  Required toggle/Save button share the same selectors as any open row editor — close it first so row-scoped
   *  clicks can't land on the wrong editor. It's normally absent (not just hidden), so this is an instant,
   *  non-waiting state read (isVisible(0)), not a web-first wait for it to appear. */
  private async closeInlineAddEditorIfOpen(): Promise<void> {
    const inlineEditor = this.webActionHandler.getWebElement(this.getResource('inlineAddEditor'));
    if (await inlineEditor.isVisible(0)) {
      await this.clickAddQuestion();
    }
  }

  /** `requiredToggle` ([data-test-id='-input-checkbox']) — confirmed correct per Codegen recording; the truncated id with no real prefix is how the live DOM renders it, so the
   *  same attribute matches EVERY question's checkbox (rendered, not just visible, once more than one editor has been opened in the session). When `index` is given, scopes to
   *  that row (`.question-row >> nth=${index}`) instead of a page-wide nth, so it can't match another editor's toggle; `index` is optional (default: unscoped, first match) so
   *  the pre-existing single-editor scratch tests keep their original behavior. */
  async toggleRequired(index?: number): Promise<void> {
    try {
      if (index === undefined) {
        await this.clickWhenVisible('requiredToggle', 'Required toggle');
      } else {
        await this.closeInlineAddEditorIfOpen();
        const rowResource = this.getResource('questionRow');
        const toggleResource = this.getResource('requiredToggle');
        const toggle = this.webActionHandler.getWebElement({
          ...toggleResource,
          selectorType: 'playwrights',
          selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue}`
        });
        await this.waitUntilVisible(toggle, `Required toggle (index ${index})`);
        await this.withTimeout(
          toggle.click(),
          ELEMENT_WAIT_TIMEOUT,
          `Click Required toggle (step: toggleRequired, index ${index}, locator: ${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue})`
        );
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to toggle required: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_12 — footer's "Back" button (footer.component.html), no data-test-id, resolved by text. */
  async clickBackButton(): Promise<void> {
    try {
      await this.clickWhenVisible('backButton', 'Back button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to click back button: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_12 — stepper's clickable circle (niq-step-circle, athena-core StepComponent), text doesn't navigate; index 0 = Select Panelists. */
  async clickSelectPanelistsStep(): Promise<void> {
    try {
      await this.clickWhenVisible('select-panelists-step-circle', 'Select Panelists step circle', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to click Select Panelists step: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickAddQuestion(): Promise<void> {
    try {
      await this.clickWhenVisible('addQuestionLink', 'Add question link');
      await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
    } catch (error) {
      throw new Error(`Failed to click add question: ${error instanceof Error ? error.message : error}`);
    }
  }

  // ---------------------------------------------------------------------
  // Per-question-type methods (TC_BS_03–TC_BS_09)
  // Each assumes it is called right after clickAddQuestion() (or for
  // question 1, right after landing on Build Survey), while this question
  // is the currently expanded one.
  // ---------------------------------------------------------------------

  /** TC_BS_03 */
  async addSingleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeSingleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.reopenCollapsedQuestion();
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }

      const saveButton = this.webActionHandler.getWebElement(this.getResource('saveQuestionChangesButton'));
      if (await saveButton.isVisible(SMALL_TIMEOUT)) {
        await saveButton.click();
      }
      await this.waitForQuestionCountAtLeast(questionIndex, MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to add Single Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_04 */
  async addMultipleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultipleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question; survey-builder.spec.ts also calls clickAddQuestion() before this, which may add an extra blank question (not fixed here)
    } catch (error) {
      throw new Error(`Failed to add Multiple Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_05 */
  async addRatingQuestion(questionText: string): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeRating');
      await this.fillRatingQuestionText(questionText); // Rating's input is unscoped by index (interim :visible-based mitigation)
      await this.clickAddQuestion(); // finalizes/saves this question; survey-builder.spec.ts also calls clickAddQuestion() before this, which may add an extra blank question (not fixed here)
    } catch (error) {
      throw new Error(`Failed to add Rating question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * TC_BS_06 — NOT IMPLEMENTED. No confirmed locator for the "Text" question
   * type exists yet (never exercised in the Codegen capture). Add this once
   * `questionTypeText` is confirmed and added to survey-builder.locator.json.
   */
  // async addTextQuestion(questionIndex: number, questionText: string): Promise<void> { ... }

  /** TC_BS_07 */
  async addNPSQuestion(questionText: string): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeNPS');
      await this.fillQuestionText(questionIndex, questionText); // confirmed via DevTools: NPS reuses the shared questionTextInput locator at this index
      await this.clickAddQuestion(); // finalizes/saves this question; survey-builder.spec.ts also calls clickAddQuestion() before this, which may add an extra blank question (not fixed here)
    } catch (error) {
      throw new Error(`Failed to add Net Promoter Score question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * TC_BS_08 — Point Scale. Shares the exact same `survey-scale-editor` Angular
   * component (and matrix-actions hover mechanism) as Multi Scale — confirmed
   * via source (scale-editor.component.html).
   */
  async addPointScaleQuestion(
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypePointScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question; survey-builder.spec.ts also calls clickAddQuestion() before this, which may add an extra blank question (not fixed here)
    } catch (error) {
      throw new Error(`Failed to add Point Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_09 — Multi Scale, including add-row/add-column (confirmed real per Codegen + TC_BS_09). */
  async addMultiScaleQuestion(
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultiScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question; survey-builder.spec.ts also calls clickAddQuestion() before this, which may add an extra blank question (not fixed here)
    } catch (error) {
      throw new Error(`Failed to add Multi Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Review mode (part of TC_BS_13; select/reorder indices per Codegen —
  // NOT independently confirmed against a clean manual flow)

  async enterReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('reviewSurveyButton', 'Review survey button');
      const selectAllButtonAfterEntering = this.webActionHandler.getWebElement(this.getResource('selectAllButton'));
      await this.waitUntilVisible(selectAllButtonAfterEntering, 'Select all button (review mode controls)');
    } catch (error) {
      throw new Error(`Failed to enter review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectQuestionInReview(index: number): Promise<void> {
    try {
      const questionCheckbox = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(questionCheckbox, `Select-question checkbox (index ${index})`);
      await questionCheckbox.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to select question ${index} in review: ${error instanceof Error ? error.message : error}`);
    }
  }

  async deleteSelectedQuestions(): Promise<void> {
    try {
      await this.clickWhenVisible('deleteQuestionsButton', 'Delete questions button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to delete selected questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectAll(): Promise<void> {
    try {
      await this.clickWhenVisible('selectAllButton', 'Select all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to select all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async unselectAll(): Promise<void> {
    try {
      await this.clickWhenVisible('unselectAllButton', 'Unselect all button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to unselect all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async expandAll(): Promise<void> {
    try {
      await this.clickWhenVisible('expandAllButton', 'Expand all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to expand all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async collapseAll(): Promise<void> {
    try {
      await this.clickWhenVisible('collapseAllButton', 'Collapse all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to collapse all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async exitReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('exitReviewModeButton', 'Exit review mode button');
      const reviewButtonAfterExit = this.webActionHandler.getWebElement(this.getResource('reviewSurveyButton'));
      await this.waitUntilVisible(reviewButtonAfterExit, 'Review survey button (back on Build Survey screen)');
    } catch (error) {
      throw new Error(`Failed to exit review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_13: Select All/Expand All/Collapse All/Delete/Exit Review Mode buttons all visible. */
  async areReviewControlsVisible(): Promise<boolean> {
    try {
      const controls = ['selectAllButton', 'expandAllButton', 'collapseAllButton', 'deleteQuestionsButton', 'exitReviewModeButton'];
      for (const control of controls) {
        const element = this.webActionHandler.getWebElement(this.getResource(control));
        if (!(await element.isVisible())) {
          return false;
        }
      }
      return true;
    } catch (error) {
      throw new Error(`Failed to check review controls visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_13: counts visible select-question checkboxes across indices 0..questionCount-1. */
  async getReviewCheckboxCount(questionCount: number): Promise<number> {
    try {
      let visibleCount = 0;
      for (let index = 0; index < questionCount; index++) {
        const checkbox = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
        );
        if (await checkbox.isVisible()) {
          visibleCount++;
        }
      }
      return visibleCount;
    } catch (error) {
      throw new Error(`Failed to get review checkbox count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_14: ticked state of a single Review Mode question checkbox — `select-question-<i>-icon`
   * is a `<niq-icon>` with no checked state of its own; the real `checked`/`unchecked` class
   * lives on its ancestor `.checkbox-container` (niq-checkbox's own template). */
  async isQuestionSelected(index: number): Promise<boolean> {
    try {
      const container = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionCheckboxContainer', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      const classAttr = (await container.getAttribute('class')) ?? '';
      return classAttr.split(/\s+/).includes('checked');
    } catch (error) {
      throw new Error(`Failed to check if question ${index} is selected: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_14: raw `.question-number` marker texts, for post-delete renumbering assertion. */
  async getQuestionNumbers(): Promise<string[]> {
    try {
      return await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    } catch (error) {
      throw new Error(`Failed to get question numbers: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Polls `getQuestionNumbers()` until its length reaches `target`, or throws after `timeout` ms. */
  private async waitForQuestionCountAtLeast(target: number, timeout: number): Promise<string[]> {
    const start = Date.now();
    let questionNumbers = await this.getQuestionNumbers();
    while (questionNumbers.length < target) {
      if (Date.now() - start >= timeout) {
        throw new Error(`Timed out waiting for question count to reach ${target} (current: ${questionNumbers.length})`);
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      questionNumbers = await this.getQuestionNumbers();
    }
    return questionNumbers;
  }

  /** TC_BS_PUBLISH/@ReviewMode precondition — tops up to `min` Rating questions, stopping as soon as the
   *  saved count (`.question-number`) reaches it. The Rating tile is a toggle (clicking add-question again
   *  while it's open closes it with ✕), so add-question is only clicked when the tile isn't already visible. */
  async ensureQuestionCount(min: number): Promise<void> {
    try {
      const { questionText } = devTestData.surveyQuestions.rating;
      let questionNumbers = await this.getQuestionNumbers();

      while (questionNumbers.length < min) {
        const countBeforeAdd = questionNumbers.length;
        const typeTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));

        if (!(await typeTile.isVisible(SMALL_TIMEOUT))) {
          await this.clickAddQuestion();
          if (!(await typeTile.isVisible(MEDIUM_TIMEOUT))) {
            throw new Error(`Question-type picker did not open after clicking add-question (current question count: ${countBeforeAdd})`);
          }
        }

        await this.addRatingQuestion(`${questionText} ${countBeforeAdd + 1}`);
        questionNumbers = await this.waitForQuestionCountAtLeast(countBeforeAdd + 1, MEDIUM_TIMEOUT);
      }
    } catch (error) {
      throw new Error(`Failed to ensure question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Survey name, save, publish (TC_BS_02, TC_BS_16)
  /** TC_BS_02 */
  async setSurveyTitle(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('editSurveyNameIcon', 'Edit survey name icon');
      await this.fillWhenVisible('surveyTitleInput', title, 'Survey title input');
    } catch (error) {
      throw new Error(`Failed to set survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Fills the Save-a-copy dialog (title, My Assets, save pending changes) — shared by saveDraft() and publishSurvey(). */
  private async fillSaveCopyDialog(title: string): Promise<void> {
    await this.fillWhenVisible('saveCopyTitleInput', title, 'Save-copy title input');
    await this.clickWhenVisible('myAssetsTreeItem', 'My Assets tree item');
    await this.clickWhenVisible('savePendingChangesButton', 'Save pending changes button');
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /** TC_BS_SAVE_DRAFT — opens Save Draft dialog, titles the copy, picks My Assets, and confirms. */
  async saveDraft(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');

      await this.fillSaveCopyDialog(title);
    } catch (error) {
      throw new Error(`Failed to save draft: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_SAVE_DRAFT — navigates to My Assets and checks the saved survey's gridcell is visible. */
  async isSurveyVisibleInMyAssets(title: string): Promise<boolean> {
    try {
      const myAssetsURL = this.buildUrl(envConfig.BASE_URL, 'survey/my-assets');
      await this.navigateToUrl(myAssetsURL);
      const gridcell = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('savedAssetGridcellByTitle', title, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      return gridcell.isVisible();
    } catch (error) {
      throw new Error(`Failed to check survey visibility in My Assets: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_SAVE_DRAFT — checks the post-save toast confirming the draft was saved. */
  async isDraftSavedToastVisible(): Promise<boolean> {
    try {
      const toast = this.webActionHandler.getWebElement(this.getResource('saveDraftSuccessToast'));
      return toast.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to check draft saved toast visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_08 — "Add question" has no `state` attribute; disabled is reflected as a `disabled` class token (or aria-disabled). */
  async getAddQuestionDisabledState(): Promise<{ disabled: boolean; classAttr: string }> {
    try {
      const addQuestion = this.webActionHandler.getWebElement(this.getResource('addQuestionLink'));
      const classAttr = (await addQuestion.getAttribute('class')) ?? '';
      const ariaDisabled = await addQuestion.getAttribute('aria-disabled');
      return { disabled: classAttr.split(/\s+/).includes('disabled') || ariaDisabled === 'true', classAttr };
    } catch (error) {
      throw new Error(`Failed to get add-question disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_08 — scrolls into view, hovers "Add question", and checks the max-questions tooltip appears. */
  async isAddQuestionTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const addQuestion = this.webActionHandler.getWebElement(this.getResource('addQuestionLink'));
      await addQuestion.executeScript((e) => e.scrollIntoView());
      await addQuestion.hover();
      const message = this.webActionHandler.getWebElement(this.getResource('maxQuestionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait, no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off the hovered button so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check add-question tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `duplicateQuestionButton` matches one icon per question — scope to a single question (default: first). */
  private getDuplicateQuestionElement(questionIndex = 0) {
    const duplicateResource = this.getResource('duplicateQuestionButton');
    return this.webActionHandler.getWebElement({
      ...duplicateResource,
      selectorType: 'playwrights',
      selectorValue: `${duplicateResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** `.question-actions` (incl. Duplicate) is only revealed via `.question-row`'s (mouseenter) handler — see
   *  preview-mode.component.html/.scss — not a CSS :hover. Scope to a single row (default: first). */
  private getQuestionRowElement(questionIndex = 0) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** TC_BS_08 — hovers the first question's row (reveals Duplicate, see getQuestionRowElement), then hovers
   *  Duplicate and checks the tooltip appears within 10s. */
  async isDuplicateTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const row = this.getQuestionRowElement();
      await row.hover();
      const duplicateButton = this.getDuplicateQuestionElement();
      await duplicateButton.executeScript((e) => e.scrollIntoView());
      await duplicateButton.hover();
      const message = this.webActionHandler.getWebElement(this.getResource('maxQuestionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait (10s), no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off Duplicate so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check duplicate tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_08 — Duplicate's disabled state (aria-disabled, or legacy `state` attribute) + outerHTML for failure diagnostics. */
  async getDuplicateDisabledState(): Promise<{ disabled: boolean; outerHtml: string }> {
    try {
      const duplicateButton = this.getDuplicateQuestionElement();
      const ariaDisabled = await duplicateButton.getAttribute('aria-disabled');
      const state = await duplicateButton.getAttribute('state');
      const outerHtml = String(await duplicateButton.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { disabled: ariaDisabled === 'true' || state === 'disabled', outerHtml };
    } catch (error) {
      throw new Error(`Failed to get duplicate disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — clicks Publish, then either fills the Save-a-copy dialog (if it appears) or, if the
   *  survey was already saved (e.g. by Save draft), Publish opens the Confirm publish? dialog directly. */
  async publishSurvey(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('publishSurveyButton', 'Publish survey button');

      const titleInput = this.webActionHandler.getWebElement(this.getResource('saveCopyTitleInput'));
      const confirmDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      const [isTitleInputVisible, isConfirmDialogVisible] = await Promise.all([
        titleInput.isVisible(ELEMENT_WAIT_TIMEOUT),
        confirmDialogText.isVisible(ELEMENT_WAIT_TIMEOUT),
      ]);

      if (isTitleInputVisible) {
        await this.fillSaveCopyDialog(title);
      } else if (!isConfirmDialogVisible) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        throw new Error(`Neither the Save-a-copy dialog nor the Confirm publish? dialog appeared after clicking Publish (url: ${currentUrl})`);
      }
    } catch (error) {
      throw new Error(`Failed to publish survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — "Quick review" dimensions in the Confirm publish? dialog each render with
   *  `data-test-id="ds-<Label>_Dimension"` inside `#publish-data-summary` (confirmed via
   *  @nielsen/crf-data-summary's compiled template). Checks the last expected index is visible. */
  async isPublishDialogDimensionCountVisible(expectedCount: number): Promise<boolean> {
    try {
      if (expectedCount <= 0) return true;
      const lastDimension = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('publish-dialog-dimension-by-index', String(expectedCount - 1), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(lastDimension, `Publish dialog dimension (index ${expectedCount - 1})`, 10000);
      return await lastDimension.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to verify Confirm publish? dimension count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — reads the "<count> responses." text from the Confirm publish? dialog's response summary. */
  async getPublishResponseSummaryText(): Promise<string> {
    try {
      const responseCount = this.webActionHandler.getWebElement(this.getResource('publish-response-count-text'));
      await this.waitUntilVisible(responseCount, 'Publish response count text', 10000);
      const text = await responseCount.getText();
      return (text ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read Confirm publish? response summary: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — "Survey published successfully." toast fired by survey-publish-popup.component.ts after confirm. */
  async isPublishSuccessToastVisible(): Promise<boolean> {
    try {
      const toast = this.webActionHandler.getWebElement(this.getResource('publish-success-toast'));
      return toast.isVisible(ELEMENT_WAIT_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check publish success toast visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — post-Confirm outcome check. Polls up to 60s: success once the URL has redirected to
   *  `/my-assets` and the success toast confirms it; fails fast as soon as `.survey-action-toast` shows
   *  anything other than the success text (survey-publish-popup.component.ts's error handler reuses the
   *  same `containerClass: 'survey-action-toast'` for `InsertToast('error', <backend message>, ...)`, so
   *  there is no separate error-only locator to check). */
  async verifyPublishSucceeded(confirmClickTime: number): Promise<boolean> {
    try {
      const elapsedSeconds = () => ((Date.now() - confirmClickTime) / 1000).toFixed(1);
      const actionToast = this.webActionHandler.getWebElement(this.getResource('survey-action-toast'));
      const successToast = this.webActionHandler.getWebElement(this.getResource('publish-success-toast'));

      const deadline = Date.now() + NAVIGATION_TIMEOUT;
      while (Date.now() < deadline) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        if (currentUrl.includes('my-assets')) {
          if (await successToast.isVisible(MEDIUM_TIMEOUT)) {
            return true;
          }
          const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
          throw new Error(`"Survey published successfully" toast did not appear after redirect (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`);
        }

        if (await actionToast.isVisible(0)) {
          const toastText = await actionToast.getText();
          if (!toastText.includes('Survey published successfully')) {
            throw new Error(`Publish failed: "${toastText}" (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s)`);
          }
        }

        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }

      const currentUrl = await this.webActionHandler.getPageUrl();
      const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
      throw new Error(`Timed out waiting for navigation to /my-assets after Confirm (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`);
    } catch (error) {
      throw new Error(`Failed to verify publish succeeded: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_PUBLISH — asserts "Confirm publish?" prompt, clicks Confirm, and waits for the "Publishing survey" status. */
  async confirmPublish(): Promise<boolean> {
    try {
      const confirmPublishDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      await this.waitUntilVisible(confirmPublishDialogText, 'Confirm publish dialog text');
      const isConfirmDialogVisible = await confirmPublishDialogText.isVisible();

      await this.clickWhenVisible('confirmPublishButton', 'Confirm publish button');

      const publishingSurveyStatus = this.webActionHandler.getWebElement(this.getResource('publishingSurveyStatus'));
      await this.waitUntilVisible(publishingSurveyStatus, 'Publishing survey status');
      const isPublishingStatusVisible = await publishingSurveyStatus.isVisible();

      return isConfirmDialogVisible && isPublishingStatusVisible;
    } catch (error) {
      throw new Error(`Failed to confirm publish: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_AI_07/TC_BS_02 — commits a title edit: survey-header.component.ts only saves on `(blur)="disableEdit()"`
   *  (calls `surveyService.updateTitle()`); `enterText()`/Playwright `fill()` never blurs the field. */
  async commitSurveyTitle(): Promise<void> {
    try {
      const titleInput = this.webActionHandler.getWebElement(this.getResource('surveyTitleInput'));
      await titleInput.pressTab();
    } catch (error) {
      throw new Error(`Failed to commit survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_AI_07/Reuse-audit — reads the `.survey-title` header text (survey-header.component.html), for asserting a title edit took effect. */
  async getSurveyTitleDisplay(): Promise<string> {
    try {
      const title = this.webActionHandler.getWebElement(this.getResource('surveyTitleDisplay'));
      await this.waitUntilVisible(title, 'Survey title display');
      return (await title.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read survey title display: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `.question-text` (readonly question display, shows `*` suffix when required) also matches the "Add question"
   *  button's own `.question-text` label; scoping to `.question-row >> nth=${index}` excludes it (that label
   *  sits outside any `.question-row`) instead of relying on index alignment. */
  private getQuestionTextDisplayElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const resource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...resource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${resource.selectorValue}`
    });
  }

  /** TC_BS_07 — reads row `index`'s SAVED Required state (editor closed) from the "*" span, text-filtered so it
   *  can't match any other sibling span; a short, non-hanging timeout since this is a point-in-time read. */
  private getRequiredStarElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const textResource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...textResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${textResource.selectorValue} >> span:text-is("*")`
    });
  }

  async isRequiredOn(index: number): Promise<boolean> {
    try {
      return await this.getRequiredStarElement(index).isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Required state (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Waits (bounded, no indefinite hang) for row `index`'s saved Required state to reach `desired`; returns
   *  false (not throw) on timeout so callers can produce their own assertion message. */
  async waitForRequiredState(index: number, desired: boolean, timeoutMs: number = MEDIUM_TIMEOUT): Promise<boolean> {
    try {
      await this.getRequiredStarElement(index).waitFor(timeoutMs, desired ? 'visible' : 'hidden');
      return true;
    } catch {
      return false;
    }
  }

  /** TC_BS_07 — sets row `index`'s Required state to `desired`, no-op if it already matches (AI-generated
   *  questions may start Required ON). Opens that row's editor (closing `.inline-add-editor` first, see
   *  openQuestionForEditing), clicks its row-scoped toggle/Save, then confirms the saved state actually changed. */
  async setRequired(index: number, desired: boolean): Promise<void> {
    try {
      if ((await this.isRequiredOn(index)) === desired) {
        return;
      }
      await this.openQuestionForEditing(index);
      await this.toggleRequired(index);
      await this.saveQuestionChanges(index);
      if (!(await this.waitForRequiredState(index, desired, MEDIUM_TIMEOUT))) {
        throw new Error(`Required state for question ${index} did not reach ${desired} within ${MEDIUM_TIMEOUT}ms (step: waitForRequiredState)`);
      }
    } catch (error) {
      throw new Error(`Failed to set Required (index ${index}) to ${desired}: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Reuse-audit (Edit question/Required star) — reads question `index`'s readonly display text (includes a trailing `*` when Required is on). */
  async getQuestionTextDisplay(index: number): Promise<string> {
    try {
      const textElement = this.getQuestionTextDisplayElement(index);
      await this.waitUntilVisible(textElement, `Question text display (index ${index})`);
      return (await textElement.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read question ${index} text display: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Reuse-audit (Edit question/Required star) — hovers row `index` (same hover-reveal gating as rephraseQuestion()/
   *  getQuestionRowElement()), clicks its Edit pencil, and waits for the question editor to open. */
  async openQuestionForEditing(index: number): Promise<void> {
    try {
      await this.closeInlineAddEditorIfOpen();
      const rowResource = this.getResource('questionRow');
      const rowLocator = `${rowResource.selectorValue} >> nth=${index}`;
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (step: hover, index ${index}, locator: ${rowLocator})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(
        row.hover(),
        ELEMENT_WAIT_TIMEOUT,
        `Hover question row (step: hover, index ${index}, locator: ${rowLocator})`
      );
      const editButtonResource = this.getResource('editQuestionButton');
      const editButtonLocator = `${editButtonResource.selectorValue} >> nth=${index}`;
      const editButton = this.webActionHandler.getWebElement({
        ...editButtonResource,
        selectorType: 'playwrights',
        selectorValue: editButtonLocator
      });
      await this.waitUntilVisible(editButton, `Edit question button (step: click edit pencil, index ${index}, locator: ${editButtonLocator})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(
        editButton.click(),
        ELEMENT_WAIT_TIMEOUT,
        `Click Edit question button (step: click edit pencil, index ${index}, locator: ${editButtonLocator})`
      );
      const saveButtonResource = this.getResource('saveQuestionChangesButton');
      const saveButton = this.webActionHandler.getWebElement(saveButtonResource);
      await this.waitUntilVisible(saveButton, `Save changes button (step: question editor open, index ${index}, locator: ${saveButtonResource.selectorValue})`, ELEMENT_WAIT_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to open question ${index} for editing: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Reuse-audit (Edit question) — clicks the Save changes button (`survey-question-editor .save-changes-action`).
   *  When `index` is given, scopes to that row so it can't click another open editor's Save button (e.g. the
   *  Add Question panel's). */
  async saveQuestionChanges(index?: number): Promise<void> {
    try {
      if (index === undefined) {
        await this.clickWhenVisible('saveQuestionChangesButton', 'Save changes button');
      } else {
        const rowResource = this.getResource('questionRow');
        const saveButtonResource = this.getResource('saveQuestionChangesButton');
        const saveButton = this.webActionHandler.getWebElement({
          ...saveButtonResource,
          selectorType: 'playwrights',
          selectorValue: `${rowResource.selectorValue} >> nth=${index} >> .save-changes-action:visible`
        });
        await this.waitUntilVisible(saveButton, `Save changes button (index ${index})`);
        await this.withTimeout(
          saveButton.click(),
          ELEMENT_WAIT_TIMEOUT,
          `Click Save changes button (step: saveQuestionChanges, index ${index}, locator: ${rowResource.selectorValue} >> nth=${index} >> .save-changes-action:visible)`
        );
      }
    } catch (error) {
      throw new Error(`Failed to save question changes: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Question editors' text input `data-test-id` only exists for Choice/NPS/Scale (`question-text-input-<questionNumber>`
   *  on `niq-text-field`, which renders it on an inner `<input data-test-id="<that>-input">`); Rating's `niq-text-field`
   *  has no such attribute at all, so its inner input renders as the literal `-input` (confirmed by the existing
   *  `ratingQuestionTextInput` resource). Matching the common `-input` suffix, scoped to the row's own editor,
   *  works for every question type without depending on `questionNumber()`/index alignment. */
  private getQuestionTextFieldElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const textResource = this.getResource('questionTextInput');
    return this.webActionHandler.getWebElement({
      ...textResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> survey-question-editor [data-test-id$='-input']:visible`
    });
  }

  /** Reuse-audit (Edit question) — opens question `index` for editing, replaces its text, and saves. */
  async editQuestionText(index: number, newText: string): Promise<void> {
    try {
      await this.openQuestionForEditing(index);
      const textField = this.getQuestionTextFieldElement(index);
      await this.waitUntilVisible(textField, `Question text field (index ${index})`);
      await textField.enterText(newText);
      await this.saveQuestionChanges(index);
    } catch (error) {
      throw new Error(`Failed to edit question ${index} text: ${error instanceof Error ? error.message : error}`);
    }
  }
}
