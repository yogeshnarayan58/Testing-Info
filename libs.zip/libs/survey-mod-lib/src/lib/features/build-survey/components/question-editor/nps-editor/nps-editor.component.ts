import {
  Component,
  ElementRef,
  inject,
  model,
  output
} from '@angular/core';
import { TextFieldModule, ToggleModule, ButtonModule } from '@nielseniq/athena-core';
import { BaseQuestionEditorDirective } from '../base-question-editor.directive';
import { SuggestionTagsComponent } from '../suggestion-tags/suggestion-tags.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'survey-nps-editor',
  standalone: true,
  imports: [TextFieldModule, ToggleModule, ButtonModule, SuggestionTagsComponent, TranslateModule],
  providers: [TranslateService],
  templateUrl: './nps-editor.component.html',
  styleUrl: './nps-editor.component.scss',
})
export class NpsEditorComponent extends BaseQuestionEditorDirective {
  private readonly translate = inject(TranslateService);

  readonly defaultLeftLabel = this.translate.instant('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND');
  readonly defaultRightLabel = this.translate.instant('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND');

  // Component-specific inputs
  npsLeftLabel = model(this.defaultLeftLabel);
  npsRightLabel = model(this.defaultRightLabel);

  /** Notifies the parent that the form changed so it can run validation/preview side effects. */
  formChange = output<void>();

  constructor(elementRef: ElementRef<HTMLElement>) {
    super(elementRef);
  }

  onInputChange(value: string | number) {
    this.question.set(String(value ?? ''));
    this.formChange.emit();
  }

  onLeftLabelChange(value: string | number) {
    this.npsLeftLabel.set(String(value ?? ''));
    this.formChange.emit();
  }

  onRightLabelChange(value: string | number) {
    this.npsRightLabel.set(String(value ?? ''));
    this.formChange.emit();
  }

  toggleChange(event: Event) {
    this.isRequired.set((event.target as HTMLInputElement).checked ?? false);
    this.formChange.emit();
  }
}