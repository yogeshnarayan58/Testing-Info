﻿import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { afterEach, describe, expect, it } from 'vitest';
import { GridComponent } from './grid.component';
import { HEAT_GRID_PREVIEW_RESPONSE, NORMAL_GRID_PREVIEW_RESPONSE } from '../../constants/survey-results-preview';
import type { GridResponse } from '../../models/question-result';

describe('GridComponent', () => {
  afterEach(() => TestBed.resetTestingModule());
  it('uses the same renderer for independent normal and heat responses', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    const response = signal<GridResponse>(structuredClone(NORMAL_GRID_PREVIEW_RESPONSE.components[0]));
    Object.defineProperty(component, 'response', { value: response });
    expect(component.rowData()).toHaveLength(5);
    expect(component.rowData()[0]['col3'].cellValue).toBe(42.11);
    expect(component.rowData()[4]['col2'].cellValue).toBe('Other');
    expect(component.rowData()[4]['col3'].cellValue).toBe(0);
    expect(component.columnDefinitions().map(col => col.headerName)).toEqual(['Answer', 'Percentage']);
    expect(component.legendGradient()).toBeNull();
    response.set(structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]));
    expect(component.rowData()).toHaveLength(4);
    expect(component.rowData()[0]['col2'].cellValue).toBe(6);
    expect(component.columnDefinitions().map(col => col.headerName)).toEqual(['Statement', 'Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree', 'Overall', 'Average Score']);
    expect(component.legendGradient()).toBe('linear-gradient(to right, #a3445e 0%, #a3445e 15%, #18a477 55%, #0b513e 100%)');
    const recolored = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    recolored.tableConfig.rowProperties!['style-unique-for-rule-1'].shade!.color = '#123456';
    response.set(recolored);
    expect(component.legendGradient()).toContain('#123456');
    expect(component.legendGradient()).not.toContain('#a3445e');
    const unstyled = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    unstyled.tableConfig.rowProperties = {};
    response.set(unstyled);
    expect(component.legendGradient()).toBeNull();
    response.set({ type: 'grid', objects: { data: [], metadata: {} }, tableConfig: {} });
    expect(component.rowData()).toEqual([]);
    expect(component.columnDefinitions()).toEqual([]);
  });
});
