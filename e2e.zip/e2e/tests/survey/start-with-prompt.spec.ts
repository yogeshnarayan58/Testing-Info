import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory } from '../../utils/base-page-factory';
import { StartWithPromptPage, OMNISHOPPER_OFFERING_DATA_TEST_ID } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Start with a prompt', { tag: '@StartWithPrompt' }, () => {
  let basePage: BasePage;
  let promptPage: StartWithPromptPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async () => {
    if (basePage) {
      await basePage.getWebActions().closeBrowser();
    }
  });

  test('Start with a Prompt: Should display the Start with a prompt option on the survey home page', { tag: '@StartWithPrompt' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    promptPage = new StartWithPromptPage(basePage);

    await promptPage.navigateToSurvey();
    await promptPage.clickStartWithPrompt();

    const isVisible = await promptPage.isDatasetTypeSelectorVisible(0);
    assertTrue(isVisible);
  });

  test('Dataset Selection: Should select the dataset type and dataset', { tag: '@DatasetSelection' }, async () => {
    await promptPage.selectDatasetType(OMNISHOPPER_OFFERING_DATA_TEST_ID);

    const isDatasetSelectionConfirmed = await promptPage.searchAndSelectDataset(
      datasetConfig.searchTerm,
      String(DATASET_NAME)
    );
    assertTrue(
      isDatasetSelectionConfirmed,
      `Expected dataset selection to succeed for ${DATASET_NAME}`
    );

    await promptPage.applyDataset();
  });

  test('Panelist Filters: Should set dimension selections and search for panelists', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);
    await selectPanelistPage.clickSearchForPanelists();

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should select a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.click250Responses();
  });

  test('Generate Survey: Should fill the prompt and reach the Build Survey page', { tag: '@GenerateSurvey' }, async () => {
    await promptPage.fillPromptAndGenerate('Generate a few questions about product satisfaction');

    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after generating the survey from a prompt');
  });
});