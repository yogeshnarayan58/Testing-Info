import { HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { ToastService, ToastState } from '@nielseniq/athena-core';
import { EnvironmentConfig, ToastTime } from '@nielseniq/crf-discover-fe-core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { ApiService } from '../../../shared/services/api.service';
import { ValidationToastType, validationToastTime } from '../../my-assets/constants/survey-status.constant';
import {
  AiSuggestion,
  QuestionModel,
  SuggestionSeverity,
  SUGGESTION_SEVERITY,
  SURVEY_SUGGESTIONS_STATE,
  SURVEY_VALIDATION_STATE,
  SurveyAIValidationResponse,
  SurveyAIValidationState,
  SurveySuggestionState,
} from '../models/build-survey';
import { TranslateService } from '@ngx-translate/core';


type OptionField = 'options' | 'rowOptions' | 'columnOptions';

// Suggestion paths that point at an option by position, e.g. `options[2]`.
const OPTION_PATH = /^(options|rowOptions|columnOptions)\[(\d+)\]$/;

// Keyed by `<mandatory>-<optional>` bucket: 1 is singular, 2+ is plural, 0 means none.
const MANDATORY_TOAST_KEYS: Record<string, string> = {
  '1-0': 'SURVEYMOD_TM_MANDATORY_CHANGE',
  '2+-0': 'SURVEYMOD_TM_MANDATORY_CHANGES',
  '1-1': 'SURVEYMOD_TM_MANDATORY_CHANGE_OPTIONAL_CHANGE',
  '1-2+': 'SURVEYMOD_TM_MANDATORY_CHANGE_OPTIONAL_CHANGES',
  '2+-1': 'SURVEYMOD_TM_MANDATORY_CHANGES_OPTIONAL_CHANGE',
  '2+-2+': 'SURVEYMOD_TM_MANDATORY_CHANGES_OPTIONAL_CHANGES',
};

const mandatoryToastKey = (mandatory: number, optional: number): string => {
  const mandatoryBucket = mandatory === 1 ? '1' : '2+';
  const optionalBucket = optional === 0 ? '0' : optional === 1 ? '1' : '2+';
  return MANDATORY_TOAST_KEYS[`${mandatoryBucket}-${optionalBucket}`];
};

@Injectable({ providedIn: 'root' })
export class ValidationService {
  private readonly apiService = inject(ApiService);
  private readonly environment = inject(EnvironmentConfig);
  private readonly toastService = inject(ToastService);

  readonly surveyAIValidationState = signal<SurveyAIValidationState>(
    SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION
  );
  readonly surveySuggestionState = signal<SurveySuggestionState>(
    SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION
  );

  private readonly httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
  };

  private readonly translate = inject(TranslateService);

  validateSurvey(questions: QuestionModel[]): Observable<SurveyAIValidationResponse> {
    const previousValidationState = this.surveyAIValidationState();
    this.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS);
    this.showValidationToast(
      questions,
      previousValidationState === SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION
        ? ValidationToastType.VALIDATION_IN_PROGRESS
        : ValidationToastType.REVALIDATION_IN_PROGRESS
    );

    const payload = {
      survey: {
        questions: questions.map((question) => ({
          ...question,
          id: `q_${question.questionNumber}`,
          order: question.questionNumber,
        })),
      },
    };

    return this.apiService
      .post<SurveyAIValidationResponse>(
        `${this.environment.apiUrls.surveyAiEngineUrl}/validate-survey`,
        payload,
        this.httpOptions
      )
      .pipe(
        tap((response) => {
          const validatedQuestions = this.normalizeValidatedQuestions(response);
          this.updateSuggestionState(validatedQuestions, SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);
          this.surveyAIValidationState.set(
            validatedQuestions.some(question => question.reviewRequired === true) ||
              this.countSuggestions(validatedQuestions, SUGGESTION_SEVERITY.MANDATORY) > 0
              ? SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW
              : SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
          );
          this.showValidationToast(validatedQuestions);
        }),
        catchError((error) => {
          this.surveyAIValidationState.set(previousValidationState);
          return throwError(() => error);
        })
      );
  }

  normalizeValidatedQuestions(response: SurveyAIValidationResponse): QuestionModel[] {
    if (!response || !Array.isArray(response.result)) {
      throw new Error('Invalid survey validation response: result must be an array');
    }
    return response.result.map((question, index) => ({
      ...question,
      questionNumber: index + 1,
    }));
  }

  countSuggestions(questions: QuestionModel[], severity: SuggestionSeverity): number {
    return questions.reduce(
      (count, question) =>
        count +
        (question.suggestions?.filter((suggestion) => suggestion.severity === severity).length ?? 0),
      0
    );
  }

  invalidateSurveyValidation(): void {
    if (this.surveyAIValidationState() === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH) {
      this.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
      this.showValidationToast([], ValidationToastType.SURVEY_EDITED);
    }
  }

  resetValidation(): void {
    this.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
    this.surveySuggestionState.set(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);
  }

  markQuestionForReview(questions: QuestionModel[], index: number): QuestionModel[] {
    return questions.map((question, questionIndex) =>
      questionIndex === index ? { ...question, reviewRequired: true } : question
    );
  }

  applyAddOptionSuggestion(
    questions: QuestionModel[],
    questionId: string,
    suggestion: AiSuggestion
  ): QuestionModel[] {
    return questions.map((question) => {
      if (question.id !== questionId) return question;

      const current = this.findSuggestion(question, suggestion.suggestionId);
      const match = current?.fieldPath?.match(OPTION_PATH);
      if (!current || !match || !current.suggestedText?.trim()) return question;

      const [, field, indexText] = match;
      const optionIndex = Number(indexText);
      const options = [...(question[field as OptionField] ?? [])];
      const isNewOption = !options.includes(current.suggestedText);
      if (isNewOption) options.splice(optionIndex, 0, current.suggestedText);

      const remaining = question.suggestions?.filter(
        (item) => item.suggestionId !== current.suggestionId
      );
      return {
        ...question,
        [field]: options,
        suggestions: isNewOption
          ? this.reindexSuggestions(remaining, field, optionIndex, 'insert')
          : remaining,
      };
    });
  }

  rephraseSuggestion(
    questions: QuestionModel[],
    questionId: string,
    suggestion: AiSuggestion
  ): QuestionModel[] {
    return questions.map((question) => {
      if (question.id !== questionId) return question;

      const current = this.findSuggestion(question, suggestion.suggestionId);
      if (!current || !current.suggestedText?.trim()) return question;

      const { fieldPath, suggestedText, suggestionId } = current;
      if (fieldPath === 'question' || fieldPath === 'npsLeftLabel' || fieldPath === 'npsRightLabel') {
        return {
          ...question,
          [fieldPath]: suggestedText,
          suggestions: question.suggestions?.filter(
            (item) => item.suggestionId !== suggestionId
          ),
        };
      }

      const match = fieldPath?.match(OPTION_PATH);
      if (!match) return question;

      const [, field, indexText] = match;
      const optionIndex = Number(indexText);
      const options = [...(question[field as OptionField] ?? [])];
      if (optionIndex < 0 || optionIndex >= options.length) return question;

      options[optionIndex] = suggestedText;
      return {
        ...question,
        [field]: options,
        suggestions: question.suggestions?.filter(
          (item) => item.suggestionId !== suggestionId
        ),
      };
    });
  }

  dismissSuggestion(
    questions: QuestionModel[],
    questionId: string,
    suggestionId: string
  ): QuestionModel[] {
    return questions.map((question) =>
      question.id === questionId
        ? {
          ...question,
          suggestions: question.suggestions?.filter(
            (suggestion) => suggestion.suggestionId !== suggestionId
          ),
        }
        : question
    );
  }

  removeOptionSuggestion(
    questions: QuestionModel[],
    questionId: string,
    suggestion: AiSuggestion
  ): QuestionModel[] {
    return questions.map((question) => {
      if (question.id !== questionId) return question;

      const current = this.findSuggestion(question, suggestion.suggestionId);
      const match = current?.fieldPath?.match(OPTION_PATH);
      if (!current || !match) return question;

      const [, field, indexText] = match;
      const optionIndex = Number(indexText);
      const options = [...(question[field as OptionField] ?? [])];
      if (optionIndex < 0 || optionIndex >= options.length) return question;

      options.splice(optionIndex, 1);
      return {
        ...question,
        [field]: options,
        suggestions: this.reindexSuggestions(
          question.suggestions?.filter(
            (item) => item.suggestionId !== suggestion.suggestionId
          ),
          field,
          optionIndex,
          'remove'
        ),
      };
    });
  }

  syncAfterSuggestionChange(questions: QuestionModel[]): void {
    const hasMandatorySuggestions =
      this.countSuggestions(questions, SUGGESTION_SEVERITY.MANDATORY) > 0;
    const requiresRevalidation = questions.some(question => question.reviewRequired === true);
    const state = this.surveyAIValidationState();
    if (
      state === SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW ||
      state === SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
    ) {
      this.surveyAIValidationState.set(
        hasMandatorySuggestions || requiresRevalidation
          ? SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW
          : SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
      );
    }
    this.updateSuggestionState(questions, SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
  }

  private findSuggestion(question: QuestionModel, suggestionId: string): AiSuggestion | undefined {
    return question.suggestions?.find((item) => item.suggestionId === suggestionId);
  }

  private reindexSuggestions(
    suggestions: AiSuggestion[] | undefined,
    field: string,
    optionIndex: number,
    change: 'insert' | 'remove'
  ): AiSuggestion[] | undefined {
    return suggestions?.flatMap((suggestion) => {
      const fieldPathMatch = suggestion.fieldPath?.match(OPTION_PATH);
      if (!fieldPathMatch || fieldPathMatch[1] !== field) return [suggestion];

      const suggestionIndex = Number(fieldPathMatch[2]);
      const isAddOptionSuggestion = suggestion.action === 'ADD_OPTION';
      if (
        change === 'remove' &&
        !isAddOptionSuggestion &&
        suggestionIndex === optionIndex
      ) {
        return [];
      }

      const shouldShiftIndex =
        change === 'insert'
          ? isAddOptionSuggestion
            ? suggestionIndex > optionIndex
            : suggestionIndex >= optionIndex
          : suggestionIndex > optionIndex;
      if (!shouldShiftIndex) return [suggestion];

      return [
        {
          ...suggestion,
          fieldPath: `${field}[${suggestionIndex + (change === 'insert' ? 1 : -1)}]`,
        },
      ];
    });
  }

  private updateSuggestionState(
    questions: QuestionModel[],
    emptyState: SurveySuggestionState
  ): void {
    const total =
      this.countSuggestions(questions, SUGGESTION_SEVERITY.MANDATORY) +
      this.countSuggestions(questions, SUGGESTION_SEVERITY.OPTIONAL);
    this.surveySuggestionState.set(
      total === 0 ? emptyState : SURVEY_SUGGESTIONS_STATE.IN_REVIEW
    );
  }

  private showValidationToast(
    questions: QuestionModel[],
    type?: ValidationToastType,
    dismissAfter?: number
  ): void {
    const mandatoryCount = this.countSuggestions(questions, SUGGESTION_SEVERITY.MANDATORY);
    const optionalCount = this.countSuggestions(questions, SUGGESTION_SEVERITY.OPTIONAL);
    const toastType =
      type ??
      (mandatoryCount > 0
        ? ValidationToastType.MANDATORY_CHANGES
        : optionalCount > 0
          ? ValidationToastType.OPTIONAL_CHANGES
          : ValidationToastType.NO_CHANGES);

    let message = '';
    let title = '';
    let toastState: ToastState = 'info';

    switch (toastType) {
      case ValidationToastType.MANDATORY_CHANGES:
        message = this.translate.instant(
          mandatoryToastKey(mandatoryCount, optionalCount),
          { mandatory: mandatoryCount, optional: optionalCount }
        );
        title = this.translate.instant('SURVEYMOD_TT_CHANGES_NEEDED');
        toastState = 'warning';
        break;
      case ValidationToastType.OPTIONAL_CHANGES: {
        const messageKey = optionalCount === 1 ? 'SURVEYMOD_TM_OPTIONAL_CHANGE' : 'SURVEYMOD_TM_OPTIONAL_CHANGES';
        message = this.translate.instant(messageKey, { optional: optionalCount });
        title = this.translate.instant('SURVEYMOD_TT_CHANGES_RECOMMENDED');
        break;
      }
      case ValidationToastType.NO_CHANGES:
        message = this.translate.instant('SURVEYMOD_TM_READY_TOBE_PUBLISHED');
        title = this.translate.instant('SURVEYMOD_TT_VALIDATION_COMPLETE');
        toastState = 'success';
        break;
      case ValidationToastType.VALIDATION_IN_PROGRESS:
        message = this.translate.instant('SURVEYMOD_TM_VALIDATING_YOUR_SURVEY');
        title = this.translate.instant('SURVEYMOD_TT_VALIDATING_YOUR_SURVEY');
        break;
      case ValidationToastType.REVALIDATION_IN_PROGRESS:
        message = this.translate.instant('SURVEYMOD_TM_VALIDATING_YOUR_SURVEY');
        title = this.translate.instant('SURVEYMOD_TT_REVALIDATING_YOUR_SURVEY');
        break;
      case ValidationToastType.SURVEY_EDITED:
        message = this.translate.instant('SURVEYMOD_TM_SURVEY_HAS_CHANGED');
        title = this.translate.instant('SURVEYMOD_TT_REVALIDATION_NEEDED');
        break;
      case ValidationToastType.ERROR:
        message = this.translate.instant('SURVEYMOD_TM_SURVEY_COULD_NOT_BE_VALIDATED');
        title = this.translate.instant('SURVEYMOD_TT_SURVEY_NOT_VALIDATED');
        toastState = 'error';
        break;
    }

    this.toastService.InsertToast(toastState, message, {
      dismissAfter: dismissAfter ?? validationToastTime,
      size: 'large',
      containerClass: 'survey-action-toast',
      title,
    });
  }
}
