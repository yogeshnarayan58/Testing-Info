import { Routes } from '@angular/router';
import { MY_ASSETS_FOLDER_BREADCRUMB_TABS, MY_ASSETS_TABS_LIST } from './features/my-assets/constants/my-assets-tabs.constant';
import {
  redirectPublishedSurveyEditsGuard,
  redirectUnpublishedSurveyResultsGuard,
} from './shared/common/guards/published-survey-results.guard';

const loadSurveyHomepage = () =>
  import('./features/survey-home/components/survey-homepage/survey-homepage.component').then(
    ({ SurveyHomepageComponent }) => SurveyHomepageComponent
  );

const loadMyAssetsPage = () =>
  import('./features/my-assets/components/my-assets-page.component').then(
    ({ MyAssetsPageComponent }) => MyAssetsPageComponent
  );

const loadSelectPanelist = () =>
  import('./features/select-panelist/components/select-panelist.component').then(
    ({ SelectPanelistComponent }) => SelectPanelistComponent
  );

const loadBuildSurvey = () =>
  import('./features/build-survey/components/build-survey.component').then(
    ({ BuildSurveyComponent }) => BuildSurveyComponent
  );
const loadSurveyResults = () =>
  import('./features/survey-results/components/survey-results/survey-results.component').then(
    ({ SurveyResultsComponent }) => SurveyResultsComponent
  );

const loadSurveyWrapper = () =>
  import('./shared/components/crf-survey-wrapper/crf-survey-wrapper.component').then(
    ({ CrfSurveyWrapperComponent }) => CrfSurveyWrapperComponent
  );


const loadGenerateSurvey = () =>
  import('./features/survey-model-validator/components/generate-survey/generate-survey.component').then(
    ({ GenerateSurveyComponent }) => GenerateSurveyComponent
  );

// Generates the base tab routes for My Assets views.
const myAssetsTabRoutes: Routes = MY_ASSETS_TABS_LIST.map((tab) => ({
  path: tab.routePath,
  pathMatch: 'full' as const,
  loadComponent: loadMyAssetsPage,
  data: { tabId: tab.id },
}));

// Generates folder child routes per tab so folder navigation keeps tab context.
const myAssetsFolderRoutes: Routes = MY_ASSETS_TABS_LIST.filter((tab) =>
  MY_ASSETS_FOLDER_BREADCRUMB_TABS.includes(tab.id)
).map((tab) => ({
  path: `${tab.routePath}/folder/:folderId`,
  pathMatch: 'full' as const,
  loadComponent: loadMyAssetsPage,
  data: { tabId: tab.id },
}));

// Keep folder routes in the public route set used by the Landing Page host.
export const myAssetsRoutes: Routes = [...myAssetsFolderRoutes, ...myAssetsTabRoutes];

export const SURVEY_MOD_STEP_ROUTES: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'select-panelist',
  },
  {
    path: 'select-panelist',
    loadComponent: loadSelectPanelist,
  },
  {
    path: 'select-panelist/:surveyId',
    canActivate: [redirectPublishedSurveyEditsGuard],
    loadComponent: loadSelectPanelist,
  },
  {
    path: 'build-survey',
    loadComponent: loadBuildSurvey,
  },
  {
    path: 'build-survey/:surveyId',
    canActivate: [redirectPublishedSurveyEditsGuard],
    loadComponent: loadBuildSurvey,
  },
  {
    path: 'results',
    loadComponent: loadSurveyResults,
  },
  {
    path: 'results/:surveyId',
    canActivate: [redirectUnpublishedSurveyResultsGuard],
    loadComponent: loadSurveyResults,
  },
];

export const SURVEY_MOD_ROUTES: Routes = [
  {
    path: '',
    pathMatch: 'full',
    loadComponent: loadSurveyHomepage,
  },
  ...myAssetsRoutes,
  {
    path: 'model-validator',
    pathMatch: 'full',
    loadComponent: loadGenerateSurvey,
  },
  {
    path: '',
    loadComponent: loadSurveyWrapper,
    data: { flowType: 'scratch' },
    children: SURVEY_MOD_STEP_ROUTES,
  },
  {
    path: 'aiflow',
    loadComponent: loadSurveyWrapper,
    data: { flowType: 'aiflow' },
    children: SURVEY_MOD_STEP_ROUTES,
  },
];
