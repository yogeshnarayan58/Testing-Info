import { BasePage, WebActions } from "@gfk/gta";
import { CommonTestCase } from "../../pages/common-test-case/common-test-case";
import { ResourceManager } from "../../utils/resource-manager";
import { SMALL_TIMEOUT, NAVIGATION_TIMEOUT, MAX_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { getPage } from "../../utils/page-utils";
import { 
  ExportFormat, 
  ExportContent, 
  ArrangeCards, 
  EXPORT_COMPONENT_NAME 
} from "./export-types";
import * as exportResources from "./export-resources.json";

export class ExportComponent extends CommonTestCase {
  private retryCount: number = 1;

  constructor(basePage: BasePage) {
    super(basePage);
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
    this.resourceManager.registerResources(EXPORT_COMPONENT_NAME, exportResources);
  }

  /**
   * Validates export functionality for specified format
   * @param format - Export format: "Excel" or "PowerPoint" only
   * @param content - Export content: "Editable objects" or "Static images" only
   * @param arrangeCards - Card arrangement: "Separately" or "As displayed in report" only
   */
  public async validateExportFunctionality(
    format: ExportFormat, 
    content: ExportContent, 
    arrangeCards: ArrangeCards
  ): Promise<void> {

      await this.clickExportIcon();
      
      // Select export option and execute
      await this.selectExportOptions(format, content, arrangeCards);
       // Verify export success
    await this.verifyExportSuccessMessage();
    console.log("Validated export success message");
      console.log("Check if options are selected for excel/ppt when Export icon is clicked");
      
    
  }

  /**
   * Clicks the export icon to open the export dialog
   */
  public async clickExportIcon(): Promise<void> {
    try {
      console.log("Clicking export icon to open export dialog");
      await super.clickWebelement("exportIcon", EXPORT_COMPONENT_NAME);
      
      console.log("Export icon clicked successfully - export dialog should be open");
    } catch (error) {
      throw new Error(`Failed to click export icon: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Selects export format option and executes export
   * @param format - Export format: "excel" or "ppt"
   * @param staticImageExport - Whether to include static images
   */
  public async selectExportOptions(format: string, content: string, arrangeCards: string): Promise<void> {
  
      await this.selectExportFormat(format);
      await this.selectExportContent(content);
      await this.selectExportArrangeCards(arrangeCards);
    // Click export button
    await super.clickWebelement("exportButton", EXPORT_COMPONENT_NAME);
    
   
  }

   /**
   * Selects PowerPoint export option
   * @param content - Content option parameter
   * @param arrangeCards - Arrange cards parameter
   */
  public async selectExportFormat(format: string): Promise<void> {
    try {
      console.log(`Selecting ${format} export option`);
      await super.clickWebelement(format, EXPORT_COMPONENT_NAME);
    } catch (error) {
      throw new Error(`Failed to select ${format} option: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Selects export content option (e.g., static images, dynamic content)
   * @param contentOption - The name of the content option element to select
   * @param waitForElement - Whether to wait for element visibility before clicking (default: true)
   */
  public async selectExportContent(
    contentOption: string, 
    waitForElement: boolean = true
  ): Promise<void> {
    try {
      console.log(`Selecting export content option: ${contentOption}`);
      
      // Use the enhanced clickWebelement method with centralized validation
      await super.clickWebelement(contentOption, EXPORT_COMPONENT_NAME, {
        waitForElement,
        timeout: SMALL_TIMEOUT
      });
      
      console.log(`Successfully selected export content option: ${contentOption}`);
      
    } catch (error) {
      // The enhanced clickWebelement method already provides detailed error messages
      throw error;
    }
  }

  public async selectExportArrangeCards(
    arrangeCardsOption: string, 
    waitForElement: boolean = true
  ): Promise<void> {
    try {
      console.log(`Selecting export arrange cards option: ${arrangeCardsOption}`);
      
      // Use the enhanced clickWebelement method with centralized validation
      await super.clickWebelement(arrangeCardsOption, EXPORT_COMPONENT_NAME, {
        waitForElement,
        timeout: SMALL_TIMEOUT
      });
      
      console.log(`Successfully selected export content option: ${arrangeCardsOption}`);
      
    } catch (error) {
      // The enhanced clickWebelement method already provides detailed error messages
      throw error;
    }
  }

  /**
   * Selects PowerPoint export option
   * @param content - Content option parameter
   * @param arrangeCards - Arrange cards parameter
   */
  public async selectPowerPointOption(content: string, arrangeCards: string): Promise<void> {
    try {
      console.log("Selecting PowerPoint export option");
      
      // Use enhanced clickWebelement with automatic validation
      await super.clickWebelement("powerPointOption", EXPORT_COMPONENT_NAME);
      
      console.log("PowerPoint export option selected successfully");
    } catch (error) {
      throw new Error(`Failed to select PowerPoint option: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  

  /**
   * Selects Excel export option
   * @param content - Content option parameter
   * @param arrangeCards - Arrange cards parameter
   */
  public async selectExcelOption(format: string, content: string, arrangeCards: string): Promise<void> {
    try {
      console.log(`Selecting ${format} export option`);
      await super.clickWebelement(format, EXPORT_COMPONENT_NAME);
      
      console.log(`${format} export option selected successfully`);
    } catch (error) {
      throw new Error(`Failed to select ${format} option: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Verifies export success message appears
   */
  public async verifyExportSuccessMessage(): Promise<void> {
    try {
      const successMessage = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("successMessage", EXPORT_COMPONENT_NAME)
      );
      
      // Wait for success message with extended timeout
      await successMessage.waitFor(MAX_TEST_TIMEOUT);
      
      const isVisible = await successMessage.isVisible();
      if (!isVisible) {
        throw new Error("Export success message is not visible");
      }
      
      console.log("Verified export success message");
    } catch (error) {
      console.error("Failed to verify export success message");
      throw error;
    }
  }

  /**
   * Checks if export icon is visible and enabled
   */
  public async isExportIconAvailable(): Promise<boolean> {
    try {
      const exportIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("exportIcon", EXPORT_COMPONENT_NAME)
      );
      
      await exportIcon.waitFor(SMALL_TIMEOUT);
      return await exportIcon.isEnabled();
    } catch (error) {
      return false;
    }
  }

}
