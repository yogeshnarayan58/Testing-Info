import { BasePage } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { NAVIGATION_TIMEOUT, SMALL_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';
import startFromScratchPageResources from '../../locators/survey/start-from-scratch.locator.json';
import selectPanelistPageResources from '../../locators/survey/select-panelist.locator.json';
import { searchAndSelectDataset as searchAndSelectDatasetHelper } from '../common/dataset-selection.helper';

const START_FROM_SCRATCH_PAGE_COMPONENT_NAME = 'startFromScratchPage';
// Product Offering modal locators live in select-panelist.locator.json, so they are registered under their own component name.
const SELECT_PANELIST_RESOURCES_COMPONENT_NAME = 'selectPanelistPage';

export class StartFromScratchPage extends CommonPage {
  protected readonly componentName = START_FROM_SCRATCH_PAGE_COMPONENT_NAME;

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(START_FROM_SCRATCH_PAGE_COMPONENT_NAME, startFromScratchPageResources);
    this.resourceManager.registerResources(SELECT_PANELIST_RESOURCES_COMPONENT_NAME, selectPanelistPageResources);
  }

  async clickStartFromScratch(): Promise<void> {
    try {
      const startFromScratch = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('startFromScratch', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );
      await startFromScratch.waitFor(SMALL_TIMEOUT);
      await startFromScratch.click();
    } catch (error) {
      throw new Error(`Failed to click Start from scratch: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isStartFromScratchVisible(): Promise<boolean> {
    const startFromScratch = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('startFromScratch', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
    );
    await startFromScratch.waitFor(NAVIGATION_TIMEOUT);
    return await startFromScratch.isVisible();
  }

  /** Same check as isStartFromScratchVisible(), but if the tile is missing after ELEMENT_WAIT_TIMEOUT it waits for network idle and reloads once before giving up. */
  async isStartFromScratchVisibleAfterReload(): Promise<boolean> {
    return await this.isVisibleAfterOneReload('startFromScratch');
  }

  async selectProductOffering(_productOffering: string): Promise<void> {
    try {
      const productOfferingHeading = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('productOfferingHeading', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );

      const isProductOfferingScreenShown = await productOfferingHeading.isVisible().catch(() => false);
      if (!isProductOfferingScreenShown) {
        return;
      }

      await productOfferingHeading.waitFor(SMALL_TIMEOUT);

      const nextButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('nextButton', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );
      await nextButton.waitFor(SMALL_TIMEOUT);
      await nextButton.click();
    } catch (error) {
      throw new Error(`Failed to select product offering: ${error instanceof Error ? error.message : error}`);
    }
  }

  async searchAndSelectDataset(searchTerm: string, datasetLabel: string): Promise<boolean> {
    try {
      return await searchAndSelectDatasetHelper(
        this.webActionHandler,
        this.resourceManager,
        START_FROM_SCRATCH_PAGE_COMPONENT_NAME,
        searchTerm,
        datasetLabel,
        {
          datasetResourceKey: 'datasetByLabel',
          searchToggleResourceKey: 'searchToggle',
          searchInputResourceKey: 'searchInput',
        }
      );
    } catch (error) {
      throw new Error(`Failed to search and select dataset "${datasetLabel}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDatasetSelectionConfirmed(): Promise<boolean> {
    try {
      const breadcrumb = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('chooseDatasetBreadcrumb', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );
      await breadcrumb.waitFor(SMALL_TIMEOUT);
      return await breadcrumb.isVisible();
    } catch (error) {
      throw new Error(`Failed to confirm dataset selection screen: ${error instanceof Error ? error.message : error}`);
    }
  }

  async proceedToNextAfterDatasetSelection(): Promise<void> {
    try {
      const nextButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('applyButton', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );
      await nextButton.waitFor(SMALL_TIMEOUT);
      await nextButton.click();
    } catch (error) {
      throw new Error(`Failed to click Next after dataset selection: ${error instanceof Error ? error.message : error}`);
    }
  }

  async applyEntireDataset(): Promise<void> {
    try {
      const dialogElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dialogElement', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );

      const isChooseViewDialogShown = await dialogElement.isVisible().catch(() => false);
      if (!isChooseViewDialogShown) {
        return;
      }

      await dialogElement.waitFor(SMALL_TIMEOUT);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const applyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('applyButton', START_FROM_SCRATCH_PAGE_COMPONENT_NAME)
      );
      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();
    } catch (error) {
      throw new Error(`Failed to apply entire dataset: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isProductOfferingModalVisible(): Promise<boolean> {
    const modal = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('productOfferingModal', SELECT_PANELIST_RESOURCES_COMPONENT_NAME)
    );
    return modal.isVisible(SMALL_TIMEOUT);
  }

  /** Clicks Cancel in the Product Offering dialog footer (scoped by `[data-test-id='rv-dataset-selector-footer'] niq-button.btn-cancel`, not nested under the modal root). */
  async cancelProductOfferingModal(): Promise<void> {
    try {
      const cancelButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('cancelDatasetButton', SELECT_PANELIST_RESOURCES_COMPONENT_NAME)
      );
      await this.waitUntilVisible(cancelButton, 'Product Offering Cancel button', SMALL_TIMEOUT);
      await cancelButton.click();
    } catch (error) {
      throw new Error(`Failed to cancel Product Offering modal: ${error instanceof Error ? error.message : error}`);
    }
  }
}
