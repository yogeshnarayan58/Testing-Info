import { BasePage } from '@gfk/gta';
import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { config } from '../../playwright/config';
import { WebActions } from '@gfk/gta/dist/core/web/webActions';
import { getLambdaTestBuildName } from './configurationDetails';

// Store session names with timestamp as key (for reporter lookup)
export const sessionRegistry: Array<{ timestamp: number; sessionName: string; title?: string }> = [];

// Map to store session per worker - each worker runs tests sequentially
export const workerSessionMap = new Map<number, string>();

// Global current session tracker - stores the last created session
export let currentLTSession: string | null = null;

export class BasePageFactory {
  static async createBasePage(forceHeadless?: boolean): Promise<BasePage> {
    const isLambdaTest = process.env.LAMBDATEST === 'true';

    const ltUser = process.env.LAMBDATEST_USERNAME || process.env.LT_USERNAME;
    const ltAccessKey = process.env.LAMBDATEST_ACCESS_KEY || process.env.LT_ACCESS_KEY;
    const ltProject = process.env.LT_PROJECT || 'OMNI Discover';
    const ltBuildBase = process.env.LT_BUILD || 'Discover build';
    const ltBuildIdentifier =
      process.env.LT_BUILD_IDENTIFIER ||
      process.env.BUILD_NUMBER ||
      process.env.GITHUB_RUN_NUMBER ||
      undefined;
    const ltBuild = getLambdaTestBuildName(ltBuildBase, ltBuildIdentifier);

    const ltVideo = process.env.LT_VIDEO === 'false' ? false : true;
    const ltNetwork = process.env.LT_NETWORK === 'true';
    const ltConsole = process.env.LT_CONSOLE === 'true';

    let storageState: string | undefined;
    const authPath = path.resolve(process.cwd(), 'storage/auth.json');

    if (fs.existsSync(authPath)) {
      storageState = authPath;
      console.log('Auth state loaded from storage/auth.json');
    } else {
      console.log('No auth state found - login required');
    }
    if (isLambdaTest) {
      console.log('Connecting to LambdaTest cloud...');

      const timestamp = Date.now();
      const sessionName = `Test-${timestamp}`;

      const ltOptions: any = {
        platform: 'Windows 11',
        project: ltProject,
        build: ltBuild,
        name: sessionName,
        user: ltUser,
        accessKey: ltAccessKey,
        network: ltNetwork,
        video: ltVideo,
        console: ltConsole,
      };

      if (forceHeadless !== undefined) {
        ltOptions.headless = forceHeadless;
      }

      const wsEndpoint = `wss://cdp.lambdatest.com/playwright?capabilities=${encodeURIComponent(
        JSON.stringify({
          browserName: 'pw-chromium',
          browserVersion: 'latest',
          'LT:Options': ltOptions,
        })
      )}`;

      const browser = await chromium.connect(wsEndpoint);
      console.log(`Connected to LambdaTest (Session: ${sessionName})`);

      const contextOptions: any = {
        acceptDownloads: true,
        viewport: { width: 1920, height: 1080 },
      };

      if (storageState) {
        contextOptions.storageState = storageState;
      }

      const context = await browser.newContext(contextOptions);
      const page = await context.newPage();

      // Store session info for reporter/global-teardown
      try {
        const workerIndex = Number(process.env.TEST_WORKER_INDEX || 0);
        const testId =
          process.env.__CURRENT_TEST_ID__ || (global as any).__CURRENT_TEST_ID__ || null;

        const sessionDir = path.join(process.cwd(), '.lt-sessions');
        fs.mkdirSync(sessionDir, { recursive: true });

        // store in memory
        (page as any).__LT_SESSION_NAME__ = sessionName;
        sessionRegistry.push({ timestamp, sessionName });
        workerSessionMap.set(workerIndex, sessionName);
        currentLTSession = sessionName;

        // append sessions.jsonl (fallback)
        fs.appendFileSync(
          path.join(sessionDir, 'sessions.jsonl'),
          JSON.stringify({ sessionName, timestamp, workerIndex }) + '\n',
          'utf-8'
        );

        // PRIMARY (parallel safe): write per-test session file
        if (testId) {
          fs.writeFileSync(
            path.join(sessionDir, `test-${testId}.json`),
            JSON.stringify({ sessionName, timestamp, testId }),
            'utf-8'
          );
          console.log(`[LT Session] ✓ test-${testId}.json written`);
        } else {
          console.warn('[LT Session] ⚠ testId not available, using fallback sessions.jsonl');
        }

        // optional worker file
        fs.writeFileSync(
          path.join(sessionDir, `worker-${workerIndex}.json`),
          JSON.stringify({ sessionName, timestamp }),
          'utf-8'
        );

        console.log(`[LT Session] Registered session: ${sessionName} (worker: ${workerIndex})`);
      } catch (err) {
        console.warn('[LT Session] Could not store session info:', err);
      }

      // Inject into BasePage
      (BasePage as any).browser = browser;
      (BasePage as any).context = context;
      (BasePage as any).page = page;
      (BasePage as any).webActions = new WebActions(page, context);

      return new (BasePage as any)();
    }
    const browserName = config.browser ?? 'chromium';
    let browserOptions = config.browserOptions ?? {};

    if (forceHeadless !== undefined) {
      browserOptions = { ...browserOptions, headless: forceHeadless };
    }

    const contextOptions = {
      acceptDownloads: true,
      recordVideo: process.env.PWVIDEO ? { dir: 'screenshots' } : undefined,
      viewport: null,
      storageState,
    };

    return await BasePage.initializer(browserName, browserOptions, contextOptions);
  }
}