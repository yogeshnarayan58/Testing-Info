import { assert, BasePage} from "@gfk/gta";
import * as insightsPanelResources from "./insights-panel-resources.json";
import { MAX_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../pages/common-test-case/common-test-case";

const INSIGHTS_PANEL_COMPONENT_NAME  = "InsightsPanel";

export class InsightsPanel extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    // Register multiple resources for the same component
    this.resourceManager.registerResources(
      INSIGHTS_PANEL_COMPONENT_NAME ,
      insightsPanelResources
    );
  }

  /**
   * Clicks on the "Insights Icon" element.
   */
  public async clickInsightsIcon() {
    await super.clickWebelement("InsightsPanelIcon", INSIGHTS_PANEL_COMPONENT_NAME );
  }

  /**
   * Checks the visibility of the "Report Insights Title" element.
   *
   * @returns A promise that resolves to a boolean indicating whether the element is visible.
   */
  public async isReportInsightsTitleVisible(): Promise<boolean> {
    const reportInsightsTitle = await super.getWebelement("ReportInsightsTitle", INSIGHTS_PANEL_COMPONENT_NAME );
    return await reportInsightsTitle.isVisible();
  }

  /**
   * Checks the visibility of the "Report Insights Panel Close" element.
   *
   * @returns A promise that resolves to a boolean indicating whether the element is visible.
   */
  public async isReportInsightsPanelCloseIconVisible(): Promise<boolean> {
    const reportInsightsPanelClose = await super.getWebelement("ReportInsightsPanelClose", INSIGHTS_PANEL_COMPONENT_NAME );
    return await reportInsightsPanelClose.isVisible();
  }

  /**
   * Closes the Insights Panel by clicking the close icon.
   */
  public async closeInsightsPanel(): Promise<void> {
    await super.clickWebelement("ReportInsightsPanelClose", INSIGHTS_PANEL_COMPONENT_NAME );
  }

  /**
   * Retrieves the text content of the "Insights Report Title" element.
   *
   * @returns A promise that resolves to the text content of the element.
   */
  public async getInsightsReportTitle(): Promise<string> {
    const insightsReportTitle = await super.getWebelement("InsightsReportTitle", INSIGHTS_PANEL_COMPONENT_NAME );
    return await insightsReportTitle.getText();
  }

  /**
   * Retrieves the insights panel description text.
   *
   * @returns A promise that resolves to the text content of the description.
   */
  public async getInsightsPanelDescription(): Promise<string> {
    const descriptionLocator = await super.getWebelement("InsightsDescription", INSIGHTS_PANEL_COMPONENT_NAME );
    return await descriptionLocator.getText();
  }

  /**
   * Checks the visibility of the "Business Questions" title element in the Insights panel.
   *
   * @returns A promise that resolves to a boolean indicating whether the element is visible.
   */
  public async isBusinessQuestionsTitleVisible(): Promise<boolean> {
    const businessQuestionsTitle = await super.getWebelement("InsightsBusinessQuestionTitle", INSIGHTS_PANEL_COMPONENT_NAME );
    return await businessQuestionsTitle.isVisible();
  }

  /**
   * Validates the list of business questions displayed in the Insights panel.
   *
   * @param expectedQuestions - An array of expected business question strings.
   * @returns A promise that resolves to true if all questions match; otherwise, throws an assertion error.
   */
  public async validateBusinessQuestions(
    expectedQuestions: string[]
  ): Promise<void> {
    for (let index = 0; index < expectedQuestions.length; index++) {
      const expectedText = expectedQuestions[index].trim();

      // Construct the data-test-id dynamically
      const questionLocator = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(
          `BusinessQuestion_${index}`,
          INSIGHTS_PANEL_COMPONENT_NAME 
        )
      );

      // Assert that the element exists and is visible
      assert(await questionLocator.isVisible()).toBeTruthy();

      // Get the text content and compare
      const actualText = (await questionLocator.getText())?.trim() ?? "";
      assert(actualText).toBe(expectedText);
    }
  }

  /**
   * Navigates the browser to the specified URL within the given timeout.
   *
   * @param targetUrl - The full URL to navigate to.
   * @param timeoutMs - Optional maximum time to wait for navigation (in milliseconds). Defaults to MAX_TEST_TIMEOUT.
   *
   * @throws Will throw an error if navigation fails or if an invalid URL is provided.
   */
  public async navigateToUrl(
    targetUrl: string,
    timeout: number = MAX_TEST_TIMEOUT
  ): Promise<void> {
    try {
      // Log the start of navigation for debugging purposes
      console.info(`Navigating to URL: ${targetUrl}`);

      // Perform the navigation action with the specified timeout
      await super.navigateToUrl(targetUrl, timeout);

      // Log success after navigation completes
      console.info(`Navigation to ${targetUrl} completed successfully.`);
    } catch (navigationError) {
      // Log the error for troubleshooting
      console.error(`Navigation to URL failed: ${targetUrl}`, navigationError);

      // Re-throw the error to propagate failure to the caller
      throw navigationError;
    }
  }

  /**
   * Returns the base page instance.
   * @returns {BasePage} The base page instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }
}
