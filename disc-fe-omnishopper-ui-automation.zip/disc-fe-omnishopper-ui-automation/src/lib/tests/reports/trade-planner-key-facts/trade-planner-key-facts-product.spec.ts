import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import {
    findDataSetByName,
    getDimensionSelectionsByPivot,
    hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import prodTestData from "./test-data/prod-test-data.json";
import { config } from "../../../playwright/config";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Product";
test.describe.serial("trade-planner-key-facts - Product Pivot", { tag: "@Report_E2E_Flow" }, () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;
    test.beforeAll(() => {
        const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
        if (!isValidTestData) {
            console.warn('Skipping tests as the required pivot test data is not present');
        }
        test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
    });
    test(
        "Validate run report",
        { tag: "@RunReport" },
        async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);
            await dataSelector.switchPivotDropdown(pivot);
            await dataSelector.clickAdditionalPromptEllipsisIcon();
            // Get Product pivot data
            const productData = getDimensionSelectionsByPivot(pivot, reportTestData);

            await dataSelector.clickMadlibDimension("Product Universe");
            await dataSelector.setMadlibSelection(
                productData["Product Universe"]
            );
            await dataSelector.clickMadlibDimension("Products");
            await dataSelector.setMadlibSelection(
                productData["Products"]
            );
            await dataSelector.waitForMadlibStability();
            await dataSelector.clickMadlibDimension("Retailers");
            await dataSelector.setMadlibSelection(
                productData["Retailers"]
            );
            await dataSelector.waitForMadlibStability();
            await dataSelector.clickMadlibDimension("Period");
            await dataSelector.setPeriodMadlibSelection(
                productData["Period"]
            );

            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(
                productData["Geography"]
            );

            await dataSelector.clickMadlibDimension("Demographic");
            await dataSelector.setMadlibSelection(
                productData["Demographic"]
            );

            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.selectClosedDropdown(
                productData["Facts"]["selections"]
            );

            // await dataSelector.clickMadlibDimension("People");
            // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
            // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
            // for (const selection of productData["People"].selections) {
            //     await dataSelector.handlePeopleMenuOptions(selection);
            // }


            let dsBasePage = await dataSelector.getBasePage();
            commonTestCase = new CommonTestCase(dsBasePage);
            await commonTestCase.clickRunButton();
            await commonTestCase.waitForReportRunCompletion();
            console.log("Run complete in spec");
            const { newReportTitle, newUrl } =
                await commonTestCase.saveReport();
            savedReportTitle = newReportTitle;
            savedReportUrl = newUrl;
            console.log("savedReportTitle:", savedReportTitle);
            console.log("savedReportUrl:", savedReportUrl);
        }
    );
    test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
    });
    test(
        "Validate PPT export",
        { tag: "@ValidatePPTExport" },
        async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
        }
    );

    test(
        "Validate Excel export",
        { tag: "@ValidateExcelExport" },
        async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality(
                "Excel",
                "Editable objects",
                "Separately"
            );
        }
    );
});