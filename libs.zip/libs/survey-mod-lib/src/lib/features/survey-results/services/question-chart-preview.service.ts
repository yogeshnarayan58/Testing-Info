import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { QuestionTypes } from '../../build-survey/models/build-survey';
import type { GridResponse, QuestionChartPreview } from '../models/question-result';
import { RESULTS_DASHBOARD_CHART_TYPE_VALUES } from '../models/survey-results';
import { HEAT_GRID_PREVIEW_RESPONSE, NORMAL_GRID_PREVIEW_RESPONSE, NPS_COLUMN_CHART_RESPONSE, NPS_GRID_PREVIEW_RESPONSE, NPS_PIE_CHART_RESPONSE, SURVEY_CHART_RESPONSES } from '../constants/survey-results-preview';

@Injectable({ providedIn: 'root' })
export class QuestionChartPreviewService {

  // Table data is independent of chart data.
  loadGrid(questionType?: string): Observable<GridResponse> {
    const response = questionType === QuestionTypes.NetPromoterScore
      ? NPS_GRID_PREVIEW_RESPONSE
      : NORMAL_GRID_PREVIEW_RESPONSE;
    return of(structuredClone(response.components[0]));
  }

  // Prepare the selected chart with sample data.
  load(selection: string, questionType?: string): Observable<QuestionChartPreview> {
    if (selection === 'heatmap') {
      const gridResponse = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
      return of({ configs: [], properties: {}, data: gridResponse.objects.data, metadata: gridResponse.objects.metadata, gridResponse });
    }
    const isNpsPie = selection === RESULTS_DASHBOARD_CHART_TYPE_VALUES.pie && questionType === QuestionTypes.NetPromoterScore;
    const isNpsColumn = selection === RESULTS_DASHBOARD_CHART_TYPE_VALUES.column && questionType === QuestionTypes.NetPromoterScore;
    const sample = isNpsPie
      ? NPS_PIE_CHART_RESPONSE
      : isNpsColumn ? NPS_COLUMN_CHART_RESPONSE : SURVEY_CHART_RESPONSES[selection];
    const response = sample?.data[0]?.components[0];
    if (!response) {
      return of({ configs: [], properties: {}, data: [], metadata: {} });
    }
    const preview = structuredClone({
      configs: response.chartConfigs,
      properties: response.chartProperty,
      data: response.objects.data,
      metadata: response.objects.metadata,
    });
    return of(preview);
  }
}
