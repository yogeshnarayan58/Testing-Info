#!/bin/bash

ENVIRONMENT=$1
TEST_TAGS=$2
DATASET=$3
BUILD_TRIGGER_BY=$4
BUILD_URL=$5
BRANCH=$6
BROWSER=$7
EMAILFLAG=$8
PARALLELCOUNT=$9
REPORTS=${10}
shift 10
ARTIFACT_URL=$1
# Build Test Summary Table
RECIPIENT_EMAIL="Jayaseelan.Selvaraj@nielseniq.com Muniyasamy.N@nielseniq.com Vasanth.Regupathy@nielseniq.com Dhanubala.A@nielseniq.com Bhoomika.N@nielseniq.com Shailesh.Rajaram@nielseniq.com Bala.Kumaran@nielseniq.com penki.alekhya@encora.com Chandravadana.S@coforge.com Vibha.Sahu.consultant@nielseniq.com Kanamarlapudi.Amulya@nielseniq.com Nivediitha.S@nielseniq.com Sithika.MohamedHazzali@nielseniq.com Vivek.x.Kumar.consultant@nielseniq.com"
# Try to read from test-summary.env first (created by workflow)
summary_file="test-summary.env"
results_file="playwright-report/test-results.json"

if [[ -f "$summary_file" ]]; then
  # Read from test-summary.env (Allure-based summary from workflow)
  source "$summary_file"
  total=$TOTAL
  passed=$PASSED
  failed=$FAILED
  skipped=$SKIPPED
  
  if [[ "$total" -gt 0 ]]; then
    pass_percent=$(awk "BEGIN {printf \"%.2f\", (${passed}/${total})*100}")
  else
    pass_percent="0.00"
  fi
elif [[ -f "$results_file" ]]; then
  # Fallback: Read from playwright-report (old method)
  total=$(jq '[.suites[].suites[].specs[].tests[]] | length' "$results_file")
  passed=$(jq '[.suites[].suites[].specs[].tests[] | select(.results[-1].status == "passed")] | length' "$results_file")
  failed=$(jq '[.suites[].suites[].specs[].tests[] | select(.results[-1].status == "failed" or .results[-1].status == "timedOut" or .results[-1].status == "unexpected") ] | length' "$results_file")
  skipped=$(jq '[.suites[].suites[].specs[].tests[] | select(.results[-1].status == "skipped")] | length' "$results_file")

  if [[ "$total" -gt 0 ]]; then
    pass_percent=$(awk "BEGIN {printf \"%.2f\", (${passed}/${total})*100}")
  else
    pass_percent="0.00"
  fi
else
  # No test results found - set defaults
  total=0
  passed=0
  failed=0
  skipped=0
  pass_percent="0.00"
fi

# Calculate pass percentage color
pass_percent=$(echo "$pass_percent" | xargs)
if (( $(echo "$pass_percent >= 90" | bc -l) )); then
  percent_color="#28a745"       # green
  percent_text_color="white"
elif (( $(echo "$pass_percent >= 70" | bc -l) )); then
  percent_color="#ffc107"       # amber/yellow
  percent_text_color="black"
else
  percent_color="#dc3545"       # red
  percent_text_color="white"
fi

SUMMARY_TABLE="<table border='1' cellpadding='3' cellspacing='2' style='border-collapse: collapse; width: 60%; border: 1px solid black; font-family: Arial, sans-serif; font-size: 14px;'>
              <thead>
                <tr>
                  <th colspan='2' style='padding: 8px; text-align: center; font-weight: bold; background-color: #007bff; color: white;'>Test Execution Summary</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                    <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Total Tests</b></td>
                    <td style='background-color: #6c757d; color: white; padding: 5px; border: 1px solid black; font-weight: bold;'>${total}</td>
                  </tr>
                  <tr>
                    <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Passed</b></td>
                    <td style='background-color: #28a745; color: white; padding: 5px; border: 1px solid black; font-weight: bold;'>${passed}</td>
                  </tr>
                  <tr>
                    <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Failed</b></td>
                    <td style='background-color: #dc3545; color: white; padding: 5px; border: 1px solid black; font-weight: bold;'>${failed}</td>
                  </tr>
                  <tr>
                    <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Skipped</b></td>
                    <td style='background-color: #ffc107; color: black; padding: 5px; border: 1px solid black; font-weight: bold;'>${skipped}</td>
                  </tr>
                  <tr>
                    <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Pass Percentage</b></td>
                    <td style='background-color: ${percent_color}; color: ${percent_text_color}; padding: 5px; border: 1px solid black; font-weight: bold;'>${pass_percent}%</td>
                  </tr>
                </tbody>
              </table>"


# Construct the HTML table for project/environment details
ENV_TABLE="<table border='1' cellpadding='3' cellspacing='2' style='border-collapse: collapse; width: 60%; border: 1px solid black;'>
            <thead>
              <tr>
                <th colspan='2' style='padding: 8px; text-align: center; font-weight: bold; background-color: #007bff; color: white;'>Project & Environment Details</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Environment</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${ENVIRONMENT}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Data Set</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${DATASET}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Build Triggered By</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${BUILD_TRIGGER_BY}</td>
              </tr>
              <tr>
                  <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Build URL</b></td>
                  <td style='padding: 5px; border: 1px solid black;'>
                      <a href='${BUILD_URL}' style='color: #1E90FF; text-decoration: none;' target='_blank'>Build URL</a>
                  </td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Branch</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${BRANCH}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Browser</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${BROWSER}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Email Flag</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${EMAILFLAG}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Parallel Count</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${PARALLELCOUNT}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Reports</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${REPORTS}</td>
              </tr>
              <tr>
                <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Test Tags</b></td>
                <td style='padding: 5px; border: 1px solid black;'>${TEST_TAGS}</td>
              </tr>
              <tr>
                  <td style='background-color: #333333; color: white; padding: 5px; border: 1px solid black;'><b>Allure report</b></td>
                  <td style='padding: 5px; border: 1px solid black;'>
                      <a href='${ARTIFACT_URL}' style='color: #1E90FF; text-decoration: none;' target='_blank'>Download Link</a>
                  </td>
              </tr>
            </tbody>
          </table>"

EMAIL_BODY=$(cat <<EOF
<html>
<body>
  <p>Hi Team,</p>
  <p>Automation Test Execution has been Completed with the following details:</p>
  ${SUMMARY_TABLE}
  ${ENV_TABLE}
  <p>Note: Test results are available in the above link. Please download and open the Html report to view the detailed results.</p>
  <p>Thanks & Regards,<br>Discover OMNI Team</p>
</body>
</html>
EOF
)
# Send the email using mutt
echo "$EMAIL_BODY" | mutt \
  -e "set content_type=text/html" \
  -s "OMNI Test Execution Completed - ${ENVIRONMENT} | $(echo ${GITHUB_REF} | sed 's/refs\/heads\///') | Build #${GITHUB_RUN_NUMBER}" \
  -- ${RECIPIENT_EMAIL}
# Check if the email was sent successfully
if [ $? -ne 0 ]; then
  echo "Error: Failed to send email!"
  exit 1
fi
