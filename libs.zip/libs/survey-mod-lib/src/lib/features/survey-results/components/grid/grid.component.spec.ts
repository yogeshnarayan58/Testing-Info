﻿import { signal } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { afterEach, describe, expect, it, vi } from 'vitest';
import type { GridApi, GridReadyEvent, GridSizeChangedEvent } from 'ag-grid-community';
import { GridComponent } from './grid.component';
import { HEAT_GRID_PREVIEW_RESPONSE, NORMAL_GRID_PREVIEW_RESPONSE } from '../../constants/survey-results-preview';
import type { GridResponse } from '../../models/question-result';
import { SetFilterModule } from 'ag-grid-enterprise';

describe('GridComponent', () => {
  afterEach(() => TestBed.resetTestingModule());
  it.each([
    { preview: NORMAL_GRID_PREVIEW_RESPONSE, limit: 6 },
    { preview: HEAT_GRID_PREVIEW_RESPONSE, limit: 10 },
  ])('scrolls after $limit rows without removing data', ({ preview, limit }) => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    const response = signal<GridResponse>(structuredClone(preview.components[0]));
    const sampleRow = response().objects.data[1];
    response().objects.data = [response().objects.data[0], ...Array.from({ length: 15 }, () => structuredClone(sampleRow))];
    Object.defineProperty(component, 'response', { value: response });
    Object.defineProperty(component, 'isHeatGrid', { value: signal(preview === HEAT_GRID_PREVIEW_RESPONSE) });
    expect(component.visibleRowLimit()).toBe(limit);
    expect(component.hasScrollableRows()).toBe(true);
    expect(component.gridHeight()).toBe(limit * 40 + 42);
    expect(component.rowData()).toHaveLength(15);
    const shorter = structuredClone(response());
    shorter.objects.data = shorter.objects.data.slice(0, limit + 1);
    response.set(shorter);
    expect(component.hasScrollableRows()).toBe(false);
    expect(component.gridHeight()).toBeNull();
    shorter.objects.data = shorter.objects.data.slice(0, limit);
    response.set(structuredClone(shorter));
    expect(component.hasScrollableRows()).toBe(false);
    expect(component.gridHeight()).toBeNull();
  });
  it('keeps explicit heat-grid behavior without style IDs or shading', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    const response = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.tableConfig.rowProperties = {};
    response.objects.data.forEach(row => Object.values(row).forEach(cell => delete cell.styleId));
    Object.defineProperty(component, 'isHeatGrid', { value: signal(true) });
    Object.defineProperty(component, 'response', { value: signal(response) });
    expect(component.legendGradient()).toBeNull();
    expect(component.isHeatGrid()).toBe(true);
    expect(component.visibleRowLimit()).toBe(10);
    expect(component.columnDefinitions()[0]).toMatchObject({ pinned: 'left', maxWidth: 330 });
    expect(component.defaultColDef.minWidth).toBe(110);
  });

  it('defaults to normal-grid behavior even when the data contains style IDs', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    Object.defineProperty(component, 'response', { value: signal(structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0])) });
    expect(component.isHeatGrid()).toBe(false);
    expect(component.visibleRowLimit()).toBe(6);
    expect(component.columnDefinitions()[0]).toMatchObject({ maxWidth: undefined, lockPinned: false });
  });

  it('unpins in a narrow viewport and pins again when the second column fits', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    Object.defineProperty(component, 'response', { value: signal(structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0])) });
    Object.defineProperty(component, 'isHeatGrid', { value: signal(true) });
    let pinned: 'left' | null = 'left';
    const first = { getActualWidth: () => 160, getPinned: () => pinned };
    const second = { getMinWidth: () => 110 };
    const setColumnsPinned = vi.fn((_: unknown, value: 'left' | null) => { pinned = value; });
    const api = { getColumns: () => [first, second], setColumnsPinned };
    component.onGridSizeChanged({ api, clientHeight: 0, clientWidth: 200 } as unknown as GridSizeChangedEvent);
    expect(setColumnsPinned).toHaveBeenLastCalledWith([first], null);
    component.onGridSizeChanged({ api, clientHeight: 0, clientWidth: 500 } as unknown as GridSizeChangedEvent);
    expect(setColumnsPinned).toHaveBeenLastCalledWith([first], 'left');
    component.onGridSizeChanged({ api, clientHeight: 0, clientWidth: 600 } as unknown as GridSizeChangedEvent);
    expect(setColumnsPinned).toHaveBeenCalledTimes(2);
  });

  it('accounts for header and scrollbar space using the public viewport API', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    const response = structuredClone(NORMAL_GRID_PREVIEW_RESPONSE.components[0]);
    response.objects.data = [response.objects.data[0], ...Array.from({ length: 15 }, () => structuredClone(response.objects.data[1]))];
    Object.defineProperty(component, 'response', { value: signal(response) });
    const getVerticalPixelRange = vi.fn().mockReturnValue({ top: 100, bottom: 284 });
    const api = { getVerticalPixelRange } as unknown as GridApi;
    component.updateGridHeight(api, 282);
    expect(component.gridHeight()).toBe(338);
    getVerticalPixelRange.mockReturnValue({ top: 100, bottom: 316 });
    component.updateGridHeight(api, 338);
    expect(component.gridHeight()).toBe(362);
  });

  it('closes menus on outside scroll, preserves popup scrolling, and removes the listener on destroy', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    const document = TestBed.inject(DOCUMENT);
    const hidePopupMenu = vi.fn();
    component.onGridReady({ api: { hidePopupMenu } } as unknown as GridReadyEvent);
    const popup = document.createElement('div');
    popup.className = 'ag-popup';
    const list = document.createElement('div');
    popup.appendChild(list);
    document.body.appendChild(popup);
    try {
      list.dispatchEvent(new Event('scroll'));
      expect(hidePopupMenu).not.toHaveBeenCalled();
      document.dispatchEvent(new Event('scroll'));
      expect(hidePopupMenu).toHaveBeenCalledTimes(1);
      document.body.dispatchEvent(new Event('scroll'));
      expect(hidePopupMenu).toHaveBeenCalledTimes(2);
      TestBed.resetTestingModule();
      document.dispatchEvent(new Event('scroll'));
      expect(hidePopupMenu).toHaveBeenCalledTimes(2);
    } finally {
      popup.remove();
    }
  });
  it('attaches popups to the document body outside the grid container', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    expect(component.popupParent).toBe(TestBed.inject(DOCUMENT).body);
  });
  it('exposes the values filter tab with its required module', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    expect(component.defaultColDef.menuTabs).toEqual(['generalMenuTab', 'filterMenuTab', 'columnsMenuTab']);
    expect(component.gridModules).toContain(SetFilterModule);
  });
  it('uses the same renderer for independent normal and heat responses', () => {
    const component = TestBed.runInInjectionContext(() => new GridComponent());
    const response = signal<GridResponse>(structuredClone(NORMAL_GRID_PREVIEW_RESPONSE.components[0]));
    Object.defineProperty(component, 'response', { value: response });
    expect(component.rowData()).toHaveLength(5);
    expect(component.rowData()[0]['col3'].cellValue).toBe(42.11);
    expect(component.rowData()[4]['col2'].cellValue).toBe('Other');
    expect(component.rowData()[4]['col3'].cellValue).toBe(0);
    expect(component.columnDefinitions().map(col => col.headerName)).toEqual(['Answer', 'Percentage']);
    expect(component.legendGradient()).toBeNull();
    response.set(structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]));
    expect(component.rowData()).toHaveLength(4);
    expect(component.rowData()[0]['col2'].cellValue).toBe(6);
    expect(component.columnDefinitions().map(col => col.headerName)).toEqual(['Statement', 'Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree', 'Overall', 'Average Score']);
    expect(component.legendGradient()).toBe('linear-gradient(to right, #a3445e 0%, #a3445e 15%, #18a477 55%, #0b513e 100%)');
    const recolored = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    recolored.tableConfig.rowProperties!['style-unique-for-rule-1'].shade!.color = '#123456';
    response.set(recolored);
    expect(component.legendGradient()).toContain('#123456');
    expect(component.legendGradient()).not.toContain('#a3445e');
    const unstyled = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    unstyled.tableConfig.rowProperties = {};
    response.set(unstyled);
    expect(component.legendGradient()).toBeNull();
    response.set({ type: 'grid', objects: { data: [], metadata: {} }, tableConfig: {} });
    expect(component.rowData()).toEqual([]);
    expect(component.columnDefinitions()).toEqual([]);
  });
});
