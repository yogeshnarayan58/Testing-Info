import { inject, Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { Observable } from 'rxjs';
import {
  ChoiceQuestionTypes,
  GenerateSurveyPayload,
  QuestionModel,
  QuestionType,
  QuestionTypes,
  ScaleQuestionTypes,
} from '../../build-survey/models/build-survey';
import {
  GenerateAndValidateSurveyPayload,
  GenerateAndValidateSurveyResponse,
  GeneratedQuestionsResponse,
  SurveyModelValidatorPrompts,
  SURVEY_MODEL_VALIDATOR_MIN_CHOICE_OPTIONS,
  ValidateSurveyPayload,
  ValidateSurveyResponse,
  ValidationIssue,
  ValidationResult,
} from '../models/survey-model-validator.model';
import { ApiService } from '../../../shared/services/api.service';


@Injectable({ providedIn: 'root' })
export class SurveyModelValidatorService {
  private readonly api = inject(ApiService);
  private readonly environment = inject(EnvironmentConfig);
  private readonly aiApiHttpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
  };

  extractPrompts(): Observable<SurveyModelValidatorPrompts> {
    const url = `${this.environment.apiUrls.surveyAiEngineUrl}/utils/extract-prompts`;
    return this.api.get<SurveyModelValidatorPrompts>(url);
  }

  generateQuestions(payload: GenerateSurveyPayload): Observable<GeneratedQuestionsResponse> {
    return this.api.post<GeneratedQuestionsResponse>(
      `${this.environment.apiUrls.surveyAiEngineUrl}/utils/generate-questions-with-prompts`,
      payload,
      this.aiApiHttpOptions,
    );
  }

  generateAndValidateSurvey(payload: GenerateAndValidateSurveyPayload): Observable<GenerateAndValidateSurveyResponse> {
    return this.api.post<GenerateAndValidateSurveyResponse>(
      `${this.environment.apiUrls.surveyAiEngineUrl}/utils/generate-and-validate-survey`,
      payload,
      this.aiApiHttpOptions,
    );
  }

  validateSurveyWithPrompt(payload: ValidateSurveyPayload): Observable<ValidateSurveyResponse> {
    return this.api.post<ValidateSurveyResponse>(
      `${this.environment.apiUrls.surveyAiEngineUrl}/utils/validate-questions-using-prompt`,
      payload,
      this.aiApiHttpOptions,
    );
  }

  validateQuestions(questions: QuestionModel[] | null | undefined): ValidationResult {
    const issues: ValidationIssue[] = [];
    const list = questions ?? [];

    if (list.length === 0) {
      issues.push({
        questionIndex: -1,
        field: 'questions',
        message: 'No questions were returned by the generator.',
      });
    }

    list.forEach((question, index) => this.validateQuestion(question, index, issues));

    return {
      valid: issues.length === 0,
      issueCount: issues.length,
      issues,
    };
  }

  private validateQuestion(question: QuestionModel, index: number, issues: ValidationIssue[]): void {
    if (!question?.question?.trim()) {
      issues.push({ questionIndex: index, field: 'question', message: 'Question text is required.' });
    }

    if (!question?.type) {
      issues.push({ questionIndex: index, field: 'type', message: 'Question type is required.' });
    }

    if (typeof question?.isRequired !== 'boolean') {
      issues.push({ questionIndex: index, field: 'isRequired', message: 'isRequired flag must be a boolean.' });
    }

    const type = question?.type as QuestionType | undefined;

    if (type && ChoiceQuestionTypes.includes(type)) {
      if (!question.options || question.options.length < SURVEY_MODEL_VALIDATOR_MIN_CHOICE_OPTIONS) {
        issues.push({
          questionIndex: index,
          field: 'options',
          message: `Choice questions need at least ${SURVEY_MODEL_VALIDATOR_MIN_CHOICE_OPTIONS} options.`,
        });
      }
    }

    if (type && ScaleQuestionTypes.includes(type)) {
      if (!question.rowOptions || question.rowOptions.length === 0) {
        issues.push({ questionIndex: index, field: 'rowOptions', message: 'Scale questions need row options.' });
      }
      if (!question.columnOptions || question.columnOptions.length === 0) {
        issues.push({ questionIndex: index, field: 'columnOptions', message: 'Scale questions need column options.' });
      }
    }

    if (type === QuestionTypes.NetPromoterScore) {
      if (!question.npsLeftLabel?.trim() || !question.npsRightLabel?.trim()) {
        issues.push({
          questionIndex: index,
          field: 'npsLabels',
          message: 'Net Promoter Score questions need both left and right labels.',
        });
      }
    }
  }
}
