import { ElementRef, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it } from 'vitest';
import { SuggestionTag } from '../../models/build-survey';
import { BaseQuestionEditorDirective } from './base-question-editor.directive';

class TestQuestionEditorDirective extends BaseQuestionEditorDirective {
  get isReadonlyEditing(): boolean {
    return this.isReadonlyBlockEditing;
  }
}

describe('BaseQuestionEditorDirective', () => {
  const createDirective = () => TestBed.runInInjectionContext(() =>
    new TestQuestionEditorDirective(new ElementRef(document.createElement('div'))),
  );

  it('starts in edit mode', () => {
    const directive = createDirective();

    expect(directive.isEditingMode).toBe(true);
  });

  it('enables readonly block editing when allowed', () => {
    const directive = createDirective();
    directive.mode = (() => 'readonly') as typeof directive.mode;

    directive.enableReadonlyBlockEdit();

    expect(directive.isReadonlyEditing).toBe(true);
    expect(directive.isEditingMode).toBe(true);
  });

  it('does not enable readonly editing in preview mode', () => {
    const directive = createDirective();
    directive.mode = (() => 'readonly') as typeof directive.mode;
    directive.isPreview = (() => true) as typeof directive.isPreview;

    directive.enableReadonlyBlockEdit();

    expect(directive.isReadonlyEditing).toBe(false);
  });

  it('closes readonly editing after an outside click', () => {
    const element = document.createElement('div');
    const directive = TestBed.runInInjectionContext(() =>
      new TestQuestionEditorDirective(new ElementRef(element)),
    );
    directive.mode = (() => 'readonly') as typeof directive.mode;
    directive.enableReadonlyBlockEdit();

    directive.onDocumentClick(new MouseEvent('click'));

    expect(directive.isReadonlyEditing).toBe(false);
  });

  it('ignores document clicks when readonly editing is inactive', () => {
    const directive = createDirective();

    directive.onDocumentClick(new MouseEvent('click'));

    expect(directive.isReadonlyEditing).toBe(false);
  });

  it('keeps readonly editing open for an inside click', () => {
    const element = document.createElement('div');
    const child = document.createElement('span');
    element.appendChild(child);
    const directive = TestBed.runInInjectionContext(() =>
      new TestQuestionEditorDirective(new ElementRef(element)),
    );
    directive.mode = (() => 'readonly') as typeof directive.mode;
    directive.enableReadonlyBlockEdit();

    const event = new MouseEvent('click', { bubbles: true });
    Object.defineProperty(event, 'target', { value: child });
    directive.onDocumentClick(event);

    expect(directive.isReadonlyEditing).toBe(true);
  });

  it('resets readonly editing when mode changes to readonly', () => {
    const directive = createDirective();
    directive.mode = (() => 'readonly') as typeof directive.mode;
    directive.enableReadonlyBlockEdit();

    directive.ngOnChanges({
      mode: {
        currentValue: 'readonly',
        previousValue: 'edit',
        firstChange: false,
        isFirstChange: () => false,
      },
    });

    expect(directive.isReadonlyEditing).toBe(false);
  });

  it('does not reset readonly editing when mode changes to a non-readonly value', () => {
    const directive = createDirective();
    directive.mode = (() => 'readonly') as typeof directive.mode;
    directive.enableReadonlyBlockEdit();

    directive.ngOnChanges({
      mode: {
        currentValue: 'edit',
        previousValue: 'readonly',
        firstChange: false,
        isFirstChange: () => false,
      },
    });

    expect(directive.isReadonlyEditing).toBe(true);
  });

  describe('hasSuggestions computed signal', () => {
    const createWithCounts = (initial: SuggestionTag | null) => {
      const directive = createDirective();
      const counts = signal<SuggestionTag | null>(initial);
      directive.suggestionCounts = counts as unknown as typeof directive.suggestionCounts;
      return { directive, counts };
    };

    it('is false by default (suggestionCounts is null)', () => {
      expect(createDirective().hasSuggestions()).toBe(false);
    });

    it('is false when suggestionCounts is null', () => {
      expect(createWithCounts(null).directive.hasSuggestions()).toBe(false);
    });

    it('is false when both counts are 0', () => {
      expect(createWithCounts({ mandatoryCount: 0, optionalCount: 0 }).directive.hasSuggestions()).toBe(false);
    });

    it('is true when only mandatoryCount is greater than 0', () => {
      expect(createWithCounts({ mandatoryCount: 2, optionalCount: 0 }).directive.hasSuggestions()).toBe(true);
    });

    it('is true when only optionalCount is greater than 0', () => {
      expect(createWithCounts({ mandatoryCount: 0, optionalCount: 3 }).directive.hasSuggestions()).toBe(true);
    });

    it('is true when both counts are greater than 0', () => {
      expect(createWithCounts({ mandatoryCount: 1, optionalCount: 1 }).directive.hasSuggestions()).toBe(true);
    });

    it('is false for negative counts', () => {
      expect(createWithCounts({ mandatoryCount: -1, optionalCount: -5 }).directive.hasSuggestions()).toBe(false);
    });

    it('is true when a negative count is paired with a positive count', () => {
      expect(createWithCounts({ mandatoryCount: -1, optionalCount: 2 }).directive.hasSuggestions()).toBe(true);
    });

    it('recomputes when suggestionCounts changes', () => {
      const { directive, counts } = createWithCounts(null);
      expect(directive.hasSuggestions()).toBe(false);

      counts.set({ mandatoryCount: 1, optionalCount: 0 });
      expect(directive.hasSuggestions()).toBe(true);

      counts.set({ mandatoryCount: 0, optionalCount: 0 });
      expect(directive.hasSuggestions()).toBe(false);

      counts.set(null);
      expect(directive.hasSuggestions()).toBe(false);
    });
  });

  describe('input bindings', () => {
    it('has default values for all inputs', () => {
      const directive = createDirective();

      expect(directive.type()).toBe('');
      expect(directive.mode()).toBe('edit');
      expect(directive.isPreview()).toBe(false);
      expect(directive.isInlineAdd()).toBe(false);
      expect(directive.questionNumber()).toBe(1);
      expect(directive.index()).toBe(0);
      expect(directive.isActive()).toBe(true);
      expect(directive.activeField()).toBe(null);
      expect(directive.showSuggestionTags()).toBe(false);
      expect(directive.suggestionCounts()).toBe(null);
    });
  });
});
