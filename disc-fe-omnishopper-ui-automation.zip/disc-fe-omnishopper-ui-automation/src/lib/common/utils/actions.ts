import { Locator } from "@playwright/test";
import { getLocator } from "./locator-utils";
import { STANDARD_TIMEOUT } from "../../constants/time-out-constants";
import { getPage } from "./page-utils";
import { LOADSTATE } from "../../../../playwright.config";
import { ClickOptions, FillOptions, NavigationOptions, WaitForLoadStateOptions } from "../../constants/optional-parameter-types";

/**
 * Fills a specified element with a value.
 * @param {string | Locator} input - The element to fill.
 * @param {string} value - The value to fill the element with.
 * @param {FillOptions} options - The fill options.
 */
export async function fill(input: string | Locator, value: string, options?: FillOptions): Promise<void> {
    const locator = getLocator(input);
    await locator.fill(value, options);
  }

/**
 * Clicks on a specified element and waits for navigation.
 * @param {string | Locator} input - The element to click on.
 * @param {ClickOptions} options - The click options.
 */
export async function clickAndNavigate(input: string | Locator, options?: ClickOptions): Promise<void> {
    const timeout = options?.timeout || STANDARD_TIMEOUT;
    await Promise.all([click(input, options), getPage().waitForEvent('framenavigated', { timeout: timeout })]);
    await getPage().waitForLoadState(options?.loadState || LOADSTATE, {
      timeout: timeout
    });
  }

/**
 * Clicks on a specified element.
 * @param {string | Locator} input - The element to click on.
 * @param {ClickOptions} options - The click options.
 */
export async function click(input: string | Locator, options?: ClickOptions): Promise<void> {
    const locator = getLocator(input);
    await locator.click(options ? options : { timeout: STANDARD_TIMEOUT });
  }


  /**
 * Waits for a specific page load state.
 * @param {NavigationOptions} options - The navigation options.
 */
export async function waitForPageLoadState(options?: NavigationOptions): Promise<void> {
  let waitUntil: WaitForLoadStateOptions = LOADSTATE;

  if (options?.waitUntil && options.waitUntil !== 'commit') {
    waitUntil = options.waitUntil;
  }

  await getPage().waitForLoadState(waitUntil);
}