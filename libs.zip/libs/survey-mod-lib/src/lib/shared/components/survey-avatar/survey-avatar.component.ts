import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { IconModule, TooltipModule } from '@nielseniq/athena-core';

@Component({
  selector: 'survey-avatar',
  standalone: true,
  imports: [IconModule, TooltipModule],
  templateUrl: './survey-avatar.component.html',
  styleUrl: './survey-avatar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyAvatarComponent {
  readonly name = input.required<string>();
  readonly isGroup = input(false);
  readonly initials = computed(() => this.name().trim().split(/\s+/).slice(0, 2)
    .map((part) => part.charAt(0)).join('').toUpperCase());
}