import { ReportSpecObject, RequestInstance } from '@nielsen/crf-common';
import { SURVEY_PAYLOAD_DEFAULTS } from '../../build-survey/models/build-survey';

export interface ReportPayloadAttributes {
  reportName: string;
  reportType: string;
  workFlow: string;
  assetType: string;
  cardSource: string;
  cardType: string;
}

export interface SurveyPanelistReportPayload {
  attributes: ReportPayloadAttributes;
  reportSpec: ReportSpecObject;
  requestInstance: RequestInstance;
  jobId: string | null;
  isPersistedReport: boolean;
  ignoreLink: boolean;
  reportType: 'SURVEY_PANELISTS';
}

export interface SurveyPanelistReportPayloadOptions {
  jobId?: string | null;
  reportSpec?: ReportSpecObject | null;
  requestInstance?: RequestInstance | null;
}

export const SURVEY_PANELIST_REPORT_DEFAULT_ATTRIBUTES: ReportPayloadAttributes = {
  reportName: SURVEY_PAYLOAD_DEFAULTS.untitledName,
  reportType: 'Table Builder',
  workFlow: 'Report',
  assetType: 'REPORT',
  cardSource: 'DISCOVERREPORT',
  cardType: 'ADVANCED_GRID',
};

export function createSurveyPanelistReportPayload(options: SurveyPanelistReportPayloadOptions = {}): SurveyPanelistReportPayload {
  const {
    jobId = null,
    reportSpec = {},
    requestInstance = {},
  } = options;

  return {
    attributes: { ...SURVEY_PANELIST_REPORT_DEFAULT_ATTRIBUTES },
    reportSpec: { ...(reportSpec as object) } as ReportSpecObject,
    requestInstance: { ...(requestInstance as object) } as RequestInstance,
    jobId,
    isPersistedReport: false,
    ignoreLink: true,
    reportType: 'SURVEY_PANELISTS',
  };
}
