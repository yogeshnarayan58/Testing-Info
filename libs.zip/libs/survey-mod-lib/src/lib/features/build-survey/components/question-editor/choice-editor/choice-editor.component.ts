import { Component, computed, ElementRef, model, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ButtonModule,
  CheckboxModule,
  IconModule,
  RadioButtonModule,
  TextFieldModule,
  ToggleModule,
  TooltipModule,
} from '@nielseniq/athena-core';
import { BaseQuestionEditorDirective } from '../base-question-editor.directive';
import { SuggestionTagsComponent } from '../suggestion-tags/suggestion-tags.component';
import { MAXIMUM_OPTIONS_ALLOWED } from '../../../models/build-survey';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-choice-editor',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    CheckboxModule,
    IconModule,
    RadioButtonModule,
    TextFieldModule,
    ToggleModule,
    TooltipModule,
    SuggestionTagsComponent,
    TranslateModule
  ],
  templateUrl: './choice-editor.component.html',
  styleUrls: ['./choice-editor.component.scss']
})
export class ChoiceEditorComponent extends BaseQuestionEditorDirective {
  options = model<string[]>(['', '']);
  formChange = output<void>();
  isAtMaxOptions = computed(() => this.options().length >= MAXIMUM_OPTIONS_ALLOWED);

  constructor(elementRef: ElementRef<HTMLElement>) {
    super(elementRef);
  }

  onQuestionChange(value: string) {
    this.question.set(value);
    this.formChange.emit();
  }

  addOption() {
    if(this.isAtMaxOptions()) {
      return;
    }
    this.options.set([...this.options(), '']);
    this.formChange.emit();
  }

  onOptionEdit(index: number, value: string) {
    const updatedOptions = [...this.options()];
    updatedOptions[index] = value;
    this.options.set(updatedOptions);
    this.formChange.emit();
  }

  removeOption(index: number) {
    const currentOptions = this.options();
    if (currentOptions.length > 2) {
      this.options.set(currentOptions.filter((_, i) => i !== index));
      this.formChange.emit();
    }
  }

  toggleChange(event: Event) {
    this.isRequired.set((event.target as HTMLInputElement).checked ?? false);
    this.formChange.emit();
  }
}