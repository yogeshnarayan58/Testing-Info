import { TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { ActivatedRoute, convertToParamMap, type ParamMap } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('@nielseniq/athena-core', () => ({
  TabModule: class {},
}));
vi.mock('@ngx-translate/core', () => ({
  TranslateModule: class {},
  TranslateService: class {},
  TranslateStore: class {},
  TranslateLoader: class {},
  TranslateCompiler: class {},
  TranslateParser: class {},
  MissingTranslationHandler: class {},
}));
vi.mock('../survey-overview/survey-overview.component', () => ({
  SurveyOverview: class {},
}));
vi.mock('../survey-overview/survey-overview.component.ts', () => ({
  SurveyOverview: class {},
}));
vi.mock('../results-dashboard/results-dashboard.component', () => ({
  ResultsDashboardComponent: class {},
}));
vi.mock('../results-dashboard/results-dashboard.component.ts', () => ({
  ResultsDashboardComponent: class {},
}));
vi.mock('../../../../shared/components/dataset-footer/dataset-footer.component', () => ({
  DatasetFooterComponent: class {},
}));
vi.mock('../../../../shared/components/dataset-footer/dataset-footer.component.ts', () => ({
  DatasetFooterComponent: class {},
}));
vi.mock('../../../../shared/services/survey-common.service', () => ({
  SurveyCommonService: class {},
}));
vi.mock('../../../build-survey/services/survey.service', () => ({
  SurveyService: class {},
}));

import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyService } from '../../../build-survey/services/survey.service';
import type { SavedSurveyDetails } from '../../../build-survey/models/build-survey';
import { DataSummaryService } from '../../utils-datasummary/data-summary.service';
import { SURVEY_RESULTS_TAB_VALUES } from '../../models/survey-results';
import type { SurveyResultsQuestionPayload } from '../../utils/survey-results-payload.util';
import { SurveyResultsComponent } from './survey-results.component';

describe('SurveyResultsComponent', () => {
  let component: SurveyResultsComponent;
  const loadedSurveyDetails = signal<SavedSurveyDetails | null>(null);
  const routeParamMap = new BehaviorSubject<ParamMap>(convertToParamMap({ surveyId: 'survey-1' }));
  const dataSummaryServiceStub = {
    generateDataSummary: vi.fn(),
    clearDataSummary: vi.fn(),
  };

  const surveyCommonServiceStub = {
    setActiveSurveyStep: vi.fn(),
    setDatasetFooterVisible: vi.fn(),
  };

  beforeEach(async () => {
    loadedSurveyDetails.set(null);
    surveyCommonServiceStub.setDatasetFooterVisible.mockReset();
    surveyCommonServiceStub.setActiveSurveyStep.mockReset();
    loadedSurveyDetails.set(null);
    routeParamMap.next(convertToParamMap({ surveyId: 'survey-1' }));
    dataSummaryServiceStub.generateDataSummary.mockReset();
    dataSummaryServiceStub.generateDataSummary.mockReturnValue({ header: { title: 'Saved survey' } });
    dataSummaryServiceStub.clearDataSummary.mockReset();

    await TestBed.configureTestingModule({
      providers: [
        { provide: SurveyCommonService, useValue: surveyCommonServiceStub },
        { provide: SurveyService, useValue: { loadedSurveyDetails } },
        { provide: DataSummaryService, useValue: dataSummaryServiceStub },
        { provide: ActivatedRoute, useValue: {
          paramMap: routeParamMap.asObservable(),
          snapshot: { paramMap: convertToParamMap({ surveyId: 'survey-1' }) },
        } },
      ],
    });

    component = TestBed.runInInjectionContext(() => new SurveyResultsComponent());
  });

  it('waits for loaded questions and logs the dynamic payload when they arrive', () => {
    const log = vi.spyOn(console, 'log').mockImplementation(() => {});
    try {
      TestBed.tick();
      expect(log).not.toHaveBeenCalled();

      loadedSurveyDetails.set({
        surveyId: 'survey-1',
        name: 'Saved survey',
        questions: [{ id: 'backend-id', prompt: { text: 'Real question' }, type: 'STAR_RATING' }],
        metadata: { questionTypes: [], userPrompts: [] },
        reportInfo: { jobId: '' },
        panelists: { targetCompletes: 100 },
      });
      TestBed.tick();
      const payload = log.mock.calls.at(-1)?.[1] as SurveyResultsQuestionPayload[];
      expect(payload).toHaveLength(1);
      expect(payload?.[0]).toMatchObject({
        id: 'backend-id',
        title: 'Real question',
        type: 'STAR_RATING',
        attributes: {},
        reportSpec: {
          id: expect.stringMatching(/^[0-9a-f-]{36}$/i),
          specs: [{
            id: 'spec-1',
            objects: expect.any(Array),
            containers: expect.any(Array),
            dataSummary: { header: { title: 'Saved survey' } },
          }],
        },
      });
      expect(payload?.[0].reportSpec.specs[0].uiConfigs[0]).toMatchObject({
        type: 'GRID',
        id: 'q1_c1_heatmap_absolute',
      });
      expect(log).toHaveBeenLastCalledWith('Survey results payload:', payload);
      expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenCalledOnce();
    } finally {
      log.mockRestore();
    }
  });

  it('sets footer visibility for default Results tab on init', () => {
    component.ngOnInit();

    expect(surveyCommonServiceStub.setActiveSurveyStep).toHaveBeenCalledWith('results');
    expect(component.selectedTab()).toBe(SURVEY_RESULTS_TAB_VALUES.results);
    expect(surveyCommonServiceStub.setDatasetFooterVisible).toHaveBeenCalledWith(false);
  });

  it('updates selected tab and enables footer on Survey specs tab', () => {
    component.onTabChange(SURVEY_RESULTS_TAB_VALUES.surveySpecs);

    expect(component.selectedTab()).toBe(SURVEY_RESULTS_TAB_VALUES.surveySpecs);
    expect(surveyCommonServiceStub.setDatasetFooterVisible).toHaveBeenCalledWith(true);
  });

  it('clears the summary through the payload utility on destroy and stops pending generation', () => {
    component.ngOnDestroy();
    loadedSurveyDetails.set({
      surveyId: 'survey-1', name: 'Survey', questions: [],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: 'job-1' }, panelists: { targetCompletes: 100 },
    });
    TestBed.tick();

    expect(surveyCommonServiceStub.setDatasetFooterVisible).toHaveBeenCalledWith(false);
    expect(dataSummaryServiceStub.clearDataSummary).toHaveBeenCalledTimes(1);
    expect(dataSummaryServiceStub.generateDataSummary).not.toHaveBeenCalled();
  });

  it('delegates summary generation to the payload utility for each loaded survey', () => {
    TestBed.tick();
    expect(dataSummaryServiceStub.generateDataSummary).not.toHaveBeenCalled();
    expect(dataSummaryServiceStub.clearDataSummary).toHaveBeenCalled();

    const survey: SavedSurveyDetails = {
      surveyId: 'survey-1', name: 'Survey', questions: [],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: 'job-1' }, panelists: { targetCompletes: 100 },
      reportDetail: { requestInstance: { datasetLabel: 'Live dataset', prompts: [] } },
    };
    loadedSurveyDetails.set(survey);
    TestBed.tick();
    expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenCalledTimes(1);
    expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenLastCalledWith(survey);

    const updatedSurvey = { ...survey, name: 'Updated survey' };
    loadedSurveyDetails.set(updatedSurvey);
    TestBed.tick();
    expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenLastCalledWith(updatedSurvey);
    expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenCalledTimes(2);
  });

  it('uses one generated summary for every question in a survey payload', () => {
    const log = vi.spyOn(console, 'log').mockImplementation(() => {});
    const dataSummary = { header: { title: 'Shared survey summary' } };
    dataSummaryServiceStub.generateDataSummary.mockReturnValue(dataSummary);
    loadedSurveyDetails.set({
      surveyId: 'survey-1',
      name: 'Survey',
      questions: [
        { id: 'question-1', prompt: { text: 'First question' }, type: 'SINGLE_CHOICE' },
        { id: 'question-2', prompt: { text: 'Second question' }, type: 'STAR_RATING' },
      ],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: 'job-1' },
      panelists: { targetCompletes: 100 },
    });
    TestBed.tick();

    const payload = log.mock.calls.at(-1)?.[1] as SurveyResultsQuestionPayload[];
    expect(payload).toHaveLength(2);
    expect(payload?.[0].reportSpec.specs[0].dataSummary).toBe(dataSummary);
    expect(payload?.[1].reportSpec.specs[0].dataSummary).toBe(dataSummary);
    expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenCalledOnce();
    log.mockRestore();
  });

  it('uses survey ID and questions from the loaded survey response without route params', () => {
    routeParamMap.next(convertToParamMap({}));
    TestBed.tick();
    const survey: SavedSurveyDetails = {
      surveyId: 'response-survey-id',
      name: 'First survey',
      questions: [{ id: 'question-from-response', prompt: { text: 'Question' }, type: 'SINGLE_CHOICE' }],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: 'job-1' }, panelists: { targetCompletes: 100 },
    };
    loadedSurveyDetails.set(survey);
    TestBed.tick();
    expect(dataSummaryServiceStub.generateDataSummary).toHaveBeenCalledWith(survey);
  });

  it('clears stale summary when route changes to a survey that has not loaded', () => {
    loadedSurveyDetails.set({
      surveyId: 'survey-1',
      name: 'Previously loaded survey',
      questions: [],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: 'job-1' },
      panelists: { targetCompletes: 100 },
    });
    TestBed.tick();
    dataSummaryServiceStub.generateDataSummary.mockClear();
    dataSummaryServiceStub.clearDataSummary.mockClear();

    routeParamMap.next(convertToParamMap({ surveyId: 'survey-2' }));
    TestBed.tick();

    expect(dataSummaryServiceStub.clearDataSummary).toHaveBeenCalledOnce();
    expect(dataSummaryServiceStub.generateDataSummary).not.toHaveBeenCalled();
  });
});
