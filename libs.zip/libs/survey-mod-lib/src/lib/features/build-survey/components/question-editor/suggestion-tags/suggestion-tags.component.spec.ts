import { Component, Input, signal, WritableSignal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { describe, expect, it, beforeEach, vi } from 'vitest';
import { SuggestionTag } from '../../../models/build-survey';
import { SuggestionTagsComponent } from './suggestion-tags.component';

// The athena-core mock does not provide TagModule, so a stub exposes the inputs the template binds.
// eslint-disable-next-line @angular-eslint/component-selector -- must match the real <niq-tag> element
@Component({ selector: 'niq-tag', standalone: true, template: '' })
class NiqTagStubComponent {
  @Input() iconName = '';
  @Input() size = '';
  @Input() variant = '';
  @Input() label = '';
  @Input() tooltipLabel = '';
}

describe('SuggestionTagsComponent', () => {
  let fixture: ComponentFixture<SuggestionTagsComponent>;
  let counts: WritableSignal<SuggestionTag | null>;
  let translations: Record<string, string>;

  const render = (value: SuggestionTag | null) => {
    counts.set(value);
    fixture.detectChanges();
  };

  const tags = () => fixture.debugElement.queryAll((el) => el.name === 'niq-tag');
  const tagWith = (variant: string) =>
    tags().find((tag) => (tag.componentInstance as NiqTagStubComponent).variant === variant);

  beforeEach(async () => {
    translations = {};
    // Returns the key unchanged when there is no translation, like the real service.
    const translateService = {
      instant: vi.fn((key: string, params?: Record<string, unknown>) =>
        translations[key]?.replace(/{{(\w+)}}/g, (_, name: string) => String(params?.[name])) ?? key
      ),
    };
    await TestBed.configureTestingModule({
      providers: [{ provide: TranslateService, useValue: translateService }],
    })
      .overrideComponent(SuggestionTagsComponent, {
        set: { imports: [NiqTagStubComponent], styleUrl: undefined },
      })
      .compileComponents();
    fixture = TestBed.createComponent(SuggestionTagsComponent);
    // Vitest runs without Angular's compiler transform, so setInput() fails (NG0303) for input() signals.
    // Supplying a real writable signal keeps the template reactive like a bound input.
    counts = signal<SuggestionTag | null>(null);
    Object.defineProperty(fixture.componentInstance, 'suggestionCounts', { value: counts });
  });

  it('creates the component and renders an empty container by default', () => {
    fixture.detectChanges();

    expect(fixture.componentInstance).toBeTruthy();
    expect(fixture.nativeElement.querySelector('.question-suggestion-tags')).not.toBeNull();
    expect(tags()).toHaveLength(0);
  });

  it('renders no tags when suggestionCounts is null', () => {
    render(null);

    expect(tags()).toHaveLength(0);
  });

  it('renders no tags when both counts are 0', () => {
    render({ mandatoryCount: 0, optionalCount: 0 });

    expect(tags()).toHaveLength(0);
  });

  it('renders only the required-change tag when only mandatoryCount is greater than 0', () => {
    render({ mandatoryCount: 2, optionalCount: 0 });

    expect(tags()).toHaveLength(1);
    const tag = tagWith('error')!.componentInstance as NiqTagStubComponent;
    expect(tag.iconName).toBe('error');
    expect(tag.size).toBe('x-small');
    expect(tag.label).toBe('2 required change');
    expect(tag.tooltipLabel).toBe('2 required change');
    expect(tagWith('warning')).toBeUndefined();
  });

  it('renders only the recommendation tag when only optionalCount is greater than 0', () => {
    render({ mandatoryCount: 0, optionalCount: 3 });

    expect(tags()).toHaveLength(1);
    const tag = tagWith('warning')!.componentInstance as NiqTagStubComponent;
    expect(tag.iconName).toBe('triangle-alert');
    expect(tag.size).toBe('x-small');
    expect(tag.label).toBe('3 recommendation');
    expect(tag.tooltipLabel).toBe('3 recommendation');
    expect(tagWith('error')).toBeUndefined();
  });

  it('renders both tags, required change first, when both counts are greater than 0', () => {
    render({ mandatoryCount: 1, optionalCount: 2 });

    const rendered = tags().map((tag) => tag.componentInstance as NiqTagStubComponent);
    expect(rendered.map((tag) => tag.variant)).toEqual(['error', 'warning']);
    expect(rendered.map((tag) => tag.label)).toEqual(['1 required change', '2 recommendation']);
  });

  it('updates the rendered tags when suggestionCounts changes', () => {
    render({ mandatoryCount: 1, optionalCount: 0 });
    expect(tags()).toHaveLength(1);

    render({ mandatoryCount: 1, optionalCount: 4 });
    expect(tags()).toHaveLength(2);

    render({ mandatoryCount: 0, optionalCount: 4 });
    expect(tags()).toHaveLength(1);
    expect(tagWith('warning')).toBeDefined();

    render(null);
    expect(tags()).toHaveLength(0);
  });
});
