import { BasePage, WebActions, assert } from "@gfk/gta";
import { getFormatPanelSelections } from "../../utils/helper-service";
import * as resources from "./format-panel-resources.json";
import { MAX_TEST_TIMEOUT, MAX_TIMEOUT} from "../../../constants/time-out-constants";
import { ResourceManager } from "../../utils/resource-manager";
const FP_COMPONENT_NAME = "FormatPanel";
/**
 * Method makes sure to call the Default formal panel checks based on testData and Data set
 * @param testData - Should have formatPanelSelections object.
 * @param dataset - String to match Data set id. 
 */

export class FormatPanel {
  webActionHandler: WebActions;
  resourceManager: ResourceManager;
  constructor(basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    // Initialize ResourceManager with component resources
    this.resourceManager = new ResourceManager({});

    // Register multiple resources for the same component
    this.resourceManager.registerResources(FP_COMPONENT_NAME, resources);
  }

  public async navigateToUrlAndCheckMadlibVisbility(
    targetUrl: string
  ) {
      // Perform the navigation action with the specified timeout
      await this.webActionHandler.navigateTo(targetUrl, MAX_TEST_TIMEOUT,"domcontentloaded");
      const reportMenuIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource(
          "formatPanelId",
          FP_COMPONENT_NAME
        )
      );
      await reportMenuIcon.waitFor();
  }

  public async checkDefaultFormatPanelAfterRun(
    testData: any,
    dataset: string
  ) {
    await this.checkDefaultFormatPanel(testData, dataset);
    await this.checkIfChartsMatching(testData, dataset);
  }
  
  public async checkDefaultFormatPanel(
    testData: any,
    dataset: string
  ) {
    console.log("Satrt - Inside format panel selections default checks");
    const formatPanelSelections = getFormatPanelSelections(
      testData,
      dataset
    );
    if (!formatPanelSelections) {
      console.log(`Selections not found for ${dataset}.`);
      return;
    }
    await this.openFormatPanel();
    await this.testDefaultFormatPanel(formatPanelSelections.default);
    await this.closeFormatPanel();
    console.log("End - Inside format panel selections default checks");
  }
  
  /**
   * Method checks the default state of format panel selections - when report is opened intially.
   * @param formatPanelSelections 
   */
  public async testDefaultFormatPanel(formatPanelSelections: any) {
    console.log("Checking the default state of format panel based on formatPanelSelections");
    for (let index = 0; index < formatPanelSelections.length; index++) {
      const formatPanelItem = formatPanelSelections[index];
      const formatpanelLabelLoc = await this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
        `formatPanelCheckBoxSelectionLabel`,
         formatPanelItem.id, FP_COMPONENT_NAME)
      );
      await formatpanelLabelLoc.waitFor();
      const labelVal =  await formatpanelLabelLoc.getAllInnerText();
      console.log(labelVal);
      if (labelVal && labelVal.length > 0) {
        await assert(labelVal[0]).toBe(formatPanelItem.value);
      } else {
        console.warn(`No label text found for format panel item: ${formatPanelItem.id}`);
        await assert(labelVal).toBeDefined();
      }
  
      const checkBoxLoc = await this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
        'formatPanelCheckBoxSelectionDiv', formatPanelItem.id, FP_COMPONENT_NAME)
      );
      if (formatPanelItem.selected) {
         const res = await checkBoxLoc.getAttribute("class");
         assert(res).toBe("checkbox-container large checked");
      } else {
        const res = await checkBoxLoc.getAttribute("class");
        assert(res).toContain("unchecked");
      }
    }
  }
  
  /**
   * Method call the main method responsible for checking the Components matching the format panel 
   * @param testData 
   * @param dataset 
   * @returns 
   */
  public async checkIfChartsMatching(
      testData: any,
      dataset: string
    ) {
    const formatPanelSelections = await getFormatPanelSelections(
      testData,
      dataset
    );
    if (!formatPanelSelections) {
      console.log(`Selections not found for ${dataset}.`);
      return;
    }
    await this.openFormatPanel();
    await this.testFormatPanelSelectionMatchWithChart(formatPanelSelections.default);
    await this.closeFormatPanel();
  }
  
  /**
   * This method will test the components based on the formatPanelSelections sent.
   * This can be reused to check the format panel changes of each component- based on formatPanelSelections sent.
   * @param formatPanelSelections 
   */
  public async testFormatPanelSelectionMatchWithChart(formatPanelSelections: any) {
      console.log("Am inside testFormatPanelSelectionMatchWithChart")
      for (let index = 0; index < formatPanelSelections.length; index++) {
        
        const formatPanelItem = formatPanelSelections[index];
        if(formatPanelItem.value.toLowerCase()==='grid lines'){ 
              console.log("Am inside the format panel check @@@@@@grid lines");
              if(formatPanelItem?.components?.length > 0){ 
                
                  for (let j = 0; j < formatPanelItem.components.length; j++){
                      const gridLinesLoc = await this.webActionHandler.getWebElement(
                        this.resourceManager.getDynamicResource(
                          'formatPanelComponentSvg',formatPanelItem.components[j], FP_COMPONENT_NAME ));
                      console.log("Am inside formatSelections list for loop", gridLinesLoc);
                      if(formatPanelItem.selected){
                          const stroke = await gridLinesLoc.getAttribute('stroke');
                          await assert(stroke).toBe('#e6e6e6');
                      }
                      else {
                          const stroke = await gridLinesLoc.getAttribute('stroke');
                          await assert(stroke).not().toBe('#e6e6e6');
                      }
                  }
              }
         } 
  
        if(formatPanelItem.value.toLowerCase()==='data labels'){
          console.log("Am inside the format panel check @@@@@@data labels");
          console.log(formatPanelItem);
          if(formatPanelItem?.components?.length > 0){
              for (let k = 0; k < formatPanelItem.components.length; k++){
                  console.log(formatPanelItem.components[k])
                  const dataLabelLoc = await this.webActionHandler.getWebElement(
                    this.resourceManager.getDynamicResource(
                      'formatPanelChartsDataLabel',formatPanelItem.components[k], FP_COMPONENT_NAME))
                  console.log("Am getting inside expect loop", dataLabelLoc);
                  if(formatPanelItem.selected){
                      const label = await dataLabelLoc.isVisible()
                      await assert(label).toBeTruthy();
                      //await expect(dataLabelLoc).toBeAttached();
                  } else {
                      const label = await dataLabelLoc.isVisible()
                      await assert(label).toBeFalsy();
                      //await expect(dataLabelLoc).not.toBeAttached();
                  }
              }
          }
          
        }
  
        if(formatPanelItem.value.toLowerCase()==='characteristic short description'){
          console.log("Am inside the format panel check @@@@@@characteristic short description");
          //TODO: Need to find proper way 
          /*const labelLocaltor = await getPage().getByText(`...${formatPanelItem.labelToTest}`).first();
          if(formatPanelItem.selected){
              await expect(labelLocaltor).toBeAttached();
          } else {
              await expect(labelLocaltor).not.toBeAttached();
          }*/
        }
        
      }
  }
  
  /**
   * Method helps in opening format panel
   */
  public async openFormatPanel() {
      console.log("Trying to open format panel !!");
      const formatPanelId = this.webActionHandler.getWebElement(this.resourceManager.getResource('formatPanelId', FP_COMPONENT_NAME));
      await formatPanelId.waitFor(MAX_TIMEOUT, 'visible');
      await formatPanelId.click();
      const formatMenu =   this.webActionHandler.getWebElement(this.resourceManager.getResource('formatPanelmenuId', FP_COMPONENT_NAME));
      await formatMenu.waitFor(MAX_TIMEOUT, 'visible');
      await formatMenu.click();
  }
  
  /**
   * Method helps in closing format panel
   */
  public async closeFormatPanel(){
      await  this.webActionHandler.getWebElement(this.resourceManager.getResource('formatPanelCloseIcon', FP_COMPONENT_NAME)).click();
  }

  /**
 * Method checks the default state of format panel selections - when report is opened intially.
 */
  public async checkIsFormatPanelVisible() {
    try {
      console.log("Trying to open menu panel !!");
      const formatPanelId = this.webActionHandler.getWebElement(this.resourceManager.getResource('formatPanelId', FP_COMPONENT_NAME));
      await formatPanelId.waitFor(MAX_TIMEOUT, 'visible');
      await formatPanelId.click();

      const formatMenu = this.webActionHandler.getWebElement(this.resourceManager.getResource('formatPanelmenuId', FP_COMPONENT_NAME));
      await formatMenu.isVisible()
      if (await formatMenu.isVisible()) {
        throw new Error("Format panel is available when it is not expected to be.");
      }
    } catch (error) {
      console.error(`Failed to click format panel ':`, error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Error interacting with format panel': ${errorMessage}`);
    }

  }

}
