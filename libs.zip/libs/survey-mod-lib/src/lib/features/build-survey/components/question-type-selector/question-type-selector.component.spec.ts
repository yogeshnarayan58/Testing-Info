import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { QuestionTypes } from '../../models/build-survey';
import { SurveyService } from '../../services/survey.service';
import { QuestionTypeSelectorComponent } from './question-type-selector.component';

vi.mock('../../services/survey.service', () => ({
  SurveyService: class {},
}));

describe('QuestionTypeSelectorComponent', () => {
  let component: QuestionTypeSelectorComponent;
  let surveyService: {
    getQuestionType: ReturnType<typeof vi.fn>;
    setQuestionType: ReturnType<typeof vi.fn>;
  };

  beforeEach(() => {
    surveyService = {
      getQuestionType: vi.fn().mockReturnValue(''),
      setQuestionType: vi.fn(),
    };

    TestBed.configureTestingModule({
      providers: [{ provide: SurveyService, useValue: surveyService }],
    });

    component = TestBed.runInInjectionContext(
      () => new QuestionTypeSelectorComponent(surveyService as unknown as SurveyService),
    );
  });

  it('loads the selected question type on initialization', () => {
    surveyService.getQuestionType.mockReturnValue(QuestionTypes.Text);

    component.ngOnInit();

    expect(component.selectedType()).toBe(QuestionTypes.Text);
  });

  it('does not open the editor for an empty selection', () => {
    component.onTypeSelected('');

    expect(component.showEditor()).toBe(false);
    expect(surveyService.setQuestionType).not.toHaveBeenCalled();
  });

  it('saves a valid selection and opens the editor', () => {
    component.onTypeSelected(QuestionTypes.SingleChoice);

    expect(component.selectedType()).toBe(QuestionTypes.SingleChoice);
    expect(surveyService.setQuestionType).toHaveBeenCalledWith(QuestionTypes.SingleChoice);
    expect(component.showEditor()).toBe(true);
  });

  it('clears the selected type and closes the editor when discarding the first question', () => {
    component.onTypeSelected(QuestionTypes.SingleChoice);

    component.discardQuestion();

    expect(component.selectedType()).toBe('');
    expect(component.showEditor()).toBe(false);
    expect(surveyService.setQuestionType).toHaveBeenLastCalledWith('');
  });

  it('publishes the initial question when clicking outside the editor', () => {
    vi.useFakeTimers();
    const editorElement = document.createElement('div');
    component.showEditor.set(true);
    (component as any).initialQuestionEditor = () => ({ nativeElement: editorElement });

    component.saveOnOutsideClick(new MouseEvent('click'));
    vi.runAllTimers();

    expect(component.publishRequest()).toBe(1);
    vi.useRealTimers();
  });
});
