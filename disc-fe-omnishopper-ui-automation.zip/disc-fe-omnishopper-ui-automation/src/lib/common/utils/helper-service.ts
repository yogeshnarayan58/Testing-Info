import { DatasetConfig, DatasetContent, ReportLocalizationData, TestData} from "../models/data-model";

export const getTestData = (data: any, attribute: string, section?: string): any => {

  if (section) {
    if (!data[section]) {
      throw new Error(`Section "${section}" not found in JSON file.`);
    }
    return data[section][attribute];
  }

  if (!data[attribute]) {
    throw new Error(`Attribute "${attribute}" not found in JSON file.`);
  }
  return data[attribute];
};

/**
 * Utility function to access dataset configuration by exact key match
 * 
 * @param testData The complete test data object
 * @param datasetName The exact name of the dataset key to find
 * @returns The dataset configuration or undefined if not found
 */
/**
 * Utility function to access dataset configuration by exact key match
 * Supports both object-based TestData and array-based legacy data
 * 
 * @param testData The complete test data object or array
 * @param datasetName The exact name of the dataset key to find (must be one of the valid DatasetContent values)
 * @returns The dataset configuration or undefined if not found
 */
export function findDataSetByName(testData: TestData | any, datasetName: DatasetContent | string): DatasetConfig | any | undefined {
    // Validate input parameters
    if (!testData) {
        console.warn('findDataSetByName: testData is null or undefined');
        return undefined;
    }
    
    if (!datasetName || typeof datasetName !== 'string') {
        console.warn('findDataSetByName: datasetName is null, undefined, or not a string');
        return undefined;
    }
    
    // Handle array-based data structure (legacy format)
    if (Array.isArray(testData)) {
        console.log('findDataSetByName: Processing array-based test data');
        const found = testData.find((item: any) => 
            item.dataSet === datasetName || 
            item.id === datasetName ||
            item.DataSet === datasetName
        );
        if (found) {
            console.log(`findDataSetByName: Found dataset '${datasetName}' in array format`);
            return found;
        } else {
            console.warn(`findDataSetByName: Dataset '${datasetName}' not found in array format`);
            return undefined;
        }
    }
    
    // Handle object-based data structure (TestData format)
    if (testData.datasets && typeof testData.datasets === 'object') {
        console.log('findDataSetByName: Processing object-based test data');
        
        // Check if the dataset exists
        if (datasetName in testData.datasets) {
            console.log(`findDataSetByName: Found dataset '${datasetName}' in object format`);
            return testData.datasets[datasetName];
        } else {
            console.warn(`findDataSetByName: Dataset '${datasetName}' not found in testData.datasets. Available datasets: ${Object.keys(testData.datasets).join(', ')}`);
            return undefined;
        }
    }
    
    // If neither array nor object with datasets property
    console.warn('findDataSetByName: testData is neither an array nor an object with datasets property');
    return undefined;
}
export const getDimensionSelections = (testData: any, key: string, pivot?: string): any => {
    if (!testData || typeof testData !== 'object') {
      console.warn('Invalid test data provided.');
      return null; // Return null for invalid test data
    }
  
    // Check if the specified key exists in the test data
    if (!testData[key]) {
      console.warn(`Key "${key}" not found in the test data.`);
      return null; // Return null if the key is not found
    }

    let dimensionSelections;
      // Retrieve the "Selections" object
    if (pivot) {
      dimensionSelections = testData[key]?.dimensionSelections.find((dimension: { pivot: string; }) => dimension.pivot === pivot);
    } else {
      dimensionSelections = testData[key]?.dimensionSelections[0];
    }
  
    
  
    // Return null if Selections is not found
    if (!dimensionSelections) {
      console.warn(`"Selections" not found under key "${key}".`);
      return null;
    }
  
    return dimensionSelections;
  };


  export const getFormatPanelSelections = (testData: any, key: string): any => {
    if (!testData || typeof testData !== 'object') {
      console.warn('Invalid test data provided.');
      return null; // Return null for invalid test data
    }
  
    // Check if the specified key exists in the test data
    if (!testData[key]) {
      console.warn(`Key "${key}" not found in the test data.`);
      return null; // Return null if the key is not found
    }

    let formatPanelSelections = testData[key]?.formatPanelSelections;

    // Return null if Selections is not found
    if (!formatPanelSelections) {
      console.warn(`"Selections" not found under key "${key}".`);
      return null;
    }
    return formatPanelSelections;
  };
  
  
  export async function getReportTestData(env: string, devTestData: any, siTestData: any) {
    console.log('Get test data');
    if (env == 'dev') {
      return devTestData;
    } else {
      return siTestData;
    }
  }
  
/**
 * Checks if a specific pivot exists in the test data's dimension selections
 * 
 * @param testData The dataset configuration containing dimension selections
 * @param pivotName The name of the pivot to check for
 * @returns True if the pivot exists in dimension selections, false otherwise
 */
export function hasPivotInDimensionSelections(testData: DatasetConfig | undefined, pivotName: string): boolean {
    if (!testData || !testData.dimensionSelections || !Array.isArray(testData.dimensionSelections)) {
        console.warn('Test data or dimension selections is undefined or invalid.');
        return false;
    }

    if (!pivotName || typeof pivotName !== 'string') {
        console.warn('Pivot name is undefined or invalid.');
        return false;
    }

    return testData.dimensionSelections.some((selection: any) => selection.pivot === pivotName);
}

/**
 * Fetches locale-specific test data from a provided dataset.
 *
 * @param localeCode - The locale identifier (e.g., 'en-US')
 * @param dataset - Array of test data entries conforming to LocaleTestEntry
 * @returns The matching locale's data
 * @throws If the specified locale is not found in the dataset
 */
export function getTestDataByLocale(
  localeCode: string,
  dataset: ReportLocalizationData[]
): ReportLocalizationData {
  const entry = dataset.find((item) => item.locale === localeCode);

  if (!entry) {
    throw new Error(
      `Locale '${localeCode}' not found in the provided test data.`
    );
  }

  return entry;
}

/**
 * Finds the index of a specific pivot in the dataset's dimension selections array.
 * @param reportTestData - The dataset configuration containing dimension selections
 * @param pivot - The name of the pivot to find (e.g., 'Average price', 'Distribution')
 * @returns The zero-based index of the pivot if found, or -1 if not found or if test data is invalid
 */
export function getPivotDataIndexByName(reportTestData: DatasetConfig | undefined, pivot: string): number {
  return reportTestData?.dimensionSelections?.findIndex(
  (selection: any) => selection.pivot === pivot
) ?? -1;
}

/**
 * Returns the pivot object from the assertion data's dataSummary list
 * matching the provided pivot name.
 *
 * Accepts either the array itself or the full assertion object containing
 * a dataSummary field.
 *
 * @param pivotName - The name of the pivot to find (e.g., "Product").
 * @param data - The dataSummary array or an object with a dataSummary array.
 * @returns The matching pivot object if found, otherwise null.
 */
export function getDataSummaryByPivot(pivotName: string, data: any): any {
  try {
    // Accept either the array at data.dataSummary or the array directly
    const list = Array.isArray(data)
      ? data
      : data?.dataSummary;

    // If list is not an array, throw error
    if (!Array.isArray(list)) {
      throw new Error("dataSummary is not defined or not an array in assertion data.");
    }

    // Find and return the pivot object matching the pivotName
    return (
      list.find((item: any) => typeof item?.pivot === 'string' && item.pivot === pivotName) || null
    );
  } catch (error) {
    console.error(`getDataSummaryByPivot: Failed to find pivot '${pivotName}'.`, error);
    return null;
  }
}

/**
 * Returns the dimensionSelections entry matching a pivot name.
 *
 * Accepts either the array itself or an object containing a `dimensionSelections` array.
 * Mirrors the ergonomics of getDataSummaryByPivot.
 *
 * @param pivotName - The name of the pivot to find (e.g., "Product", "Retailer").
 * @param data - The `dimensionSelections` array or an object with a `dimensionSelections` array.
 * @returns The matching dimension selection object if found, otherwise null.
 */
export function getDimensionSelectionsByPivot(pivotName: string, data: any): any {
  try {
    // Accept either the array at data.dimensionSelections or the array directly
    const list = Array.isArray(data)
      ? data
      : data?.dimensionSelections;

    const lowerPivotName = pivotName.toLowerCase();

    // Find and return the pivot object matching the pivotName
    return (
      list.find((item: any) => typeof item?.pivot === 'string' && item.pivot.toLowerCase() === lowerPivotName) || null
    );
  } catch (error) {
    console.error(`getDimensionSelectionsByPivot: Failed to find pivot '${pivotName}'.`, error);
    return null;
  }
}
