import { MY_ASSETS_ROOT } from '../../../shared/utils/survey-folder.util';
import { HttpClient } from '@angular/common/http';
import { createEnvironmentInjector, EnvironmentInjector, Injector, runInInjectionContext, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AssignRightsHelperService, UserService } from '@nielsen/crf-lp-common';
import { ToastService } from '@nielseniq/athena-core';
import { EnvironmentConfig, ListCallDatasetService } from '@nielseniq/crf-discover-fe-core';
import { finalize, of, Subject, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { FLOW_TYPES } from '../../../core/config/config';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { ApiService } from '../../../shared/services/api.service';
import { RunReportService } from '../../select-panelist/services/run-report.service';
import { SelectPanelistUtilsService } from '../../select-panelist/utils.service';
import { ChannelName, DimensionKeys, QuestionTypes, SURVEY_ID_PREFIX, SURVEY_SUGGESTIONS_STATE, SURVEY_VALIDATION_STATE, SurveyStatusType } from '../models/build-survey';
import { buildAnswerSpec, stringFormat, toApiOptions, toApiQuestion } from './survey-payload.util';
import {
  extractRephrasedQuestion,
  isChoiceOptionsValid,
  isChoiceType,
  isQuestionTextValid,
  isQuestionValid,
  isScaleMatrixValid,
  isScaleType,
  normalizeRephrasedQuestion,
} from './survey-question.util';
import { SurveyService } from './survey.service';
import { ValidationService } from './validation.service';

vi.mock('@nielsen/crf-lp-common', () => ({
  AssignRightsHelperService: class {},
  UserService: class {},
}));

describe('SurveyService', () => {
  const question = (overrides: Record<string, unknown> = {}) => ({
    question: 'Question',
    options: ['A', 'B'],
    isRequired: false,
    type: QuestionTypes.SingleChoice,
    ...overrides,
  });

  const createService = (routerUrl = '/survey/build-survey') => {
    const httpClient = { get: vi.fn().mockReturnValue(of({})), post: vi.fn() };
    const dataViewId = Object.assign(vi.fn(() => 'view-1'), { set: vi.fn() });
    const panelistCompleted = signal(false);
    const sessionState: {
      userPrompt: string;
      panelistDimensionalValue: Record<string, string[]>;
      selectPanelistUiState: { reportData: boolean; householdCount: string; selectedResponses: 25 | null };
      dataViewId: string | null;
      selectedDatasetConfig: any;
      selectedDatasetDisplay: string;
      refreshedDate: string | null;
      panelistDataSelectorState: any;
      questions: any[];
    } = {
      userPrompt: 'Prompt',
      panelistDimensionalValue: { [DimensionKeys.product]: ['Snacks'] },
      selectPanelistUiState: { reportData: false, householdCount: '0', selectedResponses: 25 },
      dataViewId: 'view-1',
      selectedDatasetConfig: { dataView: { dataViewId: 'dataset-view-1' } },
      selectedDatasetDisplay: 'Dataset Display',
      refreshedDate: 'today',
      panelistDataSelectorState: { datasetName: 'Dataset 1', selections: [], dataPrompts: [] },
      questions: [],
    };
    const surveyCommonService = {
      setUserContext: vi.fn(),
      getUserContext: vi.fn().mockReturnValue({
        userId: 'user-1', applicationId: 'app-1', clientId: 'client-1', emailId: 'user@example.com', locale: 'en-US',
      }),
      flowType: vi.fn().mockReturnValue({
        [FLOW_TYPES.IMPORT]: false,
        [FLOW_TYPES.SCRATCH]: true,
        [FLOW_TYPES.AIFLOW]: false,
        [FLOW_TYPES.TEMPLATE]: false,
      }),
      getSurveySessionState: vi.fn().mockImplementation(() => structuredClone(sessionState)),
      hydrateSurveySessionState: vi.fn().mockImplementation((partialState: Record<string, unknown>) => {
        Object.assign(sessionState, partialState);
      }),
      getClientStateForDraftSave: vi.fn().mockImplementation(() => ({
        selectedDatasetConfig: sessionState.selectedDatasetConfig,
        selectedDatasetDisplay: sessionState.selectedDatasetDisplay,
        refreshedDate: sessionState.refreshedDate,
        panelistDataSelectorState: sessionState.panelistDataSelectorState,
      })),
      setDataViewId: vi.fn().mockImplementation((value: string | null) => {
        sessionState.dataViewId = value;
      }),
      setSurveyQuestions: vi.fn().mockImplementation((questions: unknown[]) => {
        sessionState.questions = questions as any[];
      }),
      getSurveyQuestions: vi.fn().mockImplementation(() => sessionState.questions),
      getSelectedDatasetConfig: vi.fn().mockReturnValue({ dataView: { dataViewId: 'dataset-view-1' } }),
      getPanelistDataSelectorState: vi.fn().mockReturnValue({ datasetName: 'Dataset 1', selections: [], dataPrompts: [] }),
      getPanelistDimensionalValue: vi.fn().mockReturnValue({ [DimensionKeys.product]: ['Snacks'] }),
      getUserPrompt: vi.fn().mockReturnValue('Prompt'),
      setUserPrompt: vi.fn(),
      setPanelistDimensionalValue: vi.fn(),
      setSelectedDatasetConfig: vi.fn(),
      setSelectedDatasetDisplay: vi.fn(),
      setRefreshedDate: vi.fn(),
      setPanelistDataSelectorState: vi.fn(),
      getSelectedDatasetDisplay: vi.fn().mockReturnValue('Dataset Display'),
      getRefreshedDate: vi.fn().mockReturnValue('today'),
      setSelectPanelistUiState: vi.fn(),
      getSelectPanelistUiState: vi.fn().mockReturnValue({ reportData: false, householdCount: '0', selectedResponses: 25 }),
      setSurveyLoading: vi.fn(),
      setDataselectorLoading: vi.fn(),
      dataViewId,
      panelistCompleted,
    };
    const runReportService = {
      lastJobId: 'job-1',
      reportPayload: { jobId: 'request-job-1' },
      runReport: vi.fn(),
      reset: vi.fn(),
    };
    runReportService.runReport.mockImplementation(() => {
      runReportService.reportPayload.jobId = 'publish-request-job-1';
      return of('panelist-job-1');
    });
    const assignRightsHelperService = { getDefaultRights: vi.fn().mockReturnValue(of([{ role: 'OWNER' }])) };
    const userService = { getUserData: vi.fn().mockReturnValue(of({
      id: 'user-1', organization: { id: 'client-1' }, userName: 'user@example.com', locale: 'en-US',
    })) };
    const listCallDatasetService = { getDataSetDetails: vi.fn().mockReturnValue(of({})) };
    const injector = createEnvironmentInjector([
      ValidationService,
      { provide: HttpClient, useValue: httpClient },
      { provide: ToastService, useValue: { InsertToast: vi.fn() } },
      { provide: EnvironmentConfig, useValue: { appId: 'app-1', apiUrls: { assetCatalogDiscovery: '/discover-ui-gateway/svc/ess/asset-catalog-discovery/v3/assets' } } },
      { provide: SurveyCommonService, useValue: surveyCommonService },
      { provide: RunReportService, useValue: runReportService },
      { provide: ListCallDatasetService, useValue: listCallDatasetService },
      { provide: SelectPanelistUtilsService, useClass: SelectPanelistUtilsService },
      { provide: AssignRightsHelperService, useValue: assignRightsHelperService },
      { provide: UserService, useValue: userService },
      { provide: Router, useValue: { url: routerUrl } },
    ], Injector.NULL as unknown as EnvironmentInjector);
    const service = runInInjectionContext(
      injector,
      () => new SurveyService(new ApiService(httpClient as unknown as HttpClient)),
    );
    const validationService = injector.get(ValidationService);
    return { service, httpClient, surveyCommonService, runReportService, userService, listCallDatasetService, validationService, injector };
  };

  it('finishes survey loading and dataset restoration while the catalog GET is pending', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService, injector } = createService();
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      assetInfo: { assetId: 'US-asset-1', status: SurveyStatusType.DRAFT },
      reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'US' } },
    };
    const catalogResponse = new Subject<unknown>();
    const catalogFinalized = vi.fn();
    httpClient.post.mockReturnValue(of({ data: saved }));
    httpClient.get.mockReturnValue(catalogResponse.pipe(finalize(catalogFinalized)));
    const loaded = vi.fn();
    const completed = vi.fn();

    service.loadSurvey('survey-1').subscribe({ next: loaded, complete: completed });

    expect(listCallDatasetService.getDataSetDetails).toHaveBeenCalledWith('US');
    expect(loaded).toHaveBeenCalledExactlyOnceWith(saved);
    expect(completed).toHaveBeenCalledOnce();
    expect(surveyCommonService.setSurveyLoading).toHaveBeenLastCalledWith(false);
    expect(catalogFinalized).not.toHaveBeenCalled();

    injector.destroy();

    expect(catalogFinalized).toHaveBeenCalledOnce();
  });

  it('requests recently-opened tracking on every load of the same asset', () => {
    const { service, httpClient } = createService();
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      assetInfo: { assetId: 'US-1210439282460590102', status: SurveyStatusType.DRAFT },
    };
    httpClient.post.mockReturnValue(of({ data: saved }));
    const loaded: unknown[] = [];

    service.loadSurvey('survey-1').subscribe(value => loaded.push(value));
    service.loadSurvey('survey-1').subscribe(value => loaded.push(value));

    expect(httpClient.get).toHaveBeenCalledTimes(2);
    const expectedRequest = [
      '/discover-ui-gateway/svc/ess/asset-catalog-discovery/v3/assets/US-1210439282460590102',
      {
        withCredentials: true,
        params: { lastOpenedByMe: true },
      },
    ];
    expect(httpClient.get).toHaveBeenCalledWith(...expectedRequest);
    expect(loaded).toEqual([saved, saved]);
  });

  it('keeps the survey usable when the catalog GET fails', () => {
    const { service, httpClient, surveyCommonService } = createService();
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      assetInfo: { assetId: 'US-asset-1', status: SurveyStatusType.DRAFT },
    };
    httpClient.post.mockReturnValue(of({ data: saved }));
    httpClient.get.mockReturnValue(throwError(() => new Error('Catalog unavailable')));
    let loaded: unknown;

    service.loadSurvey('survey-1').subscribe(value => loaded = value);

    expect(loaded).toBe(saved);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenLastCalledWith(false);
  });

  it.each([undefined, '   '])('skips the catalog GET when the survey asset id is missing or blank (%s)', assetId => {
    const { service, httpClient } = createService();
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      assetInfo: { assetId },
    };
    httpClient.post.mockReturnValue(of({ data: saved }));

    service.loadSurvey('survey-1').subscribe();

    expect(httpClient.get).not.toHaveBeenCalled();
  });

  it('restores the dataset refresh date when loading a draft in a fresh session', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    surveyCommonService.getRefreshedDate.mockReturnValue(null);
    surveyCommonService.getSelectedDatasetConfig.mockReturnValue(null);
    surveyCommonService.getPanelistDataSelectorState.mockReturnValue(null);
    const draft = service.buildSurveyPayload(SurveyStatusType.DRAFT);
    const saved = { ...draft, reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'EU' } } };
    httpClient.post.mockReturnValue(of({ data: saved }));
    listCallDatasetService.getDataSetDetails.mockReturnValue(of({ PANEL_OD_OMNI: [
      { id: 'dataset-1', stackId: 'US', refreshedOn: Date.UTC(2026, 8, 1) },
      { id: 'dataset-1', stackId: 'EU', refreshedOn: String(Date.UTC(2026, 8, 30)) },
    ] }));
    let loaded: unknown;

    service.loadSurvey('draft-1').subscribe(value => loaded = value);

    expect(listCallDatasetService.getDataSetDetails).toHaveBeenCalledWith('EU');
    expect(surveyCommonService.setRefreshedDate.mock.calls).toEqual([[null], ['Sep 30, 2026']]);
    expect(loaded).toBe(saved);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenLastCalledWith(false);
  });

  it('reuses saved requestInstance refreshedOn and skips dataset details API', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    surveyCommonService.getRefreshedDate.mockReturnValue(null);
    surveyCommonService.getSelectedDatasetConfig.mockReturnValue(null);
    const refreshedOn = String(Date.UTC(2026, 8, 30));
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'EU', refreshedOn } },
    };
    httpClient.post.mockReturnValue(of({ data: saved }));

    service.loadSurvey('draft-1').subscribe();

    expect(listCallDatasetService.getDataSetDetails).not.toHaveBeenCalled();
    expect(surveyCommonService.setRefreshedDate.mock.calls).toEqual([[null], ['Sep 30, 2026']]);
  });

  it('reuses matching selected dataset refreshedOn and skips dataset details API', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    surveyCommonService.getRefreshedDate.mockReturnValue(null);
    surveyCommonService.getSelectedDatasetConfig.mockReturnValue({
      id: 'dataset-1',
      stackId: 'EU',
      refreshedOn: String(Date.UTC(2026, 8, 29)),
    });
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'EU' } },
    };
    httpClient.post.mockReturnValue(of({ data: saved }));

    service.loadSurvey('draft-1').subscribe();

    expect(listCallDatasetService.getDataSetDetails).not.toHaveBeenCalled();
    expect(surveyCommonService.setRefreshedDate.mock.calls).toEqual([[null], ['Sep 29, 2026']]);
  });

  it('falls back to dataset details API when selected dataset does not match request instance', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    surveyCommonService.getRefreshedDate.mockReturnValue(null);
    surveyCommonService.getSelectedDatasetConfig.mockReturnValue({
      id: 'dataset-2',
      stackId: 'EU',
      refreshedOn: String(Date.UTC(2026, 8, 29)),
    });
    const saved = {
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'EU' } },
    };
    httpClient.post.mockReturnValue(of({ data: saved }));
    listCallDatasetService.getDataSetDetails.mockReturnValue(of({ PANEL_OD_OMNI: [
      { id: 'dataset-1', stackId: 'EU', refreshedOn: String(Date.UTC(2026, 8, 30)) },
    ] }));

    service.loadSurvey('draft-1').subscribe();

    expect(listCallDatasetService.getDataSetDetails).toHaveBeenCalledWith('EU');
    expect(surveyCommonService.setRefreshedDate.mock.calls).toEqual([[null], ['Sep 30, 2026']]);
  });

  it('keeps the draft usable when dataset metadata cannot be fetched', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    const saved = { ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'EU' } } };
    httpClient.post.mockReturnValue(of({ data: saved }));
    listCallDatasetService.getDataSetDetails.mockReturnValue(throwError(() => new Error('Dataset unavailable')));
    let loaded: unknown;

    service.loadSurvey('draft-1').subscribe(value => loaded = value);

    expect(loaded).toBe(saved);
    expect(surveyCommonService.setRefreshedDate).toHaveBeenCalledExactlyOnceWith(null);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenLastCalledWith(false);
  });

  it.each([
    {},
    null,
    { PANEL_OD_OMNI: [{ id: 'dataset-1', stackId: 'EU' }] },
    { PANEL_OD_OMNI: [{ id: 'dataset-1', stackId: 'EU', refreshedOn: '' }] },
    { PANEL_OD_OMNI: [{ id: 'dataset-1', stackId: 'EU', refreshedOn: 'invalid' }] },
    { PANEL_OD_OMNI: [{ id: 'dataset-1', stackId: 'US', refreshedOn: Date.UTC(2026, 8, 30) }] },
  ])('clears the previous refresh date for unavailable or invalid metadata %j', datasets => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    const saved = { ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      reportDetail: { requestInstance: { datasetId: 'dataset-1', datasetStackId: 'EU' } } };
    httpClient.post.mockReturnValue(of({ data: saved }));
    listCallDatasetService.getDataSetDetails.mockReturnValue(of(datasets));
    let loaded: unknown;

    service.loadSurvey('draft-1').subscribe(value => loaded = value);

    expect(loaded).toBe(saved);
    expect(surveyCommonService.setRefreshedDate).toHaveBeenCalledExactlyOnceWith(null);
  });

  it('skips dataset lookup and clears the previous date when the saved draft has no dataset identifier', () => {
    const { service, httpClient, surveyCommonService, listCallDatasetService } = createService();
    httpClient.post.mockReturnValue(of({ data: service.buildSurveyPayload(SurveyStatusType.DRAFT) }));

    service.loadSurvey('draft-1').subscribe();

    expect(listCallDatasetService.getDataSetDetails).not.toHaveBeenCalled();
    expect(surveyCommonService.setRefreshedDate).toHaveBeenCalledExactlyOnceWith(null);
  });

  it('updates title and selected question type', () => {
    const { service } = createService();

    service.updateTitle('Customer survey');
    service.setQuestionType(QuestionTypes.Text);

    expect(service.title()).toBe('Customer survey');
    expect(service.getQuestionType()).toBe(QuestionTypes.Text);
  });

  it('adds, normalizes, updates, and removes questions', () => {
    const { service } = createService();

    service.addQuestion(question({ question: '  First  ', options: [null, ' B '] }));
    service.addQuestion(question({ question: 'Second', type: QuestionTypes.Text }));
    service.updateQuestionField(0, 'question', ' Updated ');
    service.updateOptionField(0, 1, 'Changed');
    service.removeQuestion(1);

    expect(service.getQuestions()).toEqual([{
      questionNumber: 1,
      question: 'Updated',
      options: ['', 'Changed'],
      rowOptions: [],
      columnOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
      isRequired: false,
      type: QuestionTypes.SingleChoice,
    }]);
  });

  it('uses safe defaults for incomplete questions', () => {
    const { service } = createService();

    service.addQuestion({ question: null, isRequired: 0, type: null } as any);

    expect(service.getQuestions()[0]).toEqual({
      questionNumber: 1,
      question: '',
      options: [],
      rowOptions: [],
      columnOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
      isRequired: false,
      type: '',
    });
  });

  it('preserves reviewRequired when adding a question', () => {
    const { service } = createService();

    service.addQuestion(question({ reviewRequired: true }));

    expect(service.getQuestions()[0].reviewRequired).toBe(true);
  });

  it('normalizes an explicit questionNumber to the next sequential value', () => {
    const { service } = createService();

    service.addQuestion(question({ questionNumber: 7 }));

    expect(service.getQuestions()).toHaveLength(1);
    expect(service.getQuestions()[0].questionNumber).toBe(1);
  });

  it('renumbers questions when set directly', () => {
    const { service } = createService();

    service.setQuestions([question({ questionNumber: 99 }), question({ questionNumber: 4 })]);

    expect(service.getQuestions().map(item => item.questionNumber)).toEqual([1, 2]);
  });

  it('manages drafts and remaps them after deletion', () => {
    const { service } = createService();
    service.saveDraft(0, { question: 'First draft' });
    service.saveDraft(2, { question: 'Third draft' });

    expect(service.getDraft(0)).toEqual({ question: 'First draft' });
    service.removeQuestion(1);

    expect(service.getDraft(0)).toEqual({ question: 'First draft' });
    expect(service.getDraft(1)).toEqual({ question: 'Third draft' });
    service.clearDraft(0);
    service.clearAllDrafts();
    expect(service.getDraft(1)).toBeUndefined();
  });

  it('remaps drafts in both reorder directions', () => {
    const { service } = createService();
    service.saveDraft(0, { question: 'Moved down' });
    service.saveDraft(2, { question: 'Shifted up' });
    service.remapDraftsAfterReorder(0, 2);
    expect(service.getDraft(2)).toEqual({ question: 'Moved down' });
    expect(service.getDraft(1)).toEqual({ question: 'Shifted up' });

    service.remapDraftsAfterReorder(2, 0);
    expect(service.getDraft(0)).toEqual({ question: 'Moved down' });
    expect(service.getDraft(2)).toEqual({ question: 'Shifted up' });
  });

  it('keeps unaffected drafts at their original index', () => {
    const { service } = createService();
    service.saveDraft(3, { question: 'Unchanged draft' });

    service.remapDraftsAfterReorder(0, 2);

    expect(service.getDraft(3)).toEqual({ question: 'Unchanged draft' });
  });

  it.each([
    QuestionTypes.SingleChoice,
    QuestionTypes.MultipleChoice,
    QuestionTypes.StarRating,
    QuestionTypes.NetPromoterScore,
    QuestionTypes.SinglePointScale,
    QuestionTypes.MultiplePointScale,
    QuestionTypes.Text,
  ])('clears the selected type after deleting the last %s question', type => {
    const { service } = createService();
    service.setQuestionType(type);
    service.addQuestion(question({ type }));
    service.saveDraft(0, { question: 'Draft' });

    service.removeQuestion(0);

    expect(service.getQuestions()).toEqual([]);
    expect(service.getQuestionType()).toBe('');
    expect(service.getDraft(0)).toBeUndefined();

    service.setQuestionType(type);
    service.addQuestion(question({ type, question: 'Replacement question' }));
    expect(service.getQuestions()[0]).toEqual(expect.objectContaining({
      type, question: 'Replacement question', questionNumber: 1,
    }));
  });

  it('preserves the selected type while other questions remain after deletion', () => {
    const { service } = createService();
    service.setQuestionType(QuestionTypes.SingleChoice);
    service.addQuestion(question());
    service.addQuestion(question({ question: 'Remaining question' }));

    service.removeQuestion(0);

    expect(service.getQuestionType()).toBe(QuestionTypes.SingleChoice);
    expect(service.getQuestions()[0]).toEqual(expect.objectContaining({
      question: 'Remaining question', questionNumber: 1,
    }));
  });

  it('resets questions, drafts, and selected type', () => {
    const { service } = createService();
    service.addQuestion(question());
    service.saveDraft(0, { question: 'Draft' });
    service.setQuestionType(QuestionTypes.Text);

    service.reset();

    expect(service.questions()).toEqual([]);
    expect(service.getDraft(0)).toBeUndefined();
    expect(service.getQuestionType()).toBe('');
  });

  it('clears survey A state before loading survey B in the same service instance', () => {
    const { service, httpClient, surveyCommonService, runReportService, validationService } = createService();
    const savedSurvey = (surveyId: string, type: (typeof QuestionTypes)[keyof typeof QuestionTypes]) => ({
      ...service.buildSurveyPayload(SurveyStatusType.DRAFT),
      surveyId,
      name: surveyId,
      assetInfo: { assetId: `asset-${surveyId}`, title: surveyId, parameters: { dataViewId: `view-${surveyId}` } },
      questions: [],
      metadata: { questionTypes: [type], userPrompts: [`Prompt ${surveyId}`] },
      reportInfo: { jobId: `job-${surveyId}` },
    });
    const surveyA = savedSurvey('survey-a', QuestionTypes.SingleChoice);
    const surveyB = savedSurvey('survey-b', QuestionTypes.Text);
    httpClient.post.mockReturnValueOnce(of({ data: surveyA })).mockReturnValueOnce(of({ data: surveyB }));

    service.loadSurvey('survey-a').subscribe();
    validationService.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    validationService.surveySuggestionState.set(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
    service.genState.set('done');
    service.repromptLoading.set(true);
    service.setDuplicateFromId('survey-a');
    service.saveDraft(0, { question: 'Unsaved survey A question' });
    service.setQuestionType(QuestionTypes.SingleChoice);

    service.reset();

    expect(service.title()).toBe('Untitled Survey');
    expect(validationService.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
    expect(validationService.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);
    expect(service.genState()).toBe('idle');
    expect(service.repromptLoading()).toBe(false);
    expect(service.questionTypes()).toEqual([]);
    expect(service.questions()).toEqual([]);
    expect(service.loadedSurveyDetails()).toBeNull();
    expect(service.currentSurveyId).toBeNull();
    expect(service.currentAssetIdValue).toBeNull();
    expect(service.currentDataViewIdValue).toBeNull();
    expect(service.getSelectedFolder()).toBeNull();
    expect(service.getDuplicateFromId()).toBeNull();
    expect(service.getDraft(0)).toBeUndefined();
    expect(service.getQuestionType()).toBe('');
    expect(runReportService.reset).toHaveBeenCalledOnce();

    service.loadSurvey('survey-b').subscribe();

    expect(service.loadedSurveyDetails()).toBe(surveyB);
    expect(service.currentSurveyId).toBe('survey-b');
    expect(service.title()).toBe('survey-b');
    expect(service.questionTypes()).toEqual([QuestionTypes.Text]);
    expect(service.currentAssetIdValue).toBe('asset-survey-b');
    expect(service.currentDataViewIdValue).toBe('view-survey-b');
    expect(service.getDuplicateFromId()).toBeNull();
    expect(validationService.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION);
    expect(surveyCommonService.getSurveySessionState().userPrompt).toBe('Prompt survey-b');
    expect(runReportService.lastJobId).toBe('job-survey-b');
  });

  it('saves and restores My Assets without sending its UI ID', () => {
    const { service } = createService();
    service.setSelectedFolder({ folderId: MY_ASSETS_ROOT.assetId, name: MY_ASSETS_ROOT.title });
    for (const status of [SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED]) {
      expect(service.buildSurveyPayload(status).folder).toEqual({ name: 'My Assets', folderId: '' });
    }
    service.restoreSurveyState({
      name: 'Survey',
      assetInfo: { assetId: 'asset-root' },
      questions: [],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: '' },
      panelists: { targetCompletes: 0 },
    });
    expect(service.getSelectedFolder()).toEqual({ folderId: MY_ASSETS_ROOT.assetId, name: MY_ASSETS_ROOT.title });
  });

  it.each([SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED])('sends single-point scale rows and columns for %s', status => {
    const { service } = createService();
    const payload = service.createSaveDraftPayload({
      title: 'Scale survey', surveyId: 'survey-1', userPrompt: '', status,
      questions: [{ questionNumber: 1, question: 'Rate quality', type: QuestionTypes.SinglePointScale,
        isRequired: true, options: [], rowOptions: ['Quality'], columnOptions: ['Low', 'High'] }],
    });
    expect(payload.questions[0].answerSpec).toEqual({
      rows: [{ value: 'quality', label: 'Quality' }],
      columns: [{ value: 'low', label: 'Low' }, { value: 'high', label: 'High' }],
    });
    expect(payload.questions[0].validation).toEqual({ minSelections: 1, maxSelections: 1 });
  });

  it.each([{}, { folderId: '', name: '' }, { folderId: null, name: null }, null, undefined])('restores root assets with folder %j as My Assets', folder => {
    const { service } = createService();
    service.restoreSurveyState({
      name: 'Root survey', assetInfo: { assetId: 'asset-root' }, folder,
      questions: [], metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: '' }, panelists: { targetCompletes: 0 },
    } as any);
    expect(service.getSelectedFolder()).toEqual({ folderId: MY_ASSETS_ROOT.assetId, name: MY_ASSETS_ROOT.title });
    for (const status of [SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED]) {
      expect(service.buildSurveyPayload(status).folder).toEqual({ name: 'My Assets', folderId: '' });
    }
  });

  it.each([SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED])('omits deprecated folder type for subfolder %s requests', status => {
    const { service } = createService();
    service.setSelectedFolder({ folderId: 'folder-1', name: 'Research' });
    expect(service.buildSurveyPayload(status).folder).toEqual({ folderId: 'folder-1', name: 'Research' });
  });

  it.each([{}, { folderId: '', name: '' }, null, undefined])('does not select My Assets for an unsaved survey with folder %j', folder => {
    const { service } = createService();
    service.restoreSurveyState({
      name: 'Unsaved survey', folder, questions: [],
      metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: '' }, panelists: { targetCompletes: 0 },
    } as any);
    expect(service.getSelectedFolder()).toBeNull();
  });

  it('stores the current survey assetId', () => {
    const { service } = createService();

    expect(service.currentAssetIdValue).toBeNull();
    service.currentAssetIdValue = 'asset-1';
    expect(service.currentAssetIdValue).toBe('asset-1');
    service.currentAssetIdValue = null;
    expect(service.currentAssetIdValue).toBeNull();
  });

  it('validates question text, choice options, and scale matrices', () => {
    expect(isQuestionTextValid('  text ')).toBe(true);
    expect(isQuestionTextValid('  ')).toBe(false);
    expect(isChoiceOptionsValid(['A', 'B'])).toBe(true);
    expect(isChoiceOptionsValid(['A'])).toBe(false);
    expect(isChoiceOptionsValid(['A', ' '])).toBe(false);
    expect(isScaleMatrixValid(['Row 1', 'Row 2'], ['Low', 'High'])).toBe(true);
    expect(isScaleMatrixValid(['Row 1'], ['Low', 'High'])).toBe(false);
    expect(isScaleMatrixValid(['Row 1', 'Row 2'], [' '])).toBe(false);
  });

  it('clears non-array option values during field updates', () => {
    const { service } = createService();
    service.addQuestion(question());

    service.updateQuestionField(0, 'options', 'invalid');

    expect(service.getQuestions()[0].options).toEqual([]);
  });

  it('preserves generic field values during updates', () => {
    const { service } = createService();
    service.addQuestion(question());

    service.updateQuestionField(0, 'questionNumber', 7);

    expect(service.getQuestions()[0].questionNumber).toBe(1);
  });

  it('validates question types and complete questions', () => {
    const question_ = (overrides: Record<string, unknown> = {}) => ({
      question: 'Question',
      options: ['A', 'B'],
      isRequired: false,
      type: QuestionTypes.SingleChoice,
      ...overrides,
    });

    expect(isChoiceType(QuestionTypes.MultipleChoice)).toBe(true);
    expect(isChoiceType(QuestionTypes.Text)).toBe(false);
    expect(isScaleType(QuestionTypes.SinglePointScale)).toBe(true);
    expect(isScaleType(QuestionTypes.Text)).toBe(false);
    expect(isQuestionValid({ question: '' })).toBe(false);
    expect(isQuestionValid(question_())).toBe(true);
    expect(isQuestionValid(question_({ options: ['A'] }))).toBe(false);
    expect(isQuestionValid(question_({ type: QuestionTypes.Text }))).toBe(true);
    expect(isQuestionValid(question_({
      type: QuestionTypes.SinglePointScale,
      rowOptions: ['Low', 'High'],
      columnOptions: ['Poor', 'Good'],
    }))).toBe(true);
  });

  it('handles null validation inputs and unknown question types', () => {
    expect(isChoiceOptionsValid(null)).toBe(false);
    expect(isScaleMatrixValid(null, null)).toBe(false);
    expect(isQuestionValid({ question: 'Question', type: 'UNKNOWN' })).toBe(true);
  });

  it('remaps indexes correctly for delete and reorder operations', () => {
    const { service } = createService();

    expect(service.remapIndexAfterDelete(null, 1)).toBeNull();
    expect(service.remapIndexAfterDelete(1, 1)).toBeNull();
    expect(service.remapIndexAfterDelete(3, 1)).toBe(2);
    expect(service.remapIndexAfterDelete(0, 1)).toBe(0);

    expect(service.remapIndexAfterReorder(0, 0, 2)).toBe(2);
    expect(service.remapIndexAfterReorder(1, 0, 2)).toBe(0);
    expect(service.remapIndexAfterReorder(2, 0, 2)).toBe(1);
    expect(service.remapIndexAfterReorder(2, 2, 0)).toBe(0);
    expect(service.remapIndexAfterReorder(0, 2, 0)).toBe(1);
    expect(service.remapIndexAfterReorder(3, 2, 0)).toBe(3);
  });

  it('extracts and normalizes rephrased responses from supported shapes', () => {
    const currentQuestion = question({
      questionNumber: 4,
      type: QuestionTypes.SingleChoice,
      options: ['Keep option'],
    });

    expect(extractRephrasedQuestion({ result: { question: 'From result' } })).toEqual({ question: 'From result' });
    expect(extractRephrasedQuestion({ question: { question: 'From nested' } })).toEqual({ question: 'From nested' });
    expect(extractRephrasedQuestion({ result: { question: { question: 'From nested result' } } })).toEqual({ question: 'From nested result' });
    expect(extractRephrasedQuestion([{ question: 'From array' }])).toEqual({ question: 'From array' });
    expect(extractRephrasedQuestion({ result: [null] })).toBeNull();
    expect(extractRephrasedQuestion({ result: ['plain-text'] })).toBeNull();
    expect(extractRephrasedQuestion('plain-text')).toBeNull();
    expect(extractRephrasedQuestion({ invalid: true })).toBeNull();

    const choice = normalizeRephrasedQuestion(
      { question: '  Choice ', type: QuestionTypes.SingleChoice, options: [' A ', null] },
      currentQuestion as any,
      0
    );
    expect(choice).toEqual(expect.objectContaining({
      questionNumber: 4,
      question: 'Choice',
      type: QuestionTypes.SingleChoice,
      options: ['A', ''],
    }));

    const scale = normalizeRephrasedQuestion(
      { question: 'Scale', type: QuestionTypes.SinglePointScale, rowOptions: [' R '], columnOptions: [' C '] },
      question({
        type: QuestionTypes.SinglePointScale,
        rowOptions: ['Keep row'],
        columnOptions: ['Keep col'],
      }) as any,
      1
    );
    expect(scale).toEqual(expect.objectContaining({
      rowOptions: ['R'],
      columnOptions: ['C'],
    }));

    const nps = normalizeRephrasedQuestion(
      { question: 'NPS', type: QuestionTypes.NetPromoterScore, npsLeftLabel: ' Left ', npsRightLabel: ' Right ' },
      question({ type: QuestionTypes.NetPromoterScore }) as any,
      2
    );
    expect(nps).toEqual(expect.objectContaining({
      npsLeftLabel: 'Left',
      npsRightLabel: 'Right',
    }));
  });

  it('returns null for object-shaped rephrase responses without a string question', () => {
    expect(extractRephrasedQuestion({ result: { question: 100 } as any })).toBeNull();
    expect(extractRephrasedQuestion({ question: { question: 100 } as any })).toBeNull();
    expect(extractRephrasedQuestion({ result: [{ question: 100 }] })).toBeNull();
  });

  it('falls back to current scale fields and normalizes non-string NPS labels', () => {
    const scaleFallback = normalizeRephrasedQuestion(
      { question: 'Scale fallback', type: QuestionTypes.SinglePointScale, rowOptions: null as any, columnOptions: undefined as any },
      question({
        type: QuestionTypes.SinglePointScale,
        rowOptions: ['Existing row'],
        columnOptions: ['Existing col'],
      }) as any,
      0
    );

    expect(scaleFallback).toEqual(expect.objectContaining({
      rowOptions: ['Existing row'],
      columnOptions: ['Existing col'],
    }));

    const npsFallback = normalizeRephrasedQuestion(
      { question: 'NPS fallback', type: QuestionTypes.NetPromoterScore, npsLeftLabel: 1 as any, npsRightLabel: null as any },
      question({ type: QuestionTypes.NetPromoterScore }) as any,
      1
    );

    expect(npsFallback).toEqual(expect.objectContaining({
      npsLeftLabel: '',
      npsRightLabel: '',
    }));
  });

  it('falls back to empty scale arrays when no current question exists', () => {
    const normalized = normalizeRephrasedQuestion(
      { question: 'Scale fallback', type: QuestionTypes.SinglePointScale, rowOptions: undefined as any, columnOptions: undefined as any },
      undefined,
      0
    );

    expect(normalized).toEqual(expect.objectContaining({
      rowOptions: [],
      columnOptions: [],
    }));
  });

  it('trims rephrased question and maps scale arrays from extracted values', () => {
    const normalized = normalizeRephrasedQuestion(
      {
        result: {
          question: '  Scale trimmed  ',
          type: QuestionTypes.SinglePointScale,
          rowOptions: [' R1 ', null],
          columnOptions: [' C1 ', undefined],
        }
      },
      undefined,
      0
    );

    expect(normalized).toEqual(expect.objectContaining({
      question: 'Scale trimmed',
      rowOptions: ['R1', ''],
      columnOptions: ['C1', ''],
    }));
  });

  it('returns null when rephrase extraction fails during normalization', () => {
    const normalized = normalizeRephrasedQuestion({ invalid: true }, undefined, 0);

    expect(normalized).toBeNull();
  });

  it('falls back to empty choice options when extracted options are invalid and current options missing', () => {
    const normalized = normalizeRephrasedQuestion(
      { question: 'Choice fallback', type: QuestionTypes.SingleChoice, options: 'invalid' as any },
      question({ type: QuestionTypes.SingleChoice, options: undefined as any }) as any,
      0
    );

    expect(normalized).toEqual(expect.objectContaining({
      options: [],
    }));
  });

  it('keeps default option arrays for non-choice and non-scale normalization types', () => {
    const normalized = normalizeRephrasedQuestion(
      { question: 'Text question', type: QuestionTypes.Text },
      question({ type: QuestionTypes.Text, options: ['A'], rowOptions: ['R'], columnOptions: ['C'] } as any),
      0
    );

    expect(normalized).toEqual(expect.objectContaining({
      options: [],
      rowOptions: [],
      columnOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
    }));
  });

  it('normalizes with undefined current question using extracted choice fields', () => {
    const normalized = normalizeRephrasedQuestion(
      { question: ' Choice ', type: QuestionTypes.SingleChoice, options: [' A ', null] },
      undefined,
      2
    );

    expect(normalized).toEqual(expect.objectContaining({
      questionNumber: 3,
      question: 'Choice',
      type: QuestionTypes.SingleChoice,
      options: ['A', ''],
    }));
  });

  it('builds add-more payloads with existing question titles excluded', () => {
    const { service } = createService();
    service.setQuestions([
      question({ question: ' First question ' }),
      question({ question: '   ' }),
    ]);

    const payload = service.buildAddMoreQuestionsPayload(
      'More questions',
      [QuestionTypes.Text],
      { DEMO: ['Adults'], GEO: ['US'] },
      5,
    );

    expect(payload.prompt.questionCount).toBe(5);
    expect(payload.prompt.excludeQuestions).toEqual([{ text: 'First question' }]);
    expect(payload.prompt.demographic).toBe('Adults');
    expect(payload.prompt.geography).toBe('US');
  });

  it('uses the AI response title for the header and saved survey in AI flow', () => {
    const { service, httpClient, surveyCommonService } = createService();
    surveyCommonService.flowType.mockReturnValue({ [FLOW_TYPES.AIFLOW]: true } as any);
    httpClient.post.mockReturnValue(of({ title: '  Shopper purchase drivers  ', result: [question()] }));

    service.generateQuestions({ prompt: {} } as any).subscribe();

    expect(service.title()).toBe('Shopper purchase drivers');
    expect(service.getQuestions()).toEqual([question()]);
    const payload = service.buildSurveyPayload(SurveyStatusType.DRAFT);
    expect(payload.name).toBe('Shopper purchase drivers');
    expect(payload.assetInfo.title).toBe('Shopper purchase drivers');
  });

  it.each([undefined, null, '', '   ', 123])('preserves the current AI survey title when the response title is %s', title => {
    const { service, httpClient, surveyCommonService } = createService();
    surveyCommonService.flowType.mockReturnValue({ [FLOW_TYPES.AIFLOW]: true } as any);
    service.updateTitle('Existing title');
    httpClient.post.mockReturnValue(of({ title, result: [question()] }));

    service.generateQuestions({ prompt: {} } as any).subscribe();

    expect(service.getTitle()).toBe('Existing title');
    expect(service.getQuestions()).toEqual([question()]);
  });

  it('does not apply the generated title outside AI flow', () => {
    const { service, httpClient } = createService();
    service.updateTitle('Scratch survey');
    httpClient.post.mockReturnValue(of({ title: 'AI title', result: [question()] }));

    service.generateQuestions({ prompt: {} } as any).subscribe();

    expect(service.getTitle()).toBe('Scratch survey');
  });

  it('does not apply the AI title or questions for utility generation', () => {
    const { service, httpClient, surveyCommonService } = createService();
    surveyCommonService.flowType.mockReturnValue({ [FLOW_TYPES.AIFLOW]: true } as any);
    service.updateTitle('Existing title');
    httpClient.post.mockReturnValue(of({ title: 'Utility title', result: [question()] }));

    service.generateQuestions({ prompt: {} } as any, true).subscribe();

    expect(service.getTitle()).toBe('Existing title');
    expect(service.getQuestions()).toEqual([]);
  });

  it('stores generated and added questions from HTTP results', () => {
    const { service, httpClient } = createService();
    const generated = [question({ question: 'Generated' })];
    httpClient.post.mockReturnValueOnce(of({ result: generated }));
    service.generateQuestions({ prompt: {} } as any).subscribe();
    expect(service.getQuestions()).toEqual(generated);

    httpClient.post.mockReturnValueOnce(of({ result: [question({ question: 'Added' })] }));
    service.addMoreQuestions({ prompt: {} } as any).subscribe();
    expect(service.getQuestions().map(item => item.question)).toEqual(['Generated', 'Added']);
  });

  it('flags AI-added questions from addMoreQuestions as reviewRequired since they are not yet validated', () => {
    const { service, httpClient } = createService();
    httpClient.post.mockReturnValueOnce(of({ result: [question({ question: 'Generated' })] }));
    service.generateQuestions({ prompt: {} } as any).subscribe();

    httpClient.post.mockReturnValueOnce(of({ result: [question({ question: 'Added' })] }));
    service.addMoreQuestions({ prompt: {} } as any).subscribe();

    const [generatedQuestion, addedQuestion] = service.getQuestions();
    expect(generatedQuestion.reviewRequired).toBeUndefined();
    expect(addedQuestion.reviewRequired).toBe(true);
  });

  it.each([null, undefined, { result: 'invalid' }, { result: 42 }, { result: {} }])(
    'does not mutate questions when the add-more response is malformed (%j)', response => {
      const { service, httpClient } = createService();
      service.setQuestions([question({ question: 'Existing question' })]);
      const existingQuestions = structuredClone(service.getQuestions());
      const errorHandler = vi.fn();
      const nextHandler = vi.fn();
      const setQuestions = vi.spyOn(service, 'setQuestions');
      httpClient.post.mockReturnValue(of(response));

      service.addMoreQuestions({ prompt: {} } as any).subscribe({ next: nextHandler, error: errorHandler });

      expect(service.getQuestions()).toEqual(existingQuestions);
      expect(setQuestions).not.toHaveBeenCalled();
      expect(nextHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalledWith(
        expect.objectContaining({ message: 'Invalid response while adding more questions: result must be an array' })
      );
    }
  );

  it.each([{}, { result: null }, { result: [] }])('normalizes empty add-more results (%j)', response => {
    const { service, httpClient } = createService();
    service.setQuestions([question()]);
    const existingQuestions = structuredClone(service.getQuestions());
    const nextHandler = vi.fn();
    httpClient.post.mockReturnValue(of(response));

    service.addMoreQuestions({ prompt: {} } as any).subscribe(nextHandler);

    expect(nextHandler).toHaveBeenCalledExactlyOnceWith({ result: [] });
    expect(service.getQuestions()).toEqual(existingQuestions);
  });

  it('handles empty HTTP result collections', () => {
    const { service, httpClient } = createService();
    httpClient.post.mockReturnValue(of({}));

    service.generateQuestions({ prompt: {} } as any).subscribe();
    service.addMoreQuestions({ prompt: {} } as any).subscribe();

    expect(service.getQuestions()).toEqual([]);
  });

  it('calls generateQuestions endpoint and completes pipeline', () => {
    const { service, httpClient } = createService();
    httpClient.post.mockReturnValue(of({ result: [question({ question: 'Generated A' })] }));

    service.generateQuestions({ prompt: {} } as any).subscribe();

    expect(httpClient.post).toHaveBeenCalledWith(expect.stringMatching(/\/generate-questions$/), expect.anything(), expect.anything());
    expect(service.getQuestions()[0].question).toBe('Generated A');
  });

  it('requests generated questions without changing shared question state', () => {
    const { service, httpClient } = createService();
    service.setQuestions([question({ question: 'Existing question' })]);
    httpClient.post.mockReturnValue(of({ result: [question({ question: 'Validator question' })] }));

    service.generateQuestions({ prompt: {} } as any, true).subscribe();

    expect(httpClient.post).toHaveBeenCalledWith(
      expect.stringContaining('/utils/generate-questions-with-prompts'),
      expect.anything(),
      expect.anything(),
    );
    expect(service.getQuestions()[0].question).toBe('Existing question');
  });

  it('rephrases questions and resets reprompt loading', () => {
    const { service, httpClient } = createService();
    httpClient.post.mockReturnValue(of({ result: question({ question: 'Rephrased' }) }));

    service.rephraseQuestions({ question: question(), userPrompt: 'Improve' }).subscribe();
    expect(httpClient.post).toHaveBeenCalled();

    httpClient.post.mockReturnValue(of({ result: [] }));
    service.submitAddMoreQuestions('More', [QuestionTypes.Text], { DEMO: ['Adults'] }).subscribe();
    expect(service.repromptLoading()).toBe(false);
  });

  it('creates complete and fallback save payloads', () => {
    const { service } = createService();
    const questions = [
      question({ type: QuestionTypes.SingleChoice, isRequired: true, question: ' Pick one ', options: [' A ', null, ''] }),
      question({ type: QuestionTypes.MultipleChoice, isRequired: true }),
      question({ type: QuestionTypes.NetPromoterScore, npsLeftLabel: '', npsRightLabel: 'Great' }),
      question({ type: QuestionTypes.StarRating }),
      question({ type: QuestionTypes.SinglePointScale, columnOptions: ['Low', 'High'], options: ['Fallback'] }),
      question({ type: QuestionTypes.SinglePointScale, columnOptions: [], options: ['Fallback'] }),
      question({ type: QuestionTypes.MultiplePointScale, rowOptions: ['R1'], columnOptions: ['C1'] }),
      question({ type: QuestionTypes.Text }),
      question({ question: '   ' }),
    ] as any;

    const payload = service.createSaveDraftPayload({
      title: ' Survey ',
      questions,
      userPrompt: ' Prompt ',
      status: SurveyStatusType.DRAFT,
      surveyId: 'survey-1',
      dynamics: {
        targetCompletes: 20, reportJobId: 'job', panelistJobId: 'panel-job', dataViewId: ' view ',
        userId: 'user', clientId: 'client', emailId: 'mail', applicationId: 'app', locale: 'fr-FR',
      },
      rights: [{ role: 'OWNER' }],
      assetId: 'asset-1',
    });

    expect(payload.name).toBe('Survey');
    expect(payload.metadata).toEqual({ questionTypes: [], source: 'DISCOVER-UI', userPrompts: ['Prompt'] });
    expect(payload.assetInfo.assetId).toBe('asset-1');
    expect(payload.assetInfo.launchURL).toBe('survey/build-survey/survey-1');
    expect(payload.questions).toHaveLength(8);
    expect(payload.panelists).toEqual({
      targetCompletes: 20,
      maxResponsesPerPanelist: 1,
    });
    expect(payload).not.toHaveProperty('behavior');
    expect(payload.folder).toEqual({ name: '', folderId: '' });
    expect(payload.metadata).toHaveProperty('questionTypes');
    expect(payload.panelists).not.toHaveProperty('mode');
    expect(payload.panelists).not.toHaveProperty('savedSegmentId');
    expect(payload.panelists).not.toHaveProperty('explicitNIQPanelistIds');
    expect(payload.folder).not.toHaveProperty('createIfMissing');
    expect(payload.folder).not.toHaveProperty('onFailure');
    expect(payload.questions[0]).toEqual(expect.objectContaining({
      id: 'q_1',
      order: '1',
      prompt: { text: 'Pick one', helpText: null },
    }));
    expect(payload.questions[0]).not.toHaveProperty('key');
    expect(payload.questions[0]).not.toHaveProperty('widget');
    expect(payload.questions[0]).not.toHaveProperty('layout');
    expect(payload.questions[0]).not.toHaveProperty('logic');
    expect(payload.questions[0]).not.toHaveProperty('tags');
    expect(payload.questions[0].prompt).not.toHaveProperty('mediaUrl');
    expect(payload.questions.every(questionPayload => !('scaleKind' in questionPayload))).toBe(true);
    expect(payload.delivery).toEqual({
      invitesSent: 0,
      channels: [],
      schedule: { openAt: null, closeAt: null, timezone: null },
    });

    const fallback = service.createSaveDraftPayload({
      title: null as any,
      questions: null as any,
      userPrompt: null as any,
      status: undefined,
      surveyId: 'survey-2',
      dynamics: undefined,
      rights: undefined,
      assetId: undefined,
    });
    expect(fallback.name).toBe('Untitled Survey');
    expect(fallback.description).toBe('Untitled Survey');
    expect(fallback.metadata.userPrompts).toEqual([]);
    expect(fallback.questions).toEqual([]);
    expect(fallback.assetInfo).not.toHaveProperty('assetId');
  });

  it('maps optional values for payload branches when values are nullish', () => {
    const { service } = createService();
    const payload = service.createSaveDraftPayload({
      title: null as any,
      questions: null as any,
      userPrompt: null as any,
      status: undefined,
      surveyId: 'survey-2',
      dynamics: undefined,
      rights: undefined,
      assetId: undefined,
    });
    expect(payload.panelists).toEqual({
      targetCompletes: 0,
      maxResponsesPerPanelist: 1,
    });
  });

  it('uses aiflow launch url when active flow is aiflow', () => {
    const { service, surveyCommonService } = createService();
    (surveyCommonService.flowType as ReturnType<typeof vi.fn>).mockReturnValue({
      [FLOW_TYPES.IMPORT]: false,
      [FLOW_TYPES.SCRATCH]: false,
      [FLOW_TYPES.AIFLOW]: true,
      [FLOW_TYPES.TEMPLATE]: false,
    });

    const payload = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [question()],
      userPrompt: 'Prompt',
      status: SurveyStatusType.DRAFT,
      surveyId: 'survey-1',
    });

    expect(payload.assetInfo.launchURL).toBe('survey/aiflow/build-survey/survey-1');
  });

  it('maps launchURL from the active route without query parameters or fragments', () => {
    const { service } = createService('/survey/aiflow/build-survey?surveyId=123#questions');

    const payload = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [],
      userPrompt: '',
      status: SurveyStatusType.DRAFT,
      surveyId: 'survey-1',
    });

    expect(payload.assetInfo.launchURL).toBe('survey/build-survey/survey-1');
  });

  it('uses the configured launch URL when the active route is empty', () => {
    const { service } = createService('/');

    const payload = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [],
      userPrompt: '',
      status: SurveyStatusType.DRAFT,
      surveyId: 'survey-1',
    });

    expect(payload.assetInfo.launchURL).toBe('survey/build-survey/survey-1');
  });

  it('uses the launch URL fallback when the active route only contains query data', () => {
    const { service } = createService('?surveyId=123');

    const payload = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [],
      userPrompt: '',
      status: SurveyStatusType.DRAFT,
      surveyId: 'survey-1',
    });

    expect(payload.assetInfo.launchURL).toBe('survey/build-survey/survey-1');
  });

  it('maps options and rejects unsupported questions safely', () => {
    createService();

    expect(toApiOptions(undefined)).toEqual([]);
    expect(stringFormat('***', 'fallback')).toBe('fallback');
    expect(() => toApiQuestion(question({ type: 'UNKNOWN' }) as any, 0)).toThrow('Unsupported question type');
  });

  it('generates, reuses, sets, and clears the survey id', () => {
    const { service } = createService();
    const generated = service.getSurveyId();
    expect(generated.startsWith(SURVEY_ID_PREFIX)).toBe(true);
    expect(service.getSurveyId()).toBe(generated);
    expect(service.currentSurveyId).toBe(generated);

    service.surveyIdValue = 'saved-id';
    expect(service.getSurveyId()).toBe('saved-id');
    service.clearSurveyId();
    expect(service.getSurveyId()).not.toBe('saved-id');

    service.currentAssetIdValue = 'asset-1';
    expect(service.currentAssetIdValue).toBe('asset-1');
    service.clearCurrentAssetId();
    expect(service.currentAssetIdValue).toBeNull();

    service.currentDataViewIdValue = 'view-1';
    expect(service.currentDataViewIdValue).toBe('view-1');
    service.clearCurrentDataViewId();
    expect(service.currentDataViewIdValue).toBeNull();
  });

  it('builds and posts a survey draft with user context', () => {
    const { service, httpClient, surveyCommonService, runReportService } = createService();
    service.updateTitle('Draft');
    service.addQuestion(question());
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved', assetInfo: { assetId: 'asset-1', parameters: { dataViewId: 'saved-view-1' } } } }));

    let response: any;
    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe(value => response = value);

    expect(surveyCommonService.setUserContext).toHaveBeenCalledWith(expect.objectContaining({ userId: 'user-1' }));
    expect(httpClient.post).toHaveBeenCalledWith(expect.any(String), expect.objectContaining({ name: 'Draft' }), expect.any(Object));
    expect(httpClient.post.mock.calls[0]?.[1]).toEqual(expect.objectContaining({
      reportInfo: {
        jobId: 'job-1',
        panelistJobId: '',
        application: 'DISCOVER',
      },
    }));
    expect(runReportService.runReport).not.toHaveBeenCalled();
    expect(response.data.surveyId).toBe('saved');
    expect(service.currentAssetIdValue).toBe('asset-1');
    expect(service.currentDataViewIdValue).toBeNull();
    expect(service.hasLoadedSurvey('saved')).toBe(true);
  });

  it('returns null from ensureSurveyLoaded when surveyId is empty', () => {
    const { service } = createService();
    const loadSpy = vi.spyOn(service, 'loadSurvey');
    let result: any = 'unset';

    service.ensureSurveyLoaded('   ').subscribe(value => (result = value));

    expect(result).toBeNull();
    expect(loadSpy).not.toHaveBeenCalled();
  });

  it('returns null from ensureSurveyLoaded when same survey is already loaded', () => {
    const { service } = createService();
    service.surveyIdValue = 'survey-42';
    const loadSpy = vi.spyOn(service, 'loadSurvey');
    let result: any = 'unset';

    service.ensureSurveyLoaded('survey-42').subscribe(value => (result = value));

    expect(result).toBeNull();
    expect(loadSpy).not.toHaveBeenCalled();
  });

  it('calls loadSurvey from ensureSurveyLoaded for a new survey id', () => {
    const { service } = createService();
    const loadSpy = vi.spyOn(service, 'loadSurvey').mockReturnValue(of({ surveyId: 'survey-77' } as any));
    let result: any;

    service.ensureSurveyLoaded('survey-77').subscribe(value => (result = value));

    expect(loadSpy).toHaveBeenCalledWith('survey-77');
    expect(result).toEqual({ surveyId: 'survey-77' });
  });

  it('clears the original survey and asset IDs after loading a duplicate', () => {
    const { service } = createService();
    service.surveyIdValue = 'original-survey';
    service.currentAssetIdValue = 'original-asset';
    vi.spyOn(service, 'loadSurvey').mockReturnValue(of({} as any));

    service.loadSurveyForDuplicate('original-survey').subscribe();

    expect(service.currentSurveyId).toBeNull();
    expect(service.currentAssetIdValue).toBeNull();
  });

  it('uses dataViewId from the shared signal when building the save payload', () => {
    const { service, httpClient, surveyCommonService } = createService();
    service.updateTitle('Draft');
    service.addQuestion(question());
    surveyCommonService.getSurveySessionState.mockReturnValueOnce({
      ...surveyCommonService.getSurveySessionState(),
      dataViewId: null,
      selectedDatasetConfig: { dataView: { dataViewId: 'dataset-view-1' } },
    });
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved', assetInfo: { assetId: 'asset-1' } } }));

    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe();
    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe();

    expect(httpClient.post.mock.calls.map(call => call[1].version)).toEqual(['2', '3']);
  });

  it('increments createSaveDraftPayload version for any status when assetId is present', () => {
    const { service } = createService();

    const initialPayload = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [],
      userPrompt: '',
      status: SurveyStatusType.PUBLISHED,
      surveyId: 'survey-1',
      dynamics: {},
      rights: [],
    });
    const updatePayload = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [],
      userPrompt: '',
      status: SurveyStatusType.PUBLISHED,
      surveyId: 'survey-1',
      dynamics: {},
      rights: [],
      assetId: 'asset-1',
    });
    const payloadWithoutAssetId = service.createSaveDraftPayload({
      title: 'Survey',
      questions: [],
      userPrompt: '',
      status: SurveyStatusType.PUBLISHED,
      surveyId: 'survey-1',
      dynamics: {},
      rights: [],
    });

    expect(initialPayload.version).toBe('1');
    expect(updatePayload.version).toBe('2');
    expect(updatePayload.assetInfo.assetId).toBe('asset-1');
    expect(payloadWithoutAssetId.version).toBe('2');
  });

  it.each([SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED])('uses the survey name as the asset title for a new %s', status => {
    const { service } = createService();
    service.updateTitle('New survey');
    service.setSelectedFolder({ folderId: 'folder-1', name: 'Research folder' });
    const payload = service.buildSurveyPayload(status);
    expect(payload.name).toBe('New survey');
    expect(payload.description).toBe('New survey');
    expect(payload.assetInfo.title).toBe('New survey');
    expect(payload.folder.name).toBe('Research folder');
  });

  it.each([SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED])('preserves existing survey fields when renaming an asset for %s', status => {
    const { service } = createService();
    service.restoreSurveyState({
      surveyId: 'saved-survey', name: 'Original survey', description: 'Original description',
      folder: { folderId: 'folder-1', name: 'Research folder' },
      assetInfo: { assetId: 'asset-1', title: 'Saved asset name' },
      questions: [], metadata: { questionTypes: [], userPrompts: [] },
      reportInfo: { jobId: 'job-1' }, panelists: { targetCompletes: 0 },
    });
    expect(service.getTitle()).toBe('Saved asset name');
    service.updateTitle('Edited asset name');
    const payload = service.buildSurveyPayload(status, [], 'asset-1');
    expect(payload.assetInfo.title).toBe('Edited asset name');
    expect(payload.assetInfo.assetId).toBe('asset-1');
    expect(payload.name).toBe('Edited asset name');
    expect(payload.description).toBe('Original description');
    expect(payload.folder.name).toBe('Research folder');
    service.reset();
    service.updateTitle('Another survey');
    expect(service.buildSurveyPayload(status).name).toBe('Another survey');
  });

  it('does not require delivery channels or a schedule for drafts', () => {
    const { service } = createService();
    expect(service.deliveryPayloadFormat(SurveyStatusType.DRAFT)).toEqual({
      invitesSent: 0, channels: [], schedule: { openAt: null, closeAt: null, timezone: null },
    });
  });

  it('preserves an unavailable browser timezone in the publish delivery schedule', () => {
    const { service } = createService();
    const original = Intl.DateTimeFormat.prototype.resolvedOptions;
    const timezone = vi.spyOn(Intl.DateTimeFormat.prototype, 'resolvedOptions').mockImplementation(function (this: Intl.DateTimeFormat) {
      return { ...original.call(this), timeZone: '' };
    });
    try {
      const delivery = service.deliveryPayloadFormat(SurveyStatusType.PUBLISHED);
      expect(delivery.channels.length).toBeGreaterThan(0);
      expect(delivery.schedule.timezone).toBe('');
      expect(Number.isFinite(Date.parse(delivery.schedule.openAt!))).toBe(true);
      expect(Date.parse(delivery.schedule.closeAt!)).toBeGreaterThan(Date.parse(delivery.schedule.openAt!));
      expect(delivery.channels[0].config.expiresAt).toBe(delivery.schedule.closeAt);
    } finally {
      timezone.mockRestore();
    }
  });

  it('posts a published survey to the publish endpoint', () => {
    const { service, httpClient, runReportService } = createService();
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'published' } }));

    service.publishSurvey(SurveyStatusType.PUBLISHED).subscribe();

    expect(httpClient.post).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        assetInfo: expect.objectContaining({
          parameters: expect.objectContaining({ dataViewId: 'view-1' }),
        }),
      }),
      expect.any(Object),
    );
    expect(httpClient.post.mock.calls[0]?.[1]).toEqual(expect.objectContaining({
      reportInfo: expect.objectContaining({
        jobId: 'request-job-1',
        panelistJobId: 'panelist-job-1',
      }),
    }));
    expect(runReportService.runReport).toHaveBeenCalledWith(true);
    const reportInfo = httpClient.post.mock.calls[0]?.[1].reportInfo;
    expect(reportInfo.jobId).not.toBe(reportInfo.panelistJobId);
  });

  it('uses the previous panelist jobId as reportJobId and maps each completed panelistJobId', () => {
    const { service, httpClient, runReportService, surveyCommonService } = createService();
    let requestNumber = 0;
    runReportService.runReport.mockImplementation(() => {
      requestNumber += 1;
      runReportService.reportPayload.jobId = `publish-request-${requestNumber}`;
      return of(`panelist-job-${requestNumber}`);
    });
    surveyCommonService.getSelectedDatasetConfig.mockReturnValue(null);
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved', assetInfo: { assetId: 'asset-1' } } }));

    service.publishSurvey(SurveyStatusType.PUBLISHED).subscribe();
    runReportService.reportPayload.jobId = 'request-job-2';
    service.publishSurvey(SurveyStatusType.PUBLISHED).subscribe();

    expect(httpClient.post).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        assetInfo: expect.objectContaining({
          parameters: expect.objectContaining({ dataViewId: 'view-1' }),
        }),
      }),
      expect.any(Object),
    );
  });

  it('loads a saved draft and restores the persisted builder state', () => {
    const { service, httpClient, surveyCommonService, runReportService } = createService();
    const savedDraft = {
      surveyId: 'survey-99',
      name: 'Loaded survey',
      description: 'Loaded prompt',
      version: '1',
      metadata: { category: 'Snacks', source: 'discover-ui', userPrompts: ['Loaded prompt'] },
      behavior: { randomizeQuestions: false, allowBack: true, saveAndResume: true, estimatedMinutes: 2 },
      questions: [
        {
          type: QuestionTypes.MultipleChoice,
          required: true,
          prompt: { text: 'Which products do you buy?' },
          answerSpec: {
            options: [{ label: 'Chips' }, { label: 'Cookies' }],
          },
        },
        {
          type: QuestionTypes.MultiplePointScale,
          required: false,
          prompt: { text: 'Rate each option' },
          answerSpec: {
            rows: [{ label: 'Taste' }, { label: 'Value' }],
            columns: [{ label: 'Poor' }, { label: 'Excellent' }],
          },
        },
      ],
      reportInfo: { jobId: 'job-22', panelistJobId: '', application: 'DISCOVER' },
      assetInfo: {
        assetId: 'asset-99',
        assetType: 'DISCOVERSURVEY',
        rights: [],
        sourceType: 'NG2PORTAL',
        parameters: { reportType: 'layoutEditor', dataViewId: ' view-9 ' },
        launchURL: 'survey/build-survey',
        status: SurveyStatusType.DRAFT,
      },
      locale: 'en-US',
      createdBy: {
        userId: 'saved-user',
        clientId: 'saved-client',
        emailId: 'saved@example.com',
        applicationId: 'saved-app',
      },
      folder: { name: '', folderId: '', type: 'SURVEY', createIfMissing: true, onFailure: 'FAIL' },
      delivery: { invitesSent: 0, channels: [], schedule: { openAt: null, closeAt: null, timezone: null } },
      panelists: {
        mode: 'CRITERIA',
        savedSegmentId: null,
        explicitNIQPanelistIds: [],
        criteria: {
          op: 'AND',
          clauses: [
            { attribute: DimensionKeys.product, value: ['Snacks', 'Beverages'] },
            { attribute: DimensionKeys.geography, value: 'United States' },
          ],
        },
        targetCompletes: 150,
        maxResponsesPerPanelist: 1,
      },
      blobName: null,
    };
    httpClient.post.mockReturnValue(of({ data: savedDraft }));

    let response: any;
    service.loadSurvey('survey-99').subscribe((value) => response = value);

    expect(httpClient.post).toHaveBeenCalledWith(
      expect.any(String),
      {
        userId: 'user-1',
        surveyId: 'survey-99',
      },
      expect.any(Object),
    );
    expect(response).toEqual(savedDraft);
    expect(service.title()).toBe('Loaded survey');
    expect(service.currentSurveyId).toBe('survey-99');
    expect(service.currentAssetIdValue).toBe('asset-99');
    expect(service.getQuestions()).toEqual([
      {
        questionNumber: 1,
        question: 'Which products do you buy?',
        isRequired: true,
        type: QuestionTypes.MultipleChoice,
        options: ['Chips', 'Cookies'],
        rowOptions: [],
        columnOptions: [],
        npsLeftLabel: '',
        npsRightLabel: '',
      },
      {
        questionNumber: 2,
        question: 'Rate each option',
        isRequired: false,
        type: QuestionTypes.MultiplePointScale,
        options: [],
        rowOptions: ['Taste', 'Value'],
        columnOptions: ['Poor', 'Excellent'],
        npsLeftLabel: '',
        npsRightLabel: '',
      },
    ]);
    expect(surveyCommonService.hydrateSurveySessionState).toHaveBeenCalled();
    expect(surveyCommonService.panelistCompleted()).toBe(true);
    expect(surveyCommonService.setDataViewId).toHaveBeenCalledWith('view-9');
    expect(surveyCommonService.setUserContext).not.toHaveBeenCalled();
    expect(runReportService.lastJobId).toBe('job-22');
  });

  it('clears lastJobId instead of reusing the saved jobId when restoring a duplicate-flow survey', () => {
    const { service, httpClient, runReportService } = createService();
    service.setDuplicateFromId('survey-99');
    httpClient.post.mockReturnValue(of({
      data: { surveyId: 'survey-100', assetInfo: {}, reportInfo: { jobId: 'job-22' } },
    }));

    service.loadSurvey('survey-100').subscribe();

    expect(runReportService.lastJobId).toBe('');
    expect(runReportService.runReport).toHaveBeenCalled();
  });

  it('clears the dataselector loader when user lookup fails during survey load', () => {
    const { service, httpClient, surveyCommonService, userService } = createService();
    userService.getUserData.mockReturnValue(throwError(() => new Error('User lookup failed')));

    let capturedError: Error | undefined;
    service.loadSurvey('survey-99').subscribe({
      error: (error) => {
        capturedError = error;
      },
    });

    expect(httpClient.post).not.toHaveBeenCalled();
    expect(surveyCommonService.setDataselectorLoading).toHaveBeenNthCalledWith(1, true);
    expect(surveyCommonService.setDataselectorLoading).toHaveBeenLastCalledWith(false);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenNthCalledWith(1, true);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenLastCalledWith(false);
    expect(capturedError?.message).toBe('User lookup failed');
  });

  it('clears the dataselector loader when survey fetch fails during survey load', () => {
    const { service, surveyCommonService, httpClient } = createService();
    httpClient.post.mockReturnValue(throwError(() => new Error('Survey fetch failed')));

    let capturedError: Error | undefined;
    service.loadSurvey('survey-99').subscribe({
      error: (error) => {
        capturedError = error;
      },
    });

    expect(surveyCommonService.setDataselectorLoading).toHaveBeenNthCalledWith(1, true);
    expect(surveyCommonService.setDataselectorLoading).toHaveBeenLastCalledWith(false);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenNthCalledWith(1, true);
    expect(surveyCommonService.setSurveyLoading).toHaveBeenLastCalledWith(false);
    expect(capturedError?.message).toBe('Survey fetch failed');
  });

  it('sends empty report job IDs when a draft is saved before any report runs', () => {
    const { service, httpClient, runReportService } = createService();
    runReportService.reportPayload.jobId = '';
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved' } }));

    service.saveSurveyDraft(SurveyStatusType.DRAFT).subscribe();

    expect(httpClient.post.mock.calls[0]?.[1]).toEqual(expect.objectContaining({
      reportInfo: expect.objectContaining({ jobId: 'job-1', panelistJobId: '' }),
    }));
  });

  it('increments the version for each draft update', () => {
    const { service, httpClient } = createService();
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved', assetInfo: { assetId: 'asset-1' } } }));

    service.saveSurveyDraft(SurveyStatusType.DRAFT).subscribe();
    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe();
    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe();

    expect(httpClient.post.mock.calls.map(call => call[1].version)).toEqual(['1', '2', '3']);
  });

  it('posts a published survey to the publish endpoint', () => {
    const { service, httpClient, runReportService } = createService();
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'published' } }));

    service.publishSurvey(SurveyStatusType.PUBLISHED).subscribe();

    expect(httpClient.post).toHaveBeenCalledWith(
      expect.stringMatching(/\/publish$/),
      expect.objectContaining({
        assetInfo: expect.objectContaining({ status: SurveyStatusType.PUBLISHED }),
        delivery: expect.objectContaining({
          invitesSent: 25,
          channels: [expect.objectContaining({ channel: ChannelName.WebLink, enabled: true })],
          schedule: expect.objectContaining({
            openAt: expect.any(String),
            closeAt: expect.any(String),
            timezone: expect.any(String),
          }),
        }),
      }),
      expect.any(Object),
    );
    expect(httpClient.post.mock.calls[0]?.[1]).toEqual(expect.objectContaining({
      reportInfo: expect.objectContaining({
        jobId: 'request-job-1',
        panelistJobId: 'panelist-job-1',
      }),
    }));
    expect(runReportService.runReport).toHaveBeenCalledWith(true);
    const reportInfo = httpClient.post.mock.calls[0]?.[1].reportInfo;
    expect(reportInfo.jobId).not.toBe(reportInfo.panelistJobId);
  });

  it('sends a fresh request jobId for each publish and maps each completed panelistJobId', () => {
    const { service, httpClient, runReportService } = createService();
    let requestNumber = 0;
    runReportService.runReport.mockImplementation(() => {
      requestNumber += 1;
      runReportService.reportPayload.jobId = `publish-request-${requestNumber}`;
      return of(`panelist-job-${requestNumber}`);
    });
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'published' } }));

    service.publishSurvey(SurveyStatusType.PUBLISHED).subscribe();
    service.publishSurvey(SurveyStatusType.PUBLISHED).subscribe();

    const reportInfo = httpClient.post.mock.calls.map(call => call[1].reportInfo);
    expect(reportInfo.map(info => info.panelistJobId)).toEqual(['panelist-job-1', 'panelist-job-2']);
    expect(reportInfo.every(info => typeof info.jobId === 'string' && info.jobId.length > 0)).toBe(true);
    expect(reportInfo[0].jobId).not.toBe(reportInfo[1].jobId);
  });

  it('sets applicationId in user context during saveSurveyDraft', () => {
    const { service, httpClient, surveyCommonService } = createService();
    service.updateTitle('Draft');
    service.addQuestion(question());
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved' } }));

    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe();

    expect(surveyCommonService.setUserContext).toHaveBeenCalledWith(expect.objectContaining({
      applicationId: 'app-1',
    }));
  });

  it('posts survey draft to the survey endpoint path', () => {
    const { service, httpClient } = createService();
    service.updateTitle('Draft');
    service.addQuestion(question());
    httpClient.post.mockReturnValue(of({ data: { surveyId: 'saved' } }));

    service.saveSurveyDraft(SurveyStatusType.DRAFT, 'asset-1').subscribe();

    expect(httpClient.post).toHaveBeenCalled();
    const calledUrl = String(httpClient.post.mock.calls[0]?.[0] ?? '');
    expect(calledUrl.endsWith('/survey')).toBe(true);
  });

  it('uses default options array when updating option field on a question without options', () => {
    const { service } = createService();
    service.addQuestion(question({ options: undefined as any }));

    service.updateOptionField(0, 0, 'First option');

    expect(service.getQuestions()[0].options).toEqual(['First option']);
  });

  it('updates an option index when a question starts with undefined options via direct setQuestions', () => {
    const { service } = createService();
    service.setQuestions([
      {
        question: 'Question',
        options: undefined as any,
        rowOptions: [],
        columnOptions: [],
        npsLeftLabel: '',
        npsRightLabel: '',
        isRequired: false,
        type: QuestionTypes.SingleChoice,
      } as any,
    ]);

    service.updateOptionField(0, 1, 'Second option');

    expect(service.getQuestions()[0]?.options?.[1]).toBe('Second option');
  });

  it('remaps drafts after deleting a middle question from a populated list', () => {
    const { service } = createService();
    service.setQuestions([question({ question: 'Q1' }), question({ question: 'Q2' }), question({ question: 'Q3' })]);
    service.saveDraft(2, { question: 'Draft Q3' });

    service.removeQuestion(1);

    expect(service.getDraft(1)).toEqual({ question: 'Draft Q3' });
  });

  it('remaps private draft indexes only when greater than deleted index', () => {
    const { service } = createService();
    service.saveDraft(0, { question: 'Keep' });
    service.saveDraft(3, { question: 'Shift' });

    (service as any).remapDraftsAfterDelete(1);

    expect(service.getDraft(0)).toEqual({ question: 'Keep' });
    expect(service.getDraft(2)).toEqual({ question: 'Shift' });
  });

  it('normalizes default type and trimmed question when extracted payload omits type', () => {
    const normalized = normalizeRephrasedQuestion({ question: '  Trim me  ' }, undefined, 4);

    expect(normalized).toEqual(expect.objectContaining({
      questionNumber: 5,
      type: '',
      question: 'Trim me',
    }));
  });

  it('maps optional values for payload branches when values are nullish', () => {
    const { service } = createService();
    const payload = service.createSaveDraftPayload({
      title: 'Title',
      questions: [
        question({ type: QuestionTypes.MultipleChoice, isRequired: false, options: ['One', 'Two'] }),
        question({ type: QuestionTypes.NetPromoterScore, npsLeftLabel: undefined as any, npsRightLabel: '' }),
      ] as any,
      userPrompt: 'Prompt',
      status: SurveyStatusType.DRAFT,
      surveyId: 'survey-1',
    });

    expect(payload.questions[0].validation).toEqual(expect.objectContaining({ minSelections: 0 }));
    expect(payload.questions[1].answerSpec).toEqual(expect.objectContaining({
      anchors: expect.objectContaining({ min: 'Not at all likely', max: 'Extremely likely' }),
    }));
    expect(payload.panelists).toEqual({
      targetCompletes: 0,
      maxResponsesPerPanelist: 1,
    });
  });

  it('uses fallback NPS max anchor when right label is blank after trim', () => {
    const answer = buildAnswerSpec({
      question: 'NPS',
      type: QuestionTypes.NetPromoterScore,
      options: [],
      rowOptions: [],
      columnOptions: [],
      isRequired: false,
      npsLeftLabel: 'Left',
      npsRightLabel: '   ',
    } as any);

    expect((answer.answerSpec as any).anchors.max).toBe('Extremely likely');
  });

  it('normalizes whitespace question text to empty string', () => {
    const normalized = normalizeRephrasedQuestion(
      { result: { question: '   ', type: QuestionTypes.Text } },
      undefined,
      0
    );

    expect(normalized).toEqual(expect.objectContaining({
      type: QuestionTypes.Text,
      question: '',
    }));
  });

  it('builds required scale validations for single-point and multiple-point scales', () => {
    const single = buildAnswerSpec({
      question: 'Single scale',
      type: QuestionTypes.SinglePointScale,
      isRequired: true,
      options: ['fallback'],
      columnOptions: ['Low', 'High'],
      rowOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
    } as any);

    const multiple = buildAnswerSpec({
      question: 'Multi scale',
      type: QuestionTypes.MultiplePointScale,
      isRequired: true,
      options: [],
      rowOptions: ['R1', 'R2'],
      columnOptions: ['C1', 'C2'],
      npsLeftLabel: '',
      npsRightLabel: '',
    } as any);

    expect(single.validation).toEqual(expect.objectContaining({ minSelections: 1, maxSelections: 1 }));
    expect(multiple.validation).toEqual(expect.objectContaining({ minSelections: 1 }));
  });

  it.each([SurveyStatusType.DRAFT, SurveyStatusType.PUBLISHED])('reuses the loaded survey folder for %s', status => {
    const { service, httpClient } = createService();
    const folder = { folderId: 'US-1208173687611031569', name: 'Survey', type: 'SURVEY' };
    httpClient.post.mockReturnValueOnce(of({ data: {
      surveyId: 'survey-1', name: 'Survey', questions: [],
      metadata: { userPrompts: [] }, reportInfo: { jobId: '' },
      assetInfo: { assetId: 'asset-1' }, folder,
      panelists: { targetCompletes: 0, criteria: { clauses: [] } },
    } })).mockReturnValue(of({}));

    service.loadSurvey('survey-1').subscribe();
    const request = status === SurveyStatusType.DRAFT
      ? service.saveSurveyDraft(status, service.currentAssetIdValue!)
      : service.publishSurvey(SurveyStatusType.PUBLISHED, service.currentAssetIdValue);
    request.subscribe();

    expect(httpClient.post.mock.calls[1][1].folder).toEqual({ folderId: folder.folderId, name: folder.name });
    expect(httpClient.post.mock.calls[1][1].assetInfo.assetId).toBe('asset-1');
  });

  it('clears a previous folder when the loaded survey has no folder', () => {
    const { service, httpClient } = createService();
    service.setSelectedFolder({ folderId: 'old-folder', name: 'Old' });
    httpClient.post.mockReturnValue(of({ data: {
      surveyId: 'survey-2', name: 'Survey', questions: [],
      metadata: { userPrompts: [] }, reportInfo: { jobId: '' },
      panelists: { targetCompletes: 0, criteria: { clauses: [] } },
    } }));

    service.loadSurvey('survey-2').subscribe();

    expect(service.getSelectedFolder()).toBeNull();
  });

  describe('Survey State Management Methods', () => {
    it('clears duplicate survey ID', () => {
      const { service } = createService();
      service.setDuplicateFromId('survey-123');

      expect(service.getDuplicateFromId()).toBe('survey-123');

      service.clearDuplicateFromId();

      expect(service.getDuplicateFromId()).toBeNull();
    });

    it('throws error when loaded survey data is null', () => {
      const { service, httpClient, surveyCommonService } = createService();
      surveyCommonService.getRefreshedDate.mockReturnValue(null);
      surveyCommonService.getSelectedDatasetConfig.mockReturnValue(null);
      httpClient.post.mockReturnValue(of({ data: null }));

      let error: unknown;
      service.loadSurvey('invalid-survey').subscribe({
        error: (e) => { error = e; },
      });

      expect(error).toBeInstanceOf(Error);
      expect((error as Error).message).toContain('could not be loaded');
    });
  });

});
