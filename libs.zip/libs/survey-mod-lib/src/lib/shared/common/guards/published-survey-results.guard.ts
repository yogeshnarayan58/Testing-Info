import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { catchError, map, of } from 'rxjs';
import { FLOW_TYPES, SURVEY_FLOW_STEPS } from '../../../core/config/config';
import { SurveyStatusType } from '../../../features/build-survey/models/build-survey';
import { resolveLaunchUrlByFlow } from '../../../features/build-survey/services/survey-data-mapper.util';
import { SurveyService } from '../../../features/build-survey/services/survey.service';

// Returns true only when the survey status is PUBLISHED.
const isPublishedSurvey = (status?: SurveyStatusType): boolean => status === SurveyStatusType.PUBLISHED;

// Creates the correct results URL and keeps scratch/aiflow routing intact.
const resolveResultsUrlTree = (
  router: Router,
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot,
  surveyId: string,
): UrlTree => {
  const flowType = route.parent?.data?.['flowType'];
  const isAiFlow = flowType === FLOW_TYPES.AIFLOW || state.url.includes('/aiflow/');

  return router.createUrlTree([
    '/survey',
    ...(isAiFlow ? [FLOW_TYPES.AIFLOW] : []),
    'results',
    surveyId,
  ]);
};

// Prevents editing published surveys by redirecting edit routes back to results.
export const redirectPublishedSurveyEditsGuard: CanActivateFn = (route, state) => {
  const surveyId = route.paramMap.get('surveyId')?.trim();
  if (!surveyId) {
    return true;
  }

  const surveyService = inject(SurveyService);
  const router = inject(Router);

 // Reuses SurveyService in-memory state and only loads when this survey id is not already active.
  return surveyService.ensureSurveyLoaded(surveyId).pipe(
    map(() => {
      const status = surveyService.loadedSurveyDetails()?.assetInfo?.status;
      if (!isPublishedSurvey(status)) {
        return true;
      }

      return resolveResultsUrlTree(router, route, state, surveyId);
    }),
    catchError(() => of(true as const)),
  );
};

// Redirects non-published surveys away from the results page to the survey's launch URL.
export const redirectUnpublishedSurveyResultsGuard: CanActivateFn = (route, state) => {
  const surveyId = route.paramMap.get('surveyId')?.trim();
  if (!surveyId) {
    return true;
  }

  const surveyService = inject(SurveyService);
  const router = inject(Router);
  const isAiFlow = route.parent?.data?.['flowType'] === FLOW_TYPES.AIFLOW || state.url.includes('/aiflow/');

  // Falls back here whenever the launch URL can't be trusted, so a non-published survey never stays on results.
  const buildSurveyUrlTree = (): UrlTree =>
    router.createUrlTree(['/survey', ...(isAiFlow ? [FLOW_TYPES.AIFLOW] : []), SURVEY_FLOW_STEPS.BUILD_SURVEY, surveyId]);

  // Only follows in-app paths, and never back to results, to avoid open redirects and loops.
  const toLaunchUrlTree = (launchUrl?: string): UrlTree => {
    const path = launchUrl?.trim().replace(/^\/+/, '');
    if (!path || path.includes('://') || path.includes('\\') || path.includes(`/${SURVEY_FLOW_STEPS.RESULTS}/`)) {
      return buildSurveyUrlTree();
    }
    return router.parseUrl(`/${path}`);
  };

  return surveyService.ensureSurveyLoaded(surveyId).pipe(
    map(() => {
      const assetInfo = surveyService.loadedSurveyDetails()?.assetInfo;
      if (isPublishedSurvey(assetInfo?.status)) {
        return true;
      }

      // Load doesn't always return a launchURL, so derive it the same way it's saved.
      const launchUrl = assetInfo?.launchURL ?? resolveLaunchUrlByFlow({ [FLOW_TYPES.AIFLOW]: isAiFlow }, surveyId, assetInfo?.status ?? '');
      return toLaunchUrlTree(launchUrl);
    }),
    catchError(() => {
      // Lets the wrapper's own load retry and report the failure, instead of a stale id blocking it.
      surveyService.clearSurveyId();
      return of(true as const);
    }),
  );
};
