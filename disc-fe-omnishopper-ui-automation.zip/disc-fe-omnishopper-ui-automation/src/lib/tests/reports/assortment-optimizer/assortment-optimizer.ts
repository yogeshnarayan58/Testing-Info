import { BasePage } from "@gfk/gta";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import * as aoResources from "./assortment-optimizer-resource.json";
import { SMALL_TIMEOUT } from "../../../constants/time-out-constants";

const TOGGLE_COMPONENT_NAME = "AssortmentOptimizerToggle";

/**
 * AssortmentOptimizerComponent - Report specific test cases for Assortment Optimizer
 * Handles toggle switching functionality for Questions 1 and 4
 */
export class AssortmentOptimizerComponent extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      TOGGLE_COMPONENT_NAME,
      aoResources
    );
  }

  /**
   * Switch to a specific toggle segment by question number and segment index (0-based)
   * @param questionNumber The question number (1 or 4)
   * @param segmentIndex The segment/toggle index (0-based: 0 = first toggle, 1 = second toggle, 2 = third toggle)
   * @example await component.switchToggle(1, 0); // Question 1, first toggle
   * @example await component.switchToggle(4, 2); // Question 4, third toggle
   */
  public async switchToggle(questionNumber: number, segmentIndex: number): Promise<void> {
    try {
      // Validate question number
      if (questionNumber !== 1 && questionNumber !== 4) {
        throw new Error(`Invalid question number: ${questionNumber}. Only questions 1 and 4 have toggles.`);
      }

      // Validate segment index based on question
      const maxSegments = questionNumber === 1 ? 2 : 3;
      if (segmentIndex < 0 || segmentIndex >= maxSegments) {
        throw new Error(
          `Invalid segment index: ${segmentIndex}. Question ${questionNumber} has ${maxSegments} toggles (0-${maxSegments - 1}).`
        );
      }

      // Use getMultiDynamicResource for multiple replacements
      const toggleSegmentResource = this.resourceManager.getMultiDynamicResource(
        "toggleSegment",
        { questionNumber: questionNumber.toString(), segmentIndex: segmentIndex.toString() },
        TOGGLE_COMPONENT_NAME
      );
      const toggleSegment = this.webActionHandler.getWebElement(toggleSegmentResource);

      await toggleSegment.waitFor();
      await toggleSegment.click();

      // Wait for toggle action to complete
      await this.webActionHandler.delay(SMALL_TIMEOUT);

      console.log(`Successfully switched to toggle segment ${segmentIndex} for question ${questionNumber}`);
    } catch (error) {
      throw new Error(`Failed to switch toggle for question ${questionNumber}, segment ${segmentIndex}: ${error}`);
    }
  }

  /**
   * Validate toggle segment text values before switching
   * @param questionNumber The question number (1 or 4)
   * @param expectedValues Array of expected toggle text values from localization data
   * @example await component.validateToggleValues(1, ["Buyers", "EQ2"]);
   * @example await component.validateToggleValues(4, ["Exclusive", "Duplicators", "All Buyers"]);
   */
  public async validateToggleValues(questionNumber: number, expectedValues: string[]): Promise<void> {
    try {
      // Validate question number
      if (questionNumber !== 1 && questionNumber !== 4) {
        throw new Error(`Invalid question number: ${questionNumber}. Only questions 1 and 4 have toggles.`);
      }

      // Validate segment count matches expected values length
      const maxSegments = questionNumber === 1 ? 2 : 3;
      if (expectedValues.length !== maxSegments) {
        throw new Error(
          `Expected ${maxSegments} toggle values for question ${questionNumber}, but got ${expectedValues.length}`
        );
      }

      // Validate all toggle segments and their text content
      for (let segmentIndex = 0; segmentIndex < expectedValues.length; segmentIndex++) {
        // Use getMultiDynamicResource for multiple replacements
        const toggleSegmentResource = this.resourceManager.getMultiDynamicResource(
          "toggleSegment",
          { questionNumber: questionNumber.toString(), segmentIndex: segmentIndex.toString() },
          TOGGLE_COMPONENT_NAME
        );
        const toggleSegment = this.webActionHandler.getWebElement(toggleSegmentResource);

        await toggleSegment.waitFor();
        const actualText = await toggleSegment.getText();
        const expectedText = expectedValues[segmentIndex];

        if (!actualText || actualText.trim() !== expectedText.trim()) {
          throw new Error(
            `Toggle ${segmentIndex} validation failed for question ${questionNumber}. Expected: "${expectedText}", but got: "${actualText}"`
          );
        }

        console.log(`✓ Question ${questionNumber} - Toggle ${segmentIndex} text validated: "${actualText}"`);
      }

      console.log(`✓ All toggle values validated successfully for question ${questionNumber}`);
    } catch (error) {
      throw new Error(`Failed to validate toggle values for question ${questionNumber}: ${error}`);
    }
  }

  /**
   * Get the BasePage instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }
}
