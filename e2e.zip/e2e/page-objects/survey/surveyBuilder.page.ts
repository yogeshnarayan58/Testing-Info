import { BasePage, WebActions } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import {ELEMENT_WAIT_TIMEOUT,UI_STATE_UPDATE_DELAY,PANEL_TRANSITION_DELAY,SMALL_TIMEOUT,MEDIUM_TIMEOUT,NAVIGATION_TIMEOUT} from '../../constants/timeout-constants';
import { envConfig } from '../../config/env.config';
import surveyBuilderPageResources from '../../locators/survey/surveyBuilder.locator.json';
import devTestData from '../../test-data/dev-test-data.json';

const SURVEY_BUILDER_PAGE_COMPONENT_NAME = 'surveyBuilderPage';

export class SurveyBuilderPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      SURVEY_BUILDER_PAGE_COMPONENT_NAME,
      surveyBuilderPageResources
    );
  }

  /** Throws (unlike `waitFor()`, which does not throw on timeout in this framework) if `element` isn't visible within `timeoutMs`. */
  private async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  private getResource(name: string) {
    return this.resourceManager.getResource(name, SURVEY_BUILDER_PAGE_COMPONENT_NAME);
  }

  /** Races `action` against `timeoutMs` since hover/click/enterText have no native timeout param, so an unreachable/occluded element can't hang past it. */
  private async withTimeout<T>(action: Promise<T>, timeoutMs: number, step: string): Promise<T> {
    let timer!: ReturnType<typeof setTimeout>;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${step} timed out after ${timeoutMs}ms`)), timeoutMs);
    });
    try {
      return await Promise.race([action, timeoutPromise]);
    } finally {
      clearTimeout(timer);
    }
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then clicks it. */
  private async clickWhenVisible(resourceName: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.click();
  }

  /** Gets `resourceName` by its registered static name, waits for it to be visible, then fills it. */
  private async fillWhenVisible(resourceName: string, text: string, what: string, timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<void> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what, timeoutMs);
    await element.enterText(text);
  }

  // Question type selection
  private async clickQuestionTypeResource(resourceName: string): Promise<void> {
    await this.clickWhenVisible(resourceName, `Question-type tile "${resourceName}"`, MEDIUM_TIMEOUT);
  }

  /** Selects a question type tile without saving; call clickAddQuestion() again to cancel without persisting. */
  async clickQuestionTypeTile(resourceName: string): Promise<void> {
    await this.clickQuestionTypeResource(resourceName);
  }

  // Shared field helpers (operate on the currently expanded/editing question)
  private async fillQuestionText(questionIndex: number, text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('questionTextInput', String(questionIndex), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await this.waitUntilVisible(questionText, 'Question text input');
    await questionText.enterText(text);
  }

  /** Fills Option N / Row N / Column N fields by their visible role label, e.g. 'Option 1', 'Row 2'. */
  private async fillLabeledField(label: string, value: string): Promise<void> {
    const field = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('optionInputByLabel', label, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await this.waitUntilVisible(field, `Field "${label}"`);
    await field.enterText(value);
  }

  /** Fills Rating's question-text field — locator is unscoped by question index (interim `:visible`-based mitigation). */
  private async fillRatingQuestionText(text: string): Promise<void> {
    await this.fillWhenVisible('ratingQuestionTextInput', text, 'Rating question text input');
  }

  /** Counts rendered `.question-number` markers rather than trusting a hardcoded literal, since the persisted survey's question count is not stable across runs. */
  private async getNextQuestionIndex(): Promise<number> {
    const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    return markers.length + 1;
  }

  async getQuestionCount(): Promise<number> {
    try {
      const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
      return markers.length;
    } catch (error) {
      throw new Error(`Failed to get question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Re-expands the question card after it collapses/saves; scopes to the LAST `editQuestionButton` match since once 2+ questions exist it would otherwise be a strict-mode violation. */
  private async reopenCollapsedQuestion(): Promise<void> {
    const addOptionButton = this.webActionHandler.getWebElement(this.getResource('addOptionButton'));
    if (await addOptionButton.isVisible(SMALL_TIMEOUT)) {
      return;
    }

    const questionCount = await this.getQuestionCount();
    const editButtonResource = this.getResource('editQuestionButton');
    const editButton = this.webActionHandler.getWebElement({
      ...editButtonResource,
      selectorType: 'playwrights',
      selectorValue: `${editButtonResource.selectorValue} >> nth=${Math.max(questionCount - 1, 0)}`
    });
    await this.waitUntilVisible(editButton, 'Edit question button');
    await editButton.click();
  }

  async addOptionToQuestion(): Promise<void> {
    try {
      await this.clickWhenVisible('addOptionButton', 'Add option button');
    } catch (error) {
      throw new Error(`Failed to add option to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers the Add-menu trigger wrapper (`.matrix-action-area`) so the Row/Column buttons render. */
  private async hoverScaleAddMenuTrigger() {
    const addMenuTrigger = this.webActionHandler.getWebElement(this.getResource('scaleAddMenuTrigger'));
    await this.waitUntilVisible(addMenuTrigger, 'Scale add-menu trigger');
    await addMenuTrigger.hover();
    return addMenuTrigger;
  }

  /** Shared by Point Scale and Multi Scale — both use the same survey-scale-editor matrix-actions mechanism. */
  async addRowToQuestion(): Promise<void> {
    try {
      const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
      const addRow = addMenuTrigger.getWebElement(this.getResource('addRowButton'));
      await this.waitUntilVisible(addRow, 'Add row button');
      await addRow.click();
    } catch (error) {
      throw new Error(`Failed to add row to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Shared by Point Scale and Multi Scale — both use the same survey-scale-editor matrix-actions mechanism. */
  async addColumnToQuestion(): Promise<void> {
    try {
      const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
      const addColumn = addMenuTrigger.getWebElement(this.getResource('addColumnButton'));
      await this.waitUntilVisible(addColumn, 'Add column button');
      await addColumn.click();
    } catch (error) {
      throw new Error(`Failed to add column to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Closes the Add Question panel first (its editor shares selectors with any open row editor) using isHidden() - isVisible(0) is NOT instant, it waits forever for the element to appear. */
  private async closeInlineAddEditorIfOpen(): Promise<void> {
    const inlineEditor = this.webActionHandler.getWebElement(this.getResource('inlineAddEditor'));
    if (!(await inlineEditor.isHidden())) {
      await this.clickAddQuestion();
    }
  }

  /** `requiredToggle`'s truncated id matches EVERY question's checkbox once more than one editor has been opened, so when `index` is given this scopes to that row instead of a page-wide nth. */
  async toggleRequired(index?: number): Promise<void> {
    try {
      if (index === undefined) {
        await this.clickWhenVisible('requiredToggle', 'Required toggle');
      } else {
        await this.closeInlineAddEditorIfOpen();
        const rowResource = this.getResource('questionRow');
        const toggleResource = this.getResource('requiredToggle');
        const toggle = this.webActionHandler.getWebElement({
          ...toggleResource,
          selectorType: 'playwrights',
          selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue}`
        });
        await this.waitUntilVisible(toggle, `Required toggle (index ${index})`);
        await this.withTimeout(
          toggle.click(),
          ELEMENT_WAIT_TIMEOUT,
          `Click Required toggle (step: toggleRequired, index ${index}, locator: ${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue})`
        );
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to toggle required: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Footer's "Back" button has no data-test-id, resolved by text. */
  async clickBackButton(): Promise<void> {
    try {
      await this.clickWhenVisible('backButton', 'Back button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to click back button: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Stepper's clickable circle; text doesn't navigate - index 0 = Select Panelists. */
  async clickSelectPanelistsStep(): Promise<void> {
    try {
      await this.clickWhenVisible('select-panelists-step-circle', 'Select Panelists step circle', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to click Select Panelists step: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickAddQuestion(): Promise<void> {
    try {
      await this.clickWhenVisible('addQuestionLink', 'Add question link');
      await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
    } catch (error) {
      throw new Error(`Failed to click add question: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Per-question-type methods: each assumes it's called right after clickAddQuestion(), while this question is the currently expanded one.

  async addSingleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeSingleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.reopenCollapsedQuestion();
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }

      const saveButton = this.webActionHandler.getWebElement(this.getResource('saveQuestionChangesButton'));
      if (await saveButton.isVisible(SMALL_TIMEOUT)) {
        await saveButton.click();
      }
      await this.waitForQuestionCountAtLeast(questionIndex, MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to add Single Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addMultipleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultipleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Multiple Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addRatingQuestion(questionText: string): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeRating');
      await this.fillRatingQuestionText(questionText); // unscoped by index (interim :visible-based mitigation)
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Rating question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addNPSQuestion(questionText: string): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeNPS');
      await this.fillQuestionText(questionIndex, questionText); // NPS reuses the shared questionTextInput locator
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Net Promoter Score question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Point Scale shares the survey-scale-editor matrix-actions mechanism with Multi Scale. */
  async addPointScaleQuestion(
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypePointScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Point Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addMultiScaleQuestion(
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultiScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Multi Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async enterReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('reviewSurveyButton', 'Review survey button');
      const selectAllButtonAfterEntering = this.webActionHandler.getWebElement(this.getResource('selectAllButton'));
      await this.waitUntilVisible(selectAllButtonAfterEntering, 'Select all button (review mode controls)');
    } catch (error) {
      throw new Error(`Failed to enter review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectQuestionInReview(index: number): Promise<void> {
    try {
      const questionCheckbox = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(questionCheckbox, `Select-question checkbox (index ${index})`);
      await questionCheckbox.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to select question ${index} in review: ${error instanceof Error ? error.message : error}`);
    }
  }

  async deleteSelectedQuestions(): Promise<void> {
    try {
      await this.clickWhenVisible('deleteQuestionsButton', 'Delete questions button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to delete selected questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectAll(): Promise<void> {
    try {
      await this.clickWhenVisible('selectAllButton', 'Select all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to select all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async unselectAll(): Promise<void> {
    try {
      await this.clickWhenVisible('unselectAllButton', 'Unselect all button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to unselect all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async expandAll(): Promise<void> {
    try {
      await this.clickWhenVisible('expandAllButton', 'Expand all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to expand all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async collapseAll(): Promise<void> {
    try {
      await this.clickWhenVisible('collapseAllButton', 'Collapse all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to collapse all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async exitReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('exitReviewModeButton', 'Exit review mode button');
      const reviewButtonAfterExit = this.webActionHandler.getWebElement(this.getResource('reviewSurveyButton'));
      await this.waitUntilVisible(reviewButtonAfterExit, 'Review survey button (back on Build Survey screen)');
    } catch (error) {
      throw new Error(`Failed to exit review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Instant check (isHidden(), not isVisible(0) which waits forever) for whether delete-all already auto-closed Review Mode. */
  async isExitReviewModeButtonHidden(): Promise<boolean> {
    try {
      const exitButton = this.webActionHandler.getWebElement(this.getResource('exitReviewModeButton'));
      return await exitButton.isHidden();
    } catch (error) {
      throw new Error(`Failed to check exit-review-mode button visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async areReviewControlsVisible(): Promise<boolean> {
    try {
      const controls = ['selectAllButton', 'expandAllButton', 'collapseAllButton', 'deleteQuestionsButton', 'exitReviewModeButton'];
      for (const control of controls) {
        const element = this.webActionHandler.getWebElement(this.getResource(control));
        if (!(await element.isVisible())) {
          return false;
        }
      }
      return true;
    } catch (error) {
      throw new Error(`Failed to check review controls visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getReviewCheckboxCount(questionCount: number): Promise<number> {
    try {
      let visibleCount = 0;
      for (let index = 0; index < questionCount; index++) {
        const checkbox = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
        );
        if (await checkbox.isVisible()) {
          visibleCount++;
        }
      }
      return visibleCount;
    } catch (error) {
      throw new Error(`Failed to get review checkbox count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `select-question-<i>-icon` has no checked state itself; the real checked/unchecked class lives on its ancestor `.checkbox-container`. */
  async isQuestionSelected(index: number): Promise<boolean> {
    try {
      const container = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionCheckboxContainer', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      const classAttr = (await container.getAttribute('class')) ?? '';
      return classAttr.split(/\s+/).includes('checked');
    } catch (error) {
      throw new Error(`Failed to check if question ${index} is selected: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getQuestionNumbers(): Promise<string[]> {
    try {
      return await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    } catch (error) {
      throw new Error(`Failed to get question numbers: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Polls `getQuestionNumbers()` until its length reaches `target`, or throws after `timeout` ms. */
  private async waitForQuestionCountAtLeast(target: number, timeout: number): Promise<string[]> {
    const start = Date.now();
    let questionNumbers = await this.getQuestionNumbers();
    while (questionNumbers.length < target) {
      if (Date.now() - start >= timeout) {
        throw new Error(`Timed out waiting for question count to reach ${target} (current: ${questionNumbers.length})`);
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      questionNumbers = await this.getQuestionNumbers();
    }
    return questionNumbers;
  }

  /** Tops up to `min` Rating questions; the Rating tile toggles closed if add-question is clicked while already open, so only click it when not visible. */
  async ensureQuestionCount(min: number): Promise<void> {
    try {
      const { questionText } = devTestData.surveyQuestions.rating;
      let questionNumbers = await this.getQuestionNumbers();

      while (questionNumbers.length < min) {
        const countBeforeAdd = questionNumbers.length;
        const typeTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));

        if (!(await typeTile.isVisible(SMALL_TIMEOUT))) {
          await this.clickAddQuestion();
          if (!(await typeTile.isVisible(MEDIUM_TIMEOUT))) {
            throw new Error(`Question-type picker did not open after clicking add-question (current question count: ${countBeforeAdd})`);
          }
        }

        await this.addRatingQuestion(`${questionText} ${countBeforeAdd + 1}`);
        questionNumbers = await this.waitForQuestionCountAtLeast(countBeforeAdd + 1, MEDIUM_TIMEOUT);
      }
    } catch (error) {
      throw new Error(`Failed to ensure question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Survey name, save, publish
  async setSurveyTitle(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('editSurveyNameIcon', 'Edit survey name icon');
      await this.fillWhenVisible('surveyTitleInput', title, 'Survey title input');
    } catch (error) {
      throw new Error(`Failed to set survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Expands "My Assets" via its own row-scoped `.arrow` (not page-wide) and picks the first non-"My Assets" folder row, only when Save isn't already enabled on "My Assets" alone. Shared by fillSaveCopyDialog(); publish can reuse it too. */
  private async selectSaveLocation(): Promise<void> {
    await this.clickWhenVisible('myAssetsTreeItem', 'My Assets tree item');

    const saveButton = this.webActionHandler.getWebElement(this.getResource('savePendingChangesButton'));
    const isSaveButtonVisible = await saveButton.isVisible(SMALL_TIMEOUT);
    const isSaveReady = isSaveButtonVisible && (await saveButton.isEnabled());
    if (isSaveReady) {
      return;
    }

    const nativePage = (BasePage as any).page as import('playwright').Page; // "not My Assets" folder filtering needs Playwright's filter API, not expressible via resource strings
    const myAssetsRow = nativePage.getByRole('treeitem', { name: 'My Assets' });
    await myAssetsRow.locator('.arrow').click({ timeout: SMALL_TIMEOUT });

    const folderRow = nativePage.getByRole('treeitem').filter({ hasNotText: 'My Assets' }).first();
    await folderRow.click({ timeout: SMALL_TIMEOUT });
  }

  /** Fills the Save-a-copy dialog (title, My Assets, save pending changes) — shared by saveDraft() and publishSurvey(). */
  private async fillSaveCopyDialog(title: string): Promise<void> {
    await this.fillWhenVisible('saveCopyTitleInput', title, 'Save-copy title input');
    await this.selectSaveLocation();
    await this.clickWhenVisible('savePendingChangesButton', 'Save pending changes button');
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  async saveDraft(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');

      await this.fillSaveCopyDialog(title);
    } catch (error) {
      throw new Error(`Failed to save draft: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isSurveyVisibleInMyAssets(title: string): Promise<boolean> {
    try {
      const myAssetsURL = this.buildUrl(envConfig.BASE_URL, 'survey/my-assets');
      await this.navigateToUrl(myAssetsURL);
      const gridcell = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('savedAssetGridcellByTitle', title, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      return gridcell.isVisible();
    } catch (error) {
      throw new Error(`Failed to check survey visibility in My Assets: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDraftSavedToastVisible(): Promise<boolean> {
    try {
      const toast = this.webActionHandler.getWebElement(this.getResource('saveDraftSuccessToast'));
      return toast.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to check draft saved toast visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** "Add question" has no `state` attribute; disabled is reflected via a `disabled` class token or aria-disabled. */
  async getAddQuestionDisabledState(): Promise<{ disabled: boolean; classAttr: string; outerHtml: string }> {
    try {
      const addQuestion = this.webActionHandler.getWebElement(this.getResource('addQuestionLink'));
      const classAttr = (await addQuestion.getAttribute('class')) ?? '';
      const ariaDisabled = await addQuestion.getAttribute('aria-disabled');
      const outerHtml = String(await addQuestion.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { disabled: classAttr.split(/\s+/).includes('disabled') || ariaDisabled === 'true', classAttr, outerHtml };
    } catch (error) {
      throw new Error(`Failed to get add-question disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isAddQuestionTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const addQuestion = this.webActionHandler.getWebElement(this.getResource('addQuestionLink'));
      await this.withTimeout(addQuestion.executeScript((e) => e.scrollIntoView()), ELEMENT_WAIT_TIMEOUT, 'Scroll Add question into view');
      await this.withTimeout(addQuestion.hover(), ELEMENT_WAIT_TIMEOUT, 'Hover Add question');
      const message = this.webActionHandler.getWebElement(this.getResource('maxQuestionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait, no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off the hovered button so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check add-question tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `duplicateQuestionButton` matches one icon per question — scope to a single question (default: first). */
  private getDuplicateQuestionElement(questionIndex = 0) {
    const duplicateResource = this.getResource('duplicateQuestionButton');
    return this.webActionHandler.getWebElement({
      ...duplicateResource,
      selectorType: 'playwrights',
      selectorValue: `${duplicateResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** `deleteQuestionButton` (`.delete-action`) matches one icon per question — scope to a single question. */
  private getDeleteQuestionElement(questionIndex = 0) {
    const deleteResource = this.getResource('deleteQuestionButton');
    return this.webActionHandler.getWebElement({
      ...deleteResource,
      selectorType: 'playwrights',
      selectorValue: `${deleteResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** `.question-actions` is only revealed via `.question-row`'s mouseenter handler, not CSS :hover. Scope to a single row (default: first). */
  private getQuestionRowElement(questionIndex = 0) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${questionIndex}`
    });
  }

  /** Hovers row `index` to reveal Delete, then clicks it. */
  async deleteQuestionAt(index: number): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(row.hover(), ELEMENT_WAIT_TIMEOUT, `Hover question row (step: deleteQuestionAt, index ${index})`);
      const deleteButton = this.getDeleteQuestionElement(index);
      await this.waitUntilVisible(deleteButton, `Delete question button (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(deleteButton.click(), ELEMENT_WAIT_TIMEOUT, `Click Delete question button (index ${index})`);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to delete question (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers row `index` to reveal Duplicate, then clicks it; no-op at max questions. */
  async duplicateQuestionAt(index: number): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(row.hover(), ELEMENT_WAIT_TIMEOUT, `Hover question row (step: duplicateQuestionAt, index ${index})`);
      const duplicateButton = this.getDuplicateQuestionElement(index);
      await this.waitUntilVisible(duplicateButton, `Duplicate question button (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(duplicateButton.click(), ELEMENT_WAIT_TIMEOUT, `Click Duplicate question button (index ${index})`);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to duplicate question (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Angular CDK drag reorders on real pointer/mouse events, not native HTML5 DnD, so this uses explicit mouse-move steps instead of WebElement.dragTo(). */
  async dragQuestionRow(fromIndex: number, toIndex: number): Promise<void> {
    try {
      const row = this.getQuestionRowElement(fromIndex);
      await this.waitUntilVisible(row, `Question row (index ${fromIndex})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(row.hover(), ELEMENT_WAIT_TIMEOUT, `Hover question row (step: dragQuestionRow, index ${fromIndex})`);

      const rowResource = this.getResource('questionRow');
      const handle = this.webActionHandler.getWebElement({
        ...rowResource,
        selectorType: 'playwrights',
        selectorValue: `${rowResource.selectorValue} >> nth=${fromIndex} >> .drag-handle`
      });
      await this.waitUntilVisible(handle, `Drag handle (index ${fromIndex})`, ELEMENT_WAIT_TIMEOUT);

      const handleBox = await handle.executeScript((e) => {
        const r = e.getBoundingClientRect();
        return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
      });
      const targetRow = this.getQuestionRowElement(toIndex);
      await this.waitUntilVisible(targetRow, `Question row (index ${toIndex})`, ELEMENT_WAIT_TIMEOUT);
      const targetBox = await targetRow.executeScript((e) => {
        const r = e.getBoundingClientRect();
        return { x: r.x + r.width / 2, y: r.bottom - 4 };
      });

      await this.webActionHandler.mouseMove(handleBox.x, handleBox.y);
      await this.webActionHandler.mouseDown();
      await this.webActionHandler.mouseMove(handleBox.x, handleBox.y + 10);
      await this.webActionHandler.mouseMove((handleBox.x + targetBox.x) / 2, (handleBox.y + targetBox.y) / 2);
      await this.webActionHandler.mouseMove(targetBox.x, targetBox.y);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      await this.webActionHandler.mouseUp();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to drag question row (from ${fromIndex} to ${toIndex}): ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Publish's disabled state may be on the niq-button host (aria-disabled/state/disabled/class) or its inner `<button>` (`.disabled` property); check both, like getDuplicateDisabledState(). */
  async getPublishDisabledState(): Promise<{ disabled: boolean; hostOuterHtml: string; innerButtonOuterHtml: string | null; matchCount: number; innerText: string }> {
    try {
      const matchCount = (await this.webActionHandler.getWebElementsText(this.getResource('publishSurveyButton'))).length;
      const publishButton = this.webActionHandler.getWebElement(this.getResource('publishSurveyButton'));
      const innerText = (await publishButton.getText()).trim();
      const ariaDisabled = await publishButton.getAttribute('aria-disabled');
      const state = await publishButton.getAttribute('state');
      const disabledAttr = await publishButton.getAttribute('disabled');
      const classAttr = (await publishButton.getAttribute('class')) ?? '';
      const hostOuterHtml = String(await publishButton.executeScript((e) => e.outerHTML)).slice(0, 400);
      const innerButtonDisabled = await publishButton.executeScript((e) => {
        const inner = e.querySelector('button');
        return inner ? inner.disabled : null;
      });
      const innerButtonOuterHtml = await publishButton.executeScript((e) => {
        const inner = e.querySelector('button');
        return inner ? inner.outerHTML : null;
      });
      const disabled =
        ariaDisabled === 'true' ||
        state === 'disabled' ||
        disabledAttr !== null ||
        classAttr.split(/\s+/).includes('disabled') ||
        innerButtonDisabled === true;
      return {
        disabled,
        hostOuterHtml,
        innerButtonOuterHtml: innerButtonOuterHtml === null ? null : String(innerButtonOuterHtml).slice(0, 400),
        matchCount,
        innerText,
      };
    } catch (error) {
      throw new Error(`Failed to get publish disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** At 0 questions, the type tiles render directly with no toggle button; Rating is a stable stand-in tile. */
  async areAddQuestionOptionsVisible(timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<boolean> {
    try {
      const ratingTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));
      return await ratingTile.isVisible(timeoutMs);
    } catch (error) {
      throw new Error(`Failed to check add-question options visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getCurrentUrl(): Promise<string> {
    try {
      return await this.webActionHandler.getPageUrl();
    } catch (error) {
      throw new Error(`Failed to get current URL: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Selects questions [remaining, count) and deletes them, leaving exactly `remaining`; only exits Review Mode if still open (delete-all auto-closes it). */
  async deleteQuestionsDownTo(remaining: number): Promise<void> {
    try {
      await this.enterReviewMode();
      const count = await this.getQuestionCount();
      if (remaining <= 0) {
        await this.selectAll();
      } else {
        for (let index = remaining; index < count; index++) {
          await this.selectQuestionInReview(index);
        }
      }
      await this.deleteSelectedQuestions();
      const exitButton = this.webActionHandler.getWebElement(this.getResource('exitReviewModeButton'));
      if (!(await exitButton.isHidden())) {
        await this.exitReviewMode();
      }
    } catch (error) {
      throw new Error(`Failed to delete questions down to ${remaining}: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers the first row to reveal Duplicate, then hovers Duplicate and checks the max-questions tooltip appears. */
  async isDuplicateTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const row = this.getQuestionRowElement();
      const duplicateButton = this.getDuplicateQuestionElement();
      await this.withTimeout(row.hover(), ELEMENT_WAIT_TIMEOUT, 'Hover first question row');
      if (!(await duplicateButton.isVisible(SMALL_TIMEOUT))) {
        await this.webActionHandler.mouseMove(0, 0);
        await this.withTimeout(row.hover(), ELEMENT_WAIT_TIMEOUT, 'Re-hover first question row');
        await this.waitUntilVisible(duplicateButton, 'Duplicate question button', SMALL_TIMEOUT);
      }
      await this.withTimeout(duplicateButton.executeScript((e) => e.scrollIntoView()), ELEMENT_WAIT_TIMEOUT, 'Scroll Duplicate button into view');
      const duplicateResource = this.getResource('duplicateQuestionButton');
      const nativePage = (BasePage as any).page as import('playwright').Page; // gta exposes no public getter for the raw Page, and WebElement.hover() has no timeout param
      await nativePage.locator(duplicateResource.selectorValue).first().hover({ force: true, timeout: SMALL_TIMEOUT });
      const message = this.webActionHandler.getWebElement(this.getResource('maxQuestionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait (10s), no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off Duplicate so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check duplicate tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Duplicate's disabled state (aria-disabled or legacy `state` attribute) plus outerHTML for failure diagnostics. */
  async getDuplicateDisabledState(): Promise<{ disabled: boolean; outerHtml: string }> {
    try {
      const duplicateButton = this.getDuplicateQuestionElement();
      const ariaDisabled = await duplicateButton.getAttribute('aria-disabled');
      const state = await duplicateButton.getAttribute('state');
      const outerHtml = String(await duplicateButton.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { disabled: ariaDisabled === 'true' || state === 'disabled', outerHtml };
    } catch (error) {
      throw new Error(`Failed to get duplicate disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Clicks Validate survey; the page dims and shows a "Validating your survey" toast until recommendations land and the button becomes Publish survey. */
  async clickValidateSurvey(): Promise<void> {
    await this.clickWhenVisible('validateSurveyButton', 'Validate survey button');
  }

  /** Waits (existing NAVIGATION_TIMEOUT, no fixed delay) for 'publishSurveyButton' to appear once validation finishes. */
  async waitForValidationComplete(): Promise<void> {
    const publishButton = this.webActionHandler.getWebElement(this.getResource('publishSurveyButton'));
    await this.waitUntilVisible(publishButton, 'Publish survey button (after validation)', NAVIGATION_TIMEOUT);
  }

  async validateSurvey(): Promise<void> {
    try {
      await this.clickValidateSurvey();
      await this.waitForValidationComplete();
    } catch (error) {
      throw new Error(`Failed to validate survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isValidatingToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(this.getResource('validatingSurveyToastText'));
    return await toast.isVisible(SMALL_TIMEOUT);
  }

  async isChangesRecommendedToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    return await toast.isVisible(SMALL_TIMEOUT);
  }

  async isRecommendationTagVisible(): Promise<boolean> {
    const tag = this.webActionHandler.getWebElement(this.getResource('recommendationTagText'));
    return await tag.isVisible(SMALL_TIMEOUT);
  }

  async isViewOptiqFeedbackLinkVisible(): Promise<boolean> {
    const link = this.webActionHandler.getWebElement(this.getResource('viewOptiqFeedbackLink'));
    return await link.isVisible(SMALL_TIMEOUT);
  }

  /** Closes the validate/publish toast if one is still showing; does nothing otherwise. */
  async dismissToastIfVisible(): Promise<void> {
    const closeButton = this.webActionHandler.getWebElement(this.getResource('toastCloseButton'));
    if (await closeButton.isVisible(SMALL_TIMEOUT)) {
      await closeButton.click();
    }
  }

  /** Validates (if "Validate survey" is still the bottom button) then clicks Publish; fills Save-a-copy if it appears, otherwise Review survey details opens directly (already saved). */
  async publishSurvey(title: string): Promise<void> {
    try {
      const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
      if (await validateButton.isVisible(SMALL_TIMEOUT)) {
        await this.validateSurvey();
      }
      await this.dismissToastIfVisible();

      await this.clickWhenVisible('publishSurveyButton', 'Publish survey button');

      const titleInput = this.webActionHandler.getWebElement(this.getResource('saveCopyTitleInput'));
      const confirmDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      const [isTitleInputVisible, isConfirmDialogVisible] = await Promise.all([
        titleInput.isVisible(ELEMENT_WAIT_TIMEOUT),
        confirmDialogText.isVisible(ELEMENT_WAIT_TIMEOUT),
      ]);

      if (isTitleInputVisible) {
        await this.fillSaveCopyDialog(title);
      } else if (!isConfirmDialogVisible) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        throw new Error(`Neither the Save-a-copy dialog nor the Review survey details dialog appeared after clicking Publish (url: ${currentUrl})`);
      }
    } catch (error) {
      throw new Error(`Failed to publish survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Checks the last expected dimension index is visible in the Review survey details dialog's Quick review list. */
  async isPublishDialogDimensionCountVisible(expectedCount: number): Promise<boolean> {
    try {
      if (expectedCount <= 0) return true;
      const lastDimension = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('publish-dialog-dimension-by-index', String(expectedCount - 1), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(lastDimension, `Publish dialog dimension (index ${expectedCount - 1})`, 10000);
      return await lastDimension.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to verify Review survey details dimension count: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getPublishResponseSummaryText(): Promise<string> {
    try {
      const responseCount = this.webActionHandler.getWebElement(this.getResource('publish-response-count-text'));
      await this.waitUntilVisible(responseCount, 'Publish response count text', 10000);
      const text = await responseCount.getText();
      return (text ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read Review survey details response summary: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Polls until redirect to /my-assets plus success toast, or fails fast if `.survey-action-toast` shows non-success text (there's no separate error-only locator). */
  async verifyPublishSucceeded(confirmClickTime: number): Promise<boolean> {
    try {
      const elapsedSeconds = () => ((Date.now() - confirmClickTime) / 1000).toFixed(1);
      const actionToast = this.webActionHandler.getWebElement(this.getResource('survey-action-toast'));
      const successToast = this.webActionHandler.getWebElement(this.getResource('publish-success-toast'));

      const deadline = Date.now() + NAVIGATION_TIMEOUT;
      while (Date.now() < deadline) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        if (currentUrl.includes('my-assets')) {
          if (await successToast.isVisible(MEDIUM_TIMEOUT)) {
            return true;
          }
          const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
          throw new Error(`"Survey published successfully" toast did not appear after redirect (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`);
        }

        if (!(await actionToast.isHidden())) {
          const toastText = await actionToast.getText();
          if (!toastText.includes('Survey published successfully')) {
            throw new Error(`Publish failed: "${toastText}" (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s)`);
          }
        }

        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }

      const currentUrl = await this.webActionHandler.getPageUrl();
      const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
      throw new Error(`Timed out waiting for navigation to /my-assets after Confirm (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`);
    } catch (error) {
      throw new Error(`Failed to verify publish succeeded: ${error instanceof Error ? error.message : error}`);
    }
  }

  async confirmPublish(): Promise<boolean> {
    try {
      const confirmPublishDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      await this.waitUntilVisible(confirmPublishDialogText, 'Review survey details dialog text');
      const isConfirmDialogVisible = await confirmPublishDialogText.isVisible();

      await this.clickWhenVisible('confirmPublishButton', 'Confirm publish button');

      const publishingSurveyStatus = this.webActionHandler.getWebElement(this.getResource('publishingSurveyStatus'));
      await this.waitUntilVisible(publishingSurveyStatus, 'Publishing survey status');
      const isPublishingStatusVisible = await publishingSurveyStatus.isVisible();

      return isConfirmDialogVisible && isPublishingStatusVisible;
    } catch (error) {
      throw new Error(`Failed to confirm publish: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Commits a title edit via Tab (blur), since fill()/enterText() never blurs the field and this component only saves on blur. */
  async commitSurveyTitle(): Promise<void> {
    try {
      const titleInput = this.webActionHandler.getWebElement(this.getResource('surveyTitleInput'));
      await titleInput.pressTab();
    } catch (error) {
      throw new Error(`Failed to commit survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getSurveyTitleDisplay(): Promise<string> {
    try {
      const title = this.webActionHandler.getWebElement(this.getResource('surveyTitleDisplay'));
      await this.waitUntilVisible(title, 'Survey title display');
      return (await title.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read survey title display: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `.question-text` also matches the "Add question" button's own label; scoping to `.question-row >> nth=${index}` excludes it instead of relying on index alignment. */
  private getQuestionTextDisplayElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const resource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...resource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${resource.selectorValue}`
    });
  }

  /** Reads row `index`'s SAVED Required state from the "*" span, text-filtered so it can't match any sibling span; a short, non-hanging timeout since this is a point-in-time read. */
  private getRequiredStarElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const textResource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...textResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${textResource.selectorValue} >> span:text-is("*")`
    });
  }

  async isRequiredOn(index: number): Promise<boolean> {
    try {
      return await this.getRequiredStarElement(index).isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Required state (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Waits (bounded, no indefinite hang) for row `index`'s saved Required state to reach `desired`; returns
   *  false (not throw) on timeout so callers can produce their own assertion message. */
  async waitForRequiredState(index: number, desired: boolean, timeoutMs: number = MEDIUM_TIMEOUT): Promise<boolean> {
    try {
      await this.getRequiredStarElement(index).waitFor(timeoutMs, desired ? 'visible' : 'hidden');
      return true;
    } catch {
      return false;
    }
  }

  /** No-op if Required already matches `desired` (AI-generated questions may start Required ON); opens the row editor, toggles, saves, then confirms the change. */
  async setRequired(index: number, desired: boolean): Promise<void> {
    try {
      if ((await this.isRequiredOn(index)) === desired) {
        return;
      }
      await this.openQuestionForEditing(index);
      await this.toggleRequired(index);
      await this.saveQuestionChanges(index);
      if (!(await this.waitForRequiredState(index, desired, MEDIUM_TIMEOUT))) {
        throw new Error(`Required state for question ${index} did not reach ${desired} within ${MEDIUM_TIMEOUT}ms (step: waitForRequiredState)`);
      }
    } catch (error) {
      throw new Error(`Failed to set Required (index ${index}) to ${desired}: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Readonly display text includes a trailing `*` when Required is on. */
  async getQuestionTextDisplay(index: number): Promise<string> {
    try {
      const textElement = this.getQuestionTextDisplayElement(index);
      await this.waitUntilVisible(textElement, `Question text display (index ${index})`);
      return (await textElement.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read question ${index} text display: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers row `index` (same hover-reveal gating as getQuestionRowElement()) then clicks Edit and waits for the editor to open. */
  async openQuestionForEditing(index: number): Promise<void> {
    try {
      await this.closeInlineAddEditorIfOpen();
      const rowResource = this.getResource('questionRow');
      const rowLocator = `${rowResource.selectorValue} >> nth=${index}`;
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (step: hover, index ${index}, locator: ${rowLocator})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(
        row.hover(),
        ELEMENT_WAIT_TIMEOUT,
        `Hover question row (step: hover, index ${index}, locator: ${rowLocator})`
      );
      const editButtonResource = this.getResource('editQuestionButton');
      const editButtonLocator = `${editButtonResource.selectorValue} >> nth=${index}`;
      const editButton = this.webActionHandler.getWebElement({
        ...editButtonResource,
        selectorType: 'playwrights',
        selectorValue: editButtonLocator
      });
      await this.waitUntilVisible(editButton, `Edit question button (step: click edit pencil, index ${index}, locator: ${editButtonLocator})`, ELEMENT_WAIT_TIMEOUT);
      await this.withTimeout(
        editButton.click(),
        ELEMENT_WAIT_TIMEOUT,
        `Click Edit question button (step: click edit pencil, index ${index}, locator: ${editButtonLocator})`
      );
      const saveButtonResource = this.getResource('saveQuestionChangesButton');
      const saveButton = this.webActionHandler.getWebElement(saveButtonResource);
      await this.waitUntilVisible(saveButton, `Save changes button (step: question editor open, index ${index}, locator: ${saveButtonResource.selectorValue})`, ELEMENT_WAIT_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to open question ${index} for editing: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** When `index` is given, scopes Save changes to that row so it can't click another open editor's Save button. */
  async saveQuestionChanges(index?: number): Promise<void> {
    try {
      if (index === undefined) {
        await this.clickWhenVisible('saveQuestionChangesButton', 'Save changes button');
      } else {
        const rowResource = this.getResource('questionRow');
        const saveButtonResource = this.getResource('saveQuestionChangesButton');
        const saveButton = this.webActionHandler.getWebElement({
          ...saveButtonResource,
          selectorType: 'playwrights',
          selectorValue: `${rowResource.selectorValue} >> nth=${index} >> .save-changes-action:visible`
        });
        await this.waitUntilVisible(saveButton, `Save changes button (index ${index})`);
        await this.withTimeout(
          saveButton.click(),
          ELEMENT_WAIT_TIMEOUT,
          `Click Save changes button (step: saveQuestionChanges, index ${index}, locator: ${rowResource.selectorValue} >> nth=${index} >> .save-changes-action:visible)`
        );
      }
    } catch (error) {
      throw new Error(`Failed to save question changes: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Rating leaves its text-input `data-test-id` unset (defaults to "-input"); Choice/NPS/Scale set it explicitly, so matching the common `-input` suffix works for every question type without depending on index alignment. */
  private getQuestionTextFieldElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const textResource = this.getResource('questionTextInput');
    return this.webActionHandler.getWebElement({
      ...textResource,
      selectorType: 'playwrights',
      // nth=0 picks the question-text field, always the first survey-question-editor input in DOM order.
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> survey-question-editor input:is([data-test-id$='-input'], [data-test-id^='question-text-input']):visible >> nth=0`
    });
  }

  /** Opens question `index` for editing, replaces its text, and saves. */
  async editQuestionText(index: number, newText: string): Promise<void> {
    try {
      await this.openQuestionForEditing(index);
      const textField = this.getQuestionTextFieldElement(index);
      await this.waitUntilVisible(textField, `Question text field (index ${index})`);
      await textField.enterText(newText);
      await this.saveQuestionChanges(index);
    } catch (error) {
      throw new Error(`Failed to edit question ${index} text (expected text field to accept "${newText}" and save): ${error instanceof Error ? error.message : error}`);
    }
  }
}
