/**
 * Include the .json translation
 * i18n en.json and es.json file paths
 * in order to be used in our TranslationLoader
 */
export const jsonPaths: string[] = [
	'assets/i18n/@nielseniq/global-translate',
];

export const locales = {
  EN_US: 'en-US',
  ES_CO: 'es-CO',
  DE_DE: 'de-DE',
  EN_GB: 'en-GB',
  FR_FR: 'fr-FR',
  ES_ES: 'es-ES',
  IT_IT: 'it-IT',
  PT_PT: 'pt-PT',
  TR_TR: 'tr-TR',
  NL_NL: 'nl-NL',
  KO_KR: 'ko-KR',
  ZH_TW: 'zh-TW',
  ZH_CN: 'zh-CN',
};

export const formatLocale = (locale: string) => (locale ? locale.replace('_', '-') : '');
