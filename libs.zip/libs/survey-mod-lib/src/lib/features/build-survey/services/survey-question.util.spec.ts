import { describe, expect, it } from 'vitest';
import { QuestionTypes } from '../models/build-survey';
import {
  extractRephrasedQuestion,
  isChoiceOptionsValid,
  isChoiceType,
  isQuestionTextValid,
  isQuestionValid,
  isScaleMatrixValid,
  isScaleType,
  isStarRatingRowsValid,
  normalizeRephrasedQuestion,
} from './survey-question.util';

describe('survey-question.util', () => {
  describe('isQuestionTextValid', () => {
    it('should return true for valid question text', () => {
      expect(isQuestionTextValid('What is your favorite color?')).toBe(true);
      expect(isQuestionTextValid('  Question with spaces  ')).toBe(true);
    });

    it('should return false for empty/whitespace text', () => {
      expect(isQuestionTextValid('')).toBe(false);
      expect(isQuestionTextValid('   ')).toBe(false);
      expect(isQuestionTextValid(null)).toBe(false);
      expect(isQuestionTextValid(undefined)).toBe(false);
    });
  });

  describe('isChoiceType', () => {
    it('should return true for SingleChoice', () => {
      expect(isChoiceType(QuestionTypes.SingleChoice)).toBe(true);
    });

    it('should return true for MultipleChoice', () => {
      expect(isChoiceType(QuestionTypes.MultipleChoice)).toBe(true);
    });

    it('should return false for non-choice types', () => {
      expect(isChoiceType(QuestionTypes.Text)).toBe(false);
      expect(isChoiceType(QuestionTypes.NetPromoterScore)).toBe(false);
      expect(isChoiceType(QuestionTypes.SinglePointScale)).toBe(false);
      expect(isChoiceType(QuestionTypes.MultiplePointScale)).toBe(false);
      expect(isChoiceType('INVALID_TYPE' as any)).toBe(false);
      expect(isChoiceType('')).toBe(false);
    });
  });

  describe('isChoiceOptionsValid', () => {
    it('should return true when options meet minimum count and are non-empty', () => {
      expect(isChoiceOptionsValid(['Option 1', 'Option 2'])).toBe(true);
      expect(isChoiceOptionsValid(['A', 'B', 'C'])).toBe(true);
    });

    it('should return false when options count is less than 2', () => {
      expect(isChoiceOptionsValid([])).toBe(false);
      expect(isChoiceOptionsValid(['Only One'])).toBe(false);
    });

    it('should return false when any option is empty or whitespace', () => {
      expect(isChoiceOptionsValid(['Option 1', ''])).toBe(false);
      expect(isChoiceOptionsValid(['Option 1', '   '])).toBe(false);
      expect(isChoiceOptionsValid(['', '', 'Option 1'])).toBe(false);
    });

    it('should return false for null/undefined input', () => {
      expect(isChoiceOptionsValid(null)).toBe(false);
      expect(isChoiceOptionsValid(undefined)).toBe(false);
    });

    it('should handle options with special characters', () => {
      expect(isChoiceOptionsValid(['Option!', 'Option@'])).toBe(true);
      expect(isChoiceOptionsValid(['  Trimmed  ', '  Also Trimmed  '])).toBe(true);
    });
  });

  describe('isScaleType', () => {
    it('should return true for SinglePointScale', () => {
      expect(isScaleType(QuestionTypes.SinglePointScale)).toBe(true);
    });

    it('should return true for MultiplePointScale', () => {
      expect(isScaleType(QuestionTypes.MultiplePointScale)).toBe(true);
    });

    it('should return false for non-scale types', () => {
      expect(isScaleType(QuestionTypes.SingleChoice)).toBe(false);
      expect(isScaleType(QuestionTypes.Text)).toBe(false);
      expect(isScaleType(QuestionTypes.NetPromoterScore)).toBe(false);
      expect(isScaleType('INVALID_TYPE' as any)).toBe(false);
      expect(isScaleType('')).toBe(false);
    });
  });

  describe('isScaleMatrixValid', () => {
    it('should return true when rows and columns meet requirements', () => {
      expect(isScaleMatrixValid(['Row 1', 'Row 2'], ['Col 1', 'Col 2'])).toBe(true);
      expect(isScaleMatrixValid(['R1', 'R2', 'R3'], ['C1', 'C2'])).toBe(true);
    });

    it('should return false when rows count is less than 2', () => {
      expect(isScaleMatrixValid(['Row 1'], ['Col 1', 'Col 2'])).toBe(false);
      expect(isScaleMatrixValid([], ['Col 1', 'Col 2'])).toBe(false);
    });

    it('should return false when columns count is less than 2', () => {
      expect(isScaleMatrixValid(['Row 1', 'Row 2'], ['Col 1'])).toBe(false);
      expect(isScaleMatrixValid(['Row 1', 'Row 2'], [])).toBe(false);
    });

    it('should return false when any row or column is empty or whitespace', () => {
      expect(isScaleMatrixValid(['Row 1', ''], ['Col 1', 'Col 2'])).toBe(false);
      expect(isScaleMatrixValid(['Row 1', '   '], ['Col 1', 'Col 2'])).toBe(false);
      expect(isScaleMatrixValid(['Row 1', 'Row 2'], ['Col 1', ''])).toBe(false);
    });

    it('should return false for null/undefined input', () => {
      expect(isScaleMatrixValid(null, ['Col 1', 'Col 2'])).toBe(false);
      expect(isScaleMatrixValid(['Row 1', 'Row 2'], null)).toBe(false);
      expect(isScaleMatrixValid(undefined, undefined)).toBe(false);
    });
  });

  describe('isStarRatingRowsValid', () => {
    it('should accept one or more non-empty row labels', () => {
      expect(isStarRatingRowsValid(['Overall'])).toBe(true);
      expect(isStarRatingRowsValid(['Quality', 'Value'])).toBe(true);
    });

    it('should reject missing, empty, or whitespace-only rows', () => {
      expect(isStarRatingRowsValid([])).toBe(false);
      expect(isStarRatingRowsValid([''])).toBe(false);
      expect(isStarRatingRowsValid(['Quality', '   '])).toBe(false);
      expect(isStarRatingRowsValid(null)).toBe(false);
      expect(isStarRatingRowsValid(undefined)).toBe(false);
    });
  });

  describe('isQuestionValid', () => {
    it('should validate valid SingleChoice question', () => {
      const question = {
        question: 'Choose one?',
        type: QuestionTypes.SingleChoice,
        options: ['Option 1', 'Option 2'],
      };

      expect(isQuestionValid(question)).toBe(true);
    });

    it('should validate valid MultipleChoice question', () => {
      const question = {
        question: 'Choose multiple?',
        type: QuestionTypes.MultipleChoice,
        options: ['A', 'B', 'C'],
      };

      expect(isQuestionValid(question)).toBe(true);
    });

    it('should validate valid scale question', () => {
      const question = {
        question: 'Rate this?',
        type: QuestionTypes.SinglePointScale,
        rowOptions: ['Row 1', 'Row 2'],
        columnOptions: ['Col 1', 'Col 2'],
      };

      expect(isQuestionValid(question)).toBe(true);
    });

    it('should validate StarRating rows and reject missing or blank labels', () => {
      const question = {
        question: 'Rate these aspects?',
        type: QuestionTypes.StarRating,
        rowOptions: ['Quality'],
      };

      expect(isQuestionValid(question)).toBe(true);
      expect(isQuestionValid({ ...question, rowOptions: [] })).toBe(false);
      expect(isQuestionValid({ ...question, rowOptions: [' '] })).toBe(false);
    });

    it('should validate non-choice/scale types with just question text', () => {
      const question = {
        question: 'What is your name?',
        type: QuestionTypes.Text,
      };

      expect(isQuestionValid(question)).toBe(true);
    });

    it('should return false when question text is empty', () => {
      const question = {
        question: '',
        type: QuestionTypes.Text,
      };

      expect(isQuestionValid(question)).toBe(false);
    });

    it('should return false for choice question without valid options', () => {
      const question = {
        question: 'Choose?',
        type: QuestionTypes.SingleChoice,
        options: ['Only one'],
      };

      expect(isQuestionValid(question)).toBe(false);
    });

    it('should return false for scale question without valid matrix', () => {
      const question = {
        question: 'Rate?',
        type: QuestionTypes.SinglePointScale,
        rowOptions: ['Row 1'],
        columnOptions: ['Col 1', 'Col 2'],
      };

      expect(isQuestionValid(question)).toBe(false);
    });

    it('should handle undefined question field', () => {
      const question = {
        question: undefined,
        type: QuestionTypes.Text,
      };

      expect(isQuestionValid(question)).toBe(false);
    });
  });

  describe('normalizeRephrasedQuestion', () => {
    it('should normalize rephrase response with SingleChoice', () => {
      const response = {
        question: 'What is your preference?',
        type: QuestionTypes.SingleChoice,
        options: ['Option A', 'Option B'],
        isRequired: true,
      };
      const currentQuestion = undefined;

      const result = normalizeRephrasedQuestion(response, currentQuestion, 0);

      expect(result).toBeDefined();
      expect(result?.question).toBe('What is your preference?');
      expect(result?.type).toBe(QuestionTypes.SingleChoice);
      expect(result?.options).toEqual(['Option A', 'Option B']);
      expect(result?.isRequired).toBe(true);
    });

    it('should normalize scale question', () => {
      const response = {
        question: 'Rate the experience?',
        type: QuestionTypes.MultiplePointScale,
        rowOptions: ['Very Poor', 'Poor', 'Good', 'Excellent'],
        columnOptions: ['Q1', 'Q2', 'Q3'],
      };

      const result = normalizeRephrasedQuestion(response, undefined, 1);

      expect(result?.questionNumber).toBe(2);
      expect(result?.rowOptions).toEqual(['Very Poor', 'Poor', 'Good', 'Excellent']);
      expect(result?.columnOptions).toEqual(['Q1', 'Q2', 'Q3']);
    });

    it('should normalize NPS question', () => {
      const response = {
        question: 'How likely are you to recommend?',
        type: QuestionTypes.NetPromoterScore,
        npsLeftLabel: 'Very Unlikely',
        npsRightLabel: 'Very Likely',
      };

      const result = normalizeRephrasedQuestion(response, undefined, 2);

      expect(result?.type).toBe(QuestionTypes.NetPromoterScore);
      expect(result?.npsLeftLabel).toBe('Very Unlikely');
      expect(result?.npsRightLabel).toBe('Very Likely');
    });

    it('should use current question as fallback', () => {
      const response = {
        question: 'Updated question?',
        isRequired: true,
      };
      const currentQuestion = {
        questionNumber: 5,
        question: 'Old question?',
        type: QuestionTypes.SingleChoice,
        options: ['A', 'B'],
        isRequired: false,
        rowOptions: [],
        columnOptions: [],
        npsLeftLabel: '',
        npsRightLabel: '',
      };

      const result = normalizeRephrasedQuestion(response, currentQuestion, 0);

      expect(result?.questionNumber).toBe(5);
      expect(result?.type).toBe(QuestionTypes.SingleChoice);
      expect(result?.isRequired).toBe(true);
    });

    it('should return null for invalid response', () => {
      const result = normalizeRephrasedQuestion(null, undefined, 0);

      expect(result).toBeNull();
    });

    it('should trim whitespace from text fields', () => {
      const response = {
        question: '  Trimmed question  ',
        type: QuestionTypes.NetPromoterScore,
        npsLeftLabel: '  Not Likely  ',
        npsRightLabel: '  Very Likely  ',
      };

      const result = normalizeRephrasedQuestion(response, undefined, 0);

      expect(result?.question).toBe('Trimmed question');
      expect(result?.npsLeftLabel).toBe('Not Likely');
      expect(result?.npsRightLabel).toBe('Very Likely');
    });
  });

  describe('extractRephrasedQuestion', () => {
    it('should extract from simple question object', () => {
      const response = {
        question: 'What is your preference?',
        type: QuestionTypes.SingleChoice,
        options: ['A', 'B'],
      };

      const result = extractRephrasedQuestion(response);

      expect(result?.question).toBe('What is your preference?');
      expect(result?.options).toEqual(['A', 'B']);
    });

    it('should extract from nested result property', () => {
      const response = {
        result: {
          question: 'Nested question?',
          type: QuestionTypes.Text,
        },
      };

      const result = extractRephrasedQuestion(response);

      expect(result?.question).toBe('Nested question?');
      expect(result?.type).toBe(QuestionTypes.Text);
    });

    it('should extract from nested question property', () => {
      const response = {
        question: {
          question: 'Double nested?',
          options: ['X', 'Y'],
        },
      };

      const result = extractRephrasedQuestion(response);

      expect(result?.question).toBe('Double nested?');
      expect(result?.options).toEqual(['X', 'Y']);
    });

    it('should extract from array', () => {
      const response = [{
        question: 'Array question?',
        type: QuestionTypes.MultipleChoice,
      }];

      const result = extractRephrasedQuestion(response);

      expect(result?.question).toBe('Array question?');
      expect(result?.type).toBe(QuestionTypes.MultipleChoice);
    });

    it('should return null for invalid response', () => {
      expect(extractRephrasedQuestion(null)).toBeNull();
      expect(extractRephrasedQuestion(undefined)).toBeNull();
      expect(extractRephrasedQuestion('not an object')).toBeNull();
      expect(extractRephrasedQuestion({})).toBeNull();
      expect(extractRephrasedQuestion({ result: {} })).toBeNull();
    });

    it('should handle response with result property containing array', () => {
      const response = {
        result: [{
          question: 'Array in result?',
          type: QuestionTypes.Text,
        }],
      };

      const result = extractRephrasedQuestion(response);

      expect(result?.question).toBe('Array in result?');
    });

    it('should prioritize result over question property', () => {
      const response = {
        result: {
          question: 'From result',
        },
        question: {
          question: 'From question',
        },
      };

      const result = extractRephrasedQuestion(response);

      expect(result?.question).toBe('From result');
    });
  });
});
