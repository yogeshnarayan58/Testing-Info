import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { findDataSetByName, getDimensionSelectionsByPivot, getTestDataByLocale, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Average price";

  test.describe.serial(
    "Consumer Distribution Analysis - Average price Pivot",
    { tag: ["@Report_E2E_Flow"] },
    async () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;
    let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
    test.beforeAll(() => {
      const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
      if (!isValidTestData) {
        console.warn('Skipping tests as the required pivot test data is not present');
      }
      test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
    });
    test(
      "Validate run report",
      {
        tag: "@RunReport",
      },
      async () => {
         test.setTimeout(RUN_TEST_TIMEOUT);
        // Initialize base page with authentication from storage/auth.json (created in global setup)
        let basePage = await BasePageFactory.createBasePage();
        dataSelector = new DataSelector(basePage);
        
        // Navigate to the specific report URL
        await dataSelector.navigateToUrl(reportUrl);
        
        // Click additional prompt ellipsis first to reveal pivot dropdown
        await dataSelector.clickAdditionalPromptEllipsisIcon();
        
        // Switch to "Average price" pivot
        await dataSelector.switchPivotDropdown(pivot);

        // Get Average price pivot data
        const averagePriceData = getDimensionSelectionsByPivot(pivot, reportTestData);
        
        await dataSelector.clickMadlibDimension("Product Universe");
        await dataSelector.setMadlibSelection(
          averagePriceData["Product Universe"]
        );

        // Configure Range dimension
        await dataSelector.clickMadlibDimension("Range");
        const rangeConfig = averagePriceData["Range"];
        await dataSelector.clickMadlibDimension("defineNewRangeButton");
        
        await dataSelector.configureRange(
          rangeConfig.volumetricType,     // Volumetric type from dropdown (e.g., "Avg. Price (EQ2)")
          rangeConfig.minValue,           // Min value
          rangeConfig.maxValue,           // Max value
          rangeConfig.incrementValue      // Increment value
        );   

        await dataSelector.clickMadlibDimension("Products");
        await dataSelector.setMadlibSelection(
          averagePriceData["Products"]
        );
         await dataSelector.waitForMadlibStability();
                
        await dataSelector.clickMadlibDimension("Retailers");
        await dataSelector.setMadlibSelection(
          averagePriceData["Retailers"]
        );
        await dataSelector.clickMadlibDimension("Period");
        await dataSelector.setPeriodMadlibSelection(
          averagePriceData["Period"]
        );
        await dataSelector.clickMadlibDimension("Facts");
        await dataSelector.selectClosedDropdown(
          averagePriceData["Facts"]["selections"]
        );
        await dataSelector.clickMadlibDimension("Geography");
        await dataSelector.setMadlibSelection(
          averagePriceData["Geography"]
        );
        await dataSelector.clickMadlibDimension("Period");
        await dataSelector.setPeriodMadlibSelection(
          averagePriceData["Period"]
        );
        await dataSelector.clickMadlibDimension("Demography");
        await dataSelector.setMadlibSelection(
          averagePriceData["Demography"]
        );
        // await dataSelector.clickMadlibDimension("People");
        // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
        // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
        // for (const selection of averagePriceData["People"]
        //   .selections) {
        //   await dataSelector.handlePeopleMenuOptions(selection);
        // }

        let dsBasePage = await dataSelector.getBasePage();
        commonTestCase = new CommonTestCase(dsBasePage);
        await commonTestCase.clickRunButton();
        await commonTestCase.waitForReportRunCompletion();
        console.log("run complete in spec");
        const { newReportTitle, newUrl } =
          await commonTestCase.saveReport();
        savedReportTitle = newReportTitle;
        savedReportUrl = newUrl;
        console.log("savedReportTitle:", savedReportTitle);
        console.log("savedReportUrl:", savedReportUrl);
      }
    );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
    });
  