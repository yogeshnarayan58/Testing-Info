import { RIGHTS_CONFIG, RightsUtilityService } from '@nielsen/crf-lp-common';
import { SurveyActionItem } from '../../../shared/components/survey-action-items/survey-action-items.model';
import { SurveyStatusType } from '../../build-survey/models/build-survey';
import { SurveyGridRow } from '../models/survey-asset.model';
import { isFolderAsset } from '../utils/survey-status.util';
import { ASSET_TYPE, MY_ASSETS_TABS, MyAssetsTabId } from './my-assets-tabs.constant';

export type MyAssetsSelectionActionId = 'open-new-tab' | 'move' | 'info' | 'duplicate' | 'rename' | 'share' | 'delete' | 'restore';

type Selection = readonly SurveyGridRow[];

const isSingleSelection = (rows: Selection): boolean => rows.length === 1;
const isMultiSelection = (rows: Selection): boolean => rows.length > 1;
const isSingleSurvey = (rows: Selection): boolean => isSingleSelection(rows) && rows[0].assetType === ASSET_TYPE.DISCOVERSURVEY;
const isSingleFolder = (rows: Selection): boolean => isSingleSelection(rows) && isFolderAsset(rows[0]);
const isClosedSurvey = (row: SurveyGridRow): boolean => row.status?.toUpperCase() === SurveyStatusType.CLOSED;

/**
 * Bulk actions for the My Assets grid selection, in display order.
 * - Single survey: all actions; Share only once the survey is Closed.
 * - Single folder: Info, Rename, Share, Delete.
 * - Multiple assets: Move to, Delete.
 */
export const MY_ASSETS_SELECTION_ACTIONS: readonly SurveyActionItem<SurveyGridRow, MyAssetsSelectionActionId>[] = [
  { id: 'open-new-tab', label: 'Open in new window', iconName: 'open', isVisible: isSingleSurvey },
  { id: 'move', label: 'Move to', iconName: 'folder-move', isVisible: (rows) => isSingleSurvey(rows) || isMultiSelection(rows) },
  { id: 'info', label: 'Info', iconName: 'info', isVisible: isSingleSelection },
  { id: 'duplicate', label: 'Duplicate', iconName: 'duplicate', isVisible: isSingleSurvey },
  { id: 'rename', label: 'Rename', iconName: 'rename', isVisible: isSingleSelection },
  {
    id: 'share',
    label: 'Share',
    iconName: 'share',
    isVisible: (rows) => isSingleFolder(rows) || (isSingleSurvey(rows) && isClosedSurvey(rows[0])),
  },
  { id: 'delete', label: 'Delete', iconName: 'trash' },
];

export function getMyAssetsSelectionActions(
  tab: MyAssetsTabId,
  userId: string | undefined,
  rightsUtility: Pick<RightsUtilityService, 'checkAvailableRightsForMe'>
): readonly SurveyActionItem<SurveyGridRow, MyAssetsSelectionActionId>[] {
  if (tab === MY_ASSETS_TABS.TRASH) {
    return [
      { id: 'restore', label: 'Restore', iconName: 'undo', isVisible: (rows) => rows.length > 0 },
      { id: 'delete', label: 'Delete permanently', iconName: 'trash', isVisible: (rows) => rows.length > 0 },
      { id: 'info', label: 'Info', iconName: 'info', isVisible: isSingleSelection },
    ];
  }

  return MY_ASSETS_SELECTION_ACTIONS.map((action) => ({
    ...action,
    isVisible: (rows: Selection): boolean => {
      if (!rows.length || !(action.isVisible?.(rows) ?? true)) {
        return false;
      }
      if (action.id === 'move') {
        return tab === MY_ASSETS_TABS.MY_ASSETS && rows.length <= 20 && !!userId
          && rows.every((row) => row.assetType === ASSET_TYPE.DISCOVERSURVEY
            && rightsUtility.checkAvailableRightsForMe(row, userId, RIGHTS_CONFIG.EDITOR_RIGHTS));
      }
      if (isMultiSelection(rows)) {
        return true;
      }
      const row = rows[0];
      if (action.id === 'info' || action.id === 'open-new-tab' || action.id === 'duplicate') {
        return true;
      }
      if (!userId || !rightsUtility.checkAvailableRightsForMe(row, userId, RIGHTS_CONFIG.EDITOR_RIGHTS)) {
        return false;
      }
      if (action.id === 'delete') {
        return row.rights?.some((right) => right.availability === 'OWNED'
          && (right.userId === userId || (right.orderManagementType === 'COG' && !right.userId))) ?? false;
      }
      return true;
    },
  }));
}
