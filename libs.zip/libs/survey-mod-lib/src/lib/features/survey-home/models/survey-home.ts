import { SurveyStatusVariant } from '../../my-assets/constants/survey-status.constant';

export interface Survey {
  id: string;
  name: string;
  status: 'closed' | 'in-progress' | 'draft';
  statusText: string;
  icon?: string;          
  date: string;
  responseCount?: string;  
  variant?: SurveyStatusVariant;
  launchURL?: string;
}

export interface FeatureCard {
  id: string;
  title: string;
  description: string;
  image?: string;
  url?: string;
}

export interface HelpItem {
  id: string;
  title: string;
  meta: string;
  image?: string;
  url?: string;
}

export interface QuickSurveyCard {
  id: string;
  label: string;
  description: string;
  metadata?: string;
}

export interface PrebuiltSurvey {
  id: string;
  title: string;
  questionCount: number;
}

export interface SurveyCredits {
  used: number;
  total: number;
  remaining: number;
  resetText: string;
}

export const FEATURE_CARDS: ReadonlyArray<FeatureCard> = [
  { 
    id: 'feature-1', 
    title: 'Survey report templates', 
    description: 'Open your survey results in a prebuilt report to integrate with your NIQ data',
    url: 'https://uat.service.nielseniq.io/home/userguides/solution/5uYUwSfuaNKgXXFJmnXQl?solutionName=Discover'
  },
  { 
    id: 'feature-2', 
    title: 'GfK survey', 
    description: 'Create surveys using the GfK panel to gather feedback from targeted audiences',
    url: 'https://uat.service.nielseniq.io/home/userguides/solution/5uYUwSfuaNKgXXFJmnXQl?solutionName=Discover'
  }
];

export const SURVEY_PREVIEW_RESPONSE_COUNTS: ReadonlyArray<string> = [
  '500/500 responses',
  '400/800 responses',
  '250/600 responses',
  '0/0 responses'
];

export const DEFAULT_RESPONSE_COUNT = '0/0 responses';
export const SURVEY_HOME_FETCH_LIMIT = 15;

export const HELP_ITEMS: ReadonlyArray<HelpItem> = [
  { 
    id: 'help-1', 
    title: 'Get started with survey', 
    meta: 'Central - Home',
    image: 'assets/images/GettyImages-2249995450.jpg',
    url: 'https://nielseniq.com/'
  },
  { 
    id: 'help-2', 
    title: 'Become a survey expert', 
    meta: 'Enhance Product Strategy with Development Solutions',
    image: 'assets/images/GettyImages-1500651098.jpg',
    url: 'https://nielseniq.com/global/en/solutions/innovation/?_gl=1*1416ite*_up*MQ..*_ga*ODc0NTI2ODcyLjE3OTMwMjY2MDY.*_ga_KKW9KLS56J*czE3OTMwMjY2MDYkbzEkZzEkdDE3OTMwMjY2MTIkajU0JGwwJGgw'
  },
  { 
    id: 'help-3', 
    title: 'Using Optiq with survey', 
    meta: 'Industry Trends - NIQ',
    image: 'assets/images/GettyImages-1322511398.jpg',
    url: 'https://nielseniq.com/global/en/insights/industry-trends/?_gl=1*1d7ttwt*_up*MQ..*_ga*ODY2Mzk3NjgzLjE3OTMwMjYzNzM.*_ga_KKW9KLS56J*czE3OTMwMjYzNzIkbzEkZzAkdDE3OTMwMjYzNzIkajYwJGwwJGgw'
  },
  { 
    id: 'help-4', 
    title: 'What\'s new in surveys', 
    meta: 'AI for Business: Enterprise AI Insights & Use Cases | NIQ',
    image: 'assets/images/GettyImages-2125180482.jpg',
    url: 'https://nielseniq.com/global/en/hubs/artificial-intelligence/?_gl=1*1ipoge8*_up*MQ..*_ga*ODY2Mzk3NjgzLjE3OTMwMjYzNzM.*_ga_KKW9KLS56J*czE3OTMwMjYzNzIkbzEkZzEkdDE3OTMwMjY2NDckajYwJGwwJGgw'
  }
];

export const QUICK_SURVEY_CARDS: ReadonlyArray<QuickSurveyCard> = [
  { id: 'quick-1', label: 'Build with Optiq', description: 'Describe your goal and Optiq will generate your survey', metadata: 'Fully editable before you publish' },
  { id: 'quick-2', label: 'Start from scratch', description: 'Build your survey question by question', metadata: 'Blank survey' },
  { id: 'quick-3', label: 'Import a survey', description: 'Bring in a survey from another platform', metadata: 'docs, .xlsx, .csv' }
];

export const PREBUILT_SURVEYS: ReadonlyArray<PrebuiltSurvey> = [
  { id: 'prebuilt-1', title: 'New, lost, retained survey', questionCount: 5 },
  { id: 'prebuilt-2', title: 'Product satisfaction score', questionCount: 4 },
  { id: 'prebuilt-3', title: 'User satisfaction survey', questionCount: 4 },
  { id: 'prebuilt-4', title: 'Brand perception study', questionCount: 3 }
];

export const SURVEY_CREDITS: SurveyCredits = {
  used: 480,
  total: 600,
  remaining: 120,
  resetText: 'Resets Jan 1'
};

export const SURVEY_CREDITS_NO_USAGE: SurveyCredits = {
  ...SURVEY_CREDITS,
  used: 0,
  remaining: 600
};

export const PRIORITY_ORDER = ['closed', 'in-progress', 'draft'] as const;

export const ASSET_TYPES = {
  DISCOVER_FOLDER: 'DISCOVERFOLDER',
  DISCOVER_SHARED_FOLDER: 'DISCOVERSHAREDFOLDER'
} as const;
