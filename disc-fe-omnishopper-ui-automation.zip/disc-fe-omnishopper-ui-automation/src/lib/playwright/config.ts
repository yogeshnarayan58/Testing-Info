/* eslint-disable import/prefer-default-export */
import { LaunchOptions } from '@playwright/test';
import { parseBoolean, resolveEnvValue } from '../common/utils/env-utils';

const parseNumber = (value: string | undefined, fallback: number): number => {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const isCI = parseBoolean(process.env.CI, false);
const cliHeadless = process.env.PLAYWRIGHT_HEADLESS;
// Headless precedence:
//  1) HEADLESS env var (explicit opt-in/out when set)
//  2) PLAYWRIGHT_HEADLESS env var (CLI override)
//  3) CI detection fallback via process.env.CI (defaults to true in CI, false locally)
// This keeps CI runs headless unless explicitly overridden while keeping local runs headed by default.
const headlessValue = parseBoolean(process.env.HEADLESS ?? cliHeadless, isCI);
const slowMoValue = parseNumber(process.env.PW_SLOW_MO ?? process.env.SLOW_MO, 0);

/**
 * Playwright browser launch configuration shared by BasePageFactory and the test runner.
 * - `slowMo` allows throttling UI interactions when PW_SLOW_MO/SLOW_MO is set.
 * - `headless` respects HEADLESS/PLAYWRIGHT_HEADLESS/CI precedence for consistent CI behavior.
 * - `args` ensure fullscreen windows and deterministic media permissions.
 * - `firefoxUserPrefs` mocks media streams to keep video components stable in automation.
 */
const browserOptions: LaunchOptions = {
  slowMo: slowMoValue,
  headless: headlessValue,
  args: [
    '--start-maximized', // for fullscreen window
    '--use-fake-ui-for-media-stream',
    '--use-fake-device-for-media-stream',
  ],
  firefoxUserPrefs: {
    'media.navigator.streams.fake': true,
    'media.navigator.permission.disabled': true,
  },
};

// config.ts

export const config = {
  // Project-specific information
  project: process.env.PROJECT?.trim() || 'sample_project',
  TestTimeout: 100 * 1000,
  assertionTimeout: 5000,
  runFilesInParallel: true,
  actionTimeout: 0,
  playwrightTrace: 'on',

  // Browser-related configuration
  browser: (process.env.BROWSER?.trim() as 'chromium' | 'firefox' | 'webkit') || 'chromium',
  viewport: { width: 1920, height: 1080 },
  browserOptions,

  // Miscellaneous settings
  ENV: process.env.ENV || 'DEV',
  LOCALE: process.env.LOCALE || 'en-US',
  DATASET: process.env.DATASET || 'Omni Agg SI 3yrs Synd',
  // DATASET_SECONDARY: process.env.DATASET_SECONDARY || 'DE ES IT PT CH FR GB - Syndicated - Total store',

  cucumberTrace: false,
  storageState: 'storage/auth.json',
  keepStorageState: true,
  logger: 'console-only',
  baseURLs: {
    DEV: 'https://si.connect.nielseniq.io/reportexperience-dev',
    SI: 'https://si.connect.nielseniq.io/reportexperience',
    UAT: 'https://uat.connect.nielseniq.io/reportexperience',
    LOCAL:'http://localhost:4200',
    EUSI: 'https://eusi.connect.nielseniq.io/reportexperience',
    // Production Environments
    PROD_US: 'https://connect.nielseniq.com/discover',
    PROD_EU: 'https://eu.connect.nielseniq.com/discover',
    PROD_APAC: 'https://apac.connect.nielseniq.com/discover',
    PROD_CALATAM: 'https://calatam.connect.nielseniq.com/discover'
  },

  getBaseURL(env: string = 'DEV') {
    return this.baseURLs[env as keyof typeof this.baseURLs];
  },

  // Dynamically returns the URL based on process.env.ENV (defaults to DEV)
  get BASE_URL() {
    return this.getBaseURL(process.env.ENV || config.ENV);
  },
  SHARE_MAIL_ID: 'automation2gen@nielseniq.com',

  // Grafana Playwright Reporter configuration
  postgresAPIUrl: process.env.POSTGRES_API_URL || 'https://postgres-api.qa.in.gfk.com/report-postgres/api/v1',

  // Jira configuration - release/cycle names are time-sensitive and should be explicitly set
  jiraUrl: resolveEnvValue('JiraUrl') || 'https://adlm.nielseniq.com/jira',
  jiraRelease: resolveEnvValue('JiraRelease') || '',
  jiraCycle: resolveEnvValue('JiraCycle') || '',
  jiraFolderName: resolveEnvValue('FolderName') || '',
  jiraProjectId: resolveEnvValue('JiraProjectId') || '41103',
  jiraUpdateEnabled: parseBoolean(resolveEnvValue('JiraUpdateEnabled'), false),
  jiraAuthorizationKey: resolveEnvValue('AuthorizationKey') || '',

  // Report paths
  DEFAULT_REPORT_PATH: 'playwright-report/test-results.json',
};