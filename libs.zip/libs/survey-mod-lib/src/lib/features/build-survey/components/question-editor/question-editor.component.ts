
import { Component, ElementRef, HostListener, input, output, effect, signal, computed, ChangeDetectionStrategy, viewChild, untracked, inject } from '@angular/core';
import { SurveyService } from '../../services/survey.service';
import { QuestionModel, QuestionTypes, MAX_SURVEY_QUESTIONS, SuggestionTag } from '../../models/build-survey';
import { ScaleEditorComponent } from './scale-editor/scale-editor.component';
import { ChoiceEditorComponent } from './choice-editor/choice-editor.component';
import { TextEditorComponent } from './text-editor/text-editor.component';
import { RatingEditorComponent } from './rating-editor/rating-editor.component';
import { NpsEditorComponent } from './nps-editor/nps-editor.component';
import { ButtonModule } from '@nielseniq/athena-core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'survey-question-editor',
  imports: [
    ScaleEditorComponent,
    ChoiceEditorComponent,
    TextEditorComponent,
    RatingEditorComponent,
    NpsEditorComponent,
    ButtonModule,
    TranslateModule
  ],
  providers: [TranslateService],
  standalone: true,
  templateUrl: './question-editor.component.html',
  styleUrls: ['./question-editor.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QuestionEditorComponent {
  protected readonly QuestionTypes = QuestionTypes;
  private readonly translate = inject(TranslateService);
  DEFAULT_LEFT_NPS_LABEL = this.translate.instant('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND');
  DEFAULT_RIGHT_NPS_LABEL = this.translate.instant('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND');

  selectedType = input('');
  mode = input<'edit' | 'readonly'>('edit');
  questionData = input<QuestionModel | null>(null);
  isPreview = input(false);
  questionNumber = input<number | undefined>(undefined);
  isPreviewContext = input(false);
  isInlineAdd = input(false);
  publishRequest = input(0);
  showSuggestionTags = input(false);
  suggestionCounts = input<SuggestionTag | null>(null);

  questionDataChange = output<Partial<QuestionModel>>();
  saveChangesRequested = output<void>();
  discardChangesRequested = output<void>();

  // State signals for 2-way binding with child components
  question = signal('');
  options = signal<string[]>(['', '']);
  isRequired = signal(false);
  npsLeftLabel = signal(this.DEFAULT_LEFT_NPS_LABEL);
  npsRightLabel = signal(this.DEFAULT_RIGHT_NPS_LABEL);
  showQuestionEditor = true;

  private isNavigatingToPreview = false;
  private pendingAutoSave = false;

  editorContainer = viewChild<ElementRef<HTMLElement>>('editorContainer');

  constructor(public surveyService: SurveyService) {
    // Setup effect to react to questionData changes
    effect(() => {
      if (this.isPreviewContext()) {
        this.mode();
        if (this.questionData()) {
          this.applyQuestionData();
        }
      } else {
        // For non-preview context, initialize from selectedType or fallback
        const type = this.selectedType();  // Get current value
        if (!type) {
          this.clearEditorState();
        }
      }
    });

    effect(() => {
      if (this.publishRequest() > 0) {
        untracked(() => this.publish());
      }
    });
  }

  rowOptions = signal<string[]>(['', '']);
  columnOptions = signal<string[]>(['', '']);

  get childMode(): 'edit' | 'readonly' {
    return this.isPreviewContext() ? this.mode() : 'edit';
  }

  displayQuestionNumber = computed(() => 
    this.questionNumber() ?? this.upcomingQuestionNumber
  );

  currentSelectedType = computed(() => 
    this.selectedType() || this.getInitialSelectedType()
  );

  get upcomingQuestionNumber(): number {
    return this.surveyService.getQuestions().length + 1;
  }

  private getInitialSelectedType(): string {
    return this.surveyService.getQuestionType() ||
      history.state?.selectedType ||
      '';
  }

  private applyQuestionData(): void {
    const source = this.questionData();
    if (!source) return;

    // selectedType comes from input, don't reassign
    this.question.set(source.question ?? '');
    this.options.set(Array.isArray(source.options) ? [...source.options] : []);
    this.isRequired.set(!!source.isRequired);
    this.npsLeftLabel.set(source.npsLeftLabel ?? this.DEFAULT_LEFT_NPS_LABEL);
    this.npsRightLabel.set(source.npsRightLabel ?? this.DEFAULT_RIGHT_NPS_LABEL);
    this.rowOptions.set(Array.isArray(source.rowOptions) ? [...source.rowOptions] : []);
    this.columnOptions.set(Array.isArray(source.columnOptions) ? [...source.columnOptions] : []);
  }

  private emitPreviewDataChange(payload: Partial<QuestionModel>): void {
    if (this.isPreviewContext()) {
      this.questionDataChange.emit(payload);
    }
  }

  /** Builds a payload containing only the fields relevant to the current question type. */
  private buildQuestionPayload(): Partial<QuestionModel> {
    const payload: Partial<QuestionModel> = {
      question: this.question(),
      isRequired: this.isRequired()
    };

    if (this.isChoiceType()) {
      payload.options = this.options();
    }

    if (this.isScaleType()) {
      payload.rowOptions = this.rowOptions();
      payload.columnOptions = this.columnOptions();
    }

    if (this.isNpsType()) {
      payload.npsLeftLabel = this.npsLeftLabel();
      payload.npsRightLabel = this.npsRightLabel();
    }

    return payload;
  }

  /** Called by every child editor whenever its form changes. */
  onFormChange(): void {
    this.emitPreviewDataChange(this.buildQuestionPayload());
    if (!this.isPreviewContext()) {
      this.updatePublishState();
    }
  }

  private isChoiceType = computed(() => 
    this.currentSelectedType() === QuestionTypes.SingleChoice || this.currentSelectedType() === QuestionTypes.MultipleChoice
  );

  private isScaleType = computed(() => 
    this.currentSelectedType() === QuestionTypes.SinglePointScale || this.currentSelectedType() === QuestionTypes.MultiplePointScale
  );

  private isNpsType = computed(() => 
    this.currentSelectedType() === QuestionTypes.NetPromoterScore
  );

  private hasValidChoiceOptions = computed(() => {
    const options = this.options();
    return options.length >= 2 && options.every(o => o.trim().length > 0);
  });

  private hasValidScaleOptions = computed(() => {
    const rowOptions = this.rowOptions();
    const columnOptions = this.columnOptions();
    return rowOptions.length >= 2 && columnOptions.length >= 2 &&
      rowOptions.every(row => (row ?? '').trim().length > 0) &&
      columnOptions.every(column => (column ?? '').trim().length > 0);
  });

  private hasValidOptionsForSelectedType = computed(() => {
    if (this.isChoiceType()) {
      return this.hasValidChoiceOptions();
    }

    if (this.isScaleType()) {
      return this.hasValidScaleOptions();
    }

    return true;
  });

  readonly isPublishDisable = computed(() => {
    const hasQuestion = this.question().trim().length > 0;
    const hasValidOptions = this.hasValidOptionsForSelectedType();
    return !(hasQuestion && hasValidOptions);
  });

  updatePublishState(): void {
    // Publish state is now computed and automatically updated
  }

  publish(): void {
    if (this.isPublishDisable()) return;
    this.saveChanges();
  }

  requestSaveChanges(event: MouseEvent): void {
    event.stopPropagation();
    this.saveChangesRequested.emit();
  }

  requestDiscardChanges(event: MouseEvent): void {
    event.stopPropagation();
    this.discardChangesRequested.emit();
  }

  private clearEditorState(): void {
    // Clear all input signals and state
    this.question.set('');
    this.isRequired.set(false);
    this.options.set(['', '']);
    this.rowOptions.set(['', '']);
    this.columnOptions.set(['', '']);
    this.npsLeftLabel.set(this.DEFAULT_LEFT_NPS_LABEL);
    this.npsRightLabel.set(this.DEFAULT_RIGHT_NPS_LABEL);
  }

  saveChanges(): void {
    // Prevent adding new questions if at max limit
    if (this.surveyService.getQuestions().length >= MAX_SURVEY_QUESTIONS) {
      this.showQuestionEditor = false;
      this.clearEditorState();
      return;
    }

    const newQuestion: QuestionModel = {
      questionNumber: this.upcomingQuestionNumber,
      question: this.question(),
      options: this.options(),
      rowOptions: this.isScaleType() ? [...this.rowOptions()] : [],
      columnOptions: this.isScaleType() ? [...this.columnOptions()] : [],
      npsLeftLabel: this.isNpsType() ? this.npsLeftLabel() : '',
      npsRightLabel: this.isNpsType() ? this.npsRightLabel() : '',
      isRequired: this.isRequired(),
      type: this.currentSelectedType()
    };
    this.surveyService.addQuestion(newQuestion);
    this.showQuestionEditor = false;
    this.clearEditorState();  // Clear state after saving so next question starts fresh
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (this.isPreviewContext() || !this.showQuestionEditor || this.isNavigatingToPreview || this.pendingAutoSave) {
      return;
    }

    const target = event.target as Node | null;
    const targetEl = target instanceof HTMLElement ? target : null;
    const isInsideEditor = !!target && !!this.editorContainer()?.nativeElement.contains(target);
    const isInsideHeader = !!targetEl?.closest?.('.survey-header');

    if (isInsideEditor || isInsideHeader) return;

    this.pendingAutoSave = true;
    setTimeout(() => {
      this.pendingAutoSave = false;
      if (!this.showQuestionEditor || this.isNavigatingToPreview) return;
      this.updatePublishState();
      if (this.isPublishDisable()) return;
      this.isNavigatingToPreview = true;
      this.publish();
    }, 0);
  }
}