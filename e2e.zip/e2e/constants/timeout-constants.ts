export const MAX_TEST_TIMEOUT = 2 * 60 * 1000; // 120,000 ms
export const NAVIGATION_TIMEOUT = 60 * 1000; // 60,000 ms
export const SMALL_TIMEOUT = 5 * 1000; // 5,000 ms
export const ELEMENT_WAIT_TIMEOUT = 15 * 1000; // 15,000 ms
export const DATASET_SELECTOR_TIMEOUT = 8 * 1000; // 3,000 ms
export const UI_STATE_UPDATE_DELAY = 300;  // 300 ms - very short settle (clear/enter, search debounce)
export const PANEL_TRANSITION_DELAY = 1000; // 1000 ms - panel/dropdown open or item selection settle
