import test from "@playwright/test";
import { findDataSetByName, getDimensionSelectionsByPivot, getTestDataByLocale, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";



// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";

const pivot: string = "Loyalty to Retailer";


  test.describe("Distribution analysis Loyalty to Retailer pivot", async () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;

    test.beforeAll(() => {
        const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
        if (!isValidTestData) {
          console.warn('Skipping tests as the required pivot test data is not present');
        }
        test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
      });

    test(
      "QuickLook: Should display correct preview information when template is selected",
      {
        tag: "@QuickLook",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        let landingPage = new LandingPage(basePage);
        await landingPage.navigateToUrl(config.BASE_URL+"/reports-templates?tab=ALL_TEMPLATES");
        let chooseAtemplatePage = new ChooseAtemplatePage(
          landingPage.getBasePage()
        );
        await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
        await chooseAtemplatePage.hoverThumbnailBySrc(
          devTestData.common.thumbnailSrc
        );
        await chooseAtemplatePage.clickQuickLookInfoButton();
        let quickLookPage = new QuickLookPage(
          chooseAtemplatePage.getBasePage()
        );
        const previewDescriptionValue = await quickLookPage.getPreviewDescription();
        assert(previewDescriptionValue).toBe(localeData.description);       
        const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
        assertionData.common.dataSets.forEach((expectedDataset: string) => {
          assert(previewDatasetsValue).toContain(expectedDataset);
        });
      }
    );


 test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
    test(
          "Validate run report",
          {
            tag: "@RunReport",
          },
          async () => {
             test.setTimeout(RUN_TEST_TIMEOUT);
            // Initialize base page with authentication from storage/auth.json (created in global setup)
            let basePage = await BasePageFactory.createBasePage();
            dataSelector = new DataSelector(basePage);
            
            // Navigate to the specific report URL
           commonTestCase = new CommonTestCase(basePage);
           await commonTestCase.navigateToReportUrl(reportUrl);
            
            // Click additional prompt ellipsis first to reveal pivot dropdown
            await dataSelector.clickAdditionalPromptEllipsisIcon();
            
            // Switch to "Loyalty to retailer" pivot
            await dataSelector.switchPivotDropdown(pivot);
    
            // GetLoyalty to retailer pivot data
            const pivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
            await dataSelector.waitForMadlibStability();

            // Configure Range dimension
            await dataSelector.clickMadlibDimension("Range");
            const rangeConfig = pivotData["Range"];
            await dataSelector.clickMadlibDimension("defineNewRangeButton");
            
            await dataSelector.configureRange(
              rangeConfig.volumetricType,     // Volumetric type from dropdown (e.g., "Avg. Price (EQ2)")
              rangeConfig.minValue,           // Min value
              rangeConfig.maxValue,           // Max value
              rangeConfig.incrementValue      // Increment value
            );   
            
            // Wait for madlib to stabilize after Range configuration
            await dataSelector.waitForMadlibStability();

            // await dataSelector.clickMadlibDimension("People");
            // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
            // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
            // await dataSelector.setDimensionSelection(pivotData["People"]
            //   .selections)

              await dataSelector.clickMadlibDimension("Products");
              await dataSelector.setMadlibSelection(
               pivotData["Products"]
              );
            
            await dataSelector.clickMadlibDimension("Period");
            await dataSelector.setPeriodMadlibSelection(
              pivotData["Period"]
            );
            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.selectClosedDropdown(
              pivotData["Facts"]["selections"]
            );
            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(
              pivotData["Geography"]
            );
    
            await dataSelector.clickMadlibDimension("Demography");
            await dataSelector.setMadlibSelection(
              pivotData["Demography"]
            );
             await dataSelector.clickMadlibDimension("Retailer Universe");
            await dataSelector.setMadlibSelection(
             pivotData["Retailer Universe"]
            );       
                    
             await dataSelector.clickMadlibDimension("Retailers");
              await dataSelector.setMadlibSelection(
                pivotData["Retailers"]
              );
             await dataSelector.waitForMadlibStability();
            
        let dsBasePage = await dataSelector.getBasePage();
        commonTestCase = new CommonTestCase(dsBasePage);
        await commonTestCase.clickRunButton();
        await commonTestCase.waitForReportRunCompletion();
        console.log("run complete in spec");
        const { newReportTitle, newUrl } = await commonTestCase.saveReport();
        savedReportTitle = newReportTitle;
        savedReportUrl = newUrl;
        console.log("savedReportTitle:", savedReportTitle);
        console.log("savedReportUrl:", savedReportUrl);
      }
    );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });

        test(
                "Validate FullScreen",
                {
                  tag: "@ValidateFullScreen",
                },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  await commonTestCase.fullScreenView();
                }
              );
        
              test(
                "Validate presentationMode",
                {
                  tag: "@PresentationMode",
                },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  await commonTestCase.presentationMode();
                }
              );
        
              test(
                "Validate snapshot",
                { tag: "@Snapshot" },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  const commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
                  await snapshot.waitForReportRunCompletion();
                  await snapshot.clickSaveIcon();
                  await snapshot.clickSnapshotIcon();
                  console.log("Snapshot clicked");
                  assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
                  let snapshotUrl: string = await snapshot.shiftingToSnapshot();
                }
              );
              
        
              test(
                "Validate Excel export",
                {
                  tag: "@ValidateExcelExport",
                },
                async () => {
                  let exportComponent: ExportComponent;
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  let commonBasePage = await commonTestCase.getBasePage();
                  exportComponent = new ExportComponent(commonBasePage);
                  await exportComponent.validateExportFunctionality(
                    "Excel",
                    "Editable objects",
                    "Separately"
                  );
                }
              );
                    

  });
  
  });