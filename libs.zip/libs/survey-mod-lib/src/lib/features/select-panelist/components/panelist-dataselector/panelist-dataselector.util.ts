import { DimensionSelection, Prompt } from '@nielsen/crf-common';
import { cloneDeep } from 'lodash-es';

/**
 * Temporary function to be removed once null properties are removed from the backend.
 */
export function removeNullProperties(value: Record<string, unknown> | undefined): Record<string, unknown> | undefined {
  if (!value) {
    return value;
  }

  const sanitize = (input: unknown): unknown => {
    if (Array.isArray(input)) {
      return input.map((item) => sanitize(item));
    }

    if (input && typeof input === 'object') {
      const source = input as Record<string, unknown>;
      return Object.entries(source).reduce((acc, [key, itemValue]) => {
        if (itemValue !== null) {
          acc[key] = sanitize(itemValue);
        }
        return acc;
      }, {} as Record<string, unknown>);
    }

    return input;
  };

  return sanitize(value) as Record<string, unknown>;
}

export function resolveDatasetName(datasetDetails: any): string {
  return datasetDetails?.title || datasetDetails?.label || datasetDetails?.description || datasetDetails?.id || 'Selected Dataset';
}

/**
 * Temporary function, will be removed once backend removes the dropDrillByContext property.
 */
export function dropDrillByContextFromSelectionChildren(selections: DimensionSelection[]): DimensionSelection[] {
  return (selections ?? []).map((selection: any) => {
    if (!Array.isArray(selection?.children)) {
      return selection;
    }

    return {
      ...selection,
      children: selection.children.map((child: any) => {
        if (!child || typeof child !== 'object') {
          return child;
        }

        const { drillByContext, ...rest } = child;
        return rest;
      }),
    };
  });
}

/**
 * Temporary function, also to be removed once promptForSelection null property is removed from backend.
 */
export function removePromptForSelection(prompts: any[]): any[] {
  return (prompts ?? []).map((prompt: any) => {
    if (!prompt || typeof prompt !== 'object') {
      return prompt;
    }
    const { promptForSelection, ...rest } = prompt;
    return rest;
  });
}

/** Prompt restore prioritizes explicit prompt cache, then panel copy, then requestInstance fallback. */
export function getRestoredPrompts(cachedState: any): Prompt[] {
  if (cachedState.dataPrompts?.length) {
    return cloneDeep(cachedState.dataPrompts) || [];
  }

  if (cachedState.panelDataPrompts?.length) {
    return cloneDeep(cachedState.panelDataPrompts) || [];
  }

  return cloneDeep(cachedState.requestInstance?.prompts ?? []) || [];
}

/** Selection restore prioritizes normalized cached selections over request payload fallback. */
export function getRestoredSelections(cachedState: any): DimensionSelection[] {
  if (cachedState.selections?.length) {
    return cloneDeep(cachedState.selections) || [];
  }

  return cloneDeep(cachedState.requestInstance?.dimensionSelections ?? []) || [];
}
