import { BasePage } from '@gfk/gta';
import { CommonPage } from './common-page';
import profilePageResources from '../../locators/survey/profile.locator.json';
import { NAVIGATION_TIMEOUT } from '../../constants/timeout-constants';

const PROFILE_PAGE_COMPONENT_NAME = 'profilePage';
const LANGUAGE_OPTION_SELECTOR_PREFIX = 'profile-language-drp-down-value-';
const UNKNOWN_LABEL_PLACEHOLDER = 'TODO';

export class ProfilePage extends CommonPage {
  protected readonly componentName = PROFILE_PAGE_COMPONENT_NAME;

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(PROFILE_PAGE_COMPONENT_NAME, profilePageResources);
  }

  /** Language option label (as shown in the dropdown) for a locale code, read from its locator; throws if the locale has no locator or its label is still TODO. */
  private getLocaleLabel(locale: string): string {
    let selectorValue: string;
    try {
      selectorValue = this.getResource(locale).selectorValue;
    } catch {
      throw new Error(`no language option locator for locale '${locale}' in profile.locator.json`);
    }
    const label = selectorValue.slice(selectorValue.indexOf(LANGUAGE_OPTION_SELECTOR_PREFIX) + LANGUAGE_OPTION_SELECTOR_PREFIX.length, -2);
    if (!label || label === UNKNOWN_LABEL_PLACEHOLDER) {
      throw new Error(`language option label for locale '${locale}' is not known yet (TODO in profile.locator.json)`);
    }
    return label;
  }

  async navigateToProfileSettings(): Promise<void> {
    try {
      await this.clickWhenVisible('profileIcon', 'Profile icon');
      await this.clickWhenVisible('profileSettings', 'Profile settings menu item');
      const title = this.webActionHandler.getWebElement(this.getResource('profileSettingsTitle'));
      await this.waitUntilVisible(title, 'Profile settings page title');
    } catch (error) {
      throw new Error(`Failed to open the profile settings: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Returns the language text currently shown in the Account settings (e.g. "English (United States)"). */
  async getUserLocale(): Promise<string> {
    try {
      await this.navigateToProfileSettings();
      await this.clickWhenVisible('accountSettings', 'Account settings category');
      const accountTitle = this.webActionHandler.getWebElement(this.getResource('profileAccountTitle'));
      await this.waitUntilVisible(accountTitle, 'Profile account title');

      const languageInput = this.webActionHandler.getWebElement(this.getResource('profileLanguageInput'));
      await this.waitUntilVisible(languageInput, 'Profile language input');
      return ((await languageInput.getText()) ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read the user locale: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Picks the language in the profile settings and saves; Save reloads the page, so this waits for the reload before returning. */
  async setUserLocale(locale: string): Promise<void> {
    try {
      this.getLocaleLabel(locale);
      await this.navigateToProfileSettings();
      await this.clickWhenVisible('profileLanguageSettingsInput', 'Profile language dropdown');
      await this.clickWhenVisible(locale, `Language option for locale '${locale}'`);

      const nativePage = (BasePage as any).page as import('playwright').Page; // the reload wait is not exposed by the GTA wrapper
      const reloaded = nativePage.waitForEvent('load', { timeout: NAVIGATION_TIMEOUT });
      reloaded.catch(() => undefined); // avoids an unhandled rejection if the click below fails first
      await this.clickWhenVisible('saveChanges', 'Save changes button');
      await reloaded;
    } catch (error) {
      throw new Error(`Failed to set the user locale to '${locale}': ${error instanceof Error ? error.message : error}`);
    }
  }

  /** True when the language shown in the profile settings is the one for the given locale code. */
  async validateUserLocale(locale: string): Promise<boolean> {
    try {
      const expectedLabel = this.getLocaleLabel(locale);
      const actualLabel = await this.getUserLocale();
      return actualLabel === expectedLabel;
    } catch (error) {
      throw new Error(`Failed to validate the user locale '${locale}': ${error instanceof Error ? error.message : error}`);
    }
  }
}
