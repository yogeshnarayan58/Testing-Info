export const GRID_TEXT = {
  valueNotAvailable: 'Value not available',
  missingValue: '- Missing -',
  legend: 'Legend',
  minCount: 'Min Count',
  maxCount: 'Max Count',
  legendAriaLabel: 'Heat grid legend',
  loadingChart: 'Loading chart',
  noChartResults: 'No results available for this chart.',
  chartLoadError: 'Unable to load chart.',
  gridLoadError: 'Unable to load table results.',
  chartPlaceholder: 'Question chart',
  heatGridPlaceholder: 'Question heat grid',
  statementBreakdown: 'Show statement breakdown',
} as const;

export const HEAT_GRID_LEGEND_STOP_POSITIONS = [15, 55, 100] as const;