import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { DatasetFooterComponent } from './dataset-footer.component';

describe('DatasetFooterComponent', () => {
  it('emits click only when editable', () => {
    const component = TestBed.runInInjectionContext(() => new DatasetFooterComponent());
    const emitSpy = vi.spyOn(component.footerClick, 'emit');

    component.onDatasetFooterClick();
    expect(emitSpy).toHaveBeenCalledTimes(1);

    (component as any).isEditable = () => false;
    component.onDatasetFooterClick();
    expect(emitSpy).toHaveBeenCalledTimes(1);
  });
});
