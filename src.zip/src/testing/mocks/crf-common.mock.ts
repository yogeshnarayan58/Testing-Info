export class CpfService {}

export class DimensionSelection {
  [key: string]: unknown;
}

export class Prompt {
  [key: string]: unknown;
}
