import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";

import { ProfilePage } from "../../../common/pages/profile-page/profile-page";
import { CommonTestCases, getDataElement } from "../../test-cases/common-test-cases-helper-service";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import {
  findDataSetByName,
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { config } from "../../../playwright/config";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { NlsnPinMenuComponent } from "../../../common/components/nlsn-pin-menu/nlsn-pin-menu";
import assertionData from "./assertion-data/assertion-data.json";
import { ReportPage } from "../../../common/pages/report-page/report-page";
import * as cpaReportPageResources from "./resources/report-page-resources.json";
// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = '';
let savedReportUrl: string = '';

if (reportTestData) {
  test.describe("Combination purchase analysis", () => {
    let profilePage: ProfilePage;
    let chooseAtemplatePage: ChooseAtemplatePage;
    let landingPage: LandingPage;
    let quickLookPage: QuickLookPage;
    // let commonTestCases: CommonTestCases;
    let insightsPanel: InsightsPanel;
    let dataSelector: DataSelector;
    let reportPage:ReportPage;
    let snapshot: Snapshot;
    let commonTestCase: CommonTestCase;
    let formatPanel: FormatPanel;

  
    
      test("QuickLook: Should display correct preview information when template is selected",
      {
        tag: "@QuickLook",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        let landingPage = new LandingPage(basePage);
        await landingPage.navigateToUrl(config.BASE_URL + "/reports-templates?tab=ALL_TEMPLATES");
        let chooseAtemplatePage = new ChooseAtemplatePage(
          landingPage.getBasePage()
        );
        await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
        await chooseAtemplatePage.hoverThumbnailBySrc(
          testData.common.thumbnailSrc
        );
        await chooseAtemplatePage.clickQuickLookInfoButton();
        let quickLookPage = new QuickLookPage(
          chooseAtemplatePage.getBasePage()
        );
        const previewDescriptionValue = await quickLookPage.getPreviewDescription();
        assert(previewDescriptionValue).toBe(localeData.description);       
        const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
        assertionData.common.dataSets.forEach((expectedDataset: string) => {
          assert(previewDatasetsValue).toContain(expectedDataset);
        });
        const themesValue = await quickLookPage.getPreviewThemes();
        assertionData.common.themes.forEach((expectedTheme: string) => {
          assert(themesValue).toContain(expectedTheme);
        });

      }
    );

    
    test(
        "Insights Panel: Should validate business questions and report metadata",
        {
          tag: "@Insights",
        },
        async () => {
          let basePage = await BasePageFactory.createBasePage();
          const insightsPanel = new InsightsPanel(basePage);
          await insightsPanel.navigateToUrl(reportUrl);
          await insightsPanel.clickInsightsIcon();
          const isTitleVisible =
            await insightsPanel.isReportInsightsTitleVisible();
          assert(isTitleVisible).toBeTruthy();
          const isCloseIconVisible =
            await insightsPanel.isReportInsightsPanelCloseIconVisible();
          assert(isCloseIconVisible).toBeTruthy();
          const insightsReportTitle =
            await insightsPanel.getInsightsReportTitle();
          assert(insightsReportTitle?.trim()).toBe(localeData.title);
          const description = await insightsPanel.getInsightsPanelDescription();
          assert(description?.trim()).toBe(localeData.description);
          const isBusinessTitleVisible =
            await insightsPanel.isBusinessQuestionsTitleVisible();
          assert(isBusinessTitleVisible).toBeTruthy();
          await insightsPanel.validateBusinessQuestions(
            localeData.businessQuestions
          );
          await insightsPanel.closeInsightsPanel();
        }
      );
    test(
      "Madlib Validation: Should validate madlib text content matches expected pattern",
      {
        tag: "@MadlibValidation",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(reportUrl);
        let commonBasePage = commonTestCase.getBasePage();
        dataSelector = new DataSelector(commonBasePage);

        if (localeData.madlibText) {
          const actualMadlibText = await dataSelector.getMadlibText();
          console.log("Actual Madlib Text:", actualMadlibText);
          console.log("Expected Pattern:", localeData.madlibText);
          assert(actualMadlibText).toMatch(
            new RegExp(localeData.madlibText, "i")
          );

          console.log(
            " Madlib validation passed for locale:",
            localeData.locale
          );
        } else {
          console.warn(
            `No madlib text pattern defined for locale: ${localeData.locale}`
          );
        }
      }
    );

    test(
      "Validate default format panel",
      {
        tag: "@FormatPanelDefaultVerification",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        formatPanel = new FormatPanel(basePage);
        await formatPanel.navigateToUrlAndCheckMadlibVisbility(reportUrl);
        await formatPanel.openFormatPanel();
        await formatPanel.testDefaultFormatPanel(
          reportAssertData["formatPanel"]["default"]
        );
        await formatPanel.closeFormatPanel();
      }
    );
    test.describe.serial(
      "Run, PPT Export, Excel Export",
      { tag: ["@Report_E2E_Flow"] },
      () => {
        test(
          "Report Generation: Validates dimension selection and successful execution",
          {
            tag: "@RunReport",
          },
          async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);
            await dataSelector.clickAdditionalPromptEllipsisIcon();
           
            await dataSelector.clickMadlibDimension("Retailer");
            await dataSelector.setMadlibSelection(reportTestData.dimensionSelections[0]["Retailer"]);

            
            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(reportTestData.dimensionSelections[0]["Geography"]);
            
            await dataSelector.clickMadlibDimension("Benchmark Product");
            await dataSelector.setMadlibSelection(reportTestData.dimensionSelections[0]["Benchmark Product"]);

            await dataSelector.clickMadlibDimension("Products");
            await dataSelector.setMadlibSelection(reportTestData.dimensionSelections[0]["Products"]);
            await dataSelector.webActionHandler.delay(SMALL_TIMEOUT);
            await dataSelector.clickMadlibDimension("Period");
            await dataSelector.setPeriodMadlibSelection(reportTestData.dimensionSelections[0]["Period"]);

            await dataSelector.clickMadlibDimension("Comparison Period");
            await dataSelector.setPeriodMadlibSelection(reportTestData.dimensionSelections[0]["Comparison Period"]);
             
            await dataSelector.clickMadlibDimension("Demographic");
            await dataSelector.setMadlibSelection(reportTestData.dimensionSelections[0]["Demographic"]);
            
            let dsBasePage = await dataSelector.getBasePage();
            commonTestCase = new CommonTestCase(dsBasePage);
            await commonTestCase.clickRunButton();
            await commonTestCase.waitForReportRunCompletion();
            console.log("run complete in spec");
            const { newReportTitle, newUrl } =
              await commonTestCase.saveReport();
            savedReportTitle = newReportTitle;
            savedReportUrl = newUrl;
            
            console.log("savedReportTitle:", savedReportTitle);
            console.log("savedReportUrl:", savedReportUrl);
          }
        );

        test(
          "Validate FullScreen",
          {
            tag: "@ValidateFullScreen",
          },
          async () => {
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.fullScreenView();
          }
        );

        test(
          "Validate presentationMode",
          {
            tag: "@PresentationMode",
          },
          async () => {
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.presentationMode();
          }
        );

        test(
                "Validate snapshot",
                { tag: "@Snapshot" },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  const commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
                  await snapshot.waitForReportRunCompletion();
                  await snapshot.clickSaveIcon();
                  await snapshot.clickSnapshotIcon();
                  console.log("Snapshot clicked");
                  assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
                  let snapshotUrl: string = await snapshot.shiftingToSnapshot();
                  console.log("Snapshot shifted to right:", snapshotUrl);
                }
              );

        test(
          "Pin Menu: Should validate default question and all dropdown options",
          {
            tag: "@PinMenuValidation",
          },
          async () => {
            // If RunReport fails, savedReportUrl will be empty and this test will skip
            test.skip(!savedReportUrl, 'Skipping Pin Menu - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            const pinMenu = new NlsnPinMenuComponent(basePage);
            await pinMenu.navigateToUrl(savedReportUrl);

            // CPA has no template placeholders (no Facts dimension), use pinMenuQuestions directly
            const pinMenuQuestions = localeData.pinMenuQuestions || [];

            // Validate default selection (should be index 0 = first question)
            console.log("Validating default pin menu selection...");
            await pinMenu.validateDefaultSelection(0, pinMenuQuestions[0] || "");

            // Validate all questions in dropdown
            console.log("Validating all pin menu questions...");
            await pinMenu.validateAllQuestions(pinMenuQuestions);

            // Validate view count text (index 0 displays as "View 1")
            const totalQuestions = await pinMenu.getTotalQuestions();
            console.log(`Validating view count: View 1 of ${totalQuestions}`);
            await pinMenu.validateViewCount(0, totalQuestions);

            // CPA Question 1 is "Table View (combination purchase)" which is the default view.
            // Switch to Question 2 to validate navigation works
            await pinMenu.switchToQuestionNumber(2);

            // Additional use case
            // Note: This method is fully implemented in NlsnPinMenuComponent and can be
            // reused in any report that has the nlsn-pin-menu dropdown component.
            // Use case: Pin a specific question by question number (1-based)
            // await pinMenu.pinQuestionNumber(3); // Pins question 3 (3rd question)
            // await pinMenu.pinQuestionNumber(1); // Pins question 1 (1st question)

            console.log("Pin menu validation completed successfully");
          }
        );

        test.skip(
          "Report Specific Validations: Screenshot comparisons and multi-question navigation",
          {
            tag: "@ReportSpecificValidations",
          },
          async ({ }, testInfo) => {
            test.skip(!savedReportUrl, 'Skipping Report Specific Validations - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            // Set timeout for this test using constant: 5 minutes for all questions
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            const pinMenu = new NlsnPinMenuComponent(basePage);
            const testCommonTestCase = new CommonTestCase(basePage);
            await testCommonTestCase.navigateToReportUrl(savedReportUrl);

            // ============================================================================
            // Question 1 - Table View (combination purchase) - Default view
            // ============================================================================
            console.log("Testing Question 1 (Table View)...");
            // Note: Report loads on Question 1 by default, so no need to navigate
            console.log("Navigated to Question 1");
            await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q1-table-view", "combination-purchase-analysis");

        //     // ============================================================================
        //     // Question 2 - Fair share volume analysis
        //     // ============================================================================
             console.log("Testing Question 2...");
             await pinMenu.switchToQuestionNumber(2);
             await pinMenu.webActionHandler.delay(SMALL_TIMEOUT);
             console.log("Navigated to Question 2");
             await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q2-fair-share", "combination-purchase-analysis");

             // ============================================================================
             // Question 3 - Focus buyer group analysis
             // ============================================================================
               console.log("Testing Question 3...");
               await pinMenu.switchToQuestionNumber(3);
               await pinMenu.webActionHandler.delay(SMALL_TIMEOUT);
             console.log("Navigated to Question 3");
             await testCommonTestCase.compareScreenshotAfterRun(testInfo, "q3-buyer-group", "combination-purchase-analysis");

             console.log("Report specific validations completed successfully");
          }
        );

        test(
          "Validate internal dropdown panel",
          {
            tag: "@FactsDropdownValidation",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skippingvalidate internal dropdown - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
            
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            reportPage = new ReportPage(commonBasePage);
            // Register CPA resources directly
            reportPage.resourceManager.registerResources("CPAReportPage", cpaReportPageResources);

           await reportPage.validateAllFacts(
             reportAssertData["dataSummary"]["facts"],
             "CPAReportPage"
           );
           
          }
        );

        test(
          "Validate run after facts change",
          {
            tag: "@FactsRun",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping Run after facts change- Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

           
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            reportPage = new ReportPage(commonBasePage);
            // Register CPA resources directly
            reportPage.resourceManager.registerResources("CPAReportPage", cpaReportPageResources);
            

            await reportPage.clickDimension("factsInternalDropdown", "CPAReportPage");
            await reportPage.switchToOption(3, "factsInternalDropdownOptions", "CPAReportPage");
            await commonTestCase.clickRunButton();           
           await commonTestCase.waitForReportRunCompletion(); 
          });



        test(
          "Validate PPT export",
          {
            tag: "@ValidatePPTExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
          }
        );

        test(
          "Validate Excel export",
          {
            tag: "@ValidateExcelExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality(
              "Excel",
              "Editable objects",
              "Separately"
            );
          }
        );

        test.skip("Validate Share Option for New Template", { tag: '@ShareNewTemplate' }, async () => {
          const newBasePage = await BasePageFactory.createBasePage();
          const webActions = newBasePage.getWebActions();

          dataSelector = new DataSelector(newBasePage);

          await dataSelector.navigateToUrl(savedReportUrl);

          const newFindMyStuff = new FindMyStuff(newBasePage);
          await newFindMyStuff.validateShareOptionForNewTemplate(savedReportUrl);

          console.log("Share option validated for NEW copied report");
        });

        test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

          let basePage = await BasePageFactory.createBasePage();
          let findMyStuff = new FindMyStuff(basePage);
          await findMyStuff.navigateToUrl(config.BASE_URL);

          await findMyStuff.clickFindMyStuff();
          await findMyStuff.openCurrentReportFMS(savedReportTitle);

          console.log("Open current report from FMS - Report visible in UI");
        });


          test(
                "Validate Add Blank Report",
                {
                  tag: "@ValidateAddBlankReport",
                },
                async () => {
                  test.setTimeout(RUN_TEST_TIMEOUT);
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
        
                  // Make a copy of the current report
                  const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();
        
                  // Create a new CommonTestCase for the new report flow  
                  let newBasePage = await BasePageFactory.createBasePage();
                  let newCommonTestCase = new CommonTestCase(newBasePage);
        
                  // Navigate to the new URL using CommonTestCase
                  await newCommonTestCase.navigateToReportUrl(newUrl);
        
                  // Create ReportFlowPage with the same base page
                  let reportFlowPage = new ReportFlowPage(newBasePage);
        
                  // Test the correct workflow: Add Menu -> Add Blank Report
                  await reportFlowPage.clickAddMenuIcon();
        
                  // Wait briefly for dropdown to appear
                  await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);
        
                  // Validate all three dropdown options are present
                  await reportFlowPage.validateAddMenuDropdownOptions();
        
                  // Click "Add blank report" option directly from dropdown
                  await reportFlowPage.clickAddBlankReportOption();
        
                  // Wait for blank report to be created
                  await reportFlowPage.waitForBlankReportIndicator();
        
                  // Validate that blank report was created successfully
                  await reportFlowPage.validateBlankReportCreation();
        
                  // Validate that the report title shows 'Untitled'
                  await reportFlowPage.validateUntitledReportTitle();
        
                  // Run the complete blank report workflow (dataset selector, apply dataset, madlib selections, and report execution)
                  await reportFlowPage.runBlankReport(config.DATASET);
        
                  // Switch back to the original report tab
                  await reportFlowPage.clickReportByName(newReportTitle);
        
                  // Wait for the madlib to stabilize and validate it's loaded properly
                  const dataSelector = new DataSelector(newBasePage);
                  await dataSelector.waitForMadlibStability();
                  const madlibText = await dataSelector.getMadlibText();
        
                  // Assert that madlib text is not empty and contains expected content
                  assert(madlibText.length).toBeGreaterThan(0);
                }
              );
      });
      // test("Validate snapshot", { tag: "@snapshot" }, async () => {
    //   let basePage = await BasePageFactory.createBasePage();
    //   snapshot = new Snapshot(basePage);
    //   dataSelector = new DataSelector(basePage);
    //   await dataSelector.navigateToUrlAndCheckMadlibVisbility(savedReportUrl);
    //   await snapshot.waitForReportRunCompletion();
    //   await snapshot.clickSaveIcon();
    //   await snapshot.clickSnapshotIcon();
    //   // assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
    //   await snapshot.shiftingToSnapshot();
    //   assert(await snapshot.isRobustnessFooterVisible()).toBeTruthy();
    // });
  });
} else {
  console.warn(
    "Combination purchase analysis::warning title=Missing Test Data::Test suite 'Data-driven tests' skipped because required test data was not found."
  );
}
function reportSpecificCases() {
  //    test("Report specific cases",  async () => {
  //     console.log("Inside report specific case - CPA");
  //     console.log("1. Start Checking the format panel working - by making changes");
  //     await getPage().locator('[data-test-id="omni-tsbp-menu-icon-button-icon"]').click();
  //     await getPage().getByText(`Fair Share Change`).click();
  //     await checkDefaultFormatPanelAfterRun(devTestData, "POD_OMNI");
  //     await openFormatPanel();
  //     await getPage().locator('[data-test-id="checkbox-property-0-icon"]').click();
  //     await testFormatPanelSelectionMatchWithChart(devTestData.POD_OMNI.formatPanelSelections.afterChangeCheck);
  //     await closeFormatPanel();
  //     console.log("1.End Checking the format panel working - by making changes");
  // });
}