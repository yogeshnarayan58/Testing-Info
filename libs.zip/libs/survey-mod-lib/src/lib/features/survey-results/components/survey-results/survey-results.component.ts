import { Component, effect, inject, OnDestroy, OnInit, signal, viewChild } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { ActivatedRoute } from '@angular/router';
import { TabModule } from '@nielseniq/athena-core';
import { map } from 'rxjs';
import { SURVEY_FLOW_STEPS } from '../../../../core/config/config';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SURVEY_RESULTS_TABS, SURVEY_RESULTS_TAB_VALUES } from '../../models/survey-results';
import { ResultsDashboardComponent } from '../results-dashboard/results-dashboard.component';
import { SurveyOverview } from '../survey-overview/survey-overview.component';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { DataSummaryService } from '../../utils-datasummary/data-summary.service';
import {
  buildSurveyResultsPayloadWithDataSummary,
  clearSurveyResultsDataSummary,
} from '../../utils/survey-results-payload.util';

@Component({
  selector: 'app-survey-results',
  imports: [TabModule, SurveyOverview, ResultsDashboardComponent, CdkScrollable],
  templateUrl: './survey-results.component.html',
  styleUrls: ['./survey-results.component.scss'],
})
export class SurveyResultsComponent implements OnInit, OnDestroy {
  readonly surveyCommonService = inject(SurveyCommonService);
  private readonly surveyService = inject(SurveyService);
  private readonly dataSummaryService = inject(DataSummaryService);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly surveyId = toSignal(
    this.activatedRoute.paramMap.pipe(map(params => params.get('surveyId'))),
    { initialValue: this.activatedRoute.snapshot.paramMap.get('surveyId') },
  );
  private readonly resultsDashboard = viewChild(ResultsDashboardComponent);
  readonly tabs: ReadonlyArray<{name: string, value: string}> = SURVEY_RESULTS_TABS;
  readonly selectedTab = signal<string>(this.tabs[0].value);

  private readonly resultsPayloadEffect = effect(() => {
    const survey = this.surveyService.loadedSurveyDetails();
    const payload = buildSurveyResultsPayloadWithDataSummary(survey, this.dataSummaryService, this.surveyId());
    if (payload !== null) {
      console.log('Survey results payload:', payload);
    }
  });

  /** Initialize footer visibility from the default tab on first render. */
  ngOnInit(): void {
    this.surveyCommonService.setActiveSurveyStep(SURVEY_FLOW_STEPS.RESULTS);
    this.updateFooterVisibility(this.selectedTab());
  }

  /** Keep selected tab state and wrapper footer visibility in sync on tab switch. */
  onTabChange(selectedTab: string): void {
    this.selectedTab.set(selectedTab);
    this.updateFooterVisibility(selectedTab);
  }

  /** Synchronize the dashboard dropdown when the results panel scrolls. */
  onResultsScroll(): void {
    this.resultsDashboard()?.closeChartMenuOnScroll();
  }

  /** Hide the footer when leaving this page; the next page sets its own visibility. */
  ngOnDestroy(): void {
    this.resultsPayloadEffect.destroy();
    clearSurveyResultsDataSummary(this.dataSummaryService);
    this.surveyCommonService.setDatasetFooterVisible(false);
  }

  /** Show the dataset footer only for the Survey specs tab. */
  private updateFooterVisibility(selectedTab: string): void {
    this.surveyCommonService.setDatasetFooterVisible(selectedTab === SURVEY_RESULTS_TAB_VALUES.surveySpecs);
  }
}
