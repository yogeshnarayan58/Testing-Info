import { SURVEY_ACCESS_AVAILABILITY } from '../constants/survey-status.constant';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ChangeDetectorRef, Component, EventEmitter, NO_ERRORS_SCHEMA, Output, signal } from '@angular/core';
import { By } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { MomentModule } from 'ngx-moment';
import { GridDataSourceService } from '@nielsen/crf-lp-common';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest';
import { TranslateModule, TranslateService, TranslateStore } from '@ngx-translate/core';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { BehaviorSubject, Observable, of, Subject, throwError } from 'rxjs';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { ApiService } from '../../../shared/services/api.service';
import { SurveyAssetApiService } from '../services/survey-asset-api.service';
import { ToastService } from '@nielseniq/athena-core';
import { SurveyGridHandlerService } from '../services/survey-grid-handler.service';
import { MY_ASSETS_TABS } from '../constants/my-assets-tabs.constant';
import { getAssetCatalogCacheTag } from '../constants/my-assets-tabs.constant';
import { RightsUtilityService, UserService } from '@nielsen/crf-lp-common';
import { SurveyGridLoadType, SurveyGridRow, SurveyGridRowsLoadedEvent } from '../models/survey-asset.model';
import * as moment from 'moment';

import { MyAssetsPageComponent } from './my-assets-page.component';
import template from './my-assets-page.component.html?raw';
import { CommonSidePanelComponent } from '../../../shared/components/common-side-panel/common-side-panel.component';

const viewLoaded = (success: boolean, loadType: SurveyGridLoadType = 'current-view'): SurveyGridRowsLoadedEvent =>
  ({ success, loadType });

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

const createMockTranslateStore = () => ({
  currentLanguage: 'en',
  defaultLanguage: 'en',
  languages: ['en'],
});

@Component({
  selector: 'crf-uic-create-folder',
  standalone: true,
  template: '',
})
class CreateFolderDialogStub {
  @Output() readonly save = new EventEmitter<{ title: string }>();
  @Output() readonly cancel = new EventEmitter<void>();
  readonly updateLoader = vi.fn();
  readonly close = vi.fn(() => {
    // Emit cancel once so the test catches repeated close calls without causing a stack overflow.
    if (this.close.mock.calls.length === 1) {
      this.cancel.emit();
    }
  });
}

vi.mock('@nielseniq/athena-core', () => ({
  CardModule: class {},
  BreadcrumbModule: class {},
  IconModule: class {},
  TooltipModule: class {},
  TagModule: class {},
  CheckboxModule: class {},
  ButtonModule: class {},
  IconButtonModule: class {},
  DialogModule: class {},
  LinkModule: class {},
  TabModule: class {},
  SidePanelModule: class {},
  SpinnerModule: class {},
  TextFieldModule: class {},
  MenuModule: class {},
  ItemModule: class {},
  ToastService: class {
    InsertToast = vi.fn();
  },
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  CrfLpCommonModule: class {},
  GridDataSourceService: class {},
  InfiniteGridComponent: class {},
  RightsUtilityService: class {},
  UserService: class {},
  RIGHTS_CONFIG: { EDITOR_RIGHTS: ['OWNED', 'EDIT'] },
}));

vi.mock('@nielsen/crf-ui-components', () => ({
  DialogsModule: class {},
  TreeForderSelectorModule: class {},
  CreateFolderComponent: class {
    resetForm = vi.fn();
    open = vi.fn();
    close = vi.fn();
    updateLoader = vi.fn();
  },
}));

vi.mock('../../../shared/services/survey-common.service', () => ({
  SurveyCommonService: class {},
}));

vi.mock('../services/survey-grid-handler.service', () => ({
  SurveyGridHandlerService: class {},
}));

vi.mock('../services/survey-asset-api.service', () => ({
  SurveyAssetApiService: class {
    createFolder = vi.fn();
    fetchFolderHierarchy = vi.fn().mockReturnValue(of([]));
  },
}));

describe('MyAssetsPageComponent', () => {
  let mockTranslateService: any;
  let component: MyAssetsPageComponent;
  let router: Pick<Router, 'navigate' | 'navigateByUrl'> & { url: string };
  let store: Pick<Store, 'dispatch'>;
  let storeDispatchSpy: ReturnType<typeof vi.fn>;
  let surveyCommonService: Pick<SurveyCommonService, 'resetState'>;
  let storeStub: Pick<Store, 'dispatch'>;
  let routerStub: Pick<Router, 'navigate' | 'navigateByUrl'>;
  let surveyCommonStub: Pick<SurveyCommonService, 'resetState'>;
  let surveyAssetApiStub: { createFolder: ReturnType<typeof vi.fn>; fetchSurveyDetails: ReturnType<typeof vi.fn>; fetchFolderHierarchy: ReturnType<typeof vi.fn> };
  let toastServiceStub: { InsertToast: ReturnType<typeof vi.fn> };
  let gridServiceStub: { isLoading: ReturnType<typeof signal<boolean>>; onMenuAction: ReturnType<typeof vi.fn>; pageSize: number; deleteRequested$: Subject<SurveyGridRow>; rowUpdated$: Observable<{ action: string }>; rowsLoaded$: Subject<SurveyGridRowsLoadedEvent>; setActiveFolder: ReturnType<typeof vi.fn>; viewUpdatedAt: Map<string, number>  };
  let rowsLoaded: Subject<SurveyGridRowsLoadedEvent>;
  let activatedRouteStub: ActivatedRoute;
  let routeParamMap: BehaviorSubject<{ get: (key: string) => string | null }>;
  let currentUser: BehaviorSubject<{ id: string }>;
  let rightsUtilityStub: { checkAvailableRightsForMe: ReturnType<typeof vi.fn> };

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    storeDispatchSpy = vi.fn();
    router = {
      url: '/survey/my-assets',
      navigate: vi.fn().mockResolvedValue(true),
      navigateByUrl: vi.fn().mockResolvedValue(true),
    };
    store = {
      dispatch: storeDispatchSpy,
    } as Pick<Store, 'dispatch'>;
    surveyCommonService = {
      resetState: vi.fn(),
    };
    surveyAssetApiStub = {
      createFolder: vi.fn(),
      fetchSurveyDetails: vi.fn(),
      fetchFolderHierarchy: vi.fn().mockReturnValue(of([])),
    };
    toastServiceStub = {
      InsertToast: vi.fn(),
    };
    rowsLoaded = new Subject<SurveyGridRowsLoadedEvent>();
    gridServiceStub = {
      isLoading: signal(false),
      onMenuAction: vi.fn(),
      pageSize: 100,
      deleteRequested$: new Subject<SurveyGridRow>(),
      rowUpdated$: of(),
      rowsLoaded$: rowsLoaded,
      setActiveFolder: vi.fn(),
      viewUpdatedAt: new Map(),
    };

    storeStub = store as Pick<Store, 'dispatch'>;
    routerStub = router;
    surveyCommonStub = surveyCommonService as Pick<SurveyCommonService, 'resetState'>;

    routeParamMap = new BehaviorSubject<{ get: (key: string) => string | null }>({ get: () => null });
    currentUser = new BehaviorSubject({ id: 'current-user' });
    rightsUtilityStub = { checkAvailableRightsForMe: vi.fn().mockReturnValue(true) };
    activatedRouteStub = {
      paramMap: routeParamMap,
      parent: {},
      snapshot: { data: { tabId: 'my-assets' }, paramMap: { get: () => null } },
    } as unknown as ActivatedRoute;

    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: TranslateStore, useValue: createMockTranslateStore() },
        { provide: Store, useValue: storeStub },
        { provide: Router, useValue: routerStub },
        { provide: SurveyCommonService, useValue: surveyCommonStub },
        { provide: ActivatedRoute, useValue: activatedRouteStub },
        { provide: SurveyAssetApiService, useValue: surveyAssetApiStub },
        { provide: ToastService, useValue: toastServiceStub },
        { provide: SurveyGridHandlerService, useValue: gridServiceStub },
        { provide: UserService, useValue: { getUserData: () => currentUser } },
        { provide: RightsUtilityService, useValue: rightsUtilityStub },
        { provide: ChangeDetectorRef, useValue: { markForCheck: vi.fn(), detectChanges: vi.fn() } },
        { provide: EnvironmentConfig, useValue: { apiUrls: { assetCatalogDiscovery: '/assets' } } },
      ],
    });

    component = TestBed.runInInjectionContext(() => new MyAssetsPageComponent());
  });

    afterEach(() => TestBed.resetTestingModule());

    const surveyRow: SurveyGridRow = {
      assetId: 'survey-1',
      assetType: 'DISCOVERSURVEY',
      title: 'Survey',
      lastModifiedTimestamp: 0,
    };

    it.each([
      ['keydown', 'Enter', true],
      ['keydown', ' ', false],
      ['keyup', ' ', true],
    ] as const)('handles asset title %s with %j', (type, key, shouldOpen) => {
      const event = new KeyboardEvent(type, { key, cancelable: true });
      const stopPropagation = vi.spyOn(event, 'stopPropagation');
      const open = vi.spyOn(component, 'onGridRowAction');

      component.onAssetTitleKey(event, surveyRow);

      expect(event.defaultPrevented).toBe(true);
      expect(stopPropagation).toHaveBeenCalledOnce();
      if (shouldOpen) {
        expect(open).toHaveBeenCalledExactlyOnceWith('open', surveyRow);
      } else {
        expect(open).not.toHaveBeenCalled();
      }
    });

    it('loads details and returns to idle when the panel closes', () => {
      const response = new Subject<SurveyGridRow>();
      surveyAssetApiStub.fetchSurveyDetails.mockReturnValue(response);
      expect(component.detailsState()).toEqual({ status: 'idle' });
      component.onGridRowAction('info', surveyRow);
      TestBed.tick();
      expect(surveyAssetApiStub.fetchSurveyDetails).toHaveBeenCalledWith(surveyRow);
      expect(component.detailsState()).toEqual({ status: 'loading' });
      response.next(surveyRow);
      expect(component.detailsState()).toEqual({ status: 'ready', survey: surveyRow });
      component.closeDetails();
      TestBed.tick();
      expect(component.selectedSurvey()).toBeNull();
      expect(component.detailsState()).toEqual({ status: 'idle' });
      expect(response.observed).toBe(false);
    });

    it('shows an error when details fail and can load a different survey afterwards', () => {
      surveyAssetApiStub.fetchSurveyDetails.mockReturnValueOnce(throwError(() => new Error('Failed')))
        .mockReturnValueOnce(of({ ...surveyRow, assetId: 'survey-2' }));
      component.onGridRowAction('info', surveyRow);
      TestBed.tick();
      expect(component.detailsState()).toEqual({ status: 'error' });
      component.onGridRowAction('info', { ...surveyRow, assetId: 'survey-2' });
      TestBed.tick();
      expect(component.detailsState()).toEqual({
        status: 'ready', survey: { ...surveyRow, assetId: 'survey-2' },
      });
    });

    it('cancels the previous detail request when another row is selected', () => {
      const previous = new Subject<SurveyGridRow>();
      const current = new Subject<SurveyGridRow>();
      surveyAssetApiStub.fetchSurveyDetails.mockReturnValueOnce(previous).mockReturnValueOnce(current);
      component.onGridRowAction('info', surveyRow);
      TestBed.tick();
      component.onGridRowAction('info', { ...surveyRow, assetId: 'survey-2' });
      TestBed.tick();
      expect(previous.observed).toBe(false);
      expect(current.observed).toBe(true);
      expect(component.detailsState()).toEqual({ status: 'loading' });
    });
  afterEach(() => {
    vi.unstubAllGlobals();
    TestBed.resetTestingModule();
  });

  it('selects the tab supplied by route data', () => {
    expect(component.activeTabId).toBe('my-assets');
  });

  it('tracks row selection by asset ID', () => {
    component.onInfiniteGridSelectionChange([surveyRow]);
    expect(component.selectedRows()).toEqual([surveyRow]);
    expect(component.isRowSelected(surveyRow)).toBe(true);
    expect(component.isRowSelected({ ...surveyRow, assetId: 'other' })).toBe(false);
  });

  it('deselects all rows through the grid API and clears local selection', () => {
    const deselectAll = vi.fn();
    (component as any).grid = { agGrid: { api: { deselectAll } } };
    component.onInfiniteGridSelectionChange([surveyRow]);

    component.deselectAllRows();

    expect(deselectAll).toHaveBeenCalledOnce();
    expect(component.selectedRows()).toEqual([]);
    expect(component.isRowSelected(surveyRow)).toBe(false);
  });

  it('clears selection when the grid emits no selection payload', () => {
    component.onInfiniteGridSelectionChange(undefined as unknown as SurveyGridRow[]);
    expect(component.selectedRows()).toEqual([]);
  });

  it('wires open in new window and duplicate selection actions to the grid service', () => {
    component.onSelectionAction({ actionId: 'open-new-tab', items: [surveyRow] });
    component.onSelectionAction({ actionId: 'duplicate', items: [surveyRow] });

    expect(gridServiceStub.onMenuAction).toHaveBeenNthCalledWith(1, { optionType: 'open-new-tab', row: surveyRow });
    expect(gridServiceStub.onMenuAction).toHaveBeenNthCalledWith(2, { optionType: 'duplicate', row: surveyRow });
  });

  it('opens the details side panel for the info selection action', () => {
    component.onSelectionAction({ actionId: 'info', items: [surveyRow] });
    expect(component.selectedSurvey()).toEqual(surveyRow);
    expect(component.isDetailsOpenFor(surveyRow)).toBe(true);
    expect(component.isDetailsOpenFor({ ...surveyRow, assetId: 'other' })).toBe(false);
  });

  it('selects the row when info opens and deselects it when the same info toggles closed', () => {
    const setSelected = vi.fn();
    const getRowNode = vi.fn().mockReturnValue({ setSelected });
    (component as any).grid = { agGrid: { api: { getRowNode } } };

    component.onGridRowAction('info', surveyRow);
    expect(getRowNode).toHaveBeenCalledWith('survey-1');
    expect(setSelected).toHaveBeenLastCalledWith(true);
    expect(component.selectedSurvey()).toEqual(surveyRow);

    component.onGridRowAction('info', surveyRow);
    expect(setSelected).toHaveBeenLastCalledWith(false);
    expect(component.selectedSurvey()).toBeNull();
  });

  it('closes details only when the details row leaves the selection', () => {
    const other = { ...surveyRow, assetId: 'other' };
    component.toggleDetails(surveyRow);

    component.onInfiniteGridSelectionChange([surveyRow, other]);
    expect(component.selectedSurvey()).toEqual(surveyRow);

    component.onInfiniteGridSelectionChange([other]);
    expect(component.selectedSurvey()).toBeNull();
  });

  it('uses the active tab for single-selection visibility', () => {
    const row = { ...surveyRow, status: 'CLOSED', rights: [{ userId: 'current-user', availability: SURVEY_ACCESS_AVAILABILITY.OWNED }] };
    const visibleIds = () => component.selectionActions
      .filter((action) => action.isVisible?.([row]) ?? true).map((action) => action.id);

    expect(visibleIds()).toContain('move');
    component.activeTabId = MY_ASSETS_TABS.SHARED_WITH_ME;
    expect(visibleIds()).not.toContain('move');
    component.activeTabId = MY_ASSETS_TABS.TRASH;
    expect(visibleIds()).toEqual(['info']);
  });

  it('re-evaluates permissions when the current user changes', () => {
    const row = { ...surveyRow, rights: [{ userId: 'current-user', availability: SURVEY_ACCESS_AVAILABILITY.OWNED }] };
    rightsUtilityStub.checkAvailableRightsForMe.mockImplementation((_asset, userId) => userId === 'current-user');
    const canRename = () => component.selectionActions.find((action) => action.id === 'rename')?.isVisible?.([row]);
    expect(canRename()).toBe(true);
    currentUser.next({ id: 'another-user' });
    expect(canRename()).toBe(false);
  });

  describe('grid context menu', () => {
    const makeEvent = (clientX = 100, clientY = 100) => ({
      clientX, clientY, preventDefault: vi.fn(), stopPropagation: vi.fn()
    } as unknown as MouseEvent);

    it('opens the menu for the right-clicked row without mutating the grid selection, preventing the browser default menu', () => {
      expect(component.contextMenuRow()).toBeNull();
      expect(component.contextMenuOpen()).toBe(false);
      const event = makeEvent(50, 60);

      component.onGridContextMenu({ data: surveyRow, event });

      expect(component.contextMenuRow()).toEqual(surveyRow);
      expect(component.contextMenuOpen()).toBe(true);
      expect(component.contextMenuPosition()).toEqual({ x: 50, y: 60 });
      expect(component.selectedRows()).toEqual([]);
      expect(event.preventDefault).toHaveBeenCalled();
      expect(event.stopPropagation).not.toHaveBeenCalled();
    });

    it('reopens for a second right-click while the menu is already open (the same niq-menu instance is reused)', () => {
      const rowA = surveyRow;
      const rowB = { ...surveyRow, assetId: 'survey-2' };

      component.onGridContextMenu({ data: rowA, event: makeEvent(10, 10) });
      expect(component.contextMenuRow()).toEqual(rowA);
      expect(component.contextMenuOpen()).toBe(true);

      component.onGridContextMenu({ data: rowB, event: makeEvent(20, 20) });
      expect(component.contextMenuRow()).toEqual(rowB);
      expect(component.contextMenuOpen()).toBe(true);
      expect(component.contextMenuPosition()).toEqual({ x: 20, y: 20 });
    });

    it('ignores context menu events missing row data or the mouse event', () => {
      component.onGridContextMenu({ event: makeEvent() });
      expect(component.contextMenuRow()).toBeNull();

      component.onGridContextMenu({ data: surveyRow });
      expect(component.contextMenuRow()).toBeNull();
    });

    it('shows the exact same actions/visibility as a single-row toolbar selection, per active tab', () => {
      const row = { ...surveyRow, status: 'CLOSED', rights: [{ userId: 'current-user', availability: SURVEY_ACCESS_AVAILABILITY.OWNED }] };
      const toolbarVisibleIds = () => component.selectionActions
        .filter((action) => action.isVisible?.([row]) ?? true).map((action) => action.id);

      for (const tabId of Object.values(MY_ASSETS_TABS)) {
        component.activeTabId = tabId;
        component.onGridContextMenu({ data: row, event: makeEvent() });
        expect(component.contextMenuActions.map((action) => action.id)).toEqual(toolbarVisibleIds());
        if (tabId === MY_ASSETS_TABS.RECENT || tabId === MY_ASSETS_TABS.MY_FAVORITES) {
          expect(component.showRowSelectionCheckbox()).toBe(false);
        }
      }
    });

    it('dispatches the selected context-menu action through the same handler the toolbar uses, then closes', () => {
      component.onGridContextMenu({ data: surveyRow, event: makeEvent() });

      component.onContextMenuAction('info', surveyRow);

      expect(component.selectedSurvey()).toEqual(surveyRow);
      expect(component.contextMenuRow()).toBeNull();
      expect(component.contextMenuOpen()).toBe(false);
    });

    it('still dispatches with the clicked row when niq-menu auto-closes (and nulls contextMenuRow) first', () => {
      // Menu activation can clear the signal before the action handler runs.
      component.onGridContextMenu({ data: surveyRow, event: makeEvent() });
      component.onContextMenuOpenedChange(false);
      expect(component.contextMenuRow()).toBeNull();

      component.onContextMenuAction('info', surveyRow);

      expect(component.selectedSurvey()).toEqual(surveyRow);
    });

    it('closes the menu when the menu reports it is no longer opened', () => {
      component.onGridContextMenu({ data: surveyRow, event: makeEvent() });
      expect(component.contextMenuRow()).not.toBeNull();
      expect(component.contextMenuOpen()).toBe(true);

      component.onContextMenuOpenedChange(true);
      expect(component.contextMenuRow()).not.toBeNull();
      expect(component.contextMenuOpen()).toBe(true);

      component.onContextMenuOpenedChange(false);
      expect(component.contextMenuRow()).toBeNull();
      expect(component.contextMenuOpen()).toBe(false);
      expect(component.contextMenuActions).toEqual([]);
    });
  });

  it.each(Object.values(MY_ASSETS_TABS))('hides pending Delete and Restore actions from the toolbar and context menu in %s', (tab) => {
    component.activeTabId = tab;
    const row = { ...surveyRow, status: 'CLOSED', rights: [{ userId: 'current-user', availability: SURVEY_ACCESS_AVAILABILITY.OWNED }] };
    component.onGridContextMenu({ data: row, event: new MouseEvent('contextmenu') });

    expect(component.selectionActions.map((action) => action.id)).not.toContain('delete');
    expect(component.selectionActions.map((action) => action.id)).not.toContain('restore');
    expect(component.contextMenuActions.map((action) => action.id)).not.toContain('delete');
    expect(component.contextMenuActions.map((action) => action.id)).not.toContain('restore');
    if (tab === MY_ASSETS_TABS.TRASH) {
      expect(component.contextMenuActions.map((action) => action.id)).toEqual(['info']);
    }
  });

  it('treats out-of-scope and empty selection actions as no-ops', () => {
    const openDelete = vi.fn();
    const openDeletePermanently = vi.fn();
    const restore = vi.fn();
    Object.assign(component, { assetActionDialogs: { openDelete, openDeletePermanently, restore } });
    for (const actionId of ['share', 'export', 'delete', 'restore'] as const) {
      component.onSelectionAction({ actionId, items: [surveyRow] });
    }
    component.activeTabId = MY_ASSETS_TABS.TRASH;
    component.onContextMenuAction('delete', surveyRow);
    component.onContextMenuAction('restore', surveyRow);
    gridServiceStub.deleteRequested$.next(surveyRow);
    component.onSelectionAction({ actionId: 'info', items: [] });

    expect(openDelete).not.toHaveBeenCalled();
    expect(openDeletePermanently).not.toHaveBeenCalled();
    expect(restore).not.toHaveBeenCalled();
    expect(gridServiceStub.onMenuAction).not.toHaveBeenCalled();
    expect(component.selectedSurvey()).toBeNull();
  });

  it('opens the shared action dialogs with the selected assets', () => {
    const openRename = vi.fn();
    const openMove = vi.fn();
    Object.assign(component, { assetActionDialogs: { openRename, openMove } });
    component.onSelectionAction({ actionId: 'rename', items: [surveyRow] });
    component.onSelectionAction({ actionId: 'move', items: [surveyRow] });
    expect(openRename).toHaveBeenCalledWith(surveyRow);
    expect(openMove).toHaveBeenCalledWith([surveyRow]);
  });

  // Retain integration tests until Delete and Restore API wiring is re-enabled.
  it.skip('routes soft deletion outside Trash for single assets, folders and bulk selections', () => {
    const openDelete = vi.fn();
    const openDeletePermanently = vi.fn();
    Object.assign(component, { assetActionDialogs: { openDelete, openDeletePermanently } });
    component.activeTabId = MY_ASSETS_TABS.MY_ASSETS;

    const folderRow = { ...surveyRow, assetId: 'folder-1', assetType: 'DISCOVERFOLDER' };
    component.onSelectionAction({ actionId: 'delete', items: [surveyRow] });
    component.onSelectionAction({ actionId: 'delete', items: [folderRow] });
    component.onSelectionAction({ actionId: 'delete', items: [surveyRow, folderRow] });

    expect(openDelete).toHaveBeenCalledTimes(3);
    expect(openDelete).toHaveBeenNthCalledWith(1, [surveyRow]);
    expect(openDelete).toHaveBeenNthCalledWith(2, [folderRow]);
    expect(openDelete).toHaveBeenNthCalledWith(3, [surveyRow, folderRow]);
    expect(openDeletePermanently).not.toHaveBeenCalled();
  });

  it.skip('routes the grid single-row delete through the shared delete handler', () => {
    const openDelete = vi.fn();
    Object.assign(component, { assetActionDialogs: { openDelete } });

    gridServiceStub.deleteRequested$.next(surveyRow);

    expect(openDelete).toHaveBeenCalledExactlyOnceWith([surveyRow]);
  });

  it.skip('opens Delete permanently (not the soft-delete confirmation) when "delete" fires from the Trash tab', () => {
    const openDelete = vi.fn();
    const openDeletePermanently = vi.fn();
    Object.assign(component, { assetActionDialogs: { openDelete, openDeletePermanently } });
    component.activeTabId = MY_ASSETS_TABS.TRASH;

    component.onSelectionAction({ actionId: 'delete', items: [surveyRow] });

    expect(openDeletePermanently).toHaveBeenCalledExactlyOnceWith([surveyRow]);
    expect(openDelete).not.toHaveBeenCalled();
  });

  it.skip('restores immediately (no confirmation dialog) regardless of the active tab', () => {
    const restore = vi.fn();
    Object.assign(component, { assetActionDialogs: { restore } });
    component.activeTabId = MY_ASSETS_TABS.TRASH;

    component.onSelectionAction({ actionId: 'restore', items: [surveyRow] });

    expect(restore).toHaveBeenCalledExactlyOnceWith([surveyRow]);
  });

  it('invalidates and refreshes the catalog, clears selection, and marks the view updated after an asset action succeeds', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      const clearCache = vi.spyOn(TestBed.inject(ApiService), 'clearCache');
      const refresh = vi.spyOn(component, 'refreshGrid');
      component.selectedSurvey.set(surveyRow);
      component.onInfiniteGridSelectionChange([surveyRow]);
      gridServiceStub.viewUpdatedAt.set('/survey/my-assets/folder/destination', 123);
      gridServiceStub.viewUpdatedAt.set('/survey/trash', 456);
      component.onAssetsChanged();
      expect(component.selectedSurvey()).toBeNull();
      expect(component.selectedRows()).toEqual([]);
      expect(clearCache).toHaveBeenCalledExactlyOnceWith('/assets');
      expect(refresh).toHaveBeenCalledOnce();
      expect(clearCache.mock.invocationCallOrder[0]).toBeLessThan(refresh.mock.invocationCallOrder[0]);
      expect(component.lastUpdated()).toBe(Date.now());
      expect(gridServiceStub.viewUpdatedAt.get(router.url)).toBe(Date.now());
      expect(gridServiceStub.viewUpdatedAt.size).toBe(1);
      expect(component.showRefreshButton()).toBe(false);
    } finally {
      vi.useRealTimers();
    }
  });

  it('initializes a fresh timestamp when revisiting a folder after an asset mutation', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      const folderUrl = '/survey/my-assets/folder/destination';
      gridServiceStub.viewUpdatedAt.set(folderUrl, 123);
      component.onAssetsChanged();
      expect(gridServiceStub.viewUpdatedAt.has(folderUrl)).toBe(false);
      vi.advanceTimersByTime(60_000);
      const url = vi.spyOn(router, 'url', 'get').mockReturnValue(folderUrl);
      rowsLoaded.next(viewLoaded(true));
      expect(component.lastUpdated()).toBe(Date.now());
      expect(gridServiceStub.viewUpdatedAt.get(folderUrl)).toBe(Date.now());
      expect(component.showRefreshButton()).toBe(false);
      url.mockRestore();
    } finally {
      vi.useRealTimers();
    }
  });

  it('delegates non-info actions without opening the details panel', () => {
    component.onGridRowAction('favorite', surveyRow);
    expect(gridServiceStub.onMenuAction).toHaveBeenCalledWith({ optionType: 'favorite', row: surveyRow });
    expect(component.selectedSurvey()).toBeNull();
  });

  it('formats grid placeholders and published dates', () => {
    expect(component.formatResponses(surveyRow)).toBe('--');
    expect(component.formatPublishedDate()).toBe('--');
    expect(component.formatPublishedDate(new Date(2026, 9, 16).getTime())).toBe('--');
  });

  it('resets survey state before following the empty-state route', () => {
    const navigateByUrl = vi.fn().mockResolvedValue(true);
    Object.assign(router, { navigateByUrl });
    component.onEmptyStateAction('/survey');
    expect(surveyCommonService.resetState).toHaveBeenCalledOnce();
    expect(navigateByUrl).toHaveBeenCalledWith('/survey');
  });

  it('opens and resets the folder dialog when available', () => {
    const resetForm = vi.fn();
    const open = vi.fn();
    Object.assign(component, { createFolderDialog: { resetForm, open } });
    component.openCreateFolderDialog();
    expect(resetForm).toHaveBeenCalledOnce();
    expect(open).toHaveBeenCalledOnce();
  });

  it('handles opening the folder dialog before the view query is available', () => {
    expect(() => component.openCreateFolderDialog()).not.toThrow();
  });

  it('refreshes favorites only for favorite updates on the Favorites tab', () => {
    const updates = new Subject<{ action: string }>();
    gridServiceStub.rowUpdated$ = updates;
    const subscribedComponent = TestBed.runInInjectionContext(() => new MyAssetsPageComponent());
    const refresh = vi.spyOn(subscribedComponent, 'refreshGrid');
    gridServiceStub.viewUpdatedAt.set('/survey/my-favorites', 123);
    updates.next({ action: 'favorite' });
    expect(refresh).not.toHaveBeenCalled();
    expect(gridServiceStub.viewUpdatedAt.has('/survey/my-favorites')).toBe(false);
    expect(gridServiceStub.viewUpdatedAt.get(router.url)).toBe(subscribedComponent.lastUpdated());
    expect(subscribedComponent.showRefreshButton()).toBe(false);
    subscribedComponent.activeTabId = MY_ASSETS_TABS.MY_FAVORITES;
    updates.next({ action: 'favorite' });
    expect(refresh).toHaveBeenCalledOnce();
    updates.next({ action: 'other' });
    expect(refresh).toHaveBeenCalledOnce();
  });

  it.each([
    [MY_ASSETS_TABS.MY_ASSETS, true],
    [MY_ASSETS_TABS.RECENT, false],
    [MY_ASSETS_TABS.SHARED_WITH_ME, true],
    [MY_ASSETS_TABS.MY_FAVORITES, false],
    [MY_ASSETS_TABS.TRASH, true],
  ] as const)('shows row selection checkbox for %s: %s', (tabId, expected) => {
    component.activeTabId = tabId;
    expect(component.showRowSelectionCheckbox()).toBe(expected);
  });

  it('loads the folder from the route snapshot when paramMap is unavailable', () => {
    Object.defineProperty(activatedRouteStub, 'paramMap', { value: undefined });
    Object.defineProperty(activatedRouteStub.snapshot, 'paramMap', {
      value: { get: (key: string) => key === 'folderId' ? 'snapshot-folder' : null },
    });

    const snapshotComponent = TestBed.runInInjectionContext(() => new MyAssetsPageComponent());

    expect(snapshotComponent.activeFolderId()).toBe('snapshot-folder');
    expect(surveyAssetApiStub.fetchFolderHierarchy).toHaveBeenCalledWith('snapshot-folder');
  });

  it('falls back to My Assets for an unknown route tab', () => {
    activatedRouteStub.snapshot.data['tabId'] = 'unknown-tab';

    expect((component as any).getActiveTabId()).toBe('my-assets');
  });

  it('navigates to the selected tab route', () => {
    component.onTabChange('shared-with-me');

    expect(router.navigateByUrl).toHaveBeenCalledWith('/survey/shared-with-me');
  });

  it('preserves the Landing Page route prefix when changing tabs', () => {
    router.url = '/my-assets/survey/my-assets';

    component.onTabChange('shared-with-me');

    expect(router.navigateByUrl).toHaveBeenCalledWith('/my-assets/survey/shared-with-me');
  });

  it('navigates to a clickable breadcrumb ancestor but ignores the current folder', () => {
    component.activeFolderId.set('child');
    const root = { label: 'My assets', url: '/survey/my-assets' };
    const ancestor = { label: 'Parent', url: '/survey/my-assets/folder/parent' };
    const current = { label: 'Child', url: '/survey/my-assets/folder/child' };
    component.folderBreadcrumbs.set([root, ancestor, current]);

    component.onFolderBreadcrumbClick(ancestor);
    component.onFolderBreadcrumbClick(current);

    expect(router.navigateByUrl).toHaveBeenCalledTimes(1);
    expect(router.navigateByUrl).toHaveBeenCalledWith('/survey/my-assets/folder/parent', {
      state: { folderBreadcrumbs: [root, ancestor] },
    });
  });

  it('preserves the Landing Page route prefix when navigating a folder breadcrumb', () => {
    router.url = '/my-assets/survey/my-assets/folder/child';
    component.activeFolderId.set('child');
    const root = { label: 'My assets', url: '/my-assets/survey/my-assets' };
    const ancestor = { label: 'Parent', url: '/my-assets/survey/my-assets/folder/parent' };
    const current = { label: 'Child', url: '/my-assets/survey/my-assets/folder/child' };
    component.folderBreadcrumbs.set([root, ancestor, current]);

    component.onFolderBreadcrumbClick(ancestor);

    expect(router.navigateByUrl).toHaveBeenCalledWith('/my-assets/survey/my-assets/folder/parent', {
      state: { folderBreadcrumbs: [root, ancestor] },
    });
  });

  it.each([
    ['my-assets', true],
    ['shared-with-me', true],
    ['trash', true],
    ['recent', false],
    ['my-favorites', false],
  ] as const)('shows a folder breadcrumb on %s: %s', (tabId, expected) => {
    component.activeTabId = tabId;
    component.activeFolderId.set('folder-1');

    expect(component.shouldShowFolderBreadcrumb()).toBe(expected);
  });

  it('navigates to the root tab when the My Assets breadcrumb is selected', () => {
    component.activeFolderId.set('child');

    component.onFolderBreadcrumbClick({ label: 'My assets', url: '/survey/my-assets' });

    expect(router.navigateByUrl).toHaveBeenCalledWith('/survey/my-assets');
  });

  it('does not navigate when the active tab is selected again', () => {
    component.onTabChange('my-assets');

    expect(router.navigateByUrl).not.toHaveBeenCalled();
  });

  it('initializes the grid when its view query becomes available', () => {
    const grid = { infiniteInitialRowCount: 0 };

    component.surveyGrid = grid as any;

    expect(grid.infiniteInitialRowCount).toBe(100);
  });

  it('updates the initial loading row count without refreshing the datasource', () => {
    const setGridOption = vi.fn();
    const refreshData = vi.fn();
    const grid = {
      infiniteInitialRowCount: 1,
      agGrid: { api: { setGridOption } },
      refreshData,
    };

    component.surveyGrid = grid as any;

    expect(setGridOption).toHaveBeenCalledWith('infiniteInitialRowCount', 100);
    expect(refreshData).not.toHaveBeenCalled();
  });

  it('initializes the grid row count and handles loading completion', () => {
    const setGridOption = vi.fn();
    const grid = {
      infiniteInitialRowCount: 0,
      refreshData: vi.fn(),
      agGrid: { api: { setGridOption } },
    };
    component.surveyGrid = grid as any;
    component.onShowGridFlag(false);
    component.onShowGridFlag(true);

    expect(grid.infiniteInitialRowCount).toBe(100);
    expect(setGridOption).toHaveBeenCalledWith('loading', false);
  });

  it('refreshes the current grid', () => {
    const refreshData = vi.fn();
    (component as any).surveyGrid = { refreshData };

    component.refreshGrid();

    expect(refreshData).toHaveBeenCalledTimes(1);
  });

  it('invalidates only the active tab and folder cache on Refresh', () => {
    const clearCache = vi.spyOn(TestBed.inject(ApiService), 'clearCache');
    component.surveyGrid = { refreshData: vi.fn() } as any;
    component.activeTabId = MY_ASSETS_TABS.SHARED_WITH_ME;
    component.activeFolderId.set('folder-42');
    rowsLoaded.next(viewLoaded(false));

    component.onRefresh();

    expect(clearCache).toHaveBeenCalledWith(
      '/assets',
      getAssetCatalogCacheTag(MY_ASSETS_TABS.SHARED_WITH_ME, 'folder-42')
    );
  });

  it('disables Refresh immediately on folder navigation before the grid request starts', () => {
    rowsLoaded.next(viewLoaded(false));
    expect(component.isRefreshing()).toBe(false);
    routeParamMap.next({ get: (key) => key === 'folderId' ? 'next-folder' : null });
    expect(gridServiceStub.isLoading()).toBe(false);
    expect(component.isRefreshing()).toBe(true);
    rowsLoaded.next(viewLoaded(false));
    expect(component.isRefreshing()).toBe(false);
  });

  it('disables Refresh while loading, then shows "just now" for 10 seconds after a successful load', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      const refreshData = vi.fn();
      component.surveyGrid = { refreshData } as any;
      component.lastUpdated.set(0);

      rowsLoaded.next(viewLoaded(false));
      component.onRefresh();
      component.onRefresh();

      expect(refreshData).toHaveBeenCalledTimes(1);
      expect(component.isRefreshing()).toBe(true);
      expect(component.showRefreshButton()).toBe(true);
      expect(component.lastUpdated()).toBe(0);

      rowsLoaded.next(viewLoaded(true));

      expect(component.isRefreshing()).toBe(false);
      expect(component.lastUpdated()).toBe(Date.now());
      expect(component.showRefreshButton()).toBe(false);

      vi.advanceTimersByTime(5_000);
      component.onRefresh();
      rowsLoaded.next(viewLoaded(true));
      vi.advanceTimersByTime(9_999);
      expect(component.showRefreshButton()).toBe(false);

      vi.advanceTimersByTime(1);
      expect(component.showRefreshButton()).toBe(true);
    } finally {
      vi.useRealTimers();
    }
  });

  it('re-enables Refresh and keeps the last updated time when the load fails', () => {
    component.surveyGrid = { refreshData: vi.fn() } as any;
    component.lastUpdated.set(123);

    component.onRefresh();
    rowsLoaded.next(viewLoaded(false));

    expect(component.isRefreshing()).toBe(false);
    expect(component.showRefreshButton()).toBe(true);
    expect(component.lastUpdated()).toBe(123);
  });

  it('does not claim an update before the first successful load', () => {
    expect(component.lastUpdated()).toBeNull();
    component.onRefresh();
    rowsLoaded.next(viewLoaded(false));

    expect(component.lastUpdated()).toBeNull();
    expect(component.isRefreshing()).toBe(false);
    expect(component.showRefreshButton()).toBe(true);
  });

  it('cancels the hide timer on failure and starts a fresh delay after recovery', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      rowsLoaded.next(viewLoaded(true));
      const lastSuccess = component.lastUpdated();
      expect(vi.getTimerCount()).toBe(1);
      vi.advanceTimersByTime(3_000);
      rowsLoaded.next(viewLoaded(false));

      expect(component.lastUpdated()).toBe(lastSuccess);
      expect(component.showRefreshButton()).toBe(true);
      expect(component.isRefreshing()).toBe(false);
      expect(vi.getTimerCount()).toBe(0);

      rowsLoaded.next(viewLoaded(true));
      expect(component.lastUpdated()).toBe(Date.now());
      expect(component.showRefreshButton()).toBe(false);
      vi.advanceTimersByTime(7_000);
      expect(component.showRefreshButton()).toBe(false);
      vi.advanceTimersByTime(3_000);
      expect(component.showRefreshButton()).toBe(true);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      TestBed.resetTestingModule();
      vi.useRealTimers();
    }
  });

  it.each(['save', 'cancel'] as const)('does not re-enter dialog close when handling %s through the template', async (action) => {
    TestBed.resetTestingModule();
    await TestBed.configureTestingModule({
      providers: [
        { provide: RightsUtilityService, useValue: rightsUtilityStub },
        { provide: UserService, useValue: { getUserData: () => currentUser } },
        { provide: Store, useValue: storeStub },
        { provide: Router, useValue: routerStub },
        { provide: SurveyCommonService, useValue: surveyCommonStub },
        { provide: ActivatedRoute, useValue: activatedRouteStub },
        { provide: SurveyAssetApiService, useValue: surveyAssetApiStub },
        { provide: ToastService, useValue: toastServiceStub },
        { provide: SurveyGridHandlerService, useValue: gridServiceStub },
        { provide: EnvironmentConfig, useValue: { apiUrls: { assetCatalogDiscovery: '/assets' } } },
      ],
    }).overrideComponent(MyAssetsPageComponent, {
      set: {
        providers: [
          { provide: GridDataSourceService, useExisting: SurveyGridHandlerService },
          { provide: TranslateService, useValue: mockTranslateService },
        ],
        imports: [CommonModule, MomentModule, CreateFolderDialogStub],
        schemas: [NO_ERRORS_SCHEMA],
        templateUrl: undefined,
        styleUrl: undefined,
        styles: [],
        template,
      },
    }).compileComponents();
    const fixture = TestBed.createComponent(MyAssetsPageComponent);
    const page = fixture.componentInstance;
    const refreshGrid = vi.spyOn(page, 'refreshGrid').mockImplementation(() => undefined);
    fixture.detectChanges();
    const dialog = fixture.debugElement.query(By.directive(CreateFolderDialogStub))
      .injector.get(CreateFolderDialogStub);
    surveyAssetApiStub.createFolder.mockReturnValue(of({ assetId: 'child-folder' }));
    page.activeFolderId.set('parent-folder');

    if (action === 'save') {
      dialog.save.emit({ title: 'Child folder' });
      expect(surveyAssetApiStub.createFolder).toHaveBeenCalledWith('Child folder', 'parent-folder');
      expect(dialog.updateLoader).toHaveBeenCalledOnce();
      expect(refreshGrid).toHaveBeenCalledOnce();
    } else {
      dialog.close();
      expect(surveyAssetApiStub.createFolder).not.toHaveBeenCalled();
      expect(refreshGrid).not.toHaveBeenCalled();
    }

    expect(dialog.close).toHaveBeenCalledOnce();
  });

  it('renders context-menu interactions and refresh state through the page template', async () => {
    mockTranslateService = createMockTranslateService();
    TestBed.resetTestingModule();
    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: RightsUtilityService, useValue: rightsUtilityStub },
        { provide: UserService, useValue: { getUserData: () => currentUser } },
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: TranslateStore, useValue: createMockTranslateStore() },
        { provide: Store, useValue: storeStub },
        { provide: Router, useValue: routerStub },
        { provide: SurveyCommonService, useValue: surveyCommonStub },
        { provide: ActivatedRoute, useValue: activatedRouteStub },
        { provide: SurveyAssetApiService, useValue: surveyAssetApiStub },
        { provide: ToastService, useValue: toastServiceStub },
        { provide: SurveyGridHandlerService, useValue: gridServiceStub },
        { provide: EnvironmentConfig, useValue: { apiUrls: { assetCatalogDiscovery: '/assets' } } },
      ],
    }).overrideComponent(MyAssetsPageComponent, {
      set: {
        imports: [CommonModule, MomentModule, CommonSidePanelComponent],
        schemas: [NO_ERRORS_SCHEMA],
        templateUrl: undefined,
        styleUrl: undefined,
        styles: [],
        template,
      },
    }).overrideComponent(CommonSidePanelComponent, {
      set: {
        outputs: ['closeRequested'],
        imports: [],
        schemas: [NO_ERRORS_SCHEMA],
        templateUrl: undefined,
        styleUrl: undefined,
        template: '<section class="survey-side-panel"><ng-content /></section>',
      },
    }).compileComponents();
    const fixture = TestBed.createComponent(MyAssetsPageComponent);
    const host: HTMLElement = fixture.nativeElement;
    const query = (id: string) => host.querySelector<HTMLElement>(`[data-test-id="${id}"]`);
    fixture.detectChanges();
    const page = fixture.componentInstance;
    const panelDebug = fixture.debugElement.query(By.directive(CommonSidePanelComponent));
    Object.defineProperties(panelDebug.componentInstance, {
      open: { value: () => page.selectedSurvey() !== null },
      closeOnOutsideClick: { value: signal(true) },
    });
    page.onGridContextMenu({
      data: { ...surveyRow, status: 'CLOSED' },
      event: new MouseEvent('contextmenu', { clientX: 50, clientY: 60 }),
    });
    fixture.detectChanges();
    const menu = query('survey-grid-context-menu');
    expect(menu?.classList.contains('ctx-menu-wrapper')).toBe(true);
    expect(menu?.style.left).toBe('50px');
    expect(menu?.style.top).toBe('60px');
    expect(menu?.querySelector('[dropdown-trigger].ctx-hidden-trigger')).not.toBeNull();
    expect(menu?.querySelector('[dropdown-content] > .listbox')).not.toBeNull();
    const exportAction = query('survey-grid-context-menu-export');
    expect(exportAction?.querySelector('.listbox-item > .listbox-label')).not.toBeNull();
    expect(exportAction?.querySelector('niq-icon')?.getAttribute('state')).toBe('primary');
    const dispatchAction = vi.spyOn(page, 'onContextMenuAction');
    surveyAssetApiStub.fetchSurveyDetails.mockReturnValue(of(surveyRow));
    const info = fixture.debugElement.query(By.css('[data-test-id="survey-grid-context-menu-info"]'));
    info.nativeElement.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
    fixture.detectChanges();
    expect(page.selectedSurvey()?.assetId).toBe(surveyRow.assetId);
    expect(panelDebug.nativeElement.classList.contains('is-open')).toBe(true);
    document.body.click();
    fixture.detectChanges();
    expect(page.selectedSurvey()).toBeNull();
    expect(panelDebug.nativeElement.classList.contains('is-open')).toBe(false);
    expect(dispatchAction).toHaveBeenCalledExactlyOnceWith('info', expect.objectContaining({ assetId: surveyRow.assetId }));
    expect(page.contextMenuOpen()).toBe(false);
    fixture.detectChanges();
    const status = query('my-assets-refresh-status');
    expect(status?.getAttribute('role')).toBe('status');
    expect(status?.getAttribute('aria-live')).toBe('polite');
    expect(status?.textContent?.trim()).toBe('');
    expect(query('my-assets-last-updated')).toBeNull();
    expect(query('my-assets-updated-just-now')).toBeNull();
    expect(Reflect.get(query('my-assets-refresh-btn')!, 'state')).toBe('disabled');
    rowsLoaded.next(viewLoaded(false));
    gridServiceStub.isLoading.set(true);
    fixture.detectChanges();
    expect(Reflect.get(query('my-assets-refresh-btn')!, 'state')).toBe('disabled');
    const refresh = vi.spyOn(fixture.componentInstance, 'refreshGrid');
    fixture.componentInstance.onRefresh();
    expect(refresh).not.toHaveBeenCalled();
    gridServiceStub.isLoading.set(false);
    fixture.detectChanges();
    expect(Reflect.get(query('my-assets-refresh-btn')!, 'state')).toBe('default');
    expect(query('my-assets-refresh-btn')).not.toBeNull();
    expect(status?.contains(query('my-assets-refresh-btn'))).toBe(false);

    rowsLoaded.next(viewLoaded(false));
    fixture.detectChanges();
    expect(query('my-assets-last-updated')).toBeNull();
    expect(query('my-assets-updated-just-now')).toBeNull();

    rowsLoaded.next(viewLoaded(true));
    fixture.detectChanges();
    expect(query('my-assets-updated-just-now')?.textContent).toContain('Updated just now');
    expect(query('my-assets-refresh-status')).toBe(status);
    expect(status?.contains(query('my-assets-updated-just-now'))).toBe(true);
    expect(query('my-assets-refresh-btn')).toBeNull();

    rowsLoaded.next(viewLoaded(false));
    fixture.detectChanges();
    expect(query('my-assets-refresh-status')).toBe(status);
    expect(status?.contains(query('my-assets-last-updated'))).toBe(false);
    expect(query('my-assets-updated-just-now')).toBeNull();
    expect(query('my-assets-last-updated')?.textContent).toContain('Updated');
    expect(query('my-assets-refresh-btn')).not.toBeNull();
    expect(Reflect.get(query('my-assets-refresh-btn')!, 'state')).toBe('default');
  });

  it.each(Object.values(MY_ASSETS_TABS))('shows "just now" after loading the %s tab without clicking Refresh', (tabId) => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      activatedRouteStub.snapshot.data['tabId'] = tabId;
      const tabRowsLoaded = new Subject<SurveyGridRowsLoadedEvent>();
      gridServiceStub.rowsLoaded$ = tabRowsLoaded;
      const tabComponent = TestBed.runInInjectionContext(() => new MyAssetsPageComponent());
      tabComponent.lastUpdated.set(123);

      expect(tabComponent.activeTabId).toBe(tabId);
      expect(tabComponent.isRefreshing()).toBe(true);

      tabRowsLoaded.next(viewLoaded(true));

      expect(tabComponent.lastUpdated()).toBe(Date.now());
      expect(tabComponent.showRefreshButton()).toBe(false);
      expect(tabComponent.isRefreshing()).toBe(false);

      vi.advanceTimersByTime(9_999);
      expect(tabComponent.showRefreshButton()).toBe(false);
      vi.advanceTimersByTime(1);
      expect(tabComponent.showRefreshButton()).toBe(true);
    } finally {
      TestBed.resetTestingModule();
      vi.useRealTimers();
    }
  });

  it('keeps the last updated time and Refresh available when a tab load fails', () => {
    component.lastUpdated.set(123);

    rowsLoaded.next(viewLoaded(false));

    expect(component.lastUpdated()).toBe(123);
    expect(component.showRefreshButton()).toBe(true);
  });

  it('keeps the original update time when the same view loads again from the cache', () => {
    vi.useFakeTimers();
    try {
      rowsLoaded.next(viewLoaded(true));
      const firstLoad = component.lastUpdated();
      vi.advanceTimersByTime(5_000);
      rowsLoaded.next(viewLoaded(true));

      expect(component.lastUpdated()).toBe(firstLoad);
      vi.advanceTimersByTime(4_999);
      expect(component.showRefreshButton()).toBe(false);
      vi.advanceTimersByTime(1);
      expect(component.showRefreshButton()).toBe(true);
    } finally {
      TestBed.resetTestingModule();
      vi.useRealTimers();
    }
  });

  it('keeps the freshness timestamp and hide period when a later page loads while scrolling', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      rowsLoaded.next(viewLoaded(true));
      const initialLoad = component.lastUpdated();
      vi.advanceTimersByTime(10_000);
      expect(component.showRefreshButton()).toBe(true);

      vi.advanceTimersByTime(5 * 60_000);
      rowsLoaded.next(viewLoaded(true, 'pagination'));

      expect(component.lastUpdated()).toBe(initialLoad);
      expect(component.showRefreshButton()).toBe(true);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      TestBed.resetTestingModule();
      vi.useRealTimers();
    }
  });

  it('does not restart an active hide period on pagination', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      rowsLoaded.next(viewLoaded(true));
      vi.advanceTimersByTime(4_000);
      rowsLoaded.next(viewLoaded(true, 'pagination'));
      vi.advanceTimersByTime(6_000);

      expect(component.showRefreshButton()).toBe(true);
    } finally {
      TestBed.resetTestingModule();
      vi.useRealTimers();
    }
  });

  it('keeps the original update time and does not restart the timer when a visited tab is revisited', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      rowsLoaded.next(viewLoaded(true));
      const firstLoad = component.lastUpdated();
      vi.advanceTimersByTime(120_000);

      const revisited = TestBed.runInInjectionContext(() => new MyAssetsPageComponent());
      rowsLoaded.next(viewLoaded(true));

      expect(revisited.lastUpdated()).toBe(firstLoad);
      expect(revisited.showRefreshButton()).toBe(true);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });

  it('starts a new update time after Refresh or a failed load', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      gridServiceStub.viewUpdatedAt.set('/survey/my-shared', 1);
      rowsLoaded.next(viewLoaded(true));
      vi.advanceTimersByTime(60_000);

      component.onRefresh();
      expect(gridServiceStub.viewUpdatedAt.has(router.url)).toBe(false);
      expect(gridServiceStub.viewUpdatedAt.get('/survey/my-shared')).toBe(1);
      rowsLoaded.next(viewLoaded(true));
      expect(component.lastUpdated()).toBe(Date.now());
      expect(gridServiceStub.viewUpdatedAt.get(router.url)).toBe(Date.now());

      vi.advanceTimersByTime(60_000);
      rowsLoaded.next(viewLoaded(false));
      expect(gridServiceStub.viewUpdatedAt.has(router.url)).toBe(false);
      expect(gridServiceStub.viewUpdatedAt.get('/survey/my-shared')).toBe(1);
      rowsLoaded.next(viewLoaded(true));
      expect(component.lastUpdated()).toBe(Date.now());
    } finally {
      vi.useRealTimers();
    }
  });

  it('re-enables Refresh without touching the timestamp when a later page fails', () => {
    vi.useFakeTimers({ now: new Date('2026-01-01T10:00:00Z') });
    try {
      rowsLoaded.next(viewLoaded(true));
      const initialLoad = component.lastUpdated();
      vi.advanceTimersByTime(2_000);

      rowsLoaded.next(viewLoaded(false, 'pagination'));

      expect(component.lastUpdated()).toBe(initialLoad);
      expect(component.showRefreshButton()).toBe(true);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      TestBed.resetTestingModule();
      vi.useRealTimers();
    }
  });

  it('does not change Moment\'s global relative-time thresholds', () => {
    expect(moment.relativeTimeThreshold('m')).toBe(45);
  });

  it.each([
    [44, '44 minutes ago'],
    [50, '50 minutes ago'],
    [58, '58 minutes ago'],
    [59, 'an hour ago'],
    [120, '2 hours ago'],
  ])('formats a load %i minutes ago as "%s"', (minutes, expected) => {
    const loadedAt = moment.utc().subtract(minutes, 'minutes');

    expect(component.formatLastUpdated(loadedAt)).toBe(expected);
    // The default Moment output is unchanged, so other screens keep switching to "an hour ago" at 45 minutes.
    expect(loadedAt.fromNow()).toBe(minutes >= 45 && minutes < 90 ? 'an hour ago' : expected);
  });

  it('clears the pending Refresh timer on destroy', () => {
    const clearSpy = vi.spyOn(globalThis, 'clearTimeout');
    component.onRefresh();
    rowsLoaded.next(viewLoaded(true));
    TestBed.resetTestingModule();
    expect(clearSpy).toHaveBeenCalled();
  });

  it('recreates the grid before refreshing when the empty state is shown', () => {
    const refreshData = vi.fn();
    component.showEmptyState.set(true);
    component.surveyGrid = undefined;
    const detectChanges = vi.spyOn((component as any).cdr, 'detectChanges').mockImplementation(() => {
      component.surveyGrid = { refreshData } as any;
    });

    component.refreshGrid();

    expect(component.showEmptyState()).toBe(false);
    expect(detectChanges).toHaveBeenCalledTimes(1);
    expect(refreshData).toHaveBeenCalledTimes(1);
  });

  it('handles successful folder creation', () => {
    const dialog = {
      updateLoader: vi.fn(),
      close: vi.fn(),
    };
    const refreshSpy = vi.spyOn(component, 'refreshGrid');
    (component as any).createFolderDialog = dialog;
    vi.stubGlobal('history', { state: {
      folderAsset: { assetId: 'parent-folder-123', title: 'Parent folder' },
      folderBreadcrumbs: [
        { label: 'My assets', url: '/survey/my-assets' },
        { label: 'Parent folder', url: '/survey/my-assets/folder/parent-folder-123' },
      ],
    } });
    routeParamMap.next({ get: (key) => key === 'folderId' ? 'parent-folder-123' : null });
    surveyAssetApiStub.createFolder.mockReturnValue(of({ assetId: 'folder-1' }));

    component.onCreateFolderSave({ title: 'New folder' });

    expect(component.activeFolderId()).toBe('parent-folder-123');
    expect(surveyAssetApiStub.fetchFolderHierarchy).not.toHaveBeenCalled();
    expect(surveyAssetApiStub.createFolder).toHaveBeenCalledWith('New folder', 'parent-folder-123');
    expect(refreshSpy).toHaveBeenCalledTimes(2);
    expect(dialog.updateLoader).toHaveBeenCalledTimes(1);
    expect(dialog.close).toHaveBeenCalledTimes(1);
    expect(toastServiceStub.InsertToast).toHaveBeenCalledWith(
      'success',
      'SURVEYMOD_FOLDER_CREATED',
      expect.any(Object)
    );
  });

  it('uses navigation-state breadcrumb data without requesting folder hierarchy', () => {
    const breadcrumbs = [
      { label: 'My assets', url: '/survey/my-assets' },
      { label: 'Parent', url: '/survey/my-assets/folder/parent-id' },
      { label: 'Current', url: '/survey/my-assets/folder/current-id' },
    ];
    vi.stubGlobal('history', { state: { folderBreadcrumbs: breadcrumbs } });
    routeParamMap.next({ get: (key) => key === 'folderId' ? 'current-id' : null });

    expect(component.folderBreadcrumbs()).toEqual(breadcrumbs);
    expect(surveyAssetApiStub.fetchFolderHierarchy).not.toHaveBeenCalled();
  });

  it('fetches folder hierarchy when a folder URL has no navigation state', () => {
    vi.stubGlobal('history', { state: {} });
    routeParamMap.next({ get: (key) => key === 'folderId' ? 'direct-folder-id' : null });

    expect(surveyAssetApiStub.fetchFolderHierarchy).toHaveBeenCalledWith('direct-folder-id');
  });

  it.each([
    { assetId: 'parent', title: 'Parent', expectedLabel: 'Parent' },
    { assetId: 'parent', expectedLabel: 'parent' },
  ])('builds navigation-state ancestors with label $expectedLabel', ({ expectedLabel, ...parent }) => {
    vi.stubGlobal('history', {
      state: { folderAsset: { assetId: 'child', title: 'Child', parentAsset: parent } },
    });

    routeParamMap.next({ get: (key) => key === 'folderId' ? 'child' : null });

    expect(component.folderBreadcrumbs()).toEqual([
      { label: 'My assets', url: '/survey/my-assets' },
      { label: expectedLabel, url: '/survey/my-assets/folder/parent' },
      { label: 'Child', url: '/survey/my-assets/folder/child' },
    ]);
    expect(surveyAssetApiStub.fetchFolderHierarchy).not.toHaveBeenCalled();
  });

  it('uses the folder ID as the label when hierarchy data has no title', () => {
    vi.stubGlobal('history', { state: {} });
    surveyAssetApiStub.fetchFolderHierarchy.mockReturnValue(of([{ assetId: 'child' }]));

    routeParamMap.next({ get: (key) => key === 'folderId' ? 'child' : null });

    expect(component.folderBreadcrumbs()).toEqual([
      { label: 'My assets', url: '/survey/my-assets' },
      { label: 'child', url: '/survey/my-assets/folder/child' },
    ]);
  });

  it('rebuilds all ancestors when the child folder is opened without navigation state', () => {
    vi.stubGlobal('history', { state: {} });
    surveyAssetApiStub.fetchFolderHierarchy.mockReturnValue(of([{
      assetId: 'child', title: 'Child',
      parentAsset: {
        assetId: 'parent', title: 'Parent',
        parentAsset: { assetId: 'ancestor', title: 'Ancestor' },
      },
    }]));

    routeParamMap.next({ get: (key) => key === 'folderId' ? 'child' : null });

    expect(surveyAssetApiStub.fetchFolderHierarchy).toHaveBeenCalledWith('child');
    expect(component.folderBreadcrumbs()).toEqual([
      { label: 'My assets', url: '/survey/my-assets' },
      { label: 'Ancestor', url: '/survey/my-assets/folder/ancestor' },
      { label: 'Parent', url: '/survey/my-assets/folder/parent' },
      { label: 'Child', url: '/survey/my-assets/folder/child' },
    ]);
  });

  it('ignores a stale hierarchy response after navigating to a different folder', () => {
    vi.stubGlobal('history', { state: {} });
    const staleHierarchy = new Subject<unknown[]>();
    const currentHierarchy = new Subject<unknown[]>();
    surveyAssetApiStub.fetchFolderHierarchy
      .mockReturnValueOnce(staleHierarchy)
      .mockReturnValueOnce(currentHierarchy);

    routeParamMap.next({ get: (key) => key === 'folderId' ? 'first-folder' : null });
    routeParamMap.next({ get: (key) => key === 'folderId' ? 'current-folder' : null });
    staleHierarchy.next([{ assetId: 'first-folder', title: 'Stale folder' }]);

    expect(component.folderBreadcrumbs().at(-1)?.label).toBe('current-folder');

    currentHierarchy.next([{ assetId: 'current-folder', title: 'Current folder' }]);

    expect(component.folderBreadcrumbs().at(-1)?.label).toBe('Current folder');
  });

  it('marks for check when loading folder hierarchy fails', () => {
    vi.stubGlobal('history', { state: {} });
    const markForCheck = vi.spyOn((component as any).cdr, 'markForCheck');
    surveyAssetApiStub.fetchFolderHierarchy.mockReturnValueOnce(throwError(() => new Error('hierarchy failed')));

    routeParamMap.next({ get: (key) => key === 'folderId' ? 'folder-error' : null });

    expect(markForCheck).toHaveBeenCalled();
  });

  it('stops breadcrumb traversal when parent folders form a cycle', () => {
    vi.stubGlobal('history', { state: {} });
    const child: any = { assetId: 'child', title: 'Child' };
    const parent: any = { assetId: 'parent', title: 'Parent', parentAsset: child };
    child.parentAsset = parent;
    surveyAssetApiStub.fetchFolderHierarchy.mockReturnValueOnce(of([child]));

    routeParamMap.next({ get: (key) => key === 'folderId' ? 'child' : null });

    expect(component.folderBreadcrumbs().map((breadcrumb) => breadcrumb.label)).toEqual([
      'My assets',
      'Parent',
      'Child',
    ]);
  });

  it('handles folder creation errors', () => {
    const dialog = { updateLoader: vi.fn() };
    (component as any).createFolderDialog = dialog;
    surveyAssetApiStub.createFolder.mockReturnValue(throwError(() => new Error('create failed')));
    gridServiceStub.viewUpdatedAt.set('/survey/my-assets/folder/existing', 123);

    component.onCreateFolderSave({ title: 'New folder' });

    expect(dialog.updateLoader).toHaveBeenCalledTimes(1);
    expect(gridServiceStub.viewUpdatedAt.get('/survey/my-assets/folder/existing')).toBe(123);
    expect(toastServiceStub.InsertToast).toHaveBeenCalledWith(
      'error',
      'SURVEYMOD_FOLDER_CREATION_FAILED',
      expect.any(Object)
    );
  });

  it('creates a root folder without a parent folder ID', () => {
    surveyAssetApiStub.createFolder.mockReturnValue(of({ assetId: 'folder-root' }));
    gridServiceStub.viewUpdatedAt.set('/survey/my-assets/folder/existing', 123);

    component.onCreateFolderSave({ title: 'Root folder' });

    expect(surveyAssetApiStub.createFolder).toHaveBeenCalledWith('Root folder', undefined);
    expect(gridServiceStub.viewUpdatedAt.has('/survey/my-assets/folder/existing')).toBe(false);
    expect(gridServiceStub.viewUpdatedAt.get(router.url)).toBe(component.lastUpdated());
    expect(component.showRefreshButton()).toBe(false);
  });

  it('navigates to select panelist', () => {
    const navigateSpy = vi.spyOn(router, 'navigate');
    const resetStateSpy = vi.spyOn(surveyCommonService, 'resetState');

    component.navigateToSelectPanelist();

    expect(resetStateSpy).toHaveBeenCalledTimes(1);
    expect(navigateSpy).toHaveBeenCalledWith(['/survey/select-panelist']);
    expect(navigateSpy).toHaveBeenCalledTimes(1);
  });

  it('navigates to aiflow flow', () => {
    const navigateSpy = vi.spyOn(router, 'navigate');
    const resetStateSpy = vi.spyOn(surveyCommonService, 'resetState');

    component.navigateToAiflow();

    expect(resetStateSpy).toHaveBeenCalledTimes(1);
    expect(navigateSpy).toHaveBeenCalledWith(['/survey/aiflow/select-panelist']);
    expect(navigateSpy).toHaveBeenCalledTimes(1);
  });

  it('dispatches cancel action on destroy', () => {
    component.ngOnDestroy();

    expect(storeDispatchSpy).toHaveBeenCalledTimes(1);
    const dispatchedAction = storeDispatchSpy.mock.calls[0][0] as { type: string };
    expect(dispatchedAction.type).toBe('CANCEL_REQUEST');
  });
});
