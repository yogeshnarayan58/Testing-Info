import test from "@playwright/test";
import {
  findDataSetByName,
  hasPivotInDimensionSelections,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import localizationData from "./test-data/localization-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { ConfigurePanel } from "../../../common/pages/configure-panel/configure-panel";
import * as noDataTestData from "./test-data/no-data-test-data.json";
import { ReportPage } from "../../../common/pages/report-page/report-page";
import { RollingPurchaseDrivers } from "./rolling-purchase-drivers";
import prodTestData from "./test-data/prod-test-data.json";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;

const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Purchase";

  test.describe("Rolling purchase drivers purchase pivot", async () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;
    let formatPanel: FormatPanel;

    test.beforeAll(() => {
      const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
      if (!isValidTestData) {
        console.warn('Skipping tests as the required pivot test data is not present');
      }
      test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
    });

    test(
      "QuickLook: Should display correct preview information when template is selected",
      {
        tag: "@QuickLook",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        let landingPage = new LandingPage(basePage);
        await landingPage.navigateToUrl(config.BASE_URL);
        await landingPage.clickAnalyseMyData();
        await landingPage.clickChooseATemplate();
        let chooseAtemplatePage = new ChooseAtemplatePage(
          landingPage.getBasePage()
        );
        await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
        await chooseAtemplatePage.hoverThumbnailBySrc(
          testData.common.thumbnailSrc
        );
        await chooseAtemplatePage.clickQuickLookInfoButton();
        let quickLookPage = new QuickLookPage(
          chooseAtemplatePage.getBasePage()
        );
        const previewDescriptionValue = await quickLookPage.getPreviewDescription();
        assert(previewDescriptionValue).toBe(localeData.description);
        const themesValue = await quickLookPage.getPreviewThemes();
        assertionData.common.themes.forEach((expectedTheme: string) => {
          assert(themesValue).toContain(expectedTheme);
        });
        const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
        assertionData.common.dataSets.forEach((expectedDataset: string) => {
          assert(previewDatasetsValue).toContain(expectedDataset);
        });
      }
    );

    test(
      "Insights Panel: Should validate business questions and report metadata",
      {
        tag: "@Insights",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        const insightsPanel = new InsightsPanel(basePage);
        await insightsPanel.navigateToUrl(reportUrl);
        await insightsPanel.clickInsightsIcon();
        const isTitleVisible =
          await insightsPanel.isReportInsightsTitleVisible();
        assert(isTitleVisible).toBeTruthy();
        const isCloseIconVisible =
          await insightsPanel.isReportInsightsPanelCloseIconVisible();
        assert(isCloseIconVisible).toBeTruthy();
        const insightsReportTitle =
          await insightsPanel.getInsightsReportTitle();
        assert(insightsReportTitle?.trim()).toBe(localeData.title);
        const description = await insightsPanel.getInsightsPanelDescription();
        assert(description?.trim()).toBe(localeData.description);
        const isBusinessTitleVisible =
          await insightsPanel.isBusinessQuestionsTitleVisible();
        assert(isBusinessTitleVisible).toBeTruthy();
        await insightsPanel.validateBusinessQuestions(
          localeData.businessQuestions
        );
        await insightsPanel.closeInsightsPanel();
      }
    );

    test(
            "Validate People prompt",
            {
              tag: "@PeopleDialog",
            },
            async () => {
              let basePage = await BasePageFactory.createBasePage();
              dataSelector = new DataSelector(basePage);
              await dataSelector.navigateToUrl(reportUrl);
        
              await dataSelector.clickAdditionalPromptEllipsisIcon();
              await dataSelector.clickMadlibDimension("People");
              await dataSelector.removeSelections();
              await dataSelector.clickMadlibDimension("peopleAddGroupButton");
        
              // // Open the dropdown and assert main menu options
              await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
              await dataSelector.assertPeopleMenuOptions(
                reportAssertData["dataSummary"]["people"]["menu"]
              );
        
              // Assert submenu options (re-open the closed dropdown)
              await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
              await dataSelector.assertPeopleSubMenuOptions(
                reportAssertData["dataSummary"]["people"]["menu"]
              );
        
              // Assert menu info options (re-open the closed dropdown)
              await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
              await dataSelector.assertPeopleMenuInfoOptions(
                reportAssertData['dataSummary']['people']['menu']
              );
        
              await dataSelector.peopleDialogClose();
            }
          );

    test(
      "Madlib Validation: Should validate madlib text content matches expected pattern",
      {
        tag: "@MadlibValidation",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(reportUrl);
        let commonBasePage = commonTestCase.getBasePage();
        dataSelector = new DataSelector(commonBasePage);

        // Open additional prompts to ensure madlib is visible
        // await dataSelector.clickAdditionalPromptEllipsisIcon();

        // Validate using pattern matching with detailed results
        if (localeData.pivotMadlibText) {
          // Get the actual madlib text
          const actualMadlibText = await dataSelector.getMadlibText();
          const expectedMadlibText = (localeData.pivotMadlibText as any).purchase;

          console.log("Actual Madlib Text:", actualMadlibText);
          console.log("Expected Pattern:", expectedMadlibText);

          // Use toMatch for clearer error messages showing exact mismatch
          assert(actualMadlibText).toMatch(
            new RegExp(expectedMadlibText, "i")
          );

          console.log(
            " Madlib validation passed for locale:",
            localeData.locale
          );
        } else {
          console.warn(
            `No madlib text pattern defined for locale: ${localeData.locale}`
          );
        }
      }
    );

    test(
      "Validate default format panel",
      {
        tag: "@FormatPanelDefaultVerification",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(reportUrl);
        formatPanel = new FormatPanel(basePage);
        await formatPanel.openFormatPanel();
        await formatPanel.testDefaultFormatPanel(
          reportAssertData["formatPanel"]["default"]
        );
        await formatPanel.closeFormatPanel();
      }
    );

    test(
      "Validate Configure Panel",
      {
        tag: "@configurepanel",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(reportUrl);

        // Get the basePage from commonTestCase to pass to ConfigurePanel
        let commonBasePage = commonTestCase.getBasePage();
        let configurePanel = new ConfigurePanel(commonBasePage);

        // Step 1: Open configure panel
        await configurePanel.openConfigurePanel();

        // Step 2: Validate default breakdown selection from assertion data
        await configurePanel.validateRadioOptions(
          reportAssertData["configurePanel"]["breakDown"]["options"],
          reportAssertData["configurePanel"]["breakDown"]["defaultSelection"],
          "Breakdown"
        );

        // Step 2: Validate default Change Type selection from assertion data
        await configurePanel.validateRadioOptions(
          reportAssertData["configurePanel"]["changeType"]["options"],
          reportAssertData["configurePanel"]["changeType"]["defaultSelection"],
          "Change Type"
        );

        // TODO: Validate chart legends after configuration change
      }
    );

    test(
      "Validate the pivot selection",
      {
        tag: "@Pivot List Verification",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        dataSelector = new DataSelector(basePage);
        await dataSelector.navigateToUrl(reportUrl);
        await dataSelector.assertPivotDropdown(
          reportAssertData["dataSummary"]["pivot"]["pivotList"]
        );
      }
    );

    test.describe.serial(
      "Run, PPT Export, Excel Export",
      { tag: ["@Report_E2E_Flow"] },
      () => {
        test(
          "Report Generation: Validates dimension selection and successful execution",
          {
            tag: "@RunReport",
          },
          async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            
            const purchasePivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
            if (!purchasePivotData) {
              throw new Error("Pivot not found in test data: Product");
            }
            // Use the common method
            const result = await runReportWithData(purchasePivotData, reportUrl);
            savedReportTitle = result.savedReportTitle;
            savedReportUrl = result.savedReportUrl;
          }
        );

        test(
          "Validate FullScreen",
          {
            tag: "@ValidateFullScreen",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.fullScreenView();
            // TODO: add assertions specific to full-screen behavior (report-specific checks)
          }
        );

        test(
          "Validate presentationMode",
          {
            tag: "@PresentationMode",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.presentationMode();
            // TODO: add assertions specific to presentation mode (report-specific checks)
          }
        );

        test(
          "Validate PPT export",
          {
            tag: "@ValidatePPTExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
          }
        );

        test(
          "Validate Excel export",
          {
            tag: "@ValidateExcelExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality(
              "Excel",
              "Editable objects",
              "Separately"
            );
          }
        );

        test("Validate snapshot", { tag: "@Snapshot" }, async () => {
          test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

          let basePage = await BasePageFactory.createBasePage();
          const commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
          await snapshot.waitForReportRunCompletion();
          await snapshot.clickSaveIcon();
          await snapshot.clickSnapshotIcon();
          console.log('Snapshot clicked');
          assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
          await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
          let snapshotUrl: string = await snapshot.shiftingToSnapshot();
          console.log('Snapshot shifted to right:', snapshotUrl);
          // TODO: add assertions specific to this report's snapshot (report-specific checks)
        });

        test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
          test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');
          let basePage = await BasePageFactory.createBasePage();
          let findMyStuff = new FindMyStuff(basePage);
          await findMyStuff.navigateToUrl(config.BASE_URL);
          await findMyStuff.clickFindMyStuff();
          await findMyStuff.openCurrentReportFMS(savedReportTitle);
  
          console.log("FMS execution successful");
        })

        test(
          "Validate Add Blank Report",
          {
            tag: "@ValidateAddBlankReport",
          },
          async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);

            // Make a copy of the current report
            const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

            // Create a new CommonTestCase for the new report flow  
            let newBasePage = await BasePageFactory.createBasePage();
            let newCommonTestCase = new CommonTestCase(newBasePage);

            // Navigate to the new URL using CommonTestCase
            await newCommonTestCase.navigateToReportUrl(newUrl);

            // Create ReportFlowPage with the same base page
            let reportFlowPage = new ReportFlowPage(newBasePage);

            // Test the correct workflow: Add Menu -> Add Blank Report
            await reportFlowPage.clickAddMenuIcon();

            // Wait briefly for dropdown to appear
            await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);

            // Validate all three dropdown options are present
            await reportFlowPage.validateAddMenuDropdownOptions();

            // Click "Add blank report" option directly from dropdown
            await reportFlowPage.clickAddBlankReportOption();

            // Wait for blank report to be created
            await reportFlowPage.waitForBlankReportIndicator();

            // Validate that blank report was created successfully
            await reportFlowPage.validateBlankReportCreation();

            // Validate that the report title shows 'Untitled'
            await reportFlowPage.validateUntitledReportTitle();

            // Run the complete blank report workflow (dataset selector, apply dataset, madlib selections, and report execution)
            await reportFlowPage.runBlankReport(config.DATASET);

            // Switch back to the original report tab
            await reportFlowPage.clickReportByName(newReportTitle);

            // Wait for the madlib to stabilize and validate it's loaded properly
            const dataSelector = new DataSelector(newBasePage);
            await dataSelector.waitForMadlibStability();
            const madlibText = await dataSelector.getMadlibText();

            // Assert that madlib text is not empty and contains expected content
            assert(madlibText.length).toBeGreaterThan(0);
          }
        );
      }
    );
  });

  test(
    "No data report run",
    {
      tag: "@NoDataRun",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      console.log("Starting report execution");

      const noDataDataset = findDataSetByName(noDataTestData, config.DATASET);
      const noDataReportUrl = config.BASE_URL + noDataDataset?.navUrlWithDataSetId;

      // Extract pivot data correctly (same as done in successful test)
      const purchasePivotData = getDimensionSelectionsByPivot(pivot, noDataDataset);
      if (!purchasePivotData) {
        throw new Error(`Pivot not found in test data: Purchase`);
      }

      // call the common method for report run (data);
      const result = await runReportWithData(purchasePivotData, noDataReportUrl);

      console.log("Report execution completed, validating no-data banner");

      // Assertion for no data banner
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(result.savedReportUrl);

      console.log("Waiting for saved report page to load");
      await commonTestCase.waitForReportRunCompletion(); // Wait for report to render completely

      let commonBasePage = await commonTestCase.getBasePage();
      let reportPage = new ReportPage(commonBasePage);

      let reportPageRPD = new RollingPurchaseDrivers(commonBasePage);

      console.log("Proceeding with no-data element validation for chart");
      const containerParentElement = reportPageRPD.resourceManager.getResource("reportContainerTag");
      await reportPage.assertNoDataFoundByParentElement(containerParentElement);
    }
  );


async function runReportWithData(testData: any, reportUrl: string): Promise<{ savedReportTitle: string, savedReportUrl: string }> {
  let basePage = await BasePageFactory.createBasePage();
  let commonTestCase = new CommonTestCase(basePage);
  await commonTestCase.navigateToReportUrl(reportUrl);

  let commonBasePage = commonTestCase.getBasePage();
  let dataSelector = new DataSelector(commonBasePage);

  // Set all dimension selections
  await dataSelector.clickAdditionalPromptEllipsisIcon();
  await dataSelector.waitForMadlibStability();

  await dataSelector.clickMadlibDimension("Facts");
  await dataSelector.selectClosedDropdown(testData["Facts"]["selections"]);

  await dataSelector.clickMadlibDimension("Geography");
  await dataSelector.setMadlibSelection(testData["Geography"]
  );

  await dataSelector.clickMadlibDimension("Products");
  await dataSelector.setMadlibSelection(testData["Products"]
  );
  await dataSelector.clickMadlibDimension("Retailers");
  await dataSelector.setMadlibSelection(testData["Retailers"]
  );

  await dataSelector.clickMadlibDimension("Periods");
  await dataSelector.setPeriodMadlibSelection(testData["Periods"]
  );

  await dataSelector.clickMadlibDimension("Demography");
  await dataSelector.setMadlibSelection(testData["Demography"]
  );

  await dataSelector.clickMadlibDimension("People");
  await dataSelector.checkPeopleSelectionGroupExists();
  await dataSelector.clickMadlibDimension("peopleAddGroupButton");
  await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
  await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
  for (const selection of testData["People"]
    .selections) {
    await dataSelector.handlePeopleMenuOptions(selection);
  }

  // Execute report
  let dsBasePage = await dataSelector.getBasePage();
  commonTestCase = new CommonTestCase(dsBasePage);
  await commonTestCase.clickRunButton();
  await commonTestCase.waitForReportRunCompletion();

  console.log("Report execution successful");
  const { newReportTitle, newUrl } = await commonTestCase.saveReport();

  console.log("savedReportTitle:", newReportTitle);
  console.log("savedReportUrl:", newUrl);

  return {
    savedReportTitle: newReportTitle,
    savedReportUrl: newUrl
  };
}
