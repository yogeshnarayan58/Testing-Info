// Mock for @nielseniq/token library
export const tokens = {};
export default {};
