import { BasePage, WebActions } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { ELEMENT_WAIT_TIMEOUT, SMALL_TIMEOUT, MEDIUM_TIMEOUT, NAVIGATION_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';
import startWithPromptPageResources from '../../locators/survey/start-with-prompt.locator.json';
import { searchAndSelectDataset as searchAndSelectDatasetHelper } from '../common/dataset-selection.helper';

const START_WITH_PROMPT_PAGE_COMPONENT_NAME = 'startWithPromptPage';

export const OMNISHOPPER_OFFERING_DATA_TEST_ID = 'rv-dataset-type-selector1';

export class StartWithPromptPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      START_WITH_PROMPT_PAGE_COMPONENT_NAME,
      startWithPromptPageResources
    );
  }

  /** Throws (unlike `waitFor()`, which does not throw on timeout in this framework) if `element` isn't visible within `timeoutMs`. */
  private async waitUntilVisible(
    element: ReturnType<WebActions['getWebElement']>,
    what: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT
  ): Promise<void> {
    if (!(await element.isVisible(timeoutMs))) {
      throw new Error(`${what} not visible after ${timeoutMs}ms`);
    }
  }

  private getResource(name: string) {
    return this.resourceManager.getResource(name, START_WITH_PROMPT_PAGE_COMPONENT_NAME);
  }

  /** Races `action` against `timeoutMs` (hover/click have no native timeout param in this framework - see
   *  surveyBuilder.page.ts's withTimeout for the confirmed cause) so an occluded/unreachable element fails
   *  fast with a clear step name instead of hanging until the suite timeout. */
  private async withTimeout<T>(action: Promise<T>, timeoutMs: number, step: string): Promise<T> {
    let timer!: ReturnType<typeof setTimeout>;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${step} timed out after ${timeoutMs}ms`)), timeoutMs);
    });
    try {
      return await Promise.race([action, timeoutPromise]);
    } finally {
      clearTimeout(timer);
    }
  }

  async clickStartWithPrompt(): Promise<void> {
    try {
      const startWithPrompt = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('startWithPrompt', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await startWithPrompt.waitFor(SMALL_TIMEOUT);
      await startWithPrompt.click();
    } catch (error) {
      throw new Error(`Failed to click Start with a prompt: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDatasetTypeSelectorVisible(index = 0): Promise<boolean> {
    try {
      const datasetTypeSelector = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('datasetTypeSelector', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeSelector.waitFor(SMALL_TIMEOUT);
      return datasetTypeSelector.isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check dataset type selector visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectDatasetType(offeringDataTestId: string): Promise<void> {
    try {
      const datasetTypeOption = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('omnishopperOfferingTile', offeringDataTestId, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await datasetTypeOption.waitFor(SMALL_TIMEOUT);

      const tileClass = await datasetTypeOption.getAttribute('class').catch(() => null);
      const isAlreadySelected = (tileClass ?? '').includes('dataset-type-wrapper-selected');
      if (!isAlreadySelected) {
        await datasetTypeOption.click();
      }

      const nextDatasetButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('nextDatasetButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await nextDatasetButton.waitFor(SMALL_TIMEOUT);
      await nextDatasetButton.click();
    } catch (error) {
      throw new Error(`Failed to select dataset type "${offeringDataTestId}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async searchAndSelectDataset(searchTerm: string, datasetLabel: string): Promise<boolean> {
    try {
      return await searchAndSelectDatasetHelper(
        this.webActionHandler,
        this.resourceManager,
        START_WITH_PROMPT_PAGE_COMPONENT_NAME,
        searchTerm,
        datasetLabel,
        {
          datasetResourceKey: 'datasetByText',
          searchToggleResourceKey: 'datasetSearchToggle',
          searchInputResourceKey: 'datasetSearchInput'
        }
      );
    } catch (error) {
      throw new Error(`Failed to search and select dataset "${datasetLabel}": ${error instanceof Error ? error.message : error}`);
    }
  }

  async applyDataset(): Promise<void> {
    try {
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const applyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('applyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();

      const dialogElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dialogElement', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );

      const isChooseViewDialogShown = await dialogElement.isVisible(SMALL_TIMEOUT).catch(() => false);
      if (!isChooseViewDialogShown) {
        return;
      }

      await dialogElement.waitFor(SMALL_TIMEOUT);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();
    } catch (error) {
      throw new Error(`Failed to apply dataset: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillPromptAndGenerate(promptText: string): Promise<void> {
    try {
      const promptTextarea = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('promptTextarea', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await promptTextarea.waitFor(SMALL_TIMEOUT);
      await promptTextarea.enterText(promptText);

      const generateSurveyButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('generateSurveyButton', START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await generateSurveyButton.waitForEnabled(ELEMENT_WAIT_TIMEOUT);
      await generateSurveyButton.click();
    } catch (error) {
      throw new Error(`Failed to fill prompt and generate survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Reads the slider's numeric readout is not confirmed in source (athena-core `niq-slider` is a third-party component) —
   * drags are not performed here; callers only read `isQuestionCountOutOfRange()`'s error via `isQuestionCountErrorVisible()`. */
  async isQuestionCountErrorVisible(): Promise<boolean> {
    try {
      const errorMessage = this.webActionHandler.getWebElement(this.getResource('questionCountError'));
      return await errorMessage.isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check question-count error visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickGenerateQuestions(): Promise<void> {
    try {
      const generateButton = this.webActionHandler.getWebElement(this.getResource('generateQuestionsButton'));
      await this.waitUntilVisible(generateButton, 'Generate questions button');
      await generateButton.click();
    } catch (error) {
      throw new Error(`Failed to click Generate questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_AI_04 — `questionTypeOption` tile on the Customize Questions screen (question-generator.html's
   *  `survey-question-type-list [mode]="'multi'"`), identified by its QuestionType value (e.g. 'SINGLE_CHOICE'). */
  async selectQuestionType(value: string): Promise<void> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(tile, `Question type tile (${value})`);
      await this.withTimeout(tile.click(), ELEMENT_WAIT_TIMEOUT, `Click question type tile (${value})`);
    } catch (error) {
      throw new Error(`Failed to select question type "${value}": ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_AI_04 — question-type-list.component.ts's `selectQuestionType` toggles in `multi` mode (clicking an
   *  already-selected tile deselects it), and SINGLE_CHOICE/MULTIPLE_CHOICE/STAR_RATING are pre-selected via
   *  `DefaultQuestionTypes` (build-survey.ts), so this only clicks tiles not already in the desired state. */
  async setQuestionTypeSelected(value: string, desired: boolean): Promise<void> {
    if ((await this.isQuestionTypeSelected(value)).selected !== desired) {
      await this.selectQuestionType(value);
    }
  }

  /** TC_AI_04 — DEV evidence: niq-button host reflects selection as the exact "active" CSS class token
   *  (`[state]="active"` input doesn't surface as a `state` attribute on DEV), not a `state` attribute. */
  async isQuestionTypeSelected(value: string): Promise<{ selected: boolean; outerHtml: string }> {
    try {
      const tile = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('questionTypeOption', value, START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      const classAttr = (await tile.getAttribute('class')) ?? '';
      const outerHtml = String(await tile.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { selected: classAttr.split(/\s+/).includes('active'), outerHtml };
    } catch (error) {
      throw new Error(`Failed to check question type "${value}" selected state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_AI_11 — Generate-more/Describe share isAtMaxQuestions() gating with Add Question/Duplicate
   *  (preview-mode.component.html); same `state`/`aria-disabled`/`niqtooltip` attribute-reflection convention. */
  private async getDisabledState(resourceName: string): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    const button = this.webActionHandler.getWebElement(this.getResource(resourceName));
    const state = await button.getAttribute('state');
    const ariaDisabled = await button.getAttribute('aria-disabled');
    const tooltip = await button.getAttribute('niqtooltip');
    const outerHtml = String(await button.executeScript((e) => e.outerHTML)).slice(0, 400);
    return { disabled: state === 'disabled' || ariaDisabled === 'true', tooltip, outerHtml };
  }

  async getGenerateMoreQuestionsDisabledState(): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    try {
      return await this.getDisabledState('suggestNewQuestionsButton');
    } catch (error) {
      throw new Error(`Failed to get Generate-more-questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getDescribeQuestionsDisabledState(): Promise<{ disabled: boolean; tooltip: string | null; outerHtml: string }> {
    try {
      return await this.getDisabledState('repromptNewQuestionsButton');
    } catch (error) {
      throw new Error(`Failed to get Describe-questions disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Same `.question-number` marker preview-mode renders per question, used by surveyBuilder.page.ts's getQuestionNumbers().
   * When `atLeast` is given, polls (AI generation is async) until the count reaches it or `timeoutMs` elapses. */
  async getGeneratedQuestionCount(atLeast?: number, timeoutMs: number = NAVIGATION_TIMEOUT): Promise<number> {
    try {
      const readCount = async () => (await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'))).length;
      let count = await readCount();
      if (atLeast === undefined) {
        return count;
      }
      const start = Date.now();
      while (count < atLeast) {
        if (Date.now() - start >= timeoutMs) {
          throw new Error(`Timed out waiting for question count to reach ${atLeast} (current: ${count})`);
        }
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        count = await readCount();
      }
      return count;
    } catch (error) {
      throw new Error(`Failed to get generated question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `.question-actions` (incl. Rephrase with AI) is only revealed via `.question-row`'s (mouseenter) handler — see
   *  preview-mode.component.html:29 — not a CSS :hover. Scope to a single row via nth (same pattern as surveyBuilder.page.ts). */
  private getQuestionRowElement(index: number) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index}`
    });
  }

  /** Hovers question `index`'s row (reveals Rephrase with AI, see getQuestionRowElement), opens the Rephrase
   *  popover, types `promptText`, sends, and waits for the request to finish (loading clears, prompt cleared).
   *  DEV keeps the panel open after a successful rephrase (confirmed via trace) despite the local source setting
   *  `rephraseOpenIndex = null` on success, so there is no panel-closed assertion here. Moves the mouse off the
   *  row afterward so hover state doesn't leak into the next test. */
  async rephraseQuestion(index: number, promptText: string): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await row.hover();

      const rephraseButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('rephraseWithAiButton', String(index), START_WITH_PROMPT_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
      await rephraseButton.click();

      const rephraseInput = this.webActionHandler.getWebElement(this.getResource('rephraseInput'));
      // DEV observed the click occasionally not opening the panel (human click worked) — retry exactly once, never
      // when already open (a second click would close it).
      let panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (!panelOpened) {
        console.warn('rephrase panel did not open after first click, retried');
        await this.webActionHandler.mouseMove(0, 0);
        await row.hover();
        await this.waitUntilVisible(rephraseButton, `Rephrase with AI button (index ${index})`);
        await rephraseButton.click();
        panelOpened = await rephraseInput.isVisible(SMALL_TIMEOUT);
      }
      if (!panelOpened) {
        throw new Error(`Rephrase panel (index ${index}) did not open after retry`);
      }
      await rephraseInput.enterText(promptText);

      const rephraseSendButton = this.webActionHandler.getWebElement(this.getResource('rephraseSendButton'));
      await this.waitUntilVisible(rephraseSendButton, `Rephrase send button (index ${index})`);

      // UNKNOWN: no response/network-wait API is exposed by this page object's BasePage/WebActions/WebElement
      // (@gfk/gta keeps the Playwright `page` private, no waitForResponse-style method) — cannot register a
      // response wait before clicking send without guessing an API, so send is followed only by the UI waits below.
      await rephraseSendButton.click();

      const rephraseSendLoading = this.webActionHandler.getWebElement({
        elementName: 'rephraseSendLoading',
        selectorType: 'css',
        selectorValue: '.rephrase-send-loading'
      });
      // waitFor() never throws on timeout (swallows and logs) — isHidden() is a real instant check (unlike
      // isVisible(0), where a 0 timeout tells Playwright to wait forever, not "check now" — that's what caused
      // the 2.2-minute hang) so we use it to confirm state and throw ourselves.
      await rephraseSendLoading.waitFor(ELEMENT_WAIT_TIMEOUT, 'hidden');
      if (!(await rephraseSendLoading.isHidden())) {
        throw new Error(`Rephrase send button (index ${index}) stayed in loading state after ${ELEMENT_WAIT_TIMEOUT}ms`);
      }

      await this.webActionHandler.mouseMove(0, 0); // move off the row so the hover doesn't linger into the next test

      // DEV shows both states after a successful rephrase (panel open with an empty box, or panel gone) — only
      // fail if the box is still visible AND still has text. `isVisible(SMALL_TIMEOUT)` bounds this read so a
      // closed panel (getValue() has no timeout param and would otherwise hang) is never queried.
      const panelStillOpen = await rephraseInput.isVisible(SMALL_TIMEOUT);
      if (panelStillOpen) {
        const promptValue = await rephraseInput.getValue();
        if (promptValue !== '') {
          throw new Error(`Rephrase prompt input (index ${index}) was not cleared after submit, value: "${promptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to rephrase question ${index}: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSuggestNewQuestions(): Promise<void> {
    try {
      const suggestButton = this.webActionHandler.getWebElement(this.getResource('suggestNewQuestionsButton'));
      await this.waitUntilVisible(suggestButton, 'Suggest new questions (Generate more questions) button');
      await suggestButton.click();
      await suggestButton.waitForEnabled(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to click Suggest new questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Opens "Describe questions to add", types `promptText`, submits, and waits for the panel to close. */
  async describeAndSubmitReprompt(promptText: string): Promise<void> {
    try {
      const repromptButton = this.webActionHandler.getWebElement(this.getResource('repromptNewQuestionsButton'));
      await this.waitUntilVisible(repromptButton, 'Describe questions to add button');
      await repromptButton.click();

      const repromptInput = this.webActionHandler.getWebElement(this.getResource('repromptInput'));
      await this.waitUntilVisible(repromptInput, 'Reprompt input');
      await repromptInput.enterText(promptText);

      const repromptSubmitButton = this.webActionHandler.getWebElement(this.getResource('repromptSubmitButton'));
      await this.waitUntilVisible(repromptSubmitButton, 'Reprompt submit button');
      await repromptSubmitButton.click();

      await repromptInput.waitFor(ELEMENT_WAIT_TIMEOUT, 'hidden');
      // Same tolerant check as rephraseQuestion(): DEV may leave the panel open (empty) or close it after success.
      if (await repromptInput.isVisible(SMALL_TIMEOUT)) {
        const repromptValue = await repromptInput.getValue();
        if (repromptValue !== '') {
          throw new Error(`Reprompt panel did not close or clear after submit, value: "${repromptValue}"`);
        }
      }
    } catch (error) {
      throw new Error(`Failed to describe and submit reprompt: ${error instanceof Error ? error.message : error}`);
    }
  }
}