import { BasePage } from '@gfk/gta';
import { CommonPage } from '../common/common-page';
import { UI_STATE_UPDATE_DELAY, PANEL_TRANSITION_DELAY } from '../../constants/timeout-constants';
import surveyBuilderPageResources from '../../locators/survey/surveyBuilder.json';

const SURVEY_BUILDER_PAGE_COMPONENT_NAME = 'surveyBuilderPage';

/**
 * SurveyBuilderPage — covers the "Build Survey" screen: adding questions of each
 * type (TC_BS_03–TC_BS_09), review mode (part of TC_BS_13), and save/publish
 * (TC_BS_16).
 *
 * IMPORTANT ASSUMPTIONS / UNCONFIRMED ITEMS (verify against live DOM before
 * trusting these in CI):
 *
 * 1. `optionInputByLabel`/row/column inputs are resolved by role name + `nth=0`,
 * NOT scoped to a specific question. This only works reliably for the question
 * currently expanded/being edited (i.e. call these methods for one question at
 * a time, right after adding it, before adding the next). Once a question
 * collapses (per TC_BS_03 step 4), do not attempt to edit its options via
 * these methods — no locator has been confirmed for re-opening a collapsed
 * question yet.
 * 2. `requiredToggle` ([data-test-id='-input-checkbox']) is UNCONFIRMED — the
 * Codegen capture showed this exact truncated id with no real prefix, which is
 * suspicious. Do not rely on it without a live DOM check.
 * 3. Point Scale's "+ Row"/"+ Column" buttons are UNCONFIRMED per TC_BS_08 — the
 * manual test case itself flags this as unverified. addRowToQuestion() /
 * addColumnToQuestion() are shared with Multi Scale (which IS confirmed per
 * TC_BS_09) — if Point Scale doesn't actually expose these, calling them there
 * will fail and that's expected until confirmed.
 * 4. No locator exists yet for the "Text" question type (TC_BS_06) — it was never
 * exercised in the Codegen capture. addTextQuestion() is NOT implemented here;
 * add it once a locator is confirmed.
 * 5. "Publish" is confirmed by the dev team (TC_BS_14, TC_BS_16) to currently be a
 * no-op with no validation. publishSurvey() below only performs the click —
 * callers should NOT assert a "published" outcome until backend support ships.
 */
export class SurveyBuilderPage extends CommonPage {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      SURVEY_BUILDER_PAGE_COMPONENT_NAME,
      surveyBuilderPageResources
    );
  }

  // ---------------------------------------------------------------------
  // Question type selection
  // ---------------------------------------------------------------------

  private async clickQuestionTypeResource(resourceName: string): Promise<void> {
    const typeButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(resourceName, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await typeButton.waitFor();
    await typeButton.click();
  await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
 }
 // Shared field helpers (operate on the currently expanded/editing question)


  private async fillQuestionText(questionIndex: number, text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('questionTextInput', String(questionIndex), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await questionText.waitFor();
    await questionText.enterText(text);
  }

  /** Fills Option N / Row N / Column N fields by their visible role label, e.g. 'Option 1', 'Row 2'. */
  private async fillLabeledField(label: string, value: string): Promise<void> {
    const field = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('optionInputByLabel', label, SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await field.waitFor();
    await field.enterText(value);
  }

  async addOptionToQuestion(): Promise<void> {
    const addOption = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addOptionButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addOption.waitFor();
    await addOption.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** UNCONFIRMED for Point Scale — see class-level comment #3. */
  async addRowToQuestion(): Promise<void> {
    const addRow = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addRowButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addRow.waitFor();
    await addRow.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** UNCONFIRMED for Point Scale — see class-level comment #3. */
  async addColumnToQuestion(): Promise<void> {
    const addColumn = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addColumnButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addColumn.waitFor();
    await addColumn.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /** UNCONFIRMED locator — see class-level comment #2. Do not rely on this without a live DOM check. */
  async toggleRequired(): Promise<void> {
    const toggle = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('requiredToggle', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await toggle.waitFor();
    await toggle.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async clickAddQuestion(): Promise<void> {
    const addQuestion = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addQuestionLink', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await addQuestion.waitFor();
    await addQuestion.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  // ---------------------------------------------------------------------
  // Per-question-type methods (TC_BS_03–TC_BS_09)
  // Each assumes it is called right after clickAddQuestion() (or for
  // question 1, right after landing on Build Survey), while this question
  // is the currently expanded one.
  // ---------------------------------------------------------------------

  /** TC_BS_03 */
  async addSingleChoiceQuestion(questionIndex: number, questionText: string, options: string[]): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeSingleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }
    } catch (error) {
      throw new Error(`Failed to add Single Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_04 */
  async addMultipleChoiceQuestion(questionIndex: number, questionText: string, options: string[]): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeMultipleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.addOptionToQuestion();
        }
        await this.fillLabeledField(`Option ${i + 1}`, options[i]);
      }
    } catch (error) {
      throw new Error(`Failed to add Multiple Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_05 — no question text or options per the manual test case; just adds the type. */
  async addRatingQuestion(): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeRating');
    } catch (error) {
      throw new Error(`Failed to add Rating question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * TC_BS_06 — NOT IMPLEMENTED. No confirmed locator for the "Text" question
   * type exists yet (never exercised in the Codegen capture). Add this once
   * `questionTypeText` is confirmed and added to survey-builder.locator.json.
   */
  // async addTextQuestion(questionIndex: number, questionText: string): Promise<void> { ... }

  /** TC_BS_07 */
  async addNPSQuestion(questionIndex: number, questionText: string): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeNPS');
      await this.fillQuestionText(questionIndex, questionText);
    } catch (error) {
      throw new Error(`Failed to add Net Promoter Score question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * TC_BS_08 — Point Scale. Row/column add buttons are UNCONFIRMED (see
   * class-level comment #3); only pass extraRows/extraColumns if you have
   * verified "+ Row"/"+ Column" exist for this question type.
   */
  async addPointScaleQuestion(
    questionIndex: number,
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypePointScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion(); // UNCONFIRMED for Point Scale
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion(); // UNCONFIRMED for Point Scale
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
    } catch (error) {
      throw new Error(`Failed to add Point Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** TC_BS_09 — Multi Scale, including add-row/add-column (confirmed real per Codegen + TC_BS_09). */
  async addMultiScaleQuestion(
    questionIndex: number,
    questionText: string,
    rows: string[],
    columns: string[]
  ): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeMultiScale');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < rows.length; i++) {
        if (i >= 2) {
          await this.addRowToQuestion();
        }
        await this.fillLabeledField(`Row ${i + 1}`, rows[i]);
      }
      for (let i = 0; i < columns.length; i++) {
        if (i >= 2) {
          await this.addColumnToQuestion();
        }
        await this.fillLabeledField(`Column ${i + 1}`, columns[i]);
      }
    } catch (error) {
      throw new Error(`Failed to add Multi Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  // ---------------------------------------------------------------------
  // Review mode (part of TC_BS_13; select/reorder indices per Codegen —
  // NOT independently confirmed against a clean manual flow)
  // ---------------------------------------------------------------------

  async openReviewMode(): Promise<void> {
    const reviewButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('reviewSurveyButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await reviewButton.waitFor();
    await reviewButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  async selectQuestionForReview(index: number): Promise<void> {
    const questionCheckbox = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await questionCheckbox.waitFor();
    await questionCheckbox.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async deleteSelectedQuestions(): Promise<void> {
    const deleteButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('deleteQuestionsButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await deleteButton.waitFor();
    await deleteButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async exitReviewMode(): Promise<void> {
    const exitButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('exitReviewModeButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await exitButton.waitFor();
    await exitButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  // ---------------------------------------------------------------------
  // Survey name, save, publish (TC_BS_02, TC_BS_16)
  // ---------------------------------------------------------------------

  /** TC_BS_02 */
  async setSurveyTitle(title: string): Promise<void> {
    try {
      const editIcon = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('editSurveyNameIcon', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await editIcon.waitFor();
      await editIcon.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const titleInput = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('surveyTitleInput', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await titleInput.waitFor();
      await titleInput.enterText(title);
    } catch (error) {
      throw new Error(`Failed to set survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * Save as draft, per TC_BS_16 step 2. Exact confirmation behavior after
   * clicking is NOT independently verified — this only performs the click;
   * callers should not assert a specific success indicator until confirmed.
   */
  async saveDraft(): Promise<void> {
    const saveDraftButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('saveDraftButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await saveDraftButton.waitFor();
    await saveDraftButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /**
   * PUBLISH IS CONFIRMED NON-FUNCTIONAL (TC_BS_14, TC_BS_16 — dev team
   * confirmed no-op, backend not implemented). This method only performs
   * the click for future-readiness; do NOT assert a "published" outcome
   * from it until the backend ships.
   */
  async publishSurvey(): Promise<void> {
    const publishButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('publishSurveyButton', SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await publishButton.waitFor();
    await publishButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }
}