import { TranslateModule, TranslateService } from '@ngx-translate/core';
import type { GridResponse, QuestionChartContext, QuestionChartPreview } from '../../models/question-result';
import { RESULTS_DASHBOARD_CHART_TYPE_VALUES, RESULTS_DASHBOARD_SEGMENT_VALUES } from '../../models/survey-results';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal } from '@angular/core';
import { QuestionTypes } from '../../../build-survey/models/build-survey';
import { GridComponent } from '../grid/grid.component';
import { NiqHighchartBarChartComponent, NiqHighchartColumnChartComponent, NiqHighchartPieChartComponent } from '@nielseniq/athena-charts';
import { QuestionChartPreviewService } from '../../services/question-chart-preview.service';
import { switchMap, timer } from 'rxjs';
import Highcharts from 'highcharts';
import GroupedCategories from 'highcharts-grouped-categories';

GroupedCategories(Highcharts);

@Component({
  selector: 'survey-question-chart',
  standalone: true,
  imports: [TranslateModule, GridComponent, NiqHighchartBarChartComponent, NiqHighchartColumnChartComponent, NiqHighchartPieChartComponent],
  templateUrl: './question-chart.component.html',
  styleUrl: './question-chart.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QuestionChartComponent {
  private readonly translate = inject(TranslateService);
  readonly chartTypes = RESULTS_DASHBOARD_CHART_TYPE_VALUES;
  readonly chartType = input.required<string>();
  readonly displayMode = input<string>(RESULTS_DASHBOARD_SEGMENT_VALUES.percentage);
  readonly title = input.required<string>();
  readonly context = input.required<QuestionChartContext>();
  readonly showSupplementaryGridOverride = input<boolean | undefined>(undefined);
  readonly showSupplementaryGrid = computed(() => this.showSupplementaryGridOverride() ?? this.context().question.type !== QuestionTypes.StarRating);
  readonly chart = signal<QuestionChartPreview | null>(null);
  readonly normalGrid = signal<GridResponse | null>(null);
  readonly gridError = signal('');
  readonly loading = signal(false);
  readonly error = signal('');
  private readonly source = inject(QuestionChartPreviewService);

  // Reload the chart when its inputs change.
  constructor() {
    effect(onCleanup => {
      const type = this.chartType();
      const questionType = this.context().question.type;
      this.normalGrid.set(null);
      this.gridError.set('');
      if (type === this.chartTypes.heatmap || !this.showSupplementaryGrid()) return;
      const subscription = this.source.loadGrid(questionType).subscribe({
        next: grid => this.normalGrid.set(grid),
        error: () => this.gridError.set(this.translate.instant('SURVEYMOD_UNABLE_LOAD_TABLE')),
      });
      onCleanup(() => subscription.unsubscribe());
    });
    effect(onCleanup => {
      const type = this.chartType();
      const questionType = this.context().question.type;
      this.chart.set(null);
      this.error.set('');
      this.loading.set(true);
      const subscription = timer(300).pipe(
        switchMap(() => this.source.load(type, questionType)),
      ).subscribe({
        next: chart => { this.chart.set(chart); this.loading.set(false); },
        error: error => { this.error.set(error instanceof Error ? error.message : this.translate.instant('SURVEYMOD_UNABLE_LOAD_CHART')); this.loading.set(false); },
      });
      // Cancel the old load when inputs change or the chart is removed.
      onCleanup(() => subscription.unsubscribe());
    });
  }
}

