export let mockValuesMultiCharPayload = {
  "cpfContext": {
    "applicationId": "7DBC2CC90CAA4982873B693EA59B2B43",
    "componentId": "OMNI_THL_SURVEY_PANEL"
  },
  "requestContext": {
    "datasetId": "155544",
    "dataViewId": "OrderId_4012",
    "datasetStackId": "US"
  },
  "dimension": {
    "id": "FCT"
  },
  "characteristicIds": [
    "FCT_COL_NM",
    "FCT_DSC_LONG"
  ],
  "filter": {
    "objectRefId": "12",
    "join": null,
    "operator": "IN",
    "dataItem": {
      "type": "CHARACTERISTIC_VALUE",
      "id": "FCT_COL_NM"
    },
    "filterBy": "ID",
    "values": [
      "THL_UNIQUE_HOUSEHOLD_COUNT_O",
      "THL_HOUSEHOLD_ID"
    ]
  }
}
