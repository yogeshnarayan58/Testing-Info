import { describe, expect, it } from 'vitest';
import { MY_ASSETS_ROOT, toApiFolderId, toParentFolder, withMyAssetsRoot } from './survey-folder.util';

describe('survey folder hierarchy', () => {
  it('maps the virtual root to an empty API ID and preserves real IDs', () => {
    expect(toApiFolderId(MY_ASSETS_ROOT.assetId)).toBe('');
    expect(toApiFolderId('folder-1')).toBe('folder-1');
    expect(toApiFolderId(undefined)).toBe('');
  });
  it('includes root for an empty account', () => {
    expect(withMyAssetsRoot([])).toEqual([MY_ASSETS_ROOT]);
  });
  it('preserves nested parents without changing API objects', () => {
    const parent = { assetId: 'parent' };
    const child = { assetId: 'child', parentAsset: parent };
    expect(withMyAssetsRoot([parent, child])).toEqual([
      MY_ASSETS_ROOT, { ...parent, parentAsset: MY_ASSETS_ROOT }, child,
    ]);
    expect(parent).not.toHaveProperty('parentAsset');
  });
  it('excludes the UI root ID from folder-creation requests', () => {
    expect(toParentFolder(MY_ASSETS_ROOT)).toBeUndefined();
    const folder = { assetId: 'folder-1' };
    expect(toParentFolder(folder)).toBe(folder);
  });
  it('returns undefined when the parent folder is missing', () => {
    expect(toParentFolder(null)).toBeUndefined();
    expect(toParentFolder(undefined)).toBeUndefined();
  });
});
