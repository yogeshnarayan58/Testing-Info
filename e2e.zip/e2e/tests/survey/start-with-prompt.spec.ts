import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory, closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartWithPromptPage, OMNISHOPPER_OFFERING_DATA_TEST_ID } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { SurveyBuilderPage } from '../../page-objects/common/survey-builder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import {registerEditSurveyTitleTest,registerRequiredStarTest,registerEditQuestionTextTest,
  registerDiscardSaveChangesTest,registerDeleteDuplicateQuestionTest,registerDragDropTest,
  registerCancelAddQuestionTest,registerReviewModeTest,registerReviewModeDeleteAllTest,
  registerEmptyStateTest,registerAddSingleChoiceQuestionTest,registerAddMultipleChoiceQuestionTest,
  registerAddRatingQuestionTest,registerAddNPSQuestionTest,registerAddPointScaleQuestionTest,
  registerAddMultiScaleQuestionTest,registerStepperNavigationTest,registerValidateDisabledUnderThreeTest,
  registerSaveDraftTest,registerValidateSurveyTest,registerOptionBoundaryTest,
  registerDiscardNewQuestionThenSaveTest,registerDeleteLastThenReAddTest,
  registerEmptyQuestionTextBlocksSaveTest,
  registerPublishPopupCancelTest,registerCreateFolderFromPublishPopupTest,
} from './common-test-cases/build-survey-common-test-cases';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Start with a prompt', { tag: '@StartWithPrompt' }, () => {
  let basePage: BasePage;
  let promptPage: StartWithPromptPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'start-with-prompt-video');
    }
  });

  test('Start with a Prompt: Should display the Start with a prompt option on the survey home page', {}, async () => {
    basePage = await BasePageFactory.createBasePage();
    promptPage = new StartWithPromptPage(basePage);

    await promptPage.navigateToSurvey();
    await promptPage.clickStartWithPrompt();

    const isVisible = await promptPage.isDatasetTypeSelectorVisible(0);
    assertTrue(isVisible);
  });

  test('Dataset Selection: Should select the dataset type and dataset', { tag: '@DatasetSelection' }, async () => {
    await promptPage.selectDatasetType(OMNISHOPPER_OFFERING_DATA_TEST_ID);

    const isDatasetSelectionConfirmed = await promptPage.searchAndSelectDataset(datasetConfig.searchTerm, String(DATASET_NAME));
    assertTrue(isDatasetSelectionConfirmed, `Expected dataset selection to succeed for ${DATASET_NAME}`);

    await promptPage.applyDataset();
  });

  test('Panelist Filters: Should set dimension selections and search for panelists', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);
    await selectPanelistPage.clickSearchForPanelists();

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should select a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.click250Responses();
  });

  test(
    'TC_AI_01: Select Panelists shows the Optiq heading, prompt textbox, and disables Generate Survey until prompt is entered',
    { tag: '@GenerateSurvey' },
    async () => {
      assertTrue(await promptPage.isOptiqHeadingVisible(), 'Expected "Let\'s get you started with Optiq!" heading visible');
      assertTrue(await promptPage.isPromptTextareaVisible(), 'Expected the AI prompt textarea visible below the response counts');
      assertTrue(!(await promptPage.isGenerateSurveyEnabled()), 'Expected Generate Survey disabled while the prompt is empty');

      await promptPage.setPromptText('Generate a few questions about product satisfaction');
      assertTrue(await promptPage.waitForGenerateSurveyEnabled(), 'Expected Generate Survey enabled after typing a prompt');

      await promptPage.setPromptText('');
    }
  );

  test('Generate Survey: Should fill the prompt and reach the Build Survey page', { tag: '@GenerateSurvey' }, async () => {
    await promptPage.fillPromptAndGenerate('Generate a few questions about product satisfaction');

    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after generating the survey from a prompt');
  });

  test(
    'TC_AI_04: Should allow selecting multiple question types on the Customize Questions screen',
    { tag: '@GenerateSurvey' },
    async () => {
      const allTypes = [
        'SINGLE_CHOICE',
        'MULTIPLE_CHOICE',
        'STAR_RATING',
        'NET_PROMOTER_SCORE',
        'SINGLE_POINT_SCALE',
        'MULTIPLE_POINT_SCALE',
      ];

      for (const value of allTypes) {
        const { selected, outerHtml } = await promptPage.isQuestionTypeSelected(value);
        assertTrue(selected, `Expected "${value}" to be selected by default (outerHtml="${outerHtml}")`);
      }

      for (const value of allTypes) {
        await promptPage.selectQuestionType(value);
        const { selected, outerHtml } = await promptPage.isQuestionTypeSelected(value);
        assertTrue(!selected, `Expected "${value}" to be de-selected after clicking it (outerHtml="${outerHtml}")`);

        await promptPage.selectQuestionType(value);
        const after = await promptPage.isQuestionTypeSelected(value);
        assertTrue(after.selected, `Expected "${value}" to be re-selected after clicking it again (outerHtml="${after.outerHtml}")`);
      }
    }
  );

  test('TC_AI_05: Generate questions creates AI questions', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.clickGenerateQuestions();
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);

    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    for (let index = 0; index < after; index++) {
      const questionText = await surveyBuilderPage.getQuestionTextDisplay(index);
      assertTrue(questionText.trim() !== '', `Expected generated question at index ${index} to have non-empty text`);
    }
  });

  registerEditSurveyTitleTest(
    { getBasePage: () => basePage },
    { title: 'TC_AI_07: Edit the survey title after AI generation', tag: '@BuildSurvey', expectAiTitle: true }
  );

  test('TC_AI_10: Rephrase with AI clears the loading state and prompt', { tag: '@GenerateSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const normalize = (text: string) => text.replace(/\s+/g, '').replace(/\*$/, '');
    const textBefore0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textBefore1 = await surveyBuilderPage.getQuestionTextDisplay(1);

    await promptPage.rephraseQuestion(0, 'Make this question more concise');

    const textAfter0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textAfter1 = await surveyBuilderPage.getQuestionTextDisplay(1);
    assertTrue(
      normalize(textAfter0) !== normalize(textBefore0),
      `Expected question 0 text to change after rephrase (before: "${textBefore0}", after: "${textAfter0}")`
    );
    assertTrue(
      normalize(textAfter1) === normalize(textBefore1),
      `Expected question 1 text to remain unchanged after rephrasing question 0 (before: "${textBefore1}", after: "${textAfter1}")`
    );
  });

  test('TC_AI_08: Generate more questions increases the question count', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.clickSuggestNewQuestions();
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  test('TC_AI_09: Describe questions to add increases the question count', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.describeAndSubmitReprompt('Add a question about delivery speed');
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  test(
    'TC_AI_11/TC_BS_08: Add Question/Duplicate/Generate more/Describe are disabled at 10 (max) questions',
    { tag: '@BuildSurvey @MaxQuestions' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(basePage);

      const questionCount = await surveyBuilderPage.getQuestionCount();
      assertTrue(questionCount === 10, `Expected 10 questions after the Describe-questions step, found ${questionCount}`);

      assertTrue(await surveyBuilderPage.isAddQuestionTooltipVisibleOnHover(), 'Expected max-questions tooltip on Add question hover');
      const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
      assertTrue(addQuestionState.disabled, `Expected Add question disabled at max (outerHtml="${addQuestionState.outerHtml}")`);

      assertTrue(await surveyBuilderPage.isDuplicateTooltipVisibleOnHover(), 'Expected max-questions tooltip on Duplicate hover');
      const duplicateState = await surveyBuilderPage.getDuplicateDisabledState();
      assertTrue(duplicateState.disabled, `Expected Duplicate disabled at max (outerHTML="${duplicateState.outerHtml}")`);

      const questionCountAfter = await surveyBuilderPage.getQuestionCount();
      assertTrue(questionCountAfter === 10, `Expected count to stay 10, found ${questionCountAfter}`);

      const generateMoreState = await promptPage.getGenerateMoreQuestionsDisabledState();
      assertTrue(
        generateMoreState.disabled,
        `Expected Generate more questions disabled at max (outerHtml="${generateMoreState.outerHtml}")`
      );

      const describeState = await promptPage.getDescribeQuestionsDisabledState();
      assertTrue(describeState.disabled, `Expected Describe questions to add disabled at max (outerHtml="${describeState.outerHtml}")`);
    }
  );

  registerRequiredStarTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_07: Required star appears when the Required toggle is on', tag: '@BuildSurvey' }
  );
  registerEditQuestionTextTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_25: Edit question text via the pencil icon', tag: '@BuildSurvey' }
  );
  registerDiscardSaveChangesTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_26: Discard / Save changes on an existing question', tag: '@DiscardSave' }
  );
  registerEmptyQuestionTextBlocksSaveTest({ getBasePage: () => basePage });
  registerDeleteDuplicateQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_06: Delete and duplicate a question via hover row actions', tag: '@BuildSurvey' }
  );
  registerDragDropTest({ getBasePage: () => basePage }, { title: 'TC_BS_15: Drag and drop reorders questions', tag: '@BuildSurvey' });
  registerCancelAddQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_05: Cancelling Add Question leaves the question count unchanged', tag: '@BuildSurvey' }
  );
  registerDiscardNewQuestionThenSaveTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_22: Discard a new question via Add Question cancel, then add and save one', tag: '@CancelAddQuestion' }
  );
  registerDeleteLastThenReAddTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_20: Delete the last question then re-add the same type as last', tag: '@DeleteDuplicate' }
  );
  registerReviewModeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit', tag: '@BuildSurvey' }
  );
  registerValidateDisabledUnderThreeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_09: Validate survey is disabled with fewer than 3 questions', tag: '@BuildSurvey' }
  );
  registerReviewModeDeleteAllTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_27: Review Mode select all, delete all, stay on Build Survey', tag: '@BuildSurvey' }
  );
  registerEmptyStateTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_01: Empty Build Survey state shows Add Question options and 0 rows', tag: '@BuildSurvey' }
  );
  registerAddSingleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03a: Add a Single Choice question', tag: '@BuildSurvey' }
  );
  registerAddMultipleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03b: Add a Multiple Choice question', tag: '@BuildSurvey' }
  );
  registerAddRatingQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03c: Add a Rating question', tag: '@BuildSurvey' });
  registerAddNPSQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03d: Add an NPS question', tag: '@BuildSurvey' });
  registerAddPointScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03e: Add a Point Scale question', tag: '@BuildSurvey' }
  );
  registerAddMultiScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03f: Add a Multi Scale question', tag: '@BuildSurvey' }
  );
  registerStepperNavigationTest(
    { getBasePage: () => basePage },
    {
      title: 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey',
      tag: '@BuildSurvey',
      responseCountTestId: 'select-response-count-250',
    } 
  );

  registerOptionBoundaryTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_04: Options boundary - min 2, max 15', tag: '@OptionBoundary' }
  );

  registerSaveDraftTest({ getBasePage: () => basePage }, { title: 'TC_BS_10: Save survey as draft', tag: '@SaveDraft' });

  registerValidateSurveyTest(
    { getBasePage: () => basePage },
    { title: 'TC_AI_13: Validate survey: Completes and shows Optiq feedback when there are recommendations',
      tag: '@ValidateSurvey',});

  registerPublishPopupCancelTest({ getBasePage: () => basePage }, { title: 'TC_BS_17: Publish popup Cancel leaves the survey unpublished', tag: '@PublishPopup' });

  registerCreateFolderFromPublishPopupTest(
    { getBasePage: () => basePage },
    { title: 'TC_AI_14: Create a new folder from the Publish popup', tag: '@PublishPopup' }
  );
});
