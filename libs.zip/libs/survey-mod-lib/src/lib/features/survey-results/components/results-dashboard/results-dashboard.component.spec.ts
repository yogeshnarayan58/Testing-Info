import { TestBed } from '@angular/core/testing';
import { ChangeDetectorRef, signal } from '@angular/core';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

// Keep selection tests independent of the deferred chart library runtime.
vi.mock('../question-chart/question-chart.component', () => ({
  QuestionChartComponent: class {},
}));

vi.mock('../../../build-survey/services/survey.service', () => ({
  SurveyService: class {},
}));

import { SurveyService } from '../../../build-survey/services/survey.service';
import {
  RESULTS_DASHBOARD_CHART_TYPE_OPTIONS,
  SURVEY_RESULTS_DASHBOARD_STAGES,
} from '../../models/survey-results';
import { QuestionTypes } from '../../../build-survey/models/build-survey';
import { ResultsDashboardComponent } from './results-dashboard.component';

describe('ResultsDashboardComponent', () => {
  let component: ResultsDashboardComponent;
  const detectChanges = vi.fn();
  const scrollIntoView = vi.fn();
  let questionCard: HTMLElement;

  const surveyServiceStub = {
    title: signal('Colgate Marketing Survey').asReadonly(),
    loadedSurveyDetails: vi.fn(),
    currentSurveyId: 'real-survey',
  };

  beforeEach(async () => {
    questionCard = document.createElement('div');
    questionCard.id = 'survey-results-question-card-q_1';
    questionCard.setAttribute('data-test-id', 'survey-results-question-header-q_1');
    questionCard.scrollIntoView = scrollIntoView;
    document.body.appendChild(questionCard);
    await TestBed.configureTestingModule({
      providers: [
        { provide: SurveyService, useValue: surveyServiceStub },
        { provide: ChangeDetectorRef, useValue: { detectChanges, markForCheck: vi.fn() } },
      ],
    });

    component = TestBed.runInInjectionContext(() => new ResultsDashboardComponent());
    (component as unknown as { questionHeaders: () => Array<{ nativeElement: HTMLElement }> }).questionHeaders = () =>
      questionCard.isConnected ? [{ nativeElement: questionCard }] : [];
  });

  afterEach(() => {
    questionCard.remove();
    TestBed.resetTestingModule();
  });

  it('expands the selected card without measuring its layout', () => {
    expect(component.expandedQuestionId()).toBeNull();

    component.toggleQuestionExpansion(component.questions[0].id);

    expect(component.expandedQuestionId()).toBe(component.questions[0].id);
  });

  it('collapses the same card when toggled again', () => {
    const questionId = component.questions[0].id;
    component.toggleQuestionExpansion(questionId);
    component.toggleQuestionExpansion(questionId);

    expect(component.expandedQuestionId()).toBeNull();
    expect(detectChanges).toHaveBeenCalledOnce();
    expect(scrollIntoView).toHaveBeenCalledOnce();
    expect(detectChanges.mock.invocationCallOrder[0]).toBeLessThan(scrollIntoView.mock.invocationCallOrder[0]);
  });

  it('suppresses the tooltip when expanding and collapsing the same card', () => {
    const questionId = component.questions[0].id;
    component.toggleQuestionExpansion(questionId);
    expect(component.suppressedExpandTooltipId()).toBe(questionId);

    component.suppressedExpandTooltipId.set(null);
    component.toggleQuestionExpansion(questionId);
    expect(component.suppressedExpandTooltipId()).toBe(questionId);
  });

  it('suppresses the tooltip when collapsing through the Escape handler', () => {
    const questionId = component.questions[0].id;
    component.toggleQuestionExpansion(questionId);
    component.suppressedExpandTooltipId.set(null);
    component.collapseQuestion();
    expect(component.suppressedExpandTooltipId()).toBe(questionId);
  });

  it('keeps only one question expanded at a time', () => {
    component.toggleQuestionExpansion(component.questions[0].id);
    component.toggleQuestionExpansion(component.questions[1].id);

    expect(component.expandedQuestionId()).toBe(component.questions[1].id);
  });

  it('expands an individual scale subcard without expanding its parent question', () => {
    const scaleQuestion = component.questions.find((question) => question.type === QuestionTypes.MultiplePointScale)!;
    const subCard = scaleQuestion.subCards![0];

    component.toggleQuestionExpansion(subCard.id);

    expect(component.expandedQuestionId()).toBe(subCard.id);
    expect(component.expandedQuestionId()).not.toBe(scaleQuestion.id);
  });

  it('collapses without changing chart or segment selections', () => {
    const questionId = component.questions[0].id;
    component.onSegmentChange(questionId, 'actual');
    component.onChartTypeChange(questionId, 'PIE');
    component.toggleQuestionExpansion(questionId);
    component.collapseQuestion();

    expect(component.expandedQuestionId()).toBeNull();
    expect(component.selectedByQuestionId[questionId]).toEqual({ segment: 'actual', chartType: 'PIE' });
  });

  it('does nothing when collapsing an already collapsed dashboard', () => {
    component.collapseQuestion();

    expect(component.expandedQuestionId()).toBeNull();
    expect(component.suppressedExpandTooltipId()).toBeNull();
  });

  it('sets independent mock question identities for report payloads', () => {
    component.ngOnInit();
    expect(component.chartContextByQuestionId['q_1'].question.qid).toBe('q_1');
    expect(component.chartContextByQuestionId['q_2'].question.qid).toBe('q_2');
  });

  it('exposes stage-based summary metrics', () => {
    expect(component.currentStage).toBe(SURVEY_RESULTS_DASHBOARD_STAGES.noResponses);
    expect(component.dashboardState.summaryMetrics).toHaveLength(3);
    expect(component.dashboardState.summaryMetrics[0]).toEqual({
      id: 'total-responses',
      label: 'Total Responses',
      value: '0/400',
      ariaLabel: 'Total responses',
    });
  });

  it('exposes stage-based summary state and helper flags', () => {
    expect(component.dashboardState.summaryInsights).toEqual([]);
    expect(component.dashboardState.disclaimerText).toContain('not ready to be used');
    expect(component.isPreCompletionStage).toBe(true);
    expect(component.summaryBetaText).toBe('All insights is in beta and can get things wrong.');
    expect(component.summaryLearnMoreText).toBe('Learn more');
  });

  it('updates segment independently for the selected question only', () => {
    const firstQuestionId = component.questions[0].id;
    const secondQuestionId = component.questions[1].id;

    component.onSegmentChange(firstQuestionId, 'actual');

    expect(component.selectedByQuestionId[firstQuestionId].segment).toBe('actual');
    expect(component.selectedByQuestionId[secondQuestionId].segment).toBe('percentage');
  });

  it('updates chart type independently for the selected question only', () => {
    const firstQuestionId = component.questions[0].id;
    const secondQuestionId = component.questions[2].id;

    component.onChartTypeChange(firstQuestionId, 'PIE');

    expect(component.selectedByQuestionId[firstQuestionId].chartType).toBe('PIE');
    expect(component.selectedByQuestionId[secondQuestionId].chartType).toBe('MULTIBAR_HORIZONTAL');
  });

  it('maps scale types to standard charts while hiding their main-bar chart menus', () => {
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.SingleChoice].map(({ label }) => label)).toEqual([
      'Bar Chart', 'Column Chart', 'Pie Chart',
    ]);
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.MultipleChoice]).toEqual(
      RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.SingleChoice]
    );
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.StarRating].map(({ label }) => label)).toEqual([
      'Heatmap',
    ]);
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.NetPromoterScore].map(({ label }) => label)).toEqual([
      'Bar Chart', 'Column Chart', 'Pie Chart',
    ]);
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.SinglePointScale]).toBe(
      RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.SingleChoice]
    );
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.MultiplePointScale]).toBe(
      RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.SingleChoice]
    );
    expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[QuestionTypes.Text]).toEqual([]);
    expect(component.questions.some((question) => question.type === QuestionTypes.Text)).toBe(false);
  });

  it('starts scale questions with a main heat-grid selection', () => {
    const multiScaleQuestion = component.questions.find((question) => question.type === QuestionTypes.MultiplePointScale);

    expect(multiScaleQuestion).toBeDefined();
    expect(component.selectedByQuestionId[multiScaleQuestion!.id].chartType).toBe('heatmap');
  });

  it.each([QuestionTypes.SinglePointScale, QuestionTypes.MultiplePointScale])(
    'updates each %s subcard independently with its own chart context', (questionType) => {
      component.ngOnInit();
      const question = component.questions.find((item) => item.type === questionType)!;
      const [firstSubCard, secondSubCard] = question.subCards!;

      expect(component.chartContextByQuestionId[firstSubCard.id]).toEqual({
        surveyId: 'mock-survey', surveyTitle: 'Colgate Marketing Survey',
        question: { qid: firstSubCard.id, title: firstSubCard.title, type: questionType },
      });
      for (const chartType of ['MULTIBAR_HORIZONTAL', 'MULTIBAR_VERTICAL', 'PIE']) {
        component.onChartTypeChange(firstSubCard.id, chartType);
        expect(component.selectedByQuestionId[firstSubCard.id].chartType).toBe(chartType);
        expect(component.selectedByQuestionId[secondSubCard.id].chartType).toBe('PIE');
        expect(component.selectedByQuestionId[question.id].chartType).toBe('heatmap');
      }
    }
  );

  it('provides three expandable subcards with independent chart controls for both scale question types', () => {
    const scaleQuestions = component.questions.filter((question) =>
      question.type === QuestionTypes.SinglePointScale || question.type === QuestionTypes.MultiplePointScale
    );

    expect(scaleQuestions).toHaveLength(2);
    for (const question of scaleQuestions) {
      expect(component.getChartTypeOptions(question.type).map(option => option.value)).toEqual(['heatmap']);
      expect(question.subCards?.map(({ title }) => title)).toEqual(['First Card', 'Second Card', 'Third Card']);
      for (const subCard of question.subCards ?? []) {
        expect(component.selectedByQuestionId[subCard.id].chartType).toBe('PIE');
        expect(component.getSelectedChartTypeIndex(subCard.id, component.getChartTypeOptions(question.type, true))).toBe(2);
        expect(RESULTS_DASHBOARD_CHART_TYPE_OPTIONS[question.type].map(({ label }) => label)).toEqual([
          'Bar Chart', 'Column Chart', 'Pie Chart',
        ]);
      }
    }

    const firstScaleQuestion = scaleQuestions[0];
    const firstSubCard = firstScaleQuestion.subCards![0];
    component.onChartTypeChange(firstSubCard.id, 'PIE');
    expect(component.selectedByQuestionId[firstSubCard.id].chartType).toBe('PIE');
    expect(component.selectedByQuestionId[firstScaleQuestion.id].chartType).toBe('heatmap');

    component.toggleScaleBreakdown(firstScaleQuestion.id);
    expect(component.isScaleBreakdownExpanded(firstScaleQuestion.id)).toBe(true);
    component.toggleScaleBreakdown(firstScaleQuestion.id);
    expect(component.isScaleBreakdownExpanded(firstScaleQuestion.id)).toBe(false);
  });

  it('uses the multi-card chevron as the scale breakdown expander', () => {
    const questionId = component.questions.find((question) => question.type === QuestionTypes.MultiplePointScale)!.id;
    const cardHeader = document.createElement('div');
    cardHeader.className = 'card-header';
    const chevron = document.createElement('niq-icon');
    cardHeader.appendChild(chevron);
    const chevronClick = new MouseEvent('click', { bubbles: true });
    Object.defineProperty(chevronClick, 'target', { value: chevron });

    component.onScaleCardClick(questionId, chevronClick);
    expect(component.isScaleBreakdownExpanded(questionId)).toBe(true);

    const bodyClick = new MouseEvent('click');
    component.onScaleCardClick(questionId, bodyClick);
    expect(component.isScaleBreakdownExpanded(questionId)).toBe(true);
    });
    
    it('resets the chart dropdown trigger state when its scroll area scrolls', () => {
      component.onChartMenuOpened(component.questions[0].id, true);
  
      component.closeChartMenuOnScroll();
  
      expect(component.openedChartMenuQuestionId()).toBeNull();
    });
    
    it('ignores invalid segment values', () => {
      const firstQuestionId = component.questions[0].id;
  
      component.onSegmentChange(firstQuestionId, 'invalid-value');
  
      expect(component.selectedByQuestionId[firstQuestionId].segment).toBe('percentage');
    });
  });
