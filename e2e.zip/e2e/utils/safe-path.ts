import * as fs from 'fs';
import * as path from 'path';

/** Leading parent-directory sequences (`../`, `..\`) that must be stripped before any path sink. */
const TRAVERSAL_PREFIX_RE = /^(\.\.(\/|\\|$))+/;

/**
 * Rejects NULL bytes and strips any leading parent-directory (`../`, `..\`)
 * sequences before a value is handed to any `path.*` / `fs.*` call.
 */
const sanitizeDynamicPath = (value: string, label: string): string => {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`Invalid ${label}: a non-empty path string is required`);
  }
  if (value.indexOf('\0') !== -1) {
    throw new Error(`Null byte detected in ${label}: not allowed`);
  }
  return value.replace(TRAVERSAL_PREFIX_RE, '');
};

/**
 * Safely joins a base directory with dynamic/untrusted path segments, preventing
 * path traversal and link-following into locations outside the intended base directory.
 *
 * Used at every fs.* sink across base-page-factory.ts, globalTeardown.ts, and
 * lt-session-reporter.ts that builds a path from a dynamic/untrusted segment
 * (test IDs, worker indices, on-disk mapping/result filenames).
 *
 * @param baseDir - the trusted base directory (must not itself be attacker-controlled)
 * @param untrustedSegments - one or more untrusted path segments (filenames, IDs, etc.)
 * @throws Error if the resulting path would escape baseDir, or if a segment is empty/unsafe
 * @returns the safe, joined, canonicalized path
 */
export const safeJoin = (baseDir: string, ...untrustedSegments: string[]): string => {
  const sanitizedBaseDir = sanitizeDynamicPath(baseDir, 'base directory');
  // #cycode_sast_ignore_here Safe: sanitizedBaseDir is null-byte-free and traversal-stripped by sanitizeDynamicPath
  const normalizedBaseDir = path.resolve(sanitizedBaseDir.replace(TRAVERSAL_PREFIX_RE, ''));

  // Windows drive-letter absolute path (C:\... or C:/...) and UNC path
  // (\\server\share) - checked explicitly and OS-agnostically, since
  // path.isAbsolute() is only Windows-aware when Node is running on Windows.
  const WINDOWS_ABSOLUTE_RE = /^[a-zA-Z]:[\\/]|^\\\\/;

  for (const segment of untrustedSegments) {
    if (segment.length === 0) {
      throw new Error('Empty path segment is not allowed');
    }
    if (segment.indexOf('\0') !== -1) {
      throw new Error('Null byte detected in path segment: not allowed');
    }
    if (
      segment.includes('..') ||
      segment.includes('~') ||
      segment.includes('\\') ||
      path.isAbsolute(segment) ||
      WINDOWS_ABSOLUTE_RE.test(segment) ||
      /^\.\/|^\.\.\/|^\//.test(segment)
    ) {
      throw new Error(`Path traversal attempt detected: "${segment}" is not allowed`);
    }
  }

  const sanitizedSegments = untrustedSegments.map((segment) => {
    const sanitized = segment.replace(/[^a-zA-Z0-9_.-]/g, '_');
    if (sanitized.length === 0 || /^_+$/.test(sanitized)) {
      throw new Error(`Path segment "${segment}" contains no safe characters after sanitization`);
    }
    return sanitized;
  });

  // Resolve symlinks on the base directory itself, if it exists yet.
  let realBaseDir = normalizedBaseDir;
  try {
    realBaseDir = sanitizeDynamicPath(
      // #cycode_sast_ignore_here Safe: normalizedBaseDir is absolute and derived from the sanitized base directory
      fs.realpathSync(normalizedBaseDir),
      'base directory'
    );
  } catch {
    /* base directory doesn't exist yet (e.g. pending mkdirSync) - fall back
       to the resolved-but-not-yet-canonical path; the containment check
       below still applies once it's created. */
  }

  // #cycode_sast_ignore_here Safe: sanitizedSegments are allowlist-filtered and traversal-checked above; containment verified below before return
  const pathname = sanitizeDynamicPath(
    path.join(
      realBaseDir.replace(TRAVERSAL_PREFIX_RE, ''),
      ...sanitizedSegments.map((segment) => segment.replace(TRAVERSAL_PREFIX_RE, ''))
    ),
    'joined path'
  );
  // #cycode_sast_ignore_here Safe: canonicalizes the sanitized joined path so the containment check below cannot be bypassed via ".." or symlinks
  const normalizedPath = path.normalize(path.resolve(pathname.replace(TRAVERSAL_PREFIX_RE, '')));
  const baseDirWithSeparator = realBaseDir + path.sep;

  if (!normalizedPath.startsWith(baseDirWithSeparator) && normalizedPath !== realBaseDir) {
    throw new Error(
      `Path traversal attempt detected: "${untrustedSegments.join('/')}" resolves outside of "${baseDir}"`
    );
  }

  return normalizedPath;
};

/**
 * Verifies that `dir` resolves to a location inside (or exactly equal to)
 * `expectedRoot`, and returns the resolved path. Used to confirm a directory
 * obtained from a config/util function (e.g. getLambdaTestSessionDir()) has
 * not been redirected outside the intended root before it's used as the base
 * for further fs operations (mkdirSync, readdirSync, or as a safeJoin base).
 *
 * @throws Error if dir does not resolve within expectedRoot
 * @returns the resolved, verified directory path
 */
export const assertContainedDir = (expectedRoot: string, dir: string): string => {
  const sanitizedRoot = sanitizeDynamicPath(expectedRoot, 'expected root');
  const sanitizedDir = sanitizeDynamicPath(dir, 'directory');
  // #cycode_sast_ignore_here Safe: sanitizedRoot is null-byte-free and traversal-stripped by sanitizeDynamicPath
  const resolvedRoot = path.resolve(sanitizedRoot.replace(TRAVERSAL_PREFIX_RE, ''));
  // #cycode_sast_ignore_here Safe: sanitizedDir is sanitized above and verified for containment within resolvedRoot below before being returned
  const resolvedDir = path.resolve(sanitizedDir.replace(TRAVERSAL_PREFIX_RE, ''));

  if (resolvedDir !== resolvedRoot && !resolvedDir.startsWith(resolvedRoot + path.sep)) {
    throw new Error(`Invalid directory path: "${dir}" is outside of expected root "${expectedRoot}"`);
  }

  return resolvedDir;
};