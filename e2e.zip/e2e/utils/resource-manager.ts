import { PageElement } from '@gfk/gta';
import { ElementResource } from '../interfaces/iElementResource';

/**
 * To use the ResourceManager, you can create an instance and register your component resources.
 * The resources should be structured with a unique component name and an array of web elements.
 * @example
 * Import below code lines to use ResourceManager in your component. Please ensure you have given the correct path to the resource-manager file.
 * ```typescript
 * import { ResourceManager } from './resource-manager';
 * import * as sampleResources1 from '../../../object-resources/sample-resources-1.json';
 * import * as sampleResources2 from '../../../object-resources/sample-resources-2.json';
 * 
 * // Below provided sample resources structure to be added in object-resources/sample-resources.json
 * const sampleResources1 = {
 *   name: 'My Component',
 *   webElements: [
 *     {
 *       elementName: 'submitButton',
 *       selectorValue: '[data-test-id="submit-btn"]',
 *       selectorType: 'css'
 *     },
 *     {
 *       elementName: 'dynamicItem',
 *       selectorValue: '[data-item="${text}"]',
 *       selectorType: 'css'
 *     }
 *   ]
 * }
 * 
 * // Create an instance of ResourceManager with an empty registry
 * const resourceManager = new ResourceManager({});
 * 
 * // Register resources for a component
 * resourceManager.registerResources('MyComponent1', sampleResources1);
 * resourceManager.registerResources('MyComponent2', sampleResources2);
 * 
 * // Now you can retrieve resources by their names
 * const submitButton = resourceManager.getResource('submitButton', 'MyComponent');
 * const dynamicItem = resourceManager.getDynamicResource('dynamicItem', 'item123', 'MyComponent');
 */

export class ResourceManager {
    
    // Resource registry to store component resources
    private resources: Record<string, ElementResource>;

    constructor(resources: Record<string, ElementResource>) {
        this.resources = resources;
    }
    
    /**
     * Registers component resources with the registry
     * 
     * @param componentName - Unique name for the component registering resources
     * @param resources - The resources object to register
     */
    registerResources(componentName: string, resources: ElementResource): void {
        // Use this.resources instead of resourceRegistry which isn't defined
        this.resources[componentName] = resources;
    }

    /**
     * Retrieves a web element resource by its name from any registered resource object
     * 
     * @param name - The name of the web element
     * @param componentName - Optional specific component to search in
     * @returns The matching web element resource
     * @example
     * // Returns: {
     * //   elementName: "searchButton",
     * //   selectorValue: "[data-test-id='search-btn']",
     * //   selectorType: "css"
     * // }
     * getResource('searchButton', 'SearchComponent')
     * @throws Error if the element is not found
     */
    getResource(name: string, componentName?: string): PageElement {
     if (componentName) {
         if (!this.resources[componentName]) {
             throw new Error(`Component '${componentName}' is not registered.`);
        }
         const element = this.resources[componentName].webElements.find((webElement: PageElement) => webElement.elementName === name
        );

        if (element) {
             return element;
        }} else { // Otherwise search all registered resources
            for (const [component, resourceObj] of Object.entries(this.resources)) {
                const element = resourceObj.webElements.find(
                    (x: PageElement) => x.elementName === name
                );
                if (element) return element;
            }
        }

        throw new Error(
            `Web element with name '${name}' not found in the${componentName ? ` ${componentName}` : ''} object repository.`
        );
    }

    /**
     * Retrieves a web element resource by its name from the object repository with dynamic text in selector value(or locator).
     * 
     * @param name - The name of the web element.
     * @param text - The dynamic text to replace in the selector value.
     * @param componentName - Optional component to search in. If omitted, searches all components.
     * @returns The matching web element resource.
     * @example
     * // Assuming an element with selectorValue: '[data-row='${text}']'
     * // Returns: {
     * //   elementName: "dataRow",
     * //   selectorValue: "[data-row='user123']", // ${text} replaced in '[data-row='${text}']'
     * //   selectorType: "css" 
     * // }
     * getDynamicResource('dataRow', 'user123', 'TableComponent')
     * @throws Error if the element is not found.
     */
    getDynamicResource(name: string, text: string, componentName?: string): PageElement {
        if (!name) {
            throw new Error(`Invalid resource name '${name}' provided to getDynamicResource.`);
        }
        // Use this.getResource instead of undefined getResource function
        const element = this.getResource(name, componentName);
        if (!element || !element.selectorValue) {
            throw new Error(`Web element with name '${name}' does not have a valid selector.`);
        }
        if (!element.selectorValue.includes('${text}')) {
            throw new Error(`Web element with name '${name}' does not have a dynamic selector that includes '${text}'.`);
        }
        // Return the dynamic resource object with the provided text
        return {
            ...element,
            selectorValue: element.selectorValue.replace('${text}', text) // Replace ${text} with the provided text
        };
    }

    /**
     * Retrieves a web element resource with MULTIPLE dynamic replacements in the selector value.
     * Supports composite selectors with multiple placeholders (e.g., ${questionNumber}, ${segmentIndex}).
     * 
     * @param name - The name of the web element
     * @param replacements - Object with key-value pairs for dynamic replacements
     * @param componentName - Optional component to search in. If omitted, searches all components.
     * @returns The matching web element resource with all placeholders replaced
     * 
     * @example
     * // Assuming an element with selectorValue: '[data-test-id="ao-toggle-segment-q${questionNumber}-${segmentIndex}"]'
     * // Returns: {
     * //   elementName: "toggleSegment",
     * //   selectorValue: '[data-test-id="ao-toggle-segment-q1-0"]', // All placeholders replaced
     * //   selectorType: "tag"
     * // }
     * getMultiDynamicResource('toggleSegment', { questionNumber: '1', segmentIndex: '0' }, 'AssortmentOptimizerToggle')
     * 
     * @example
     * // For selectors with multiple dynamic parts
     * getMultiDynamicResource('pinMenuItem', { index: '0', action: 'text' }, 'NlsnPinMenuComponent')
     * 
     * @throws Error if element is not found or if required placeholders are missing
     */
    getMultiDynamicResource(
        name: string,
        replacements: Record<string, string | number>,
        componentName?: string
    ): PageElement {
        if (!name) {
            throw new Error(`Invalid resource name '${name}' provided to getMultiDynamicResource.`);
        }

        if (!replacements || Object.keys(replacements).length === 0) {
            throw new Error(`No replacement values provided for getMultiDynamicResource.`);
        }

        const element = this.getResource(name, componentName);

        if (!element || !element.selectorValue) {
            throw new Error(`Web element with name '${name}' does not have a valid selector.`);
        }

        // Perform replacements for all provided key-value pairs
        let updatedSelector = element.selectorValue;

        for (const [key, value] of Object.entries(replacements)) {
            const placeholder = `\${${key}}`;
            if (!updatedSelector.includes(placeholder)) {
                throw new Error(
                    `Placeholder '${placeholder}' not found in selector for element '${name}'. ` +
                    `Available selector: ${element.selectorValue}`
                );
            }
            // Use literal string replacement instead of RegExp to avoid regex injection
            // This safely handles keys with special regex characters
            updatedSelector = updatedSelector.split(placeholder).join(String(value));
        }

        // Return the resource object with all placeholders replaced
        return {
            ...element,
            selectorValue: updatedSelector
        };
    }
}
