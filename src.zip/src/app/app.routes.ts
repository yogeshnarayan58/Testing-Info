import { Routes } from '@angular/router';
import { myAssetsRoutes, SURVEY_MOD_ROUTES } from '@nielsen/crf-survey-mod';

export const routes: Routes = [
  {
    path: 'survey',
    children: SURVEY_MOD_ROUTES,
  },
  {
    path: 'my-assets/survey',
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'my-assets'
      },
      ...myAssetsRoutes
    ],
  },
  { path: '**', redirectTo: 'survey', pathMatch: 'full' },
];
