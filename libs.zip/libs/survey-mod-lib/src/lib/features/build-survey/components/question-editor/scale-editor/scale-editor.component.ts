import { Component, computed, ElementRef, input, model, output } from '@angular/core';
import {
  ButtonModule,
  CheckboxModule,
  IconButtonModule,
  IconModule,
  RadioButtonModule,
  TextFieldModule,
  ToggleModule,
  TooltipModule,
} from '@nielseniq/athena-core';
import { BaseQuestionEditorDirective } from '../base-question-editor.directive';
import { SuggestionTagsComponent } from '../suggestion-tags/suggestion-tags.component';
import { MAXIMUM_OPTIONS_ALLOWED } from '../../../models/build-survey';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-scale-editor',
  imports: [
    ButtonModule,
    CheckboxModule,
    IconModule,
    RadioButtonModule,
    TextFieldModule,
    ToggleModule,
    IconButtonModule,
    TooltipModule,
    SuggestionTagsComponent,
    TranslateModule,
  ],
  standalone: true,
  templateUrl: './scale-editor.component.html',
  styleUrls: ['./scale-editor.component.scss'],
})
export class ScaleEditorComponent extends BaseQuestionEditorDirective {
  // Component-specific inputs
  rowOptions = model<string[]>(['', '']);
  columnOptions = model<string[]>(['', '']);
  selectedType = input('');

  /** Notifies the parent that the form changed so it can run validation/preview side effects. */
  formChange = output<void>();

  readonly minRows: number = 2;
  readonly minColumns: number = 2;

  isAtMaxRowOptions = computed(() => this.rowOptions().length >= MAXIMUM_OPTIONS_ALLOWED);
  isAtMaxColumnOptions = computed(() => this.columnOptions().length >= MAXIMUM_OPTIONS_ALLOWED);

  isAtMinRowOptions = computed(() => this.rowOptions().length <= this.minRows);
  isAtMinColumnOptions = computed(() => this.columnOptions().length <= this.minColumns);

  showAddMenu: boolean = false;
  showDeleteMenu: boolean = false;

  constructor(elementRef: ElementRef<HTMLElement>) {
    super(elementRef);
  }

  /** Handles input change event. */
  onInputChange(value: string | number): void {
    this.question.set(String(value ?? ''));
    this.formChange.emit();
  }

  /** called on row edit */
  onRowEdit(index: number, event: Event): void {
    const updatedRowOptions = [...this.rowOptions()];
    updatedRowOptions[index] = (event.target as HTMLInputElement).value;
    this.rowOptions.set(updatedRowOptions);
    this.formChange.emit();
  }

  /** called on column edit */
  onColumnEdit(index: number, event: Event): void {
    const updatedColumnOptions = [...this.columnOptions()];
    updatedColumnOptions[index] = (event.target as HTMLInputElement).value;
    this.columnOptions.set(updatedColumnOptions);
    this.formChange.emit();
  }

  /** Adds an empty row or column option based on the type parameter */
  addOption(type: 'row' | 'column'): void {
    const optionsSignal = type === 'row' ? this.rowOptions : this.columnOptions;
    const currentOptions = optionsSignal();
    if (currentOptions.length < MAXIMUM_OPTIONS_ALLOWED) {
      optionsSignal.set([...currentOptions, '']);
      this.formChange.emit();
    }
  }

  /** called on delete row */
  deleteRow(): void {
    const currentRowOptions = this.rowOptions();
    if (currentRowOptions.length > this.minRows) {
      this.rowOptions.set(currentRowOptions.slice(0, -1));
      this.formChange.emit();
    }
  }

  /** called on delete column */
  deleteColumn(): void {
    const currentColumnOptions = this.columnOptions();
    if (currentColumnOptions.length > this.minColumns) {
      this.columnOptions.set(currentColumnOptions.slice(0, -1));
      this.formChange.emit();
    }
  }

  toggleChange(event: Event): void {
    this.isRequired.set((event.target as HTMLInputElement).checked ?? false);
    this.formChange.emit();
  }
}
