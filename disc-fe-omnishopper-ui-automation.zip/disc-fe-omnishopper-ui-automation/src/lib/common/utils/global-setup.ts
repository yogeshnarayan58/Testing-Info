/**
 * @fileoverview Global setup for Playwright tests.
 * Handles authentication state management and login initialization.
 *
 * This module is executed before running tests to establish authentication
 * and prepare the testing environment.
 */
import fs from "fs";
import path from "path";
import { BasePageFactory } from "./base-page-factory";
import { LoginPage } from "../pages/login-page/login-page";
import { config } from "../../playwright/config";

// Define constants
const AUTH_FILE_PATH = "storage/auth.json";
const LT_SESSIONS_DIR = ".lt-sessions";

/**
 * Performs global setup operations before tests are run.
 * - Validates environment variables
 * - Cleans up previous authentication state
 * - Performs login to establish a new auth state
 */
async function globalSetup(): Promise<void> {
  try {
    console.log("Starting global setup...");

    // Delete existing auth state if it exists
    if (fs.existsSync(AUTH_FILE_PATH)) {
      fs.unlinkSync(AUTH_FILE_PATH);
      console.log("Old authentication state deleted.");
    }

    // Clean up LambdaTest session files from previous run
    if (fs.existsSync(LT_SESSIONS_DIR)) {
      const files = fs.readdirSync(LT_SESSIONS_DIR);
      files.forEach(file => {
        fs.unlinkSync(path.join(LT_SESSIONS_DIR, file));
      });
      console.log(`Cleared ${files.length} old LambdaTest session file(s).`);
    } else {
      // Create directory if it doesn't exist
      fs.mkdirSync(LT_SESSIONS_DIR, { recursive: true });
      console.log("Created .lt-sessions directory.");
    }
    
    // Perform login and create new auth state (force headless mode for login)
    console.log(`Logging in to ${config.BASE_URL} in headless mode...`);
    const basePage = await BasePageFactory.createBasePage(true);
    const loginPage = new LoginPage(basePage);
    await loginPage.login(config.BASE_URL);
    console.log("Authentication successful. New auth state created.");
  } catch (error) {
    console.error("Global setup failed:", error);

    // Rethrow with context to ensure the setup failure is clearly indicated
    if (error instanceof Error) {
      throw new Error(`Global setup failed: ${error.message}`);
    } else {
      throw new Error("Global setup failed with an unknown error");
    }
  }
}

export default globalSetup;
