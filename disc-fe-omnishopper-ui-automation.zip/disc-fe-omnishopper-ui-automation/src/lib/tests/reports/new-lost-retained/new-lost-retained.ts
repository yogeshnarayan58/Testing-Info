import { BasePage, WebActions, assert } from "@gfk/gta";
import { ResourceManager } from "../../../common/utils/resource-manager";
import * as commonResources from "../../../common/pages/common-test-resources.json";
import * as nlr from "../new-lost-retained/new-lost-retained.json";
import {
  MAX_TEST_TIMEOUT,
  SMALL_TIMEOUT,
} from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { config } from "../../../playwright/config";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { BasePageFactory } from "../../../common/utils/base-page-factory";

const DS_COMPONENT_NAME = "NLRSelector";
const COMMON_COMPONENT_NAME = "Common";
export class NLRSelector extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
    this.resourceManager.registerResources(DS_COMPONENT_NAME, nlr);
    this.resourceManager.registerResources(
      COMMON_COMPONENT_NAME,
      commonResources
    );

  }

  public async nlrTableCheck(): Promise<void> {
    await this.webActionHandler.delay(5000);
    let table = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("nlrBuyerFlowTable", DS_COMPONENT_NAME)
    );
    let count = await table.isVisible();
  }

  public async openSavedReport(){
    await this.webActionHandler.delay(10000);
  }

  public async openNLRDropdwn(){
    let dropDown = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("nlrDropDown", DS_COMPONENT_NAME)
    );
    // await this.webActionHandler.delay(10000);
    let dropDownContent = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("nlrDropDownContent", DS_COMPONENT_NAME)
      );
    //   await this.webActionHandler.delay(10000);
    dropDown.click();
    await this.webActionHandler.delay(5000);
    await dropDownContent.isVisible();
    await dropDownContent.getCount();
  }
}
