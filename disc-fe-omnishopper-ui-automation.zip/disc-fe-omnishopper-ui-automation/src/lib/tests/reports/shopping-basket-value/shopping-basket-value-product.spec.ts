import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";

import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import {
  findDataSetByName,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { config } from "../../../playwright/config";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { getDataElement } from "../../test-cases/common-test-cases-helper-service";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import assertionData from "./assertion-data/assertion-data.json";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";

const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Product";
test.describe("Shopping Basket Value Product", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  let formatPanel: FormatPanel;

  test.beforeAll(() => {
    const isValidTestData = reportTestData;
    if (!isValidTestData) {
      console.warn('Skipping Shopping Basket Value tests as the test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping Shopping Basket Value tests as the test data is not present');
  });

  test(
    "QuickLook: Should display correct preview information when template is selected",
    {
      tag: "@QuickLook",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let landingPage = new LandingPage(basePage);
      await landingPage.navigateToUrl(config.BASE_URL);
      await landingPage.clickAnalyseMyData();
      await landingPage.clickChooseATemplate();
      let chooseAtemplatePage = new ChooseAtemplatePage(
        landingPage.getBasePage()
      );
      await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
      await chooseAtemplatePage.hoverThumbnailBySrc(
        devTestData.common.thumbnailSrc
      );
      await chooseAtemplatePage.clickQuickLookInfoButton();
      let quickLookPage = new QuickLookPage(
        chooseAtemplatePage.getBasePage()
      );
      const previewDescriptionValue = await quickLookPage.getPreviewDescription();
      assert(previewDescriptionValue).toBe(localeData.description);
      const themesValue = await quickLookPage.getPreviewThemes();
      assertionData.common.themes.forEach((expectedTheme: string) => {
        assert(themesValue).toContain(expectedTheme);
      });
      const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
      assertionData.common.dataSets.forEach((expectedDataset: string) => {
        assert(previewDatasetsValue).toContain(expectedDataset);
      });
    }
  );

  test(
    "Insights Panel: Should validate business questions and report metadata",
    {
      tag: "@Insights",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      const insightsPanel = new InsightsPanel(basePage);
      await insightsPanel.navigateToUrl(reportUrl);
      await insightsPanel.clickInsightsIcon();
      const isTitleVisible =
        await insightsPanel.isReportInsightsTitleVisible();
      assert(isTitleVisible).toBeTruthy();
      const isCloseIconVisible =
        await insightsPanel.isReportInsightsPanelCloseIconVisible();
      assert(isCloseIconVisible).toBeTruthy();
      const insightsReportTitle =
        await insightsPanel.getInsightsReportTitle();
      assert(insightsReportTitle?.trim()).toBe(localeData.title);
      const description = await insightsPanel.getInsightsPanelDescription();
      assert(description?.trim()).toBe(localeData.description);
      const isBusinessTitleVisible =
        await insightsPanel.isBusinessQuestionsTitleVisible();
      assert(isBusinessTitleVisible).toBeTruthy();
      await insightsPanel.validateBusinessQuestions(
        localeData.businessQuestions
      );
      await insightsPanel.closeInsightsPanel();
    }
  );

  test
    (
      "Madlib Validation: Should validate madlib text content matches expected pattern",
      {
        tag: "@MadlibValidation",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        const commonTestCase = new CommonTestCase(basePage);
        commonTestCase.navigateToUrl(reportUrl);
        let commonBasePage = commonTestCase.getBasePage();
        dataSelector = new DataSelector(commonBasePage);
        await dataSelector.switchPivotDropdown(pivot);
        // Open additional prompts to ensure madlib is visible
        await dataSelector.clickAdditionalPromptEllipsisIcon();

        // Validate using pattern matching with detailed results
        if (localeData.madlibText) {
          // Get the actual madlib text
          const actualMadlibText = await dataSelector.getMadlibText();

          console.log("Actual Madlib Text:", actualMadlibText);
          console.log("Expected Pattern:", localeData.madlibText);

          // Use toMatch for clearer error messages showing exact mismatch
          assert(actualMadlibText).toMatch(
            new RegExp(localeData.madlibText, "i")
          );

          console.log(
            " Madlib validation passed for locale:",
            localeData.locale
          );
        } else {
          console.warn(
            `No madlib text pattern defined for locale: ${localeData.locale}`
          );
        }
      }
    );

  test(
    "Validate default format panel",
    {
      tag: "@FormatPanelDefaultVerification",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(reportUrl);
      formatPanel = new FormatPanel(basePage);
      await formatPanel.openFormatPanel();
      await formatPanel.testDefaultFormatPanel(
        reportAssertData["formatPanel"]["default"]
      );
      await formatPanel.closeFormatPanel();
    }
  );

  test(
    "Validate the pivot selection",
    {
      tag: "@Pivot List Verification",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.assertPivotDropdown(
        reportAssertData["dataSummary"]["pivot"]["pivotList"]
      );
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.switchPivotDropdown(pivot);
          // Get Product pivot data

          const productData = getDimensionSelectionsByPivot(pivot, reportTestData);
          if (!productData) {
            throw new Error("Pivot not found in test data: Product");
          }
          await dataSelector.clickAdditionalPromptEllipsisIcon();
          await dataSelector.clickMadlibDimension("Retailer");
          await dataSelector.setMadlibSelection(
            productData["Retailer"]
          );
          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            productData["Geography"]
          );
          await dataSelector.clickMadlibDimension("Products");
          await dataSelector.setMadlibSelection(
            productData["Products"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            productData["Period"]
          );


          await dataSelector.clickMadlibDimension("Shopper Group");
          await dataSelector.setMadlibSelection(
            productData["Shopper Group"]
          );
          await dataSelector.clickMadlibDimension("Facts");
          /* await dataSelector.assertFactsDropdown(
            reportAssertData["dataSummary"]["facts"]["factList"]
          ); */
          await dataSelector.selectClosedDropdown(
            productData["Facts"]["selections"]
          );
          
          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          console.log("run complete in spec");
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );

      test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
        test.skip(
          !savedReportTitle,
          "Skipping FMS test - Report not generated. Run with @RunReport first"
        );

        const basePage = await BasePageFactory.createBasePage();
        const findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });

      // Appended view and snapshot validations
      test(
        "Validate FullScreen",
        { tag: "@ValidateFullScreen" },
        async () => {
          test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.fullScreenView();
        }
      );

      test(
        "Validate presentationMode",
        { tag: "@PresentationMode" },
        async () => {
          test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.presentationMode();
        }
      );

      test("Validate snapshot", { tag: "@Snapshot" }, async () => {
        test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');
        let basePage = await BasePageFactory.createBasePage();
        const commonTC = new CommonTestCase(basePage);
        await commonTC.navigateToReportUrl(savedReportUrl);
        const snapshot = new Snapshot(commonTC.getBasePage());
        await snapshot.waitForReportRunCompletion();
        await snapshot.clickSaveIcon();
        await snapshot.clickSnapshotIcon();
        assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
        await snapshot.shiftingToSnapshot();
      });


      test(
        "Validate PPT export",
        {
          tag: "@ValidatePPTExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
        }
      );

      test(
        "Validate Excel export",
        {
          tag: "@ValidateExcelExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality(
            "Excel",
            "Editable objects",
            "Separately"
          );
        }
      );

      test(
        "Validate Add Blank Report",
        { tag: "@ValidateAddBlankReport" },
        async () => {
          if (!savedReportUrl) {
            test.skip(true, "No savedReportUrl available from prior RunReport test");
          }

          // Base context on saved report
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);

          // Make a copy so original saved report remains intact
          const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

          // Navigate to copied report URL
          let newBasePage = await BasePageFactory.createBasePage();
          let newCommonTestCase = new CommonTestCase(newBasePage);
          await newCommonTestCase.navigateToReportUrl(newUrl);

          // Perform blank report flow
          let reportFlowPage = new ReportFlowPage(newBasePage);
          await reportFlowPage.clickAddMenuIcon();
          await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);
          await reportFlowPage.validateAddMenuDropdownOptions();
          await reportFlowPage.clickAddBlankReportOption();
          await reportFlowPage.waitForBlankReportIndicator();
          await reportFlowPage.validateBlankReportCreation();
          await reportFlowPage.validateUntitledReportTitle();
          await reportFlowPage.runBlankReport(config.DATASET);

          // Return to copied report tab and validate madlib text exists
          await reportFlowPage.clickReportByName(newReportTitle);
          const postFlowDataSelector = new DataSelector(newBasePage);
          const madlibText = await postFlowDataSelector.getMadlibText();
          assert(madlibText?.length).toBeGreaterThan(0);
        }
      );
    }
  );

  // test("openOlderReport", async () => {
  //   let basePage = await BasePageFactory.createBasePage();
  //   let findMyStuff = new FindMyStuff(basePage);
  //   await findMyStuff.navigateToUrl(config.BASE_URL);
  //   await findMyStuff.searchForOlderAsset("Shopping Basket Value"); //Pass report name to search
  // });

});



function reportSpecificCases() {
  //    test("Report specific cases",  async () => {
  //     console.log("Inside report specific case - CPA");
  //     console.log("1. Start Checking the format panel working - by making changes");
  //     await getPage().locator('[data-test-id="omni-tsbp-menu-icon-button-icon"]').click();
  //     await getPage().getByText(`Fair Share Change`).click();
  //     await checkDefaultFormatPanelAfterRun(devTestData, "POD_OMNI");
  //     await openFormatPanel();
  //     await getPage().locator('[data-test-id="checkbox-property-0-icon"]').click();
  //     await testFormatPanelSelectionMatchWithChart(devTestData.POD_OMNI.formatPanelSelections.afterChangeCheck);
  //     await closeFormatPanel();
  //     console.log("1.End Checking the format panel working - by making changes");
  // });
}