import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { SurveyBuilderPage } from '../../page-objects/common/survey-builder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import {
  registerPublishPopupCancelTest,
  registerCreateFolderFromPublishPopupTest,
} from './common-test-cases/build-survey-common-test-cases';
import { registerScratchSetupTests } from './common-test-cases/scratch-setup';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

const SELECTED_RESPONSE_COUNT = 250; // the shared setup selects 250 responses

// The "Publish your survey" popup only opens for a survey that has no folder yet, so this spec never saves a draft.
test.describe.serial('Publish popup (start from scratch, unsaved survey)', { tag: '@PublishPopup' }, () => {
  let basePage: BasePage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'publish-popup-video');
    }
  });

  registerScratchSetupTests({
    setBasePage: (page) => {
      basePage = page;
    },
  });

  test('Setup: Should add 3 questions to the new unsaved survey', { tag: '@PublishPopupSetup' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await surveyBuilderPage.ensureQuestionCount(3);
    const questionCount = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCount >= 3, `Expected at least 3 questions, found ${questionCount}`);
  });

  registerPublishPopupCancelTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_17: Publish popup Cancel leaves the survey unpublished', tag: '@PublishPopup' }
  );

  registerCreateFolderFromPublishPopupTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_24: Create a new folder from the Publish popup', tag: '@PublishPopup' }
  );

  test('TC_BS_16/TC_BS_18: Publish survey', { tag: '@PublishSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const surveyName = testData.surveyNames.publish;

    await surveyBuilderPage.ensureQuestionCount(3);
    // Validates first when "Validate survey" is showing, then clicks "Review & publish survey".
    await surveyBuilderPage.openPublishDialog();

    assertTrue(await surveyBuilderPage.isPublishLocationDialogVisible(), 'Expected "Publish your survey" dialog to be visible');
    await surveyBuilderPage.fillPublishLocationDialogName(surveyName);
    await surveyBuilderPage.clickPublishLocationMyAssetsFolder();
    assertTrue(
      !(await surveyBuilderPage.isPublishLocationDialogContinueDisabled()),
      'Expected Continue to be enabled after entering a name and selecting My Assets'
    );
    await surveyBuilderPage.clickPublishLocationDialogContinue();

    assertTrue(await surveyBuilderPage.isReviewSurveyDetailsDialogVisible(), 'Expected "Review survey details" dialog after Continue');
    const reviewedSurveyTitle = await surveyBuilderPage.getReviewDialogSurveyTitleText();
    assertTrue(
      reviewedSurveyTitle === surveyName,
      `Expected "Review survey details" to show the survey name "${surveyName}", got "${reviewedSurveyTitle}"`
    );

    const areDimensionsShown = await surveyBuilderPage.isPublishDialogDimensionCountVisible(datasetConfig.dimensionSelections.length);
    assertTrue(areDimensionsShown, `Expected ${datasetConfig.dimensionSelections.length} dimension selections in "Review survey details"`);

    const responseCountText = await surveyBuilderPage.getReviewDialogResponseCountText();
    assertTrue(
      responseCountText.includes(String(SELECTED_RESPONSE_COUNT)),
      `Expected "${SELECTED_RESPONSE_COUNT}" responses in "Review survey details", got "${responseCountText}"`
    );

    const confirmClickTime = Date.now();
    const isPublishConfirmed = await surveyBuilderPage.confirmPublish();
    assertTrue(isPublishConfirmed, 'Expected "Review survey details" dialog and "Publishing survey" status to appear');
    const isSuccessToastVisible = await surveyBuilderPage.verifyPublishSucceeded(confirmClickTime);
    assertTrue(isSuccessToastVisible, 'Expected "Survey published successfully" message after publish');
  });
});
