import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { SurveyBuilderPage } from '../../../page-objects/common/survey-builder.page';
import { SelectPanelistPage } from '../../../page-objects/common/select-panelist.page';
import { MyAssetsPage } from '../../../page-objects/common/my-assets.page';
import { assertTrue } from '../../../page-objects/common/assert-utils';
import testData from '../../../test-data/dev-test-data.json';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

// Short readable per-run suffix, e.g. " - 04 Nov 22:55" (date and minute, so same-day reruns rarely collide).
function uniqueNameSuffix(): string {
  const now = new Date();
  const date = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
  return ` - ${date} ${time}`;
}

export interface BuildSurveyTestContext {
  getBasePage: () => BasePage;
}

export interface BuildSurveyTestOptions {
  title?: string;
  tag?: string;
  /** Only honoured by registerPublishPopupCancelTest: registers it as test.fixme. */
  fixme?: boolean;
}

export interface EditSurveyTitleTestOptions extends BuildSurveyTestOptions {
  expectAiTitle?: boolean;
}

export function registerEditSurveyTitleTest(ctx: BuildSurveyTestContext, options?: EditSurveyTitleTestOptions): void {
  test(options?.title ?? 'TC_AI_07: Edit the survey title after AI generation', { tag: options?.tag ?? '@BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    if (options?.expectAiTitle) {
      const aiTitleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
      assertTrue(
        aiTitleDisplay !== '' && aiTitleDisplay !== 'Untitled Survey',
        `Expected AI-generated survey title to be non-empty and not "Untitled Survey", got "${aiTitleDisplay}"`
      );
    }

    await surveyBuilderPage.setSurveyTitle(testData.surveyQuestions.surveyTitle);
    await surveyBuilderPage.commitSurveyTitle();
    const titleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
    assertTrue(
      titleDisplay === testData.surveyQuestions.surveyTitle,
      `Expected survey title to update to "${testData.surveyQuestions.surveyTitle}", got "${titleDisplay}"`
    );
  });
}

export function registerRequiredStarTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_07: Required star appears when the Required toggle is on',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const index = 0;

      await surveyBuilderPage.setRequired(index, true);
      assertTrue(await surveyBuilderPage.waitForRequiredState(index, true), 'Expected Required star visible after turning Required on');

      await surveyBuilderPage.setRequired(index, false);
      assertTrue(await surveyBuilderPage.waitForRequiredState(index, false), 'Expected Required star hidden after turning Required off');

      await surveyBuilderPage.setRequired(index, true);
      assertTrue(
        await surveyBuilderPage.waitForRequiredState(index, true),
        'Expected Required star visible again after turning Required back on'
      );
    }
  );
}

export function registerEditQuestionTextTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_25: Edit question text via the pencil icon',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const { questionText: newText } = testData.surveyQuestions.nps;

      await surveyBuilderPage.editQuestionText(0, newText);

      const textDisplay = await surveyBuilderPage.getQuestionTextDisplay(0);
      assertTrue(textDisplay.includes(newText), `Expected question text to update to "${newText}", got "${textDisplay}"`);
    }
  );
}

export function registerDiscardSaveChangesTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_26: Discard / Save changes on an existing question', { tag: options?.tag ?? '@DiscardSave' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const normalize = (text: string) => text.replace(/\s+/g, '');
    const original = await surveyBuilderPage.getQuestionTextDisplay(0);

    await surveyBuilderPage.openQuestionForEditing(0);
    await surveyBuilderPage.enterQuestionText(0, `Discard attempt ${Date.now()}`);
    await surveyBuilderPage.clickDiscardChanges();
    assertTrue(!(await surveyBuilderPage.isEditorOpen()), 'Expected editor closed after Discard changes');
    const afterDiscard = await surveyBuilderPage.getQuestionTextDisplay(0);
    assertTrue(normalize(afterDiscard) === normalize(original), `Expected question text unchanged after discard, got "${afterDiscard}"`);

    const newText = `Saved text ${Date.now()}`;
    await surveyBuilderPage.openQuestionForEditing(0);
    await surveyBuilderPage.enterQuestionText(0, newText);
    await surveyBuilderPage.saveQuestionChanges(0);
    assertTrue(!(await surveyBuilderPage.isEditorOpen()), 'Expected editor closed after Save changes');
    const afterSave = await surveyBuilderPage.getQuestionTextDisplay(0);
    assertTrue(normalize(afterSave).includes(normalize(newText)), `Expected question text to update to "${newText}", got "${afterSave}"`);
  });
}

export function registerEmptyQuestionTextBlocksSaveTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_28: Empty question text blocks Save changes',
    { tag: options?.tag ?? '@DiscardSave' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const normalize = (text: string) => text.replace(/\s+/g, '');
      const original = await surveyBuilderPage.getQuestionTextDisplay(0);

      await surveyBuilderPage.openQuestionForEditing(0);
      await surveyBuilderPage.enterQuestionText(0, '');
      await surveyBuilderPage.clickSaveChangesOnce(0);
      assertTrue(await surveyBuilderPage.isEditorOpen(), 'Expected editor to stay open after Save changes with empty question text');

      await surveyBuilderPage.clickDiscardChanges();
      assertTrue(!(await surveyBuilderPage.isEditorOpen()), 'Expected editor closed after discarding the empty-text attempt');
      const afterDiscard = await surveyBuilderPage.getQuestionTextDisplay(0);
      assertTrue(
        normalize(afterDiscard) === normalize(original),
        `Expected question text unchanged after Save with empty text then discard, got "${afterDiscard}"`
      );
    }
  );
}

export function registerDeleteDuplicateQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_06: Delete and duplicate a question via hover row actions',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      const countBeforeDelete = await surveyBuilderPage.getQuestionCount();
      await surveyBuilderPage.deleteQuestionAt(0);
      const countAfterDelete = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        countAfterDelete === countBeforeDelete - 1,
        `Expected count ${countBeforeDelete - 1} after delete, got ${countAfterDelete}`
      );
      assertTrue(countAfterDelete < 10, 'duplicate is disabled at 10 questions');

      const numbersAfterDelete = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(
        numbersAfterDelete.every((number, idx) => number.trim() === `${idx + 1}.`),
        'Expected remaining questions to be renumbered sequentially after delete'
      );

      const originalText = await surveyBuilderPage.getQuestionTextDisplay(0);
      const normalize = (text: string) => text.replace(/\s+/g, '');
      await surveyBuilderPage.duplicateQuestionAt(0);
      const countAfterDuplicate = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        countAfterDuplicate === countAfterDelete + 1,
        `Expected count ${countAfterDelete + 1} after duplicate, got ${countAfterDuplicate}`
      );
      const fullTextsAfter = await Promise.all(
        Array.from({ length: countAfterDuplicate }, (_, i) => surveyBuilderPage.getQuestionTextDisplay(i))
      );

      const numbersAfterDuplicate = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(
        numbersAfterDuplicate.every((number, idx) => number.trim() === `${idx + 1}.`),
        'Expected questions to be renumbered sequentially after duplicate'
      );

      const copyIndexes = fullTextsAfter.reduce<number[]>(
        (acc, text, idx) => (normalize(text) === normalize(originalText) ? [...acc, idx] : acc),
        []
      );
      assertTrue(
        copyIndexes.length === 2,
        `Expected exactly 2 questions matching original text "${normalize(originalText).slice(0, 80)}", found ${copyIndexes.length} (indexes: ${copyIndexes})`
      );
    }
  );
}

export function registerDragDropTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_15: Drag and drop reorders questions', { tag: options?.tag ?? '@BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const normalize = (text: string) => text.replace(/\s+/g, '').replace(/\*$/, '');
    const textBefore0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textBefore1 = await surveyBuilderPage.getQuestionTextDisplay(1);

    await surveyBuilderPage.dragQuestionRow(0, 1);

    const textAfter0 = await surveyBuilderPage.getQuestionTextDisplay(0);
    const textAfter1 = await surveyBuilderPage.getQuestionTextDisplay(1);
    assertTrue(
      normalize(textAfter0) === normalize(textBefore1) && normalize(textAfter1) === normalize(textBefore0),
      `Expected questions 0/1 to swap (before: ["${textBefore0}", "${textBefore1}"], after: ["${textAfter0}", "${textAfter1}"])`
    );
  });
}

export function registerCancelAddQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_05: Cancelling Add Question leaves the question count unchanged',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
      if (addQuestionState.disabled) {
        await surveyBuilderPage.deleteQuestionAt(0);
      }

      const countBefore = await surveyBuilderPage.getQuestionCount();
      await surveyBuilderPage.clickAddQuestion();
      await surveyBuilderPage.clickQuestionTypeTile('questionTypeRating');
      await surveyBuilderPage.clickAddQuestion();

      const countAfter = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfter === countBefore, `Expected question count unchanged after cancel (before ${countBefore}, after ${countAfter})`);
    }
  );
}

// Clears the max-questions limit (if hit) so 'Add question' is clickable again.
async function ensureAddQuestionEnabled(surveyBuilderPage: SurveyBuilderPage): Promise<void> {
  const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
  if (addQuestionState.disabled) {
    await surveyBuilderPage.deleteQuestionAt(0);
  }
}

// Empty state has no 'Add question' link - adds via the same type-tile flow TC_BS_03a uses, only when the survey has 0 questions.
export async function ensureAtLeastOneQuestion(surveyBuilderPage: SurveyBuilderPage): Promise<void> {
  if ((await surveyBuilderPage.getQuestionCount()) === 0) {
    const { questionText, options } = testData.surveyQuestions.singleChoice;
    await surveyBuilderPage.addSingleChoiceQuestion(questionText, options);
  }
}

export function registerDiscardNewQuestionThenSaveTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_22: Discard a new question via Add Question cancel, then add and save one',
    { tag: options?.tag ?? '@CancelAddQuestion' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      await ensureAtLeastOneQuestion(surveyBuilderPage);
      await ensureAddQuestionEnabled(surveyBuilderPage);
      const countBefore = await surveyBuilderPage.getQuestionCount();

      await surveyBuilderPage.clickAddQuestion();
      await surveyBuilderPage.clickQuestionTypeTile('questionTypeRating');
      await surveyBuilderPage.clickAddQuestion(); // toggles the panel closed, discarding the new question
      const countAfterDiscard = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        countAfterDiscard === countBefore,
        `Expected count unchanged after discard (before ${countBefore}, after ${countAfterDiscard})`
      );

      const { questionText } = testData.surveyQuestions.rating;
      await surveyBuilderPage.clickAddQuestion();
      await surveyBuilderPage.addRatingQuestion(questionText);
      const countAfterSave = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfterSave === countBefore + 1, `Expected count ${countBefore + 1} after save, got ${countAfterSave}`);
    }
  );
}

export function registerDeleteLastThenReAddTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_20: Delete the last question then re-add the same type as last',
    { tag: options?.tag ?? '@DeleteDuplicate' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      await ensureAtLeastOneQuestion(surveyBuilderPage);
      await ensureAddQuestionEnabled(surveyBuilderPage);
      const { questionText } = testData.surveyQuestions.rating;
      await surveyBuilderPage.clickAddQuestion();
      await surveyBuilderPage.addRatingQuestion(questionText);
      const countBefore = await surveyBuilderPage.getQuestionCount();

      await surveyBuilderPage.deleteQuestionAt(countBefore - 1);
      const countAfterDelete = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfterDelete === countBefore - 1, `Expected ${countBefore - 1} after delete, got ${countAfterDelete}`);

      await surveyBuilderPage.clickAddQuestion();
      await surveyBuilderPage.addRatingQuestion(questionText);
      const countAfterReAdd = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfterReAdd === countBefore, `Expected ${countBefore} after re-add, got ${countAfterReAdd}`);

      const newLastText = await surveyBuilderPage.getQuestionTextDisplay(countAfterReAdd - 1);
      assertTrue(
        newLastText.replace(/\s+/g, '').includes(questionText.replace(/\s+/g, '')),
        `Expected re-added question to be last with text "${questionText}", got "${newLastText}"`
      );
    }
  );
}

export function registerPublishPopupCancelTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  const title = options?.title ?? 'TC_BS_17: Publish popup Cancel leaves the survey unpublished';
  const details = { tag: options?.tag ?? '@PublishPopup' };
  const body = async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
      await surveyBuilderPage.ensureQuestionCount(3);
      await surveyBuilderPage.openPublishDialog();

      const countBefore = await surveyBuilderPage.getQuestionCount();

      assertTrue(await surveyBuilderPage.isPublishLocationDialogVisible(), 'Expected "Publish your survey" dialog to be visible');
      assertTrue(
        await surveyBuilderPage.isPublishLocationDialogContinueDisabled(),
        'Expected Continue to be disabled before selecting a location'
      );

      await surveyBuilderPage.clickPublishLocationDialogCancel();

      assertTrue(
        !(await surveyBuilderPage.isPublishLocationDialogVisible()),
        'Expected "Publish your survey" dialog to be closed after Cancel'
      );
      assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Expected Build Survey page still shown after Cancel');
      const countAfter = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfter === countBefore, `Expected question count unchanged after Cancel (before ${countBefore}, after ${countAfter})`);
  };

  if (options?.fixme) {
    test.fixme(title, details, body);
  } else {
    test(title, details, body);
  }
}

export function registerCreateFolderFromPublishPopupTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_24: Create a new folder from the Publish popup',
    { tag: options?.tag ?? '@PublishPopup' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
      await surveyBuilderPage.ensureQuestionCount(3);
      await surveyBuilderPage.openPublishDialog();

      await surveyBuilderPage.clickCreateNewFolderLink();

      assertTrue(await surveyBuilderPage.isCreateNewFolderDialogVisible(), 'Expected "Create new folder" dialog to be visible');
      const controls = await surveyBuilderPage.areCreateNewFolderDialogControlsVisible();
      assertTrue(controls.nameInput, 'Expected Name field visible in "Create new folder" dialog');
      assertTrue(controls.cancel, 'Expected Cancel visible in "Create new folder" dialog');
      assertTrue(controls.create, 'Expected Create visible in "Create new folder" dialog');
      assertTrue(controls.close, 'Expected close X visible in "Create new folder" dialog');

      const folderName = `${testData.folders.newFolder}${uniqueNameSuffix()}`;
      await surveyBuilderPage.fillCreateNewFolderDialogName(folderName);
      await surveyBuilderPage.clickCreateNewFolderDialogCreate();

      assertTrue(
        await surveyBuilderPage.isPublishLocationFolderHighlighted(folderName),
        `Expected new folder "${folderName}" to be listed and highlighted in "Choose a location"`
      );
      assertTrue(
        !(await surveyBuilderPage.isPublishLocationDialogContinueDisabled()),
        'Expected Continue to be enabled with the new folder selected'
      );

      await surveyBuilderPage.clickPublishLocationFolder(folderName);
      await surveyBuilderPage.clickCreateNewFolderInLocation();
      assertTrue(await surveyBuilderPage.isCreateNewFolderDialogVisible(), 'Expected nested "Create new folder" dialog to be visible');

      await surveyBuilderPage.clickCreateNewFolderDialogCancel();

      assertTrue(
        !(await surveyBuilderPage.isCreateNewFolderDialogVisible()),
        'Expected nested "Create new folder" dialog to close after Cancel'
      );
      assertTrue(await surveyBuilderPage.isPublishLocationDialogVisible(), 'Expected "Publish your survey" dialog to be shown again');

      await surveyBuilderPage.clickPublishLocationDialogCancel();
      assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Expected Build Survey page still shown after closing the popup');
    }
  );
}

export function registerReviewSurveyDetailsEditTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_29: Review survey details dialog, Edit survey returns to Build Survey',
    { tag: options?.tag ?? '@ReviewSurveyDetails' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
      await surveyBuilderPage.ensureQuestionCount(3);
      const countBefore = await surveyBuilderPage.getQuestionCount();

      // openPublishDialog() runs the existing validate step first when "Validate survey" is showing instead of "Review & publish survey".
      await surveyBuilderPage.openPublishDialog();

      assertTrue(await surveyBuilderPage.isReviewSurveyDetailsDialogVisible(), 'Expected "Review survey details" dialog to be visible');

      const dialogTitle = await surveyBuilderPage.getReviewDialogTitleText();
      assertTrue(dialogTitle !== '', 'Expected the dialog title (publish-dialog-title) to be non-empty');
      const surveyTitle = await surveyBuilderPage.getReviewDialogSurveyTitleText();
      assertTrue(surveyTitle !== '', 'Expected the survey title in the dialog to be non-empty');
      const questionSummary = await surveyBuilderPage.getReviewDialogQuestionSummaryText();
      assertTrue(questionSummary !== '', 'Expected the question count summary in the dialog to be non-empty');
      assertTrue(
        questionSummary.includes(String(countBefore)),
        `Expected the question summary to include ${countBefore}, got "${questionSummary}"`
      );
      const responseCount = await surveyBuilderPage.getReviewDialogResponseCountText();
      assertTrue(responseCount !== '', 'Expected the response count (publish-response-count) to be non-empty');
      assertTrue(await surveyBuilderPage.isReviewDialogPublishButtonVisible(), 'Expected "Publish survey" (confirm-publish) visible in the dialog');

      await surveyBuilderPage.clickReviewDialogEditSurvey();

      assertTrue(await surveyBuilderPage.isReviewSurveyDetailsDialogClosed(), 'Expected "Review survey details" dialog closed after Edit survey');
      assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Expected Build Survey page shown after Edit survey');
      const countAfter = await surveyBuilderPage.getQuestionCount();
      assertTrue(countAfter === countBefore, `Expected question count unchanged after Edit survey (before ${countBefore}, after ${countAfter})`);
    }
  );
}

export function registerPublishSavedSurveyTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_16/TC_BS_18: Publish survey', { tag: options?.tag ?? '@PublishSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
    const SELECTED_RESPONSE_COUNT = 250; // the setup selects 250 responses

    // The survey is already saved (it has a folder), so publishing opens "Review survey details" directly.
    await surveyBuilderPage.openPublishDialog();

    assertTrue(await surveyBuilderPage.isReviewSurveyDetailsDialogVisible(), 'Expected "Review survey details" dialog to be visible');
    const surveyTitle = await surveyBuilderPage.getReviewDialogSurveyTitleText();
    assertTrue(surveyTitle !== '', 'Expected the survey title in "Review survey details" to be non-empty');

    const areDimensionsShown = await surveyBuilderPage.isPublishDialogDimensionCountVisible(datasetConfig.dimensionSelections.length);
    assertTrue(areDimensionsShown, `Expected ${datasetConfig.dimensionSelections.length} dimension selections in "Review survey details"`);

    const responseCountText = await surveyBuilderPage.getReviewDialogResponseCountText();
    assertTrue(
      responseCountText.includes(String(SELECTED_RESPONSE_COUNT)),
      `Expected "${SELECTED_RESPONSE_COUNT}" responses in "Review survey details", got "${responseCountText}"`
    );

    // Edit survey -> change the first question's text -> publish again (the edit sends the survey back to "Validate survey").
    const questionCount = await surveyBuilderPage.getQuestionCount();
    await surveyBuilderPage.clickReviewDialogEditSurvey();
    assertTrue(await surveyBuilderPage.isReviewSurveyDetailsDialogClosed(), 'Expected "Review survey details" dialog closed after Edit survey');
    assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Expected Build Survey page shown after Edit survey');

    const normalize = (text: string) => text.replace(/\s+/g, '').replace(/\*$/, '');
    const textBefore = await surveyBuilderPage.getQuestionTextDisplay(0);
    const { questionText: npsText } = testData.surveyQuestions.nps;
    const newText = normalize(textBefore).includes(normalize(npsText)) ? testData.surveyQuestions.rating.questionText : npsText;
    await surveyBuilderPage.editQuestionText(0, newText);
    const textAfter = await surveyBuilderPage.getQuestionTextDisplay(0);
    assertTrue(textAfter.includes(newText), `Expected question 0 text to update to "${newText}", got "${textAfter}"`);
    assertTrue(normalize(textAfter) !== normalize(textBefore), `Expected question 0 text to change (before: "${textBefore}", after: "${textAfter}")`);

    await surveyBuilderPage.dismissToastIfVisible();
    await surveyBuilderPage.openPublishDialog(); // revalidates first: the footer button is back to "Validate survey"

    assertTrue(await surveyBuilderPage.isReviewSurveyDetailsDialogVisible(), 'Expected "Review survey details" dialog to reopen after the edit');
    const questionSummary = await surveyBuilderPage.getReviewDialogQuestionSummaryText();
    assertTrue(
      questionSummary.includes(String(questionCount)),
      `Expected "Review survey details" to show ${questionCount} questions, got "${questionSummary}"`
    );

    const confirmClickTime = Date.now();
    const isPublishConfirmed = await surveyBuilderPage.confirmPublish();
    assertTrue(isPublishConfirmed, 'Expected "Review survey details" dialog and "Publishing survey" status to appear');
    const isSuccessToastVisible = await surveyBuilderPage.verifyPublishSucceeded(confirmClickTime);
    assertTrue(isSuccessToastVisible, 'Expected "Survey published successfully" message after publish');
  });
}

export function registerSavedSurveyInMyAssetsTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  // FIXME: folder and survey are saved while the FMS toggle is off in the test browser, but the Surveys list is loaded with it on. Enable the toggle at the start of each flow, then re-enable this test.
  test.fixme(
    options?.title ?? 'TC_BS_10c: Saved folder and survey are listed in My assets',
    { tag: options?.tag ?? '@MyAssets' },
    async () => {
      const myAssetsPage = new MyAssetsPage(ctx.getBasePage());
      const folderName = testData.folders.newFolder;
      // TC_BS_10a saves under this name; in the Scratch flow TC_BS_02 renames the survey afterwards and later saves keep that title.
      const savedName = testData.surveyNames.saveDraftDialog;
      const editedName = testData.surveyQuestions.surveyTitle;

      await myAssetsPage.openMyAssetsPage();
      assertTrue(await myAssetsPage.isAssetVisibleByTitle(folderName), `Expected folder "${folderName}" to be listed in My assets`);

      await myAssetsPage.openFolderByTitle(folderName);
      const isSavedNameListed = await myAssetsPage.isAssetVisibleByTitle(savedName);
      const isListed = isSavedNameListed || (await myAssetsPage.isAssetVisibleByTitle(editedName));
      assertTrue(isListed, `Expected survey "${savedName}" (or "${editedName}") to be listed in folder "${folderName}"`);
    }
  );
}

export function registerReviewModeTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      await surveyBuilderPage.ensureQuestionCount(3);
      await surveyBuilderPage.enterReviewMode();

      const controlsVisible = await surveyBuilderPage.areReviewControlsVisible();
      assertTrue(controlsVisible, 'Expected Select All, Expand All, Collapse All, Delete, Exit Review Mode buttons to be visible');

      const questionCount = await surveyBuilderPage.getQuestionCount();
      const checkboxCount = await surveyBuilderPage.getReviewCheckboxCount(questionCount);
      assertTrue(checkboxCount === questionCount, `Expected one checkbox per question (${questionCount}), found ${checkboxCount}`);

      await surveyBuilderPage.selectAll();
      for (let index = 0; index < questionCount; index++) {
        assertTrue(await surveyBuilderPage.isQuestionSelected(index), `Expected checkbox ${index} to be ticked after Select All`);
      }

      await surveyBuilderPage.selectQuestionInReview(0);
      assertTrue(!(await surveyBuilderPage.isQuestionSelected(0)), 'Expected question 0 checkbox to clear after de-selecting it');
      for (let index = 1; index < questionCount; index++) {
        assertTrue(
          await surveyBuilderPage.isQuestionSelected(index),
          `Expected checkbox ${index} to remain ticked after de-selecting question 0`
        );
      }

      await surveyBuilderPage.selectAll();

      await surveyBuilderPage.unselectAll();
      for (let index = 0; index < questionCount; index++) {
        assertTrue(!(await surveyBuilderPage.isQuestionSelected(index)), `Expected checkbox ${index} to clear after Unselect All`);
      }

      await surveyBuilderPage.expandAll();
      await surveyBuilderPage.collapseAll();
      await surveyBuilderPage.exitReviewMode();

      await surveyBuilderPage.enterReviewMode();
      const questionCountBeforeDelete = await surveyBuilderPage.getQuestionCount();
      await surveyBuilderPage.selectQuestionInReview(0);
      await surveyBuilderPage.deleteSelectedQuestions();

      const questionCountAfterDelete = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        questionCountAfterDelete === questionCountBeforeDelete - 1,
        `Expected ${questionCountBeforeDelete - 1} questions after deleting one, found ${questionCountAfterDelete}`
      );
      assertTrue(
        questionCountAfterDelete >= 3,
        `Expected at least 3 questions to remain for publish (3..10 range), found ${questionCountAfterDelete}`
      );

      const questionNumbersAfterDelete = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(
        questionNumbersAfterDelete.every((number, idx) => number.trim() === `${idx + 1}.`),
        'Expected remaining questions to be renumbered sequentially'
      );

      await surveyBuilderPage.exitReviewMode();
      const questionCountAfterExit = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        questionCountAfterExit === questionCountAfterDelete,
        'Expected Build Survey view to keep the deletion after exiting Review Mode'
      );
    }
  );
}

export function registerReviewModeDeleteAllTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_27: Review Mode select all, delete all, stay on Build Survey',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      await surveyBuilderPage.enterReviewMode();
      await surveyBuilderPage.selectAll();
      await surveyBuilderPage.deleteSelectedQuestions();

      const questionCountAfterDelete = await surveyBuilderPage.getQuestionCount();
      assertTrue(questionCountAfterDelete === 0, `Expected 0 questions after deleting all, found ${questionCountAfterDelete}`);

      // Deleting ALL questions auto-closes Review Mode; only exit if it's still open.
      const exitButton = await surveyBuilderPage.isExitReviewModeButtonHidden();
      if (!exitButton) {
        await surveyBuilderPage.exitReviewMode();
      }

      const currentUrl = await surveyBuilderPage.getCurrentUrl();
      assertTrue(currentUrl.includes('build-survey'), `Expected to stay on Build Survey after delete-all, url: ${currentUrl}`);
      assertTrue(
        await surveyBuilderPage.areAddQuestionOptionsVisible(),
        'Expected Add Question options visible in the empty Build Survey state'
      );
    }
  );
}

export function registerEmptyStateTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_01: Empty Build Survey state shows Add Question options and 0 rows',
    { tag: options?.tag ?? '@BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      const questionCount = await surveyBuilderPage.getQuestionCount();
      assertTrue(questionCount === 0, `Expected 0 question rows in the empty state, found ${questionCount}`);
      assertTrue(
        await surveyBuilderPage.areAddQuestionOptionsVisible(),
        'Expected Add Question options visible in the empty Build Survey state'
      );
    }
  );
}

export function registerAddSingleChoiceQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03a: Add a Single Choice question', { tag: options?.tag ?? '@SingleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const { questionText, options: choiceOptions } = testData.surveyQuestions.singleChoice;

    await surveyBuilderPage.addSingleChoiceQuestion(questionText, choiceOptions);
  });
}

export function registerAddMultipleChoiceQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03b: Add a Multiple Choice question', { tag: options?.tag ?? '@MultipleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, options: choiceOptions } = testData.surveyQuestions.multipleChoice;

    await surveyBuilderPage.addMultipleChoiceQuestion(questionText, choiceOptions);
  });
}

export function registerAddRatingQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03c: Add a Rating question', { tag: options?.tag ?? '@RatingQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = testData.surveyQuestions.rating;

    await surveyBuilderPage.addRatingQuestion(questionText);
  });
}

export function registerAddNPSQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03d: Add an NPS question', { tag: options?.tag ?? '@NPSQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = testData.surveyQuestions.nps;

    await surveyBuilderPage.addNPSQuestion(questionText);
  });
}

export function registerAddPointScaleQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03e: Add a Point Scale question', { tag: options?.tag ?? '@PointScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = testData.surveyQuestions.pointScale;

    await surveyBuilderPage.addPointScaleQuestion(questionText, rows, columns);
  });
}

export function registerAddMultiScaleQuestionTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_03f: Add a Multi Scale question', { tag: options?.tag ?? '@MultiScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = testData.surveyQuestions.multiScale;

    await surveyBuilderPage.addMultiScaleQuestion(questionText, rows, columns);
  });
}

export interface StepperNavigationTestOptions extends BuildSurveyTestOptions {
  responseCountTestId?: string;
}

export function registerStepperNavigationTest(ctx: BuildSurveyTestContext, options?: StepperNavigationTestOptions): void {
  test(
    options?.title ?? 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey',
    { tag: options?.tag ?? '@StepperNavigation' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const selectPanelistPage = new SelectPanelistPage(ctx.getBasePage());
      const EXPECTED_RESPONSE_COUNT_TEST_ID = options?.responseCountTestId ?? 'select-response-count-250'; // Setup used click250Responses()

      try {
        await surveyBuilderPage.openAddQuestionPanel();
        const { questionText } = testData.surveyQuestions.rating;
        await surveyBuilderPage.addRatingQuestion(questionText);
        const questionNumbersBefore = await surveyBuilderPage.getQuestionNumbers();

        await surveyBuilderPage.clickSelectPanelistsStep();

        assertTrue(await selectPanelistPage.isProceedToSurveyBuilderVisible(), 'proceed-to-survey visible after stepper navigation');
        const currentUrl = await selectPanelistPage.getCurrentUrl();
        assertTrue(currentUrl.includes('select-panelist'), `URL contains select-panelist (got ${currentUrl})`);

        const selectedResponseCountTestId = await selectPanelistPage.getSelectedResponseCountDataTestId();
        assertTrue(
          selectedResponseCountTestId === EXPECTED_RESPONSE_COUNT_TEST_ID,
          `response count retained (expected ${EXPECTED_RESPONSE_COUNT_TEST_ID}, got ${selectedResponseCountTestId})`
        );
        for (const selection of datasetConfig.dimensionSelections) {
          assertTrue(
            await selectPanelistPage.isDimensionSelectionRetained(selection.dimensionTab, selection.items),
            `${selection.dimensionTab} selection retained after stepper navigation (expected to contain ${selection.items.join(', ')})`
          );
        }

        await selectPanelistPage.clickProceedToSurveyBuilder();
        assertTrue(await selectPanelistPage.isBuildSurveyPageLoaded(), 'Build Survey page visible after Proceed');

        const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
        assertTrue(
          questionNumbersAfter.length === questionNumbersBefore.length,
          `question count retained (expected ${questionNumbersBefore.length}, got ${questionNumbersAfter.length})`
        );
      } catch (error) {
        throw new Error(`Failed to verify stepper navigation retains data: ${error instanceof Error ? error.message : error}`);
      }
    }
  );
}

export function registerValidateDisabledUnderThreeTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_09: Validate survey is disabled with fewer than 3 questions',
    { tag: options?.tag ?? '@StartWithPrompt @BuildSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      await surveyBuilderPage.deleteQuestionsDownTo(2);
      const questionCount = await surveyBuilderPage.getQuestionCount();
      assertTrue(questionCount < 3, `Expected fewer than 3 questions, found ${questionCount}`);

      // Once a survey has been validated earlier, 'validateSurveyButton' is replaced by 'publishSurveyButton' ("Review & publish survey"), which should stay disabled below 3 questions too.
      const isValidateButtonVisible = await surveyBuilderPage.isValidateSurveyButtonVisible();
      const disabledState = isValidateButtonVisible
        ? await surveyBuilderPage.getValidateDisabledState()
        : await surveyBuilderPage.getPublishDisabledState();
      assertTrue(
        disabledState.disabled,
        `Expected "${isValidateButtonVisible ? 'Validate survey' : 'Review & publish survey'}" disabled with fewer than 3 questions (matchCount=${disabledState.matchCount}, innerText="${disabledState.innerText}", hostOuterHtml="${disabledState.hostOuterHtml}", innerButtonOuterHtml="${disabledState.innerButtonOuterHtml}")`
      );
    }
  );
}

export function registerSaveDraftTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_10: Save survey as draft', { tag: options?.tag ?? '@SaveDraft' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const title = `${testData.surveyNames.saveDraft}${uniqueNameSuffix()}`;
    await surveyBuilderPage.saveDraft(title);
    const isToastVisible = await surveyBuilderPage.isDraftSavedToastVisible();
    assertTrue(isToastVisible, 'Expected "Survey saved as draft successfully" toast to be visible after saving draft');
  });
}

export function registerSaveDraftEmptyTitleTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_10a: Save draft with empty title requires a survey name',
    { tag: options?.tag ?? '@SaveDraftDialog' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
      const initialQuestionCount = await surveyBuilderPage.getQuestionCount();

      await surveyBuilderPage.setSurveyTitle('');
      const titleValue = await surveyBuilderPage.getSurveyTitleValue();
      assertTrue(titleValue === '', `Expected survey title value to be empty before saving draft, got "${titleValue}"`);
      await surveyBuilderPage.commitSurveyTitle();


      await ensureAtLeastOneQuestion(surveyBuilderPage);

      await surveyBuilderPage.clickSaveDraftAndWaitForDialog();

      assertTrue(
        await surveyBuilderPage.isSaveDraftDialogVisible(),
        'Expected "Save your survey" dialog to be visible after clicking Save draft'
      );
      assertTrue(
        await surveyBuilderPage.isSaveDraftDialogValidationErrorVisible(),
        'Expected "Survey name is required." error to be visible with an empty survey name'
      );
      assertTrue(
        await surveyBuilderPage.isSaveDraftDialogSaveButtonDisabled(),
        "Expected the dialog's Save draft button to be disabled with an empty survey name"
      );

      // Cancel (covers the old TC_BS_17): the dialog closes and nothing changes, then it is reopened for the rest of the test.
      const countBeforeCancel = await surveyBuilderPage.getQuestionCount();
      await surveyBuilderPage.clickSaveDraftDialogCancel();
      assertTrue(await surveyBuilderPage.isSaveDraftDialogClosed(), 'Expected "Save your survey" dialog to be closed after Cancel');
      assertTrue(
        await new SelectPanelistPage(ctx.getBasePage()).isBuildSurveyPageLoaded(),
        'Expected Build Survey page still shown after cancelling the Save your survey dialog'
      );
      const countAfterCancel = await surveyBuilderPage.getQuestionCount();
      assertTrue(
        countAfterCancel === countBeforeCancel,
        `Expected question count unchanged after Cancel (before ${countBeforeCancel}, after ${countAfterCancel})`
      );
      await surveyBuilderPage.clickSaveDraftAndWaitForDialog();
      assertTrue(await surveyBuilderPage.isSaveDraftDialogVisible(), 'Expected "Save your survey" dialog to reopen after Cancel');

      // Create the folder first, or reuse it when a previous run already created it.
      const folderName = testData.folders.newFolder;
      if (!(await surveyBuilderPage.ensureSaveDraftDialogFolderListed(folderName))) {
        await surveyBuilderPage.clickSaveDraftDialogCreateNewFolderLink();
        assertTrue(await surveyBuilderPage.isCreateNewFolderDialogVisible(), 'Expected "Create new folder" dialog to be visible');
        await surveyBuilderPage.fillCreateNewFolderDialogName(folderName);
        await surveyBuilderPage.clickCreateNewFolderDialogCreate();

        // The app closes the Create dialog, reloads the folders and reopens "Save your survey" by itself (header Save draft is only a fallback).
        await surveyBuilderPage.waitForSaveDraftDialogAfterFolderCreate();
        assertTrue(
          await surveyBuilderPage.isSaveDraftDialogVisible(),
          'Expected "Save your survey" dialog to reopen after the folder was created'
        );
        assertTrue(
          await surveyBuilderPage.ensureSaveDraftDialogFolderListed(folderName),
          `Expected new folder "${folderName}" to be listed in the "Save your survey" dialog`
        );
      }

      const draftName = testData.surveyNames.saveDraftDialog;
      await surveyBuilderPage.fillSaveDraftDialogName(draftName);
      await surveyBuilderPage.clickSaveDraftDialogFolder(folderName);
      assertTrue(
        !(await surveyBuilderPage.isSaveDraftDialogSaveButtonDisabled()),
        `Expected the dialog's Save draft button to be enabled after entering a name and selecting "${folderName}"`
      );

      await surveyBuilderPage.clickSaveDraftDialogSaveButton();

      const isToastVisible = await surveyBuilderPage.isDraftSavedToastVisible();
      assertTrue(isToastVisible, 'Expected "Survey saved as draft successfully" toast to be visible after saving draft');

      const titleAfterSave = await surveyBuilderPage.getSurveyTitleDisplay();
      assertTrue(titleAfterSave === draftName, `Expected survey title to update to "${draftName}" after saving draft, got "${titleAfterSave}"`);

      // TC_BS_03a (next registered test) assumes a 0-question empty state, so undo the question added above.
      // Skipped when questions already existed (e.g. AI-generated) so real questions are not deleted.
      if (initialQuestionCount === 0) {
        await surveyBuilderPage.deleteQuestionAt(0);
      }
    }
  );
}

export function registerValidateSurveyTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(
    options?.title ?? 'TC_BS_23: Validate survey: Completes and shows Optiq feedback when there are recommendations',
    { tag: options?.tag ?? '@ValidateSurvey' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());

      await surveyBuilderPage.ensureQuestionCount(3);

      await surveyBuilderPage.clickValidateSurvey();
      await surveyBuilderPage.waitForValidationComplete();

      assertTrue(
        await surveyBuilderPage.isValidationCompleted(),
        'Expected "Validate survey" to be replaced by "Review & publish survey" after validation'
      );

      const hasRecommendations = await surveyBuilderPage.isRecommendationTagVisible();
      if (hasRecommendations) {
        assertTrue(
          await surveyBuilderPage.isViewOptiqFeedbackLinkVisible(),
          'Expected "View Optiq feedback" link when recommendations are shown'
        );
      }
    }
  );
}

export function registerOptionBoundaryTest(ctx: BuildSurveyTestContext, options?: BuildSurveyTestOptions): void {
  test(options?.title ?? 'TC_BS_04: Options boundary - min 2, max 15', { tag: options?.tag ?? '@OptionBoundary' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(ctx.getBasePage());
    const { questionText, options: choiceOptions } = testData.surveyQuestions.singleChoice;

    const questionIndex = await surveyBuilderPage.getQuestionCount();
    if (!(await surveyBuilderPage.areAddQuestionOptionsVisible())) {
      await surveyBuilderPage.clickAddQuestion();
    }
    await surveyBuilderPage.addSingleChoiceQuestion(questionText, choiceOptions.slice(0, 2));
    await surveyBuilderPage.openQuestionForEditing(questionIndex);

    assertTrue((await surveyBuilderPage.getOptionCount()) === 2, 'Expected 2 options on a new Single Choice question');
    assertTrue((await surveyBuilderPage.getRemoveOptionIconCount()) === 0, 'Expected no remove (X) icons at the 2-option minimum');

    await surveyBuilderPage.addOptionToQuestion();
    assertTrue((await surveyBuilderPage.getOptionCount()) === 3, 'Expected 3 options after adding one');
    assertTrue((await surveyBuilderPage.getRemoveOptionIconCount()) >= 1, 'Expected remove (X) icons to appear with more than 2 options');

    await surveyBuilderPage.removeLastOption();
    assertTrue((await surveyBuilderPage.getOptionCount()) === 2, 'Expected 2 options after removing the added one');
    assertTrue((await surveyBuilderPage.getRemoveOptionIconCount()) === 0, 'Expected no remove (X) icons back at the 2-option minimum');

    for (let i = 0; i < 12; i++) {
      await surveyBuilderPage.addOptionToQuestion();
    }
    const optionCountAt14 = await surveyBuilderPage.getOptionCount();
    assertTrue(optionCountAt14 === 14, `Expected 14 options, found ${optionCountAt14}`);

    await surveyBuilderPage.addOptionToQuestion();
    const optionCountAt15 = await surveyBuilderPage.getOptionCount();
    assertTrue(optionCountAt15 === 15, `Expected 15 options, found ${optionCountAt15}`);

    assertTrue(await surveyBuilderPage.isAddOptionDisabled(), 'Expected Add option disabled at the 15-option maximum');
    assertTrue(await surveyBuilderPage.isMaxOptionsTooltipVisibleOnHover(), 'Expected max-options tooltip on Add option hover');

    const optionCountAfterMax = await surveyBuilderPage.getOptionCount();
    assertTrue(optionCountAfterMax === 15, `Expected option count to stay 15, found ${optionCountAfterMax}`);

    // The blank options cannot be saved; discard instead.
    await surveyBuilderPage.clickDiscardChanges();
    assertTrue(!(await surveyBuilderPage.isEditorOpen()), 'Expected editor closed after Discard changes');
  });
}
