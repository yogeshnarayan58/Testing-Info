import { defineConfig, devices } from '@playwright/test';
import * as dotenv from 'dotenv';
import path from 'path';
import { WaitForLoadStateOptions } from './src/lib/constants/optional-parameter-types';
import { MAX_TEST_TIMEOUT, NAVIGATION_TIMEOUT, RUN_TEST_TIMEOUT } from './src/lib/constants/time-out-constants';
import { config as frameworkConfig } from './src/lib/playwright/config';
import { getLambdaTestBuildName } from './src/lib/common/utils/configurationDetails';

// Read from ".env" file.

dotenv.config({ path: path.join(__dirname, '.env') });

const isLambdaTest = process.env.LAMBDATEST === 'true';
// LambdaTest environment variables
const ltUser = process.env.LAMBDATEST_USERNAME || process.env.LT_USERNAME;
const ltAccessKey = process.env.LAMBDATEST_ACCESS_KEY || process.env.LT_ACCESS_KEY;
const ltProject = process.env.LT_PROJECT || 'OMNI Discover';
const ltBuild = process.env.LT_BUILD || 'Discover build';
const ltBuildIdentifier =
  process.env.LT_BUILD_IDENTIFIER ||
  process.env.BUILD_NUMBER ||
  process.env.GITHUB_RUN_NUMBER ||
  undefined;

const ltVideo = process.env.LT_VIDEO ? process.env.LT_VIDEO === 'true' : true;
const ltNetwork = process.env.LT_NETWORK ? process.env.LT_NETWORK === 'true' : false;
const ltConsole = process.env.LT_CONSOLE ? process.env.LT_CONSOLE === 'true' : false;
const ltResolution = process.env.LT_RESOLUTION || process.env.LAMBDATEST_RESOLUTION;

const ltIdleTimeout = process.env.LT_IDLE_TIMEOUT
  ? Number(process.env.LT_IDLE_TIMEOUT)
  : 300;

const ltWorkers = process.env.LT_WORKERS ? Number(process.env.LT_WORKERS) : 1;

const requestedLocalBrowser = (process.env.BROWSER || process.env.PW_BROWSER || 'chromium')
  .trim()
  .toLowerCase();

const localProject = (() => {
  switch (requestedLocalBrowser) {
    case 'firefox':
      return {
        name: 'firefox',
        use: {
          browserName: 'firefox' as const,
          viewport: null,
        },
      };
    case 'webkit':
      return {
        name: 'webkit',
        use: {
          browserName: 'webkit' as const,
          viewport: null,
        },
      };
    case 'edge':
    case 'msedge':
    case 'microsoft-edge':
      return {
        name: 'Microsoft Edge',
        use: {
          channel: 'msedge' as const,
          viewport: null,
          launchOptions: {
            args: ['--start-maximized'],
          },
        },
      };
    case 'chrome':
    case 'google-chrome':
      return {
        name: 'Google Chrome',
        use: {
          channel: 'chrome' as const,
          viewport: null,
          launchOptions: {
            args: ['--start-maximized'],
          },
        },
      };
    default:
      return {
        name: 'chromium',
        use: {
          viewport: null,
          launchOptions: {
            args: ['--start-maximized'],
          },
        },
      };
  }
})();

const requestedLtBrowser = (process.env.LT_BROWSER || process.env.LAMBDATEST_BROWSER || 'chromium')
  .trim()
  .toLowerCase();

const lambdaBrowserName: 'chromium' | 'firefox' | 'webkit' =
  requestedLtBrowser === 'firefox' || requestedLtBrowser === 'webkit'
    ? requestedLtBrowser
    : 'chromium';

const lambdaProjectName = `lambdatest-${lambdaBrowserName}`;
const lambdaPlaywrightBrowserName = `pw-${lambdaBrowserName}`;

console.log('isLambdaTest =', isLambdaTest);
console.log('LAMBDATEST env var =', process.env.LAMBDATEST);

if (isLambdaTest) {

  console.log('\n🌐 LambdaTest Cloud Execution Enabled');
  console.log('   User:', ltUser);
  console.log('   Project:', ltProject);
  console.log('   Workers:', ltWorkers);

  if (!ltUser || !ltAccessKey) {
    throw new Error(
      'LambdaTest credentials missing! Please set LAMBDATEST_USERNAME/LT_USERNAME and LAMBDATEST_ACCESS_KEY/LT_ACCESS_KEY'
    );
  }
}

export const LOADSTATE: WaitForLoadStateOptions = 'domcontentloaded';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
export default defineConfig({
  testDir: './src/lib/tests/reports',
  /* Run tests in files in parallel */
  fullyParallel: true,

  timeout: isLambdaTest ? RUN_TEST_TIMEOUT : MAX_TEST_TIMEOUT,

  globalSetup: require.resolve('./src/lib/common/utils/global-setup'),
  globalTeardown: require.resolve('./src/lib/playwright/setup/globalTeardown'),
  
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,

  // LambdaTest runs should be minimal workers to avoid session conflicts
  workers: isLambdaTest ? ltWorkers : process.env.CI ? 1 : 2,

  reporter: process.env.CI
    ? [
        ['list'],
        ['json', { outputFile: 'playwright-report/test-results.json' }],
        ['allure-playwright', { outputFolder: 'allure-results' }],
        ...(isLambdaTest ? [['./src/lib/playwright/reporters/lt-session-reporter.ts'] as const] : []),
        [
          './src/lib/playwright/grafana-reporter.ts',
          {
            areaName: process.env.AREA_NAME || 'TestArea',
            domainName: process.env.DOMAIN_NAME || 'TechTest',
            teamName: process.env.TEAM_NAME || 'DiscoverOmniTest',
            projectName: process.env.PROJECT_NAME || 'GTATesting'
          }
        ]
      ]
    : [
        ['list'],
        ['allure-playwright', { outputFolder: 'allure-results' }],
        ...(isLambdaTest ? [['./src/lib/playwright/reporters/lt-session-reporter.ts'] as const] : [])
      ],

  use: {
    trace: 'on-first-retry',
    navigationTimeout: NAVIGATION_TIMEOUT,
    baseURL: frameworkConfig.BASE_URL,
    viewport: null
  },

  /* Configure one browser project per run to avoid test count multiplication */
  projects: isLambdaTest
    ? [
        {
          name: lambdaProjectName,
          use: {
            browserName: lambdaBrowserName,
            headless: true,
            viewport: null,
            baseURL: frameworkConfig.BASE_URL,

            connectOptions: {
              wsEndpoint: `wss://cdp.lambdatest.com/playwright?capabilities=${encodeURIComponent(
                JSON.stringify({
                  browserName: lambdaPlaywrightBrowserName,
                  browserVersion: 'latest',

                  'LT:Options': {
                    platform: 'Windows 11',

                    // Build name should include identifier so you can track correctly
                    build: getLambdaTestBuildName(ltBuild, ltBuildIdentifier),

                    name: 'Playwright Automation',

                    user: ltUser,
                    accessKey: ltAccessKey,

                    project: ltProject,

                    network: ltNetwork,
                    video: ltVideo,
                    console: ltConsole,
                    ...(ltResolution ? { resolution: ltResolution } : {}),

                    plugin: 'playwright-test',
                    w3c: true,
                    idleTimeout: ltIdleTimeout
                  }
                })
              )}`
            }
          }
        }
      ]
    : [localProject]

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://127.0.0.1:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});