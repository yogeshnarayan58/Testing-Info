import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { IconModule, TagModule, TooltipModule } from '@nielseniq/athena-core';
import { SurveyGridRow } from '../../models/survey-asset.model';
import { SurveyStatusType } from '../../../build-survey/models/build-survey';
import { isFolderAsset } from '../../utils/survey-status.util';
import { SurveyAvatarComponent } from '../../../../shared/components/survey-avatar/survey-avatar.component';
import { SURVEY_ACCESS_AVAILABILITY } from '../../constants/survey-status.constant';

@Component({
  selector: 'survey-details',
  standalone: true,
  imports: [DatePipe, IconModule, TagModule, TooltipModule, SurveyAvatarComponent],
  templateUrl: './survey-details.component.html',
  styleUrl: './survey-details.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyDetailsComponent {
  readonly survey = input.required<SurveyGridRow>();
  readonly isFolder = computed(() => isFolderAsset(this.survey()));
  readonly isClosed = computed(() => this.survey().status?.toUpperCase() === SurveyStatusType.CLOSED);
  readonly isDraft = computed(() => this.survey().status?.toUpperCase() === SurveyStatusType.DRAFT);
  readonly canShare = computed(() => this.isFolder() || this.isClosed());
  readonly createdDate = computed(() => this.validDate(this.survey().initialCreationTimestamp ?? this.survey().initialCreation));
  readonly publishedDate = computed(() => this.validDate(this.survey().publishedTimestamp));
  readonly location = computed(() => {
    const ancestors: string[] = [];
    let parent = this.survey().parentAsset;
    while (parent) {
      if (parent.title) {
        ancestors.unshift(parent.title);
      }
      parent = parent.parentAsset;
    }
    return ancestors.join(' / ') || 'My assets';
  });
  readonly owners = computed(() => this.people([SURVEY_ACCESS_AVAILABILITY.OWNED]));
  readonly sharedWith = computed(() => {
    const ownerIds = new Set(this.owners().map((person) => person.id));
    return this.people([
      SURVEY_ACCESS_AVAILABILITY.EDIT,
      SURVEY_ACCESS_AVAILABILITY.VIEW,
      SURVEY_ACCESS_AVAILABILITY.STRICT_VIEW,
    ]).filter((person) => !ownerIds.has(person.id));
  });
  readonly responses = computed(() => {
    const { responsesCollected, responseTarget } = this.survey();
    if (responsesCollected == null) {
      return '--';
    }
    if (responseTarget == null || responseTarget <= 0) {
      return String(responsesCollected);
    }
    return `${responsesCollected}/${responseTarget} (${Math.round(responsesCollected / responseTarget * 100)}%)`;
  });

  private validDate(value: number | string | undefined): Date | null {
    if (value == null || value === '') {
      return null;
    }
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  private people(availabilities: readonly string[]): Array<{ id: string; name: string; isGroup: boolean }> {
    const people = new Map<string, { id: string; name: string; isGroup: boolean }>();
    const rights = this.survey().rights ?? [];
    for (const right of rights) {
      if (!right.availability || !availabilities.includes(right.availability)) {
        continue;
      }
      const userId = right.userId?.trim();
      const orderManagementId = right.orderManagementId?.trim() || right.orderManagementInfo?.id?.trim();
      if (!userId && !orderManagementId) {
        continue;
      }
      const orderManagementType = right.orderManagementType || right.orderManagementInfo?.type || '';
      const id = userId || `order-management:${orderManagementType}:${orderManagementId}`;
      const displayName = (userId
        ? right.userInfo?.displayName?.trim()
        : right.orderManagementInfo?.displayName?.trim())
        || right.displayName?.trim()
        || userId
        || orderManagementId
        || id;
      const isGroup = !userId && (orderManagementType === 'COG' || orderManagementType === 'ORGANIZATION');
      people.set(id, { id, name: displayName, isGroup });
    }
    return [...people.values()];
  }
}