import { FullConfig } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';
import { LoginPage } from '../page-objects/common/login.page';
import { BasePageFactory } from '../utils/base-page-factory';
import { envConfig } from '../config/env.config';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const AUTH_FILE_PATH = path.resolve(__dirname, '../storage/auth.json');

async function globalSetup(config: FullConfig): Promise<void> {
  let basePage: BasePage | null = null;
  try {
    console.log('Starting global setup...');

    if (fs.existsSync(AUTH_FILE_PATH)) {
      fs.unlinkSync(AUTH_FILE_PATH);
      console.log('Old authentication state deleted.');
    }

    const storageDir = path.dirname(AUTH_FILE_PATH);
    if (!fs.existsSync(storageDir)) {
      fs.mkdirSync(storageDir, { recursive: true });
    }

    const baseURL = envConfig.BASE_URL;
    const username = process.env.USER_NAME || '';
    const password = process.env.PASS_WORD || '';

    console.log(`Logging in to ${baseURL}...`);
    basePage = await BasePageFactory.createBasePage();

    const loginPage = new LoginPage(basePage);
    await loginPage.login(baseURL, username, password);

    console.log('Authentication successful. New auth state created.');
  } catch (error) {
    console.error('Global setup failed:', error);
    if (error instanceof Error) {
      throw new Error(`Global setup failed: ${error.message}`);
    }
    throw new Error('Global setup failed with an unknown error');
  } finally {
    // Auth state is persisted to storage/auth.json, browser will close naturally
    if (basePage) {
      console.log('Global setup completed. Auth state saved.');
    }
  }
}

export default globalSetup;