
import { toObservable, toSignal, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, OnDestroy, inject, signal, ViewChild } from '@angular/core';
import { createAction, Store } from '@ngrx/store';
import { BreadcrumbModule, ButtonModule, CardModule, IconModule, IconButtonModule, ItemModule, MenuModule, ToastService, DialogModule, LinkModule, TabModule, CheckboxModule, TagModule, TooltipModule, SpinnerModule } from '@nielseniq/athena-core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { SurveyAssetApiService } from '../services/survey-asset-api.service';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { DialogsModule, CreateFolderComponent } from '@nielsen/crf-ui-components';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MomentModule } from 'ngx-moment';
import { Moment, duration } from 'moment';
import { ASSET_TYPE, EMPTY_VALUE_PLACEHOLDER, getAssetCatalogCacheTag, LAST_UPDATED_MINUTES_THRESHOLD, MY_ASSETS_EMPTY_STATES, MY_ASSETS_FOLDER_BREADCRUMB_TABS, MY_ASSETS_TABS, MY_ASSETS_TABS_LIST, MyAssetsTabId, REFRESH_BUTTON_HIDE_MS, SurveyGridActionType } from '../constants/my-assets-tabs.constant';
import { RightsUtilityService, UserService, CrfLpCommonModule, GridDataSourceService, InfiniteGridComponent, Asset } from '@nielsen/crf-lp-common';
import { SurveyGridRow, SurveyGridRowsLoadedEvent } from '../models/survey-asset.model';
import { SurveyGridHandlerService } from '../services/survey-grid-handler.service';
import { SURVEY_GRID_COLUMNS } from './survey-grid-columns.config';
import { isFolderAsset } from '../utils/survey-status.util';
import { formatSurveyDate } from '../../../shared/utils/survey-date.util';
import { MyAssetsEmptyStateComponent } from './my-assets-empty-state/my-assets-empty-state.component';
import { CommonSidePanelComponent } from '../../../shared/components/common-side-panel/common-side-panel.component';
import { SurveyDetailsComponent } from './survey-details/survey-details.component';
import { SurveyActionItemsComponent } from '../../../shared/components/survey-action-items/survey-action-items.component';
import { SurveyActionItem, SurveyActionItemClickEvent } from '../../../shared/components/survey-action-items/survey-action-items.model';
import { getMyAssetsSelectionActions, MyAssetsSelectionActionId } from '../constants/my-assets-selection-actions.constant';
import { SurveyAssetActionDialogsComponent } from './survey-asset-action-dialogs/survey-asset-action-dialogs.component';
import { catchError, map, of, startWith, switchMap } from 'rxjs';
import { ApiService } from '../../../shared/services/api.service';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';

interface SurveyDetailsState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  survey?: SurveyGridRow;
}
import { getMyAssetsFolderUrl, getMyAssetsTabUrl } from '../utils/my-assets-route.util';

const CANCEL_REQUEST = createAction('CANCEL_REQUEST');

@Component({
  selector: 'survey-my-assets-page',
  standalone: true,
  imports: [CommonSidePanelComponent, ButtonModule, SurveyDetailsComponent, SurveyActionItemsComponent, SurveyAssetActionDialogsComponent, MyAssetsEmptyStateComponent, BreadcrumbModule, SpinnerModule, CardModule, IconModule, TooltipModule, TagModule, CheckboxModule, IconButtonModule, ItemModule, MenuModule, CrfLpCommonModule, DialogModule, CommonModule, DialogsModule, LinkModule, TabModule, TranslateModule, MomentModule],
  providers: [
    { provide: GridDataSourceService, useExisting: SurveyGridHandlerService },
    TranslateService
  ],
  templateUrl: './my-assets-page.component.html',
  styleUrl: './my-assets-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyAssetsPageComponent implements OnDestroy {
  readonly tabs = MY_ASSETS_TABS_LIST;
  readonly SURVEY_FMS_TABS = MY_ASSETS_TABS;
  readonly gridService = inject(SurveyGridHandlerService);
  private readonly store = inject(Store<unknown>);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly translate = inject(TranslateService);
  private readonly surveyCommonService = inject(SurveyCommonService);
  private readonly surveyAssetApi = inject(SurveyAssetApiService);
  private readonly toastService = inject(ToastService);
  private readonly api = inject(ApiService);
  private readonly environment = inject(EnvironmentConfig);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly rightsUtility = inject(RightsUtilityService);
  private readonly userId = toSignal(inject(UserService).getUserData().pipe(map((user) => user.id)));
  readonly selectedSurvey = signal<SurveyGridRow | null>(null);
  readonly detailsState = toSignal(toObservable(this.selectedSurvey).pipe(
    switchMap((row) => row
      ? this.surveyAssetApi.fetchSurveyDetails(row).pipe(
          map((survey): SurveyDetailsState => ({ status: 'ready', survey })),
          catchError(() => of<SurveyDetailsState>({ status: 'error' })),
          startWith<SurveyDetailsState>({ status: 'loading' })
        )
      : of<SurveyDetailsState>({ status: 'idle' }))
  ), { initialValue: { status: 'idle' } as SurveyDetailsState });
  private readonly destroyRef = inject(DestroyRef);
  activeTabId = this.getActiveTabId();
  readonly gridColumns = SURVEY_GRID_COLUMNS;
  readonly rowSelectionConfig = {
    selectionType: 'multiple',
    rowMultiSelectWithClick: true,
  };
  readonly isFolderAsset = isFolderAsset;
  readonly EMPTY_VALUE_PLACEHOLDER = EMPTY_VALUE_PLACEHOLDER;
  readonly showEmptyState = signal(false);
  readonly lastUpdated = signal<number | null>(null);
  readonly showRefreshButton = signal(true);
  readonly isRefreshing = signal(false);
  private refreshButtonTimeoutId?: ReturnType<typeof setTimeout>;
  /**
   * Formatter for `amTimeAgo` that keeps minutes until 59 using per-call thresholds,
   * so Moment's global relative-time configuration shared with the host app is never mutated.
   */
  readonly formatLastUpdated = (value: Moment): string =>
    duration(value.diff(Date.now())).humanize(true, { m: LAST_UPDATED_MINUTES_THRESHOLD });
  readonly folderBreadcrumbs = signal<Array<{ label: string; url: string }>>([]);
  readonly activeFolderId = signal<string | null>(null);
  readonly folderBreadcrumbTabs = MY_ASSETS_FOLDER_BREADCRUMB_TABS;
  readonly emptyState = MY_ASSETS_EMPTY_STATES[this.activeTabId];
  readonly selectedRows = signal<SurveyGridRow[]>([]);
  get selectionActions() {
    // Hide Delete, Delete permanently and Restore until their API integration is ready.
    return getMyAssetsSelectionActions(this.activeTabId, this.userId(), this.rightsUtility)
      .filter((action) => action.id !== 'delete' && action.id !== 'restore');
  }
  private selectedRowIds = new Set<string>();
  private readonly selectionActionHandlers: Record<MyAssetsSelectionActionId, (rows: readonly SurveyGridRow[]) => void> = {
    'open-new-tab': ([row]) => this.gridService.onMenuAction({ optionType: 'open-new-tab', row }),
    info: ([row]) => this.toggleDetails(row),
    duplicate: ([row]) => this.gridService.onMenuAction({ optionType: 'duplicate', row }),
    move: (rows) => this.assetActionDialogs?.openMove(rows),
    rename: ([row]) => this.assetActionDialogs?.openRename(row),
    share: () => undefined,
    export: () => undefined,
    // Pending API integration; retain the wiring for re-enabling these actions.
    // delete: (rows) => this.activeTabId === MY_ASSETS_TABS.TRASH
    //   ? this.assetActionDialogs?.openDeletePermanently(rows)
    //   : this.assetActionDialogs?.openDelete(rows),
    // restore: (rows) => this.assetActionDialogs?.restore(rows)
    delete: () => undefined,
    restore: () => undefined,
  };

  /** Row the grid's right-click (context) menu is currently targeting; `null` while the menu is closed. */
  readonly contextMenuRow = signal<SurveyGridRow | null>(null);
  readonly contextMenuPosition = signal<{ x: number; y: number }>({ x: 0, y: 0 });
  /**
   * Drives `niq-menu`'s `[opened]` input. The menu element itself stays in the template
   * permanently (see the template comment); only this flag toggles, so the same `niq-menu`
   * instance - and its underlying CDK overlay - is reused and reopened on every right-click
   * instead of being destroyed/recreated, matching the Landing Page reference's persistent menu.
   */
  readonly contextMenuOpen = signal(false);
  /**
   * Actions shown in the right-click menu, filtered through the same `isVisible` predicates the
   * toolbar uses for a single-row selection, so visibility/permission rules stay byte-for-byte identical.
   */
  get contextMenuActions(): readonly SurveyActionItem<SurveyGridRow, MyAssetsSelectionActionId>[] {
    const row = this.contextMenuRow();
    if (!row) {
      return [];
    }
    return this.selectionActions.filter((action) => action.isVisible?.([row]) ?? true);
  }

  @ViewChild('createFolderDialog') createFolderDialog?: CreateFolderComponent;
  @ViewChild(SurveyAssetActionDialogsComponent) assetActionDialogs?: SurveyAssetActionDialogsComponent;
  private grid?: InfiniteGridComponent<SurveyGridRow[]>;

  @ViewChild('surveyGrid')
  set surveyGrid(grid: InfiniteGridComponent<SurveyGridRow[]> | undefined) {
    this.grid = grid;
    if (grid) {
      grid.infiniteInitialRowCount = this.gridService.pageSize;
      if (grid.agGrid?.api) {
        grid.agGrid.api.setGridOption('infiniteInitialRowCount', this.gridService.pageSize);
      }
    }
  }

  get surveyGrid(): InfiniteGridComponent<SurveyGridRow[]> | undefined {
    return this.grid;
  }

  constructor() {
    this.destroyRef.onDestroy(() => clearTimeout(this.refreshButtonTimeoutId));

    this.gridService.rowsLoaded$
      .pipe(takeUntilDestroyed())
      .subscribe((event) => this.onRowsLoaded(event));

    this.gridService.rowUpdated$
      .pipe(takeUntilDestroyed())
      .subscribe(({ action }) => {
        this.resetRefreshState();
        this.cdr.markForCheck();
        // refresh the grid when a row's favorite status changes in the favorite tab's grid.
        if (action === 'favorite' && this.activeTabId === MY_ASSETS_TABS.MY_FAVORITES) {
          this.refreshGrid();
        }
      });

    this.gridService.deleteRequested$
      .pipe(takeUntilDestroyed())
      .subscribe((row) => this.selectionActionHandlers.delete([row]));

    if (this.route.paramMap) {
      this.route.paramMap.pipe(takeUntilDestroyed()).subscribe((params) => this.onFolderRouteChange(params.get('folderId')));
    } else {
      this.onFolderRouteChange(this.route.snapshot.paramMap?.get('folderId') ?? null);
    }
  }

  /** Clears AG Grid's loading state while preserving the common grid's no-rows overlay. */
  onShowGridFlag(hasRows: boolean): void {
    this.showEmptyState.set(!hasRows && !this.gridService.loadFailed);
    if (!hasRows) {
      this.surveyGrid?.agGrid?.api?.setGridOption('loading', false);
    }
  }

  onTabChange(tabId: MyAssetsTabId): void {
    const tab = this.tabs.find((tab: { id: string }) => tab.id === tabId);
    if (!tab || tab.id === this.activeTabId) {
      return;
    }

    void this.router.navigateByUrl(getMyAssetsTabUrl(this.router.url, tab.id));
  }

  // Navigates to a breadcrumb level and preserves breadcrumb state for deeper folder routes.
  onFolderBreadcrumbClick(item: { label: string; url: string }): void {
    if (!item.url || item.url === this.currentFolderUrl()) {
      return;
    }
    const breadcrumbIndex = this.folderBreadcrumbs().findIndex((breadcrumb) => breadcrumb.url === item.url);
    const folderId = this.getFolderIdFromUrl(item.url);
    if (!folderId) {
      void this.router.navigateByUrl(item.url);
      return;
    }
    const folderBreadcrumbs = breadcrumbIndex >= 0
      ? this.folderBreadcrumbs().slice(0, breadcrumbIndex + 1)
      : undefined;
    void this.router.navigateByUrl(getMyAssetsFolderUrl(this.router.url, this.activeTabId, folderId), {
      state: { folderBreadcrumbs },
    });
  }

  // Shows breadcrumbs only when a folder route is active on tabs that support folder hierarchy.
  shouldShowFolderBreadcrumb(): boolean {
    return !!this.activeFolderId() && this.folderBreadcrumbTabs.includes(this.activeTabId);
  }

  /** Asks the infinite grid to discard its row blocks and request fresh data. */
  refreshGrid(): void {
    if (!this.surveyGrid && this.showEmptyState()) {
      this.showEmptyState.set(false);
      this.cdr.detectChanges();
    }
    this.surveyGrid?.refreshData();
  }

  /** Disables Refresh while the grid reloads; the API result decides what is shown next. */
  onRefresh(): void {
    if (this.isRefreshing() || this.gridService.isLoading()) {
      return;
    }
    this.isRefreshing.set(true);
    this.api.clearCache(
      this.environment.apiUrls.assetCatalogDiscovery,
      getAssetCatalogCacheTag(this.activeTabId, this.activeFolderId())
    );
    this.gridService.viewUpdatedAt.delete(this.router.url);
    this.refreshGrid();
  }

  /**
   * Tracks grid freshness. Only current-view loads (initial, tab/folder/sort change, Refresh) reset the
   * timestamp and hide period; pagination leaves cached rows untouched, so a successful page load is ignored.
   * Any failure re-enables Refresh so the user can recover.
   */
  private onRowsLoaded({ success, loadType }: SurveyGridRowsLoadedEvent): void {
    if (success && loadType === 'pagination') {
      return;
    }
    this.isRefreshing.set(false);
    if (success) {
      const visitedAt = this.gridService.viewUpdatedAt.get(this.router.url);
      if (visitedAt !== undefined) {
        this.lastUpdated.set(visitedAt);
        const remainingHideMs = REFRESH_BUTTON_HIDE_MS - (Date.now() - visitedAt);
        clearTimeout(this.refreshButtonTimeoutId);
        this.refreshButtonTimeoutId = undefined;
        if (remainingHideMs > 0) {
          this.hideRefreshButtonForTime(remainingHideMs);
        } else {
          this.showRefreshButton.set(true);
        }
        return;
      }
      this.markViewUpdated();
    } else {
      if (loadType !== 'pagination') {
        this.gridService.viewUpdatedAt.delete(this.router.url);
      }
      clearTimeout(this.refreshButtonTimeoutId);
      this.refreshButtonTimeoutId = undefined;
      this.showRefreshButton.set(true);
    }
  }

  private markViewUpdated(): void {
    const updatedAt = Date.now();
    this.gridService.viewUpdatedAt.set(this.router.url, updatedAt);
    this.lastUpdated.set(updatedAt);
    this.hideRefreshButtonForTime(REFRESH_BUTTON_HIDE_MS);
  }

  /** Shows "Updated just now" in place of the Refresh button until the given time has passed. */
  private hideRefreshButtonForTime(time: number): void {
    this.showRefreshButton.set(false);
    clearTimeout(this.refreshButtonTimeoutId);
    this.refreshButtonTimeoutId = setTimeout(() => {
      this.refreshButtonTimeoutId = undefined;
      this.showRefreshButton.set(true);
    }, time);
  }

  onInfiniteGridSelectionChange(rows: SurveyGridRow[]): void {
    this.selectedRows.set(rows ?? []);
    this.selectedRowIds = new Set(this.selectedRows().map((row) => row.assetId));
    // The info panel belongs to a selected row, so close it when that row is deselected.
    const detailsRow = this.selectedSurvey();
    if (detailsRow && !this.selectedRowIds.has(detailsRow.assetId)) {
      this.closeDetails();
    }
  }

  /** Clears the grid selection and syncs local selection state (which also closes the info panel). */
  deselectAllRows(): void {
    this.surveyGrid?.agGrid?.api?.deselectAll();
    this.onInfiniteGridSelectionChange([]);
  }

  onSelectionAction(event: SurveyActionItemClickEvent<SurveyGridRow, MyAssetsSelectionActionId>): void {
    if (!event.items.length) {
      return;
    }
    this.selectionActionHandlers[event.actionId](event.items);
  }

  /** Uses the clicked row without changing selection; niq-menu handles viewport fitting. */
  onGridContextMenu(params: { event?: MouseEvent; data?: SurveyGridRow }): void {
    const row = params?.data;
    const event = params?.event;
    if (!row || !event) {
      return;
    }
    event.preventDefault();
    this.contextMenuPosition.set({ x: event.clientX, y: event.clientY });
    this.contextMenuRow.set(row);
    this.contextMenuOpen.set(true);
  }

  /**
   * Keep the clicked row because niq-menu may clear its state before dispatch.
   * The template stops click propagation: without zone event coalescing (e.g. in a host app),
   * the side panel would open and then immediately close from its document outside-click listener.
   */
  onContextMenuAction(actionId: MyAssetsSelectionActionId, row: SurveyGridRow): void {
    this.closeContextMenu();
    this.onSelectionAction({ actionId, items: [row] });
  }

  /** Bound to the menu's `(openedChange)`; closes local state when the menu is dismissed (e.g. outside click). */
  onContextMenuOpenedChange(opened: boolean): void {
    if (!opened) {
      this.closeContextMenu();
    }
  }

  closeContextMenu(): void {
    this.contextMenuOpen.set(false);
    this.contextMenuRow.set(null);
  }

  onAssetsChanged(): void {
    this.api.clearCache(this.environment.apiUrls.assetCatalogDiscovery);
    this.deselectAllRows();
    this.resetRefreshState();
    this.refreshGrid();
  }

  private resetRefreshState(): void {
    // Mutations can affect other tabs and folders, not only the current view.
    this.gridService.viewUpdatedAt.clear();
    this.markViewUpdated();
  }

  isRowSelected(row: SurveyGridRow): boolean {
    return this.selectedRowIds.has(row.assetId);
  }

  showRowSelectionCheckbox(): boolean {
    return this.activeTabId !== MY_ASSETS_TABS.RECENT
      && this.activeTabId !== MY_ASSETS_TABS.MY_FAVORITES;
  }

  formatResponses(row: SurveyGridRow): string {
    return '--';
  }

  formatPublishedDate(value?: number): string {
    return formatSurveyDate(value, EMPTY_VALUE_PLACEHOLDER );
  }

  onAssetTitleKey(event: Event, row: SurveyGridRow): void {
    event.preventDefault();
    event.stopPropagation();
    // Space prevents scrolling on keydown and activates on keyup, like a native button.
    if (event instanceof KeyboardEvent && event.key === ' ' && event.type === 'keydown') {
      return;
    }
    this.onGridRowAction('open', row);
  }

  onGridRowAction(optionType: SurveyGridActionType, row: SurveyGridRow): void {
    if (optionType === 'info') {
      this.toggleDetails(row);
      return;
    }
    this.gridService.onMenuAction({ optionType, row });
  }

  /**
   * Opens the info panel for a row and selects it, or closes the panel and deselects the row
   * when its panel is already open (mirrors the Landing Page info toggle).
   */
  toggleDetails(row: SurveyGridRow): void {
    const isOpen = this.isDetailsOpenFor(row);
    this.surveyGrid?.agGrid?.api?.getRowNode(row.assetId)?.setSelected(!isOpen);
    this.selectedSurvey.set(isOpen ? null : row);
  }

  isDetailsOpenFor(row: SurveyGridRow): boolean {
    return this.selectedSurvey()?.assetId === row.assetId;
  }

  closeDetails(): void {
    this.selectedSurvey.set(null);
  }

  navigateToSelectPanelist(): void {
    this.surveyCommonService.resetState();
    this.router.navigate(['/survey/select-panelist']);
  }

  /** Called when my assets is empty and the empty state action button "Create a survey"  is clicked. */
  onEmptyStateAction(route: string): void {
    this.surveyCommonService.resetState();
    void this.router.navigateByUrl(route);
  }

  navigateToAiflow(): void {
    this.surveyCommonService.resetState();
    this.router.navigate(['/survey/aiflow/select-panelist']);
  }

  openCreateFolderDialog(): void {
    this.createFolderDialog?.resetForm();
    this.createFolderDialog?.open();
  }

  onCreateFolderSave(event: { title: string }): void {
    this.surveyAssetApi.createFolder(event.title, this.activeFolderId() ?? undefined).subscribe({
      next: () => {
        this.resetRefreshState();
        this.refreshGrid();
        this.toastService.InsertToast('success', this.translate.instant('SURVEYMOD_FOLDER_CREATED', {title: event.title}), { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
        this.createFolderDialog?.updateLoader();
        this.createFolderDialog?.close();
      },
      error: () => {
        this.toastService.InsertToast('error', this.translate.instant('SURVEYMOD_FOLDER_CREATION_FAILED'), { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
        this.createFolderDialog?.updateLoader();
      },
    });
  }

  ngOnDestroy(): void {
    this.store.dispatch(CANCEL_REQUEST());
  }

  // Gets the currently active tab ID from the route or defaults to MY_ASSETS.
  private getActiveTabId(): MyAssetsTabId {
    const routeTab = this.route.snapshot.data['tabId'];
    return this.tabs.some((tab) => tab.id === routeTab)
      ? routeTab as MyAssetsTabId
      : MY_ASSETS_TABS.MY_ASSETS;
  }

  // Syncs active folder route state with the grid datasource and breadcrumb state.
  private onFolderRouteChange(folderId: string | null): void {
    this.isRefreshing.set(true);
    this.activeFolderId.set(folderId);
    this.gridService.setActiveFolder(folderId);
    this.deselectAllRows();
    this.loadFolderBreadcrumbs(folderId);
    this.refreshGrid();
  }

  // Builds breadcrumb items from navigation state first, then falls back to hierarchy API for direct links.
  private loadFolderBreadcrumbs(folderId: string | null): void {
    const root = { label: this.tabs.find((tab) => tab.id === this.activeTabId)?.label ?? 'My assets', url: getMyAssetsTabUrl(this.router.url, this.activeTabId) };
    if (!folderId || !this.folderBreadcrumbTabs.includes(this.activeTabId)) {
      this.folderBreadcrumbs.set([]);
      return;
    }

    const routeState = (typeof history === 'undefined' || !history.state ? {} : history.state) as {
      folderAsset?: Asset;
      folderBreadcrumbs?: Array<{ label: string; url: string }>;
    };
    if (routeState.folderBreadcrumbs?.length) {
      this.folderBreadcrumbs.set(routeState.folderBreadcrumbs);
      return;
    }

    const folderAsset = routeState.folderAsset;
    const folderLabel = folderAsset?.title ?? folderId;
    this.folderBreadcrumbs.set([root, { label: folderLabel, url: this.currentFolderUrl(folderId) }]);
    if (folderAsset?.parentAsset) {
      const parentChain = this.getFolderChain(folderAsset.parentAsset as Asset);
      this.folderBreadcrumbs.set([
        root,
        ...parentChain.map((asset) => ({
          label: asset.title ?? String(asset.assetId ?? ''),
          url: this.currentFolderUrl(String(asset.assetId ?? '')),
        })),
        { label: folderLabel, url: this.currentFolderUrl(folderId) },
      ]);
      return;
    }

    this.loadFolderBreadcrumbsFromApi(folderId, folderLabel, root);
  }

  // Rebuilds breadcrumbs when a direct URL or refresh has no usable navigation state.
  private loadFolderBreadcrumbsFromApi(
    folderId: string,
    folderLabel: string,
    root: { label: string; url: string }
  ): void {
    this.surveyAssetApi.fetchFolderHierarchy(folderId).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (hierarchy) => {
        if (this.activeFolderId() !== folderId) {
          return;
        }
        const selected = hierarchy.find((asset) => String(asset.assetId) === folderId) ?? hierarchy[0];
        const chain = this.getFolderChain(selected);
        if (!chain.some((asset) => String(asset.assetId) === folderId)) {
          chain.push({ assetId: folderId, title: folderLabel, assetType: ASSET_TYPE.DISCOVERFOLDER });
        }
        this.folderBreadcrumbs.set([
          root,
          ...chain.map((asset) => ({
            label: asset.title ?? String(asset.assetId ?? ''),
            url: this.currentFolderUrl(String(asset.assetId ?? '')),
          })),
        ]);
        this.cdr.markForCheck();
      },
      error: () => this.cdr.markForCheck(),
    });
  }

  /**
   * Follows parentAsset from the selected folder and returns the folders in breadcrumb order.
   * Example: Child -> Parent -> Root becomes [Root, Parent, Child].
   * Stops at a repeated folder ID to avoid an infinite loop if parent references are circular.
   */
  private getFolderChain(selected: Asset | undefined): Asset[] {
    const chain: Asset[] = [];
    let current = selected;
    const visited = new Set<string>();
    while (current?.assetId != null) {
      const id = String(current.assetId);
      if (visited.has(id)) {
        break;
      }
      visited.add(id);
      chain.unshift(current);
      current = current.parentAsset as Asset | undefined;
    }
    return chain;
  }

  // Creates the tab-aware folder URL used for breadcrumb navigation.
  private currentFolderUrl(folderId = this.activeFolderId() ?? ''): string {
    return getMyAssetsFolderUrl(this.router.url, this.activeTabId, folderId);
  }

  // Extracts folderId from a folder route URL.
  private getFolderIdFromUrl(url: string): string | null {
    const match = url.match(/\/folder\/([^/?#]+)/);
    return match ? decodeURIComponent(match[1]) : null;
  }

}
