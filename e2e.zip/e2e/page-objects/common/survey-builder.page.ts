import { BasePage, WebActions } from '@gfk/gta';
import { CommonPage } from './common-page';
import {
  ELEMENT_WAIT_TIMEOUT,
  UI_STATE_UPDATE_DELAY,
  PANEL_TRANSITION_DELAY,
  SMALL_TIMEOUT,
  MEDIUM_TIMEOUT,
  NAVIGATION_TIMEOUT,
} from '../../constants/timeout-constants';
import surveyBuilderPageResources from '../../locators/survey/survey-builder.locator.json';
import devTestData from '../../test-data/dev-test-data.json';

const SURVEY_BUILDER_PAGE_COMPONENT_NAME = 'surveyBuilderPage';

export class SurveyBuilderPage extends CommonPage {
  protected readonly componentName = SURVEY_BUILDER_PAGE_COMPONENT_NAME;
  private lastPublishStatus?: number; // HTTP status of the latest '/api/v1/publish' response

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(SURVEY_BUILDER_PAGE_COMPONENT_NAME, surveyBuilderPageResources);
  }

  // Question type selection
  private async clickQuestionTypeResource(resourceName: string): Promise<void> {
    await this.clickWhenVisible(resourceName, `Question-type tile "${resourceName}"`, MEDIUM_TIMEOUT);
  }

  /** Selects a question type tile without saving; call clickAddQuestion() again to cancel without persisting. */
  async clickQuestionTypeTile(resourceName: string): Promise<void> {
    await this.clickQuestionTypeResource(resourceName);
  }

  // Shared field helpers (operate on the currently expanded/editing question)
  private async fillQuestionText(questionIndex: number, text: string): Promise<void> {
    const questionText = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('questionTextInput', String(questionIndex), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
    );
    await this.waitUntilVisible(questionText, 'Question text input');
    await questionText.enterText(text);
  }

  private async fillOptionField(questionNumber: number, optionIndex: number, value: string): Promise<void> {
    await this.fillByDirectId(`question-option-${questionNumber}-${optionIndex}`, value, `Option ${optionIndex + 1}`);
  }

  private async fillScaleField(kind: 'row' | 'column', questionNumber: number, index: number, value: string): Promise<void> {
    await this.fillByDirectId(`scale-${kind}-input-${questionNumber}-${index}`, value, `${kind} ${index + 1}`);
  }

  private async fillByDirectId(id: string, value: string, label: string): Promise<void> {
    const field = this.webActionHandler.getWebElement({
      ...this.getResource('questionTextInput'),
      selectorType: 'css',
      selectorValue: `[data-test-id='${id}'] input, input[data-test-id='${id}'], input[data-test-id='${id}-input']`,
    });
    await this.waitUntilVisible(field, `Field "${label}"`);
    await field.enterText(value);
  }

  /** Counts rendered `.question-number` markers rather than trusting a hardcoded literal, since the persisted survey's question count is not stable across runs. */
  private async getNextQuestionIndex(): Promise<number> {
    const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    return markers.length + 1;
  }

  async getQuestionCount(): Promise<number> {
    try {
      const markers = await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
      return markers.length;
    } catch (error) {
      throw new Error(`Failed to get question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Re-expands the question card after it collapses/saves; scopes to the LAST `editQuestionButton` match since once 2+ questions exist it would otherwise be a strict-mode violation. */
  private async reopenCollapsedQuestion(): Promise<void> {
    const addOptionButton = this.webActionHandler.getWebElement(this.getResource('addOptionButton'));
    if (await addOptionButton.isVisible(SMALL_TIMEOUT)) {
      return;
    }

    const questionCount = await this.getQuestionCount();
    const editButtonResource = this.getResource('editQuestionButton');
    const editButton = this.webActionHandler.getWebElement({
      ...editButtonResource,
      selectorType: 'playwrights',
      selectorValue: `${editButtonResource.selectorValue} >> nth=${Math.max(questionCount - 1, 0)}`,
    });
    await this.waitUntilVisible(editButton, 'Edit question button');
    await editButton.click();
  }

  async addOptionToQuestion(): Promise<void> {
    try {
      const addOptionButton = this.webActionHandler.getWebElement(this.getResource('addOptionButton'));
      await this.waitUntilVisible(addOptionButton, 'Add option button');
      await addOptionButton.click();
    } catch (error) {
      throw new Error(`Failed to add option to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Counts `.option-row` on the currently open question editor. */
  async getOptionCount(): Promise<number> {
    try {
      const rows = await this.webActionHandler.getWebElementsText(this.getResource('optionRow'));
      return rows.length;
    } catch (error) {
      throw new Error(`Failed to get option count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Counts remove (X) icons on the currently open question editor; 0 when at the 2-option minimum. */
  async getRemoveOptionIconCount(): Promise<number> {
    try {
      const icons = await this.webActionHandler.getWebElementsText(this.getResource('removeOptionIcon'));
      return icons.length;
    } catch (error) {
      throw new Error(`Failed to get remove-option icon count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Clicks the last option row's remove (X) icon. */
  async removeLastOption(): Promise<void> {
    try {
      const removeResource = this.getResource('removeOptionIcon');
      const count = await this.getRemoveOptionIconCount();
      const lastIcon = this.webActionHandler.getWebElement({
        ...removeResource,
        selectorType: 'playwrights',
        selectorValue: `${removeResource.selectorValue} >> nth=${count - 1}`,
      });
      await this.waitUntilVisible(lastIcon, 'Remove option icon');
      await lastIcon.click();
    } catch (error) {
      throw new Error(`Failed to remove last option: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** "Add option" has no `state` attribute; disabled is reflected via a `disabled` class token or aria-disabled, like getAddQuestionDisabledState(). */
  async isAddOptionDisabled(): Promise<boolean> {
    try {
      const addOption = this.webActionHandler.getWebElement(this.getResource('addOptionButton'));
      const classAttr = (await addOption.getAttribute('class')) ?? '';
      const ariaDisabled = await addOption.getAttribute('aria-disabled');
      return classAttr.split(/\s+/).includes('disabled') || ariaDisabled === 'true';
    } catch (error) {
      throw new Error(`Failed to get add-option disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers Add option and checks the max-options tooltip, like isAddQuestionTooltipVisibleOnHover(). */
  async isMaxOptionsTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const addOption = this.webActionHandler.getWebElement(this.getResource('addOptionButton'));
      await addOption.executeScript((e) => e.scrollIntoView());
      await addOption.hover();
      const message = this.webActionHandler.getWebElement(this.getResource('maxOptionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait, no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off the hovered button so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check max-options tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers the Add-menu trigger wrapper (`.matrix-action-area`) so the Row/Column buttons render. */
  private async hoverScaleAddMenuTrigger() {
    const addMenuTrigger = this.webActionHandler.getWebElement(this.getResource('scaleAddMenuTrigger'));
    await this.waitUntilVisible(addMenuTrigger, 'Scale add-menu trigger');
    await addMenuTrigger.hover();
    return addMenuTrigger;
  }

  /** Shared by Point Scale and Multi Scale — both use the same survey-scale-editor matrix-actions mechanism. */
  async addRowToQuestion(): Promise<void> {
    try {
      const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
      const addRow = addMenuTrigger.getWebElement(this.getResource('addRowButton'));
      await this.waitUntilVisible(addRow, 'Add row button');
      await addRow.click();
    } catch (error) {
      throw new Error(`Failed to add row to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Shared by Point Scale and Multi Scale — both use the same survey-scale-editor matrix-actions mechanism. */
  async addColumnToQuestion(): Promise<void> {
    try {
      const addMenuTrigger = await this.hoverScaleAddMenuTrigger();
      const addColumn = addMenuTrigger.getWebElement(this.getResource('addColumnButton'));
      await this.waitUntilVisible(addColumn, 'Add column button');
      await addColumn.click();
    } catch (error) {
      throw new Error(`Failed to add column to question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Closes the Add Question panel first (its editor shares selectors with any open row editor) using isHidden() - isVisible(0) is NOT instant, it waits forever for the element to appear. */
  private async closeInlineAddEditorIfOpen(): Promise<void> {
    const inlineEditor = this.webActionHandler.getWebElement(this.getResource('inlineAddEditor'));
    if (!(await inlineEditor.isHidden())) {
      await this.clickAddQuestion();
    }
  }

  /** `requiredToggle`'s truncated id matches EVERY question's checkbox once more than one editor has been opened, so when `index` is given this scopes to that row instead of a page-wide nth. */
  async toggleRequired(index?: number): Promise<void> {
    try {
      if (index === undefined) {
        await this.clickWhenVisible('requiredToggle', 'Required toggle');
      } else {
        await this.closeInlineAddEditorIfOpen();
        const rowResource = this.getResource('questionRow');
        const toggleResource = this.getResource('requiredToggle');
        const toggle = this.webActionHandler.getWebElement({
          ...toggleResource,
          selectorType: 'playwrights',
          selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue}`,
        });
        await this.waitUntilVisible(toggle, `Required toggle (index ${index})`);
        await toggle.click();
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to toggle required: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Stepper's clickable circle; text doesn't navigate - index 0 = Select Panelists. */
  async clickSelectPanelistsStep(): Promise<void> {
    try {
      await this.clickWhenVisible('select-panelists-step-circle', 'Select Panelists step circle', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to click Select Panelists step: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Navigates back to the previous step (Select Panelists) from the builder. */
  async clickBackButton(): Promise<void> {
    try {
      await this.clickWhenVisible('backButton', 'Back button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to click Back button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickAddQuestion(): Promise<void> {
    try {
      await this.clickWhenVisible('addQuestionLink', 'Add question link');
      await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
    } catch (error) {
      throw new Error(`Failed to click add question: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Per-question-type methods: each assumes it's called right after clickAddQuestion(), while this question is the currently expanded one.

  async addSingleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeSingleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.reopenCollapsedQuestion();
          await this.addOptionToQuestion();
        }
        await this.fillOptionField(questionIndex, i, options[i]);
      }

      const saveButton = this.webActionHandler.getWebElement(this.getResource('saveQuestionChangesButton'));
      if (await saveButton.isVisible(SMALL_TIMEOUT)) {
        await saveButton.click();
      }
      await this.waitForQuestionCountAtLeast(questionIndex, MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to add Single Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addMultipleChoiceQuestion(questionText: string, options: string[]): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeMultipleChoice');
      await this.fillQuestionText(questionIndex, questionText);
      for (let i = 0; i < options.length; i++) {
        if (i >= 2) {
          await this.addOptionToQuestion();
        }
        await this.fillOptionField(questionIndex, i, options[i]);
      }
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Multiple Choice question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addRatingQuestion(questionText: string, rows: string[] = devTestData.surveyQuestions.rating.rows): Promise<void> {
    try {
      await this.clickQuestionTypeResource('questionTypeRating');
      // Rating editor's inner input id is unreliable (id race), so fill the visible question-text input instead.
      await this.fillWhenVisible('ratingQuestionTextInput', questionText, 'Rating question text input');
      await this.fillRatingRows(rows);
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Rating question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Rating starts with 1 empty row (min 1); fills row 1 and clicks "Add option" for each extra row. Empty rows block saving. */
  private async fillRatingRows(rows: string[]): Promise<void> {
    const rowResource = this.getResource('ratingRowInput');
    for (let i = 0; i < rows.length; i++) {
      if (i > 0) {
        const addRow = this.webActionHandler.getWebElement(this.getResource('addRatingRowButton'));
        await this.waitUntilVisible(addRow, 'Rating "Add option" button');
        await addRow.click();
      }
      const rowInput = this.webActionHandler.getWebElement({
        ...rowResource,
        selectorType: 'playwrights',
        selectorValue: `${rowResource.selectorValue} >> nth=${i}`,
      });
      await this.waitUntilVisible(rowInput, `Rating row ${i + 1}`);
      await rowInput.enterText(rows[i]);
    }
  }

  async addNPSQuestion(questionText: string): Promise<void> {
    try {
      const questionIndex = await this.getNextQuestionIndex();
      await this.clickQuestionTypeResource('questionTypeNPS');
      await this.fillQuestionText(questionIndex, questionText); // NPS reuses the shared questionTextInput locator
      await this.clickAddQuestion(); // finalizes/saves this question
    } catch (error) {
      throw new Error(`Failed to add Net Promoter Score question: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Shared body for Point Scale and Multi Scale, which differ only in the question-type tile resource. */
  private async addScaleQuestion(typeResource: string, questionText: string, rows: string[], columns: string[]): Promise<void> {
    const questionIndex = await this.getNextQuestionIndex();
    await this.clickQuestionTypeResource(typeResource);
    await this.fillQuestionText(questionIndex, questionText);
    for (let i = 0; i < rows.length; i++) {
      if (i >= 2) {
        await this.addRowToQuestion();
      }
      await this.fillScaleField('row', questionIndex, i, rows[i]);
    }
    for (let i = 0; i < columns.length; i++) {
      if (i >= 2) {
        await this.addColumnToQuestion();
      }
      await this.fillScaleField('column', questionIndex, i, columns[i]);
    }
    await this.clickAddQuestion(); // finalizes/saves this question
  }

  async addPointScaleQuestion(questionText: string, rows: string[], columns: string[]): Promise<void> {
    try {
      await this.addScaleQuestion('questionTypePointScale', questionText, rows, columns);
    } catch (error) {
      throw new Error(`Failed to add Point Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async addMultiScaleQuestion(questionText: string, rows: string[], columns: string[]): Promise<void> {
    try {
      await this.addScaleQuestion('questionTypeMultiScale', questionText, rows, columns);
    } catch (error) {
      throw new Error(`Failed to add Multi Scale question: ${error instanceof Error ? error.message : error}`);
    }
  }

  async enterReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('reviewSurveyButton', 'Review survey button');
      const selectAllButtonAfterEntering = this.webActionHandler.getWebElement(this.getResource('selectAllButton'));
      await this.waitUntilVisible(selectAllButtonAfterEntering, 'Select all button (review mode controls)');
    } catch (error) {
      throw new Error(`Failed to enter review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectQuestionInReview(index: number): Promise<void> {
    try {
      const questionCheckbox = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      await this.waitUntilVisible(questionCheckbox, `Select-question checkbox (index ${index})`);
      await questionCheckbox.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to select question ${index} in review: ${error instanceof Error ? error.message : error}`);
    }
  }

  async deleteSelectedQuestions(): Promise<void> {
    try {
      await this.clickWhenVisible('deleteQuestionsButton', 'Delete questions button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to delete selected questions: ${error instanceof Error ? error.message : error}`);
    }
  }

  async selectAll(): Promise<void> {
    try {
      await this.clickWhenVisible('selectAllButton', 'Select all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to select all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async unselectAll(): Promise<void> {
    try {
      await this.clickWhenVisible('unselectAllButton', 'Unselect all button');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to unselect all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async expandAll(): Promise<void> {
    try {
      await this.clickWhenVisible('expandAllButton', 'Expand all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to expand all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async collapseAll(): Promise<void> {
    try {
      await this.clickWhenVisible('collapseAllButton', 'Collapse all button', 10000);
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to collapse all: ${error instanceof Error ? error.message : error}`);
    }
  }

  async exitReviewMode(): Promise<void> {
    try {
      await this.clickWhenVisible('exitReviewModeButton', 'Exit review mode button');
      const reviewButtonAfterExit = this.webActionHandler.getWebElement(this.getResource('reviewSurveyButton'));
      await this.waitUntilVisible(reviewButtonAfterExit, 'Review survey button (back on Build Survey screen)');
    } catch (error) {
      throw new Error(`Failed to exit review mode: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Instant check (isHidden(), not isVisible(0) which waits forever) for whether delete-all already auto-closed Review Mode. */
  async isExitReviewModeButtonHidden(): Promise<boolean> {
    try {
      const exitButton = this.webActionHandler.getWebElement(this.getResource('exitReviewModeButton'));
      return await exitButton.isHidden();
    } catch (error) {
      throw new Error(`Failed to check exit-review-mode button visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async areReviewControlsVisible(): Promise<boolean> {
    try {
      const controls = ['selectAllButton', 'expandAllButton', 'collapseAllButton', 'deleteQuestionsButton', 'exitReviewModeButton'];
      for (const control of controls) {
        const element = this.webActionHandler.getWebElement(this.getResource(control));
        if (!(await element.isVisible())) {
          return false;
        }
      }
      return true;
    } catch (error) {
      throw new Error(`Failed to check review controls visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getReviewCheckboxCount(questionCount: number): Promise<number> {
    try {
      let visibleCount = 0;
      for (let index = 0; index < questionCount; index++) {
        const checkbox = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource('selectQuestionByIndex', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
        );
        if (await checkbox.isVisible()) {
          visibleCount++;
        }
      }
      return visibleCount;
    } catch (error) {
      throw new Error(`Failed to get review checkbox count: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** `select-question-<i>-icon` has no checked state itself; the real checked/unchecked class lives on its ancestor `.checkbox-container`. */
  async isQuestionSelected(index: number): Promise<boolean> {
    try {
      const container = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource('selectQuestionCheckboxContainer', String(index), SURVEY_BUILDER_PAGE_COMPONENT_NAME)
      );
      const classAttr = (await container.getAttribute('class')) ?? '';
      return classAttr.split(/\s+/).includes('checked');
    } catch (error) {
      throw new Error(`Failed to check if question ${index} is selected: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getQuestionNumbers(): Promise<string[]> {
    try {
      return await this.webActionHandler.getWebElementsText(this.getResource('questionNumberMarker'));
    } catch (error) {
      throw new Error(`Failed to get question numbers: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Polls `getQuestionNumbers()` until its length reaches `target`, or throws after `timeout` ms. */
  private async waitForQuestionCountAtLeast(target: number, timeout: number): Promise<string[]> {
    const start = Date.now();
    let questionNumbers = await this.getQuestionNumbers();
    while (questionNumbers.length < target) {
      if (Date.now() - start >= timeout) {
        throw new Error(`Timed out waiting for question count to reach ${target} (current: ${questionNumbers.length})`);
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      questionNumbers = await this.getQuestionNumbers();
    }
    return questionNumbers;
  }

  /** Tops up to `min` Rating questions; the Rating tile toggles closed if add-question is clicked while already open, so only click it when not visible. */
  async ensureQuestionCount(min: number): Promise<void> {
    try {
      const { questionText } = devTestData.surveyQuestions.rating;
      let questionNumbers = await this.getQuestionNumbers();

      while (questionNumbers.length < min) {
        const countBeforeAdd = questionNumbers.length;
        const typeTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));

        if (!(await typeTile.isVisible(SMALL_TIMEOUT))) {
          await this.clickAddQuestion();
          if (!(await typeTile.isVisible(MEDIUM_TIMEOUT))) {
            throw new Error(`Question-type picker did not open after clicking add-question (current question count: ${countBeforeAdd})`);
          }
        }

        await this.addRatingQuestion(`${questionText} ${countBeforeAdd + 1}`);
        questionNumbers = await this.waitForQuestionCountAtLeast(countBeforeAdd + 1, MEDIUM_TIMEOUT);
      }
    } catch (error) {
      throw new Error(`Failed to ensure question count: ${error instanceof Error ? error.message : error}`);
    }
  }

  // Survey name, save, publish
  async setSurveyTitle(title: string): Promise<void> {
    try {
      await this.clickWhenVisible('editSurveyNameIcon', 'Edit survey name icon');
      await this.fillWhenVisible('surveyTitleInput', title, 'Survey title input');
    } catch (error) {
      throw new Error(`Failed to set survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Expands "My Assets" via its own row-scoped `.arrow` (not page-wide) and picks the first non-"My Assets" folder row, only when Save isn't already enabled on "My Assets" alone. Shared by fillSaveCopyDialog(); publish can reuse it too. */
  private async selectSaveLocation(): Promise<void> {
    await this.clickWhenVisible('myAssetsTreeItem', 'My Assets tree item');

    const saveButton = this.webActionHandler.getWebElement(this.getResource('savePendingChangesButton'));
    const isSaveButtonVisible = await saveButton.isVisible(SMALL_TIMEOUT);
    const isSaveReady = isSaveButtonVisible && (await saveButton.isEnabled());
    if (isSaveReady) {
      return;
    }

    const nativePage = (BasePage as any).page as import('playwright').Page; // "not My Assets" folder filtering needs Playwright's filter API, not expressible via resource strings
    const myAssetsRow = nativePage.getByRole('treeitem', { name: 'My Assets' });
    await myAssetsRow.locator('.arrow').click({ timeout: SMALL_TIMEOUT });

    const folderRow = nativePage.getByRole('treeitem').filter({ hasNotText: 'My Assets' }).first();
    await folderRow.click({ timeout: SMALL_TIMEOUT });
  }

  /** Fills the Save-a-copy dialog (title, My Assets, save pending changes) — shared by saveDraft() and publishSurvey(). */
  private async fillSaveCopyDialog(title: string): Promise<void> {
    await this.fillWhenVisible('saveCopyTitleInput', title, 'Save-copy title input');
    await this.selectSaveLocation();
    await this.clickWhenVisible('savePendingChangesButton', 'Save pending changes button');
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /** Already-saved surveys (e.g. after TC_BS_10a) save directly without the Save-a-copy dialog; waits for whichever of the dialog or the "saved as draft" toast shows first. */
  async saveDraft(title: string): Promise<void> {
    try {
      const savedToast = this.webActionHandler.getWebElement(this.getResource('saveDraftSuccessToast'));
      // A leftover toast from an earlier save would make the check below pass without this save having happened.
      await savedToast.waitFor(MEDIUM_TIMEOUT, 'hidden');
      if (!(await savedToast.isHidden())) {
        throw new Error(`A previous "saved as draft" toast was still visible after ${MEDIUM_TIMEOUT}ms`);
      }

      await this.clickWhenVisible('saveDraftButton', 'Save draft button');

      const nativePage = (BasePage as any).page as import('playwright').Page; // waiting on "A or B, whichever first" needs Playwright's locator.or()
      const titleInput = nativePage.locator(this.getResource('saveCopyTitleInput').selectorValue);
      const toastText = nativePage.getByText(this.getResource('saveDraftSuccessToast').selectorValue);
      await titleInput.or(toastText).first().waitFor({ state: 'visible', timeout: MEDIUM_TIMEOUT });

      if (!(await titleInput.isVisible())) {
        return;
      }
      await this.fillSaveCopyDialog(title);
    } catch (error) {
      throw new Error(`Failed to save draft: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDraftSavedToastVisible(): Promise<boolean> {
    try {
      const toast = this.webActionHandler.getWebElement(this.getResource('saveDraftSuccessToast'));
      return await toast.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check draft saved toast visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSaveDraftButton(): Promise<void> {
    try {
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');
    } catch (error) {
      throw new Error(`Failed to click Save draft button: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Waits until the header Save draft button has left its loading state (`state="loading"`) and is enabled. */
  private async waitForSaveDraftButtonReady(): Promise<void> {
    const button = this.webActionHandler.getWebElement(this.getResource('saveDraftButton'));
    await this.waitUntilVisible(button, 'Save draft button', ELEMENT_WAIT_TIMEOUT);
    const deadline = Date.now() + ELEMENT_WAIT_TIMEOUT;
    do {
      const state = await button.getAttribute('state');
      const ariaDisabled = await button.getAttribute('aria-disabled');
      if (state !== 'loading' && state !== 'disabled' && ariaDisabled !== 'true') {
        return;
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } while (Date.now() < deadline);
    throw new Error(`Save draft button was still loading or disabled after ${ELEMENT_WAIT_TIMEOUT}ms`);
  }

  /** Clicks Save draft once the button is ready; if the "Save your survey" dialog is not up within SMALL_TIMEOUT, clicks once more (one retry only). */
  async clickSaveDraftAndWaitForDialog(): Promise<void> {
    try {
      await this.waitForSaveDraftButtonReady();
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');
      // The first click puts the button into a loading state (aria-busy) while the draft saves; the dialog can take >5s.
      if (await this.isSaveDraftDialogVisible(MEDIUM_TIMEOUT)) {
        return;
      }
      await this.waitForSaveDraftButtonReady();
      // Re-check before re-clicking: if the dialog opened meanwhile, a second click is blocked by its overlay.
      if (await this.isSaveDraftDialogVisible(SMALL_TIMEOUT)) {
        return;
      }
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');
    } catch (error) {
      throw new Error(`Failed to open the Save draft dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Cancel of the "Save your survey" dialog itself (not the Publish popup or Create new folder dialog). */
  async clickSaveDraftDialogCancel(): Promise<void> {
    try {
      const cancelButton = this.getScopedElement('saveDraftDialog', 'saveDraftDialogCancelButton');
      await this.waitUntilVisible(cancelButton, 'Save your survey dialog Cancel button');
      await cancelButton.click();
    } catch (error) {
      throw new Error(`Failed to click Save your survey dialog Cancel button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isSaveDraftDialogClosed(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('saveDraftDialog'));
      await dialog.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return await dialog.isHidden();
    } catch (error) {
      throw new Error(`Failed to check Save your survey dialog closed state: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getSaveDraftDialogFolderElement(folderName: string) {
    const dialog = this.getResource('saveDraftDialog');
    const folder = this.resourceManager.getDynamicResource('locationDialogFolderByName', folderName, SURVEY_BUILDER_PAGE_COMPONENT_NAME);
    return this.webActionHandler.getWebElement({
      ...folder,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${folder.selectorValue} >> nth=0`,
    });
  }

  /** Scrolls the folder tree in the "Save your survey" dialog page by page until the folder is in view, or the tree cannot scroll any further. */
  private async scrollSaveDraftDialogTreeToFolder(folder: ReturnType<WebActions['getWebElement']>): Promise<boolean> {
    const tree = this.getScopedElement('saveDraftDialog', 'saveDraftDialogFolderTree');
    const deadline = Date.now() + ELEMENT_WAIT_TIMEOUT;
    while (Date.now() < deadline) {
      if (!(await folder.isHidden())) {
        return true;
      }
      if (await tree.isHidden()) {
        return false;
      }
      // Scrolls the nearest scrollable element (the tree itself or an ancestor) down by one page.
      const moved = await tree.executeScript((e) => {
        let node: HTMLElement | null = e as HTMLElement;
        while (node && node.scrollHeight <= node.clientHeight) {
          node = node.parentElement;
        }
        if (!node) {
          return false;
        }
        const before = node.scrollTop;
        node.scrollTop = before + node.clientHeight;
        return node.scrollTop !== before;
      });
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      if (!moved) {
        return !(await folder.isHidden());
      }
    }
    return !(await folder.isHidden());
  }

  /** Checks the folder is listed in the "Save your survey" dialog; scrolls the tree, and expands "My Assets" once, if the folder is not showing yet. */
  async ensureSaveDraftDialogFolderListed(folderName: string): Promise<boolean> {
    try {
      const folder = this.getSaveDraftDialogFolderElement(folderName);
      if (!(await folder.isHidden())) {
        return true;
      }
      if (await this.scrollSaveDraftDialogTreeToFolder(folder)) {
        return true;
      }
      await this.getScopedElement('saveDraftDialog', 'saveDraftDialogMyAssetsArrow').click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      if (await folder.isVisible(SMALL_TIMEOUT)) {
        return true;
      }
      return await this.scrollSaveDraftDialogTreeToFolder(folder);
    } catch (error) {
      throw new Error(`Failed to look for folder "${folderName}" in the Save your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  /**
   * After Create in the "Create new folder" dialog the app closes it, reloads the folder list and reopens "Save your survey" by itself.
   * Waits for that; if the Save dialog does not reappear, clicks the header Save draft once as a fallback.
   */
  async waitForSaveDraftDialogAfterFolderCreate(): Promise<void> {
    try {
      const createDialog = this.webActionHandler.getWebElement(this.getResource('createNewFolderDialog'));
      await createDialog.waitFor(ELEMENT_WAIT_TIMEOUT, 'hidden');
      if (!(await createDialog.isHidden())) {
        const actionToast = this.webActionHandler.getWebElement(this.getResource('survey-action-toast'));
        const toastText = (await actionToast.isHidden()) ? 'none visible' : ((await actionToast.getText()) ?? '').trim();
        throw new Error(`"Create new folder" dialog was still visible after ${ELEMENT_WAIT_TIMEOUT}ms (.survey-action-toast text: ${toastText})`);
      }

      if (await this.isSaveDraftDialogVisible(ELEMENT_WAIT_TIMEOUT)) {
        return;
      }
      await this.waitForSaveDraftButtonReady();
      await this.clickWhenVisible('saveDraftButton', 'Save draft button');
    } catch (error) {
      throw new Error(`Failed to wait for the Save your survey dialog after creating the folder: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSaveDraftDialogFolder(folderName: string): Promise<void> {
    try {
      const folder = this.getSaveDraftDialogFolderElement(folderName);
      await this.waitUntilVisible(folder, `Folder "${folderName}" in the Save your survey dialog`);
      await folder.click();
    } catch (error) {
      throw new Error(`Failed to click folder "${folderName}" in the Save your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSaveDraftDialogCreateNewFolderLink(): Promise<void> {
    try {
      const link = this.getScopedElement('saveDraftDialog', 'saveDraftDialogCreateNewFolderLink');
      await this.waitUntilVisible(link, 'Save your survey dialog "Create new folder" link');
      await link.click();
    } catch (error) {
      throw new Error(`Failed to click "Create new folder" in the Save your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** The app closes the Create new folder dialog on success (it does not reopen the location dialog). */
  async isCreateNewFolderDialogClosed(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('createNewFolderDialog'));
      await dialog.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return await dialog.isHidden();
    } catch (error) {
      throw new Error(`Failed to check Create new folder dialog closed state: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getSaveDraftDialogChild(resourceName: string) {
    const dialog = this.webActionHandler.getWebElement(this.getResource('saveDraftDialog'));
    return dialog.getWebElement(this.getResource(resourceName));
  }

  async isSaveDraftDialogVisible(timeoutMs: number = MEDIUM_TIMEOUT): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('saveDraftDialog'));
      return await dialog.isVisible(timeoutMs);
    } catch (error) {
      throw new Error(`Failed to check Save draft dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isSaveDraftDialogValidationErrorVisible(): Promise<boolean> {
    try {
      const errorText = this.getSaveDraftDialogChild('saveDraftDialogErrorText');
      return await errorText.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Save draft dialog validation error visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isSaveDraftDialogSaveButtonDisabled(): Promise<boolean> {
    try {
      const saveButton = this.getSaveDraftDialogChild('saveDraftDialogSaveButton');
      const ariaDisabled = await saveButton.getAttribute('aria-disabled');
      const state = await saveButton.getAttribute('state');
      const disabledAttr = await saveButton.getAttribute('disabled');
      const classAttr = (await saveButton.getAttribute('class')) ?? '';
      return ariaDisabled === 'true' || state === 'disabled' || disabledAttr !== null || classAttr.split(/\s+/).includes('disabled');
    } catch (error) {
      throw new Error(`Failed to get Save draft dialog Save button disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillSaveDraftDialogName(name: string): Promise<void> {
    try {
      const nameInput = this.getSaveDraftDialogChild('saveDraftDialogNameInput');
      await this.waitUntilVisible(nameInput, 'Save draft dialog Name input');
      await nameInput.enterText(name);
    } catch (error) {
      throw new Error(`Failed to fill Save draft dialog Name input: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSaveDraftDialogMyAssetsFolder(): Promise<void> {
    try {
      const folder = this.getSaveDraftDialogChild('saveDraftDialogMyAssetsFolder');
      await this.waitUntilVisible(folder, 'Save draft dialog My Assets folder');
      await folder.click();
    } catch (error) {
      throw new Error(`Failed to click Save draft dialog My Assets folder: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickSaveDraftDialogSaveButton(): Promise<void> {
    try {
      const saveButton = this.getSaveDraftDialogChild('saveDraftDialogSaveButton');
      await this.waitUntilVisible(saveButton, 'Save draft dialog Save draft button');
      await saveButton.click();
    } catch (error) {
      throw new Error(`Failed to click Save draft dialog Save draft button: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getScopedElement(dialogResourceName: string, childResourceName: string) {
    const dialog = this.getResource(dialogResourceName);
    const child = this.getResource(childResourceName);
    return this.webActionHandler.getWebElement({
      ...child,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${child.selectorValue}`,
    });
  }

  private getScopedDynamicElement(dialogResourceName: string, childResourceName: string, text: string) {
    const dialog = this.getResource(dialogResourceName);
    const child = this.resourceManager.getDynamicResource(childResourceName, text, SURVEY_BUILDER_PAGE_COMPONENT_NAME);
    return this.webActionHandler.getWebElement({
      ...child,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${child.selectorValue}`,
    });
  }

  private async getScopedElementsText(dialogResourceName: string, childResourceName: string): Promise<string[]> {
    const dialog = this.getResource(dialogResourceName);
    const child = this.getResource(childResourceName);
    return this.webActionHandler.getWebElementsText({
      ...child,
      selectorType: 'playwrights',
      selectorValue: `${dialog.selectorValue} >> ${child.selectorValue}`,
    });
  }

  async isPublishLocationDialogVisible(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('publishLocationDialog'));
      return await dialog.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Publish your survey dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isPublishLocationDialogContinueDisabled(): Promise<boolean> {
    try {
      const continueButton = this.getScopedElement('publishLocationDialog', 'dialogContinueButton');
      const ariaDisabled = await continueButton.getAttribute('aria-disabled');
      const state = await continueButton.getAttribute('state');
      const disabledAttr = await continueButton.getAttribute('disabled');
      const classAttr = (await continueButton.getAttribute('class')) ?? '';
      return ariaDisabled === 'true' || state === 'disabled' || disabledAttr !== null || classAttr.split(/\s+/).includes('disabled');
    } catch (error) {
      throw new Error(`Failed to get Publish your survey dialog Continue button disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickPublishLocationDialogCancel(): Promise<void> {
    try {
      const cancelButton = this.getScopedElement('publishLocationDialog', 'saveDraftDialogCancelButton');
      await this.waitUntilVisible(cancelButton, 'Publish your survey dialog Cancel button');
      await cancelButton.click();
    } catch (error) {
      throw new Error(`Failed to click Publish your survey dialog Cancel button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillPublishLocationDialogName(name: string): Promise<void> {
    try {
      const nameInput = this.getScopedElement('publishLocationDialog', 'saveCopyTitleInput');
      await this.waitUntilVisible(nameInput, 'Publish your survey dialog Name input');
      await nameInput.enterText(name);
    } catch (error) {
      throw new Error(`Failed to fill Publish your survey dialog Name input: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Selects the "My Assets" root in the Publish your survey dialog (first match, like the Save draft dialog's folder click). */
  async clickPublishLocationMyAssetsFolder(): Promise<void> {
    try {
      const folder = this.getScopedElement('publishLocationDialog', 'saveDraftDialogMyAssetsFolder');
      await this.waitUntilVisible(folder, 'Publish your survey dialog My Assets folder');
      await folder.click();
    } catch (error) {
      throw new Error(`Failed to click Publish your survey dialog My Assets folder: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickPublishLocationDialogContinue(): Promise<void> {
    try {
      const continueButton = this.getScopedElement('publishLocationDialog', 'dialogContinueButton');
      await this.waitUntilVisible(continueButton, 'Publish your survey dialog Continue button');
      await continueButton.click();
    } catch (error) {
      throw new Error(`Failed to click Publish your survey dialog Continue button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isReviewSurveyDetailsDialogVisible(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('reviewSurveyDetailsDialog'));
      return await dialog.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Review survey details dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Waits for the Review survey details dialog to close; false if it is still showing after MEDIUM_TIMEOUT. */
  async isReviewSurveyDetailsDialogClosed(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('reviewSurveyDetailsDialog'));
      await dialog.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return await dialog.isHidden();
    } catch (error) {
      throw new Error(`Failed to check Review survey details dialog closed state: ${error instanceof Error ? error.message : error}`);
    }
  }

  private async getVisibleText(resourceName: string, what: string): Promise<string> {
    const element = this.webActionHandler.getWebElement(this.getResource(resourceName));
    await this.waitUntilVisible(element, what);
    return ((await element.getText()) ?? '').trim();
  }

  async getReviewDialogTitleText(): Promise<string> {
    try {
      return await this.getVisibleText('publishDialogTitle', 'Review survey details dialog title');
    } catch (error) {
      throw new Error(`Failed to read Review survey details dialog title: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getReviewDialogSurveyTitleText(): Promise<string> {
    try {
      return await this.getVisibleText('publishSurveyTitle', 'Review survey details survey title');
    } catch (error) {
      throw new Error(`Failed to read Review survey details survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getReviewDialogQuestionSummaryText(): Promise<string> {
    try {
      return await this.getVisibleText('publishQuestionSummary', 'Review survey details question summary');
    } catch (error) {
      throw new Error(`Failed to read Review survey details question summary: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getReviewDialogResponseCountText(): Promise<string> {
    try {
      return await this.getVisibleText('publishResponseCount', 'Review survey details response count');
    } catch (error) {
      throw new Error(`Failed to read Review survey details response count: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isReviewDialogPublishButtonVisible(): Promise<boolean> {
    try {
      const button = this.webActionHandler.getWebElement(this.getResource('reviewDialogPublishButton'));
      return await button.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Review survey details Publish survey button visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickReviewDialogEditSurvey(): Promise<void> {
    try {
      const editButton = this.getScopedElement('reviewSurveyDetailsDialog', 'publishEditSurveyButton');
      await this.waitUntilVisible(editButton, 'Review survey details Edit survey button');
      await editButton.click();
    } catch (error) {
      throw new Error(`Failed to click Review survey details Edit survey button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderLink(): Promise<void> {
    try {
      const link = this.getScopedElement('publishLocationDialog', 'createNewFolderLink');
      await this.waitUntilVisible(link, 'Create new folder link');
      await link.click();
    } catch (error) {
      throw new Error(`Failed to click Create new folder link: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderInLocation(): Promise<void> {
    try {
      const button = this.getScopedElement('publishLocationDialog', 'createNewFolderInLocationButton');
      await this.waitUntilVisible(button, 'Create new folder in location button');
      await button.click();
    } catch (error) {
      throw new Error(`Failed to click "Create new folder in location" button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isCreateNewFolderDialogVisible(): Promise<boolean> {
    try {
      const dialog = this.webActionHandler.getWebElement(this.getResource('createNewFolderDialog'));
      return await dialog.isVisible(MEDIUM_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Create new folder dialog visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async areCreateNewFolderDialogControlsVisible(): Promise<{ nameInput: boolean; cancel: boolean; create: boolean; close: boolean }> {
    try {
      const [nameInput, cancel, create, close] = await Promise.all([
        this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogNameInput').isVisible(MEDIUM_TIMEOUT),
        this.getScopedElement('createNewFolderDialog', 'saveDraftDialogCancelButton').isVisible(MEDIUM_TIMEOUT),
        this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogCreateButton').isVisible(MEDIUM_TIMEOUT),
        this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogCloseButton').isVisible(MEDIUM_TIMEOUT),
      ]);
      return { nameInput, cancel, create, close };
    } catch (error) {
      throw new Error(`Failed to check Create new folder dialog controls: ${error instanceof Error ? error.message : error}`);
    }
  }

  async fillCreateNewFolderDialogName(name: string): Promise<void> {
    try {
      const nameInput = this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogNameInput');
      await this.waitUntilVisible(nameInput, 'Create new folder dialog Name input');
      await nameInput.enterText(name);
      const typedValue = await nameInput.getValue();
      if (typedValue !== name) {
        throw new Error(`the field shows "${typedValue}" instead of "${name}"`);
      }
    } catch (error) {
      throw new Error(`Failed to fill Create new folder dialog Name input: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderDialogCreate(): Promise<void> {
    try {
      const createButton = this.getScopedElement('createNewFolderDialog', 'createNewFolderDialogCreateButton');
      await this.waitUntilVisible(createButton, 'Create new folder dialog Create button');

      // Create stays disabled until the name field is valid, so wait for it instead of clicking a disabled button.
      const deadline = Date.now() + MEDIUM_TIMEOUT;
      let isDisabled!: boolean;
      do {
        const ariaDisabled = await createButton.getAttribute('aria-disabled');
        const state = await createButton.getAttribute('state');
        const classAttr = (await createButton.getAttribute('class')) ?? '';
        isDisabled =
          !(await createButton.isEnabled()) || ariaDisabled === 'true' || state === 'disabled' || classAttr.split(/\s+/).includes('disabled');
        if (!isDisabled) {
          break;
        }
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      } while (Date.now() < deadline);
      if (isDisabled) {
        throw new Error(`Create button was still disabled after ${MEDIUM_TIMEOUT}ms`);
      }

      await createButton.click();
    } catch (error) {
      throw new Error(`Failed to click Create new folder dialog Create button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickCreateNewFolderDialogCancel(): Promise<void> {
    try {
      const cancelButton = this.getScopedElement('createNewFolderDialog', 'saveDraftDialogCancelButton');
      await this.waitUntilVisible(cancelButton, 'Create new folder dialog Cancel button');
      await cancelButton.click();
    } catch (error) {
      throw new Error(`Failed to click Create new folder dialog Cancel button: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getPublishLocationFolderCount(): Promise<number> {
    try {
      return (await this.getScopedElementsText('publishLocationDialog', 'locationDialogFolderRow')).length;
    } catch (error) {
      throw new Error(`Failed to get folder count in Publish your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isPublishLocationFolderHighlighted(folderName: string): Promise<boolean> {
    try {
      const folder = this.getScopedDynamicElement('publishLocationDialog', 'locationDialogFolderByName', folderName);
      const ariaSelected = await folder.getAttribute('aria-selected');
      const classAttr = (await folder.getAttribute('class')) ?? '';
      return ariaSelected === 'true' || classAttr.split(/\s+/).includes('selected') || classAttr.split(/\s+/).includes('highlighted');
    } catch (error) {
      throw new Error(`Failed to check folder highlighted state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickPublishLocationFolder(folderName: string): Promise<void> {
    try {
      const folder = this.getScopedDynamicElement('publishLocationDialog', 'locationDialogFolderByName', folderName);
      await this.waitUntilVisible(folder, `Folder "${folderName}" in Publish your survey dialog`);
      await folder.click();
    } catch (error) {
      throw new Error(`Failed to click folder "${folderName}" in Publish your survey dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getAddQuestionDisabledState(): Promise<{ disabled: boolean; classAttr: string; outerHtml: string }> {
    try {
      const addQuestion = this.webActionHandler.getWebElement(this.getResource('addQuestionLink'));
      const classAttr = (await addQuestion.getAttribute('class')) ?? '';
      const ariaDisabled = await addQuestion.getAttribute('aria-disabled');
      const outerHtml = String(await addQuestion.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { disabled: classAttr.split(/\s+/).includes('disabled') || ariaDisabled === 'true', classAttr, outerHtml };
    } catch (error) {
      throw new Error(`Failed to get add-question disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isAddQuestionTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const addQuestion = this.webActionHandler.getWebElement(this.getResource('addQuestionLink'));
      await addQuestion.executeScript((e) => e.scrollIntoView());
      await addQuestion.hover();
      const message = this.webActionHandler.getWebElement(this.getResource('maxQuestionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait, no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off the hovered button so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check add-question tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getDuplicateQuestionElement(questionIndex = 0) {
    const duplicateResource = this.getResource('duplicateQuestionButton');
    return this.webActionHandler.getWebElement({
      ...duplicateResource,
      selectorType: 'playwrights',
      selectorValue: `${duplicateResource.selectorValue} >> nth=${questionIndex}`,
    });
  }

  private getDeleteQuestionElement(questionIndex = 0) {
    const deleteResource = this.getResource('deleteQuestionButton');
    return this.webActionHandler.getWebElement({
      ...deleteResource,
      selectorType: 'playwrights',
      selectorValue: `${deleteResource.selectorValue} >> nth=${questionIndex}`,
    });
  }

  private getQuestionRowElement(questionIndex = 0) {
    const rowResource = this.getResource('questionRow');
    return this.webActionHandler.getWebElement({
      ...rowResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${questionIndex}`,
    });
  }

  async deleteQuestionAt(index: number): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await row.hover();
      const deleteButton = this.getDeleteQuestionElement(index);
      await this.waitUntilVisible(deleteButton, `Delete question button (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await deleteButton.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to delete question (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  async duplicateQuestionAt(index: number): Promise<void> {
    try {
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await row.hover();
      const duplicateButton = this.getDuplicateQuestionElement(index);
      await this.waitUntilVisible(duplicateButton, `Duplicate question button (index ${index})`, ELEMENT_WAIT_TIMEOUT);
      await duplicateButton.click();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } catch (error) {
      throw new Error(`Failed to duplicate question (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  async dragQuestionRow(fromIndex: number, toIndex: number): Promise<void> {
    try {
      const row = this.getQuestionRowElement(fromIndex);
      await this.waitUntilVisible(row, `Question row (index ${fromIndex})`, ELEMENT_WAIT_TIMEOUT);
      await row.hover();

      const rowResource = this.getResource('questionRow');
      const handle = this.webActionHandler.getWebElement({
        ...rowResource,
        selectorType: 'playwrights',
        selectorValue: `${rowResource.selectorValue} >> nth=${fromIndex} >> .drag-handle`,
      });
      await this.waitUntilVisible(handle, `Drag handle (index ${fromIndex})`, ELEMENT_WAIT_TIMEOUT);

      const sourceText = await this.getQuestionTextDisplay(fromIndex);

      const handleBox = await handle.executeScript((e) => {
        const r = e.getBoundingClientRect();
        return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
      });
      const targetRow = this.getQuestionRowElement(toIndex);
      await this.waitUntilVisible(targetRow, `Question row (index ${toIndex})`, ELEMENT_WAIT_TIMEOUT);
      const targetRect = await targetRow.executeScript((e) => {
        const r = e.getBoundingClientRect();
        return { x: r.x + r.width / 2, top: r.top, height: r.height };
      });
      const movingDown = toIndex > fromIndex;
      const targetBox = { x: targetRect.x, y: targetRect.top + targetRect.height * (movingDown ? 0.75 : 0.25) };

      const nativePage = (BasePage as any).page as import('playwright').Page; // gta exposes no public getter for the raw Page, and WebActions has no mouse-move-steps API
      await nativePage.mouse.move(handleBox.x, handleBox.y);
      await nativePage.mouse.down();
      const STEPS = 10;
      for (let step = 1; step <= STEPS; step++) {
        await nativePage.mouse.move(
          handleBox.x + ((targetBox.x - handleBox.x) * step) / STEPS,
          handleBox.y + ((targetBox.y - handleBox.y) * step) / STEPS
        );
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      await nativePage.mouse.up();
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      const deadline = Date.now() + ELEMENT_WAIT_TIMEOUT;
      while (Date.now() <= deadline) {
        const text = await this.getQuestionTextDisplay(toIndex);
        if (Date.now() > deadline) {
          break;
        }
        if (text === sourceText) {
          break;
        }
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }
      if (Date.now() > deadline) {
        throw new Error(`Wait for dragged question to settle at index ${toIndex} timed out after ${ELEMENT_WAIT_TIMEOUT}ms`);
      }
    } catch (error) {
      throw new Error(`Failed to drag question row (from ${fromIndex} to ${toIndex}): ${error instanceof Error ? error.message : error}`);
    }
  }

  private async getButtonDisabledState(
    resourceName: string
  ): Promise<{ disabled: boolean; hostOuterHtml: string; innerButtonOuterHtml: string | null; matchCount: number; innerText: string }> {
    const matchCount = (await this.webActionHandler.getWebElementsText(this.getResource(resourceName))).length;
    const button = this.webActionHandler.getWebElement(this.getResource(resourceName));
    const innerText = (await button.getText()).trim();
    const ariaDisabled = await button.getAttribute('aria-disabled');
    const state = await button.getAttribute('state');
    const disabledAttr = await button.getAttribute('disabled');
    const classAttr = (await button.getAttribute('class')) ?? '';
    const hostOuterHtml = String(await button.executeScript((e) => e.outerHTML)).slice(0, 400);
    const innerButtonDisabled = await button.executeScript((e) => {
      const inner = e.querySelector('button');
      return inner ? inner.disabled : null;
    });
    const innerButtonOuterHtml = await button.executeScript((e) => {
      const inner = e.querySelector('button');
      return inner ? inner.outerHTML : null;
    });
    const disabled =
      ariaDisabled === 'true' ||
      state === 'disabled' ||
      disabledAttr !== null ||
      classAttr.split(/\s+/).includes('disabled') ||
      innerButtonDisabled === true;
    return {
      disabled,
      hostOuterHtml,
      innerButtonOuterHtml: innerButtonOuterHtml === null ? null : String(innerButtonOuterHtml).slice(0, 400),
      matchCount,
      innerText,
    };
  }

  async getPublishDisabledState(): Promise<{
    disabled: boolean;
    hostOuterHtml: string;
    innerButtonOuterHtml: string | null;
    matchCount: number;
    innerText: string;
  }> {
    try {
      return await this.getButtonDisabledState('publishSurveyButton');
    } catch (error) {
      throw new Error(`Failed to get publish disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getValidateDisabledState(): Promise<{
    disabled: boolean;
    hostOuterHtml: string;
    innerButtonOuterHtml: string | null;
    matchCount: number;
    innerText: string;
  }> {
    try {
      return await this.getButtonDisabledState('validateSurveyButton');
    } catch (error) {
      throw new Error(`Failed to get validate disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isValidateSurveyButtonVisible(timeoutMs: number = SMALL_TIMEOUT): Promise<boolean> {
    const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
    return await validateButton.isVisible(timeoutMs);
  }

  async areAddQuestionOptionsVisible(timeoutMs: number = ELEMENT_WAIT_TIMEOUT): Promise<boolean> {
    try {
      const ratingTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));
      return await ratingTile.isVisible(timeoutMs);
    } catch (error) {
      throw new Error(`Failed to check add-question options visibility: ${error instanceof Error ? error.message : error}`);
    }
  }

  async openAddQuestionPanel(): Promise<void> {
    try {
      if (await this.areAddQuestionOptionsVisible(SMALL_TIMEOUT)) {
        return;
      }
      await this.clickAddQuestion();
      if (!(await this.areAddQuestionOptionsVisible(SMALL_TIMEOUT))) {
        await this.clickAddQuestion();
      }
      const ratingTile = this.webActionHandler.getWebElement(this.getResource('questionTypeRating'));
      await ratingTile.waitFor(ELEMENT_WAIT_TIMEOUT, 'visible');
    } catch (error) {
      throw new Error(`Failed to open Add Question panel: ${error instanceof Error ? error.message : error}`);
    }
  }

  async deleteQuestionsDownTo(remaining: number): Promise<void> {
    try {
      const initialCount = await this.getQuestionCount();
      if (initialCount <= remaining) {
        return;
      }
      await this.enterReviewMode();
      const count = await this.getQuestionCount();
      if (remaining <= 0) {
        await this.selectAll();
      } else {
        for (let index = remaining; index < count; index++) {
          await this.selectQuestionInReview(index);
        }
      }
      await this.deleteSelectedQuestions();
      const exitButton = this.webActionHandler.getWebElement(this.getResource('exitReviewModeButton'));
      if (!(await exitButton.isHidden())) {
        await this.exitReviewMode();
      }
    } catch (error) {
      throw new Error(`Failed to delete questions down to ${remaining}: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isDuplicateTooltipVisibleOnHover(): Promise<boolean> {
    try {
      const row = this.getQuestionRowElement();
      const duplicateButton = this.getDuplicateQuestionElement();
      const duplicateResource = this.getResource('duplicateQuestionButton');
      const nativePage = (BasePage as any).page as import('playwright').Page; 
      let lastError: unknown;
      let hovered = false;
      for (let attempt = 1; attempt <= 3 && !hovered; attempt++) {
        try {
          await row.hover();
          if (!(await duplicateButton.isVisible(SMALL_TIMEOUT))) {
            await this.webActionHandler.mouseMove(0, 0);
            await row.hover();
            await this.waitUntilVisible(duplicateButton, 'Duplicate question button', SMALL_TIMEOUT);
          }
          await duplicateButton.executeScript((e) => e.scrollIntoView());
          await nativePage.locator(duplicateResource.selectorValue).first().hover({ force: true, timeout: SMALL_TIMEOUT });
          hovered = true;
        } catch (error) {
          lastError = error;
          if (attempt < 3) {
            await this.webActionHandler.mouseMove(0, 0);
          }
        }
      }
      if (!hovered) {
        throw lastError;
      }
      const message = this.webActionHandler.getWebElement(this.getResource('maxQuestionsMessageText'));
      const isTooltipVisible = await message.isVisible(MEDIUM_TIMEOUT); // web-first wait (10s), no fixed delay
      await this.webActionHandler.mouseMove(0, 0); // move off Duplicate so the tooltip doesn't linger into the next test
      await message.waitFor(MEDIUM_TIMEOUT, 'hidden');
      return isTooltipVisible;
    } catch (error) {
      throw new Error(`Failed to check duplicate tooltip on hover: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getDuplicateDisabledState(): Promise<{ disabled: boolean; outerHtml: string }> {
    try {
      const duplicateButton = this.getDuplicateQuestionElement();
      const ariaDisabled = await duplicateButton.getAttribute('aria-disabled');
      const state = await duplicateButton.getAttribute('state');
      const outerHtml = String(await duplicateButton.executeScript((e) => e.outerHTML)).slice(0, 400);
      return { disabled: ariaDisabled === 'true' || state === 'disabled', outerHtml };
    } catch (error) {
      throw new Error(`Failed to get duplicate disabled state: ${error instanceof Error ? error.message : error}`);
    }
  }

  async clickValidateSurvey(): Promise<void> {
    await this.clickWhenVisible('validateSurveyButton', 'Validate survey button');
  }

  async waitForValidationComplete(): Promise<void> {
    const nativePage = (BasePage as any).page as import('playwright').Page;
    await nativePage.locator("[data-test-id='survey-validation-loader']").waitFor({ state: 'hidden', timeout: NAVIGATION_TIMEOUT });
  }

  async validateSurvey(): Promise<void> {
    try {
      await this.clickValidateSurvey();
      await this.waitForValidationComplete();
    } catch (error) {
      throw new Error(`Failed to validate survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  async isValidatingToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(this.getResource('validatingSurveyToastText'));
    return await toast.isVisible(SMALL_TIMEOUT);
  }

  async isChangesRecommendedToastVisible(): Promise<boolean> {
    const toast = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    return await toast.isVisible(SMALL_TIMEOUT);
  }

  /** True if any of the three post-validation result toasts (complete / recommended / needed) is visible. */
  async isValidationResultToastVisible(): Promise<boolean> {
    const complete = this.webActionHandler.getWebElement(this.getResource('validationCompleteToastText'));
    const recommended = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    const needed = this.webActionHandler.getWebElement(this.getResource('changesNeededToastText'));
    // Checked in parallel: the result toast auto-hides, so sequential checks can miss it.
    const [isCompleteVisible, isRecommendedVisible, isNeededVisible] = await Promise.all([
      complete.isVisible(SMALL_TIMEOUT),
      recommended.isVisible(SMALL_TIMEOUT),
      needed.isVisible(SMALL_TIMEOUT),
    ]);
    return isCompleteVisible || isRecommendedVisible || isNeededVisible;
  }

  async isRecommendationTagVisible(): Promise<boolean> {
    const tag = this.webActionHandler.getWebElement(this.getResource('recommendationTagText'));
    return await tag.isVisible(SMALL_TIMEOUT);
  }

  /** Which of the three post-validation result toasts (complete / recommended / needed) is showing, or 'none' if none is. */
  async getValidationOutcome(): Promise<'complete' | 'recommended' | 'needed' | 'none'> {
    const complete = this.webActionHandler.getWebElement(this.getResource('validationCompleteToastText'));
    const recommended = this.webActionHandler.getWebElement(this.getResource('changesRecommendedToastText'));
    const needed = this.webActionHandler.getWebElement(this.getResource('changesNeededToastText'));
    // Checked in parallel: the result toast auto-hides, so sequential checks can miss it.
    const [isCompleteVisible, isRecommendedVisible, isNeededVisible] = await Promise.all([
      complete.isVisible(SMALL_TIMEOUT),
      recommended.isVisible(SMALL_TIMEOUT),
      needed.isVisible(SMALL_TIMEOUT),
    ]);
    if (isNeededVisible) {
      return 'needed';
    }
    if (isRecommendedVisible) {
      return 'recommended';
    }
    if (isCompleteVisible) {
      return 'complete';
    }
    return 'none';
  }

  /** Persistent (non-toast) signal that validation finished: 'publishSurveyButton' has replaced 'validateSurveyButton'. */
  async isValidationCompleted(): Promise<boolean> {
    const publishButton = this.webActionHandler.getWebElement(this.getResource('publishSurveyButton'));
    const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
    const [isPublishVisible, isValidateHidden] = await Promise.all([
      publishButton.isVisible(ELEMENT_WAIT_TIMEOUT),
      validateButton.isHidden(),
    ]);
    return isPublishVisible && isValidateHidden;
  }

  async isViewOptiqFeedbackLinkVisible(): Promise<boolean> {
    const link = this.webActionHandler.getWebElement(this.getResource('viewOptiqFeedbackLink'));
    return await link.isVisible(SMALL_TIMEOUT);
  }

  /** Closes the validate/publish toast if one is still showing; best-effort, never throws (the close button can match an element that is not clickable). */
  async dismissToastIfVisible(): Promise<void> {
    try {
      const nativePage = (BasePage as any).page as import('playwright').Page; // first-visible match + short click timeout need Playwright's locator API
      const closeButton = nativePage.locator(`${this.getResource('toastCloseButton').selectorValue} >> visible=true >> nth=0`);
      await closeButton.waitFor({ state: 'visible', timeout: SMALL_TIMEOUT });
      await closeButton.click({ timeout: SMALL_TIMEOUT });
    } catch {
      // no toast to close, or the button could not be clicked: carry on
    }
  }


  async openPublishDialog(): Promise<void> {
    try {
      const validateButton = this.webActionHandler.getWebElement(this.getResource('validateSurveyButton'));
      if (await validateButton.isVisible(SMALL_TIMEOUT)) {
        await this.validateSurvey();
      }
      await this.dismissToastIfVisible();

      await this.clickWhenVisible('publishSurveyButton', 'Publish survey button');
    } catch (error) {
      throw new Error(`Failed to open Publish dialog: ${error instanceof Error ? error.message : error}`);
    }
  }

  async publishSurvey(title: string): Promise<void> {
    try {
      await this.openPublishDialog();

      const titleInput = this.webActionHandler.getWebElement(this.getResource('saveCopyTitleInput'));
      const confirmDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      const [isTitleInputVisible, isConfirmDialogVisible] = await Promise.all([
        titleInput.isVisible(ELEMENT_WAIT_TIMEOUT),
        confirmDialogText.isVisible(ELEMENT_WAIT_TIMEOUT),
      ]);

      if (isTitleInputVisible) {
        await this.fillSaveCopyDialog(title);
      } else if (!isConfirmDialogVisible) {
        const currentUrl = await this.webActionHandler.getPageUrl();
        throw new Error(
          `Neither the Save-a-copy dialog nor the Review survey details dialog appeared after clicking Publish (url: ${currentUrl})`
        );
      }
    } catch (error) {
      throw new Error(`Failed to publish survey: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Checks the last expected dimension index is visible in the Review survey details dialog's Quick review list. */
  async isPublishDialogDimensionCountVisible(expectedCount: number): Promise<boolean> {
    try {
      if (expectedCount <= 0) return true;
      const lastDimension = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource(
          'publish-dialog-dimension-by-index',
          String(expectedCount - 1),
          SURVEY_BUILDER_PAGE_COMPONENT_NAME
        )
      );
      await this.waitUntilVisible(lastDimension, `Publish dialog dimension (index ${expectedCount - 1})`, 10000);
      return await lastDimension.isVisible(10000);
    } catch (error) {
      throw new Error(`Failed to verify Review survey details dimension count: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getPublishResponseSummaryText(): Promise<string> {
    try {
      const responseCount = this.webActionHandler.getWebElement(this.getResource('publish-response-count-text'));
      await this.waitUntilVisible(responseCount, 'Publish response count text', 10000);
      const text = await responseCount.getText();
      return (text ?? '').trim();
    } catch (error) {
      throw new Error(`Failed to read Review survey details response summary: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Polls until the redirect to /my-assets (success = redirect, whether or not the "published successfully" toast is still showing), or fails fast if `.survey-action-toast` shows non-success text (there's no separate error-only locator). */
  async verifyPublishSucceeded(confirmClickTime: number): Promise<boolean> {
    try {
      const elapsedSeconds = () => ((Date.now() - confirmClickTime) / 1000).toFixed(1);
      const actionToast = this.webActionHandler.getWebElement(this.getResource('survey-action-toast'));

      const deadline = Date.now() + NAVIGATION_TIMEOUT;
      while (Date.now() < deadline) {
        const currentUrl = await this.webActionHandler.getPageUrl();

        if (!(await actionToast.isHidden()) && this.lastPublishStatus !== undefined && this.lastPublishStatus >= 400) {
          const toastText = await actionToast.getText();
          throw new Error(`Publish failed: "${toastText}" (HTTP ${this.lastPublishStatus}, url: ${currentUrl}, elapsed: ${elapsedSeconds()}s)`);
        }

        if (currentUrl.includes('my-assets')) {
          return true;
        }

        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }

      const currentUrl = await this.webActionHandler.getPageUrl();
      const toastText = (await actionToast.isVisible()) ? await actionToast.getText() : 'none visible';
      throw new Error(
        `Timed out waiting for navigation to /my-assets after Confirm (url: ${currentUrl}, elapsed: ${elapsedSeconds()}s, .survey-action-toast text: ${toastText})`
      );
    } catch (error) {
      throw new Error(`Failed to verify publish succeeded: ${error instanceof Error ? error.message : error}`);
    }
  }

  async confirmPublish(): Promise<boolean> {
    try {
      const confirmPublishDialogText = this.webActionHandler.getWebElement(this.getResource('confirmPublishDialogText'));
      await this.waitUntilVisible(confirmPublishDialogText, 'Review survey details dialog text');
      const isConfirmDialogVisible = await confirmPublishDialogText.isVisible();

      const publishButton = this.getScopedElement('reviewSurveyDetailsDialog', 'reviewDialogPublishButton');
      await this.waitUntilVisible(publishButton, 'Review survey details Publish survey button (confirm-publish)');

      // Diagnostic only: log the failing publish request/response once. Logging must never affect the test.
      const nativePage = (BasePage as any).page as import('playwright').Page;
      const logFailedPublish = async (response: import('playwright').Response): Promise<void> => {
        if (!response.url().includes('/api/v1/publish')) {
          return;
        }
        nativePage.off('response', logFailedPublish);
        this.lastPublishStatus = response.status();
        try {
          const status = this.lastPublishStatus;
          if (status < 400) {
            return;
          }
          console.log(`Publish request failed with status ${status}`);
          const postData = (response.request().postData() ?? '').slice(0, 3000);
          console.log(`Publish request post data: ${postData}`);
          const responseBody = (await response.text()).slice(0, 2000);
          console.log(`Publish response body: ${responseBody}`);
        } catch {
          // body no longer available: ignore, this is logging only
        }
      };
      nativePage.on('response', logFailedPublish);
      this.lastPublishStatus = undefined;
      try {
        await publishButton.click();
      } catch (clickError) {
        nativePage.off('response', logFailedPublish);
        throw clickError;
      }

      const publishingSurveyStatus = this.webActionHandler.getWebElement(this.getResource('publishingSurveyStatus'));
      await this.waitUntilVisible(publishingSurveyStatus, 'Publishing survey status');
      const isPublishingStatusVisible = await publishingSurveyStatus.isVisible();

      return isConfirmDialogVisible && isPublishingStatusVisible;
    } catch (error) {
      throw new Error(`Failed to confirm publish: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Commits a title edit via Tab (blur), since fill()/enterText() never blurs the field and this component only saves on blur. */
  async commitSurveyTitle(): Promise<void> {
    try {
      const titleInput = this.webActionHandler.getWebElement(this.getResource('surveyTitleInput'));
      await titleInput.pressTab();
    } catch (error) {
      throw new Error(`Failed to commit survey title: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getSurveyTitleDisplay(): Promise<string> {
    try {
      const title = this.webActionHandler.getWebElement(this.getResource('surveyTitleDisplay'));
      await this.waitUntilVisible(title, 'Survey title display');
      return (await title.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read survey title display: ${error instanceof Error ? error.message : error}`);
    }
  }

  async getSurveyTitleValue(): Promise<string> {
    try {
      const titleInput = this.webActionHandler.getWebElement(this.getResource('surveyTitleInput'));
      return titleInput.getValue();
    } catch (error) {
      throw new Error(`Failed to read survey title value: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getQuestionTextDisplayElement(index: number) {
    const resource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...resource,
      selectorType: 'css',
      selectorValue: `[data-test-id='question-text-${index + 1}']`,
    });
  }

  /** Reads row `index`'s SAVED Required state from the "*" span, text-filtered so it can't match any sibling span; a short, non-hanging timeout since this is a point-in-time read. */
  private getRequiredStarElement(index: number) {
    const textResource = this.getResource('questionTextDisplay');
    return this.webActionHandler.getWebElement({
      ...textResource,
      selectorType: 'css',
      selectorValue: `[data-test-id='question-required-marker-${index + 1}']`,
    });
  }

  async isRequiredOn(index: number): Promise<boolean> {
    try {
      return await this.getRequiredStarElement(index).isVisible(SMALL_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to check Required state (index ${index}): ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Waits (bounded, no indefinite hang) for row `index`'s saved Required state to reach `desired`; returns
   *  false (not throw) on timeout so callers can produce their own assertion message. */
  async waitForRequiredState(index: number, desired: boolean, timeoutMs: number = MEDIUM_TIMEOUT): Promise<boolean> {
    try {
      const star = this.getRequiredStarElement(index);
      await star.waitFor(timeoutMs, desired ? 'visible' : 'hidden');
      return (await star.isHidden()) === !desired;
    } catch {
      return false;
    }
  }

  /** No-op if Required already matches `desired` (AI-generated questions may start Required ON); opens the row editor, toggles, saves, then confirms the change. */
  async setRequired(index: number, desired: boolean): Promise<void> {
    try {
      await this.openQuestionForEditing(index);
      // Reads the toggle's own state in the open editor and clicks only when it differs from `desired`.
      const rowResource = this.getResource('questionRow');
      const toggleResource = this.getResource('requiredToggle');
      const toggle = this.webActionHandler.getWebElement({
        ...toggleResource,
        selectorType: 'playwrights',
        selectorValue: `${rowResource.selectorValue} >> nth=${index} >> ${toggleResource.selectorValue}`,
      });
      await this.waitUntilVisible(toggle, `Required toggle (index ${index})`);
      const ariaChecked = await toggle.getAttribute('aria-checked');
      const isToggleOn = ariaChecked !== null ? ariaChecked === 'true' : Boolean(await toggle.executeScript((e) => (e as HTMLInputElement).checked));
      if (isToggleOn !== desired) {
        await this.toggleRequired(index);
      }
      await this.saveQuestionChanges(index);
      if (!(await this.waitForRequiredState(index, desired, MEDIUM_TIMEOUT))) {
        throw new Error(
          `Required state for question ${index} did not reach ${desired} within ${MEDIUM_TIMEOUT}ms (step: waitForRequiredState)`
        );
      }
    } catch (error) {
      throw new Error(`Failed to set Required (index ${index}) to ${desired}: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Readonly display text includes a trailing `*` when Required is on. */
  async getQuestionTextDisplay(index: number): Promise<string> {
    try {
      const textElement = this.getQuestionTextDisplayElement(index);
      await this.waitUntilVisible(textElement, `Question text display (index ${index})`);
      return (await textElement.getText()).trim();
    } catch (error) {
      throw new Error(`Failed to read question ${index} text display: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Hovers row `index` (same hover-reveal gating as getQuestionRowElement()) then clicks Edit and waits for the editor to open. */
  async openQuestionForEditing(index: number): Promise<void> {
    try {
      await this.closeInlineAddEditorIfOpen();
      const rowResource = this.getResource('questionRow');
      const rowLocator = `${rowResource.selectorValue} >> nth=${index}`;
      const row = this.getQuestionRowElement(index);
      await this.waitUntilVisible(row, `Question row (step: hover, index ${index}, locator: ${rowLocator})`, ELEMENT_WAIT_TIMEOUT);
      await row.hover();
      const editButtonResource = this.getResource('editQuestionButton');
      const editButtonLocator = `${editButtonResource.selectorValue} >> nth=${index}`;
      const editButton = this.webActionHandler.getWebElement({
        ...editButtonResource,
        selectorType: 'playwrights',
        selectorValue: editButtonLocator,
      });
      await this.waitUntilVisible(
        editButton,
        `Edit question button (step: click edit pencil, index ${index}, locator: ${editButtonLocator})`,
        ELEMENT_WAIT_TIMEOUT
      );
      await editButton.click();
      const saveButtonResource = this.getResource('saveQuestionChangesButton');
      const saveButton = this.webActionHandler.getWebElement(saveButtonResource);
      await this.waitUntilVisible(
        saveButton,
        `Save changes button (step: question editor open, index ${index}, locator: ${saveButtonResource.selectorValue})`,
        ELEMENT_WAIT_TIMEOUT
      );
    } catch (error) {
      throw new Error(`Failed to open question ${index} for editing: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Resolves the Save changes button, scoped to `index`'s row when given so it can't click another open editor's Save button. */
  private getSaveChangesButtonElement(index?: number): ReturnType<WebActions['getWebElement']> {
    if (index === undefined) {
      return this.webActionHandler.getWebElement(this.getResource('saveQuestionChangesButton'));
    }
    const rowResource = this.getResource('questionRow');
    const saveButtonResource = this.getResource('saveQuestionChangesButton');
    return this.webActionHandler.getWebElement({
      ...saveButtonResource,
      selectorType: 'playwrights',
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> [data-test-id='save-question-changes']:visible`,
    });
  }

  /** Clicks Save changes once with no outside-click/Discard fallback; use when Save is expected to be blocked (e.g. empty question text) so the editor is left open for the caller to assert. */
  async clickSaveChangesOnce(index?: number): Promise<void> {
    try {
      const saveButton = this.getSaveChangesButtonElement(index);
      await this.waitUntilVisible(saveButton, index === undefined ? 'Save changes button' : `Save changes button (index ${index})`);
      await saveButton.click();
    } catch (error) {
      throw new Error(`Failed to click Save changes: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** When `index` is given, scopes Save changes to that row so it can't click another open editor's Save button. */
  async saveQuestionChanges(index?: number): Promise<void> {
    try {
      const saveButton = this.getSaveChangesButtonElement(index);
      await this.waitUntilVisible(saveButton, index === undefined ? 'Save changes button' : `Save changes button (index ${index})`);
      await saveButton.click();

      // Some question types (e.g. AI Multi Scale) leave the editor open after Save changes; click outside the card to close it.
      if (await saveButton.isVisible(SMALL_TIMEOUT)) {
        const header = this.webActionHandler.getWebElement(this.getResource('surveyTitleDisplay'));
        await header.click();
        await saveButton.waitFor(ELEMENT_WAIT_TIMEOUT, 'hidden');

        // Outside click didn't close it either; fall back to Discard.
        if (!(await saveButton.isHidden())) {
          await this.clickDiscardChanges();
          await saveButton.waitFor(ELEMENT_WAIT_TIMEOUT, 'hidden');
          if (await this.isEditorOpen()) {
            throw new Error(`Editor stayed open after Save, outside click and Discard (question index ${index})`);
          }
        }
      }
    } catch (error) {
      throw new Error(`Failed to save question changes: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** True while a question editor is expanded (addOptionButton only renders for Choice types; save-changes renders for every editable type). */
  async isEditorOpen(): Promise<boolean> {
    const addOptionButton = this.webActionHandler.getWebElement(this.getResource('addOptionButton'));
    const saveButton = this.webActionHandler.getWebElement(this.getResource('saveQuestionChangesButton'));
    return (await addOptionButton.isVisible(SMALL_TIMEOUT)) || (await saveButton.isVisible(SMALL_TIMEOUT));
  }

  /** Discards unsaved changes on the currently open question editor. */
  async clickDiscardChanges(): Promise<void> {
    try {
      const discardButton = this.webActionHandler.getWebElement(this.getResource('discardChangesButton'));
      await this.waitUntilVisible(discardButton, 'Discard changes button');
      await discardButton.click();
    } catch (error) {
      throw new Error(`Failed to discard question changes: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** Rating leaves its text-input `data-test-id` unset (defaults to "-input"); Choice/NPS/Scale set it explicitly, so matching the common `-input` suffix works for every question type without depending on index alignment. */
  private getQuestionTextFieldElement(index: number) {
    const rowResource = this.getResource('questionRow');
    const textResource = this.getResource('questionTextInput');
    return this.webActionHandler.getWebElement({
      ...textResource,
      selectorType: 'playwrights',
      // nth=0 picks the question-text field, always the first survey-question-editor input in DOM order.
      selectorValue: `${rowResource.selectorValue} >> nth=${index} >> survey-question-editor input:is([data-test-id$='-input'], [data-test-id^='question-text-input']):visible >> nth=0`,
    });
  }

  /** Opens question `index` for editing, replaces its text, and saves. */
  async editQuestionText(index: number, newText: string): Promise<void> {
    try {
      await this.openQuestionForEditing(index);
      const textField = this.getQuestionTextFieldElement(index);
      await this.waitUntilVisible(textField, `Question text field (index ${index})`);
      await textField.enterText(newText);
      await this.saveQuestionChanges(index);
    } catch (error) {
      throw new Error(
        `Failed to edit question ${index} text (expected text field to accept "${newText}" and save): ${error instanceof Error ? error.message : error}`
      );
    }
  }

  /** Replaces question `index`'s text in its already-open editor, without saving/discarding. */
  async enterQuestionText(index: number, newText: string): Promise<void> {
    try {
      const textField = this.getQuestionTextFieldElement(index);
      await this.waitUntilVisible(textField, `Question text field (index ${index})`);
      await textField.enterText(newText);
    } catch (error) {
      throw new Error(`Failed to enter question ${index} text ("${newText}"): ${error instanceof Error ? error.message : error}`);
    }
  }
}
