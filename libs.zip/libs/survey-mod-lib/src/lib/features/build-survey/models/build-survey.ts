import { DimensionSelection, Prompt, ReportSpecObject, RequestInstance } from '@nielsen/crf-common';
import { Asset } from '@nielsen/crf-lp-common';

export interface QuestionTypeOption {
  label: string;
  value: QuestionType;
  iconName?: string;
}

export const QuestionTypes = {
  SingleChoice: 'SINGLE_CHOICE',
  MultipleChoice: 'MULTIPLE_CHOICE',
  Text: 'TEXT',
  SinglePointScale: 'SINGLE_POINT_SCALE',
  MultiplePointScale: 'MULTIPLE_POINT_SCALE',
  NetPromoterScore: 'NET_PROMOTER_SCORE',
  StarRating: 'STAR_RATING',
} as const;

export type QuestionType = (typeof QuestionTypes)[keyof typeof QuestionTypes];

export const ChoiceQuestionTypes: QuestionType[] = [
  QuestionTypes.SingleChoice,
  QuestionTypes.MultipleChoice,
];

export const ScaleQuestionTypes: QuestionType[] = [
  QuestionTypes.SinglePointScale,
  QuestionTypes.MultiplePointScale,
];

// Survey button widget types for different question types
export const QuestionTypeOptions: QuestionTypeOption[] = [
  { label: 'SURVEYMOD_SINGLE_CHOICE', value: QuestionTypes.SingleChoice, iconName: 'survey-single-choice' },
  { label: 'SURVEYMOD_MULTIPLE_CHOICE', value: QuestionTypes.MultipleChoice, iconName: 'survey-multi-choice' },
  { label: 'SURVEYMOD_RATING', value: QuestionTypes.StarRating, iconName: 'star' },
  // { label: 'Text', value: QuestionTypes.Text, iconName: 'rename'},  //TEXT question type removed from MVP scope. TODO: Re-enable in future release.
  { label: 'SURVEYMOD_NET_PROMOTER_SCORE', value: QuestionTypes.NetPromoterScore, iconName: 'dashboard' },
  { label: 'SURVEYMOD_POINT_SCALE', value: QuestionTypes.SinglePointScale, iconName: 'survey-point-scale' },
  { label: 'SURVEYMOD_MULTI_SCALE', value: QuestionTypes.MultiplePointScale, iconName: 'survey-multi-scale' },
];

export const DefaultQuestionTypes: QuestionType[] = [
  QuestionTypes.SingleChoice,
  QuestionTypes.MultipleChoice,
  QuestionTypes.StarRating,
  QuestionTypes.NetPromoterScore,
  QuestionTypes.SinglePointScale,
  QuestionTypes.MultiplePointScale,
];

export interface GenerateQuestionsRequest {
  questionCount: number;
  questionTypes: QuestionType[];
}

export interface GenerateSurveyPrompt {
  demographic: string;
  geography: string;
  period: string;
  product: string;
  questionCount: number;
  questionTypes: QuestionType[];
  retailer: string;
  systemPrompt?: string;
  userPrompt: string;
}

export interface GenerateSurveyPayload {
  prompt: GenerateSurveyPrompt;
}

export interface ExcludeQuestion {
  text: string;
}

export interface AddMoreQuestionsPrompt {
  userPrompt: string;
  product: string;
  retailer: string;
  geography: string;
  demographic: string;
  period: string;
  questionCount: number;
  excludeQuestions: ExcludeQuestion[];
  questionTypes: QuestionType[];
}

export interface AddMoreQuestionsPayload {
  prompt: AddMoreQuestionsPrompt;
}

export const DimensionKeys = {
  demographic: 'DEMO',
  geography: 'GEO',
  period: 'PRD',
  product: 'PRDC',
  retailer: 'RTLR',
} as const;

export const AddMoreQuestionDefaultPromptValues = {
  demographic: 'Adults 18-45',
  geography: 'United States',
  period: 'Last 30 days',
  product: 'Snacks',
  retailer: 'All Retailers',
  userPrompt: 'Generate additional relevant survey questions',
} as const;

export const ADD_MORE_QUESTIONS_DEFAULT_COUNT = 3;
export const QUESTION_COUNT_DEFAULT = 5;
export const MAX_SURVEY_QUESTIONS = 10;

export interface QuestionModel {
  questionNumber?: number;
  question: string;
  options?: string[];
  isRequired: boolean;
  type: string;

  // required for scale questions
  rowOptions?: string[];
  columnOptions?: string[];
  npsLeftLabel?: string;
  npsRightLabel?: string;

  //AI Validation related optional fields
  id?: string;
  reviewRequired?: boolean;
  status?: QuestionValidationStatus;
  suggestions?: AiSuggestion[];
  order?: number;
}

export function createAddMoreQuestionsPayload(
  firstLabel: (dimId: string) => string,
  userPrompt: string,
  excludeQuestions: ExcludeQuestion[],
  questionTypes: QuestionType[],
  questionCount: number = ADD_MORE_QUESTIONS_DEFAULT_COUNT
): AddMoreQuestionsPayload {
  const nonEmpty = (value: string | undefined | null, fallback: string): string => {
    const trimmed = (value ?? '').trim();
    return trimmed || fallback;
  };

  return {
    prompt: {
      demographic: nonEmpty(firstLabel(DimensionKeys.demographic), AddMoreQuestionDefaultPromptValues.demographic),
      geography: nonEmpty(firstLabel(DimensionKeys.geography), AddMoreQuestionDefaultPromptValues.geography),
      period: nonEmpty(firstLabel(DimensionKeys.period), AddMoreQuestionDefaultPromptValues.period),
      product: nonEmpty(firstLabel(DimensionKeys.product), AddMoreQuestionDefaultPromptValues.product),
      questionCount,
      retailer: nonEmpty(firstLabel(DimensionKeys.retailer), AddMoreQuestionDefaultPromptValues.retailer),
      userPrompt: nonEmpty(userPrompt, AddMoreQuestionDefaultPromptValues.userPrompt),
      excludeQuestions,
      questionTypes,
    },
  };
}

export interface RephraseQuestionsPayload {
  question: QuestionModel;
  userPrompt: string;
}

export type SurveyStatus = SurveyStatusType.DRAFT | SurveyStatusType.PUBLISHED | SurveyStatusType.LIVE | SurveyStatusType.CLOSED | SurveyStatusType.FAILED;

export enum SurveyStatusType {
  DRAFT = 'DRAFT',
  PUBLISHED = 'PUBLISHED',
  LIVE = 'LIVE',
  CLOSED = 'CLOSED',
  FAILED = 'FAILED'
}

// Survey payload defaults for creating a new survey
export const SURVEY_PAYLOAD_DEFAULTS = {
  emptyText: '',
  version: '1',
  source: 'DISCOVER-UI',
  sourceType: 'NG2PORTAL',
  application: 'DISCOVER',
  locale: 'en-US',
  launchUrl: 'survey/build-survey',
  untitledName: 'Untitled Survey',
  maxResponsesPerPanelist: 1,
  reportType: 'layoutEditor',
  assetType: 'DISCOVERSURVEY',
  folderType: 'SURVEY',
} as const;

export const SURVEY_ID_PREFIX = 'svy_';

export type SaveDraftDynamics = {
  targetCompletes?: number | null;
  invitesSent?: number | null;
  reportJobId?: string | null;
  panelistJobId?: string | null;
  dataViewId?: string | null;
  userId?: string | null;
  applicationId?: string | null;
  clientId?: string | null;
  emailId?: string | null;
  locale?: string | null;
}

export interface SurveyFolderSelection {
  folderId: string;
  name: string;
}

export interface SaveDraftDialogResult {
  title: string;
  folder: Asset;
}

export interface SavedSurveyDetails {
  description?: string;
  folder?: SurveyFolderSelection | null;
  name: string;
  surveyId?: string;
  questions: Array<Record<string, unknown>>;
  metadata: {
    questionTypes: QuestionType[];
    userPrompts: string[];
  };
  assetInfo?: {
    assetId?: string;
    status?: SurveyStatus;
    title?: string;
    launchURL?: string;
    parameters?: {
      dataViewId: string;
    };
  };
  reportInfo: {
    jobId: string;
  };
  reportDetail?: SavedSurveyReportDetail | null;
  panelists: {
    targetCompletes: number;
  };
}

export interface SavedSurveyReportDetail {
  reportSpec?: Record<string, unknown> | null;
  requestInstance?: Record<string, unknown> | null;
}

export interface SaveSurveyResponse {
  code?: {
    message?: string;
  } | null;
  errorMessage?: string | null;
  data?: SavedSurveyDetails | null;
}

export interface PanelistSummaryState {
  selections?: DimensionSelection[];
  dataPrompts?: Prompt[];
  requestInstance?: RequestInstance;
  reportSpec?: ReportSpecObject;
}

export interface ReportSelection {
  id?: string;
  children?: ReportSelection[];
  attributes?: Array<{ name?: string; value?: string }>;
}

export enum ChannelName {
  WebLink = 'WEB_LINK',
  Email = 'EMAIL',
  InApp = 'IN_APP',
  Sms = 'SMS',
}
export type CreateSaveDraftPayloadParams = {
  title: string;
  questions: QuestionModel[];
  userPrompt: string;
  surveyId: string;
  status?: SurveyStatus;
  dynamics?: SaveDraftDynamics;
  rights?: object[];
  assetId?: string | null;
};

export const MAXIMUM_OPTIONS_ALLOWED = 15;

export const SURVEY_VALIDATION_STATE = {
  READY_FOR_VALIDATION: 'readyForValidation', // Generated survey is ready for AI validation
  VALIDATION_IN_PROGRESS: 'validationInProgress', // User has initiated AI validation
  VALIDATION_IN_REVIEW: 'validationInReview', // AI validation is complete and suggestions require user review
  READY_FOR_PUBLISH: 'readyForPublish', // All mandatory suggestions have been addressed and the survey is ready to publish
};

export type SurveyAIValidationState =
  (typeof SURVEY_VALIDATION_STATE)[keyof typeof SURVEY_VALIDATION_STATE];

export type QuestionValidationStatus = 'APPROVED' | 'NEEDS_MANDATORY_CHANGES';

export const SUGGESTION_SEVERITY = {
  MANDATORY: 'MANDATORY',
  OPTIONAL: 'OPTIONAL',
} as const;

export type SuggestionSeverity =
  (typeof SUGGESTION_SEVERITY)[keyof typeof SUGGESTION_SEVERITY];

export type SuggestionSource = 'AI';

export enum SuggestionActionType {
  REPHRASE = 'REPHRASE',
  REMOVE = 'REMOVE',
  ADD_OPTION = 'ADD_OPTION',
  REVIEW = 'REVIEW',
  DISMISS = 'DISMISS',
  FIX_ALL = 'FIX_ALL'
}

export type SuggestionAction = 'REPHRASE' | 'REMOVE' | 'ADD_OPTION' | 'REVIEW';

export const SURVEY_SUGGESTIONS_STATE = {
  NO_SUGGESTION: 'NO_SUGGESTION',
  ALL_APPLIED: 'ALL_APPLIED',
  IN_REVIEW: 'IN_REVIEW',
};

export type SurveySuggestionState = (typeof SURVEY_SUGGESTIONS_STATE)[keyof typeof SURVEY_SUGGESTIONS_STATE];

export interface SurveyAIValidationResponse {
  result: QuestionModel[];
}

export interface AiSuggestion {
  suggestionId: string;
  severity: SuggestionSeverity;
  ruleCode: string;
  issue: string;
  rationale: string;
  suggestedText: string;
  fieldPath: string;
  source: SuggestionSource;
  action: SuggestionAction;
}

export type SuggestionTag = {
  mandatoryCount: number;
  optionalCount: number;
};

export const OPTIQ_FEEDBACK_ACTIONS = {
  title: 'Optiq Feedback',
  fixAll: 'Fix all',
  add: 'Add',
  rephrase: 'Rephrase',
  dismiss: 'Dismiss',
  remove: 'Remove',
  addOption: 'Add option',
  rephraseOption: 'Rephrase option',
  rephraseQuestion: 'Rephrase question',
  rephraseLabel: 'Rephrase label',
  removeOption: 'Remove option',
  removeQuestion: 'Remove question',
  removeLabel: 'Remove label',
  reviewSuggestion: 'Review suggestion',
  required: 'Required',
  optional: 'Optional',
  suggestedOption: 'Suggested option',
  original: 'Original',
  suggested: 'Suggested',
  applyingAll: 'Applying all suggestions',
  disclaimer: 'Suggestions for questions and options are generated by AI and can be wrong.',
  learnMore: 'Learn more',
  changesApplied: 'Changes Applied',
  noSuggestions: 'No Suggestions',
  validationComplete: 'Validation is complete',
} as const;

export type SuggestionConfig = {
  title: string;
  buttonLabel: string | null;
  showDismiss: boolean;
  showComparison: boolean;
  iconName: string;
  isMandatory: boolean;

};
