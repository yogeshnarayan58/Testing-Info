import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../../../shared/services/api.service';
import { createEnvironmentInjector, Injector, runInInjectionContext } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { finalize, of, Subject, throwError } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { RunReportService } from './run-report.service';

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

let mockTranslateService: any;

describe('RunReportService', () => {
  let service: RunReportService;
  let httpClientMock: any;
  let cpfServiceMock: any;
  let requestTrackingServiceMock: any;
  let toastServiceMock: any;
  let environmentConfigMock: any;
  let selectPanelistUtilsServiceMock: any;

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    vi.useFakeTimers();

    httpClientMock = {
      post: vi.fn(() => of({})),
      get: vi.fn(() => of({})),
    };

    cpfServiceMock = {
      getJobStatuses: vi.fn(() => of({})),
    };

    requestTrackingServiceMock = {
      getTransactionId: vi.fn(() => 'transaction-123'),
    };

    toastServiceMock = {
      InsertToast: vi.fn(),
    };

    environmentConfigMock = {
      apiUrls: {
        cpf: 'http://cpf-api',
        jobManagerAsync: '/job-manager-async',
        reportingServices: '/api/reports',
        apiAsync: '/discover-ui-gateway/svc/discover/job-manager-async/api',
      },
      shareDialogUrl: {
        feServiceUrl: '/fe-services',
      },
    };

    selectPanelistUtilsServiceMock = {
      getNextDelay: vi.fn((defaultDelay: number) => {
        // Generate random delay between defaultDelay and defaultDelay * 2
        const array = new Uint32Array(1);
        window.crypto.getRandomValues(array);
        const randomNumber = array[0] / (0xffffffff + 1);
        return randomNumber * defaultDelay + defaultDelay;
      }),
      updateDimensionSelections: vi.fn((payload: any) => {
        const fctDimension = payload?.requestInstance?.dimensionSelections?.find((dim: any) => dim.id === 'FCT');
        if (!fctDimension) {
          payload.requestInstance.dimensionSelections.push({
            id: 'FCT',
            virtualDim: false,
            children: []
          });
        }
      }),
    };

    const injector = createEnvironmentInjector(
      [
        { provide: EnvironmentConfig, useValue: environmentConfigMock },
        { provide: TranslateService, useValue: mockTranslateService },
      ],
      Injector.NULL as any
    );
    service = runInInjectionContext(injector, () => new RunReportService(
      new ApiService(httpClientMock),
      cpfServiceMock,
      requestTrackingServiceMock,
      toastServiceMock,
      selectPanelistUtilsServiceMock,
      { setDataselectorLoading: vi.fn() } as any,
      mockTranslateService
    ));
  });

  afterEach(() => {
    vi.clearAllMocks();
    vi.useRealTimers();
  });

  describe('runReport', () => {
    it('should initialize false, set true on call, and prepare payload', () => {
      expect(service.asyncInProgress).toBe(false);
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'job-123' } }));
      service.runReport();
      expect(service.asyncInProgress).toBe(true);
      expect(service.reportPayload.requestInstance.dimensionSelections).toBeDefined();
    });

    it('should prepare payload and call requestAsync', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'job-456' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));
      service.runReport();
      expect(service.reportPayload.requestInstance.dimensionSelections).toBeDefined();
      expect(httpClientMock.post).toHaveBeenCalled();
    });

    it('should extract jobId from response and call startPolling', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'job-789' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));
      
      service.runReport();
      
      expect(service.executionJobIds).toContain('job-789');
      expect(cpfServiceMock.getJobStatuses).toHaveBeenCalled();
    });

    it('should handle error in runReport catchError block (lines 41-42)', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      const error = new HttpErrorResponse({ error: { errorMessage: 'Request failed' } });
      httpClientMock.post.mockReturnValue(throwError(() => error));
      
      service.runReport();
      
      // When error occurs, stopPolling is called which sets asyncInProgress to false
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_ERROR', expect.any(Object));
      expect(service.asyncInProgress).toBe(false);
    });

    it('should preserve any existing jobId when running a report', () => {
      service.reportPayload = { jobId: 'existing-job-id', requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'job-abc' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));

      service.runReport();

      expect(service.reportPayload.jobId).toBe('existing-job-id');
      expect(service.executionJobIds).toContain('job-abc');
    });

    it('runs a fresh publish count job and skips package loading', () => {
      const uniqueCount = { id: 'THL_UNIQUE_HOUSEHOLD_COUNT_O', attributes: [{ name: 'isHidden', value: 'true' }] };
      const householdId = { id: 'THL_HOUSEHOLD_ID', attributes: [{ name: 'isHidden', value: 'false' }] };
      service.reportPayload = {
        jobId: 'old-request-id',
        requestInstance: {
          dimensionSelections: [{
            id: 'FCT',
            children: [{ id: 'CHR', children: [{ id: 'FCT_COL_NM', children: [uniqueCount, householdId] }] }],
          }],
        },
      };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'panelist-job-1' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({ 'panelist-job-1': { data: 'COMPLETED' } }));
      const loadSpy = vi.spyOn(service, 'loadReportDataPackage');
      let completedJobId: string | undefined;

      service.runReport(true).subscribe(jobId => completedJobId = jobId);

      expect(service.reportPayload.jobId).not.toBe('old-request-id');
      expect(completedJobId).toBe('panelist-job-1');
      expect(uniqueCount.attributes[0].value).toBe('true');
      expect(householdId.attributes[0].value).toBe('false');
      expect(loadSpy).not.toHaveBeenCalled();
    });

    it('safely handles a publish report without the expected fact hierarchy', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [{ id: 'OTHER' }] } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'panelist-job-1' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({ 'panelist-job-1': { data: 'COMPLETED' } }));

      expect(() => service.runReport(true).subscribe()).not.toThrow();
    });
  });

  describe('startPolling', () => {
    it('should call getJobStatuses and handle responses', () => {
      service.executionJobIds = ['job-1', 'job-2'];
      cpfServiceMock.getJobStatuses.mockReturnValue(
        of({ 'job-1': { data: 'COMPLETED' }, 'job-2': { data: 'IN_PROGRESS' } })
      );
      httpClientMock.post.mockReturnValue(of({ data: 'package' }));
      
      service.startPolling();
      
      expect(cpfServiceMock.getJobStatuses).toHaveBeenCalledWith(['job-1', 'job-2'], 'transaction-123');
      expect(httpClientMock.post).toHaveBeenCalled();
    });

    it('should show error toast on ERROR status and filter jobs', () => {
      service.executionJobIds = ['job-1', 'job-2'];
      service.asyncInProgress = true;
      cpfServiceMock.getJobStatuses.mockReturnValue(
        of({ 'job-1': { data: 'ERROR', errorMessage: 'Failed' }, 'job-2': { data: 'IN_PROGRESS' } })
      );
      
      service.startPolling();
      
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'Failed', expect.any(Object));
    });

    it('should handle polling errors with toast and stop', () => {
      service.executionJobIds = ['job-1'];
      const error = new HttpErrorResponse({ error: { errorMessage: 'Poll failed' } });
      cpfServiceMock.getJobStatuses.mockReturnValue(throwError(() => error));
      
      service.startPolling();
      
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'Poll failed', expect.any(Object));
    });

    it('should handle complete in polling and reschedule if asyncInProgress (lines 64-67)', () => {
      service.executionJobIds = ['job-1'];
      service.asyncInProgress = true;
      cpfServiceMock.getJobStatuses.mockReturnValue(of({ 'job-1': { data: 'IN_PROGRESS' } }));
      
      service.startPolling(500);
      
      expect(service.asyncInProgress).toBe(true);
    });

    it('should handle polling error handler subscribe block (error subscribe)', () => {
      service.executionJobIds = ['job-1'];
      service.asyncInProgress = true;
      const error = new HttpErrorResponse({ error: { errorMessage: 'Poll error' } });
      cpfServiceMock.getJobStatuses.mockReturnValue(throwError(() => error));
      
      service.startPolling();
      
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'Poll error', expect.any(Object));
      expect(service.asyncInProgress).toBe(false);
    });
  });

  describe('requestAsync & getJobStatuses', () => {
    it('should post payload and handle responses', () => {
      const payload = { requestInstance: { test: 'data' } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'job-123' } }));
      return new Promise((resolve, reject) => {
        service.requestAsync(payload).subscribe({ next: (result: any) => { expect(result.data.jobId).toBe('job-123'); resolve(undefined); }, error: reject });
      });
    });

    it('should handle errors from both services', () => {
      const error = new Error('Service error');
      httpClientMock.post.mockReturnValue(throwError(() => error));
      return new Promise((resolve, reject) => {
        service.requestAsync({}).subscribe({ next: () => reject(new Error('Should fail')), error: () => resolve(undefined) });
      });
    });
  });

  describe('loadPackage', () => {
    it('should load report data package and emit results on success', () => {
      httpClientMock.post.mockReturnValue(of({ data: 'package-data' }));
      
      let reportingResult: any;
      service.reportingResponse.subscribe((result) => {
        reportingResult = result;
      });
      
      service['loadPackage']('job-123');
      
      expect(reportingResult).toEqual({ data: 'package-data' });
    });

    it('should emit reportingResponse on loadPackage success subscribe', () => {
      httpClientMock.post.mockReturnValue(of({ data: 'success-package' }));
      
      const reportingSpy = vi.spyOn(service.reportingResponse, 'next');
      
      service['loadPackage']('job-456');
      
      expect(reportingSpy).toHaveBeenCalledWith({ data: 'success-package' });
    });
  });

  describe('stopPolling variations', () => {
    it('should set asyncInProgress to false on stopPolling', () => {
      service.asyncInProgress = true;
      service.stopPolling();
      expect(service.asyncInProgress).toBe(false);
    });

    it('should show error toast when status is ERROR', () => {
      service.stopPolling('ERROR');
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_ERROR', expect.any(Object));
    });

    it('should show error toast when status is CANCEL', () => {
      service.stopPolling('CANCEL');
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_ERROR', expect.any(Object));
    });

    it('should not show toast when status is not ERROR or CANCEL', () => {
      const callCount = toastServiceMock.InsertToast.mock.calls.length;
      service.stopPolling('OTHER');
      expect(toastServiceMock.InsertToast.mock.calls.length).toBe(callCount);
    });

    it('should emit stoprun next on stopPolling', () => {
      const stopSpy = vi.spyOn(service.stoprun, 'next');
      service.stopPolling();
      expect(stopSpy).toHaveBeenCalled();
    });
  });

  describe('null/undefined response handling', () => {
    it('should handle null response from requestAsync', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of(null));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));
      
      service.runReport();
      
      // Should not crash, executionJobIds might be empty or contain undefined
      expect(service.executionJobIds).toBeDefined();
    });

    it('should handle undefined data in response', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of({ data: undefined }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));
      
      service.runReport();
      
      expect(service.executionJobIds).toBeDefined();
    });
  });

  describe('startPolling complete handler with asyncInProgress', () => {
    it('should reschedule polling when asyncInProgress is true in complete', () => {
      service.executionJobIds = ['job-1'];
      service.asyncInProgress = true;
      const delay = 100;
      
      cpfServiceMock.getJobStatuses.mockReturnValue(of({ 'job-1': { data: 'IN_PROGRESS' } }));
      
      service.startPolling(delay);
      vi.advanceTimersByTime(delay + 10);
      
      // Polling started successfully without errors
      expect(service.executionJobIds.length).toBeGreaterThan(0);
    });

    it('should not reschedule when asyncInProgress is false', () => {
      service.executionJobIds = ['job-1'];
      service.asyncInProgress = false;
      
      cpfServiceMock.getJobStatuses.mockReturnValue(of({ 'job-1': { data: 'IN_PROGRESS' } }));
      
      service.startPolling();
      vi.advanceTimersByTime(50);
      
      // When asyncInProgress is false, polling starts but won't reschedule
      expect(service.asyncInProgress).toBe(false);
    });
  });

  describe('status filtering branches', () => {
    it('should filter jobs when status is not IN_PROGRESS', () => {
      service.executionJobIds = ['job-1', 'job-2'];
      cpfServiceMock.getJobStatuses.mockReturnValue(
        of({ 'job-1': { data: 'COMPLETED' }, 'job-2': { data: 'IN_PROGRESS' } })
      );
      httpClientMock.post.mockReturnValue(of({ data: 'package' }));
      
      service.startPolling();
      
      expect(service.executionJobIds).toContain('job-2');
    });

    it('should call loadPackage when status is COMPLETED', () => {
      service.executionJobIds = ['job-1'];
      const loadPackageSpy = vi.spyOn(service as any, 'loadPackage');
      cpfServiceMock.getJobStatuses.mockReturnValue(
        of({ 'job-1': { data: 'COMPLETED' } })
      );
      httpClientMock.post.mockReturnValue(of({ data: 'package' }));
      
      service.startPolling();
      
      expect(loadPackageSpy).toHaveBeenCalledWith('job-1');
    });

    it('should show toast for ERROR status but not filter if jobs remain', () => {
      service.executionJobIds = ['job-1', 'job-2'];
      service.asyncInProgress = true;
      cpfServiceMock.getJobStatuses.mockReturnValue(
        of({ 'job-1': { data: 'ERROR', errorMessage: 'Job failed' }, 'job-2': { data: 'IN_PROGRESS' } })
      );
      
      service.startPolling();
      
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'Job failed', expect.any(Object));
      expect(service.executionJobIds).toContain('job-2');
    });

    it('should call stopPolling when status is unknown and last job (line 67)', () => {
      service.executionJobIds = ['job-1'];
      const stopSpy = vi.spyOn(service, 'stopPolling');
      cpfServiceMock.getJobStatuses.mockReturnValue(
        of({ 'job-1': { data: 'PENDING' } })
      );
      
      service.startPolling();
      
      expect(stopSpy).toHaveBeenCalled();
    });
  });

  describe('reset', () => {
    it('clears the previous survey report payload, jobs, and completed result', () => {
      service.reportPayload = { jobId: 'survey-a-job', requestInstance: { dimensionSelections: [] } };
      service.lastJobId = 'survey-a-job';
      service.executionJobIds = ['survey-a-job'];
      service.asyncInProgress = true;
      service.reportCompleted$.next({ surveyId: 'survey-a' });
      const stopped = vi.spyOn(service.stoprun, 'next');

      service.reset();

      expect(stopped).toHaveBeenCalledOnce();
      expect(service.reportPayload).toEqual({});
      expect(service.lastJobId).toBeNull();
      expect(service.executionJobIds).toEqual([]);
      expect(service.asyncInProgress).toBe(false);
      expect(service.reportCompleted$.value).toBeNull();
      expect(toastServiceMock.InsertToast).not.toHaveBeenCalled();
    });

    it('cancels the old polling timer before another survey starts a report', () => {
      service.asyncInProgress = true;
      service.executionJobIds = ['survey-a-job'];
      service.startPolling(500);
      expect(vi.getTimerCount()).toBe(1);

      service.reset();
      service.asyncInProgress = true;
      service.executionJobIds = ['survey-b-job'];
      vi.advanceTimersByTime(1000);

      expect(vi.getTimerCount()).toBe(0);
      expect(cpfServiceMock.getJobStatuses).toHaveBeenCalledTimes(1);
    });

    it('cancels an outstanding execution request so it cannot restore the old job', () => {
      const response = new Subject<unknown>();
      const cancelled = vi.fn();
      httpClientMock.post.mockReturnValue(response.pipe(finalize(cancelled)));
      service.reportPayload = { jobId: 'survey-a-job' };
      service.runReport();

      service.reset();
      response.next({ data: { jobId: 'survey-a-job' } });

      expect(cancelled).toHaveBeenCalledOnce();
      expect(service.lastJobId).toBeNull();
      expect(cpfServiceMock.getJobStatuses).not.toHaveBeenCalled();
    });

    it('cancels an outstanding report package so it cannot emit the old result', () => {
      const response = new Subject<unknown>();
      const cancelled = vi.fn();
      const received = vi.fn();
      httpClientMock.post.mockReturnValue(response.pipe(finalize(cancelled)));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({ 'survey-a-job': { data: 'COMPLETED' } }));
      service.reportingResponse.subscribe(received);
      service.executionJobIds = ['survey-a-job'];
      service.startPolling();

      service.reset();
      response.next({ surveyId: 'survey-a' });

      expect(cancelled).toHaveBeenCalledOnce();
      expect(received).not.toHaveBeenCalled();
      expect(service.reportCompleted$.value).toBeNull();
    });
  });

  describe('resetReportCompleted', () => {
    it('should reset reportCompleted$ to null', () => {
      service.reportCompleted$.next('some-value');
      service.resetReportCompleted();
      
      expect(service.reportCompleted$.value).toBeNull();
    });
  });

  describe('loadReportDataPackage variations', () => {
    it('should use reportingDetailsUrl when isGridOrKpi is true', () => {
      const jobId = 'job-123';
      httpClientMock.post.mockReturnValue(of({}));
      
      service.loadReportDataPackage(jobId, {}, true);
      
      expect(httpClientMock.post).toHaveBeenCalledWith(
        '/fe-services/getReportingDetails/job-123',
        expect.any(Object),
        expect.any(Object)
      );
    });

    it('should use reportsUrl when isGridOrKpi is false', () => {
      const jobId = 'job-456';
      httpClientMock.post.mockReturnValue(of({}));
      
      service.loadReportDataPackage(jobId, {}, false);
      
      expect(httpClientMock.post).toHaveBeenCalledWith(
        '/api/reports/job-456',
        expect.any(Object),
        expect.any(Object)
      );
    });

    it('should include X-NLSN-TNXN-ID header', () => {
      httpClientMock.post.mockReturnValue(of({}));
      
      service.loadReportDataPackage('job-789', {}, true);
      
      expect(httpClientMock.post).toHaveBeenCalledWith(
        expect.any(String),
        expect.any(Object),
        expect.objectContaining({
          headers: expect.objectContaining({
            'X-NLSN-TNXN-ID': 'transaction-123'
          })
        })
      );
    });

    it('should include slice array in request body', () => {
      httpClientMock.post.mockReturnValue(of({}));
      const payload = { test: 'data' };
      
      service.loadReportDataPackage('job-101', payload, true);
      
      expect(httpClientMock.post).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({ slice: [] }),
        expect.any(Object)
      );
    });

    it('should handle loadPackage error and stop polling', () => {
      const error = new HttpErrorResponse({ error: { errorMessage: 'Load failed' } });
      httpClientMock.post.mockReturnValue(throwError(() => error));
      
      service.asyncInProgress = true;
      service['loadPackage']('job-123');
      
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_ERROR', expect.any(Object));
      expect(service.asyncInProgress).toBe(false);
    });

    it('should call stopPolling on loadPackage error subscribe (line 91)', () => {
      const error = new HttpErrorResponse({ error: { errorMessage: 'Package failed' } });
      httpClientMock.post.mockReturnValue(throwError(() => error));
      
      const stopSpy = vi.spyOn(service, 'stopPolling');
      service.asyncInProgress = true;
      service['loadPackage']('job-err');
      
      expect(stopSpy).toHaveBeenCalledWith('ERROR');
      expect(service.asyncInProgress).toBe(false);
    });
  });

  describe('loadReportDataPackage error handling', () => {
    it('should handle error in loadReportDataPackage and call stopPolling (line 91)', () => {
      const error = new HttpErrorResponse({ error: { errorMessage: 'Load failed' } });
      httpClientMock.post.mockReturnValue(throwError(() => error));
      
      const stopSpy = vi.spyOn(service, 'stopPolling');
      service.asyncInProgress = true;
      
      service['loadPackage']('job-123');
      
      expect(stopSpy).toHaveBeenCalledWith('ERROR');
    });
  });

  describe('Service initialization and state management', () => {
    it('should initialize with empty executionJobIds array', () => {
      expect(Array.isArray(service.executionJobIds)).toBe(true);
      expect(service.executionJobIds.length).toBe(0);
    });

    it('should have reportPayload defined on instantiation', () => {
      expect(service.reportPayload).toBeDefined();
    });

    it('should have asyncInProgress set to false initially', () => {
      expect(service.asyncInProgress).toBe(false);
    });

    it('should have reportingResponse Subject available', () => {
      expect(service.reportingResponse).toBeDefined();
      expect(service.reportingResponse.next).toBeDefined();
    });

    it('should clear and push jobId to executionJobIds array on successful runReport', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      service.executionJobIds = ['old-job'];
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'new-job' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));
      
      service.runReport();
      
      expect(service.executionJobIds).not.toContain('old-job');
      expect(service.executionJobIds).toContain('new-job');
    });

    it('should post to async endpoint via requestAsync', () => {
      service.reportPayload = { requestInstance: { dimensionSelections: [] } };
      httpClientMock.post.mockReturnValue(of({ data: { jobId: 'job-1' } }));
      cpfServiceMock.getJobStatuses.mockReturnValue(of({}));
      
      service.runReport();
      
      expect(httpClientMock.post).toHaveBeenCalledWith(
        '/discover-ui-gateway/svc/discover/job-manager-async/api/job/execute/async',
        service.reportPayload
      );
    });

    it('should trigger setTimeout in complete handler when asyncInProgress is true', () => {
      service.asyncInProgress = true;
      service.executionJobIds = ['job-1'];
      
      const mockJobStatuses = of({});
      cpfServiceMock.getJobStatuses.mockReturnValue(mockJobStatuses);
      
      const startPollingSpy = vi.spyOn(service, 'startPolling');
      
      service.startPolling(500);
      vi.advanceTimersByTime(600);
      
      expect(startPollingSpy.mock.calls.length).toBeGreaterThanOrEqual(1);
    });
  });

  describe('loadReportDataPackage', () => {
    it('should load report data package with headers', () => {
      httpClientMock.post.mockReturnValue(of({ data: 'report' }));
      return new Promise((resolve, reject) => {
        service.loadReportDataPackage('job-123').subscribe({
          next: () => {
            const call = httpClientMock.post.mock.calls[0];
            expect(call[0]).toContain('job-123');
            expect(call[2]?.headers['X-NLSN-TNXN-ID']).toBe('transaction-123');
            resolve(undefined);
          },
          error: reject,
        });
      });
    });
  });

  describe('triggerValuesMultiChar & utility methods', () => {
    it('should post to multiChar endpoint and update context', () => {
      const payload = { requestContext: {} };
      const datasetDetails = { id: 'ds-123', dataView: { dataViewId: 'dv-456' }, stackId: 'stack-001' };
      httpClientMock.post.mockReturnValue(of({ values: ['val1', 'val2'] }));

      return new Promise((resolve, reject) => {
        service.triggerValuesMultiChar(payload, datasetDetails).subscribe({
          next: () => {
            expect((payload.requestContext as any).datasetId).toBe('ds-123');
            expect((payload.requestContext as any).dataViewId).toBe('dv-456');
            expect((payload.requestContext as any).datasetStackId).toBe('stack-001');
            resolve(undefined);
          },
          error: reject,
        });
      });
    });

    it('should handle multiChar error gracefully', () => {
      const error = new Error('API error');
      httpClientMock.post.mockReturnValue(throwError(() => error));
      const payload = { requestContext: {} };
      const datasetDetails = { id: 'ds-123', dataView: { dataViewId: 'dv-456' }, stackId: 'stack-001' };
      return new Promise((resolve) => {
        service.triggerValuesMultiChar(payload, datasetDetails).subscribe({
          next: (result: any) => { expect(result).toEqual(error); resolve(undefined); },
          error: () => resolve(undefined),
        });
      });
    });

    it('should stop polling and manage state correctly', () => {
      service.asyncInProgress = true;
      service.stopPolling();
      expect(service.asyncInProgress).toBe(false);
      
      service.stopPolling('ERROR');
      expect(toastServiceMock.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_ERROR', expect.any(Object));
    });

    it('should reset report completed state', () => {
      service.reportCompleted$.next({ data: 'test' });
      service.resetReportCompleted();
      expect(service.reportCompleted$.getValue()).toBeNull();
    });
  });

  describe('Service Initialization', () => {
    it('should create service with all required methods and properties', () => {
      expect(service).toBeTruthy();
      expect(service.asyncInProgress).toBe(false);
      expect(service.executionJobIds).toEqual([]);
      expect(service.DEFAULT_DELAY_PERIOD).toBe(1200);
      
      expect(typeof service.runReport).toBe('function');
      expect(typeof service.startPolling).toBe('function');
      expect(typeof service.stopPolling).toBe('function');
      expect(typeof service.loadReportDataPackage).toBe('function');
      expect(typeof service.requestAsync).toBe('function');
      expect(typeof service.triggerValuesMultiChar).toBe('function');
      expect(typeof service.resetReportCompleted).toBe('function');
      
      expect(service.reportingResponse).toBeDefined();
      expect(service.reportCompleted$).toBeDefined();
      expect(typeof service.reportPayload).toBe('object');
    });
  });
});
