import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse } from '@angular/common/http';
import { Observable, ReplaySubject } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class MyConfigsInterceptor implements HttpInterceptor {
  private readonly _myConfigs$ = new ReplaySubject<any>(1);
  readonly myConfigs$ = this._myConfigs$.asObservable();

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.method === 'GET' && request.url.includes('/myConfigs')) {
      return next.handle(request).pipe(
        tap((event) => {
          if (event instanceof HttpResponse && event.body) {
            this._myConfigs$.next(event.body);
          }
        })
      );
    }
    return next.handle(request);
  }
}
