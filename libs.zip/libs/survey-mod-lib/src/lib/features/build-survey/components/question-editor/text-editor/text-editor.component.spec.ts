import { ElementRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { TextEditorComponent } from './text-editor.component';

describe('TextEditorComponent', () => {
  const createComponent = () => TestBed.runInInjectionContext(() =>
    new TextEditorComponent(new ElementRef(document.createElement('div'))),
  );

  it('updates the question from text input', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onInputChange('What do you think?');

    expect(component.question()).toBe('What do you think?');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('converts numeric input to text', () => {
    const component = createComponent();

    component.onInputChange(42);

    expect(component.question()).toBe('42');
  });

  it('clears the question for null input', () => {
    const component = createComponent();
    component.question.set('Existing question');

    component.onInputChange(null as unknown as string);

    expect(component.question()).toBe('');
  });

  it('updates required state from the toggle', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');
    const event = { target: { checked: true } } as unknown as Event;

    component.toggleChange(event);

    expect(component.isRequired()).toBe(true);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('defaults required state to false when toggle data is missing', () => {
    const component = createComponent();
    component.isRequired.set(true);

    component.toggleChange({ target: {} } as unknown as Event);

    expect(component.isRequired()).toBe(false);
  });
});
