import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { findDataSetByName, hasPivotInDimensionSelections, getPivotDataIndexByName } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { NAVIGATION_TIMEOUT, RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let pivotIndex: number;
let savedReportUrl: string = "";
const pivot: string = "Geography";

test.describe("Buyer Demographics - Geography Pivot", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    pivotIndex = getPivotDataIndexByName(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });
  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Validate run report",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.switchPivotDropdown(pivot);

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            reportTestData.dimensionSelections[pivotIndex]["Geography"]
          );
          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.selectClosedDropdown(
            reportTestData.dimensionSelections[pivotIndex]["Facts"]["selections"]
          );
          await dataSelector.clickMadlibDimension("Product");
          await dataSelector.setMadlibSelection(
            reportTestData.dimensionSelections[pivotIndex]["Product"]
          );
          await dataSelector.clickMadlibDimension("Retailer");
          await dataSelector.setMadlibSelection(
            reportTestData.dimensionSelections[pivotIndex]["Retailer"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            reportTestData.dimensionSelections[pivotIndex]["Period"]
          );

          /* await dataSelector.clickMadlibDimension("Comparison Period");
          await dataSelector.setPeriodMadlibSelection(
            reportTestData.dimensionSelections[pivotIndex]["Comparison Period"]
          ); */

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );
      test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
        test.skip(
          !savedReportTitle,
          "Skipping FMS test - Report not generated. Run with @RunReport first"
        );

        const basePage = await BasePageFactory.createBasePage();
        const findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
    }
  );
});

