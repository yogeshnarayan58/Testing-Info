import * as path from 'path';

/**
 * Constructs the LambdaTest build name with optional build identifier suffix.
 * Used consistently across playwright.config.ts, base-page-factory.ts, and globalTeardown.ts.
 *
 * @param ltBuild - Base build name (e.g., "Discover build")
 * @param buildIdentifier - Optional identifier to append (e.g., GitHub run number)
 * @returns Formatted build name with identifier if provided
 */
export const getLambdaTestBuildName = (
  ltBuild: string,
  buildIdentifier?: string
): string => {
  return buildIdentifier ? `${ltBuild} (${buildIdentifier})` : ltBuild;
};

export const getLambdaTestSessionDir = (): string =>
  path.join(process.cwd(), 'test-results', '.lt-sessions');

export const config = {
  get ENV(): string {
    return process.env.ENV || 'DEV';
  },
  get postgresAPIUrl(): string {
    return process.env.SM_POSTGRES_API_URL || 'https://postgres-api.qa.in.gfk.com/report-postgres/api/v1';
  },
};
