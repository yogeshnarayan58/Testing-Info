import * as fs from 'fs';
import * as path from 'path';
import { getLambdaTestBuildName, getLambdaTestSessionDir } from '../../utils/configurationDetails';
import { safeJoin, assertContainedDir } from '../../utils/safe-path';
import { MAX_TEST_TIMEOUT } from '../../constants/timeout-constants';

// #cycode_sast_ignore_here Static path: process.cwd() joined with hardcoded literal 'allure-results', no user input
const ALLURE_RESULTS_DIR = path.join(process.cwd(), 'allure-results');
// #cycode_sast_ignore_here Static path: literal filename joined onto a hardcoded directory, no dynamic input
const ENV_PROPS_PATH = path.join(ALLURE_RESULTS_DIR, 'environment.properties');

const sanitizeId = (value: unknown): string => String(value).replace(/[^a-zA-Z0-9_-]/g, '');

// Strict allowlist patterns for filenames from readdirSync(), replacing denylist-style startsWith()/endsWith() checks.
const MAPPING_FILENAME_RE = /^test-[a-zA-Z0-9_-]+-\d+-\d+\.json$/;
const ALLURE_RESULT_FILENAME_RE = /^[a-zA-Z0-9_-]+-result\.json$/;

/**
 * globalTeardown.ts: Runs after all tests complete.
 *
 * When LAMBDATEST=true, this:
 *  - Reads the test-results/.lt-sessions/ test->session mapping files written by
 *    lt-session-reporter.ts / base-page-factory.ts,
 *  - Injects an LT_SESSION parameter into the matching Allure result files,
 *  - Calls the LambdaTest Automation API to fetch session info (video link,
 *    session id) and patch each session's pass/fail status,
 *  - Writes allure-results/environment.properties with the LambdaTest build URL.
 *
 * When LAMBDATEST is not 'true', this is a complete no-op so local/default
 * test runs are entirely unaffected.
 */
export default async () => {
  const isLambdaTest = process.env.LAMBDATEST === 'true';

  if (!isLambdaTest) {
    return;
  }

  try {
    console.log('[global-teardown] Adding LambdaTest videos to Allure report...');

    const ltUser = process.env.SM_LAMBDATEST_USERNAME || process.env.SM_LT_USERNAME;
    const ltAccessKey = process.env.SM_LAMBDATEST_ACCESS_KEY || process.env.SM_LT_ACCESS_KEY;
    const ltBuild = process.env.SM_LT_BUILD || 'Discover build';
    const buildIdentifier =
      process.env.SM_LT_BUILD_IDENTIFIER ||
      process.env.BUILD_NUMBER ||
      process.env.GITHUB_RUN_NUMBER ||
      undefined;

    const actualBuildName = getLambdaTestBuildName(ltBuild, buildIdentifier);

    // #cycode_sast_ignore_here Static path: ALLURE_RESULTS_DIR is built from process.cwd() + a hardcoded literal, no user input
    fs.mkdirSync(ALLURE_RESULTS_DIR, { recursive: true });

    console.log('[global-teardown] Step 1: Reading test-session mappings...');
    // #cycode_sast_ignore_here Static path: process.cwd() joined with hardcoded literal 'test-results', no user input
    const safeSessionDir = assertContainedDir(
      path.resolve(process.cwd(), 'test-results'),
      getLambdaTestSessionDir()
    );

    const testSessionMap = new Map<string, string>(); // fullName -> sessionName
    const testIdMap = new Map<string, string>(); // testId -> sessionName

    // Read individual mapping files (one per test) to avoid concurrent write conflicts
    if (fs.existsSync(safeSessionDir)) {
      const mappingFiles = fs
        .readdirSync(safeSessionDir)
        // Strict full-pattern allowlist instead of startsWith()/endsWith(), which only checks the ends of the string.
        .filter((f) => MAPPING_FILENAME_RE.test(f));

      console.log(`[global-teardown] Found ${mappingFiles.length} test-session mapping file(s)`);

      for (const file of mappingFiles) {
        // path.basename() here is only for safe log display below; safeJoin() is the actual traversal guard.
        const sanitizedFile = path.basename(file);
        try {
          // filePath resolved via safeJoin() on the raw, already allowlist-filtered filename
          const filePath = safeJoin(safeSessionDir, file);
          // #cycode_sast_ignore_here Path validated via safeJoin() - resolves and verifies containment within base directory before use
          const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

          if (data.sessionName) {
            if (data.fullName) {
              testSessionMap.set(data.fullName.trim(), data.sessionName);
            }
            if (data.testId) {
              testIdMap.set(data.testId, data.sessionName);
            }
          }
        } catch (e) {
          console.warn(`[global-teardown] Failed to parse mapping file ${sanitizedFile}:`, e);
        }
      }
    } else {
      console.warn(`[global-teardown] No LambdaTest session directory found at ${safeSessionDir}`);
    }

    // Step 2: Read Allure result files
    console.log('[global-teardown] Step 2: Reading Allure result files...');
    const allureFiles = fs.existsSync(ALLURE_RESULTS_DIR)
      ? fs
          .readdirSync(ALLURE_RESULTS_DIR)
          // Strict full-pattern allowlist instead of endsWith() alone.
          .filter((f) => ALLURE_RESULT_FILENAME_RE.test(f))
      : [];

    console.log(`[global-teardown] Found ${allureFiles.length} Allure result files`);

    const testResults = allureFiles.map((file) => {
      // filePath resolved via safeJoin() - no filename stripping needed
      const filePath = safeJoin(ALLURE_RESULTS_DIR, file);
      // #cycode_sast_ignore_here Path validated via safeJoin() - resolves and verifies containment within base directory before use
      const result = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      return { filePath, result };
    });

    // Step 3: Inject LT_SESSION into Allure result files
    console.log('[global-teardown] Step 3: Injecting LT_SESSION into Allure files...');
    for (const testResult of testResults) {
      const result = testResult.result;

      const testName = result.name?.trim();
      if (!testName) continue;

      const testId = result.testCaseId;

      const labels = result.labels || [];
      const parentSuite = labels.find((l: any) => l.name === 'parentSuite')?.value;
      const suite = labels.find((l: any) => l.name === 'suite')?.value;
      const subSuite = labels.find((l: any) => l.name === 'subSuite')?.value;

      const fullName = [parentSuite, suite, subSuite, testName].filter(Boolean).join(' › ').trim();

      // Normalize > separator to › for consistent mapping with reporter
      const normalizedFullName = fullName.replace(/\s*>\s*/g, ' › ');

      let sessionName = testSessionMap.get(normalizedFullName);

      if (!sessionName && testId) {
        sessionName = testIdMap.get(testId);
      }

      if (sessionName) {
        result.parameters = result.parameters || [];
        const hasLTSession = result.parameters.some((p: any) => p.name === 'LT_SESSION');

        if (!hasLTSession) {
          result.parameters.push({ name: 'LT_SESSION', value: sessionName });
          // Re-derived via safeJoin() immediately before this sink rather than reusing the stored path across closures
          const safeStep3WritePath = safeJoin(ALLURE_RESULTS_DIR, path.basename(testResult.filePath));
          if (!safeStep3WritePath.endsWith('.json')) {
            throw new Error(`Refusing to write non-.json Allure result file: ${safeStep3WritePath}`);
          }
          // #cycode_sast_ignore_here Path validated via safeJoin() with .json extension re-checked immediately above
          fs.writeFileSync(safeStep3WritePath, JSON.stringify(result, null, 2));
          console.log(`[global-teardown]  Added LT_SESSION for "${fullName}": ${sessionName}`);
        }
      } else {
        console.warn(`[global-teardown]  No session mapping found for: "${fullName}"`);
      }
    }

    // Step 4: Fetch LambdaTest sessions from API
    console.log('[global-teardown] Step 4: Fetching LambdaTest sessions...');
    if (!ltUser || !ltAccessKey) {
      console.warn('[global-teardown] Missing LambdaTest credentials. Skipping API calls.');
      return;
    }

    const auth = Buffer.from(`${ltUser}:${ltAccessKey}`).toString('base64');

    const response = await fetch(
      `https://api.lambdatest.com/automation/api/v1/sessions?build=${encodeURIComponent(actualBuildName)}&limit=100`,
      {
        headers: { Authorization: `Basic ${auth}` },
        signal: AbortSignal.timeout(MAX_TEST_TIMEOUT),
      }
    );

    if (!response.ok) {
      const errorBody = await response.text().catch(() => '');
      throw new Error(
        `[global-teardown] LambdaTest API failed: ${response.status} ${response.statusText}` +
          (errorBody ? ` Body: ${errorBody}` : '')
      );
    }

    const data = await response.json();
    const sessions = data?.data || [];

    console.log(`[global-teardown] Found ${sessions.length} LambdaTest sessions`);

    // Extract build ID from the first session that exposes it
    let buildId: string | undefined;
    for (const session of sessions) {
      const sessionBuildId = session.build_id || session.buildId || session.build_number;
      if (sessionBuildId) {
        // Sanitize once at the source: buildId flows into a log line, a URL, and a static
        // properties file below, so sanitizing here covers all of those sinks.
        buildId = sanitizeId(sessionBuildId);
        console.log(`[global-teardown] Extracted Build ID: ${buildId}`);
        break;
      }
    }

    // Step 5: Add LambdaTest video links to Allure
    console.log('[global-teardown] Step 5: Adding video links to Allure files...');

    for (const testResult of testResults) {
      const result = testResult.result;
      const testName = result.name?.trim();

      if (!testName) continue;

      const ltSessionParam = result.parameters?.find((p: any) => p.name === 'LT_SESSION');
      const sessionName = ltSessionParam?.value;

      if (!sessionName) {
        console.warn(`[global-teardown] No LT_SESSION parameter for test: ${testName}`);
        continue;
      }

      console.log(`[global-teardown] Looking for session: ${sessionName}`);
      const session = sessions.find((s: any) => s.name === sessionName);
      if (!session) {
        // Session names come from the external LambdaTest API response; sanitize before logging.
        const safeAvailableNames = sessions
          .slice(0, 5)
          .map((s: any) => sanitizeId(s.name))
          .join(', ');
        console.warn(`[global-teardown] Session "${sessionName}" not found in LT API`);
        console.warn(`[global-teardown]    Available sessions (first 5): ${safeAvailableNames}`);
        continue;
      }
      // session_id comes from the external LambdaTest API response; sanitize once and reuse
      // for the log line, the video link URL, and the status-update URL below.
      const safeSessionId = sanitizeId(session.session_id);
      console.log(`[global-teardown] ✓ Found session in LT API: ${safeSessionId}`);

      result.links = result.links || [];
      result.links = result.links.filter((link: any) => link.name !== 'LambdaTest Video');

      result.links.push({
        name: 'LambdaTest Video',
        url: `https://automation.lambdatest.com/logs/?sessionID=${safeSessionId}`,
        type: 'link',
      });

      // Update LT status
      const testStatus = result.status === 'passed' ? 'passed' : 'failed';

      try {
        await fetch(`https://api.lambdatest.com/automation/api/v1/sessions/${safeSessionId}`, {
          method: 'PATCH',
          headers: {
            Authorization: `Basic ${auth}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ status_ind: testStatus }),
          signal: AbortSignal.timeout(MAX_TEST_TIMEOUT),
        });
      } catch (e) {
        console.warn(`[global-teardown] Failed to update status for session ${safeSessionId}`, e);
      }

      // Re-derived via safeJoin() immediately before this sink rather than reusing the stored path across closures
      const safeStep5WritePath = safeJoin(ALLURE_RESULTS_DIR, path.basename(testResult.filePath));
      if (!safeStep5WritePath.endsWith('.json')) {
        throw new Error(`Refusing to write non-.json Allure result file: ${safeStep5WritePath}`);
      }
      // #cycode_sast_ignore_here Path validated via safeJoin() with .json extension re-checked immediately above
      fs.writeFileSync(safeStep5WritePath, JSON.stringify(result, null, 2));
      console.log(`[global-teardown] ✓ Added video link for "${testName}"`);
    }

    // Step 6: environment.properties write

    if (buildId) {
      process.env.LT_BUILD_ID = buildId;
    }

    // process.env.LT_BUILD_ID is only ever set from the already-sanitized `buildId` above
    // (a few lines up: `process.env.LT_BUILD_ID = buildId;`), but sanitize again defensively
    // in case the env var was pre-populated by an external caller.
    const ltBuildId = buildId || (process.env.LT_BUILD_ID ? sanitizeId(process.env.LT_BUILD_ID) : undefined);

    let buildUrl: string;

    if (ltBuildId) {
      // Use simple format: ?build=<id> (not pageType)
      buildUrl = `https://automation.lambdatest.com/build?build=${ltBuildId}`;
    } else {
      // Fallback to build name search
      buildUrl = `https://automation.lambdatest.com/build?buildName=${encodeURIComponent(actualBuildName)}`;
    }

    let envContent =
      `LambdaTest.Build.URL=${buildUrl}\n` +
      `LambdaTest.Build.Name=${actualBuildName}\n` +
      (buildIdentifier ? `LambdaTest.Build.Identifier=${buildIdentifier}\n` : '') +
      (ltBuildId ? `LambdaTest.Build.ID=${ltBuildId}\n` : '') +
      `Execution.Mode=LambdaTest Cloud\n`;

    // #cycode_sast_ignore_here Safe: ENV_PROPS_PATH uses path.join() with hardcoded directory and filename, no user input
    fs.writeFileSync(ENV_PROPS_PATH, envContent, 'utf-8');

    console.log('[global-teardown] LambdaTest videos added to Allure report successfully.');
    console.log(`[global-teardown] Build URL: ${buildUrl}`);
  } catch (error) {
    console.warn('[global-teardown] Failed to add LambdaTest info:', error);
  }
};