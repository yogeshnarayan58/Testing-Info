import { BasePage } from '@gfk/gta';
import { SelectPanelistPage } from './select-panelist.page';

type DimensionSelectionsArg = Parameters<SelectPanelistPage['setDimensionSelections']>[0];

export async function completePanelistSelectionFlow(
  basePage: BasePage,
  dimensionSelections: DimensionSelectionsArg
): Promise<boolean> {
  const selectPanelistPage = new SelectPanelistPage(basePage);
  await selectPanelistPage.setDimensionSelections(dimensionSelections);
  await selectPanelistPage.clickSearchForPanelists();
  await selectPanelistPage.click250Responses();
  await selectPanelistPage.clickProceedToSurveyBuilder();
  return selectPanelistPage.isBuildSurveyPageLoaded();
}