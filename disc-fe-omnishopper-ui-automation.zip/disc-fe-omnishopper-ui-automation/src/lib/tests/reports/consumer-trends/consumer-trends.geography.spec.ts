import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { findDataSetByName, getDimensionSelectionsByPivot, getTestDataByLocale, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import localizationData from "./test-data/localization-data.json";
import { config } from "../../../playwright/config";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { assert } from "@gfk/gta";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Geography";

test.describe("Consumer trends - Geography Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });
  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);

      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      // Open additional prompts to ensure madlib is visible
      await dataSelector.clickAdditionalPromptEllipsisIcon();

      // Validate using pattern matching with detailed results
      if (localeData.pivotMadlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any)[
          "geography"
        ];

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(new RegExp(expectedMadlibText, "i"));

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else if (localeData.madlibText) {
        // Fallback to single madlib text if pivot-specific not available
        const actualMadlibText = await dataSelector.getMadlibText();
        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", localeData.madlibText);

        assert(actualMadlibText).toMatch(
          new RegExp(localeData.madlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );
  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
  test(
    "Validate run report",
    { tag: "@RunReport" },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);
      await dataSelector.clickAdditionalPromptEllipsisIcon();
      // Get Geography pivot data
      const geographyData = getDimensionSelectionsByPivot(pivot, reportTestData);

     
      await dataSelector.clickMadlibDimension("Trended Period");
      await dataSelector.setPeriodMadlibSelection(
        geographyData["Trended Period"]
      );
      await dataSelector.clickMadlibDimension("Products");
      await dataSelector.setMadlibSelection(
        geographyData["Products"]
      );
      console.log("Products selected");
      
      console.log("Trended Period selected");
      await dataSelector.clickMadlibDimension("Retailers");
      await dataSelector.setMadlibSelection(
        geographyData["Retailers"]
      );
       await dataSelector.clickMadlibDimension("Demographics");
      await dataSelector.setMadlibSelection(
        geographyData["Demographics"]
      );
      console.log("Demographics selected");
      await dataSelector.clickMadlibDimension("Geographies");
      await dataSelector.setMadlibSelection(
        geographyData["Geographies"]
      );
      console.log("Geographies selected");
       await dataSelector.clickMadlibDimension("Facts");
      await dataSelector.openPromptFactSelection(
        geographyData["Facts"]
      );
      // await dataSelector.clickMadlibDimension("People");
      // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
      // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
      // for (const selection of geographyData["People"].selections) {
      //   await dataSelector.handlePeopleMenuOptions(selection);
      // }
      // console.log("People selected");

      let dsBasePage = await dataSelector.getBasePage();
      commonTestCase = new CommonTestCase(dsBasePage);
      await commonTestCase.clickRunButton();
      await commonTestCase.waitForReportRunCompletion();
      console.log("Run complete in spec");
      const { newReportTitle, newUrl } =
        await commonTestCase.saveReport();
      savedReportTitle = newReportTitle;
      savedReportUrl = newUrl;
      console.log("savedReportTitle:", savedReportTitle);
      console.log("savedReportUrl:", savedReportUrl);
    }
  );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
  test(
    "Validate PPT export",
    { tag: "@ValidatePPTExport" },
    async () => {
      let exportComponent: ExportComponent;
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      let commonBasePage = await commonTestCase.getBasePage();
      exportComponent = new ExportComponent(commonBasePage);
      await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
    }
  );

  test(
    "Validate Excel export",
    { tag: "@ValidateExcelExport" },
    async () => {
      let exportComponent: ExportComponent;
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      let commonBasePage = await commonTestCase.getBasePage();
      exportComponent = new ExportComponent(commonBasePage);
      await exportComponent.validateExportFunctionality(
        "Excel",
        "Editable objects",
        "Separately"
      );
    }
  );
  });
});