import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CrfDataSummaryModule } from '@nielsen/crf-data-summary';
import { CardModule, IconModule } from '@nielseniq/athena-core';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { PanelistSummaryState } from '../../../build-survey/models/build-survey';
import { SURVEY_OVERVIEW_TEXTS } from '../../models/survey-results';
import { formatSurveyDate } from '../../../../shared/utils/survey-date.util';

@Component({
  selector: 'survey-survey-overview',
  standalone: true,
  imports: [CommonModule, CrfDataSummaryModule, TranslateModule, IconModule, CardModule],
  templateUrl: './survey-overview.component.html',
  styleUrls: ['./survey-overview.component.scss'],
})
export class SurveyOverview {
  readonly isPublishing = signal(false);
  readonly publishText = SURVEY_OVERVIEW_TEXTS;
  private readonly surveyService = inject(SurveyService);
  readonly surveyTitle = this.surveyService.title;
  private readonly surveyCommonService = inject(SurveyCommonService);

  /** Use saved selector state when API data is missing. */
  get panelistSummaryState(): PanelistSummaryState {
    return this.surveyCommonService.getPanelistDataSelectorState() ?? {};
  }

  /** Number of selected responses shown in the UI. */
  get selectedResponseCount(): number {
    return this.surveyCommonService.getSelectPanelistUiState().selectedResponses ?? 0;
  }

  /** Published date from API */
  get publishedDateValue(): string {
    const details = ((this.surveyService.loadedSurveyDetails() as unknown as Record<string, unknown> | null) ?? {});
    const delivery = (details['delivery'] as Record<string, unknown>) ?? {};
    const schedule = (delivery['schedule'] as Record<string, unknown>) ?? {};
    return formatSurveyDate(schedule['openAt']);
  }

  /** Closed date from API */
  get closedDateValue(): string {
    const details = ((this.surveyService.loadedSurveyDetails() as unknown as Record<string, unknown> | null) ?? {});
    const delivery = (details['delivery'] as Record<string, unknown>) ?? {};
    const schedule = (delivery['schedule'] as Record<string, unknown>) ?? {};
    return formatSurveyDate(schedule['closeAt']);
  }

}