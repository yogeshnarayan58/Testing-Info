import { Component } from '@angular/core';
import type { ICellRendererAngularComp } from 'ag-grid-angular';
import type { ICellRendererParams } from 'ag-grid-community';
import type { QuestionRow } from '../question.model';

interface ExpandIconRendererParams extends ICellRendererParams<QuestionRow> {
  onToggle?: (questionNumber: number) => void;
}

/**
 * Renders the expand/collapse chevron for a question row.
 * The native button supports keyboard activation while the parent grid owns
 * the expanded state.
 */
@Component({
  selector: 'survey-expand-icon-renderer',
  standalone: true,
  templateUrl: './expand-icon-renderer.component.html',
  styleUrl: './expand-icon-renderer.component.scss',
})
export class ExpandIconRendererComponent implements ICellRendererAngularComp {
  expanded = false;
  isQuestionRow = false;
  detailId = '';
  private questionNumber: number | null = null;
  private onToggleQuestion?: (questionNumber: number) => void;

  agInit(params: ExpandIconRendererParams): void {
    this.setState(params);
  }

  refresh(params: ExpandIconRendererParams): boolean {
    this.setState(params);
    return true;
  }

  onToggle(event: Event): void {
    event.stopPropagation();
    if (this.questionNumber !== null) {
      this.onToggleQuestion?.(this.questionNumber);
    }
  }

  private setState(params: ExpandIconRendererParams): void {
    this.isQuestionRow = params.data?.rowType === 'question';
    this.expanded = !!params.data?.expanded;
    this.questionNumber = params.data?.question?.questionNumber ?? null;
    this.detailId = this.questionNumber === null ? '' : `question-detail-${this.questionNumber}`;
    this.onToggleQuestion = params.onToggle;
  }
}
