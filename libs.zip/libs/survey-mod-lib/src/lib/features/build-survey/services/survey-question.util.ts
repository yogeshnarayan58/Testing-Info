import { QuestionModel, QuestionType, QuestionTypes } from '../models/build-survey';

/**
 * Validates that a question has non-empty text.
 */
export function isQuestionTextValid(text: string | undefined | null): boolean {
  return !!text?.trim();
}

/**
 * Checks if a question type is choice-based (single or multiple choice).
 */
export function isChoiceType(type: QuestionType | ''): boolean {
  return type === QuestionTypes.SingleChoice || type === QuestionTypes.MultipleChoice;
}

/**
 * Validates that choice options meet minimum count and non-empty requirements.
 */
export function isChoiceOptionsValid(options: string[] | undefined | null): boolean {
  const opts = options ?? [];
  return opts.length >= 2 && opts.every(opt => !!opt?.trim());
}

/**
 * Checks if a question type is scale-based (single or multiple point scale).
 */
export function isScaleType(type: QuestionType | ''): boolean {
  return type === QuestionTypes.SinglePointScale || type === QuestionTypes.MultiplePointScale;
}

/**
 * Validates that scale matrix has required row and column options.
 */
export function isScaleMatrixValid(
  rowOptions: string[] | undefined | null,
  columnOptions: string[] | undefined | null
): boolean {
  const rows = rowOptions ?? [];
  const cols = columnOptions ?? [];
  return (
    rows.length >= 2 &&
    cols.length >= 2 &&
    rows.every(r => !!r?.trim()) &&
    cols.every(c => !!c?.trim())
  );
}

/**
 * Validates a complete question model based on its type requirements.
 */
export function isQuestionValid(question: Partial<QuestionModel>): boolean {
  if (!isQuestionTextValid(question.question)) {
    return false;
  }

  if (isChoiceType(question.type as QuestionType | '')) {
    return isChoiceOptionsValid(question.options);
  }

  if (isScaleType(question.type as QuestionType | '')) {
    return isScaleMatrixValid(question.rowOptions, question.columnOptions);
  }

  return true;
}

/**
 * Normalizes a rephrased question response into a QuestionModel shape.
 * Handles both single and multiple rephrase responses.
 */
export function normalizeRephrasedQuestion(
  response: unknown,
  currentQuestion: QuestionModel | undefined,
  index: number
): QuestionModel | null {
  const extracted = extractRephrasedQuestion(response);
  if (!extracted) return null;

  const nextType = (extracted.type ?? currentQuestion?.type ?? '') as QuestionType;
  const normalized: QuestionModel = {
    questionNumber: currentQuestion?.questionNumber ?? index + 1,
    type: nextType,
    question: (extracted.question ?? '').trim(),
    isRequired: extracted.isRequired ?? currentQuestion?.isRequired ?? false,
    options: [],
    rowOptions: [],
    columnOptions: [],
    npsLeftLabel: '',
    npsRightLabel: '',
  };

  if (isChoiceType(nextType)) {
    normalized.options = Array.isArray(extracted.options)
      ? extracted.options.map(o => String(o ?? '').trim())
      : (currentQuestion?.options ?? []);
  }

  if (isScaleType(nextType)) {
    normalized.rowOptions = Array.isArray(extracted.rowOptions)
      ? extracted.rowOptions.map(r => String(r ?? '').trim())
      : (currentQuestion?.rowOptions ?? []);
    normalized.columnOptions = Array.isArray(extracted.columnOptions)
      ? extracted.columnOptions.map(c => String(c ?? '').trim())
      : (currentQuestion?.columnOptions ?? []);
  }

  if (nextType === QuestionTypes.NetPromoterScore) {
    normalized.npsLeftLabel = (typeof extracted.npsLeftLabel === 'string' ? extracted.npsLeftLabel : '').trim();
    normalized.npsRightLabel = (typeof extracted.npsRightLabel === 'string' ? extracted.npsRightLabel : '').trim();
  }

  return normalized;
}

function extractQuestionModelFromValue(value: unknown): Partial<QuestionModel> | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const responseObject = value as Record<string, unknown>;
  if (typeof responseObject['question'] === 'string') {
    return responseObject as Partial<QuestionModel>;
  }

  const nestedQuestion = responseObject['question'];
  if (nestedQuestion && typeof nestedQuestion === 'object') {
    const nestedQuestionObject = nestedQuestion as Record<string, unknown>;
    if (typeof nestedQuestionObject['question'] === 'string') {
      return nestedQuestionObject as Partial<QuestionModel>;
    }
  }

  return null;
}

function extractQuestionModelFromResponseValue(responseValue: unknown): Partial<QuestionModel> | null {
  if (Array.isArray(responseValue)) {
    return extractQuestionModelFromValue(responseValue[0]);
  }

  return extractQuestionModelFromValue(responseValue);
}

/**
 * Extracts a QuestionModel from various response shapes (API, wrapped, array, etc).
 */
export function extractRephrasedQuestion(response: unknown): Partial<QuestionModel> | null {
  const valuesToCheck: unknown[] = [];
  if (response && typeof response === 'object') {
    const source = response as Record<string, unknown>;
    valuesToCheck.push(source['result'], source['question']);
  }
  valuesToCheck.push(response);

  for (const responseValue of valuesToCheck) {
    const extracted = extractQuestionModelFromResponseValue(responseValue);
    if (extracted) {
      return extracted;
    }
  }

  return null;
}
