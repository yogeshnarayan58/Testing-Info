# Phase A: change log (e2e)

Nothing was run: no tests, no terminal commands. All paths are relative to `e2e\`.

## Files changed

| File | Change |
|---|---|
| `page-objects/common/survey-builder.page.ts` | `saveDraft()` rewritten; `isDraftSavedToastVisible()` fixed; removed the unused `SAVE_DIALOG_APPEAR_TIMEOUT` import; added page-object methods for the Publish location popup and the Review survey details dialog (listed below). Existing methods (`confirmPublish`, `publishSurvey`, `openPublishDialog`, etc.) are untouched. |
| `locators/survey/survey-builder.locator.json` | Added 7 locators (listed below). `confirmPublishButton` is untouched. |
| `test-data/dev-test-data.json` | Added `surveyNames.publish` = "Home Appliance Usage Survey". |
| `tests/survey/common-test-cases/build-survey-common-test-cases.ts` | Added `registerReviewSurveyDetailsEditTest` (TC_BS_29). No existing function changed. |
| `tests/survey/common-test-cases/scratch-setup.ts` | **New.** `registerScratchSetupTests(hooks)`: the five "Start from scratch" setup tests, moved verbatim out of `start-from-scratch.spec.ts` so two specs can share them. |
| `tests/survey/start-from-scratch.spec.ts` | The five inline setup tests replaced by one `registerScratchSetupTests(...)` call (same titles, tags and position). TC_BS_17, TC_BS_24 and TC_BS_16/18 removed (moved). Unused imports and dataset constants removed. |
| `tests/survey/publish-popup.spec.ts` | **New.** Serial describe for the "Publish your survey" popup tests on a fresh, unsaved survey. |
| `tests/survey/start-with-prompt.spec.ts` | TC_BS_29 registered last (after TC_AI_14); import added. |
| `investigation/PHASE-A.md` | This file. |

## Change 1: TC_BS_10 toast race (`survey-builder.page.ts`)

- `saveDraft(title)`:
  1. Waits for any old "Survey saved as draft successfully" toast to be hidden (up to `MEDIUM_TIMEOUT`). If it is still visible after that, it throws, so a leftover toast from TC_BS_10a cannot give a false pass.
  2. Clicks Save draft.
  3. Waits up to `MEDIUM_TIMEOUT` for whichever appears first: the save dialog's title input (`saveCopyTitleInput`) or the toast text (`saveDraftSuccessToast`), using Playwright `locator.or()`. Both selectors come from the locator JSON.
  4. Dialog showed: fill and save as before (`fillSaveCopyDialog`). Toast showed first: return (already-saved path).
- `isDraftSavedToastVisible()`: now `return await toast.isVisible(MEDIUM_TIMEOUT)`, so the `catch` works. The literal `10000` is replaced by the constant (same value).
- `registerSaveDraftTest` (TC_BS_10) is unchanged, so the Scratch spec's TC_BS_10 is untouched. Its Scratch run takes the already-saved path.
- Behaviour change to know about: the old code waited only 3 s for the dialog; the new code waits up to 10 s for either signal, and throws if neither shows.
- `SAVE_DIALOG_APPEAR_TIMEOUT` is no longer used anywhere; the constant itself is still in `timeout-constants.ts` (not removed, no constants were added).

## Change 2: `publish-popup.spec.ts`

`test.describe.serial('Publish popup (start from scratch, unsaved survey)', { tag: '@PublishPopup' })`. It never saves a draft.

| Order | Test | Source |
|---|---|---|
| 1-5 | Start from Scratch: Should display the Start from scratch option on the survey home page / Dataset Selection / Panelist Filters / Response Count / Survey Builder | `registerScratchSetupTests` (shared, moved from `start-from-scratch.spec.ts`) |
| 6 | Setup: Should add 3 questions to the new unsaved survey | new (`ensureQuestionCount(3)`) |
| 7 | TC_BS_17: Publish popup Cancel leaves the survey unpublished | moved, `registerPublishPopupCancelTest` |
| 8 | TC_BS_24: Create a new folder from the Publish popup | moved, `registerCreateFolderFromPublishPopupTest` |
| 9 | TC_BS_16/TC_BS_18: Publish survey | moved, rewritten, `test.fixme` removed |

TC_BS_16/TC_BS_18 steps: `ensureQuestionCount(3)`, `openPublishDialog()` (validates first if "Validate survey" is showing, then clicks publish-survey), assert "Publish your survey" popup, fill the Name field with `surveyNames.publish`, click My Assets, assert Continue enabled, click Continue, assert "Review survey details" is visible and shows the survey name, assert the dimension count (existing `isPublishDialogDimensionCountVisible`) and that the response count text contains 250, then `confirmPublish()` and `verifyPublishSucceeded()`.

It is **not** left as `test.fixme`: I could not see a concrete reason in the code that it cannot work. Risks I cannot rule out from code (all untested):
- The old note was that publish fails on DEV; that is a backend/environment condition I cannot see.
- `confirmPublishButton` (`[data-test-id='-footer'] >> role=button[name="Publish survey"]`) is an older selector. The app button now has `data-test-id="confirm-publish"` (new locator `reviewDialogPublishButton`). If `-footer` no longer exists, `confirmPublish()` fails at the click; I left it as instructed.
- The dimension locator `.publish-review-details [data-test-id$='_Dimension']` depends on the data-summary snapshot markup.
- If validation returns mandatory suggestions, `publish-survey` never appears and TC_BS_17, TC_BS_24 and TC_BS_16/18 fail at `openPublishDialog()`.
- Publishing under a fixed name ("Home Appliance Usage Survey") means a second run publishes a second survey with the same name; if the app rejects duplicates, the test fails on re-run.

## Change 3: TC_BS_29

TC_BS_28 is already used ("Empty question text blocks Save changes"), so the next free id is **TC_BS_29**: "TC_BS_29: Review survey details dialog, Edit survey returns to Build Survey" (`registerReviewSurveyDetailsEditTest`, tag `@ReviewSurveyDetails`), registered last in `start-with-prompt.spec.ts`.

Steps: `ensureQuestionCount(3)`, read the question count, `openPublishDialog()` (runs the validate step first if needed), assert the Review survey details dialog is visible, assert non-empty dialog title (`publish-dialog-title`), survey title (`.publish-survey-title`), question summary (`.publish-question-summary`, and that it contains the question count) and response count (`publish-response-count`), assert the dialog's Publish survey button (`confirm-publish`) is visible, click "Edit survey", assert the dialog closes, assert Build Survey is shown, assert the question count is unchanged.

Prompt-flow risk: the `describe.serial` stops after the first failure. In the Prompt flow, TC_BS_17 and TC_AI_14 (unchanged) run before TC_BS_29, and because the survey already has a folder by then (saved by TC_BS_10a / TC_BS_10), they are expected to fail at the "Publish your survey" popup assertion. If either fails, TC_BS_29 is skipped. Fixing that needs the Prompt spec's TC_BS_17 / TC_AI_14 to move or change, which was out of scope.

### Locators added (`survey-builder.locator.json`)

| elementName | selector |
|---|---|
| `reviewSurveyDetailsDialog` | `[role='dialog']:has-text("Review survey details") >> nth=0` |
| `publishDialogTitle` | `[data-test-id='publish-dialog-title']` |
| `publishSurveyTitle` | `.publish-survey-title` |
| `publishQuestionSummary` | `.publish-question-summary` |
| `publishResponseCount` | `[data-test-id='publish-response-count']` |
| `publishEditSurveyButton` | `role=button[name="Edit survey"]` (scoped inside `reviewSurveyDetailsDialog` in code) |
| `reviewDialogPublishButton` | `[data-test-id='confirm-publish']` |

### Page-object methods added (`SurveyBuilderPage`)

`fillPublishLocationDialogName`, `clickPublishLocationMyAssetsFolder`, `clickPublishLocationDialogContinue`, `isReviewSurveyDetailsDialogVisible`, `isReviewSurveyDetailsDialogClosed`, `getReviewDialogTitleText`, `getReviewDialogSurveyTitleText`, `getReviewDialogQuestionSummaryText`, `getReviewDialogResponseCountText`, `isReviewDialogPublishButtonVisible`, `clickReviewDialogEditSurvey`, plus a private helper `getVisibleText`.

## Tests added, moved, modified

| Test | Action | Where |
|---|---|---|
| TC_BS_29: Review survey details dialog, Edit survey returns to Build Survey | **added** | `start-with-prompt.spec.ts` (last), function in `build-survey-common-test-cases.ts` |
| Setup: Should add 3 questions to the new unsaved survey | **added** | `publish-popup.spec.ts` |
| TC_BS_17: Publish popup Cancel leaves the survey unpublished | **moved** out of `start-from-scratch.spec.ts` (Scratch) into `publish-popup.spec.ts` | Prompt copy unchanged |
| TC_BS_24: Create a new folder from the Publish popup | **moved** out of `start-from-scratch.spec.ts` into `publish-popup.spec.ts` | Prompt twin TC_AI_14 unchanged |
| TC_BS_16/TC_BS_18: Publish survey | **moved and modified** (fixme removed, new flow, name from `surveyNames.publish`) | `publish-popup.spec.ts` |
| The five Scratch setup tests (Start from Scratch..., Dataset Selection..., Panelist Filters..., Response Count..., Survey Builder...) | **moved** into the shared `registerScratchSetupTests`; same titles, tags and order in `start-from-scratch.spec.ts`; also registered in `publish-popup.spec.ts` | `scratch-setup.ts` |
| TC_BS_10 / `registerSaveDraftTest` | not modified; behaviour changes through `saveDraft()` and `isDraftSavedToastVisible()` | shared |
| TC_BS_10a / `registerSaveDraftEmptyTitleTest` | not modified | shared |

After the move, `start-from-scratch.spec.ts` no longer has any publish test (36 -> 33 tests), and the full-file order is otherwise unchanged. `publish-popup.spec.ts` has 9 tests.

## Notes

- The setup tests could not be "reused" as-is: they were inline in `start-from-scratch.spec.ts`, not helpers. I extracted them to `scratch-setup.ts` and had the Scratch spec call it, rather than copy-pasting them. This is the only place existing tests were touched structurally.
- The task said not to append numbers, dates or `Date.now()` to names. The earlier `uniqueNameSuffix()` (adds " - 04 Nov 22:55") on the save-draft and folder names in `build-survey-common-test-cases.ts` is still there; I did not change it because it was out of this task's list. New names added here (`surveyNames.publish`) have no suffix.
- Both `publish-popup.spec.ts` and `start-with-prompt.spec.ts` can run in parallel workers with the same stored user (`workers: 2` locally); I could not determine whether the app tolerates two surveys in progress for one user.
