import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy, OnInit } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
    ButtonModule,
    CardModule,
    DropDownModule,
    IconButtonModule,
    IconModule,
    ItemModule,
    MenuModule,
    SegmentControlModule
} from '@nielseniq/athena-core';
import { concat, of, Subject, timer } from 'rxjs';
import { map, switchMap, takeUntil } from 'rxjs/operators';
import { SURVEY_FLOW_STEPS } from '../../../core/config/config';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { SurveyService } from '../../build-survey/services/survey.service';
import { ValidationService } from '../../build-survey/services/validation.service';
import { RunReportService } from '../services/run-report.service';
import { PanelistDataselectorComponent } from './panelist-dataselector/panelist-dataselector.component';
import { TranslateModule } from '@ngx-translate/core';
@Component({
    selector: 'select-panelist',
    standalone: true,
    imports: [
        CommonModule,
        PanelistDataselectorComponent,
        MenuModule,
        ItemModule,
        CardModule,
        IconModule,
        DropDownModule,
        ButtonModule,
        IconButtonModule,
        SegmentControlModule,
        FormsModule,
        TranslateModule
    ],
    templateUrl: './select-panelist.component.html',
    styleUrl: './select-panelist.component.scss',
})
export class SelectPanelistComponent implements OnInit, OnDestroy {
    private readonly surveyService = inject(SurveyService);
    private readonly validationService = inject(ValidationService);
    private readonly runReportService = inject(RunReportService);
    private readonly router = inject(Router);
    private readonly route = inject(ActivatedRoute);
    readonly surveyCommonService = inject(SurveyCommonService);
    reportData = false;
    userPrompt = '';
    private readonly promptInput$ = new Subject<string>();
    readonly isPromptSettling = toSignal(
        this.promptInput$.pipe(
            switchMap(() => concat(of(true), timer(1500).pipe(map(() => false))))
        ),
        { initialValue: false }
    );
    private readonly destroy$ = new Subject<void>();
    reportResponse: any = null;
    householdCount: string = '0';
    isSearching = false;
    eligibleCount = 0;
    selectedResponses: number | null = null;
    responseCounts = [100, 150, 200, 250, 300, 400, 500];
    additionalResponseCounts = [600, 700, 800, 900, 1000];
    showMoreResponseOptions = false;
    hasDataset = false;
    selectedDatasetName = '';
    isPanelOpen = false;
    private skipAutoCriteriaReset = false;
    minEligibleCount = 100;
    get isUnhappyPath(): boolean {
        return this.eligibleCount <= this.minEligibleCount;
    }
    constructor() {
        effect(() => {
            this.restoreSelectPanelistUiState();
        });
    }

    ngOnInit(): void {
        this.surveyCommonService.setActiveSurveyStep(SURVEY_FLOW_STEPS.SELECT_PANELIST);
        this.surveyCommonService.setDatasetFooterVisible(true);
        this.runReportService.reportCompleted$
            .pipe(takeUntil(this.destroy$))
            .subscribe((response) => {
                if (response) {
                    this.reportResponse = response;
                    this.extractHouseholdCount(response);
                    this.reportData = true;
                    this.syncUiState({ reportData: this.reportData, householdCount: this.householdCount });
                }
            });
    }

    private restoreSelectPanelistUiState(): void {
        this.syncUiState();
        this.userPrompt = this.surveyCommonService.getUserPrompt();
        this.skipAutoCriteriaReset = this.reportData;
    }

    /**
     * Unified state management: restore or persist UI state to service
     * Consolidates restoreUiState and persistUiState into single method (Requirement #4)
     */
    private syncUiState(partialState?: Partial<{ reportData: boolean; householdCount: string; selectedResponses: number | null }>): void {
        if (partialState) {
            // Persist: save partial state to service
            this.surveyCommonService.setSelectPanelistUiState(partialState);
        } else {
            // Restore: load full state from service
            const cachedUiState = this.surveyCommonService.getSelectPanelistUiState();
            this.reportData = cachedUiState.reportData;
            this.householdCount = cachedUiState.householdCount;
            this.eligibleCount = Number(cachedUiState.householdCount?.replace(/,/g, '') || '0');
            this.selectedResponses = cachedUiState.selectedResponses;
        }
    }

    /**
     * Extract household count from report response with full type safety
     */
    private extractHouseholdCount(response: any): void {
        try {
            const gridData = response?.[0] ?? response;
            const rowData = (gridData as any)?.rowData;
            if (rowData?.length) {
                const lastRow = rowData[rowData.length - 1];
                const keys = Object.keys(lastRow);
                const lastKey = keys[keys.length - 1];
                const cellValue = Number(lastRow[lastKey]?.cellValue ?? 0);
                this.householdCount = cellValue.toLocaleString();
                this.eligibleCount = cellValue;
            }
        } catch {
            this.householdCount = '0';
            this.eligibleCount = 0;
        }
    }

    /** Keep local and shared state aligned after a successful report completion from child components. */
    onReportCompleted(event: { eligibleCount: number }): void {
        this.isSearching = false;
        this.reportData = true;
        this.eligibleCount = event.eligibleCount;
        this.householdCount = event.eligibleCount.toLocaleString();
        this.syncUiState({
            reportData: this.reportData,
            householdCount: this.householdCount,
        });
    }

    /** Dataset selection is tracked locally for UX cues independent of report execution. */
    onDatasetSelected(name: string): void {
        this.hasDataset = true;
        this.selectedDatasetName = name;
    }

    /** Prompt edits invalidate downstream survey generation state until panelist search is rerun. */
    onPromptInput(): void {
        this.promptInput$.next(this.userPrompt);
        this.surveyCommonService.setUserPrompt(this.userPrompt);
        this.surveyCommonService.panelistCompleted.set(false);
        if (this.surveyService?.questions().length) {
            this.surveyService.setQuestions([]);
            this.surveyService.genState.set('idle');
            this.validationService.resetValidation();
        }
    }

    /** Response target changes clear completion state so publish/build flows cannot proceed with stale counts. */
    selectResponse(count: number): void {
        this.selectedResponses = count;
        this.syncUiState({
            selectedResponses: this.selectedResponses,
        });
        this.surveyCommonService.panelistCompleted.set(false);
    }

    /** Expanded response options are restricted to scratch flow to match current product scope. */
    toggleMoreResponseOptions(): void {
        if (!this.surveyCommonService.flowType().scratch) return;
        this.showMoreResponseOptions = !this.showMoreResponseOptions;
    }

    /** Panel open state is mirrored to shared service for wrapper/footer coordination. */
    onPanelToggled(isOpen: boolean): void {
        this.surveyCommonService.setPanelOpen(isOpen);
        this.isPanelOpen = isOpen;
    }

    /** First criteria callback after restore is ignored once to avoid clearing valid hydrated report state. */
    onCriteriaChanged(): void {
        if (this.skipAutoCriteriaReset) {
            this.skipAutoCriteriaReset = false;
            return;
        }
        this.skipAutoCriteriaReset = false;
        this.runReportService.resetReportCompleted();
        this.clearCriteriaState();
        this.surveyCommonService.panelistCompleted.set(false);
    }

    /** Criteria reset clears derived report artifacts so UI cannot display mismatched dataset/count combinations. */
    private clearCriteriaState(): void {
        this.reportData = false;
        this.reportResponse = null;
        this.householdCount = '0';
        this.eligibleCount = 0;
        this.selectedResponses = null;
        this.syncUiState({
            reportData: this.reportData,
            householdCount: this.householdCount,
            selectedResponses: this.selectedResponses,
        });
    }
    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    /** Setting panelistCompleted gates navigation checks in downstream steps and wrappers. */
    proceedToSurveyBuilder(): void {
        this.surveyCommonService.setPanelOpen(false);
        this.surveyCommonService.setUserPrompt(this.userPrompt);
        this.surveyCommonService.panelistCompleted.set(true);
        const surveyId = this.route.snapshot.paramMap.get('surveyId')?.trim() || this.surveyService.currentSurveyId?.trim() || '';
        const routeCommands = surveyId ? ['build-survey', surveyId] : ['build-survey'];
        this.router.navigate(routeCommands, { relativeTo: this.route.parent ?? this.route });
    }

    /** Available response targets are filtered by eligible count to prevent impossible selection paths. */
    get filteredResponseCounts(): number[] {
        const availableCounts = this.surveyCommonService.flowType().scratch && this.showMoreResponseOptions
            ? [...this.responseCounts, ...this.additionalResponseCounts]
            : this.responseCounts;
        return this.isUnhappyPath
            ? []
            : availableCounts.filter(count => count <= this.eligibleCount);
    }
}
