export const HEAT_GRID_LEGEND_STOP_POSITIONS = [15, 55, 100] as const;
export const GRID_ROW_HEIGHT = 40;
export const GRID_HEADER_HEIGHT = 40;
export const GRID_BORDER_HEIGHT = 2;
export const GRID_VISIBLE_ROW_LIMIT = 6;
export const HEAT_GRID_VISIBLE_ROW_LIMIT = 10;
export const HEAT_GRID_FIRST_COLUMN_MAX_WIDTH = 330;
