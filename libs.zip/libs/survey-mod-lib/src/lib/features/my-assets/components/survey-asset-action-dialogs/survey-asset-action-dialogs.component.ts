import { ChangeDetectionStrategy, Component, DestroyRef, ViewChild, WritableSignal, computed, inject, output, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Asset } from '@nielsen/crf-lp-common';
import { TreeForderSelectorModule } from '@nielsen/crf-ui-components';
import { ButtonModule, DialogComponent, DialogModule, SpinnerModule, TabModule, TextFieldModule, ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { Observable, Subscription, finalize } from 'rxjs';
import { SurveyGridRow } from '../../models/survey-asset.model';
import { isFolderAsset } from '../../utils/survey-status.util';
import { SurveyAssetActionsService } from '../../services/survey-asset-actions.service';
import { ASSET_TYPE } from '../../constants/my-assets-tabs.constant';
import { SurveyExceptionHandlingService } from '../../../../shared/services/survey-exception-handling.service';
import { HttpErrorResponse } from '@angular/common/http';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

/** State and toast messages for a mutation. */
interface MutationState {
  busy: WritableSignal<boolean>;
  dialog?: DialogComponent;
  successMessage: string;
}

@Component({
  selector: 'survey-asset-action-dialogs',
  standalone: true,
  imports: [FormsModule, ButtonModule, DialogModule, SpinnerModule, TabModule, TextFieldModule, TreeForderSelectorModule, TranslateModule],
  templateUrl: './survey-asset-action-dialogs.component.html',
  styleUrl: './survey-asset-action-dialogs.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyAssetActionDialogsComponent {
  private readonly actions = inject(SurveyAssetActionsService);
  private readonly toast = inject(ToastService);
  private readonly exceptionHandlingService = inject(SurveyExceptionHandlingService);
  private readonly translate = inject(TranslateService);
  private readonly destroyRef = inject(DestroyRef);
  readonly assetsChanged = output<void>();
  readonly renameTitle = signal('');
  readonly renameBusy = signal(false);
  readonly renameValidation = computed(() => {
    const title = this.renameTitle();
    if (!title.length) {
      return this.translation('SURVEYMOD_FIELD_REQUIRED');
    }
    if (title.startsWith(' ')) {
      return this.translation('SURVEYMOD_LEADING_SPACE_MESSAGE');
    }
    return title.length > 150
      ? this.translation('SURVEYMOD_MAX_LENGTH_MESSAGE', { max: 150 })
      : '';
  });
  readonly folders = signal<Asset[]>([]);
  readonly foldersLoading = signal(false);
  readonly folderLoadFailed = signal(false);
  readonly moveBusy = signal(false);
  readonly rootFolder: Asset = { assetId: 'root', title: this.translation('SURVEYMOD_MY_ASSETS') };
  readonly selectedFolder = signal<Asset>(this.rootFolder);
  readonly assetsToMove = signal<readonly SurveyGridRow[]>([]);
  readonly moveDisabled = computed(() => this.foldersLoading() || this.folderLoadFailed() || this.moveBusy()
    || !this.assetsToMove().some((row) => (row.parentAsset?.assetId ?? 'root') !== this.selectedFolder().assetId));
  readonly deleteSelection = signal<{ rows: readonly SurveyGridRow[]; permanent: boolean }>({
    rows: [], permanent: false,
  });
  readonly deleteBusy = signal(false);
  readonly restoreBusy = signal(false);
  readonly deleteConfirmation = computed(() => {
    const { rows, permanent } = this.deleteSelection();
    return {
      testId: permanent ? 'survey-delete-permanent' : 'survey-delete',
      title: permanent
        ? (rows.length > 1 ? this.translation('SURVEYMOD_DELETE_PERMANENTLY') : this.translation('SURVEYMOD_CONFIRM_DELETION'))
        : (rows.length === 1 && !isFolderAsset(rows[0]) ? this.translation('SURVEYMOD_DELETE') : this.translation('SURVEYMOD_MOVE_TO_TRASH')),
      message: this.buildDeleteMessage(rows, permanent),
      busy: this.deleteBusy(),
      buttonLabel: permanent && rows.length === 1 ? this.translation('SURVEYMOD_DELETE') : this.translation('SURVEYMOD_CONFIRM'),
      permanent,
    };
  });
  private renameAssetId: string | null = null;
  private folderRequest?: Subscription;

  @ViewChild('renameDialog') renameDialog?: DialogComponent;
  @ViewChild('folderDialog') folderDialog?: DialogComponent;
  @ViewChild('confirmDialog') confirmDialog?: DialogComponent;
  @ViewChild('deleteDialog') deleteDialog?: DialogComponent;

  /** Opens Rename prefilled with the asset's current title. */
  openRename(row: SurveyGridRow): void {
    this.renameAssetId = row.assetId;
    this.renameTitle.set(row.title);
    this.renameDialog?.open();
  }

  /** Submits a valid rename; ignored while a request is pending. */
  saveRename(): void {
    if (this.renameBusy() || this.renameValidation() || !this.renameAssetId) {
      return;
    }
    this.runMutation(this.actions.renameAsset(this.renameAssetId, this.renameTitle()), {
      busy: this.renameBusy,
      dialog: this.renameDialog,
      successMessage: this.translation('SURVEYMOD_ASSET_RENAME_SUCCESS', { assetName: this.renameTitle() }),
    });
  }

  /** Opens the folder picker for a snapshot of the selected rows, defaulting to My assets. */
  openMove(rows: readonly SurveyGridRow[]): void {
    this.cancelFolderLoad();
    this.assetsToMove.set([...rows]);
    this.selectedFolder.set(this.rootFolder);
    this.folders.set([]);
    this.folderDialog?.open();
    this.loadFolders();
  }

  /** Fetches destination folders; also used by the Retry link after a failure. */
  loadFolders(): void {
    if (this.foldersLoading()) {
      return;
    }
    this.foldersLoading.set(true);
    this.folderLoadFailed.set(false);
    this.folderRequest = this.actions.fetchMoveFolders().pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => this.foldersLoading.set(false))
    ).subscribe({
      next: (folders) => this.folders.set(folders),
      error: (err: HttpErrorResponse) => {
        this.folderLoadFailed.set(true);
        this.exceptionHandlingService.handleApiError(err);
      },
    });
  }

  /** Drops a pending folder request so a stale response cannot update a closed or reopened dialog. */
  cancelFolderLoad(): void {
    this.folderRequest?.unsubscribe();
  }

  selectFolder(folder: Asset): void {
    this.selectedFolder.set(folder);
  }

  /** Switches from the folder picker to the confirmation dialog when the move is valid. */
  confirmMove(): void {
    if (this.moveDisabled()) {
      return;
    }
    this.folderDialog?.close();
    this.confirmDialog?.open();
  }

  /** Moves the selected surveys after the user confirms the destination. */
  saveMove(): void {
    if (this.moveBusy()) {
      return;
    }
    this.runMutation(this.actions.moveAssets(this.assetsToMove(), this.selectedFolder()), {
      busy: this.moveBusy,
      dialog: this.confirmDialog,
      successMessage: this.moveSuccessMessage(),
    });
  }

  private moveSuccessMessage(): string {
    const assets = this.assetsToMove();
    const destination = this.selectedFolder().title;
    return assets.length === 1
      ? this.translation('SURVEYMOD_ASSET_MOVE_SUCCESS', { assetName: assets[0].title, destination })
      : this.translation('SURVEYMOD_ASSETS_MOVE_SUCCESS', { destination });
  }

  /** Trashes a single survey directly; folders and bulk selections require confirmation. */
  openDelete(rows: readonly SurveyGridRow[]): void {
    if (this.deleteBusy() || !rows.length) {
      return;
    }
    this.deleteSelection.set({ rows: [...rows], permanent: false });
    const selectedRows = this.deleteSelection().rows;
    if (selectedRows.length === 1 && selectedRows[0].assetType === ASSET_TYPE.DISCOVERSURVEY) {
      this.runMutation(this.actions.trashAssets(selectedRows), {
        busy: this.deleteBusy,
        successMessage: this.translation('SURVEYMOD_SURVEY_MOVED_TO_TRASH', { assetName: selectedRows[0].title }),
      });
      return;
    }
    this.deleteDialog?.open();
  }

  /** Moves the selected assets to Trash after the user confirms. */
  saveDelete(): void {
    if (this.deleteBusy()) {
      return;
    }
    const rows = this.deleteSelection().rows;
    this.runMutation(this.actions.trashAssets(rows), {
      busy: this.deleteBusy,
      dialog: this.deleteDialog,
      successMessage: rows.length === 1
        ? this.translation('SURVEYMOD_ASSET_MOVED_TO_TRASH', { assetName: rows[0].title })
        : this.translation('SURVEYMOD_BULK_ASSETS_MOVED_TO_TRASH'),
    });
  }

  /** Opens the "Delete permanently" confirmation (Trash tab only; irreversible on confirm). */
  openDeletePermanently(rows: readonly SurveyGridRow[]): void {
    if (this.deleteBusy() || !rows.length) {
      return;
    }
    this.deleteSelection.set({ rows: [...rows], permanent: true });
    this.deleteDialog?.open();
  }

  saveDeleteConfirmation(): void {
    if (this.deleteSelection().permanent) {
      this.saveDeletePermanently();
    } else {
      this.saveDelete();
    }
  }

  /** Permanently deletes the selected assets after the user confirms. */
  saveDeletePermanently(): void {
    if (this.deleteBusy()) {
      return;
    }
    const rows = this.deleteSelection().rows;
    this.runMutation(this.actions.deletePermanently(rows), {
      busy: this.deleteBusy,
      dialog: this.deleteDialog,
      successMessage: rows.length === 1
        ? this.translation('SURVEYMOD_PERMANENT_DELETE_SUCCESS', { assetName: rows[0].title })
        : this.translation('SURVEYMOD_BULK_PERMANENT_DELETE_SUCCESS'),
    });
  }

  /** Restores the selection from Trash immediately: unlike delete, this isn't destructive, so no confirmation is needed. */
  restore(rows: readonly SurveyGridRow[]): void {
    if (this.restoreBusy() || !rows.length) {
      return;
    }
    this.runMutation(this.actions.restoreAssets(rows), {
      busy: this.restoreBusy,
      successMessage: rows.length === 1
        ? this.translation('SURVEYMOD_RESTORE_SUCCESS', { assetName: rows[0].title })
        : this.translation('SURVEYMOD_BULK_RESTORE_SUCCESS'),
    });
  }

  /** Builds the Delete / Delete permanently confirmation message for the current selection. */
  private buildDeleteMessage(rows: readonly SurveyGridRow[], permanent: boolean): string {
    if (rows.length > 1) {
      return permanent
        ? this.translation('SURVEYMOD_BULK_PERMANENT_DELETE_CONFIRM')
        : this.translation('SURVEYMOD_BULK_TRASH_CONFIRM');
    }
    const row = rows[0];
    if (!row) {
      return '';
    }
    if (permanent) {
      return this.translation('SURVEYMOD_PERMANENT_DELETE_CONFIRM', { assetName: row.title });
    }
    return this.translation(
      isFolderAsset(row) ? 'SURVEYMOD_FOLDER_TRASH_CONFIRM' : 'SURVEYMOD_SURVEY_TRASH_CONFIRM',
      { assetName: row.title }
    );
  }

  private translation(key: string, params?: Record<string, unknown>): string {
    return params ? this.translate.instant(key, params) : this.translate.instant(key);
  }

  /** Closes and refreshes only on success; failures show a toast and allow retry. */
  private runMutation(request: Observable<unknown>, state: MutationState): void {
    state.busy.set(true);
    request.pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => state.busy.set(false))
    ).subscribe({
      next: () => {
        state.dialog?.close();
        this.notifySuccess(state.successMessage);
      },
      error: (err: HttpErrorResponse) => this.exceptionHandlingService.handleApiError(err),
    });
  }

  /** Shows a success toast and asks the parent page to refresh its assets. */
  private notifySuccess(message: string): void {
    this.toast.InsertToast('success', message, { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
    this.assetsChanged.emit();
  }
}
