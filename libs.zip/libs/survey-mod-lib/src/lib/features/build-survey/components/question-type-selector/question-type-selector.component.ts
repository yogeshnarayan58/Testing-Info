import { Component, ElementRef, HostListener, OnInit, signal, viewChild } from '@angular/core';
import { SurveyService } from '../../services/survey.service';
import { QuestionTypeListComponent } from '../question-type-list/question-type-list.component';
import { QuestionType } from '../../models/build-survey';
import { QuestionEditorComponent } from '../question-editor/question-editor.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-question-type-selector',
  imports: [QuestionTypeListComponent, QuestionEditorComponent, TranslateModule],
  standalone: true,
  templateUrl: './question-type-selector.component.html',
  styleUrls: ['./question-type-selector.component.scss']
})
export class QuestionTypeSelectorComponent implements OnInit {

  selectedType = signal<QuestionType | ''>('');
  showEditor = signal(false);
  publishRequest = signal(0);
  initialQuestionEditor = viewChild<ElementRef<HTMLElement>>('initialQuestionEditor');

  constructor(private surveyService: SurveyService) {}

  ngOnInit() {
    this.selectedType.set(this.surveyService.getQuestionType());
  }

  onTypeSelected(type: QuestionType | '') {
    this.selectedType.set(type);
    if (!type) {
      return;
    }
    this.surveyService.setQuestionType(type);
    this.publishRequest.set(0);
    this.showEditor.set(true);
  }

  discardQuestion() {
    this.publishRequest.set(0);
    this.selectedType.set('');
    this.surveyService.setQuestionType('');
    this.showEditor.set(false);
  }

  requestPublish(): void {
    this.publishRequest.update((request) => request + 1);
  }

  @HostListener('document:click', ['$event'])
  saveOnOutsideClick(event: MouseEvent): void {
    if (!this.showEditor()) {
      return;
    }

    const target = event.target as Node | null;
    const editorElement = this.initialQuestionEditor()?.nativeElement;
    const path = event.composedPath?.() ?? [];
    const targetElement = target instanceof Element ? target : null;
    // The opening click can reach document after its type-list DOM has been removed.
    const clickedTypeList = !!targetElement?.closest('survey-question-type-list') || path.some(node =>
      node instanceof Element && node.matches('survey-question-type-list')
    );
    const clickedInsideEditor = !!editorElement &&
      ((!!target && editorElement.contains(target)) || path.includes(editorElement));

    if (!editorElement || clickedTypeList || clickedInsideEditor) {
      return;
    }

    setTimeout(() => {
      if (this.showEditor()) {
        this.requestPublish();
      }
    }, 0);
  }
}
