import test from "@playwright/test";
import {
  hasPivotInDimensionSelections,
  getDimensionSelectionsByPivot,
  findDataSetByName,
  getTestDataByLocale
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { assert } from "@gfk/gta";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import prodTestData from "./test-data/prod-test-data.json";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;

const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;

const pivot: string = "Product Share";
let savedReportTitle: string = "";
let savedReportUrl: string = "";


test.describe("Rolling purchase drivers product share pivot", async () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);
      await dataSelector.clickAdditionalPromptEllipsisIcon();

      await dataSelector.clickMadlibDimension("Benchmark Product");

      if (localeData.pivotMadlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).productShare;

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(
          new RegExp(expectedMadlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );



  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);

          const productSharePivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
          if (!productSharePivotData) {
            throw new Error("Pivot not found in test data: Retailer");
          }

          await dataSelector.switchPivotDropdown(pivot);
          await dataSelector.clickAdditionalPromptEllipsisIcon();

          await dataSelector.clickMadlibDimension("Benchmark Product");
          await dataSelector.setMadlibSelection(productSharePivotData["Benchmark Product"]);

          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.selectClosedDropdown(productSharePivotData["Facts"]["selections"]);

          await dataSelector.clickMadlibDimension("Retailers");
          await dataSelector.setMadlibSelection(productSharePivotData["Retailers"]);

          await dataSelector.clickMadlibDimension("Products");
          await dataSelector.setMadlibSelection(productSharePivotData["Products"]);

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(productSharePivotData["Geography"]);

          await dataSelector.clickMadlibDimension("Periods");
          await dataSelector.setPeriodMadlibSelection(productSharePivotData["Periods"]);

          await dataSelector.clickMadlibDimension("Demography");
          await dataSelector.setMadlibSelection(productSharePivotData["Demography"]);

          await dataSelector.clickMadlibDimension("People");
          await dataSelector.checkPeopleSelectionGroupExists();
          await dataSelector.clickMadlibDimension("peopleAddGroupButton");
          await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
          await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
          for (const selection of reportTestData.dimensionSelections[1]["People"].selections) {
            await dataSelector.handlePeopleMenuOptions(selection);
          }
          console.log("People selections made"); 

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          console.log("run complete in spec");
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );

      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');
        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);
        await findMyStuff.clickFindMyStuff();
        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("FMS execution successful");
      })
    }
  );
});


