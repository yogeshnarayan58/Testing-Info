import { NO_ERRORS_SCHEMA, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import template from './optiq-feedback.component.html?raw';
import {
  AiSuggestion,
  QuestionModel,
  SuggestionActionType,
  SURVEY_SUGGESTIONS_STATE,
  SURVEY_VALIDATION_STATE,
} from '../../models/build-survey';
import { SurveyService } from '../../services/survey.service';
import { ValidationService } from '../../services/validation.service';
import { OptiqFeedbackComponent } from './optiq-feedback.component';

vi.mock('../../services/survey.service', () => ({
  SurveyService: class {},
}));

const suggestion = (overrides: Partial<AiSuggestion> = {}): AiSuggestion => ({
  suggestionId: 's-1',
  severity: 'OPTIONAL',
  ruleCode: 'RULE',
  issue: 'Issue',
  rationale: 'Rationale',
  suggestedText: 'Suggested',
  fieldPath: 'question',
  source: 'AI',
  action: 'REPHRASE',
  ...overrides,
});

const question = (overrides: Partial<QuestionModel> = {}): QuestionModel => ({
  id: 'q1',
  questionNumber: 1,
  question: 'How satisfied are you?',
  options: ['Low', 'Medium', 'High'],
  rowOptions: ['Row 1'],
  columnOptions: ['Col 1'],
  isRequired: true,
  type: 'single-choice',
  suggestions: [],
  ...overrides,
});

describe('OptiqFeedbackComponent', () => {
  const setup = (translations: Record<string, string> = {}) => {
    const questions = signal<QuestionModel[]>([]);
    const surveyService = {
      questions,
      getQuestions: vi.fn(() => questions()),
      setQuestions: vi.fn((items: QuestionModel[]) => questions.set(items)),
      removeQuestion: vi.fn((index: number) =>
        questions.update((items) => items.filter((_, itemIndex) => itemIndex !== index))
      ),
    };
    const validationService = {
      surveyAIValidationState: signal(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW),
      surveySuggestionState: signal(SURVEY_SUGGESTIONS_STATE.IN_REVIEW),
      countSuggestions: vi.fn((items: QuestionModel[], severity: 'MANDATORY' | 'OPTIONAL') =>
        items.reduce(
          (count, item) => count +
            (item.suggestions?.filter(s => s.severity === severity).length ?? 0),
          0
        )
      ),
      applyAddOptionSuggestion: vi.fn((items: QuestionModel[]) => items),
      rephraseSuggestion: vi.fn((items: QuestionModel[]) => items),
      dismissSuggestion: vi.fn((items: QuestionModel[]) => items),
      removeOptionSuggestion: vi.fn((items: QuestionModel[]) => items),
      syncAfterSuggestionChange: vi.fn(),
    };

    const translateService = {
      instant: vi.fn((key: string, params?: Record<string, unknown>) => {
        const template = translations[key];
        if (template === undefined) {
          return key;
        }
        return template.replace(/{{(\w+)}}/g, (_, name: string) => String(params?.[name]));
      }),
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: SurveyService, useValue: surveyService },
        { provide: ValidationService, useValue: validationService },
        { provide: TranslateService, useValue: translateService },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new OptiqFeedbackComponent());
    return { component, questions, surveyService, validationService, translateService };
  };

  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('suggestion state', () => {
    it('reports no suggestions when none exist', () => {
      const { component, questions } = setup();
      questions.set([question()]);

      expect(component.hasSuggestions()).toBe(false);
      expect(component.questionsWithSuggestions()).toEqual([]);
    });

    it('lists only questions that have suggestions', () => {
      const { component, questions } = setup();
      questions.set([
        question({ id: 'q1' }),
        question({ id: 'q2', questionNumber: 2, suggestions: [suggestion()] }),
        question({ id: 'q3', questionNumber: 3, suggestions: undefined }),
      ]);

      expect(component.hasSuggestions()).toBe(true);
      expect(component.questionsWithSuggestions().map(item => item.id)).toEqual(['q2']);
    });
  });

  describe('subheader', () => {
    it('is empty when there are no suggestions', () => {
      const { component } = setup();

      expect(component.subheader()).toBe('');
    });

    it('shows a singular count with none required in brackets', () => {
      const { component, questions } = setup();
      questions.set([question({ suggestions: [suggestion()] })]);

      expect(component.subheader()).toBe('1 change found (none required)');
    });

    it('shows plural count with the mandatory count', () => {
      const { component, questions } = setup();
      questions.set([
        question({
          suggestions: [
            suggestion({ suggestionId: 'a', severity: 'MANDATORY' }),
            suggestion({ suggestionId: 'b' }),
            suggestion({ suggestionId: 'c' }),
          ],
        }),
      ]);

      expect(component.subheader()).toBe('3 changes found (1 required to publish)');
    });
  });

  describe('getSuggestionConfig', () => {
    it('configures ADD_OPTION', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(
        suggestion({ action: 'ADD_OPTION', fieldPath: 'options[1]' })
      );

      expect(config.title).toBe('Add option');
      expect(config.buttonLabel).toBe('Add');
      expect(config.showComparison).toBe(false);
    });

    it.each([
      'question',
      'options[0]',
      'rowOptions[0]',
      'columnOptions[0]',
      'npsLeftLabel',
      'npsRightLabel',
    ])('configures REPHRASE for %s', fieldPath => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ action: 'REPHRASE', fieldPath }));

      expect(config.title).toBe('Rephrase');
      expect(config.buttonLabel).toBe('Rephrase');
      expect(config.showComparison).toBe(true);
    });

    it.each([
      ['question', 'Remove question'],
      ['options[0]', 'Remove option'],
    ])('configures REMOVE for %s', (fieldPath, title) => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ action: 'REMOVE', fieldPath }));

      expect(config.title).toBe(title);
      expect(config.buttonLabel).toBe('Remove');
    });

    it.each(['npsLeftLabel', 'npsRightLabel'])('titles a REMOVE suggestion for %s as a label', (fieldPath) => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ action: 'REMOVE', fieldPath }));

      expect(config.title).toBe('Remove label');
    });

    it.each([
      ['OPTIONAL', 'npsLeftLabel'],
      ['OPTIONAL', 'npsRightLabel'],
      ['MANDATORY', 'npsLeftLabel'],
      ['MANDATORY', 'npsRightLabel'],
    ])('offers only dismiss for a %s REMOVE suggestion on %s', (severity, fieldPath) => {
      const { component } = setup();

      const config = component.getSuggestionConfig(
        suggestion({ action: 'REMOVE', severity: severity as AiSuggestion['severity'], fieldPath })
      );

      expect(config.buttonLabel).toBeNull();
      expect(config.showDismiss).toBe(true);
    });

    it('still offers the remove button for a REMOVE suggestion on an option', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ action: 'REMOVE', fieldPath: 'options[0]' }));

      expect(config.buttonLabel).toBe('Remove');
    });

    it('configures REVIEW without a primary button', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ action: 'REVIEW' }));

      expect(config.title).toBe('Review suggestion');
      expect(config.buttonLabel).toBeNull();
    });

    it('falls back to the review config for an unknown action', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(
        suggestion({ action: 'SOMETHING_NEW' as AiSuggestion['action'] })
      );

      expect(config.title).toBe('Review suggestion');
    });

    it('handles a missing fieldPath', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(
        suggestion({ action: 'REPHRASE', fieldPath: undefined as unknown as string })
      );

      expect(config.title).toBe('Rephrase');
    });

    it('marks mandatory suggestions as non-dismissable with the error icon', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ severity: 'MANDATORY' }));

      expect(config.isMandatory).toBe(true);
      expect(config.showDismiss).toBe(false);
      expect(config.iconName).toBe('error');
    });

    it('marks optional suggestions as dismissable with the warning icon', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ severity: 'OPTIONAL' }));

      expect(config.isMandatory).toBe(false);
      expect(config.showDismiss).toBe(true);
      expect(config.iconName).toBe('triangle-alert');
    });

    it.each(['ADD_OPTION', 'REPHRASE', 'REMOVE'])(
      'does not offer dismiss for a mandatory %s suggestion',
      (action) => {
        const { component } = setup();

        const config = component.getSuggestionConfig(suggestion({ severity: 'MANDATORY', action: action as AiSuggestion['action'] }));

        expect(config.showDismiss).toBe(false);
        expect(config.buttonLabel).not.toBeNull();
      }
    );

    it('offers dismiss for a mandatory REVIEW suggestion, which has no other action', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(suggestion({ severity: 'MANDATORY', action: 'REVIEW' }));

      expect(config.buttonLabel).toBeNull();
      expect(config.showDismiss).toBe(true);
    });

    it('offers dismiss for a mandatory suggestion with an unknown action', () => {
      const { component } = setup();

      const config = component.getSuggestionConfig(
        suggestion({ severity: 'MANDATORY', action: 'SOMETHING_ELSE' as AiSuggestion['action'] })
      );

      expect(config.buttonLabel).toBeNull();
      expect(config.showDismiss).toBe(true);
    });
  });

  describe('getActionAriaLabel', () => {
    it('falls back to English naming the question', () => {
      const { component } = setup();

      expect(component.getActionAriaLabel('Add', question({ questionNumber: 2 }))).toBe('Add, question 2');
    });
  });

  describe('handleSuggestionAction', () => {
    it.each([
      [SuggestionActionType.ADD_OPTION, 'applyAddOptionSuggestion'],
      [SuggestionActionType.REPHRASE, 'rephraseSuggestion'],
      [SuggestionActionType.REMOVE, 'removeOptionSuggestion'],
    ] as const)('routes %s to the validation service', (actionType, method) => {
      const { component, questions, validationService } = setup();
      const item = suggestion();
      if (actionType === SuggestionActionType.REMOVE) item.fieldPath = 'options[0]';

      component.handleSuggestionAction('q1', actionType, item);

      expect(validationService[method]).toHaveBeenCalledWith(questions(), 'q1', item);
    });

    it.each([SuggestionActionType.DISMISS, SuggestionActionType.REVIEW])(
      'dismisses the suggestion for %s',
      actionType => {
        const { component, questions, validationService } = setup();

        component.handleSuggestionAction('q1', actionType, suggestion({ suggestionId: 's-9' }));

        expect(validationService.dismissSuggestion).toHaveBeenCalledWith(
          questions(),
          'q1',
          's-9'
        );
      }
    );

    it('ignores unknown action types', () => {
      const { component, validationService } = setup();

      component.handleSuggestionAction('q1', 'UNKNOWN' as never, suggestion());

      expect(validationService.applyAddOptionSuggestion).not.toHaveBeenCalled();
      expect(validationService.rephraseSuggestion).not.toHaveBeenCalled();
      expect(validationService.dismissSuggestion).not.toHaveBeenCalled();
      expect(validationService.removeOptionSuggestion).not.toHaveBeenCalled();
    });

    it('does nothing without a suggestion or question id', () => {
      const { component, surveyService, validationService } = setup();

      component.handleSuggestionAction('q1', SuggestionActionType.REMOVE);
      component.handleSuggestionAction('', SuggestionActionType.REMOVE, suggestion());

      expect(surveyService.removeQuestion).not.toHaveBeenCalled();
      expect(validationService.removeOptionSuggestion).not.toHaveBeenCalled();
      expect(component.statusMessage()).toBe('');
    });

    it('announces the result and moves focus into the panel', () => {
      const { component } = setup();
      const focus = vi.fn();
      (component as unknown as { feedbackContainer: unknown }).feedbackContainer = () => ({
        nativeElement: { focus },
      });

      component.handleSuggestionAction('q1', SuggestionActionType.DISMISS, suggestion());
      vi.runAllTimers();

      expect(component.statusMessage()).toBe('Suggestion resolved.');
      expect(focus).toHaveBeenCalledOnce();
    });
  });

  describe('handleFixAll', () => {
    it('does nothing while a fix-all is already running', async () => {
      const { component, questions, surveyService } = setup();
      questions.set([question({ suggestions: [suggestion({ action: 'REMOVE' })] })]);
      component.isApplyingAll.set(true);

      await component.handleFixAll();

      expect(surveyService.removeQuestion).not.toHaveBeenCalled();
    });

    it('does nothing and shows no loader when nothing can be fixed', async () => {
      const { component, questions, validationService } = setup();
      questions.set([
        question({
          suggestions: [
            suggestion({ action: 'REPHRASE', suggestedText: '  ' }),
            suggestion({ suggestionId: 's-2', action: 'REVIEW', severity: 'MANDATORY', suggestedText: '' }),
          ],
        }),
      ]);

      await component.handleFixAll();

      expect(component.isApplyingAll()).toBe(false);
      expect(validationService.rephraseSuggestion).not.toHaveBeenCalled();
      expect(validationService.dismissSuggestion).not.toHaveBeenCalled();
      expect(component.statusMessage()).toBe('');
    });

    it('applies every resolvable suggestion and skips the rest', async () => {
      const { component, questions, validationService } = setup();
      questions.set([
        question({
          id: 'q1',
          suggestions: [
            suggestion({ suggestionId: 'rephrase-q', action: 'REPHRASE', fieldPath: 'question' }),
            suggestion({ suggestionId: 'remove-opt', action: 'REMOVE', fieldPath: 'options[1]', suggestedText: '' }),
            suggestion({ suggestionId: 'add-opt', action: 'ADD_OPTION', fieldPath: 'options[0]' }),
            suggestion({ suggestionId: 'add-no-text', action: 'ADD_OPTION', fieldPath: 'options[3]', suggestedText: '' }),
            suggestion({ suggestionId: 'rephrase-no-text', action: 'REPHRASE', fieldPath: 'options[2]', suggestedText: undefined as unknown as string }),
            suggestion({ suggestionId: 'review-optional', action: 'REVIEW', suggestedText: '' }),
            suggestion({ suggestionId: 'review-mandatory', action: 'REVIEW', severity: 'MANDATORY', suggestedText: '' }),
            suggestion({ suggestionId: 'review-with-text', action: 'REVIEW' }),
            suggestion({ suggestionId: 'unknown', action: 'SOMETHING_NEW' as AiSuggestion['action'] }),
          ],
        }),
        question({
          id: undefined,
          questionNumber: 2,
          suggestions: [suggestion({ suggestionId: 'no-id', action: 'REMOVE' })],
        }),
      ]);

      const promise = component.handleFixAll();
      await vi.advanceTimersByTimeAsync(500);
      await promise;

      const ids = (calls: unknown[][]) => calls.map(call => (call[2] as AiSuggestion).suggestionId);
      expect(ids(validationService.rephraseSuggestion.mock.calls)).toEqual(['rephrase-q']);
      expect(ids(validationService.removeOptionSuggestion.mock.calls)).toEqual(['remove-opt']);
      expect(ids(validationService.applyAddOptionSuggestion.mock.calls)).toEqual(['add-opt']);
      expect(validationService.dismissSuggestion).toHaveBeenCalledWith(
        expect.any(Array),
        'q1',
        'review-optional'
      );
    });

    it('applies higher option indexes first within a question', async () => {
      const { component, questions, validationService } = setup();
      const order: string[] = [];
      validationService.removeOptionSuggestion.mockImplementation((items: QuestionModel[], _id: string, item: AiSuggestion) => {
        order.push(item.fieldPath);
        return items;
      });
      validationService.applyAddOptionSuggestion.mockImplementation((items: QuestionModel[], _id: string, item: AiSuggestion) => {
        order.push(item.fieldPath);
        return items;
      });
      questions.set([
        question({
          suggestions: [
            suggestion({ suggestionId: 'a', action: 'ADD_OPTION', fieldPath: 'options[0]' }),
            suggestion({ suggestionId: 'b', action: 'REMOVE', fieldPath: 'options[2]' }),
            suggestion({ suggestionId: 'c', action: 'REMOVE', fieldPath: 'options[1]' }),
          ],
        }),
      ]);

      const promise = component.handleFixAll();
      await vi.advanceTimersByTimeAsync(500);
      await promise;

      expect(order).toEqual(['options[2]', 'options[1]', 'options[0]']);
    });

    it('treats a missing fieldPath as a non-option path when ordering', async () => {
      const { component, questions, validationService } = setup();
      questions.set([
        question({
          suggestions: [
            suggestion({ suggestionId: 'a', action: 'REMOVE', fieldPath: undefined as unknown as string }),
            suggestion({ suggestionId: 'b', action: 'REMOVE', fieldPath: 'options[0]' }),
          ],
        }),
      ]);

      const promise = component.handleFixAll();
      await vi.advanceTimersByTimeAsync(500);
      await promise;

      expect(validationService.removeOptionSuggestion).toHaveBeenCalledTimes(2);
    });

    it('keeps the loader visible for the minimum time, then hides it', async () => {
      const { component, questions, surveyService } = setup();
      questions.set([question({ suggestions: [suggestion({ action: 'REMOVE' })] })]);

      const promise = component.handleFixAll();
      expect(component.isApplyingAll()).toBe(true);

      await vi.advanceTimersByTimeAsync(0);
      expect(surveyService.removeQuestion).toHaveBeenCalledOnce();
      expect(component.isApplyingAll()).toBe(true);

      await vi.advanceTimersByTimeAsync(499);
      expect(component.isApplyingAll()).toBe(true);

      await vi.advanceTimersByTimeAsync(1);
      await promise;
      expect(component.isApplyingAll()).toBe(false);
    });

    it('announces how many suggestions were applied (singular)', async () => {
      const { component, questions, validationService } = setup();
      validationService.removeOptionSuggestion.mockImplementation((items: QuestionModel[], _id: string, item: AiSuggestion) =>
        items.map(entry => ({
            ...entry,
            suggestions: entry.suggestions?.filter(s => s.suggestionId !== item.suggestionId),
          }))
      );
      questions.set([
        question({
          suggestions: [
            suggestion({ suggestionId: 'removed', action: 'REMOVE', fieldPath: 'options[0]' }),
            suggestion({ suggestionId: 'kept', action: 'REPHRASE', suggestedText: '' }),
          ],
        }),
      ]);

      const promise = component.handleFixAll();
      await vi.advanceTimersByTimeAsync(500);
      await promise;

      expect(component.statusMessage()).toBe('1 suggestion applied.');
    });

    it('uses the plural English fallback', async () => {
      const { component, questions, validationService } = setup();
      validationService.removeOptionSuggestion.mockImplementation((items: QuestionModel[], _id: string, item: AiSuggestion) =>
        items.map(entry => ({
            ...entry,
            suggestions: entry.suggestions?.filter(s => s.suggestionId !== item.suggestionId),
          }))
      );
      questions.set([
        question({
          suggestions: [
            suggestion({ suggestionId: 'one', action: 'REMOVE', fieldPath: 'options[0]' }),
            suggestion({ suggestionId: 'two', action: 'REMOVE', fieldPath: 'options[1]' }),
          ],
        }),
      ]);

      const promise = component.handleFixAll();
      await vi.advanceTimersByTimeAsync(500);
      await promise;

      expect(component.statusMessage()).toBe('2 suggestions applied.');
    });

    it('hides the loader again when applying fails', async () => {
      const { component, questions, validationService } = setup();
      validationService.removeOptionSuggestion.mockImplementation(() => {
        throw new Error('boom');
      });
      questions.set([question({ suggestions: [suggestion({ action: 'REMOVE', fieldPath: 'options[0]' })] })]);

      const promise = component.handleFixAll();
      const assertion = expect(promise).rejects.toThrow('boom');
      await vi.advanceTimersByTimeAsync(0);
      await assertion;

      expect(component.isApplyingAll()).toBe(false);
    });
  });

  describe('getOriginalText', () => {
    it('returns the question text for the question field', () => {
      const { component } = setup();

      expect(component.getOriginalText(question(), 'question')).toBe('How satisfied are you?');
    });

    it.each([
      ['options[1]', 'Medium'],
      ['rowOptions[0]', 'Row 1'],
      ['columnOptions[0]', 'Col 1'],
    ])('returns the original value for %s', (fieldPath, expected) => {
      const { component } = setup();

      expect(component.getOriginalText(question(), fieldPath)).toBe(expected);
    });

    it.each([
      ['npsLeftLabel', 'Not at all likely'],
      ['npsRightLabel', 'Extremely likely'],
    ])('returns the original NPS label for %s', (fieldPath, expected) => {
      const { component } = setup();
      const nps = question({ npsLeftLabel: 'Not at all likely', npsRightLabel: 'Extremely likely' });

      expect(component.getOriginalText(nps, fieldPath)).toBe(expected);
    });

    it.each(['npsLeftLabel', 'npsRightLabel'])(
      'returns an empty string when %s is not set',
      fieldPath => {
        const { component } = setup();

        expect(component.getOriginalText(question(), fieldPath)).toBe('');
      }
    );

    it.each(['options[9]', 'unknown', 'options[a]', undefined as unknown as string])(
      'returns an empty string for %s',
      fieldPath => {
        const { component } = setup();

        expect(component.getOriginalText(question(), fieldPath)).toBe('');
      }
    );

    it('returns an empty string when the list is missing', () => {
      const { component } = setup();

      expect(component.getOriginalText(question({ options: undefined }), 'options[0]')).toBe('');
    });
  });

  describe('closeRequested', () => {
    it('emits when the panel asks to close', () => {
      const { component } = setup();
      const listener = vi.fn();
      component.closeRequested.subscribe(listener);

      component.onCloseRequested();

      expect(listener).toHaveBeenCalledOnce();
    });
  });

  describe('suggestion status panel', () => {
    it('exposes the service suggestion state', () => {
      const { component, validationService } = setup();

      expect(component.surveySuggestionState).toBe(validationService.surveySuggestionState);
      expect(component.suggestionState).toBe(SURVEY_SUGGESTIONS_STATE);

      validationService.surveySuggestionState.set(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
      expect(component.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
    });

    it('provides English fallbacks for the status labels', () => {
      const { component } = setup();

      expect(component.optiqFeedbackActions.changesApplied).toBe('Changes Applied');
      expect(component.optiqFeedbackActions.noSuggestions).toBe('No Suggestions');
      expect(component.optiqFeedbackActions.validationComplete).toBe('Validation is complete');
    });

    describe('rendered template', () => {
      const render = (
        state: string,
        translations: Record<string, string> = {},
        questions: QuestionModel[] = []
      ) => {
        const questionSignal = signal<QuestionModel[]>(questions);
        const surveyService = {
          questions: questionSignal,
          getQuestions: vi.fn(() => questionSignal()),
          setQuestions: vi.fn((items: QuestionModel[]) => questionSignal.set(items)),
          removeQuestion: vi.fn(),
        };
        const validationService = {
          surveyAIValidationState: signal(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW),
          surveySuggestionState: signal(state),
          countSuggestions: vi.fn((items: QuestionModel[], severity: 'MANDATORY' | 'OPTIONAL') =>
            items.reduce(
              (total, item) => total +
                (item.suggestions?.filter(s => s.severity === severity).length ?? 0),
              0
            )
          ),
        };

        TestBed.configureTestingModule({
          imports: [TranslateModule.forRoot()],
          providers: [
            { provide: SurveyService, useValue: surveyService },
            { provide: ValidationService, useValue: validationService },
          ],
        });
        TestBed.overrideComponent(OptiqFeedbackComponent, {
          set: {
            imports: [TranslateModule],
            schemas: [NO_ERRORS_SCHEMA],
            template,
            templateUrl: undefined,
            styleUrl: undefined,
            styles: [],
          },
        });
        TestBed.inject(TranslateService).setTranslation('en', translations);
        TestBed.inject(TranslateService).use('en');

        const fixture = TestBed.createComponent(OptiqFeedbackComponent);
        fixture.detectChanges();
        return { fixture, surveyService, validationService, el: fixture.nativeElement as HTMLElement };
      };

      const text = (el: HTMLElement, selector: string) => el.querySelector(selector)?.textContent?.trim();

      beforeEach(() => {
        vi.useRealTimers();
      });

      it('shows "No Suggestions" when validation returned nothing', () => {
        const { el } = render(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);

        expect(text(el, '.suggestion-status')).toBe('No Suggestions');
        expect(text(el, '.suggestion-sub-status')).toBe('Validation is complete');
        expect(el.querySelector('.sub-header')).toBeNull();
      });

      it('shows "Changes Applied" once every suggestion is resolved', () => {
        const { el } = render(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);

        expect(text(el, '.suggestion-status')).toBe('Changes Applied');
        expect(text(el, '.suggestion-sub-status')).toBe('Validation is complete');
        expect(el.querySelector('.sub-header')).toBeNull();
      });

      it('translates the status labels', () => {
        const { el } = render(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION, {
          'No Suggestions': 'Sin sugerencias',
          'Validation is complete': 'Validación completa',
        });

        expect(text(el, '.suggestion-status')).toBe('Sin sugerencias');
        expect(text(el, '.suggestion-sub-status')).toBe('Validación completa');
      });

      it.each([
        SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION,
        SURVEY_SUGGESTIONS_STATE.ALL_APPLIED,
      ])('keeps the original status message for edited questions in %s', state => {
        const { fixture, surveyService, el } = render(state, {}, [question()]);

        surveyService.questions.set([question({ reviewRequired: true })]);
        fixture.detectChanges();

        expect(text(el, '.suggestion-status')).toBe(
          state === SURVEY_SUGGESTIONS_STATE.ALL_APPLIED ? 'Changes Applied' : 'No Suggestions'
        );
        expect(text(el, '.suggestion-sub-status')).toBe('Validation is complete');
        expect(el.querySelector('.suggestion-status-icon')?.classList.contains('warning')).toBe(false);
      });

      it('shows the suggestion list instead of the status while in review', () => {
        const { el } = render(SURVEY_SUGGESTIONS_STATE.IN_REVIEW, {}, [
          question({ suggestions: [suggestion()] }),
        ]);

        expect(el.querySelector('.suggestion-status')).toBeNull();
        expect(el.querySelector('.sub-header')).not.toBeNull();
        expect(el.querySelectorAll('.suggestion').length).toBe(1);
      });

      it('switches from the list to "Changes Applied" when the state changes', () => {
        const { fixture, surveyService, validationService, el } = render(SURVEY_SUGGESTIONS_STATE.IN_REVIEW, {}, [
          question({ suggestions: [suggestion()] }),
        ]);

        surveyService.questions.set([question()]);
        validationService.surveySuggestionState.set(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
        fixture.detectChanges();

        expect(text(el, '.suggestion-status')).toBe('Changes Applied');
      });
    });
  });
});
