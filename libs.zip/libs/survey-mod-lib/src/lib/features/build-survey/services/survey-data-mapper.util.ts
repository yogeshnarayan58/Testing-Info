import { FLOW_TYPES } from '../../../core/config/config';
import { QuestionModel, QuestionTypes, SurveyStatusType } from '../models/build-survey';
import { toTrimmedString } from './survey-payload.util';

type SavedQuestionDto = {
  type?: unknown;
  required?: unknown;
  prompt?: {
    text?: unknown;
  };
  answerSpec?: {
    options?: Array<{ label?: unknown }>;
    rows?: Array<{ label?: unknown }>;
    columns?: Array<{ label?: unknown }>;
    anchors?: {
      min?: unknown;
      max?: unknown;
    };
  };
};


/**
 * Converts saved API questions into QuestionModel[] for the builder.
 */
export function fromSavedQuestions(savedQuestions: Array<Record<string, unknown>> | undefined | null): QuestionModel[] {
  return (savedQuestions ?? []).map((savedQuestion, index) => fromSavedQuestion(savedQuestion as SavedQuestionDto, index));
}

/**
 * Converts a single saved API question into QuestionModel format.
 */
export function fromSavedQuestion(savedQuestion: SavedQuestionDto, index: number): QuestionModel {
  const type = typeof savedQuestion.type === 'string' ? savedQuestion.type : '';
  const answerSpec = savedQuestion.answerSpec;

  return {
    questionNumber: index + 1,
    question: toTrimmedString(savedQuestion.prompt?.text),
    isRequired: !!savedQuestion.required,
    type,
    options: fromSavedOptionLabels(answerSpec?.options),
    rowOptions: fromSavedOptionLabels(answerSpec?.rows),
    columnOptions: resolveColumnOptions(type, answerSpec),
    npsLeftLabel: toTrimmedString(answerSpec?.anchors?.min),
    npsRightLabel: toTrimmedString(answerSpec?.anchors?.max),
  };
}

/**
 * Resolves column options based on question type, accounting for single-point scale special case.
 */
export function resolveColumnOptions(
  type: string,
  answerSpec: SavedQuestionDto['answerSpec'] | undefined,
): string[] {
  if (type === QuestionTypes.SinglePointScale) {
    // Single-point scale drafts currently persist their selectable values in `options`.
    // Restoring them into `columnOptions` lets the editor continue from the saved shape.
    return fromSavedOptionLabels(answerSpec?.columns ?? answerSpec?.options);
  }

  return fromSavedOptionLabels(answerSpec?.columns);
}

/**
 * Extracts and trims option labels from saved question format.
 */
export function fromSavedOptionLabels(options: Array<{ label?: unknown }> | undefined): string[] {
  return (options ?? [])
    .map((option) => toTrimmedString(option?.label))
    .filter(Boolean);
}

/**
 * Merges saved request instance and existing dataset config into a unified draft config.
 */
export function buildDraftDatasetConfig(
  requestInstance: any,
  existingDatasetConfig: any,
): any {
  if (!requestInstance && !existingDatasetConfig) {
    return null;
  }

  return {
    ...existingDatasetConfig,
    id: requestInstance?.['datasetId'] ?? existingDatasetConfig?.['id'] ?? '',
    title: requestInstance?.['datasetLabel'] ?? existingDatasetConfig?.['title'] ?? existingDatasetConfig?.['label'] ?? '',
    label: requestInstance?.['datasetLabel'] ?? existingDatasetConfig?.['label'] ?? existingDatasetConfig?.['title'] ?? '',
    stackId: requestInstance?.['datasetStackId'] ?? existingDatasetConfig?.['stackId'] ?? '',
    datasetDefaultLocale: requestInstance?.['locale'] ?? existingDatasetConfig?.['datasetDefaultLocale'] ?? '',
    productOfferingCode: requestInstance?.['productOfferingCode'] ?? existingDatasetConfig?.['productOfferingCode'] ?? '',
    dataView: {
      ...existingDatasetConfig?.['dataView'],
      dataViewId: requestInstance?.['dataViewId'] ?? existingDatasetConfig?.['dataView']?.['dataViewId'] ?? '',
      dataViewName: requestInstance?.['dataViewName'] ?? existingDatasetConfig?.['dataView']?.['dataViewName'] ?? '',
    },
  };
}

/**
 * Resolves the launch URL based on the current flow type.
 */
export function resolveLaunchUrlByFlow(flowType: (keyof typeof FLOW_TYPES) | Record<string, boolean> | undefined, surveyId: string, status: string): string {
    let flowFlags: Record<string, boolean> = {};

    if (typeof flowType === 'object' && flowType !== null) {
        flowFlags = flowType;
    }

    return `survey${flowFlags[FLOW_TYPES.AIFLOW] ? '/aiflow' : ''}${status === SurveyStatusType.DRAFT ? '/build-survey' : '/results'}/${surveyId}`;
}

/**
 * Extracts existing question texts from a list to use as exclusions for AI generation.
 */
export function getExistingQuestionsTitle(questions: QuestionModel[]): Array<{ text: string }> {
  return questions
    .filter((question) => !!question.question?.trim())
    .map((question) => ({ text: question.question.trim() }));
}
