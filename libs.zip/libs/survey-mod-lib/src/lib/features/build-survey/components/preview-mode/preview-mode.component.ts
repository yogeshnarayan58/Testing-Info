import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import { DOCUMENT } from '@angular/common';
import { afterNextRender, ChangeDetectionStrategy, Component, computed, DestroyRef, effect, ElementRef, HostListener, inject, Injector, input, model, signal, viewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  ButtonModule,
  IconButtonModule,
  IconModule,
  TagModule,
  TooltipModule,
} from '@nielseniq/athena-core';
import { finalize } from 'rxjs';
import { QuestionModel, SuggestionTag, SUGGESTION_SEVERITY } from '../../models/build-survey';

import { isChoiceType, isQuestionValid, isScaleType, normalizeRephrasedQuestion } from '../../services/survey-question.util';
import { SurveyService } from '../../services/survey.service';
import { ValidationService } from '../../services/validation.service';
import { QuestionEditorComponent } from '../question-editor/question-editor.component';
import { QuestionTypeListComponent } from '../question-type-list/question-type-list.component';
import { RepromptActionsComponent } from './../../../../shared/components/reprompt-actions/reprompt-actions.component';
import { SurveyCommonService } from './../../../../shared/services/survey-common.service';
import { ADD_MORE_QUESTIONS_DEFAULT_COUNT, MAX_SURVEY_QUESTIONS, QuestionType, QuestionTypes, RephraseQuestionsPayload } from './../../models/build-survey';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SurveyExceptionHandlingService } from '../../../../shared/services/survey-exception-handling.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'survey-preview-mode',
  imports: [IconModule, ButtonModule, IconButtonModule, TagModule, TooltipModule, QuestionTypeListComponent, QuestionEditorComponent, DragDropModule, RepromptActionsComponent, TranslateModule],
  providers: [TranslateService],
  standalone: true,
  templateUrl: './preview-mode.component.html',
  styleUrls: ['./preview-mode.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class PreviewModeComponent {

  private readonly injector = inject(Injector);
  private readonly destroyRef = inject(DestroyRef);
  private readonly document = inject(DOCUMENT);
  private readonly exceptionHandlingService = inject(SurveyExceptionHandlingService);
  private readonly repromptActionsPanel = viewChild<ElementRef<HTMLElement>>('repromptActionsPanel');
  private readonly previewContainer = viewChild<ElementRef<HTMLElement>>('previewContainer');

  selectedType = input<QuestionType | ''>('');
  questionTypes = input<QuestionType[]>([]);

  questions = signal<QuestionModel[]>([]);

  showQuestionTypeList = false;

  pendingNewType = signal<QuestionType | ''>('');
  newQuestionData = signal<Partial<QuestionModel>>({});

  newQuestionDataModel = computed(() => {
    const type = this.pendingNewType();
    const data = this.newQuestionData();
    if (!type) return null;
    return {
      questionNumber: 0,
      type,
      question: data.question ?? '',
      options: data.options?.length ? data.options : ['', ''],
      isRequired: data.isRequired ?? false,
      npsLeftLabel: type === QuestionTypes.NetPromoterScore ? data.npsLeftLabel : '',
      npsRightLabel: type === QuestionTypes.NetPromoterScore ? data.npsRightLabel : '',
      rowOptions: data.rowOptions?.length ? data.rowOptions : type === QuestionTypes.StarRating ? [''] : ['', ''],
      columnOptions: data.columnOptions?.length ? data.columnOptions : ['', ''],
    } as QuestionModel;
  });

  hoveredQuestionIndex: number | null = null;
  rephraseOpenIndex: number | null = null;
  rephraseErrorIndex = signal<number | null>(null);
  rephrasePrompts: Record<number, string> = {};
  rephraseLoadingIndex: number | null = null;
  private currentEditingIndex: number | null = null;
  get editingIndex(): number | null {
    return this.currentEditingIndex;
  }
  set editingIndex(index: number | null) {
    this.currentEditingIndex = index;
    this.syncEditingState();
  }
  readonly invalidEditingIndex = signal<number | null>(null);
  readonly newQuestionValidationAttempted = signal(false);
  suggestNewQuestionsLoading = signal(false);
  showRepromptPanel = model<boolean>(false);
  repromptPrompt = model<string>('');

  isAtMaxQuestions = computed(() => this.questions().length >= MAX_SURVEY_QUESTIONS);

  constructor(
    public surveyService: SurveyService,
    public surveyCommonService: SurveyCommonService,
    private translate: TranslateService,
    private readonly validationService: ValidationService
  ) {
    effect(() => {
      this.questions.set(this.surveyService.questions());
    });

    let previousPendingType: QuestionType | '' | undefined;
    effect(() => {
      const pendingType = this.pendingNewType();
      if (pendingType !== previousPendingType) {
        previousPendingType = pendingType;
        this.newQuestionValidationAttempted.set(false);
        this.newQuestionData.set({});
      }
      this.syncEditingState();
    });

    this.destroyRef.onDestroy(() => this.surveyService.isEditingQuestion.set(false));

    // Close all dialogs when max questions limit is reached
    effect(() => {
      if (this.isAtMaxQuestions()) {
        this.showQuestionTypeList = false;
        this.cancelNewQuestion();
        this.showRepromptPanel.set(false);
      }
    });
  }

  /** Lets the rest of the screen know whether a question is currently open for editing or being added. */
  private syncEditingState(): void {
    this.surveyService.isEditingQuestion.set(this.currentEditingIndex !== null || !!this.pendingNewType());
  }

  private markQuestionForReview(index: number): void {
    this.surveyService.setQuestions(
      this.validationService.markQuestionForReview(this.surveyService.getQuestions(), index)
    );
    this.validationService.invalidateSurveyValidation();
  }

  /** Block switching edited rows until the current draft is valid to prevent silent loss of in-progress edits. */
  selectQuestion(newIndex: number): void {
    if (!this.resolvePendingNewQuestion()) {
      return;
    }

    if (this.editingIndex === newIndex) {
      this.closePopupPanels();
      return;
    }

    if (this.editingIndex !== null && !this.commitQuestionDraft(this.editingIndex)) {
      return;
    }

    this.editingIndex = newIndex;
    this.invalidEditingIndex.set(null);
    this.closePopupPanels();
  }

  private closePopupPanels(): void {
    this.showQuestionTypeList = false;
    this.showRepromptPanel.set(false);
    this.rephraseOpenIndex = null;
  }

  private mergeQuestionDraft(current: QuestionModel, draft?: Partial<QuestionModel>): QuestionModel {
    const next = { ...current, ...(draft ?? {}) };
    if (next.type === QuestionTypes.NetPromoterScore) {
      if (!next.npsLeftLabel?.trim()) {
        next.npsLeftLabel = this.translate.instant('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND');
      }
      if (!next.npsRightLabel?.trim()) {
        next.npsRightLabel = this.translate.instant('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND');
      }
    }
    return next;
  }

  /** Merges a question draft into its saved state when valid, returning whether editing may continue. */
  private commitQuestionDraft(index: number): boolean {
    const questions = this.surveyService.getQuestions();
    const current = questions[index];
    const draft = this.surveyService.getDraft(index);

    if (!current) {
      this.surveyService.clearDraft(index);
      return true;
    }

    const next = this.mergeQuestionDraft(current, draft);

    if (!this.hasQuestionInput(next) || !isQuestionValid(next)) {
      this.invalidEditingIndex.set(index);
      return false;
    }

    if (!draft) {
      if (next.npsLeftLabel !== current.npsLeftLabel || next.npsRightLabel !== current.npsRightLabel) {
        const updated = [...questions];
        updated[index] = next;
        this.surveyService.setQuestions(updated);
      }
      this.surveyService.clearDraft(index);
      this.invalidEditingIndex.set(null);
      return true;
    }

    const updated = [...questions];
    updated[index] = next;
    this.surveyService.setQuestions(updated);
    this.surveyService.clearDraft(index);
    this.invalidEditingIndex.set(null);
    this.markQuestionForReview(index);
    return true;
  }

  editQuestion(index: number): void {
    this.selectQuestion(index);
  }

  asQuestionType(type: string): QuestionType {
    return type as QuestionType;
  }

  /** Type changes reset shape-specific fields to keep payloads schema-valid for the selected question type. */
  changeQuestionType(index: number, type: QuestionType | ''): void {
    if (!type) return;
    const questions = this.surveyService.getQuestions();
    const current = questions[index];
    if (!current || current.type === type) return;

    const updated = [...questions];
    updated[index] = {
      ...current,
      type,
      reviewRequired: true,
      options: isChoiceType(type) ? (current.options?.length ? [...current.options] : ['', '']) : [],
      rowOptions: type === QuestionTypes.StarRating
        ? ['']
        : isScaleType(type) ? (current.rowOptions?.length ? [...current.rowOptions] : ['', '']) : [],
      columnOptions: isScaleType(type) ? (current.columnOptions?.length ? [...current.columnOptions] : ['', '']) : [],
      npsLeftLabel: type === QuestionTypes.NetPromoterScore ? (current.npsLeftLabel || this.translate.instant('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND')) : '',
      npsRightLabel: type === QuestionTypes.NetPromoterScore ? (current.npsRightLabel || this.translate.instant('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND')) : '',
    };
    this.surveyService.clearDraft(index);
    this.surveyService.setQuestions(updated);
    if (this.invalidEditingIndex() === index) {
      this.invalidEditingIndex.set(null);
    }
    this.validationService.invalidateSurveyValidation();
  }

  /** Store invalid edits as drafts so users can recover partial work without committing broken question state. */
  onQuestionEditorDataChange(index: number, data: Partial<QuestionModel>) {
    const questions = this.surveyService.getQuestions();
    const current = questions[index];

    if (!current) {
      return;
    }

    const draft = { ...this.surveyService.getDraft(index), ...this.sanitizeQuestionData(data) };
    this.surveyService.saveDraft(index, draft);
    if (this.invalidEditingIndex() === index && isQuestionValid(this.mergeQuestionDraft(current, draft))) {
      this.invalidEditingIndex.set(null);
    }
  }

  saveQuestionChanges(index: number): void {
    if (!this.resolvePendingNewQuestion()) {
      return;
    }
    this.closePopupPanels();
    if (!this.commitQuestionDraft(index)) {
      return;
    }
    this.editingIndex = null;
  }

  discardQuestionChanges(index: number): void {
    if (!this.resolvePendingNewQuestion()) {
      return;
    }
    this.closePopupPanels();
    this.surveyService.clearDraft(index);
    this.editingIndex = null;
    this.invalidEditingIndex.set(null);
  }

  /** Restrict persisted draft fields to supported editor inputs to avoid stale/foreign properties in local state. */
  private sanitizeQuestionData(data: Partial<QuestionModel>): Partial<QuestionModel> {
    return {
      ...(typeof data.question === 'string' && { question: data.question }),
      ...(Array.isArray(data.options) && { options: data.options.map(o => o ?? '') }),
      ...(Array.isArray(data.rowOptions) && { rowOptions: data.rowOptions.map(r => r ?? '') }),
      ...(Array.isArray(data.columnOptions) && { columnOptions: data.columnOptions.map(c => c ?? '') }),
      ...(typeof data.npsLeftLabel === 'string' && { npsLeftLabel: data.npsLeftLabel }),
      ...(typeof data.npsRightLabel === 'string' && { npsRightLabel: data.npsRightLabel }),
      ...(typeof data.isRequired === 'boolean' && { isRequired: data.isRequired }),
    };
  }

  setHoveredQuestion(index: number) {
    this.hoveredQuestionIndex = index;
  }

  clearHoveredQuestion() {
    this.hoveredQuestionIndex = null;
  }

  /** Keep one rephrase popover open at a time to avoid overlapping async intents per question. */
  toggleRephrase(index: number, event: MouseEvent) {
    event.stopPropagation();
    const opening = this.rephraseOpenIndex !== index;
    if (opening && !this.resolvePendingNewQuestion()) {
      return;
    }
    this.rephraseOpenIndex = opening ? index : null;
    this.rephraseErrorIndex.set(null);
    if (opening) {
      this.showQuestionTypeList = false;
      this.showRepromptPanel.set(false);
    }
    if (this.rephraseOpenIndex !== null && typeof this.rephrasePrompts[index] !== 'string') {
      this.rephrasePrompts[index] = '';
    }
  }

  toggleQuestionTypeList(): void {
    const opening = !this.showQuestionTypeList;
    if (!opening && !this.resolvePendingNewQuestion()) {
      return;
    }
    this.showQuestionTypeList = opening;
    if (opening) {
      if (!this.pendingNewType()) {
        this.newQuestionValidationAttempted.set(false);
        this.newQuestionData.set({});
      }
      this.rephraseOpenIndex = null;
      this.showRepromptPanel.set(false);
    }
  }

  /** Resolve an inline add draft before another action can hide its editor. */
  private resolvePendingNewQuestion(): boolean {
    if (!this.pendingNewType()) {
      return true;
    }

    if (this.isNewQuestionValid()) {
      this.saveNewQuestion();
      return !this.pendingNewType();
    }

    if (this.hasQuestionInput(this.newQuestionData())) {
      this.newQuestionValidationAttempted.set(true);
      return false;
    }

    this.cancelNewQuestion();
    return true;
  }

  onRephrasePromptChange(index: number, value: string) {
    this.rephrasePrompts[index] = value;
    if (this.rephraseErrorIndex() === index) {
      this.rephraseErrorIndex.set(null);
    }
  }

  /** New-question flow starts from a clean draft per type to prevent cross-type editor data leakage. */
  onAddAnotherQuestion(type: QuestionType) {
    this.newQuestionValidationAttempted.set(false);
    this.pendingNewType.set(type);
    this.newQuestionData.set({});
  }

  onNewEditorDataChange(data: Partial<QuestionModel>) {
    const current = this.newQuestionData();
    this.newQuestionData.set({ ...current, ...data });
  }

  isNewQuestionValid = computed(() => {
    const type = this.pendingNewType();
    if (!type) return false;

    const data = this.newQuestionData();
    return isQuestionValid({
      ...data,
      question: data.question ?? '',
      type,
      npsLeftLabel: type === QuestionTypes.NetPromoterScore ? (data.npsLeftLabel ?? this.translate.instant('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND')) : '',
      npsRightLabel: type === QuestionTypes.NetPromoterScore ? (data.npsRightLabel ?? this.translate.instant('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND')) : '',
    });
  });

  saveNewQuestion() {
    this.newQuestionValidationAttempted.set(true);
    if (!this.pendingNewType() || !this.isNewQuestionValid() || this.isAtMaxQuestions()) {
      return;
    }
    const newData = this.newQuestionData();
    const type = this.pendingNewType() as QuestionType;
    const question: QuestionModel = {
      questionNumber: this.surveyService.getQuestions().length + 1,
      type,
      question: newData.question ?? '',
      reviewRequired: true,
      options: newData.options ?? [],
      isRequired: newData.isRequired ?? false,
      npsLeftLabel: type === QuestionTypes.NetPromoterScore ? (newData.npsLeftLabel ?? this.translate.instant('SURVEYMOD_NPS_LEFT_LABEL_I_WILL_DEFINITELY_NOT_RECOMMEND')) : '',
      npsRightLabel: type === QuestionTypes.NetPromoterScore ? (newData.npsRightLabel ?? this.translate.instant('SURVEYMOD_RIGHT_NPS_LABEL_I_WILL_DEFINITELY_RECOMMEND')) : '',
      rowOptions: newData.rowOptions ?? [],
      columnOptions: newData.columnOptions ?? [],
    };
    this.surveyService.addQuestion(question);
    this.cancelNewQuestion();
    this.validationService.invalidateSurveyValidation();
  }

  /** Explicit cancel clears pending inline-editor state so outside-click autosave does not run stale data. */
  cancelNewQuestion() {
    this.newQuestionValidationAttempted.set(false);
    this.pendingNewType.set('');
    this.newQuestionData.set({});
  }

  inlineEditorContainer = viewChild<ElementRef<HTMLElement>>('inlineEditorContainer');

  /** Document-level click handling coordinates draft validation, rephrase popovers, and inline add flows. */
  @HostListener('document:click', ['$event'])
  closeOnOutsideClick(event: MouseEvent) {
    const path = event.composedPath?.() ?? [];
    const targetEl = event.target instanceof Element ? event.target : null;
    const clickedInsideQuestionRow = !!targetEl?.closest('.question-row') ||
      path.some(node => node instanceof Element && node.classList.contains('question-row'));
    const clickedInsideRephrase = !!targetEl?.closest('.rephrase-wrap') ||
      path.some(node => node instanceof Element && node.classList.contains('rephrase-wrap'));

    if (this.rephraseOpenIndex !== null && !clickedInsideRephrase) {
      this.rephraseOpenIndex = null;
    }

    if (this.editingIndex !== null && !clickedInsideQuestionRow) {
      if (!this.commitQuestionDraft(this.editingIndex)) {
        return;
      }
      this.editingIndex = null;
    }

    // New logic: auto-save inline editor if click is outside
    const hasPendingType = !!this.pendingNewType();

    if (!hasPendingType) {
      return;
    }

    const target = event.target as Node | null;
    const isInsideEditorContainer = !!target && this.inlineEditorContainer()?.nativeElement?.contains(target);
    const isInsideEditorPath = path.some(node => node === this.inlineEditorContainer()?.nativeElement);
    const isInsideEditor = isInsideEditorContainer || isInsideEditorPath;

    const isInsideTypeList = !!targetEl?.closest('.question-type-wrapper') ||
      path.some(node => node instanceof Element && node.classList.contains('question-type-wrapper'));


    if (!isInsideEditor && !isInsideTypeList) {
      queueMicrotask(() => {
        if (this.destroyRef.destroyed) {
          return;
        }
        const isValid = this.isNewQuestionValid();
        if (isValid) {
          this.saveNewQuestion();
        } else {
          if (this.hasQuestionInput(this.newQuestionData())) {
            this.newQuestionValidationAttempted.set(true);
          } else {
            this.cancelNewQuestion();
          }
        }
      });
    }
  }

  /** Detect whether an existing question draft contains any input. */
  private hasQuestionInput(question: Partial<QuestionModel>): boolean {
    const questionText = question.question?.trim();
    const options = question.options ?? [];
    const rowOptions = question.rowOptions ?? [];
    const columnOptions = question.columnOptions ?? [];

    return !!questionText ||
      options.some(option => !!option?.trim()) ||
      rowOptions.some(row => !!row?.trim()) ||
      columnOptions.some(column => !!column?.trim()) ||
      question.isRequired === true ||
      !!question.npsLeftLabel?.trim() ||
      !!question.npsRightLabel?.trim();
  }

  /** Re-index rephrase UI state after deletion so prompts and loading markers continue to match rows. */
  private remapRephraseStateAfterDelete(deletedIndex: number) {
    const remappedPrompts: Record<number, string> = {};
    Object.entries(this.rephrasePrompts).forEach(([indexKey, prompt]) => {
      const index = Number(indexKey);
      if (!Number.isNaN(index)) {
        const newIndex = this.surveyService.remapIndexAfterDelete(index, deletedIndex);
        if (newIndex !== null) remappedPrompts[newIndex] = prompt;
      }
    });
    this.rephrasePrompts = remappedPrompts;
    this.rephraseOpenIndex = this.surveyService.remapIndexAfterDelete(this.rephraseOpenIndex, deletedIndex);
    this.rephraseLoadingIndex = this.surveyService.remapIndexAfterDelete(this.rephraseLoadingIndex, deletedIndex);
  }

  /** Remove uses shared remapping utilities to keep editor, rephrase, and question arrays in sync. */
  deleteQuestion(index: number) {
    if (!this.resolvePendingNewQuestion()) {
      return;
    }
    this.closePopupPanels();
    this.editingIndex = this.surveyService.remapIndexAfterDelete(this.editingIndex, index);
    this.invalidEditingIndex.set(this.surveyService.remapIndexAfterDelete(this.invalidEditingIndex(), index));
    this.remapRephraseStateAfterDelete(index);
    this.surveyService.removeQuestion(index);
    this.validationService.syncAfterSuggestionChange(this.surveyService.getQuestions());
  }

  /** Rephrase sends a normalized full question payload because the API expects complete question context. */
  rephraseQuestion(index: number) {
    if (this.rephraseLoadingIndex === index) return;
    const currentQuestion = this.surveyService.getQuestions()[index];
    if (!currentQuestion) return;

    this.rephraseLoadingIndex = index;
    if (this.rephraseErrorIndex() === index) {
      this.rephraseErrorIndex.set(null);
    }
    const questionPayload: RephraseQuestionsPayload['question'] = {
      isRequired: currentQuestion.isRequired ?? false,
      question: currentQuestion.question ?? '',
      questionNumber: currentQuestion.questionNumber ?? index + 1,
      type: currentQuestion.type as QuestionType,
      options: currentQuestion.options ?? [],
      rowOptions: currentQuestion.rowOptions ?? [],
      columnOptions: currentQuestion.columnOptions ?? [],
      npsLeftLabel: currentQuestion.npsLeftLabel ?? '',
      npsRightLabel: currentQuestion.npsRightLabel ?? '',
      id: currentQuestion.id ?? undefined,
    };

    this.surveyService.rephraseQuestions({ question: questionPayload, userPrompt: (this.rephrasePrompts[index] ?? '').trim() }).pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => { this.rephraseLoadingIndex = null; })
    ).subscribe({
      next: (response) => {
        const updatedQuestions = [...this.surveyService.getQuestions()];
        const liveIndex = updatedQuestions.findIndex((question) =>
          currentQuestion.id
            ? question.id === currentQuestion.id
            : question === currentQuestion
        );
        if (liveIndex === -1) {
          // Rephrase response ignored because the original question is no longer available.
          return;
        }
        const liveQuestion = updatedQuestions[liveIndex];
        const normalized = normalizeRephrasedQuestion(response, liveQuestion, liveIndex);
        if (!normalized) {
          this.rephraseErrorIndex.set(liveIndex);
          return;
        }
        updatedQuestions[liveIndex] = {
          ...normalized,
          id: liveQuestion.id,
          suggestions: liveQuestion.suggestions,
        };
        this.surveyService.setQuestions(updatedQuestions);
        if (this.rephraseErrorIndex() === liveIndex) {
          this.rephraseErrorIndex.set(null);
        }
        this.rephrasePrompts[liveIndex] = '';
        this.rephraseOpenIndex = null;
        this.markQuestionForReview(liveIndex);

      },
      error: (err: HttpErrorResponse) => {
          this.exceptionHandlingService.handleApiError(err);
      }
    });
  }

  copyQuestion(index: number) {
    if (!this.resolvePendingNewQuestion()) {
      return;
    }
    this.closePopupPanels();
    const questions = this.surveyService.getQuestions();
    const currentQuestion = questions[index];

    if (!currentQuestion) {
      return;
    }

    const duplicatedQuestion: QuestionModel = {
      questionNumber: questions.length + 1,
      type: currentQuestion.type,
      question: currentQuestion.question,
      reviewRequired: true,
      options: [...(currentQuestion.options ?? [])],
      rowOptions: [...(currentQuestion.rowOptions ?? [])],
      columnOptions: [...(currentQuestion.columnOptions ?? [])],
      npsLeftLabel: currentQuestion.npsLeftLabel ?? '',
      npsRightLabel: currentQuestion.npsRightLabel ?? '',
      isRequired: currentQuestion.isRequired ?? false,
    };

    const updatedQuestions = [
      ...questions.map((question, questionIndex) =>
        questionIndex === index ? { ...question, reviewRequired: true } : question
      ),
      duplicatedQuestion,
    ];
    this.surveyService.setQuestions(updatedQuestions);
    this.validationService.invalidateSurveyValidation();
  }

  /** Suggest New questions api call with suggestion count capped by remaining capacity so backend additions never exceed survey limits. */
  suggestNewQuestions(event: MouseEvent) {
    event.stopPropagation();
    if (!this.resolvePendingNewQuestion()) {
      return;
    }
    this.closePopupPanels();
    const remainingCapacity = MAX_SURVEY_QUESTIONS - this.questions().length;
    if (remainingCapacity <= 0) {
      return;
    }

    const promptSelections = this.surveyCommonService.getPanelistDimensionalValue();
    const userPrompt = this.surveyCommonService.getUserPrompt();

    const payload = this.surveyService.buildAddMoreQuestionsPayload(
      userPrompt,
      this.questionTypes(),
      promptSelections,
      Math.min(ADD_MORE_QUESTIONS_DEFAULT_COUNT, remainingCapacity)
    );

    this.suggestNewQuestionsLoading.set(true);
    this.surveyService.addMoreQuestions(payload)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.suggestNewQuestionsLoading.set(false))
      )
      .subscribe({
        next: (response) => {
          if (response.result.length) {
            this.validationService.invalidateSurveyValidation();
            const firstNewIndex = this.surveyService.getQuestions().length - response.result.length;
            afterNextRender(() => {
              const container = this.previewContainer()?.nativeElement;
              if (!container) {
                return;
              }
              const firstNewRow = container.querySelectorAll<HTMLElement>('.questions-drop-zone > .question-row')[firstNewIndex];
              if (firstNewRow) {
                firstNewRow.scrollIntoView({ block: 'start', behavior: this.getScrollBehavior() });
              } else {
                container.scrollTo({ top: container.scrollHeight, behavior: this.getScrollBehavior() });
              }
            }, { injector: this.injector });
          }
        },
        error: (err) => {
          this.exceptionHandlingService.handleApiError(err);
        }
      });
  }

  /** Opening reprompt resets text to avoid sending stale prompt intent from prior attempts. */
  toggleRepromptPanel(): void {
    const nextPanelState = !this.showRepromptPanel();
    if (nextPanelState && !this.resolvePendingNewQuestion()) {
      return;
    }
    this.showRepromptPanel.set(nextPanelState);

    if (nextPanelState) {
      this.showQuestionTypeList = false;
      this.rephraseOpenIndex = null;
      this.repromptPrompt.set('');
      afterNextRender(() => {
        if (this.showRepromptPanel()) {
          const panel = this.repromptActionsPanel();
          panel?.nativeElement.scrollIntoView({ block: 'nearest', behavior: this.getScrollBehavior() });
        }
      }, { injector: this.injector });
    }
  }

  private getScrollBehavior(): ScrollBehavior {
    const motionPreference = this.document.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)');
    return motionPreference?.matches === false ? 'smooth' : 'auto';
  }

  // Submits the user prompt to add more questions and updates the survey state
  submitReprompt() {
    const remainingCapacity = MAX_SURVEY_QUESTIONS - this.questions().length;
    if (remainingCapacity <= 0) {
      return;
    }

    const promptText = this.repromptPrompt().trim();
    if (!promptText) return;

    this.surveyService.submitAddMoreQuestions(
      promptText,
      this.questionTypes(),
      this.surveyCommonService.getPanelistDimensionalValue(),
      Math.min(ADD_MORE_QUESTIONS_DEFAULT_COUNT, remainingCapacity)
    ).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (response) => {
        this.repromptPrompt.set('');
        this.showRepromptPanel.set(false);
        // An empty result adds nothing, so there is nothing to revalidate.
        if (response.result.length) {
          this.validationService.invalidateSurveyValidation();
        }
      },
      error: (err) => {
        this.exceptionHandlingService.handleApiError(err);
      }
    });
  }

  /** Reorder remaps index-based UI state to preserve row-to-state alignment across drafts and rephrase state. */
  drop(event: CdkDragDrop<QuestionModel[]>) {
    if (event.previousIndex === event.currentIndex) return;
    const questions = [...this.surveyService.getQuestions()];
    moveItemInArray(questions, event.previousIndex, event.currentIndex);
    this.surveyService.setQuestions(questions);

    const remapIdx = (i: number | null): number | null =>
      i === null ? null : this.surveyService.remapIndexAfterReorder(i, event.previousIndex, event.currentIndex);

    if (this.editingIndex !== null) this.editingIndex = remapIdx(this.editingIndex) ?? null;
    this.invalidEditingIndex.set(remapIdx(this.invalidEditingIndex()));
    this.surveyService.remapDraftsAfterReorder(event.previousIndex, event.currentIndex);
    this.rephraseLoadingIndex = remapIdx(this.rephraseLoadingIndex);

    const remappedPrompts: Record<number, string> = {};
    Object.entries(this.rephrasePrompts).forEach(([indexKey, prompt]) => {
      const index = Number(indexKey);
      if (!Number.isNaN(index)) {
        const newIndex = remapIdx(index);
        if (newIndex !== null) remappedPrompts[newIndex] = prompt;
      }
    });
    this.rephrasePrompts = remappedPrompts;
    this.rephraseOpenIndex = null;
    this.hoveredQuestionIndex = null;
  }

  /**
 * Calculates the mandatory and optional suggestion counts for a question.
 * Indicates whether the question has no suggestions when both counts are zero.
 */
  getSuggestionCounts(question: QuestionModel): SuggestionTag {
    const suggestions = question.suggestions ?? [];
    const mandatoryCount = suggestions.filter(
      suggestion => suggestion.severity === SUGGESTION_SEVERITY.MANDATORY
    ).length;

    const optionalCount = suggestions.filter(
      suggestion => suggestion.severity === SUGGESTION_SEVERITY.OPTIONAL
    ).length;

    return {
      mandatoryCount,
      optionalCount,
    };
  }
}
