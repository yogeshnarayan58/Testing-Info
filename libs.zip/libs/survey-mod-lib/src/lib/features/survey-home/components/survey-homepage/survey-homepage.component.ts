import { Component, ChangeDetectionStrategy, CUSTOM_ELEMENTS_SCHEMA, DestroyRef, inject, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { 
  CardModule, 
  IconModule, 
  ButtonModule
} from '@nielseniq/athena-core';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyAssetApiService } from '../../../my-assets/services/survey-asset-api.service';
import { FEATURE_CARDS, HELP_ITEMS, QUICK_SURVEY_CARDS, PREBUILT_SURVEYS, SURVEY_CREDITS, SURVEY_CREDITS_NO_USAGE, Survey, SURVEY_PREVIEW_RESPONSE_COUNTS, DEFAULT_RESPONSE_COUNT, SURVEY_HOME_FETCH_LIMIT, PRIORITY_ORDER, ASSET_TYPES } from '../../models/survey-home';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize } from 'rxjs';
import { SURVEY_STATUS_DISPLAY, SurveyStatusVariant } from '../../../my-assets/constants/survey-status.constant';
import { SurveyStatusType } from '../../../build-survey/models/build-survey';

@Component({
  selector: 'survey-mod-survey-homepage',
  standalone: true,
  imports: [CommonModule, CardModule, IconModule, ButtonModule,],
  templateUrl: './survey-homepage.component.html',
  styleUrls: ['./survey-homepage.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SurveyHomepageComponent implements OnInit {
  private readonly router = inject(Router);
  private readonly surveyCommonService = inject(SurveyCommonService);
  private readonly surveyAssetApi = inject(SurveyAssetApiService);
  private readonly destroyRef = inject(DestroyRef);

  readonly surveys = signal<Survey[]>([]);
  readonly isLoadingSurveys = signal(false);
  readonly isLoadingError = signal(false);
  readonly loadedSuccessfully = signal(false);
  readonly surveyTotalCount = signal(0);
  readonly features = FEATURE_CARDS;
  readonly helpItems = HELP_ITEMS;
  readonly quickSurveyCards = QUICK_SURVEY_CARDS;
  readonly prebuiltSurveys = PREBUILT_SURVEYS;
  readonly isNewUser = computed(() => 
    this.loadedSuccessfully() && 
    this.surveys().length === 0 && 
    this.surveyTotalCount() === 0
  );
  readonly surveyCredits = computed(() =>
    this.isNewUser()
      ? SURVEY_CREDITS_NO_USAGE
      : SURVEY_CREDITS
  );

  ngOnInit(): void {
    this.loadSurveys();
  }

  private loadSurveys(): void {
    this.isLoadingSurveys.set(true);
    this.isLoadingError.set(false);
    this.loadedSuccessfully.set(false);
    
    this.surveyAssetApi.fetchSurveyAssets(0, SURVEY_HOME_FETCH_LIMIT)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.isLoadingSurveys.set(false))
      )
      .subscribe({
        next: (response) => {
          const surveys = this.filterSurveys(response.assets || []);
          const grouped = this.groupSurveysByStatus(surveys);
          const mapped = this.mapGroupedSurveys(grouped);
          this.surveys.set(mapped);
          this.surveyTotalCount.set(response.totalCount || 0);
          this.loadedSuccessfully.set(true);
        },
        error: () => {
          this.isLoadingError.set(true);
        }
      });
  }

  private filterSurveys(assets: any[]): any[] {
    return assets.filter(
      (asset: any) =>
        asset.assetType !== ASSET_TYPES.DISCOVER_FOLDER &&
        asset.assetType !== ASSET_TYPES.DISCOVER_SHARED_FOLDER
    );
  }

  private groupSurveysByStatus(surveys: any[]): { [key: string]: any } {
    const grouped: { [key: string]: any } = {};
    for (const asset of surveys) {
      const status = (asset.status || 'DRAFT').toUpperCase() as SurveyStatusType;
      const normalized = this.normalizeStatusInternal(status);
      if (!grouped[normalized]) {
        grouped[normalized] = asset;
      }
    }
    return grouped;
  }

  private mapGroupedSurveys(grouped: { [key: string]: any }): Survey[] {
    const responseCounts = SURVEY_PREVIEW_RESPONSE_COUNTS;

    return PRIORITY_ORDER
      .map((status) => grouped[status])
      .filter((asset) => asset !== undefined)
      .map((asset: any, index: number) =>
        this.transformAssetToSurvey(asset, responseCounts[index])
      );
  }

  private transformAssetToSurvey(asset: any, responseCount?: string): Survey {
    const statusMapping = this.mapStatus(asset.status || 'DRAFT');
    const dateStr = this.formatDate(
      asset.publishedTimestamp || asset.lastModifiedTimestamp
    );

    return {
      id: asset.assetId,
      name: asset.title,
      status: statusMapping.internal,
      statusText: statusMapping.display,
      icon: statusMapping.icon,
      date: `${statusMapping.dateLabel} ${dateStr}`,
      responseCount: responseCount || DEFAULT_RESPONSE_COUNT,
      variant: statusMapping.variant,
      launchURL: asset.launchURL
    };
  }

  private mapStatus(status: string): { internal: 'closed' | 'in-progress' | 'draft'; display: string; icon: string; dateLabel: string; variant: SurveyStatusVariant } {
    const normalized = status.toUpperCase() as SurveyStatusType;
    const statusDisplay = SURVEY_STATUS_DISPLAY[normalized];
    
    if (!statusDisplay) {
      return {
        internal: 'draft' as const,
        display: 'Draft',
        icon: 'edit',
        dateLabel: 'Created',
        variant: 'info' as SurveyStatusVariant
      };
    }
    
    return {
      internal: this.normalizeStatusInternal(normalized),
      display: statusDisplay.label,
      icon: statusDisplay.icon || 'edit',
      dateLabel: statusDisplay.dateLabel || 'Created',
      variant: statusDisplay.variant
    };
  }

  private normalizeStatusInternal(status: SurveyStatusType): 'closed' | 'in-progress' | 'draft' {
    if (status === SurveyStatusType.CLOSED) return 'closed';
    if (status === SurveyStatusType.PUBLISHED) return 'in-progress';
    if (status === SurveyStatusType.DRAFT) return 'draft';
    return 'draft'; 
  }

  private formatDate(timestamp?: number): string {
    if (!timestamp) {
      return '--/--';
    }
    const dateObj = new Date(timestamp);
    const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
    const day = dateObj.getDate().toString().padStart(2, '0');
    return `${month}/${day}`;
  }

  navigateToMyAssets(): void {
    this.router.navigate(['/my-assets/survey']);
  }

  navigateToSurvey(survey: Survey): void {
    if (survey.launchURL) {
      window.location.assign(survey.launchURL);
    }
  }

  navigateToSelectPanelist(): void {
    this.surveyCommonService.resetState();
    this.router.navigate(['/survey/select-panelist']);
  }

  navigateToAiflow(): void {
    this.surveyCommonService.resetState();
    this.router.navigate(['/survey/aiflow/select-panelist']);
  }

  calculateProgressPercent(responseCount: string | undefined): number {
    if (!responseCount) return 0;
    const match = responseCount.match(/(\d+)\/(\d+)/);
    if (match) {
      const collected = parseInt(match[1], 10);
      const target = parseInt(match[2], 10);
      return target > 0 ? (collected / target) * 100 : 0;
    }
    return 0;
  }

  isDraftSurvey(survey: Survey): boolean {
    return survey.status === 'draft';
  }

  openHelpItem(helpItem: any): void {
    if (helpItem.url) {
      window.open(helpItem.url, '_blank', 'noopener');
    }
  }

  openFeature(feature: any): void {
    if (feature.url) {
      window.open(feature.url, '_blank', 'noopener');
    }
  }
}
