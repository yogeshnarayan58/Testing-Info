import { describe, expect, it, beforeEach, vi } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { SurveyHomepageComponent } from './survey-homepage.component';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyAssetApiService } from '../../../my-assets/services/survey-asset-api.service';
import { SurveyGridHandlerService } from '../../../my-assets/services/survey-grid-handler.service';
import { FeatureCard, HelpItem, Survey, SURVEY_CREDITS, SURVEY_CREDITS_NO_USAGE } from '../../models/survey-home';
import { of, throwError } from 'rxjs';

vi.mock('../../../build-survey/services/survey.service', () => ({ SurveyService: class {} }));

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

describe('SurveyHomepageComponent', () => {
  let component: SurveyHomepageComponent;
  let mockRouter: { navigate: ReturnType<typeof vi.fn>; navigateByUrl: ReturnType<typeof vi.fn> };
  let mockSurveyCommonService: { resetState: ReturnType<typeof vi.fn> };
  let mockSurveyService: { currentSurveyId: string | null; reset: ReturnType<typeof vi.fn> };
  let mockSurveyAssetApi: { fetchSurveyAssets: ReturnType<typeof vi.fn> };
  let mockSurveyGridHandler: { getSafeLaunchUrl: ReturnType<typeof vi.fn> };

  beforeEach(() => {
    mockSurveyService = {
      currentSurveyId: 'previous-draft',
      reset: vi.fn(() => { mockSurveyService.currentSurveyId = null; }),
    };
    mockRouter = { navigate: vi.fn(), navigateByUrl: vi.fn() };
    mockSurveyCommonService = { resetState: vi.fn() };
    mockSurveyGridHandler = { getSafeLaunchUrl: vi.fn((url) => url) };
    mockSurveyAssetApi = {
      fetchSurveyAssets: vi.fn(() =>
        of({
          assets: [
            {
              assetId: '1',
              assetType: 'SURVEY',
              title: 'Test Survey 1',
              status: 'CLOSED',
              publishedTimestamp: new Date('2024-05-15').getTime(),
              lastModifiedTimestamp: Date.now(),
            },
            {
              assetId: '2',
              assetType: 'SURVEY',
              title: 'Test Survey 2',
              status: 'PUBLISHED',
              publishedTimestamp: new Date('2024-06-20').getTime(),
              lastModifiedTimestamp: Date.now(),
            },
          ],
          totalCount: 2,
        })
      ),
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: SurveyCommonService, useValue: mockSurveyCommonService },
        { provide: SurveyService, useValue: mockSurveyService },
        { provide: SurveyAssetApiService, useValue: mockSurveyAssetApi },
        { provide: SurveyGridHandlerService, useValue: mockSurveyGridHandler },
      ],
    });
    component = TestBed.runInInjectionContext(() => new SurveyHomepageComponent());
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Survey Loading', () => {
    it('loads surveys and maps status correctly', () => {
      component.ngOnInit();
      expect(mockSurveyAssetApi.fetchSurveyAssets).toHaveBeenCalled();
      expect(component.surveys().length).toBe(2);
      expect(component.surveys()[0].status).toBe('closed');
      expect(component.surveys()[1].status).toBe('in-progress');
      expect(component.surveyCredits()).toEqual(SURVEY_CREDITS);
    });

    it('keeps existing surveys on API error', () => {
      // First load with surveys
      component.ngOnInit();
      expect(component.surveys().length).toBe(2);
      expect(component.loadedSuccessfully()).toBe(true);
      
      // API error on next load
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        throwError(() => new Error('API Error'))
      );
      component.ngOnInit();
      // Surveys should NOT be cleared - still has 2
      expect(component.surveys().length).toBe(2);
      // loadedSuccessfully should remain false after error
      expect(component.loadedSuccessfully()).toBe(false);
    });

    it('handles empty assets array and sets flags correctly', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({ assets: [], totalCount: 0 })
      );
      component.ngOnInit();
      expect(component.surveys()).toEqual([]);
      expect(component.surveyTotalCount()).toBe(0);
      expect(component.loadedSuccessfully()).toBe(true);
      expect(component.isNewUser()).toBe(true);
      expect(component.surveyCredits()).toEqual(SURVEY_CREDITS_NO_USAGE);
    });



    it('shows only 4 most recent surveys sorted by timestamp', () => {
      const now = Date.now();
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            // API returns exactly 4 surveys sorted by DATE DESC (most recent first)
            { assetId: '5', assetType: 'SURVEY', title: 'Survey 5', status: 'DRAFT', publishedTimestamp: now - 1000, lastModifiedTimestamp: now - 1000 },
            { assetId: '4', assetType: 'SURVEY', title: 'Survey 4', status: 'PUBLISHED', publishedTimestamp: now - 2000, lastModifiedTimestamp: now - 2000 },
            { assetId: '3', assetType: 'SURVEY', title: 'Survey 3', status: 'PUBLISHED', publishedTimestamp: now - 3000, lastModifiedTimestamp: now - 3000 },
            { assetId: '2', assetType: 'SURVEY', title: 'Survey 2', status: 'CLOSED', publishedTimestamp: now - 4000, lastModifiedTimestamp: now - 4000 },
          ],
          totalCount: 10,
        })
      );
      component.ngOnInit();
      expect(component.surveys().length).toBe(4);
      // Should display all 4 from API
      expect(component.surveys()[0].id).toBe('5');
      expect(component.surveys()[1].id).toBe('4');
      expect(component.surveys()[2].id).toBe('3');
      expect(component.surveys()[3].id).toBe('2');
    });

    it('uses fallback timestamp when publishedTimestamp is missing', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'PUBLISHED', publishedTimestamp: undefined, lastModifiedTimestamp: new Date('2024-07-15').getTime() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].date).toContain('07/15');
    });

    it('handles unknown status with fallback to draft', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'UNKNOWN_STATUS', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('draft');
      expect(component.surveys()[0].statusText).toBe('SURVEYMOD_STATUS_DRAFT');
    });

    it('maps DRAFT status correctly', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'DRAFT', publishedTimestamp: undefined, lastModifiedTimestamp: new Date('2024-06-20').getTime() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('draft');
      expect(component.surveys()[0].dateLabel).toBe('SURVEYMOD_STATUS_CREATED');
    });
  });

  describe('Navigation', () => {
    it('navigates to my-assets', () => {
      component.navigateToMyAssets();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/my-assets/survey']);
    });

    it('calls navigateToSurvey with valid survey', () => {
      const survey: Survey = {
        id: '1',
        name: 'Test Survey',
        status: 'draft',
        statusText: 'Draft',
        date: 'Created 01/01',
        launchURL: '/survey/build-survey/survey-1',
      };
      // Just verify the method exists and can be called
      expect(() => component.navigateToSurvey(survey)).not.toThrow();
    });

    it('handles navigateToSurvey without launchURL', () => {
      const survey: Survey = {
        id: '1',
        name: 'Test Survey',
        status: 'draft',
        statusText: 'Draft',
        date: 'Created 01/01',
      };
      expect(() => component.navigateToSurvey(survey)).not.toThrow();
    });

    it('resets state and navigates to select-panelist', () => {
      mockRouter.navigate.mockImplementation(() => expect(mockSurveyService.currentSurveyId).toBeNull());
      component.navigateToSelectPanelist();
      expect(mockSurveyService.reset).toHaveBeenCalledOnce();
      expect(mockSurveyCommonService.resetState).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/survey/select-panelist']);
    });

    it('resets state and navigates to aiflow', () => {
      mockRouter.navigate.mockImplementation(() => expect(mockSurveyService.currentSurveyId).toBeNull());
      component.navigateToAiflow();
      expect(mockSurveyService.reset).toHaveBeenCalledOnce();
      expect(mockSurveyCommonService.resetState).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/survey/aiflow/select-panelist']);
    });
  });

  describe('Progress Calculation', () => {
    it('calculates progress percentage correctly', () => {
      expect(component.calculateProgressPercent('500/500 responses')).toBe(100);
      expect(component.calculateProgressPercent('300/1000 responses')).toBe(30);
      expect(component.calculateProgressPercent('0/100 responses')).toBe(0);
    });

    it('handles invalid format and returns 0', () => {
      expect(component.calculateProgressPercent('invalid')).toBe(0);
      expect(component.calculateProgressPercent('')).toBe(0);
      expect(component.calculateProgressPercent(undefined)).toBe(0);
    });

    it('handles division by zero', () => {
      expect(component.calculateProgressPercent('100/0 responses')).toBe(0);
    });
  });

  describe('Date Formatting', () => {
    it('formats timestamp correctly', () => {
      expect(component['formatDate'](new Date('2024-06-20').getTime())).toBe('06/20');
      expect(component['formatDate'](new Date('2024-01-05').getTime())).toBe('01/05');
    });

    it('returns --/-- for missing or zero timestamp', () => {
      expect(component['formatDate'](undefined)).toBe('--/--');
      expect(component['formatDate'](null as any)).toBe('--/--');
      expect(component['formatDate'](0)).toBe('--/--');
    });
  });

  describe('Survey Status Checks', () => {
    it('identifies draft surveys correctly', () => {
      const draftSurvey: Survey = { id: '1', name: 'Test', status: 'draft', statusText: 'Draft', date: 'Created 01/01' };
      const inProgressSurvey: Survey = { id: '2', name: 'Test', status: 'in-progress', statusText: 'In progress', date: 'Published 01/02' };
      const closedSurvey: Survey = { id: '3', name: 'Test', status: 'closed', statusText: 'Closed', date: 'Closed 01/03' };
      
      expect(component.isDraftSurvey(draftSurvey)).toBe(true);
      expect(component.isDraftSurvey(inProgressSurvey)).toBe(false);
      expect(component.isDraftSurvey(closedSurvey)).toBe(false);
    });
  });

  describe('New User Detection (isNewUser)', () => {
    it('shows new-user screen when API succeeds with 0 surveys and 0 total count', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(of({ assets: [], totalCount: 0 }));
      component.ngOnInit();
      expect(component.isNewUser()).toBe(true);
      expect(component.loadedSuccessfully()).toBe(true);
      expect(component.surveyTotalCount()).toBe(0);
    });

    it('does NOT show new-user screen when API fails', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(throwError(() => new Error('API Error')));
      component.ngOnInit();
      expect(component.isNewUser()).toBe(false);
      expect(component.loadedSuccessfully()).toBe(false);
    });

    it('does NOT show new-user screen when surveys exist in folders', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({ assets: [{ assetId: '1', assetType: 'DISCOVERFOLDER', title: 'Folder', status: undefined, publishedTimestamp: undefined, lastModifiedTimestamp: Date.now() }], totalCount: 5 })
      );
      component.ngOnInit();
      expect(component.isNewUser()).toBe(false);
      expect(component.surveyTotalCount()).toBe(5);
    });

    it('does NOT show new-user screen when surveys exist in preview', () => {
      component.ngOnInit();
      expect(component.isNewUser()).toBe(false);
      expect(component.surveys().length).toBe(2);
    });

    it('maps CLOSED status with proper dateLabel when publishedTimestamp present', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [{ assetId: '1', assetType: 'SURVEY', title: 'Closed Survey', status: 'CLOSED', publishedTimestamp: new Date('2024-01-10').getTime(), lastModifiedTimestamp: Date.now() }],
          totalCount: 1
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('closed');
      expect(component.surveys()[0].dateLabel).toBe('SURVEYMOD_STATUS_CLOSED');
    });

    it('maps PUBLISHED status to in-progress with Published dateLabel', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [{ assetId: '1', assetType: 'SURVEY', title: 'Published Survey', status: 'PUBLISHED', publishedTimestamp: new Date('2024-02-15').getTime(), lastModifiedTimestamp: Date.now() }],
          totalCount: 1
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('in-progress');
      expect(component.surveys()[0].dateLabel).toBe('SURVEYMOD_STATUS_PUBLISHED');
    });

    it('uses lastModifiedTimestamp when publishedTimestamp is missing', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [{ assetId: '1', assetType: 'SURVEY', title: 'Draft Survey', status: 'DRAFT', publishedTimestamp: undefined, lastModifiedTimestamp: new Date('2024-03-20').getTime() }],
          totalCount: 1
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('draft');
      expect(component.surveys()[0].dateLabel).toBe('SURVEYMOD_STATUS_CREATED');
    });

    it('prefers publishedTimestamp over lastModifiedTimestamp', () => {
      const published = new Date('2024-01-01').getTime();
      const lastModified = new Date('2024-12-31').getTime();
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [{ assetId: '1', assetType: 'SURVEY', title: 'Published Survey', status: 'PUBLISHED', publishedTimestamp: published, lastModifiedTimestamp: lastModified }],
          totalCount: 1
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].date).toContain('01/01');
    });

    it('returns dashes when both timestamps are missing', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [{ assetId: '1', assetType: 'SURVEY', title: 'No Date Survey', status: 'DRAFT', publishedTimestamp: undefined, lastModifiedTimestamp: undefined }],
          totalCount: 1
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].date).toContain('--/--');
    });
  });

  describe('Load State Tracking', () => {
    it('marks loadedSuccessfully and stores totalCount on successful API call', () => {
      component.ngOnInit();
      expect(component.loadedSuccessfully()).toBe(true);
      expect(component.surveyTotalCount()).toBe(2);
    });

    it('sets loadedSuccessfully false on API failure', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(throwError(() => new Error('API Error')));
      component.ngOnInit();
      expect(component.loadedSuccessfully()).toBe(false);
    });
  });

  describe('Help and Feature Navigation', () => {
    it('opens help item URL in new window when present', () => {
      const windowSpy = vi.spyOn(window, 'open').mockImplementation(() => null);
      const helpItem = { url: 'https://help.example.com' };
      component.openHelpItemOrFeature(helpItem as HelpItem);
      expect(windowSpy).toHaveBeenCalledWith('https://help.example.com', '_blank', 'noopener');
      windowSpy.mockRestore();
    });

    it('does not open window when help item has no URL', () => {
      const windowSpy = vi.spyOn(window, 'open').mockImplementation(() => null);
      const helpItem = { title: 'Help' };
      component.openHelpItemOrFeature(helpItem as HelpItem);
      expect(windowSpy).not.toHaveBeenCalled();
      windowSpy.mockRestore();
    });

    it('opens feature URL in new window when present', () => {
      const windowSpy = vi.spyOn(window, 'open').mockImplementation(() => null);
      const feature = { url: 'https://feature.example.com' };
      component.openHelpItemOrFeature(feature as FeatureCard);
      expect(windowSpy).toHaveBeenCalledWith('https://feature.example.com', '_blank', 'noopener');
      windowSpy.mockRestore();
    });

    it('does not open window when feature has no URL', () => {
      const windowSpy = vi.spyOn(window, 'open').mockImplementation(() => null);
      const feature = { title: 'Feature' };
      component.openHelpItemOrFeature(feature as FeatureCard);
      expect(windowSpy).not.toHaveBeenCalled();
      windowSpy.mockRestore();
    });

    it('defaults to DRAFT status when asset status is null', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: null, publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('draft');
      expect(component.surveys()[0].statusText).toBe('SURVEYMOD_STATUS_DRAFT');
    });

    it('defaults to DRAFT status when asset status is undefined', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('draft');
      expect(component.surveys()[0].statusText).toBe('SURVEYMOD_STATUS_DRAFT');
    });

    it('defaults to DRAFT when status is unknown', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'UNKNOWN_STATUS', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].status).toBe('draft');
      expect(component.surveys()[0].statusText).toBe('SURVEYMOD_STATUS_DRAFT');
      expect(component.surveys()[0].icon).toBe('edit');
    });

    it('handles asset with no title by using assetId', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '123', assetType: 'SURVEY', title: null, status: 'PUBLISHED', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].name).toBeNull();
    });

    it('applies correct variant for different statuses', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Closed', status: 'CLOSED', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
            { assetId: '2', assetType: 'SURVEY', title: 'Published', status: 'PUBLISHED', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
            { assetId: '3', assetType: 'SURVEY', title: 'Draft', status: 'DRAFT', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 3,
        })
      );
      component.ngOnInit();
      const surveys = component.surveys();
      expect(surveys[0].variant).toBeDefined();
      expect(surveys[1].variant).toBeDefined();
      expect(surveys[2].variant).toBeDefined();
    });

    it('detects newly created survey when timestamps are within threshold', () => {
      const now = Date.now();
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Newly Created', status: 'DRAFT', initialCreationTimestamp: now, lastModifiedTimestamp: now + 100 },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].dateLabel).toBe('SURVEYMOD_STATUS_CREATED');
    });

    it('detects modified draft when timestamps differ beyond threshold', () => {
      const now = Date.now();
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Modified Draft', status: 'DRAFT', initialCreationTimestamp: now - 5000, lastModifiedTimestamp: now },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].dateLabelText).toBe('Modified');
      expect(component.surveys()[0].date).toBeDefined();
    });

    it('handles response with no assets array', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          totalCount: 0,
        })
      );
      component.ngOnInit();
      expect(component.surveys()).toEqual([]);
      expect(component.surveyTotalCount()).toBe(0);
    });

    it('handles response with undefined totalCount', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'PUBLISHED', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
        })
      );
      component.ngOnInit();
      expect(component.surveyTotalCount()).toBe(0);
    });

    it('uses DEFAULT_RESPONSE_COUNT when responseCount is not provided', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'PUBLISHED', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].responseCount).toBeDefined();
    });

    it('sets surveyTotalCount to zero when not provided', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [],
        })
      );
      component.ngOnInit();
      expect(component.surveyTotalCount()).toBe(0);
    });

    it('displays Draft icon and dateLabel as defaults for unknown status', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'NONEXISTENT_STATUS', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.surveys()[0].icon).toBe('edit');
      expect(component.surveys()[0].dateLabel).toBe('SURVEYMOD_STATUS_CREATED');
    });

    it('identifies new user with no surveys', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [],
          totalCount: 0,
        })
      );
      component.ngOnInit();
      expect(component.isNewUser()).toBe(true);
    });

    it('identifies non-new user with surveys', () => {
      mockSurveyAssetApi.fetchSurveyAssets.mockReturnValueOnce(
        of({
          assets: [
            { assetId: '1', assetType: 'SURVEY', title: 'Survey', status: 'PUBLISHED', publishedTimestamp: Date.now(), lastModifiedTimestamp: Date.now() },
          ],
          totalCount: 1,
        })
      );
      component.ngOnInit();
      expect(component.isNewUser()).toBe(false);
    });
  });
});
