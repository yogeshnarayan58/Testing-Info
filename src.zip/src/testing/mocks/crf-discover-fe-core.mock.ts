// Vitest stand-in for @nielseniq/crf-discover-fe-core: the real package pulls in
// @nielseniq/athena-core, whose extensionless '@nielseniq/token' import breaks Node resolution.
export class EnvironmentConfig {
  [key: string]: unknown;
}

export class PreferencesService {}

export class ListCallDatasetService {}

export class RequestTrackingService {}

export enum ToastTime {
  DISMISSAFTER = 5000,
}
