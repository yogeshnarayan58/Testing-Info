import { TestBed } from '@angular/core/testing';
import { ACFetchApiService, AssignRightsHelperService, UserService } from '@nielsen/crf-lp-common';
import { EnvironmentConfig, FlippingService } from '@nielseniq/crf-discover-fe-core';
import { firstValueFrom, of, throwError } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiService } from '../../../shared/services/api.service';
import { MY_ASSETS_TABS, MyAssetsTabId } from '../constants/my-assets-tabs.constant';
import { AssetCatalogRequest, SurveyGridRow } from '../models/survey-asset.model';
import { SurveyAssetApiService } from './survey-asset-api.service';

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  AssignRightsHelperService: class {},
  UserService: class {},
}));

vi.mock('@nielseniq/crf-discover-fe-core', () => ({
  EnvironmentConfig: class {},
  FlippingService: class {},
}));

vi.mock('../../../shared/services/api.service', () => ({
  ApiService: class {},
}));

describe('SurveyAssetApiService tab payloads', () => {
  let service: SurveyAssetApiService;
  let post: ReturnType<typeof vi.fn>;
  let put: ReturnType<typeof vi.fn>;
  let userServiceStub: { getUserData: ReturnType<typeof vi.fn> };
  let getAssetInfoByAssetId: ReturnType<typeof vi.fn>;
  let getParentHierarchyByAssetId: ReturnType<typeof vi.fn>;
  let getDefaultRights: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    post = vi.fn().mockReturnValue(of({ data: { assets: [], summary: { totalAssets: 0 } } }));
    put = vi.fn().mockReturnValue(of({ success: true }));
    userServiceStub = { getUserData: vi.fn().mockReturnValue(of({ timezone: 'Etc/Universal' })) };
    getAssetInfoByAssetId = vi.fn();
    getDefaultRights = vi.fn();
    getParentHierarchyByAssetId = vi.fn().mockReturnValue(of([]));
    getDefaultRights = vi.fn().mockReturnValue(of([{ availability: 'OWNED', orderManagementId: 'order-1' }]));
    TestBed.configureTestingModule({
      providers: [
        SurveyAssetApiService,
        { provide: ApiService, useValue: { post, put, clearCache: vi.fn() } },
        { provide: EnvironmentConfig, useValue: { apiUrls: { assetCatalogDiscovery: '/assets', assetCatalogIntegration: '/integration/assets' } } },
        { provide: ACFetchApiService, useValue: { getParentHierarchyByAssetId, getAssetInfoByAssetId } },
        { provide: AssignRightsHelperService, useValue: { getDefaultRights } },
        { provide: UserService, useValue: userServiceStub },
        { provide: FlippingService, useValue: { getFlippingValue: vi.fn().mockReturnValue(false) } },
      ],
    });
    service = TestBed.inject(SurveyAssetApiService);
  });

  afterEach(() => {
    vi.useRealTimers();
    TestBed.resetTestingModule();
  });

  function requestFor(tab: MyAssetsTabId): AssetCatalogRequest {
    service.fetchSurveyAssets(100, 200, [{ colId: 'TITLE', sort: 'asc' }], 100, tab).subscribe();
    expect(post).toHaveBeenLastCalledWith('/assets', expect.any(Object), {
      withCredentials: true, cache: true, cacheTag: `my-assets:${tab}:root`,
    });
    return post.mock.calls[post.mock.calls.length - 1][1] as AssetCatalogRequest;
  }

  const row: SurveyGridRow = {
    assetId: 'survey-1', assetType: 'DISCOVERSURVEY', title: 'Grid title', lastModifiedTimestamp: 0,
  };

  it('creates requests for different asset pages, tabs and sorts', async () => {
    await firstValueFrom(service.fetchSurveyAssets(0, 100));
    await firstValueFrom(service.fetchSurveyAssets(100, 200));
    await firstValueFrom(service.fetchSurveyAssets(0, 100, undefined, 100, MY_ASSETS_TABS.MY_FAVORITES));
    await firstValueFrom(service.fetchSurveyAssets(0, 100, [{ colId: 'TITLE', sort: 'asc' }]));
    expect(post).toHaveBeenCalledTimes(4);
  });

  it('fetches detailed access information and merges the matching asset with the row', async () => {
    getAssetInfoByAssetId.mockReturnValue(of([
      { assetId: 'other' },
      { assetId: row.assetId, title: 'Detailed title', status: 'DRAFT' },
    ]));
    const result = await firstValueFrom(service.fetchSurveyDetails(row));
    expect(getAssetInfoByAssetId).toHaveBeenCalledWith(row.assetId, {
      userDetails: true, associatedUsers: true,
      parentHierarchy: true, sourceId: true,
    }, false);
    expect(result).toMatchObject({
      ...row, title: 'Detailed title', status: 'DRAFT', statusDisplay: { label: 'Draft' },
    });
  });

  it('reports an error when the requested asset is not returned', async () => {
    getAssetInfoByAssetId.mockReturnValue(of([{ assetId: 'other' }]));
    await expect(firstValueFrom(service.fetchSurveyDetails(row)))
      .rejects.toThrow('Survey details were not returned.');
  });

  it('creates folders with the default rights and credentials', async () => {
    const rights = [{ availability: 'OWNED', userId: 'owner' }];
    getDefaultRights.mockReturnValue(of(rights));
    post.mockReturnValue(of({ assetId: 'folder-1' }));
    await expect(firstValueFrom(service.createFolder('Folder'))).resolves.toEqual({ assetId: 'folder-1' });
    expect(post).toHaveBeenCalledWith('/integration/assets', [{
      assetType: 'DISCOVERFOLDER', title: 'Folder', status: 'OPEN', rights,
    }], { withCredentials: true });
  });

  it('logs and propagates folder creation failures', async () => {
    const error = new Error('Creation failed');
    const log = vi.spyOn(console, 'error').mockImplementation(() => {});
    getDefaultRights.mockReturnValue(of([]));
    post.mockReturnValue(throwError(() => error));
    try {
      await expect(firstValueFrom(service.createFolder('Folder'))).rejects.toBe(error);
      expect(log).toHaveBeenCalledWith('Error creating folder:', error);
    } finally {
      log.mockRestore();
    }
  });

  it('fetches folder children without excluding draft surveys by status', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{
          assetId: 'draft-1', assetType: 'DISCOVERSURVEY', title: 'Draft survey', status: 'DRAFT',
          publishedTimestamp: 123, timeLeft: '2 days', creditsUsed: 5, accessLabel: 'Shared',
        }],
        summary: { totalAssets: 1 },
      },
    }));
    let result: { assets: unknown[]; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1', 200, 100, [{ colId: 'TITLE', sort: 'asc' }]).subscribe((response) => {
      result = response;
    });

    expect(post).toHaveBeenCalledWith('/assets', expect.any(Object), {
      withCredentials: true, cache: true, cacheTag: 'my-assets:my-assets:folder-1',
    });
    const request = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;
    expect(request).toMatchObject({
      assets: [
        { assetType: 'DISCOVERSURVEY' },
        { assetType: 'DISCOVERFOLDER' },
        { assetType: 'DISCOVERSHAREDFOLDER' },
      ],
      properties: { pageCount: 100, pageNumber: 3, parentAsset: true, showImmediateChildren: true },
      filters: [
        { typeKey: 'HIER', elements: [{ id: 'folder-1' }] },
        { typeKey: 'AVL', elements: [{ availability: 'OWNED' }] },
      ],
      sort: { primarySort: 'TITLE', sortOrder: 'ASC' },
    });
    expect(request.assets).not.toContainEqual(expect.objectContaining({ status: expect.anything() }));
    expect(result?.assets).toEqual([
      expect.objectContaining({
        assetId: 'draft-1', title: 'Draft survey', status: 'DRAFT',
        publishedTimestamp: 123, timeLeft: '2 days', creditsUsed: 5, accessLabel: 'Shared',
      }),
    ]);
    expect(result?.totalCount).toBe(1);
  });

  it('uses folder request defaults and the properties total count fallback', () => {
    userServiceStub.getUserData.mockReturnValueOnce(of(null));
    post.mockReturnValueOnce(of({
      data: {
        assets: [{ assetId: 'child-1', assetType: 'DISCOVERSURVEY' }],
        properties: { totalAssets: 7 },
      },
    }));
    let result: { assets: unknown[]; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1', 0, 0).subscribe((response) => {
      result = response;
    });

    const request = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;
    expect(request.properties).toMatchObject({
      pageCount: 100,
      pageNumber: 1,
      timezone: 'Etc/Universal',
      parentAsset: true,
      showImmediateChildren: true,
    });
    expect(request.sort).toEqual({ primarySort: 'DATE', sortOrder: 'DESC' });
    expect(result?.totalCount).toBe(7);
  });

  it('fetches the folder hierarchy for breadcrumb reconstruction', () => {
    const hierarchy = [{ assetId: 'folder-1' }];
    getParentHierarchyByAssetId.mockReturnValueOnce(of(hierarchy));
    let result: unknown;

    service.fetchFolderHierarchy('folder-1').subscribe((value) => {
      result = value;
    });

    expect(getParentHierarchyByAssetId).toHaveBeenCalledWith('folder-1', false);
    expect(result).toBe(hierarchy);
  });

  it('preserves the existing folder request and adds parentAsset for nested folders', () => {
    service.createFolder('Nested', 'parent-1').subscribe();

    expect(getDefaultRights).toHaveBeenCalledOnce();
    expect(post).toHaveBeenCalledWith(
      '/integration/assets',
      [{
        assetType: 'DISCOVERFOLDER',
        title: 'Nested',
        status: 'OPEN',
        rights: [{ availability: 'OWNED', orderManagementId: 'order-1' }],
        parentAsset: { assetId: 'parent-1' },
      }],
      { withCredentials: true }
    );
  });

  it('preserves root folder creation without adding a parentAsset', () => {
    service.createFolder('Root folder').subscribe();

    expect(post).toHaveBeenCalledWith(
      '/integration/assets',
      [{
        assetType: 'DISCOVERFOLDER',
        title: 'Root folder',
        status: 'OPEN',
        rights: [{ availability: 'OWNED', orderManagementId: 'order-1' }],
      }],
      { withCredentials: true }
    );
  });

  it('logs and rethrows folder creation errors', () => {
    const error = new Error('request failed');
    const consoleError = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    post.mockReturnValueOnce(throwError(() => error));
    const onError = vi.fn();

    service.createFolder('Folder').subscribe({ error: onError });

    expect(consoleError).toHaveBeenCalledWith('Error creating folder:', error);
    expect(onError).toHaveBeenCalledWith(error);
    consoleError.mockRestore();
  });

  it('uses shared-with-me rights for shared folder children', () => {
    service.fetchFolderChildren('folder-1', 0, 100, undefined, MY_ASSETS_TABS.SHARED_WITH_ME).subscribe();
    const request = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;

    expect(request.filters.find((filter) => filter.typeKey === 'AVL')).toEqual({
      typeKey: 'AVL',
      elements: ['EDIT', 'VIEW', 'STRICTVIEW', 'OWNED'].map((availability) => ({ availability })),
    });
    expect(request.assets).not.toContainEqual({ status: 'TRASHED' });
  });

  it('requests trashed folder children only in the trash tab', () => {
    service.fetchFolderChildren('folder-1', 0, 100, undefined, MY_ASSETS_TABS.TRASH).subscribe();
    const request = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;

    expect(request.assets).toContainEqual({ status: 'TRASHED' });
    expect(request.filters.find((filter) => filter.typeKey === 'AVL')).toEqual({
      typeKey: 'AVL',
      elements: [{ availability: 'OWNED' }],
    });
  });

  it('uses defaults when paging, sorting, user timezone, and response data are missing', () => {
    userServiceStub.getUserData.mockReturnValueOnce(of(null));
    post.mockReturnValueOnce(of({}));
    let result: { assets: unknown[]; totalCount: number } | undefined;

    service.fetchSurveyAssets(0, 0).subscribe((response) => {
      result = response;
    });

    const request = post.mock.calls[0][1] as AssetCatalogRequest;
    expect(request.properties).toMatchObject({
      pageCount: 1,
      pageNumber: 1,
      timezone: 'Etc/Universal'
    });
    expect(request.sort).toEqual({ primarySort: 'DATE', sortOrder: 'DESC' });
    expect(result).toEqual({ assets: [], totalCount: 0 });
  });

  it('normalizes non-string folder child statuses to undefined', () => {
    post.mockReturnValueOnce(of({
      data: { assets: [{ assetId: 'asset-1', assetType: 'DISCOVERSURVEY', status: 7 }] },
    }));
    let result: { assets: Array<{ status?: string }>; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1').subscribe((response) => {
      result = response;
    });

    expect(result?.assets[0].status).toBeUndefined();
    expect(result?.totalCount).toBe(1);
  });

  it('preserves string folder child statuses', () => {
    post.mockReturnValueOnce(of({
      data: { assets: [{ assetId: 'asset-1', assetType: 'DISCOVERSURVEY', status: 'DRAFT' }] },
    }));
    let result: { assets: Array<{ status?: string }>; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1').subscribe((response) => {
      result = response;
    });

    expect(result?.assets[0].status).toBe('DRAFT');
    expect(result?.totalCount).toBe(1);
  });

  it('uses assets length as fallback when summary is missing', () => {
    post.mockReturnValueOnce(of({
      data: { assets: [
        { assetId: 'asset-1', assetType: 'DISCOVERSURVEY' },
        { assetId: 'asset-2', assetType: 'DISCOVERSURVEY' },
      ]},
    }));
    let result: { assets: unknown[]; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1').subscribe((response) => {
      result = response;
    });

    expect(result?.totalCount).toBe(2);
  });

  it('handles empty folder children response', () => {
    post.mockReturnValueOnce(of({
      data: { assets: [], summary: { totalAssets: 0 } },
    }));
    let result: { assets: unknown[]; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1').subscribe((response) => {
      result = response;
    });

    expect(result?.assets).toEqual([]);
    expect(result?.totalCount).toBe(0);
  });

  it.each([
    [MY_ASSETS_TABS.MY_ASSETS, ['OWNED'], true],
    [MY_ASSETS_TABS.SHARED_WITH_ME, ['EDIT', 'VIEW', 'STRICTVIEW'], true],
    [MY_ASSETS_TABS.RECENT, ['EDIT', 'VIEW', 'STRICTVIEW', 'OWNED'], false],
    [MY_ASSETS_TABS.MY_FAVORITES, ['EDIT', 'VIEW', 'STRICTVIEW', 'OWNED'], false],
    [MY_ASSETS_TABS.TRASH, ['OWNED'], true],
  ] as const)('uses landing-page access and hierarchy filters for %s', (tab, availability, rootOnly) => {
    const request = requestFor(tab);
    expect(request.filters.find((filter) => filter.typeKey === 'AVL')).toEqual({
      typeKey: 'AVL',
      elements: availability.map((right) => ({ availability: right })),
      ...(tab === MY_ASSETS_TABS.MY_ASSETS
        ? { exclusions: [{ availability: 'PUBLISHED' }] }
        : {}),
    });
    expect(request.filters.some((filter) => filter.typeKey === 'RLT')).toBe(rootOnly);
    expect(request.properties).toMatchObject({ pageCount: 100, pageNumber: 2 });
    expect(request.sort).toEqual({ primarySort: 'TITLE', sortOrder: 'ASC' });
  });

  it('retains the 31-day opened-date window for Recent only', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2026, 9, 6, 12));
    expect(requestFor(MY_ASSETS_TABS.RECENT).properties).toMatchObject({
      dateSortType: 'OPENED',
      startOpenedDate: '09/05/2026 00:00:00',
      endOpenedDate: '10/06/2026 23:59:00',
      lastOpenedByMe: true,
      lastAccessedByMe: false,
      restrictFlowChildren: true,
      fetchDatasetInfo: false,
    });
    expect(requestFor(MY_ASSETS_TABS.RECENT).properties).not.toHaveProperty('fetchScheduledInfo');
    const properties = requestFor(MY_ASSETS_TABS.MY_ASSETS).properties;
    expect(properties.dateSortType).toBe('MODIFIED');
    expect(properties).not.toHaveProperty('startOpenedDate');
    expect(properties).not.toHaveProperty('lastOpenedByMe');
  });

  it('adds a status constraint only for Trash', () => {
    const recentRequest = requestFor(MY_ASSETS_TABS.RECENT);
    expect(recentRequest.assets).not.toContainEqual({ status: 'OPEN' });

    for (const tab of [
      MY_ASSETS_TABS.MY_ASSETS,
      MY_ASSETS_TABS.SHARED_WITH_ME,
      MY_ASSETS_TABS.MY_FAVORITES,
      MY_ASSETS_TABS.TRASH,
    ]) {
      expect(requestFor(tab).assets).not.toContainEqual({ status: 'OPEN' });
    }
  });

  it('sets favorite and trash constraints only for their respective tabs', () => {
    expect(requestFor(MY_ASSETS_TABS.MY_FAVORITES).properties.isFavorite).toBe(true);
    const trashRequest = requestFor(MY_ASSETS_TABS.TRASH);
    expect(trashRequest.assets).toContainEqual({ status: 'TRASHED' });
    expect(trashRequest.filters.find((filter) => filter.typeKey === 'RLT')).toEqual({
      typeKey: 'RLT',
      exclusions: [{ relationshipType: 'PARENT' }],
      relationStatusToBeIgnored: ['TRASHED'],
    });
    const request = requestFor(MY_ASSETS_TABS.MY_ASSETS);
    expect(request.properties).not.toHaveProperty('isFavorite');
    expect(request.assets).not.toContainEqual({ status: 'TRASHED' });
    expect(request.assets).toContainEqual({ assetType: 'DISCOVERSURVEY' });
  });

  it('requests only surveys in Favorites without either folder type', () => {
    const request = requestFor(MY_ASSETS_TABS.MY_FAVORITES);

    expect(request.assets).toEqual([{ assetType: 'DISCOVERSURVEY' }]);
    expect(request.properties.isFavorite).toBe(true);
  });

  it.each([true, false])('updates favorite state to %s', (isFavorite) => {
    let result: unknown;
    service.updateFavorite('asset/id 1', isFavorite).subscribe((response) => {
      result = response;
    });

    expect(put).toHaveBeenCalledWith(
      '/integration/assets/asset%2Fid%201/myAssociation',
      { isFavorite },
      { withCredentials: true }
    );
    expect(result).toEqual({ success: true });
  });

  it('uses summary.totalAssets over properties fallback', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{ assetId: 'asset-1', assetType: 'DISCOVERSURVEY', status: 'DRAFT' }],
        summary: { totalAssets: 50 },
        properties: { totalAssets: 20 },
      },
    }));
    let result: { assets: unknown[]; totalCount: number } | undefined;

    service.fetchFolderChildren('folder-1').subscribe((response) => {
      result = response;
    });

    expect(result?.totalCount).toBe(50);
  });

  it('handles response with both data and root level summary', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{ assetId: 'a1', assetType: 'DISCOVERSURVEY' }],
        summary: { totalAssets: 99 },
        properties: { totalAssets: 101 },
      },
      summary: { totalAssets: 100 },
    }));
    let result: any;

    service.fetchFolderChildren('folder-1').subscribe((response) => {
      result = response;
    });

    expect(result?.totalCount).toBe(99);
  });

  it('uses the root summary before the properties fallback', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{ assetId: 'a1', assetType: 'DISCOVERSURVEY' }],
        properties: { totalAssets: 10 },
      },
      summary: { totalAssets: 8 },
    }));
    let result: any;

    service.fetchFolderChildren('folder-1').subscribe((response) => { result = response; });

    expect(result?.totalCount).toBe(8);
  });

  it('clears cache after successful favorite update and retriggers assets fetch', async () => {
    const clearCacheSpy = vi.spyOn(TestBed.inject(ApiService), 'clearCache');
    await firstValueFrom(service.updateFavorite('survey-1', true));
    expect(clearCacheSpy).toHaveBeenCalledWith('/assets');
  });

  it('clears cache after successful folder creation', async () => {
    const clearCacheSpy = vi.spyOn(TestBed.inject(ApiService), 'clearCache');
    await firstValueFrom(service.createFolder('Test Folder'));
    expect(clearCacheSpy).toHaveBeenCalledWith('/assets');
  });

  it('includes parentAsset in folder creation when parentFolderId is provided', async () => {
    await firstValueFrom(service.createFolder('Child Folder', 'parent-123'));
    expect(post).toHaveBeenCalledWith(
      '/integration/assets',
      expect.arrayContaining([
        expect.objectContaining({
          assetType: 'DISCOVERFOLDER',
          title: 'Child Folder',
          parentAsset: { assetId: 'parent-123' },
        }),
      ]),
      expect.any(Object)
    );
  });

  it('omits parentAsset in folder creation when parentFolderId is undefined', async () => {
    await firstValueFrom(service.createFolder('Root Folder'));
    const call = post.mock.calls.find(([url]) => url === '/integration/assets');
    expect(call?.[1][0]).not.toHaveProperty('parentAsset');
  });

  it('includes both folder types for non-recent and non-favorite tabs', () => {
    const request = requestFor(MY_ASSETS_TABS.MY_ASSETS);
    expect(request.assets).toEqual([
      { assetType: 'DISCOVERSURVEY' },
      { assetType: 'DISCOVERFOLDER' },
      { assetType: 'DISCOVERSHAREDFOLDER' },
    ]);
  });

  it('excludes folder types for recent tab', () => {
    const request = requestFor(MY_ASSETS_TABS.RECENT);
    expect(request.assets).toEqual([{ assetType: 'DISCOVERSURVEY' }]);
  });

  it('excludes folder types for favorites tab', () => {
    const request = requestFor(MY_ASSETS_TABS.MY_FAVORITES);
    expect(request.assets).toEqual([{ assetType: 'DISCOVERSURVEY' }]);
  });

  it('uses MODIFIED sort type for non-recent tabs', () => {
    const request = requestFor(MY_ASSETS_TABS.MY_ASSETS);
    expect(request.properties.dateSortType).toBe('MODIFIED');
  });

  it('handles null user data with timezone fallback', () => {
    userServiceStub.getUserData.mockReturnValueOnce(of(null));
    let result: { assets: unknown[]; totalCount: number } | undefined;
    service.fetchSurveyAssets(0, 100, undefined, 100, MY_ASSETS_TABS.MY_ASSETS).subscribe((r) => {
      result = r;
    });
    const request = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;
    expect(request.properties.timezone).toBe('Etc/Universal');
  });

  it('sets proper filters for shared-with-me tab without exclusions', () => {
    const request = requestFor(MY_ASSETS_TABS.SHARED_WITH_ME);
    const avlFilter = request.filters.find((f) => f.typeKey === 'AVL');
    expect(avlFilter).not.toHaveProperty('exclusions');
  });

  it('sets relationStatusToBeIgnored only for trash tab', () => {
    const trashRequest = requestFor(MY_ASSETS_TABS.TRASH);
    const rltFilter = trashRequest.filters.find((f) => f.typeKey === 'RLT');
    expect(rltFilter?.relationStatusToBeIgnored).toContain('TRASHED');
  });

  it('applies status constraint for trash only', () => {
    const trashRequest = requestFor(MY_ASSETS_TABS.TRASH);
    expect(trashRequest.assets).toContainEqual({ status: 'TRASHED' });
    const myAssetsRequest = requestFor(MY_ASSETS_TABS.MY_ASSETS);
    expect(myAssetsRequest.assets).not.toContainEqual({ status: 'TRASHED' });
  });

  it('handles page size as 0 with default value', () => {
    userServiceStub.getUserData.mockReturnValueOnce(of({ timezone: 'UTC' }));
    let requestUsed: AssetCatalogRequest | undefined;
    service.fetchSurveyAssets(0, 100, undefined, 0).subscribe();
    requestUsed = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;
    expect(requestUsed?.properties.pageCount).toBe(100);
  });

  it('calculates correct page number from start row', () => {
    userServiceStub.getUserData.mockReturnValueOnce(of({ timezone: 'UTC' }));
    service.fetchSurveyAssets(200, 300, undefined, 100).subscribe();
    const request = post.mock.calls.find(([url]) => url === '/assets')?.[1] as AssetCatalogRequest;
    expect(request.properties.pageNumber).toBe(3);
  });

  it('maps all asset properties including optional ones in folder children', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{
          assetId: 'a1',
          assetType: 'DISCOVERSURVEY',
          title: 'Survey Title',
          lastModifiedTimestamp: 1234567890,
          launchURL: 'http://launch.url',
          sourceId: 'src-123',
          isMyFavorite: true,
        }],
        summary: { totalAssets: 1 },
      },
    }));
    let result: any;
    service.fetchFolderChildren('folder-1').subscribe((r) => { result = r; });
    expect(result?.assets[0]).toMatchObject({
      assetId: 'a1',
      assetType: 'DISCOVERSURVEY',
      title: 'Survey Title',
      launchURL: 'http://launch.url',
      sourceId: 'src-123',
      isMyFavorite: true,
    });
  });

  it('uses the asset ID when title is missing and preserves null optional fields', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{ assetId: 'a1', assetType: 'DISCOVERSURVEY', title: null, launchURL: null }],
        summary: { totalAssets: 1 },
      },
    }));
    let result: any;
    service.fetchFolderChildren('folder-1').subscribe((r) => { result = r; });
    expect(result?.assets[0].title).toBe('a1');
    expect(result?.assets[0].launchURL).toBeNull();
  });

  it('normalizes required grid fields when API values are missing or non-string', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [{ assetId: 7, assetType: 8, title: undefined, lastModifiedTimestamp: undefined }],
      },
    }));
    let result: any;

    service.fetchFolderChildren('folder-1').subscribe((response) => { result = response; });

    expect(result?.assets[0]).toMatchObject({
      assetId: '7', assetType: '8', title: '7', lastModifiedTimestamp: 0,
    });
  });

  it('prefers assets length over zero summary totalAssets count', () => {
    post.mockReturnValueOnce(of({
      data: {
        assets: [
          { assetId: 'a1', assetType: 'DISCOVERSURVEY' },
          { assetId: 'a2', assetType: 'DISCOVERSURVEY' },
        ],
        summary: { totalAssets: 0 },
      },
    }));
    let result: any;
    service.fetchFolderChildren('folder-1').subscribe((r) => { result = r; });
    expect(result?.totalCount).toBe(2);
  });
});
