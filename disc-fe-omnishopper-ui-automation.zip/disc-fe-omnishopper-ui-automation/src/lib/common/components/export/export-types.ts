/**
 * Type definitions for export functionality
 * Provides strict type safety for export parameters
 */

// Export format options
export type ExportFormat = "Excel" | "PowerPoint";

// Export content options
export type ExportContent = "Editable objects" | "Static images";

// Card arrangement options
export type ArrangeCards = "Separately" | "As displayed in report";

// Component constants
export const EXPORT_COMPONENT_NAME = "Export";

// Export options interface
export interface ExportOptions {
  format: ExportFormat;
  content?: ExportContent;
  arrangement?: ArrangeCards;
}
