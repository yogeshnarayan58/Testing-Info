import { SurveyStatusType } from '../../build-survey/models/build-survey';
import { ASSET_TYPE } from '../constants/my-assets-tabs.constant';
import { SURVEY_STATUS_DISPLAY, SurveyStatusDisplay } from '../constants/survey-status.constant';
import { AssetCatalogRequest, SurveyGridAsset } from '../models/survey-asset.model';

export function isFolderAsset(asset: Pick<SurveyGridAsset, 'assetType'>): boolean {
  return asset.assetType === ASSET_TYPE.DISCOVERFOLDER || asset.assetType === ASSET_TYPE.DISCOVERSHAREDFOLDER;
}

/** Converts backend status values into title case for display. */
export function formatStatusLabel(status: string): string {
  return status
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/** Returns undefined for folders and assets without a status, which the grid renders as a placeholder. */
export function getStatusDisplay(asset: Pick<SurveyGridAsset, 'status' | 'assetType'>): SurveyStatusDisplay | undefined {
  if (!asset.status || isFolderAsset(asset)) {
    return undefined;
  }

  return SURVEY_STATUS_DISPLAY[asset.status.toUpperCase() as SurveyStatusType]
    ?? { label: formatStatusLabel(asset.status), variant: 'default' };
}

export function createAssetCatalogProperties(
  pageCount: number,
  pageNumber: number,
  dateSortType: string,
  overrides: Partial<AssetCatalogRequest['properties']> = {}
): AssetCatalogRequest['properties'] {
  return {
    displayAllRights: true,
    fetchDatasetInfo: false,
    filterElements: true,
    assetElements: true,
    userTags: true,
    sourceId: true,
    timezone: 'Etc/Universal',
    pageCount,
    pageNumber,
    dateSortType,
    ...overrides,
  };
}

export function createRootAssetFilters(): AssetCatalogRequest['filters'] {
  return [{
    typeKey: 'RLT',
    exclusions: [{ relationshipType: 'PARENT' }],
    relationStatusToBeIgnored: [],
  }];
}
