import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory, closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartWithPromptPage, OMNISHOPPER_OFFERING_DATA_TEST_ID } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { SurveyBuilderPage } from '../../page-objects/survey/surveyBuilder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Start with a prompt', { tag: '@StartWithPrompt' }, () => {
  let basePage: BasePage;
  let promptPage: StartWithPromptPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'start-with-prompt-video');
    }
  });

  test('Start with a Prompt: Should display the Start with a prompt option on the survey home page', { tag: '@StartWithPrompt' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    promptPage = new StartWithPromptPage(basePage);

    await promptPage.navigateToSurvey();
    await promptPage.clickStartWithPrompt();

    const isVisible = await promptPage.isDatasetTypeSelectorVisible(0);
    assertTrue(isVisible);
  });

  test('Dataset Selection: Should select the dataset type and dataset', { tag: '@DatasetSelection' }, async () => {
    await promptPage.selectDatasetType(OMNISHOPPER_OFFERING_DATA_TEST_ID);

    const isDatasetSelectionConfirmed = await promptPage.searchAndSelectDataset(
      datasetConfig.searchTerm,
      String(DATASET_NAME)
    );
    assertTrue(
      isDatasetSelectionConfirmed,
      `Expected dataset selection to succeed for ${DATASET_NAME}`
    );

    await promptPage.applyDataset();
  });

  test('Panelist Filters: Should set dimension selections and search for panelists', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);
    await selectPanelistPage.clickSearchForPanelists();

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should select a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.click250Responses();
  });

  test('Generate Survey: Should fill the prompt and reach the Build Survey page', { tag: '@GenerateSurvey' }, async () => {
    await promptPage.fillPromptAndGenerate('Generate a few questions about product satisfaction');

    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after generating the survey from a prompt');
  });

  // Skipped: isQuestionCountOutOfRange() (question-generator.ts) can only be true if questionCount is set below
  // ADD_MORE_QUESTIONS_DEFAULT_COUNT or above MAX_SURVEY_QUESTIONS, but the niq-slider's own min/max bounds
  // (bound to those same constants) prevent dragging it out of range — no UI path reaches this state.
  test.skip('Question count validation: slider cannot be driven out of range via the UI', { tag: '@GenerateSurvey' }, async () => {
    assertTrue(await promptPage.isQuestionCountErrorVisible(), 'unreachable via UI — see skip reason above');
  });

  test('Generate more questions: Should increase the question count', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.clickGenerateQuestions();
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  // Edited right after generation (no further AI calls touch the title signal before this point — addMoreQuestions()
  // has no title field, unlike the initial generateQuestions() response).
  test('TC_AI_07: Edit the survey title after AI generation', { tag: '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.setSurveyTitle(testData.surveyQuestions.surveyTitle);
    await surveyBuilderPage.commitSurveyTitle();
    const titleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
    assertTrue(titleDisplay === testData.surveyQuestions.surveyTitle, `Expected survey title to update to "${testData.surveyQuestions.surveyTitle}", got "${titleDisplay}"`);
  });

  test('Rephrase with AI: Should clear the loading state and prompt after submit', { tag: '@GenerateSurvey' }, async () => {
    await promptPage.rephraseQuestion(0, 'Make this question more concise');
  });

  test('Suggest new questions: Should increase the question count', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.clickSuggestNewQuestions();
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  test('Describe questions to add: Should increase the question count and close the panel', { tag: '@GenerateSurvey' }, async () => {
    const before = await promptPage.getGeneratedQuestionCount();
    await promptPage.describeAndSubmitReprompt('Add a question about delivery speed');
    const after = await promptPage.getGeneratedQuestionCount(before + 1);
    assertTrue(after > before, `question count increased (before ${before}, after ${after})`);
  });

  // Reuse audit: Build Survey (manual-flow) controls reused as-is against the AI-generated survey, via SurveyBuilderPage
  // on the same basePage/page (same pattern as TC_BS_12 in survey-builder.spec.ts).

  test('TC_BS_07: Required star appears when the Required toggle is on', { tag: '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const index = 0;

    await surveyBuilderPage.setRequired(index, true);
    assertTrue(await surveyBuilderPage.waitForRequiredState(index, true), 'Expected Required star visible after turning Required on');

    await surveyBuilderPage.setRequired(index, false);
    assertTrue(await surveyBuilderPage.waitForRequiredState(index, false), 'Expected Required star hidden after turning Required off');

    await surveyBuilderPage.setRequired(index, true);
    assertTrue(await surveyBuilderPage.waitForRequiredState(index, true), 'Expected Required star visible again after turning Required back on');
  });

  test('Edit question: Should update the question text via the pencil icon', { tag: '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText: newText } = testData.surveyQuestions.nps;

    await surveyBuilderPage.editQuestionText(0, newText);

    const textDisplay = await surveyBuilderPage.getQuestionTextDisplay(0);
    assertTrue(textDisplay.includes(newText), `Expected question text to update to "${newText}", got "${textDisplay}"`);
  });

  test('TC_BS_13/14: Review Mode controls and per-question checkboxes are visible', { tag: '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.ensureQuestionCount(3);
    await surveyBuilderPage.enterReviewMode();

    const controlsVisible = await surveyBuilderPage.areReviewControlsVisible();
    assertTrue(controlsVisible, 'Expected Select All, Expand All, Collapse All, Delete, Exit Review Mode buttons to be visible');

    const questionCount = await surveyBuilderPage.getQuestionCount();
    const checkboxCount = await surveyBuilderPage.getReviewCheckboxCount(questionCount);
    assertTrue(checkboxCount === questionCount, `Expected one checkbox per question (${questionCount}), found ${checkboxCount}`);

    await surveyBuilderPage.selectAll();
    for (let index = 0; index < questionCount; index++) {
      assertTrue(await surveyBuilderPage.isQuestionSelected(index), `Expected checkbox ${index} to be ticked after Select All`);
    }
    await surveyBuilderPage.unselectAll();
    for (let index = 0; index < questionCount; index++) {
      assertTrue(!(await surveyBuilderPage.isQuestionSelected(index)), `Expected checkbox ${index} to clear after Unselect All`);
    }

    await surveyBuilderPage.expandAll();
    await surveyBuilderPage.collapseAll();
    await surveyBuilderPage.exitReviewMode();
  });

  test('TC_BS_14: Review Mode select all, delete, and exit keeps deletions', { tag: '@StartWithPrompt @BuildSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.enterReviewMode();
    const questionCountBeforeDelete = await surveyBuilderPage.getQuestionCount();
    await surveyBuilderPage.selectAll();

    await surveyBuilderPage.deleteSelectedQuestions();
    const questionCountAfterDelete = await surveyBuilderPage.getQuestionCount();
    assertTrue(
      questionCountAfterDelete === 0,
      `Expected all ${questionCountBeforeDelete} questions to be deleted, found ${questionCountAfterDelete} remaining`
    );

    await surveyBuilderPage.exitReviewMode();
    const questionCountAfterExit = await surveyBuilderPage.getQuestionCount();
    assertTrue(questionCountAfterExit === questionCountAfterDelete, 'Expected Build Survey view to keep deletions after exiting Review Mode');
  });
});