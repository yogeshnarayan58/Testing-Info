import { computed, Directive, ElementRef, input, model, OnChanges, SimpleChanges } from '@angular/core';
import { SuggestionTag } from '../../models/build-survey';

/**
 * Base directive for all question editor components.
 * Provides common inputs, outputs, and logic for handling readonly mode,
 * form changes, and document click events.
 */
@Directive({
  host: {
    '(document:click)': 'onDocumentClick($event)'
  }
})
export class BaseQuestionEditorDirective implements OnChanges {
  // Common inputs
  type = input('');
  mode = input<'edit' | 'readonly'>('edit');
  question = model('');
  isRequired = model(false);
  isPreview = input(false);
  isInlineAdd = input(false);
  questionNumber = input(1);
  index = input<number>(0);
  isActive = input(true);
  activeField = input<unknown>(null);
  showSuggestionTags = input(false);
  suggestionCounts = input<SuggestionTag | null>(null);
  // Internal state
  protected isReadonlyBlockEditing = false;
  readonly hasSuggestions = computed(() => {
    const counts = this.suggestionCounts();
    return !!counts && (counts.mandatoryCount > 0 || counts.optionalCount > 0);
  });
  

  constructor(protected elementRef: ElementRef<HTMLElement>) {}

  /**
   * Getter to determine if component is in editing mode.
   * Returns true if mode is 'edit' or if readonly block editing is enabled.
   */
  get isEditingMode(): boolean {
    return this.mode() === 'edit' || this.isReadonlyBlockEditing;
  }

  /**
   * Enable readonly block editing mode.
   * Only works when in preview mode is false and current mode is readonly.
   */
  enableReadonlyBlockEdit(): void {
    if (this.isPreview() || this.mode() !== 'readonly') return;
    this.isReadonlyBlockEditing = true;
  }

  /**
   * Handle document click events to close readonly block editing
   * when clicking outside the component.
   */
  onDocumentClick(event: MouseEvent): void {
    if (!this.isReadonlyBlockEditing || this.mode() !== 'readonly') return;

    const target = event.target as Node | null;
    const isInsideComponent = !!target && this.elementRef.nativeElement.contains(target);

    if (!isInsideComponent) {
      this.isReadonlyBlockEditing = false;
    }
  }

  /**
   * Handle changes to inputs.
   * Resets readonly block editing when mode changes to readonly.
   */
  ngOnChanges(changes: SimpleChanges): void {
    // Reset readonly block editing when mode changes to readonly
    if (changes['mode'] && changes['mode'].currentValue === 'readonly') {
      this.isReadonlyBlockEditing = false;
    }
  }
}
