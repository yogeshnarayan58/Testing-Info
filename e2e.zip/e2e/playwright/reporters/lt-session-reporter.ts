/**
 * Custom Playwright reporter to capture LambdaTest session names.
 * NOTE: This reporter does NOT create sessions - it only captures session names created by
 * BasePageFactory (which uses getLambdaTestBuildName for consistent build naming).
 * Stores test -> session mapping into individual per-test JSON files
 * (test-results/.lt-sessions/test-<id>-<pid>-<timestamp>.json) to avoid concurrent write conflicts.
 *
 * This reporter is a complete no-op when LAMBDATEST !== 'true', so it has zero effect
 * on the default/local test run. All filesystem paths built from dynamic values (session
 * directory, test IDs) are validated via assertContainedDir() / safeJoin() before use.
 */
import { Reporter, TestCase, TestResult, FullResult } from '@playwright/test/reporter';
import * as fs from 'fs';
import * as path from 'path';
import { safeJoin, assertContainedDir } from '../../utils/safe-path';

// Allowlist-sanitize to a safe filename segment (same pattern as
// base-page-factory.ts / globalTeardown.ts's sanitizeId()). Kept as a module-level
// function (not a class method) so it stays inline/traceable at each call site.
const sanitizeTestId = (testId: string): string => testId.replace(/[^a-zA-Z0-9_-]/g, '_');

class LTSessionReporter implements Reporter {
  private testSessions = new Map<string, string>(); // fullName -> sessionName

  onBegin() {
    if (process.env.LAMBDATEST !== 'true') return;

    console.log('[LT Reporter] Initialized - capturing LambdaTest sessions...');
  }

  onTestBegin(test: TestCase) {
    if (process.env.LAMBDATEST !== 'true') return;

    // NOTE: process.env / global set here are NOT visible to base-page-factory.ts -
    // this reporter runs in Playwright's main process, while test files (and
    // BasePageFactory.createBasePage()) run in separate per-worker child processes.
    // base-page-factory.ts now reads test.info().testId directly instead, which is
    // reliable because it executes in the same process as the running test.
    console.log(`[LT Reporter] Test started: "${test.title}" (testId: ${test.id})`);
  }

  onTestEnd(test: TestCase, result: TestResult) {
    if (process.env.LAMBDATEST !== 'true') return;

    const testId = test.id;
    const testResultsDir = path.resolve('test-results');
    const safeSessionDir = assertContainedDir(
      testResultsDir,
      path.join(testResultsDir, '.lt-sessions')
    );
    // testId sanitized for path safety; safeJoin() also rejects degenerate (empty/all-underscore) segments
    const sanitizedTestId = sanitizeTestId(testId);
    const testSessionFile = safeJoin(safeSessionDir, `test-${sanitizedTestId}.json`);

    let sessionName: string | null = null;

    try {
      // 1st priority: test-specific session file
      if (fs.existsSync(testSessionFile)) {
        // #cycode_sast_ignore_here Path validated by safeJoin() before use
        const data = JSON.parse(fs.readFileSync(testSessionFile, 'utf-8'));
        sessionName = data.sessionName;

        // cleanup
        try {
          // #cycode_sast_ignore_here Path validated by safeJoin() before use
          fs.unlinkSync(testSessionFile);
        } catch {
          /* ignore cleanup failure */
        }
      }

      // fallback: sessions.jsonl
      if (!sessionName) {
        // sessions.jsonl path routed through safeJoin() for consistency with other fs sinks in this file
        const sessionsLogFile = safeJoin(safeSessionDir, 'sessions.jsonl');
        // Not used in a file path, only used for in-memory matching against sessions.jsonl entries.
        const workerIndex = result.parallelIndex ?? 0;
        const testStartTime = result.startTime?.getTime() || 0;

        if (fs.existsSync(sessionsLogFile)) {
          // #cycode_sast_ignore_here Path validated via safeJoin() - resolves and verifies containment within base directory before use
          const lines = fs.readFileSync(sessionsLogFile, 'utf-8').split('\n').filter(Boolean);

          let bestMatch: { sessionName: string; diff: number } | null = null;

          for (const line of lines) {
            try {
              const s = JSON.parse(line);
              // Guard against malformed/non-numeric timestamp or workerIndex
              // values read back from disk before they drive any matching
              // logic - this data was written by this same codebase, but is
              // still external to this function once round-tripped through
              // a file.
              const sTimestamp = Number(s.timestamp);
              const sWorkerIndex = Number(s.workerIndex);
              if (
                Number.isFinite(sTimestamp) &&
                Number.isFinite(sWorkerIndex) &&
                sWorkerIndex === workerIndex &&
                testStartTime
              ) {
                const diff = Math.abs(sTimestamp - testStartTime);
                if (diff < 60000 && (!bestMatch || diff < bestMatch.diff)) {
                  bestMatch = { sessionName: s.sessionName, diff };
                }
              }
            } catch {
              /* ignore malformed line */
            }
          }

          if (bestMatch) sessionName = bestMatch.sessionName;
        }
      }
    } catch (err) {
      console.error('[LT Reporter] Error reading session:', err);
    }

    if (!sessionName) {
      console.warn(`[LT Reporter] No session found for "${test.title}" (testId: ${testId})`);
      return;
    }

    const fullName = test.titlePath().filter(Boolean).join(' › ');
    // Normalize > separator to › for consistent mapping with globalTeardown
    const normalizedFullName = fullName.replace(/\s*>\s*/g, ' › ');

    this.testSessions.set(normalizedFullName, sessionName);

    console.log(`[LT Reporter] Stored: "${normalizedFullName}" -> ${sessionName}`);

    // Write mapping per test/worker to avoid concurrent write conflicts
    try {
      // #cycode_sast_ignore_here Path validated via assertContainedDir() above - resolves and verifies containment within test-results/
      fs.mkdirSync(safeSessionDir, { recursive: true });

      // Collision-resistant filename per test/process; safeJoin() canonicalizes and verifies containment on the raw testId segment
      const mappingFile = safeJoin(safeSessionDir, `test-${sanitizedTestId}-${process.pid}-${Date.now()}.json`);
      if (!mappingFile.endsWith('.json')) {
        throw new Error(`Refusing to write non-.json mapping file: ${mappingFile}`);
      }
      // #cycode_sast_ignore_here Path validated via safeJoin() with .json extension re-checked immediately above
      fs.writeFileSync(
        mappingFile,
        JSON.stringify(
          {
            testName: test.title,
            fullName: normalizedFullName,
            testId,
            sessionName,
            timestamp: Date.now(),
          },
          null,
          2
        ),
        'utf-8'
      );

      console.log(`[LT Reporter] Mapping written to ${path.basename(mappingFile)}`);
    } catch (err) {
      console.error('[LT Reporter] Failed to write mapping:', err);
    }
  }

  onEnd(result: FullResult) {
    if (process.env.LAMBDATEST !== 'true') return;

    if (this.testSessions.size === 0) {
      console.warn('[LT Reporter] No sessions captured.');
      return;
    }

    try {
      const testResultsDir = path.resolve('test-results');
      const safeSessionDir = assertContainedDir(
        testResultsDir,
        path.join(testResultsDir, '.lt-sessions')
      );
      // #cycode_sast_ignore_here Path validated via assertContainedDir() above - resolves and verifies containment within test-results/
      fs.mkdirSync(safeSessionDir, { recursive: true });

      // #cycode_sast_ignore_here safeSessionDir validated via assertContainedDir() above; 'session-mappings.json' is a hardcoded literal filename
      const mappingFile = path.join(safeSessionDir, 'session-mappings.json');
      // #cycode_sast_ignore_here mappingFile built from a hardcoded literal filename joined onto the assertContainedDir()-verified session directory
      fs.writeFileSync(mappingFile, JSON.stringify(Object.fromEntries(this.testSessions), null, 2));

      console.log(`[LT Reporter] Saved ${this.testSessions.size} session mappings.`);
    } catch (err) {
      console.error('[LT Reporter] Failed to save mappings:', err);
    }
  }

}

export default LTSessionReporter;
