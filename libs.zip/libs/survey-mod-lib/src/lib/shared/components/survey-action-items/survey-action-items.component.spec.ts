import { TestBed } from '@angular/core/testing';
import { BreakpointObserver } from '@angular/cdk/layout';
import { By } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs';
import { NO_ERRORS_SCHEMA, signal } from '@angular/core';
import template from './survey-action-items.component.html?raw';
import { describe, expect, it, vi } from 'vitest';
import { SurveyActionItemsComponent } from './survey-action-items.component';
import { SurveyActionItem } from './survey-action-items.model';

vi.mock('@nielseniq/athena-core', () => ({
  ButtonModule: class {},
  LinkModule: class {},
  TooltipModule: class {},
}));

interface Item { id: string; kind: 'a' | 'b' }

const ACTIONS: SurveyActionItem<Item>[] = [
  { id: 'always', label: 'Always', iconName: 'info' },
  { id: 'single', label: 'Single', iconName: 'edit', isVisible: (items) => items.length === 1 },
  { id: 'only-b', label: 'Only B', iconName: 'share', isVisible: (items) => items.every((item) => item.kind === 'b') },
];

function createComponent(selectedItems: Item[], actions = ACTIONS, width = 1280) {
  TestBed.resetTestingModule();
  const viewport = new BehaviorSubject({ matches: width <= 1279 });
  const observe = vi.fn().mockReturnValue(viewport);
  TestBed.configureTestingModule({
    providers: [{ provide: BreakpointObserver, useValue: { observe } }],
  });
  TestBed.overrideComponent(SurveyActionItemsComponent, {
    set: { template, templateUrl: undefined, styleUrl: undefined, imports: [], schemas: [NO_ERRORS_SCHEMA] },
  });
  const fixture = TestBed.createComponent(SurveyActionItemsComponent<Item>);
  // Signal inputs aren't registered under plain JIT, so swap in writable signals.
  const inputs = {
    selectedItems: signal<readonly Item[]>(selectedItems),
    actions: signal<readonly SurveyActionItem<Item>[]>(actions),
    selectedCountLabel: signal('Assets selected'),
    deselectLabel: signal('Deselect'),
    forceIconsOnly: signal(false),
    activeActionId: signal<string | null>(null),
  };
  for (const [key, value] of Object.entries(inputs)) {
    Object.defineProperty(fixture.componentInstance, key, { value });
  }
  fixture.detectChanges();
  return Object.assign(fixture, { inputs, viewport, observe });
}

describe('SurveyActionItemsComponent', () => {
  it('renders nothing when no items are selected', () => {
    const fixture = createComponent([]);
    expect(fixture.componentInstance.selectedCount()).toBe(0);
    expect(fixture.componentInstance.visibleActions()).toEqual([]);
    expect(fixture.nativeElement.querySelector('[data-test-id="survey-action-items"]')).toBeNull();
  });

  it('shows the selected count and only actions whose visibility predicate passes', () => {
    const fixture = createComponent([{ id: '1', kind: 'a' }]);
    const element: HTMLElement = fixture.nativeElement;

    expect(element.querySelector('[data-test-id="survey-action-items-count"]')?.textContent?.trim())
      .toBe('Assets selected: 1 |');
    expect(fixture.componentInstance.visibleActions().map((action) => action.id)).toEqual(['always', 'single']);
    expect(element.querySelector('[data-test-id="survey-action-item-single"]')).not.toBeNull();
    expect(element.querySelector('[data-test-id="survey-action-item-only-b"]')).toBeNull();
  });

  it('re-evaluates visibility for multi selection', () => {
    const fixture = createComponent([{ id: '1', kind: 'b' }, { id: '2', kind: 'b' }]);
    expect(fixture.componentInstance.visibleActions().map((action) => action.id)).toEqual(['always', 'only-b']);
  });

  it('supports custom labels', () => {
    const fixture = createComponent([{ id: '1', kind: 'a' }]);
    fixture.inputs.selectedCountLabel.set('Items selected');
    fixture.inputs.deselectLabel.set('Clear');
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;

    expect(element.querySelector('[data-test-id="survey-action-items-count"]')?.textContent?.trim()).toBe('Items selected: 1 |');
    expect(element.querySelector('[data-test-id="survey-action-items-deselect"]')?.textContent?.trim()).toBe('Clear');
  });

  it('emits deselectAll when the deselect control is clicked', () => {
    const fixture = createComponent([{ id: '1', kind: 'a' }]);
    const emitSpy = vi.spyOn(fixture.componentInstance.deselectAll, 'emit');

    (fixture.nativeElement.querySelector('[data-test-id="survey-action-items-deselect"]') as HTMLButtonElement).click();

    expect(emitSpy).toHaveBeenCalledOnce();
  });

  it('emits the clicked action with the current selection', () => {
    const items: Item[] = [{ id: '1', kind: 'a' }];
    const fixture = createComponent(items);
    const emitSpy = vi.spyOn(fixture.componentInstance.actionClick, 'emit');

    fixture.componentInstance.onActionClick(ACTIONS[1]);

    expect(emitSpy).toHaveBeenCalledWith({ actionId: 'single', items });
  });

  it.each([1279, 1280])('uses the Landing Page breakpoint at a width of %s', (width) => {
    const fixture = createComponent([{ id: '1', kind: 'a' }], ACTIONS, width);
    expect(fixture.observe).toHaveBeenCalledExactlyOnceWith('(max-width: 1279px)');
    expect(fixture.nativeElement.querySelector('.action-items').classList.contains('icons-only'))
      .toBe(width < 1280);
    const button = fixture.debugElement.query(By.css('[data-test-id="survey-action-item-single"]'));
    expect(button.properties['showTooltip']).toBe(width < 1280);
    expect(button.properties['niqTooltip']).toBe('Single');
    expect(button.nativeElement.querySelector('.action-label').textContent).toBe('Single');
    expect(button.properties['iconName']).toBe('edit');
  });

  it('updates icon-only mode and tooltips when the viewport changes in either direction', () => {
    const fixture = createComponent([{ id: '1', kind: 'a' }]);
    const toolbar: HTMLElement = fixture.nativeElement.querySelector('.action-items');
    for (const matches of [true, false]) {
      fixture.viewport.next({ matches });
      fixture.detectChanges();
      expect(toolbar.classList.contains('icons-only')).toBe(matches);
      expect(fixture.debugElement.query(By.css('.action-item')).properties['showTooltip']).toBe(matches);
    }
  });

  it('forces icon-only mode on a wide viewport when requested', () => {
    const fixture = createComponent([{ id: '1', kind: 'a' }]);
    fixture.inputs.forceIconsOnly.set(true);
    fixture.detectChanges();

    expect(fixture.componentInstance.iconsOnly()).toBe(true);
    expect(fixture.nativeElement.querySelector('.action-items').classList.contains('icons-only')).toBe(true);
    expect(fixture.debugElement.query(By.css('.action-item')).properties['showTooltip']).toBe(true);
  });

  it('highlights only the active action', () => {
    const fixture = createComponent([{ id: '1', kind: 'a' }]);
    const button = (id: string) => fixture.debugElement.query(By.css(`[data-test-id="survey-action-item-${id}"]`));
    expect(button('always').properties['state']).toBe('default');

    fixture.inputs.activeActionId.set('always');
    fixture.detectChanges();

    expect(button('always').properties['state']).toBe('active');
    expect(button('always').nativeElement.getAttribute('aria-pressed')).toBe('true');
    expect(button('single').properties['state']).toBe('default');
    expect(button('single').nativeElement.hasAttribute('aria-pressed')).toBe(false);
  });

  it('preserves action and deselect clicks in icon-only mode', () => {
    const items: Item[] = [{ id: '1', kind: 'a' }];
    const fixture = createComponent(items, ACTIONS, 1024);
    const action = vi.spyOn(fixture.componentInstance.actionClick, 'emit');
    const deselect = vi.spyOn(fixture.componentInstance.deselectAll, 'emit');
    fixture.nativeElement.querySelector('[data-test-id="survey-action-item-single"]').click();
    fixture.nativeElement.querySelector('[data-test-id="survey-action-items-deselect"]').click();
    expect(action).toHaveBeenCalledExactlyOnceWith({ actionId: 'single', items });
    expect(deselect).toHaveBeenCalledOnce();
  });

  it('releases the viewport subscription on destruction', () => {
    const fixture = createComponent([]);
    expect(fixture.viewport.observed).toBe(true);
    fixture.destroy();
    expect(fixture.viewport.observed).toBe(false);
  });
});
