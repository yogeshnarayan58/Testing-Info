import { HttpHeaders, HttpParams, provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { ApiService } from './api.service';

describe('ApiService', () => {
  let api: ApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    api = TestBed.inject(ApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('shares concurrent GETs and replays successful responses to later callers', () => {
    const responses: unknown[] = [];
    const request = api.get('/items');
    request.subscribe(value => responses.push(value));
    api.get('/items').subscribe(value => responses.push(value));
    http.expectOne('/items').flush({ id: 1 });
    request.subscribe(value => responses.push(value));
    api.get('/items').subscribe(value => responses.push(value));
    expect(responses).toEqual(Array(4).fill({ id: 1 }));
    http.expectNone('/items');
  });

  it('waits for subscription before issuing a GET', () => {
    api.get('/items');
    http.expectNone('/items');
  });

  it.each(['post', 'put'] as const)('shares cached %s requests and replays the result after firstValueFrom', async method => {
    const first = firstValueFrom(api[method]('/assets', { page: 1, sort: { field: 'DATE', order: 'DESC' } }, { cache: true }));
    const second = firstValueFrom(api[method]('/assets', { sort: { order: 'DESC', field: 'DATE' }, page: 1 }, { cache: true }));
    const pending = http.expectOne('/assets');
    expect(pending.request.method).toBe(method.toUpperCase());
    pending.flush({ assets: [{ id: 'survey-1' }] });
    const expected = { assets: [{ id: 'survey-1' }] };
    expect(await first).toEqual(expected);
    expect(await second).toEqual(expected);
    expect(await firstValueFrom(api[method]('/assets', { page: 1, sort: { field: 'DATE', order: 'DESC' } }, { cache: true })))
      .toEqual(expected);
    http.expectNone('/assets');
  });

  it.each(['post', 'put'] as const)('separates cached %s payloads and GETs at the same URL', method => {
    api[method]('/assets', { page: 1 }, { cache: true }).subscribe();
    api[method]('/assets', { page: 2 }, { cache: true }).subscribe();
    api.get('/assets').subscribe();
    const requests = http.match('/assets');
    expect(requests).toHaveLength(3);
    requests.forEach(request => request.flush([]));
  });

  it.each(['post', 'put'] as const)('continues cached %s requests when a subscription is cancelled', method => {
    const subscription = api[method]('/assets', { page: 1 }, { cache: true }).subscribe();
    const pending = http.expectOne('/assets');
    subscription.unsubscribe();
    expect(pending.cancelled).toBe(false);
    api[method]('/assets', { page: 1 }, { cache: true }).subscribe();
    http.expectNone('/assets');
    pending.flush([]);
  });

  it.each(['post', 'put'] as const)('evicts failed cached %s requests so they can be retried', method => {
    api[method]('/assets', {}, { cache: true }).subscribe({ error: () => undefined });
    http.expectOne('/assets').flush('Unavailable', { status: 503, statusText: 'Unavailable' });
    api[method]('/assets', {}, { cache: true }).subscribe();
    http.expectOne('/assets').flush([]);
  });

  it.each(['post', 'put'] as const)('clears every cached %s payload variant for a URL', method => {
    api[method]('/assets', { page: 1 }, { cache: true }).subscribe();
    api[method]('/assets', { page: 2 }, { cache: true }).subscribe();
    http.match('/assets').forEach(request => request.flush([]));
    api.clearCache('/assets');
    api[method]('/assets', { page: 1 }, { cache: true }).subscribe();
    api[method]('/assets', { page: 2 }, { cache: true }).subscribe();
    const requests = http.match('/assets');
    expect(requests).toHaveLength(2);
    requests.forEach(request => request.flush([]));
  });

  it('clears only cached requests with the matching tag', () => {
    api.post('/assets', { page: 1 }, { cache: true, cacheTag: 'my-assets:recent:root' }).subscribe();
    api.post('/assets', { page: 1 }, { cache: true, cacheTag: 'my-assets:my-assets:folder-1' }).subscribe();
    http.match('/assets').forEach(request => request.flush([]));

    api.clearCache('/assets', 'my-assets:recent:root');
    api.post('/assets', { page: 1 }, { cache: true, cacheTag: 'my-assets:recent:root' }).subscribe();
    api.post('/assets', { page: 1 }, { cache: true, cacheTag: 'my-assets:my-assets:folder-1' }).subscribe();

    const requests = http.match('/assets');
    expect(requests).toHaveLength(1);
    requests[0].flush([]);
  });

  it('uses equivalent parameter and header objects as the same cache key', () => {
    api.get('/items', { params: { page: 1, size: 10 }, headers: { Accept: 'application/json' } }).subscribe();
    http.expectOne('/items?page=1&size=10').flush([]);
    api.get('/items', {
      params: new HttpParams().set('size', 10).set('page', 1),
      headers: new HttpHeaders({ accept: 'application/json' }),
    }).subscribe();
    http.expectNone(() => true);
  });

  it('keeps cached POST and PUT responses separate for the same URL and body', () => {
    api.post('/items', { id: 1 }, { cache: true }).subscribe();
    api.put('/items', { id: 1 }, { cache: true }).subscribe();
    const requests = http.match('/items');
    expect(requests.map(request => request.request.method)).toEqual(['POST', 'PUT']);
    requests.forEach(request => request.flush({ success: true }));
  });

  it('separates URLs, parameters, headers and credential modes', () => {
    api.get('/items').subscribe();
    api.get('/other').subscribe();
    api.get('/items', { params: { page: 2 } }).subscribe();
    api.get('/items', { headers: { Authorization: 'Bearer example' } }).subscribe();
    api.get('/items', { withCredentials: true }).subscribe();
    const requests = http.match(() => true);
    expect(requests).toHaveLength(5);
    requests.forEach(request => request.flush([]));
  });

  it('evicts failed GETs and preserves errors for callers', () => {
    let status: number | undefined;
    const request = api.get('/items');
    request.subscribe({ error: error => status = error.status });
    http.expectOne('/items').flush('Unavailable', { status: 503, statusText: 'Unavailable' });
    expect(status).toBe(503);
    request.subscribe();
    http.expectOne('/items').flush([]);
  });

  it('bypasses an existing cache entry when cache is false', () => {
    api.get('/items').subscribe();
    http.expectOne('/items').flush({ value: 'cached' });
    api.get('/items', { cache: false }).subscribe();
    http.expectOne('/items').flush({ value: 'fresh' });
    let result: unknown;
    api.get('/items').subscribe(value => result = value);
    expect(result).toEqual({ value: 'cached' });
  });

  it('clears every parameter variant for a URL and retains other URLs', () => {
    api.get('/items', { params: { page: 1 } }).subscribe();
    api.get('/items', { params: { page: 2 } }).subscribe();
    api.get('/other').subscribe();
    http.match(() => true).forEach(request => request.flush([]));
    api.clearCache('/items');
    api.get('/other').subscribe();
    http.expectNone('/other');
    api.get('/items', { params: { page: 1 } }).subscribe();
    api.get('/items', { params: { page: 2 } }).subscribe();
    const requests = http.match(() => true);
    expect(requests).toHaveLength(2);
    requests.forEach(request => request.flush([]));
  });

  it('clears the entire cache including previously created GET observables', () => {
    const request = api.get('/items');
    request.subscribe();
    http.expectOne('/items').flush([]);
    api.clearCache();
    request.subscribe();
    http.expectOne('/items').flush([]);
  });

  it.each(['post', 'put', 'delete'] as const)('forwards %s without caching and preserves options', method => {
    const options = { params: { id: 1 }, headers: { 'X-Request': 'example' }, withCredentials: true };
    for (let index = 0; index < 2; index++) {
      const request = method === 'delete'
        ? api.delete('/items', options) : api[method]('/items', { title: 'Survey' }, options);
      request.subscribe();
      const pending = http.expectOne('/items?id=1');
      expect(pending.request.method).toBe(method.toUpperCase());
      expect(pending.request.withCredentials).toBe(true);
      expect(pending.request.headers.get('X-Request')).toBe('example');
      expect(pending.request.body).toEqual(method === 'delete' ? null : { title: 'Survey' });
      pending.flush({ success: true });
    }
  });

  it('does not retry writes automatically and passes their errors to the caller', () => {
    let status: number | undefined;
    api.post('/items', {}).subscribe({ error: error => status = error.status });
    http.expectOne('/items').flush('Failure', { status: 500, statusText: 'Failure' });
    expect(status).toBe(500);
    http.expectNone('/items');
  });
});
