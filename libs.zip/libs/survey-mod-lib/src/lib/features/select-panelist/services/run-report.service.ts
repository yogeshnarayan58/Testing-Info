import { ApiService } from '../../../shared/services/api.service';
import { HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { CpfService, RequestInstance } from '@nielsen/crf-common';
import { ToastService } from '@nielseniq/athena-core';
import { EnvironmentConfig, RequestTrackingService } from '@nielseniq/crf-discover-fe-core';
import { BehaviorSubject, catchError, finalize, map, Observable, of, ReplaySubject, Subject, takeUntil } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { ReportSelection } from '../../build-survey/models/build-survey';
import { createSurveyPanelistReportPayload, SurveyPanelistReportPayload } from '../models/report-payload.model';
import { SelectPanelistUtilsService } from '../utils.service';
import { TranslateService } from '@ngx-translate/core';
@Injectable({
  providedIn: 'root',
})
export class RunReportService {
  private readonly environmentConfig = inject(EnvironmentConfig);
  public reportingResponse: Subject<any> = new Subject<any>();
  public reportCompleted$: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  public reportPayload: SurveyPanelistReportPayload = {} as SurveyPanelistReportPayload;

  public asyncInProgress = false;
  public executionJobIds: any[] = [];
  public lastJobId: string | null = null;

  DEFAULT_DELAY_PERIOD = 1200;
  stoprun: Subject<void> = new Subject<void>();
  private pollingTimer: ReturnType<typeof setTimeout> | undefined;

  constructor(
    private readonly api: ApiService,
    private readonly cpfService: CpfService,
    private readonly requestTrackingService: RequestTrackingService,
    private readonly toastService: ToastService,
    private readonly selectPanelistUtilsService: SelectPanelistUtilsService,
    private readonly surveyCommonService: SurveyCommonService,
    private readonly translate: TranslateService
  ) { }

  /**
   * Initiates an asynchronous report execution workflow.
   * Prepares the report payload with dimension selections, sends it to the async API,
   * extracts the job ID from response, and starts polling for job status updates.
   * 
   * @returns void - Sets asyncInProgress flag and initiates polling via startPolling()
   */
  runReport(skipLoadPackage = false): Observable<string> {
    const completion = new ReplaySubject<string>(1);
    this.asyncInProgress = true;
    if (Object.keys(this.reportPayload)?.length === 0) {
      this.buildReportPayload();
    }
    if (skipLoadPackage) {
      this.setPublishFactVisibility();
    }
    if (skipLoadPackage || !this.reportPayload.jobId) {
      this.reportPayload.jobId = uuidv4();
    }
    this.requestAsync(this.reportPayload)
      .pipe(
        takeUntil(this.stoprun),
        catchError((err: HttpErrorResponse) => {
          this.stopPolling('ERROR');
          completion.error(err);
          return of(null);
        }),
      )
      .subscribe((results: any) => {
        if (!results) return;
        this.executionJobIds = [];
        const jobId = results?.data?.jobId;
        this.lastJobId = jobId ?? null;
        this.executionJobIds.push(jobId);
        this.startPolling(this.DEFAULT_DELAY_PERIOD, skipLoadPackage, completion);
      });
    return completion.asObservable();
  }

  private buildReportPayload(): void {
    const panelistDataSelectorState = this.surveyCommonService.getPanelistDataSelectorState() ?? {};
    this.reportPayload = createSurveyPanelistReportPayload({
      jobId: this.lastJobId,
      reportSpec: panelistDataSelectorState.reportSpec,
      requestInstance: panelistDataSelectorState.requestInstance,
    });
  }

  private setPublishFactVisibility(): void {
    const visibilityById: Record<string, string> = {
      THL_UNIQUE_HOUSEHOLD_COUNT_O: 'true',
      THL_HOUSEHOLD_ID: 'false',
    };
    const requestInstance = this.reportPayload.requestInstance as RequestInstance;
    const dimensionSelections = requestInstance['dimensionSelections'] as ReportSelection[] | undefined;
    const factColumn = this.findNestedSelection(dimensionSelections ?? [], ['FCT', 'CHR', 'FCT_COL_NM']);
    (factColumn?.children ?? []).forEach((factValue) => {
      const visibility = factValue.id ? visibilityById[factValue.id] : undefined;
      const isHidden = factValue.attributes?.find(attribute => attribute.name === 'isHidden');
      if (visibility !== undefined && isHidden) {
        isHidden.value = visibility;
      }
    });
  }

  private findNestedSelection(selections: ReportSelection[], path: string[]): ReportSelection | undefined {
    let children = selections;
    let matched: ReportSelection | undefined;

    for (const id of path) {
      matched = children.find(selection => selection.id === id);
      if (!matched) return undefined;
      children = matched.children ?? [];
    }

    return matched;
  }

  /**
   * Polls for job status updates at regular intervals with random jitter.
   * Handles COMPLETED, ERROR, and IN_PROGRESS statuses appropriately.
   * Reschedules itself if asyncInProgress is true and all jobs are not yet complete.
   * 
   * @param delay - Poll delay in milliseconds (defaults to DEFAULT_DELAY_PERIOD of 1200ms)
   * @returns void - Subscribes to job status Observable and manages polling loop
   */
  startPolling(delay = this.DEFAULT_DELAY_PERIOD, skipLoadPackage = false, completion?: ReplaySubject<string>) {
    this.cpfService.getJobStatuses(this.executionJobIds, this.requestTrackingService.getTransactionId())
      .pipe(takeUntil(this.stoprun))
      .subscribe({
        next: (allStatusResponse: any) => {
          Object.keys(allStatusResponse)?.forEach((jobId) => {
            const status = allStatusResponse[jobId]?.data;

            if (status != 'IN_PROGRESS') {
              this.executionJobIds = this.executionJobIds.filter((key) => key !== jobId);
              if (this.executionJobIds?.length === 0) {
                if (status === 'COMPLETED') {
                  this.asyncInProgress = false;
                  if (this.lastJobId) {
                    completion?.next(this.lastJobId);
                    completion?.complete();
                  }
                } else {
                  this.stopPolling();
                }
              }
            }
            if (status === 'COMPLETED' && !skipLoadPackage) {
              this.loadPackage(jobId);
            } else if (status === 'ERROR') {
              this.toastService.InsertToast('error', allStatusResponse[jobId]?.errorMessage, {
                dismissAfter: 8000,
                size: 'large',
              });
              completion?.error(new Error(allStatusResponse[jobId]?.errorMessage || this.translate.instant('SURVEYMOD_PANELIST_COUNT_JOB_FAILED')));
            }
          });
        },
        error: (error: HttpErrorResponse) => {
          this.toastService.InsertToast('error', error?.error?.errorMessage, {
            dismissAfter: 8000,
            size: 'large',
          });
          this.stopPolling('ERROR');
          completion?.error(error);
        },
        complete: () => {
          if (this.asyncInProgress) {
            // Track the next poll so reset can cancel it; clear the handle once the timer fires.
            this.pollingTimer = setTimeout(() => {
              this.pollingTimer = undefined;
              this.startPolling(this.selectPanelistUtilsService.getNextDelay(this.DEFAULT_DELAY_PERIOD), skipLoadPackage, completion);
            }, delay);
          }
        },
      });
  }

  /**
   * Loads the completed report data package for a given job ID.
   * Emits result to reportingResponse Subject and reportCompleted$ BehaviorSubject.
   * Handles load errors by calling stopPolling.
   * 
   * @param jobId - The unique job identifier returned from async execution
   * @returns void - Subscribes to loadReportDataPackage Observable internally
   */
  private loadPackage(jobId: string) {
    this.loadReportDataPackage(jobId, undefined, true)
      .pipe(
        takeUntil(this.stoprun),          // Prevent a previous survey's pending report response from updating the new survey.
        finalize(() => {
          this.surveyCommonService.setDataselectorLoading(false);
        })
      )
      .subscribe({
        next: (result) => {
          this.reportingResponse.next(result);
          this.reportCompleted$.next(result);
        },
        error: () => {
          this.stopPolling('ERROR');
        },
      });
  }

  /**
   * Fetches the report data package for a completed job.
   * Supports both grid/KPI (reportingDetails) and standard report (reports) endpoints.
   * Includes X-NLSN-TNXN-ID header for transaction tracking.
   * 
   * @param jobId - The job identifier for report package lookup
   * @param requestPayload - Optional payload object (defaults to empty object)
   * @param isGridOrKpi - Flag to determine endpoint: true for reportingDetailsUrl, false for reportsUrl (default: true)
   * @returns Observable emitting the report data package from HTTP POST response
   */
   public loadReportDataPackage(jobId: string, requestPayload: object = {}, isGridOrKpi = true): Observable<object> {
    const url = isGridOrKpi ? `${this.environmentConfig.shareDialogUrl?.feServiceUrl}/getReportingDetails` : this.environmentConfig.apiUrls.reportingServices;
    const payloadUrl = `${url}/${jobId}`;
    const options = {
      headers: {
        'X-NLSN-TNXN-ID': this.requestTrackingService.getTransactionId(),
      },
    };
    const requestBody = { ...requestPayload, slice: [] };
    return this.api.post(payloadUrl, requestBody, options);
  }

  /**
   * Sends the report payload to the async job manager API for processing.
   * 
   * @param payloads - The report payload object containing request instance and configuration
   * @returns Observable emitting the async execution response with job ID
   */
  requestAsync(payloads: any): any {
    return this.api.post(`${this.environmentConfig.apiUrls.apiAsync}/job/execute/async`, payloads);
  }



  /**
   * Stops the polling loop and optionally displays an error toast.
   * Clears asyncInProgress flag and signals stoprun Subject to cancel subscriptions.
   * 
   * @param status - Optional status code: 'ERROR' or 'CANCEL' triggers error toast display
   * @returns void - Stops polling and cleans up async operation state
   */
  stopPolling(status?: string) {
    this.asyncInProgress = false;
    //clearing the polling timer so old polling cannot restart.
    clearTimeout(this.pollingTimer);
    this.pollingTimer = undefined;
    this.stoprun.next();
    if (status === 'ERROR' || status === 'CANCEL') {
      this.toastService.InsertToast('error', this.translate.instant('SURVEYMOD_ERROR'), {
        dismissAfter: 8000,
        size: 'large',
      });
    }
  }

  /**
   * Resets the report completion state by emitting null to reportCompleted$ BehaviorSubject.
   * Used to clear completed report state and allow new report submissions.
   * 
   * @returns void - Sets reportCompleted$ to null
   */
  resetReportCompleted(): void {
    this.reportCompleted$.next(null);
  }

  // Stop previous report work before clearing survey-specific job and result state.
  reset(): void {
    this.stopPolling();
    this.reportPayload = {} as SurveyPanelistReportPayload;
    this.executionJobIds = [];
    this.lastJobId = null;
    this.resetReportCompleted();
  }

  /**
   * Prepares payload for multi-character value retrieval by setting dataset context.
   * Updates request context with dataset ID, dataView ID, and stack ID.
   * Posts to the characteristic values multi-char endpoint for dimension value lookup.
   * 
   * @param payload - The request payload containing characteristic request details
   * @param datasetDetails - Object containing dataset ID, dataView, and stack ID for context
   * @returns Observable emitting the multi-character values response or error
   */
  triggerValuesMultiChar(payload: any, datasetDetails: any): any {
    payload.requestContext.datasetId = datasetDetails?.id;
    payload.requestContext.dataViewId = datasetDetails?.dataView.dataViewId
    payload.requestContext.datasetStackId = datasetDetails?.stackId

    const url = `${this.environmentConfig.apiUrls.cpf}/characteristic/values:multiChar`;
    return this.api.post(url, payload).pipe(
      map((response: any) => {
        return response;
      }),
      catchError((errorResponse: any) => {
        return of(errorResponse);
      })
    );

  }


}
