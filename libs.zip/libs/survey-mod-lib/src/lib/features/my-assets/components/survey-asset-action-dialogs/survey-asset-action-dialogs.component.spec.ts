import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { of, Subject, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ToastService } from '@nielseniq/athena-core';
import { SurveyGridRow } from '../../models/survey-asset.model';
import { SurveyAssetActionsService } from '../../services/survey-asset-actions.service';
import { SurveyAssetActionDialogsComponent } from './survey-asset-action-dialogs.component';
import template from './survey-asset-action-dialogs.component.html?raw';

vi.mock('@nielsen/crf-ui-components', () => ({ TreeForderSelectorModule: class {} }));
vi.mock('../../services/survey-asset-actions.service', () => ({ SurveyAssetActionsService: class {} }));
vi.mock('@nielseniq/athena-core', () => ({
  ButtonModule: class {}, DialogModule: class {}, SpinnerModule: class {}, TabModule: class {},
  TextFieldModule: class {}, ToastService: class {},
}));

describe('SurveyAssetActionDialogsComponent', () => {
  let component: SurveyAssetActionDialogsComponent;
  let actions: {
    renameAsset: ReturnType<typeof vi.fn>;
    fetchMoveFolders: ReturnType<typeof vi.fn>;
    moveAssets: ReturnType<typeof vi.fn>;
  };
  let toast: { InsertToast: ReturnType<typeof vi.fn> };
  const row: SurveyGridRow = {
    assetId: 'survey-1', assetType: 'DISCOVERSURVEY', title: 'Survey', lastModifiedTimestamp: 0,
  };
  const folder = { assetId: 'folder-1', assetType: 'DISCOVERFOLDER', title: 'Folder' };
  const dialog = () => ({ open: vi.fn(), close: vi.fn() });
  let renameDialog: ReturnType<typeof dialog>;
  let folderDialog: ReturnType<typeof dialog>;
  let confirmDialog: ReturnType<typeof dialog>;

  beforeEach(() => {
    actions = {
      renameAsset: vi.fn().mockReturnValue(of({})),
      fetchMoveFolders: vi.fn().mockReturnValue(of([folder])),
      moveAssets: vi.fn().mockReturnValue(of({})),
    };
    toast = { InsertToast: vi.fn() };
    TestBed.configureTestingModule({ providers: [
      { provide: SurveyAssetActionsService, useValue: actions },
      { provide: ToastService, useValue: toast },
    ] });
    TestBed.overrideComponent(SurveyAssetActionDialogsComponent, {
      set: { template, templateUrl: undefined, styleUrl: undefined, imports: [], schemas: [NO_ERRORS_SCHEMA] },
    });
    component = TestBed.runInInjectionContext(() => new SurveyAssetActionDialogsComponent());
    renameDialog = dialog();
    folderDialog = dialog();
    confirmDialog = dialog();
    Object.assign(component, { renameDialog, folderDialog, confirmDialog });
  });

  it('prefills and resets Rename for the selected asset', () => {
    component.renameError.set('Previous error');
    component.openRename(row);
    expect(component.renameTitle()).toBe(row.title);
    expect(component.renameError()).toBe('');
    expect(renameDialog.open).toHaveBeenCalledOnce();
  });

  it.each([
    ['', 'required'],
    [' Leading space', 'empty spaces at the start'],
    [' '.repeat(10), 'empty spaces at the start'],
    ['a'.repeat(151), '150 characters'],
    ['a'.repeat(150), ''],
    ['Valid / name & symbols', ''],
  ])('validates Rename input %s', (title, expected) => {
    component.renameTitle.set(title);
    expect(component.renameValidation()).toContain(expected);
  });

  it('does not submit Rename before an asset is selected or with invalid input', () => {
    component.renameTitle.set('Name');
    component.saveRename();
    component.openRename(row);
    component.renameTitle.set('');
    component.saveRename();
    expect(actions.renameAsset).not.toHaveBeenCalled();
  });

  it('submits Rename once, shows success and emits only after completion', () => {
    const request = new Subject<unknown>();
    actions.renameAsset.mockReturnValue(request);
    const changed = vi.spyOn(component.assetsChanged, 'emit');
    component.openRename(row);
    component.renameTitle.set('New name');
    component.saveRename();
    component.saveRename();
    expect(component.renameBusy()).toBe(true);
    expect(actions.renameAsset).toHaveBeenCalledExactlyOnceWith(row.assetId, 'New name');
    expect(changed).not.toHaveBeenCalled();
    request.next({});
    request.complete();
    expect(component.renameBusy()).toBe(false);
    expect(renameDialog.close).toHaveBeenCalledOnce();
    expect(changed).toHaveBeenCalledOnce();
    expect(toast.InsertToast).toHaveBeenCalledWith('success', 'New name was updated', expect.any(Object));
  });

  it('keeps Rename open and allows retry after failure', () => {
    actions.renameAsset.mockReturnValueOnce(throwError(() => new Error('Failed')));
    component.openRename(row);
    component.saveRename();
    expect(component.renameBusy()).toBe(false);
    expect(component.renameError()).toContain('Unable to rename');
    expect(renameDialog.close).not.toHaveBeenCalled();
    expect(toast.InsertToast).not.toHaveBeenCalled();
    component.saveRename();
    expect(component.renameError()).toBe('');
    expect(renameDialog.close).toHaveBeenCalledOnce();
  });

  it('opens Move to with a snapshot of the selection and the shared folder list', () => {
    const rows = [row];
    component.openMove(rows);
    rows.push({ ...row, assetId: 'another' });
    expect(component.assetsToMove()).toEqual([row]);
    expect(component.selectedFolder()).toEqual(component.rootFolder);
    expect(component.folders()).toEqual([folder]);
    expect(folderDialog.open).toHaveBeenCalledOnce();
    expect(component.moveDisabled()).toBe(true);
  });

  it('prevents duplicate folder loads and cancels a pending load when closing', () => {
    const request = new Subject<typeof folder[]>();
    actions.fetchMoveFolders.mockReturnValue(request);
    component.openMove([row]);
    component.loadFolders();
    expect(component.foldersLoading()).toBe(true);
    expect(component.moveDisabled()).toBe(true);
    expect(actions.fetchMoveFolders).toHaveBeenCalledOnce();
    component.cancelFolderLoad();
    expect(request.observed).toBe(false);
    expect(component.foldersLoading()).toBe(false);
  });

  it('ignores an obsolete folder request after Move is reopened', () => {
    const previous = new Subject<typeof folder[]>();
    actions.fetchMoveFolders.mockReturnValueOnce(previous);
    component.openMove([row]);
    component.openMove([{ ...row, assetId: 'second' }]);
    previous.next([]);
    expect(previous.observed).toBe(false);
    expect(component.folders()).toEqual([folder]);
    expect(component.assetsToMove()[0].assetId).toBe('second');
  });

  it('shows folder-loading errors and allows retry without submitting a move', () => {
    actions.fetchMoveFolders.mockReturnValueOnce(throwError(() => new Error('Failed')));
    component.openMove([row]);
    expect(component.moveError()).toContain('Unable to load');
    expect(component.foldersLoading()).toBe(false);
    expect(component.moveDisabled()).toBe(true);
    component.loadFolders();
    expect(component.moveError()).toBe('');
    expect(component.folders()).toEqual([folder]);
    expect(actions.moveAssets).not.toHaveBeenCalled();
  });

  it('disables same-folder and root-to-root moves but permits moving back to My assets', () => {
    component.openMove([row]);
    component.confirmMove();
    expect(confirmDialog.open).not.toHaveBeenCalled();
    component.openMove([{ ...row, parentAsset: { assetId: folder.assetId } }]);
    expect(component.moveDisabled()).toBe(false);
    component.selectFolder(folder);
    expect(component.moveDisabled()).toBe(true);
    component.selectFolder(component.rootFolder);
    expect(component.moveDisabled()).toBe(false);
  });

  it('permits bulk moves when at least one survey changes location', () => {
    component.openMove([row, { ...row, assetId: 'second', parentAsset: { assetId: folder.assetId } }]);
    component.selectFolder(folder);
    expect(component.moveDisabled()).toBe(false);
  });

  it('requires confirmation before moving', () => {
    component.openMove([row]);
    component.selectFolder({ ...folder, assetType: 'DISCOVERSHAREDFOLDER' });
    component.confirmMove();
    expect(folderDialog.close).toHaveBeenCalledOnce();
    expect(confirmDialog.open).toHaveBeenCalledOnce();
    expect(actions.moveAssets).not.toHaveBeenCalled();
  });

  it('moves once, closes confirmation and notifies the parent only after success', () => {
    const request = new Subject<unknown>();
    actions.moveAssets.mockReturnValue(request);
    const changed = vi.spyOn(component.assetsChanged, 'emit');
    component.openMove([row]);
    component.selectFolder(folder);
    component.confirmMove();
    component.saveMove();
    component.saveMove();
    expect(actions.moveAssets).toHaveBeenCalledExactlyOnceWith([row], folder);
    expect(component.moveBusy()).toBe(true);
    expect(changed).not.toHaveBeenCalled();
    request.next({});
    request.complete();
    expect(component.moveBusy()).toBe(false);
    expect(confirmDialog.close).toHaveBeenCalledOnce();
    expect(changed).toHaveBeenCalledOnce();
    expect(toast.InsertToast).toHaveBeenCalledWith('success', '"Survey" was successfully moved to Folder', expect.any(Object));
  });

  it('uses the Landing Page bulk message when moving multiple surveys', () => {
    component.openMove([row, { ...row, assetId: 'second' }]);
    component.selectFolder(folder);
    component.saveMove();
    expect(toast.InsertToast).toHaveBeenCalledWith('success', 'Assets were successfully moved to Folder', expect.any(Object));
  });

  it('keeps confirmation open on errors and supports retry', () => {
    actions.moveAssets.mockReturnValueOnce(throwError(() => new Error('Failed')));
    component.openMove([row]);
    component.selectFolder(folder);
    component.saveMove();
    expect(component.moveBusy()).toBe(false);
    expect(component.moveError()).toContain('Unable to move');
    expect(confirmDialog.close).not.toHaveBeenCalled();
    expect(toast.InsertToast).not.toHaveBeenCalled();
    component.saveMove();
    expect(component.moveError()).toBe('');
    expect(confirmDialog.close).toHaveBeenCalledOnce();
  });

  it('unsubscribes pending requests on destruction', () => {
    const request = new Subject<unknown>();
    actions.renameAsset.mockReturnValue(request);
    component.openRename(row);
    component.saveRename();
    TestBed.resetTestingModule();
    expect(request.observed).toBe(false);
    expect(component.renameBusy()).toBe(false);
  });

  it('clears Move loading state when a pending request is cancelled on destruction', () => {
    const request = new Subject<unknown>();
    actions.moveAssets.mockReturnValue(request);
    component.openMove([row]);
    component.selectFolder(folder);
    component.saveMove();
    expect(component.moveBusy()).toBe(true);
    TestBed.resetTestingModule();
    expect(request.observed).toBe(false);
    expect(component.moveBusy()).toBe(false);
  });

  it('clears folder loading state when the component is destroyed', () => {
    const request = new Subject<typeof folder[]>();
    actions.fetchMoveFolders.mockReturnValue(request);
    component.openMove([row]);
    expect(component.foldersLoading()).toBe(true);
    TestBed.resetTestingModule();
    expect(request.observed).toBe(false);
    expect(component.foldersLoading()).toBe(false);
  });

  it('renders the shared tree, validation, loading errors and destination message', () => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    const instance = fixture.componentInstance;
    instance.folders.set([folder]);
    instance.selectFolder({ ...folder, assetType: 'DISCOVERSHAREDFOLDER' });
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.querySelector('[data-test-id="survey-move-folder-tree"]')).not.toBeNull();
    expect(element.querySelector('[data-test-id="survey-move-confirm-message"]')?.textContent)
      .toContain('will be moved to "Folder');
    instance.selectFolder(instance.rootFolder);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-confirm-message"]')).toBeNull();
    instance.foldersLoading.set(true);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-spinner"]')).not.toBeNull();
    expect(element.querySelector('[data-test-id="survey-move-folder-section"]')?.classList.contains('is-loading')).toBe(true);
    instance.foldersLoading.set(false);
    instance.moveError.set('Unable to load folders.');
    instance.renameError.set('Unable to rename.');
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-retry"]')).not.toBeNull();
    expect(element.querySelector('[data-test-id="survey-rename-error"]')?.textContent).toContain('Unable to rename.');
    expect(element.querySelector('[data-test-id="survey-move-error"]')?.textContent).toContain('Unable to load folders.');
    expect(element.querySelector('[data-test-id="survey-move-confirm-error"]')?.textContent).toContain('Unable to load folders.');
    instance.moveError.set('');
    instance.folders.set([]);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-empty-state"]')?.textContent).toContain('No folders available.');
  });

  it('wires the rendered Rename field and Update button to the mutation', () => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    fixture.detectChanges();
    const instance = fixture.componentInstance;
    Object.assign(instance, { renameDialog });
    instance.openRename(row);
    fixture.detectChanges();
    const field: HTMLElement = fixture.debugElement.query(By.css('[data-test-id="survey-rename-title"]')).nativeElement;
    expect(field.hasAttribute('label')).toBe(false);
    expect(field.getAttribute('title')).toBe('Asset name');
    fixture.debugElement.query(By.css('[data-test-id="survey-rename-title"]'))
      .triggerEventHandler('ngModelChange', 'Renamed survey');
    fixture.detectChanges();
    fixture.debugElement.query(By.css('[data-test-id="survey-rename-save"]')).nativeElement.click();
    expect(actions.renameAsset).toHaveBeenCalledWith(row.assetId, 'Renamed survey');
    expect(renameDialog.close).toHaveBeenCalledOnce();
  });

  it('wires the rendered folder picker, Move and Confirm buttons without moving prematurely', () => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    fixture.detectChanges();
    const instance = fixture.componentInstance;
    Object.assign(instance, { folderDialog, confirmDialog });
    instance.openMove([row]);
    fixture.detectChanges();
    fixture.debugElement.query(By.css('crf-uic-tree-forder-selector'))
      .triggerEventHandler('pathChange', folder);
    fixture.detectChanges();
    fixture.debugElement.query(By.css('[data-test-id="survey-move-select"]')).nativeElement.click();
    expect(confirmDialog.open).toHaveBeenCalledOnce();
    expect(actions.moveAssets).not.toHaveBeenCalled();
    fixture.debugElement.query(By.css('[data-test-id="survey-move-confirm"]')).nativeElement.click();
    expect(actions.moveAssets).toHaveBeenCalledWith([row], folder);
    expect(confirmDialog.close).toHaveBeenCalledOnce();
  });
});
