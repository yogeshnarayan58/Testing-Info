import { Locator, Page } from "@playwright/test";

export type LocatorOptions = Parameters<Page['locator']>[1];
export type FillOptions = Parameters<Locator['fill']>[1];
export type ClickOptions = Parameters<Locator['click']>[0] & {
    loadState?: WaitForLoadStateOptions;
  };
export type WaitForLoadStateOptions = Parameters<Page['waitForLoadState']>[0];
export type TimeoutOption = { timeout?: number };
export type SoftOption = { soft?: boolean };
export type ExpectOptions = TimeoutOption & SoftOption & MessageOrOptions;
export type MessageOrOptions = string | { message?: string };
export type NavigationOptions = Parameters<Page['reload']>[0];