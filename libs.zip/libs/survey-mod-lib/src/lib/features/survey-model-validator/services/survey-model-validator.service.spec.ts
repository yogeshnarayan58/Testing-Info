import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { describe, expect, it } from 'vitest';
import { QuestionModel, QuestionTypes } from '../../build-survey/models/build-survey';
import { SurveyModelValidatorService } from './survey-model-validator.service';

describe('SurveyModelValidatorService', () => {
  const createService = () => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(), provideHttpClientTesting(),
        { provide: EnvironmentConfig, useValue: { apiUrls: { surveyAiEngineUrl: '/survey-ai' } } },
      ],
    });
    return TestBed.inject(SurveyModelValidatorService);
  };

  it('loads both default prompts from the feature endpoint', () => {
    const service = createService();
    const http = TestBed.inject(HttpTestingController);
    const prompts = { generateQuestionSystemPrompt: 'Generate', validateSurveySystemPrompt: 'Validate' };
    let response: unknown;
    service.extractPrompts().subscribe(value => response = value);
    const request = http.expectOne('/survey-ai/utils/extract-prompts');
    expect(request.request.method).toBe('GET');
    expect(request.request.headers.has('Content-Type')).toBe(false);
    request.flush(prompts);
    expect(response).toEqual(prompts);
    http.verify();
  });

  it('loads default prompts once and replays the cached response', () => {
    const service = createService();
    const http = TestBed.inject(HttpTestingController);
    const prompts = { generateQuestionSystemPrompt: 'Generate', validateSurveySystemPrompt: 'Validate' };
    const responses: unknown[] = [];

    service.extractPrompts().subscribe(value => responses.push(value));
    service.extractPrompts().subscribe(value => responses.push(value));
    const request = http.expectOne('/survey-ai/utils/extract-prompts');
    request.flush(prompts);
    service.extractPrompts().subscribe(value => responses.push(value));

    http.expectNone('/survey-ai/utils/extract-prompts');
    expect(responses).toEqual([prompts, prompts, prompts]);
    http.verify();
  });

  it.each([
    { method: 'generateQuestions', endpoint: 'generate-questions-with-prompts' },
    { method: 'generateAndValidateSurvey', endpoint: 'generate-and-validate-survey' },
  ] as const)('posts $method without changing its payload or response', ({ method, endpoint }) => {
    const service = createService();
    const http = TestBed.inject(HttpTestingController);
    const payload = { prompt: {
      userPrompt: 'Generate questions', product: 'Product', retailer: 'Retailer',
      geography: 'US', demographic: 'Adults', period: '52 weeks', questionCount: 3,
      questionTypes: [QuestionTypes.SingleChoice],
      generateQuestionSystemPrompt: 'Generate balanced questions',
      validateSurveySystemPrompt: 'Validate for clarity',
    } };
    const expected = { title: 'Survey', validation: { status: 'COMPLETED' }, result: [] };
    let response: unknown;
    service[method](payload).subscribe(value => response = value);
    const request = http.expectOne(`/survey-ai/utils/${endpoint}`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(payload);
    expect(request.request.headers.get('Content-Type')).toBe('application/json');
    request.flush(expected);
    expect(response).toEqual(expected);
    http.verify();
  });

  it('posts prompt-aware validation without changing the response', () => {
    const service = createService();
    const http = TestBed.inject(HttpTestingController);
    const payload = { survey: { systemPrompt: 'Review', questions: [{ id: 'q_1', order: 1, question: 'Question?' }] } };
    const expected = { result: [] };
    let response: unknown;
    service.validateSurveyWithPrompt(payload).subscribe(value => response = value);
    const request = http.expectOne('/survey-ai/utils/validate-questions-using-prompt');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(payload);
    expect(request.request.headers.get('Content-Type')).toBe('application/json');
    request.flush(expected);
    expect(response).toEqual(expected);
    http.verify();
  });

  it('flags an empty result set', () => {
    const service = createService();

    const result = service.validateQuestions([]);

    expect(result.valid).toBe(false);
    expect(result.issueCount).toBe(1);
    expect(result.issues[0]).toMatchObject({ questionIndex: -1, field: 'questions' });
  });

  it('treats null/undefined input as an empty list', () => {
    const service = createService();

    expect(service.validateQuestions(null).valid).toBe(false);
    expect(service.validateQuestions(undefined).valid).toBe(false);
  });

  it('passes a well-formed single choice question', () => {
    const service = createService();
    const questions: QuestionModel[] = [
      {
        question: 'Which flavor do you prefer?',
        type: QuestionTypes.SingleChoice,
        isRequired: true,
        options: ['Vanilla', 'Chocolate'],
      },
    ];

    const result = service.validateQuestions(questions);

    expect(result).toEqual({ valid: true, issueCount: 0, issues: [] });
  });

  it('flags choice questions with fewer than 2 options', () => {
    const service = createService();
    const questions: QuestionModel[] = [
      {
        question: 'Which flavor do you prefer?',
        type: QuestionTypes.MultipleChoice,
        isRequired: true,
        options: ['Vanilla'],
      },
    ];

    const result = service.validateQuestions(questions);

    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual(
      expect.objectContaining({ questionIndex: 0, field: 'options' })
    );
  });

  it('flags scale questions missing row/column options', () => {
    const service = createService();
    const questions: QuestionModel[] = [
      {
        question: 'Rate the following attributes',
        type: QuestionTypes.MultiplePointScale,
        isRequired: true,
      },
    ];

    const result = service.validateQuestions(questions);

    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual(expect.objectContaining({ field: 'rowOptions' }));
    expect(result.issues).toContainEqual(expect.objectContaining({ field: 'columnOptions' }));
  });

  it('flags NPS questions missing left/right labels', () => {
    const service = createService();
    const questions: QuestionModel[] = [
      {
        question: 'How likely are you to recommend us?',
        type: QuestionTypes.NetPromoterScore,
        isRequired: true,
      },
    ];

    const result = service.validateQuestions(questions);

    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual(expect.objectContaining({ field: 'npsLabels' }));
  });

  it.each([QuestionTypes.SinglePointScale, QuestionTypes.MultiplePointScale])('accepts a complete %s scale', (type) => {
    const service = createService();

    expect(service.validateQuestions([{
      question: 'Rate the product attributes', type, isRequired: true,
      rowOptions: ['Cleaning performance'], columnOptions: ['Good', 'Poor'],
    }])).toEqual({ valid: true, issueCount: 0, issues: [] });
  });

  it.each(['rowOptions', 'columnOptions'] as const)('reports an empty %s array without flagging the other scale field', (field) => {
    const service = createService();
    const question: QuestionModel = {
      question: 'Rate the product attributes', type: QuestionTypes.SinglePointScale, isRequired: true,
      rowOptions: ['Cleaning performance'], columnOptions: ['Good', 'Poor'],
    };
    question[field] = [];

    const result = service.validateQuestions([question]);

    expect(result.valid).toBe(false);
    expect(result.issueCount).toBe(1);
    expect(result.issues[0]).toMatchObject({ questionIndex: 0, field });
  });

  it.each([
    { left: 'Not likely', right: 'Very likely', valid: true },
    { left: 'Not likely', right: undefined, valid: false },
    { left: 'Not likely', right: '   ', valid: false },
    { left: '   ', right: 'Very likely', valid: false },
  ])('validates NPS endpoints: left="$left", right="$right"', ({ left, right, valid }) => {
    const service = createService();

    const result = service.validateQuestions([{
      question: 'How likely are you to recommend us?',
      type: QuestionTypes.NetPromoterScore, isRequired: true,
      npsLeftLabel: left, npsRightLabel: right,
    }]);

    expect(result.valid).toBe(valid);
    expect(result.issueCount).toBe(valid ? 0 : 1);
    if (!valid) expect(result.issues[0]).toMatchObject({ field: 'npsLabels' });
  });

  it('reports omitted choice options', () => {
    const service = createService();

    const result = service.validateQuestions([{
      question: 'Which product do you prefer?', type: QuestionTypes.SingleChoice, isRequired: true,
    }]);

    expect(result.valid).toBe(false);
    expect(result.issueCount).toBe(1);
    expect(result.issues[0]).toMatchObject({ field: 'options' });
  });

  it('flags missing question text, type and isRequired flag', () => {
    const service = createService();
    const questions: QuestionModel[] = [
      { question: '', type: '', isRequired: undefined as unknown as boolean },
    ];

    const result = service.validateQuestions(questions);

    expect(result.issues).toContainEqual(expect.objectContaining({ field: 'question' }));
    expect(result.issues).toContainEqual(expect.objectContaining({ field: 'type' }));
    expect(result.issues).toContainEqual(expect.objectContaining({ field: 'isRequired' }));
  });
});
