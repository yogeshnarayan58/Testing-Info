import { RIGHTS_CONFIG, RightsUtilityService } from '@nielsen/crf-lp-common';
import { SurveyActionItem } from '../../../shared/components/survey-action-items/survey-action-items.model';
import { SurveyStatusType } from '../../build-survey/models/build-survey';
import { SurveyGridRow } from '../models/survey-asset.model';
import { isFolderAsset } from '../utils/survey-status.util';
import { ASSET_TYPE, MY_ASSETS_TABS, MyAssetsTabId } from './my-assets-tabs.constant';
import { SURVEY_ACCESS_AVAILABILITY } from './survey-status.constant';

export type MyAssetsSelectionActionId = 'open-new-tab' | 'move' | 'info' | 'duplicate' | 'rename' | 'share' | 'export' | 'delete' | 'restore';

type Selection = readonly SurveyGridRow[];

const isSingleSelection = (rows: Selection): boolean => rows.length === 1;
const isMultiSelection = (rows: Selection): boolean => rows.length > 1;
const isSingleSurvey = (rows: Selection): boolean => isSingleSelection(rows) && rows[0].assetType === ASSET_TYPE.DISCOVERSURVEY;
const isSingleFolder = (rows: Selection): boolean => isSingleSelection(rows) && isFolderAsset(rows[0]);
const isClosedSurvey = (row: SurveyGridRow): boolean => row.status?.toUpperCase() === SurveyStatusType.CLOSED;

/**
 * Base actions shared by the toolbar and right-click menu, in display order.
 * - Single survey: all actions; Share and Export only once the survey is Closed.
 * - Single folder: Rename, Share, Delete, Info.
 * - Multiple assets: Move to, Delete.
 * Tab capabilities and row rights are applied by getMyAssetsSelectionActions, independently of checkboxes.
 */
export const MY_ASSETS_SELECTION_ACTIONS: readonly SurveyActionItem<SurveyGridRow, MyAssetsSelectionActionId>[] = [
  { id: 'open-new-tab', label: 'Open in new window', iconName: 'open', isVisible: isSingleSurvey },
  { id: 'move', label: 'Move to', iconName: 'folder-move', isVisible: (rows) => isSingleSurvey(rows) || isMultiSelection(rows) },
  { id: 'duplicate', label: 'Duplicate', iconName: 'duplicate', isVisible: isSingleSurvey },
  { id: 'rename', label: 'Rename', iconName: 'rename', isVisible: isSingleSelection },
  {
    id: 'share',
    label: 'Share',
    iconName: 'share',
    isVisible: (rows) => isSingleFolder(rows) || (isSingleSurvey(rows) && isClosedSurvey(rows[0])),
  },
  { id: 'delete', label: 'Delete', iconName: 'trash' },
  { id: 'export', label: 'Export', iconName: 'download', isVisible: (rows) => isSingleSurvey(rows) && isClosedSurvey(rows[0]) },
  { id: 'info', label: 'Info', iconName: 'info', isVisible: isSingleSelection },
];

export function getMyAssetsSelectionActions(
  tab: MyAssetsTabId,
  userId: string | undefined,
  rightsUtility: Pick<RightsUtilityService, 'checkAvailableRightsForMe'>
): readonly SurveyActionItem<SurveyGridRow, MyAssetsSelectionActionId>[] {
  const isBulkSelectionAllowed = (rows: Selection): boolean => rows.length > 0 && rows.length <= 20;
  const canTrash = (row: SurveyGridRow): boolean => !!userId && (row.rights?.some((right) => right.availability === SURVEY_ACCESS_AVAILABILITY.OWNED
    && (right.userId === userId || (right.orderManagementType === 'COG' && !right.userId))) ?? false);

  // Trash offers restore and permanent deletion instead of normal asset actions.
  if (tab === MY_ASSETS_TABS.TRASH) {
    return [
      { id: 'restore', label: 'Restore', iconName: 'undo', isVisible: isBulkSelectionAllowed },
      { id: 'delete', label: 'Delete permanently', iconName: 'trash', isVisible: isBulkSelectionAllowed },
      { id: 'info', label: 'Info', iconName: 'info', isVisible: isSingleSelection },
    ];
  }

  return MY_ASSETS_SELECTION_ACTIONS.map((action) => ({
    ...action,
    isVisible: (rows: Selection): boolean => {
      if (!rows.length || !(action.isVisible?.(rows) ?? true)) {
        return false;
      }
      // Moving is limited to editable surveys in My Assets.
      if (action.id === 'move') {
        return tab === MY_ASSETS_TABS.MY_ASSETS && isBulkSelectionAllowed(rows) && !!userId
          && rows.every((row) => row.assetType === ASSET_TYPE.DISCOVERSURVEY
            && rightsUtility.checkAvailableRightsForMe(row, userId, RIGHTS_CONFIG.EDITOR_RIGHTS));
      }
      // Bulk actions are restricted to deletion of assets the user can trash.
      if (isMultiSelection(rows)) {
        return action.id === 'delete' && tab === MY_ASSETS_TABS.MY_ASSETS
          && isBulkSelectionAllowed(rows) && rows.every(canTrash);
      }
      const row = rows[0];
      // These actions are read-only or open their own workflow, so they need no editor check.
      if (action.id === 'info' || action.id === 'open-new-tab' || action.id === 'duplicate' || action.id === 'export') {
        return true;
      }
      if (!userId || !rightsUtility.checkAvailableRightsForMe(row, userId, RIGHTS_CONFIG.EDITOR_RIGHTS)) {
        return false;
      }
      if (action.id === 'delete') {
        // Deletion requires ownership, even when the user has editor access.
        return canTrash(row);
      }
      return true;
    },
  }));
}
