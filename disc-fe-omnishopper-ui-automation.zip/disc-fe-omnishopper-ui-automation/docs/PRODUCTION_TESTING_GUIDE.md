# Production Environment Testing Guide

## Overview
This framework supports testing across **4 production environments** using a single test data file per report.

## Supported Environments

### Lower Environments (Dev/Test)
- **DEV** - Development environment
- **SI** - System Integration environment  
- **UAT** - User Acceptance Testing environment
- Uses: `dev-test-data.json`

### Production Environments
1. **PROD_US** - Production US (`https://connect.nielseniq.com/discover`) - **2 datasets**
2. **PROD_EU** - Production EU (`https://eu.connect.nielseniq.com/discover`) - 1 dataset
3. **PROD_APAC** - Production APAC (`https://apac.connect.nielseniq.com/discover`) - 1 dataset
4. **PROD_CALATAM** - Production CALATAM (`https://calatam.connect.nielseniq.com/discover`) - 1 dataset
- Uses: `prod-test-data.json`

---

## Quick Start (3 Steps)

### 1. Generate Production Test Data File

**Use Test Data Generator Chatmode (🎭):**

1. Open VS Code chatmode: Select **🎭 test-data-generator**
2. Say: `"Production test data generate for [report-name]"`
3. Select environment: `PROD_US` (or PROD_EU/APAC/CALATAM)
4. Provide dataset name: e.g., `POD_Homescan_US_LT99`
5. Paste async payload JSON from production
6. Get complete `prod-test-data.json` file!

**For multiple environments:**
- Repeat for each environment
- Chatmode creates one file with all datasets

**File Location:**
```
src/lib/tests/reports/your-report-name/test-data/prod-test-data.json
```

---

### 2. Set Environment Variables

Set environment variables before running tests:

**Windows PowerShell:**
```powershell
$env:ENV="PROD_US"
$env:DATASET="POD_Homescan_US_LT99"
```

**Linux/Mac Bash:**
```bash
export ENV=PROD_US
export DATASET=POD_Homescan_US_LT99
```

**Note:** Production uses the same credentials as DEV/SI environments configured in GitHub secrets.

---

### 3. Run Tests

Same command as dev/si - framework auto-detects environment:
**Set these two variables:**

The framework automatically determines which test data file to load:

```typescript
// Lower Environments → dev-test-data.json
DEV, SI, UAT, EUSI, LOCAL → dev-test-data.json

// Production Environments → prod-test-data.json  
PROD_US, PROD_EU, PROD_APAC, PROD_CALATAM → prod-test-data.json
```

### URL Resolution

URLs are automatically resolved based on `ENV` variable:

```typescript
config.BASE_URL → Resolves to:
  - DEV      → https://si.connect.nielseniq.io/reportexperience-dev
  - SI       → https://si.connect.nielseniq.io/reportexperience
  - PROD_US  → https://connect.nielseniq.com/discover
  - PROD_EU  → https://eu.connect.nielseniq.com/discover
  - PROD_APAC → https://apac.connect.nielseniq.com/discover
  - PROD_CALATAM → https://calatam.connect.nielseniq.com/discover
```

---

## Running Tests

### Local Execution

#### Windows PowerShell Commands

**DEV/SI (Default):**
```powershell
# Simple/Direct (headless mode)
npx playwright test assortment-optimizer.spec.ts

# With browser visible
npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Production US:**
```powershell
# Simple/Direct Command (headless mode)
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts

# With browser visible and HTML report
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# Dataset 2 (if available)
$env:ENV="PROD_US"; $env:DATASET="POD_Homescan_US_LT99"; npx playwright test assortment-optimizer.spec.ts
```

**Production EU:**
```powershell
# Direct command
$env:ENV="PROD_EU"; $env:DATASET="POD_Homescan_GB"; npx playwright test assortment-optimizer.spec.ts

# With options
$env:ENV="PROD_EU"; $env:DATASET="POD_Homescan_GB"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Production APAC:**
```powershell
# Direct command
$env:ENV="PROD_APAC"; $env:DATASET="POD_Homescan_Australia_L9"; npx playwright test assortment-optimizer.spec.ts

# With options
$env:ENV="PROD_APAC"; $env:DATASET="POD_Homescan_Australia_L9"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Production CALATAM:**
```powershell
# Direct command
$env:ENV="PROD_CALATAM"; $env:DATASET="CANADA_HOMESCAN_CPS"; npx playwright test assortment-optimizer.spec.ts

# With options
$env:ENV="PROD_CALATAM"; $env:DATASET="CANADA_HOMESCAN_CPS"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Common Test Modes:**
```powershell
# Headed mode (see browser)
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts --headed

# Headless mode (faster, CI/CD)
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts

# Debug mode
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts --debug

# UI Mode (interactive)
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts --ui

# With Allure reporter
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts --reporter=allure-playwright
```

---

#### Linux/Mac Bash Commands

**DEV/SI (Default):**
```bash
npm run test assortment-optimizer.spec.ts
```

**Production US:**
```bash
# Dataset 1
ENV=PROD_US DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr" npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# Dataset 2
ENV=PROD_US DATASET=POD_Homescan_US_LT99 npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Production EU:**
```bash
ENV=PROD_EU DATASET=POD_Homescan_GB npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Production APAC:**
```bash
ENV=PROD_APAC DATASET=POD_Homescan_Australia_L9 npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

**Production CALATAM:**
```bash
ENV=PROD_CALATAM DATASET=CANADA_HOMESCAN_CPS npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

---

## Best Practices

### 1. Use Test Data Generator Chatmode (🎭)
- **Fastest way** to create prod-test-data.json files
- **No manual typing** - paste async payload, get complete file
- **Accurate** - auto-extracts all dimensions correctly

### 2. One File Per Report
- Single `prod-test-data.json` contains datasets for all environments
- Switch environments with just ENV and DATASET variables
- Easy to maintain and update

### 3. Dataset Naming
Ensure `DATASET` variable matches key in test data file:

```bash
ENV=PROD_US
DATASET='POD_Homescan_US_LT99'  # ← Must match dataset key exactly
```

---

## Summary

✅ **Use chatmode (🎭) to generate files**  
✅ **One prod-test-data.json per report**  
✅ **Multiple datasets in one file**  
✅ **Switch environments with ENV + DATASET only**  

**Next:** Start with chatmode to generate your first prod-test-data.json file!

---

## Quick Reference: All Environment Commands

### Windows PowerShell - Simple/Direct Commands (Most Used)

```powershell
# PROD_US - Primary Dataset (simple command)
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts

# PROD_EU
$env:ENV="PROD_EU"; $env:DATASET="POD_Homescan_GB"; npx playwright test assortment-optimizer.spec.ts

# PROD_APAC
$env:ENV="PROD_APAC"; $env:DATASET="POD_Homescan_Australia_L9"; npx playwright test assortment-optimizer.spec.ts

# PROD_CALATAM
$env:ENV="PROD_CALATAM"; $env:DATASET="CANADA_HOMESCAN_CPS"; npx playwright test assortment-optimizer.spec.ts

# DEV/SI (Default)
npx playwright test assortment-optimizer.spec.ts
```

### Windows PowerShell - With Options (Browser + HTML Report)

```powershell
# PROD_US - With headed mode and HTML report
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# PROD_EU
$env:ENV="PROD_EU"; $env:DATASET="POD_Homescan_GB"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# PROD_APAC
$env:ENV="PROD_APAC"; $env:DATASET="POD_Homescan_Australia_L9"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# PROD_CALATAM
$env:ENV="PROD_CALATAM"; $env:DATASET="CANADA_HOMESCAN_CPS"; npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# DEV/SI (Default)
npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

---

## Test Data Generator Agent - Standard Prompt Template

### How to Generate Production Test Data

When using the `test-data-generator` agent to create prod-test-data.json files, use this standardized prompt template:

### Standard Prompt Template

```
Generate production test data for [REPORT NAME] for the [PIVOT NAME].

Requirements:
1. Data Sources
   - Reference for structure: Dev test data JSON or prod test data json of assortment optimizer report
   - Reference for actual values: Attached production async payload file
   - Environment: Production US
   - Dataset: Homescan (POD_Homescan_US_LT99)

2. Key Instructions
   ✅ Extract "ALL dimension selections" from the attached file and always extract from allSelectedValues
   ✅ Append to existing prod-test-data.json if already available (do NOT create a separate file) 
      and correctly structure inside the dimensionSelections array with "pivot": "name" as the first property.
      If no prod-test-data.json is available for the report, create a new one 
      (one json file is for one report covering all the pivots in it)
   ✅ Add as a new pivot object in the dimensionSelections array
   ⚠️ Critical: Extract ALL items from selection arrays, not just the first value
   ❌ Do NOT add extra dimensions or values not present in the attached file
```

### Usage Instructions

1. **Replace placeholders:**
   - `[REPORT NAME]` → e.g., "Trade planner table", "Consumer trends", "Leakage analysis"
   - `[PIVOT NAME]` → e.g., "Product", "Retailer", "Geography", "Purchase facts"

2. **Attach your production async payload JSON file** from production environment

3. **Run with test-data-generator agent** in VS Code

### Example Usage

```
Generate production test data for Trade planner table for the Purchase facts pivot.

Requirements:
1. Data Sources
   - Reference for structure: Dev test data JSON or prod test data json of assortment optimizer report
   - Reference for actual values: Attached production async payload file
   - Environment: Production US
   - Dataset: Homescan (POD_Homescan_US_LT99)

2. Key Instructions
   ✅ Extract "ALL dimension selections" from the attached file and always extract from allSelectedValues
   ✅ Append to existing prod-test-data.json if already available (do NOT create a separate file) 
      and correctly structure inside the dimensionSelections array with "pivot": "name" as the first property.
   ✅ Add as a new pivot object in the dimensionSelections array
   ⚠️ Critical: Extract ALL items from selection arrays, not just the first value
   ❌ Do NOT add extra dimensions or values not present in the attached file
```

### For Multiple Pivots

- Repeat the prompt for each pivot in the report
- Agent will append to existing prod-test-data.json
- One JSON file covers all pivots for a report

### Output Location

```
src/lib/tests/reports/[report-name]/test-data/prod-test-data.json
```

---

### Common Test Variations (PowerShell)

```powershell
# Replace [ENV] and [DATASET] with your values

# Debug mode (step through test)
$env:ENV="[ENV]"; $env:DATASET="[DATASET]"; npx playwright test [spec-file].spec.ts --debug

# UI Mode (interactive debugging)
$env:ENV="[ENV]"; $env:DATASET="[DATASET]"; npx playwright test [spec-file].spec.ts --ui

# Headless mode (no browser window)
$env:ENV="[ENV]"; $env:DATASET="[DATASET]"; npx playwright test [spec-file].spec.ts

# With specific reporter
$env:ENV="[ENV]"; $env:DATASET="[DATASET]"; npx playwright test [spec-file].spec.ts --reporter=line
$env:ENV="[ENV]"; $env:DATASET="[DATASET]"; npx playwright test [spec-file].spec.ts --reporter=allure-playwright

# Run specific test by grep
$env:ENV="[ENV]"; $env:DATASET="[DATASET]"; npx playwright test --grep "@RunReport"
```

### Linux/Mac Bash

```bash
# PROD_US
ENV=PROD_US DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr" npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# PROD_EU
ENV=PROD_EU DATASET=POD_Homescan_GB npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# PROD_APAC
ENV=PROD_APAC DATASET=POD_Homescan_Australia_L9 npx playwright test assortment-optimizer.spec.ts --headed --reporter=html

# PROD_CALATAM
ENV=PROD_CALATAM DATASET=CANADA_HOMESCAN_CPS npx playwright test assortment-optimizer.spec.ts --headed --reporter=html
```

### NPM Scripts (package.json)

```powershell
# Use npm scripts for common scenarios
npm run test:headed          # DEV headed mode
npm run test:debug           # DEV debug mode
npm run test:ui              # DEV UI mode

# For PROD, set env vars first:
$env:ENV="PROD_US"; $env:DATASET="US Exp Osh - NDH Synd Full View - 444 5 yr"; npm run test:headed
```

---

## Troubleshooting

### Common Issues

**1. Login Timeout**
- **Cause**: PROD environments may take longer to load
- **Fix**: Login page has increased timeouts for PROD automatically

**2. DataSelector Not Loading**
- **Cause**: Page JavaScript taking time to initialize
- **Fix**: Framework waits up to 60 seconds for DataSelector in PROD

**3. Test Timeout (300s exceeded)**
- **Cause**: RUN_TEST_TIMEOUT too short for PROD
- **Fix**: Framework automatically increases timeout to 10 minutes for PROD environments

**4. Wrong Test Data Loaded**
- **Verify**: Check console logs for "Processing object-based test data"
- **Fix**: Ensure DATASET name matches exactly in prod-test-data.json

**5. Browser Closes During Test**
- **Cause**: Navigation or element wait timeout
- **Fix**: Use `--headed` mode to see what's happening visually

### Debug Commands

```powershell
# See detailed test output
$env:ENV="PROD_US"; $env:DATASET="[DATASET]"; npx playwright test [spec].spec.ts --headed --reporter=line

# Generate trace for debugging
$env:ENV="PROD_US"; $env:DATASET="[DATASET]"; npx playwright test [spec].spec.ts --trace on

# Show browser (helpful to see what's happening)
$env:ENV="PROD_US"; $env:DATASET="[DATASET]"; npx playwright test [spec].spec.ts --headed
```

---

## Environment-Specific Notes

### PROD_US
- **Base URL**: `https://connect.nielseniq.com/discover`
- **Datasets**: 2 available (check prod-test-data.json)
- **Login**: Uses same credentials as DEV/SI
- **Timeouts**: Automatically increased (10 min test timeout)

### PROD_EU
- **Base URL**: `https://eu.connect.nielseniq.com/discover`
- **Datasets**: 1 available
- **Locale**: Typically `en-GB`

### PROD_APAC
- **Base URL**: `https://apac.connect.nielseniq.com/discover`
- **Datasets**: 1 available
- **Locale**: Varies (en-AU, etc.)

### PROD_CALATAM
- **Base URL**: `https://calatam.connect.nielseniq.com/discover`
- **Datasets**: 1 available
- **Locale**: Varies (en-CA, es-MX, pt-BR)

---

**💡 Pro Tip**: Copy-paste commands from this guide and just replace the spec file name!