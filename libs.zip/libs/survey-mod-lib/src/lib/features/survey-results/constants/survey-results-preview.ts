import { RESULTS_DASHBOARD_CHART_TYPE_VALUES } from '../models/survey-results';
import type { ChartConfig, QuestionGridResponse, QuestionChartResponse } from '../models/question-result';

// Separate sample API responses for bar and column charts.
export const BAR_CHART_RESPONSE = {
  "data": [
    {
      "qid": "asasas",
      "components": [
        {
          "type": "CHART",
          "id": "30a69f2f-ee80-423c-a900-bcf840119aae",
          "objects": {
            "id": "30a69f2f-ee80-423c-a900-bcf8402323dddd",
            "attributes": {},
            "title": "How often do you purchase adult incontinence products at dollar stores?",
            "data": [
              {
                "label1": "Every purchase occasion",
                "id": 1,
                "metric1": 11.379
              },
              {
                "label1": "Most purchase occasions",
                "id": 2,
                "metric1": 7.397
              },
              {
                "label1": "Some purchase occasions",
                "id": 3,
                "metric1": 2.869
              },
              {
                "label1": "Rarely or never",
                "id": 4,
                "metric1": 5.379
              }
            ],
            "metadata": {
              "metric1": {
                "title": "Units Sales",
                "type": "number",
                "format": "#,##0.0"
              },
              "label1": {
                "title": "Units Sales",
                "type": "text",
                "hoverText": "Periods"
              }
            }
          },
          "chartType": "MULTIBAR_HORIZONTAL" as const,
          "chartConfigs": [
            {
              "chartType": "MULTIBAR_HORIZONTAL" as const,
              "dataDefinition": {
                "xaxis": [
                  {
                    "value": "id",
                    "displayValue": "label1"
                  }
                ],
                "series": [
                  {
                    "value": "metric1"
                  }
                ]
              },
              "axisConfig": {
                "showXaxis": true,
                "showYaxis": true,
                "yAxis": {
                  "showLabelEllipsis": true,
                  "axisLabel": "Units Sales",
                  "showAxisLabel": false,
                  "showMajorGridLines": true
                }
              },
              "seriesConfig": {
              "showValues": true
              }
            }
          ],
          "chartProperty": {
            "legend": {
              "align": "BOTTOM",
              "quadrantLegend": false
            },
            "margin": {
              "bottom": 0,
              "left": 0,
              "right": 8,
              "top": 5
            },
            "showLegend": false,
            "haveLabelChart": false,
            "flipTable": false,
            "useInteractiveGuideline": true,
            "highlightOnlyFirstGroup": false,
            "minBarSize": 1,
            "preview": false,
            "shimmerAnimation": false,
            "stretchTo100Percent": false,
            "donut": false,
            "enableColoredIntersections": false,
            "useDynamicColors": false,
            "setBubbleLetter": false,
            "showBubblesCountLabel": false,
            "priceTierScatter": false,
            "dynamicYAxis": false,
            "setBubbleLetterOrderBySize": false
          }
        }
      ],
      "layout": {
        "type": "ABSOLUTE",
        "tiles": [
          {
            "type": "COMPONENT",
            "componentId": "30a69f2f-ee80-423c-a900-bcf840119aae",
            "x": 0,
            "y": 0,
            "height": 100,
            "width": 100
          }
        ]
      },
      "source": "",
      "dataSummary": {
        "footer": {
          "dataSourceInfo": {
            "displayText": "Dataset: NielsenIQ Retail Measurement - FMCG | Coke Total Beverage   | Entire Dataset Rule for 97212_2YATesting_9_July_21 ",
            "dataSourceTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#000000",
                "size": 11
              }
            }
          },
          "copyrightsInfo": {
            "displayText": "Copyright © 2026 Nielsen Consumer LLC. All Rights Reserved.",
            "copyrightsTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#000000",
                "size": 11
              }
            }
          },
          "termsAndConditionsInfo": {
            "termsAndConditionsText": "Terms & Conditions",
            "termsAndConditionsTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#0000FF",
                "size": 11
              },
              "underline": true
            },
            "termsAndConditionsHyperlinkTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#0000FF",
                "size": 11
              },
              "underline": true
            }
          }
        },
        "header": {
          "summary": "#b#$#/b# of #b#TOTAL BEVERAGE#/b# in #b#Total US Mass#/b# during #b#Latest 52 Weeks#/b#",
          "headerTextStyle": {
            "bold": false,
            "alignment": "LEFT",
            "font": {
              "name": "Aktiv Grotesk",
              "color": "#000000",
              "size": 11
            },
            "underline": false
          },
          "title": "Untitled Report",
          "titleTextStyle": {
            "bold": false,
            "alignment": "LEFT",
            "font": {
              "name": "Aktiv Grotesk",
              "color": "#000000",
              "size": 13
            },
            "underline": false
          }
        }
      },
      "metaData": {
        "biCache": false,
        "dataRenamed": false,
        "cacheOriginTxId": "00BF508BAA594C0E90AE8631E926852C"
      },
      "filterSummary": {}
    }
  ],
  "timeMillis": 120
};

export const COLUMN_CHART_RESPONSE = {
  "data": [
    {
      "qid": "asasas",
      "components": [
        {
          "type": "CHART",
          "id": "30a69f2f-ee80-423c-a900-bcf840119aae",
          "objects": {
            "id": "30a69f2f-ee80-423c-a900-bcf8402323dddd",
            "attributes": {},
            "title": "How often do you purchase adult incontinence products at dollar stores?",
            "data": [
              {
                "label1": "Every purchase occasion",
                "id": 1,
                "metric1": 11.379
              },
              {
                "label1": "Most purchase occasions",
                "id": 2,
                "metric1": 7.397
              },
              {
                "label1": "Some purchase occasions",
                "id": 3,
                "metric1": 2.869
              },
              {
                "label1": "Rarely or never",
                "id": 4,
                "metric1": 5.379
              }
            ],
            "metadata": {
              "metric1": {
                "title": "Units Sales",
                "type": "number",
                "format": "#,##0.0"
              },
              "label1": {
                "title": "Units Sales",
                "type": "text",
                "hoverText": "Periods"
              }
            }
          },
          "chartType": "MULTIBAR_VERTICAL" as const,
          "chartConfigs": [
            {
              "chartType": "MULTIBAR_VERTICAL" as const,
              "dataDefinition": {
                "xaxis": [
                  {
                    "value": "id",
                    "displayValue": "label1"
                  }
                ],
                "series": [
                  {
                    "value": "metric1"
                  }
                ]
              },
              "axisConfig": {
                "showXaxis": true,
                "showYaxis": true,
                "yAxis": {
                  "showLabelEllipsis": true,
                  "axisLabel": "Units Sales",
                  "showAxisLabel": false,
                  "showMajorGridLines": true
                }
              },
              "seriesConfig": {
              "showValues": true
              }
            }
          ],
          "chartProperty": {
            "legend": {
              "align": "BOTTOM",
              "quadrantLegend": false
            },
            "margin": {
              "bottom": 0,
              "left": 0,
              "right": 8,
              "top": 5
            },
            "showLegend": false,
            "haveLabelChart": false,
            "flipTable": false,
            "useInteractiveGuideline": true,
            "highlightOnlyFirstGroup": false,
            "minBarSize": 1,
            "preview": false,
            "shimmerAnimation": false,
            "stretchTo100Percent": false,
            "donut": false,
            "enableColoredIntersections": false,
            "useDynamicColors": false,
            "setBubbleLetter": false,
            "showBubblesCountLabel": false,
            "priceTierScatter": false,
            "dynamicYAxis": false,
            "setBubbleLetterOrderBySize": false
          }
        }
      ],
      "layout": {
        "type": "ABSOLUTE",
        "tiles": [
          {
            "type": "COMPONENT",
            "componentId": "30a69f2f-ee80-423c-a900-bcf840119aae",
            "x": 0,
            "y": 0,
            "height": 100,
            "width": 100
          }
        ]
      },
      "source": "",
      "dataSummary": {
        "footer": {
          "dataSourceInfo": {
            "displayText": "Dataset: NielsenIQ Retail Measurement - FMCG | Coke Total Beverage   | Entire Dataset Rule for 97212_2YATesting_9_July_21 ",
            "dataSourceTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#000000",
                "size": 11
              }
            }
          },
          "copyrightsInfo": {
            "displayText": "Copyright © 2026 Nielsen Consumer LLC. All Rights Reserved.",
            "copyrightsTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#000000",
                "size": 11
              }
            }
          },
          "termsAndConditionsInfo": {
            "termsAndConditionsText": "Terms & Conditions",
            "termsAndConditionsTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#0000FF",
                "size": 11
              },
              "underline": true
            },
            "termsAndConditionsHyperlinkTextStyle": {
              "bold": false,
              "alignment": "CENTER",
              "font": {
                "name": "Aktiv Grotesk",
                "color": "#0000FF",
                "size": 11
              },
              "underline": true
            }
          }
        },
        "header": {
          "summary": "#b#$#/b# of #b#TOTAL BEVERAGE#/b# in #b#Total US Mass#/b# during #b#Latest 52 Weeks#/b#",
          "headerTextStyle": {
            "bold": false,
            "alignment": "LEFT",
            "font": {
              "name": "Aktiv Grotesk",
              "color": "#000000",
              "size": 11
            },
            "underline": false
          },
          "title": "Untitled Report",
          "titleTextStyle": {
            "bold": false,
            "alignment": "LEFT",
            "font": {
              "name": "Aktiv Grotesk",
              "color": "#000000",
              "size": 13
            },
            "underline": false
          }
        }
      },
      "metaData": {
        "biCache": false,
        "dataRenamed": false,
        "cacheOriginTxId": "00BF508BAA594C0E90AE8631E926852C"
      },
      "filterSummary": {}
    }
  ],
  "timeMillis": 120
};

export const PIE_CHART_RESPONSE = {
  "data": [
    {
      "qid": "asasas",
      "components": [
        {
          "type": "CHART",
          "id": "30a69f2f-ee80-423c-a900-bcf840119aae",
          "objects": {
            "id": "30a69f2f-ee80-423c-a900-bcf8402323dddd",
            "attributes": {},
            "title": "How often do you purchase adult incontinence products at dollar stores?",
            "data": [
              {
                "options": "Every purchase occasion",
                "display_order": "1",
                "metric1": 11.379,
                "id": "17803"
              },
              {
                "options": "Most purchase occasions",
                "display_order": "2",
                "metric1": 7.397,
                "id": "17804"
              },
              {
                "options": "Some purchase occasions",
                "display_order": "3",
                "metric1": 2.869,
                "id": "17805"
              },
              {
                "options": "Rarely or never",
                "display_order": "4",
                "metric1": 5.379,
                "id": "17806"
              }
            ],
            "metadata": {
              "metric1": {
                "title": "Units Absolute",
                "type": "currency",
                "format": "$#,##0.0",
                "currencyLocale": "en_US",
                "currencyCode": "USD"
              }
            }
          },
          "chartType": "MULTIBAR_VERTICAL",
          "chartConfigs": [
            {
              "chartType": "PIE" as const,
              "dataDefinition": {
                "xaxis": [
                  {
                    "value": "options",
                    "displayValue": "options"
                  }
                ],
                "yaxis": {
                  "value": "metric1"
                }
              },
              "axisConfig": {
                "showXaxis": false,
                "showYaxis": false
              },
              "seriesConfig": {
                "showValues": true,
                "showMarker": true,
                "dataLabel": {
                  "font": {
                    "color": "contrast"
                  }
                }
              },
              "showPiePercentage": true
            }
          ],
          "chartProperty": {
            "legend": {
              "font": {
                "name": "'aktiv-grotesk', sans-serif",
                "color": "#262626",
                "size": 11
              },
              "align": "RIGHT"
            },
            "margin": {
             "right": 5,
             "top": 0
            }
          }
        }
      ]
    }
  ]
};

export const NPS_PIE_CHART_CONFIG: ChartConfig = {
  chartType: 'PIE',
  dataDefinition: {
    xaxis: [{ value: 'options', displayValue: 'options' }],
    yaxis: { value: 'metric1' },
  },
  axisConfig: { showXaxis: false, showYaxis: false },
  seriesConfig: {
    showValues: true,
    showMarker: true,
    dataLabel: { font: { color: 'contrast' } },
  },
  showPiePercentage: true,
  colorPalette: [
    '#aa213f',
    '#ffb500',
    '#008a28',
  ],
};

const NPS_PIE_DATA = [
  { options: 'Detractors', display_order: '1', metric1: 50, id: 'nps-detractors' },
  { options: 'Passives', display_order: '2', metric1: 30, id: 'nps-passives' },
  { options: 'Promoters', display_order: '3', metric1: 20, id: 'nps-promoters' },
];

export const NPS_PIE_CHART_RESPONSE: QuestionChartResponse = {
  ...PIE_CHART_RESPONSE,
  data: PIE_CHART_RESPONSE.data.map(question => ({
    ...question,
    components: question.components.map(component => ({
      ...component,
      chartConfigs: [NPS_PIE_CHART_CONFIG],
      objects: {
        ...component.objects,
        title: 'NPS Summary',
        data: NPS_PIE_DATA,
        metadata: {
          metric1: { title: 'Response Percentage', type: 'number', format: '#,##0.0' },
        },
      },
    })),
  })),
};

export const NPS_COLUMN_CHART_RESPONSE: QuestionChartResponse = {
  ...COLUMN_CHART_RESPONSE,
  data: COLUMN_CHART_RESPONSE.data.map(question => ({
    ...question,
    components: question.components.map(component => ({
      ...component,
      chartType: 'STACKED_VERTICAL',
      chartConfigs: [{
        chartType: 'STACKED_VERTICAL',
        dataDefinition: {
          xaxis: [
            { value: 'groupname', displayValue: 'groupname' },
            { value: 'id', displayValue: 'label' },
          ],
          series: [{ value: 'metric1' }, { value: 'metric2' }, { value: 'metric3' }],
        },
        axisConfig: {
          showXaxis: true,
          showYaxis: true,
          xAxis: { showDotterLine: true, showMajorGridLines: false },
          yAxis: { showAxisLabel: false, showMajorGridLines: true },
        },
        seriesConfig: { showValues: false },
        colorPalette: NPS_PIE_CHART_CONFIG.colorPalette,
      }],
      chartProperty: {
        showTransitionLinks: true,
        useInteractiveGuideline: true,
        showLegend: false,
      },
      objects: {
        ...component.objects,
        title: 'NPS Score Distribution',
        data: [42, 20, 8, 42, 20, 8, 63, 42, 42, 20, 8].map((value, score) => ({
          groupname: score <= 6 ? 'Detractors' : score <= 8 ? 'Passives' : 'Promoters',
          id: String(score),
          label: String(score),
          metric1: score <= 6 ? value : null,
          metric2: score >= 7 && score <= 8 ? value : null,
          metric3: score >= 9 ? value : null,
        })),
        metadata: {
          metric1: { title: 'Detractors', type: 'number', format: '#,##0.0' },
          metric2: { title: 'Passives', type: 'number', format: '#,##0.0' },
          metric3: { title: 'Promoters', type: 'number', format: '#,##0.0' },
        },
      },
    })),
  })),
};

// Add new sample responses here.
export const SURVEY_CHART_RESPONSES: Partial<Record<string, QuestionChartResponse>> = {
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.bar]: BAR_CHART_RESPONSE,
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.column]: COLUMN_CHART_RESPONSE,
  [RESULTS_DASHBOARD_CHART_TYPE_VALUES.pie]: PIE_CHART_RESPONSE
};


// Heat-grid sample response
export const HEAT_GRID_PREVIEW_RESPONSE: QuestionGridResponse = {
  "qid": "sample-heat-grid-question",
  "components": [
    {
      "type": "grid",
      "chartType": "GRID",
      "objects": {
        "title": "Please rate your level of agreement with the following statements regarding your current toothbrush:",
        "attributes": {
          "rowHeaderCount": "1",
          "columnHeaderCount": "1",
          "totalColumns": "8",
          "recordCount": 5,
          "totalRecordCount": 5
        },
        "data": [
          {
            "col1": {
              "cellValue": "Statement",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col1",
              "altDesc": "Statement"
            },
            "col2": {
              "cellValue": "Strongly Disagree",
              "id": "column2",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col2",
              "altDesc": "Strongly Disagree"
            },
            "col3": {
              "cellValue": "Disagree",
              "id": "column3",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col3",
              "altDesc": "Disagree"
            },
            "col4": {
              "cellValue": "Neutral",
              "id": "column4",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col4",
              "altDesc": "Neutral"
            },
            "col5": {
              "cellValue": "Agree",
              "id": "column5",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col5",
              "altDesc": "Agree"
            },
            "col6": {
              "cellValue": "Strongly Agree",
              "id": "column6",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col6",
              "altDesc": "Strongly Agree"
            },
            "col7": {
              "cellValue": "Overall",
              "id": "column7",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col7",
              "altDesc": "Overall"
            },
            "col8": {
              "cellValue": "Average Score",
              "id": "column8",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col8",
              "altDesc": "Average Score"
            }
          },
          {
            "col1": {
              "cellValue": "It easily reaches the very back of my mouth.",
              "altDesc": "It easily reaches the very back of my mouth.",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default"
            },
            "col2": {
              "cellValue": 6,
              "styleId": "style-unique-for-rule-2",
              "id": "column2"
            },
            "col3": {
              "cellValue": 7,
              "styleId": "style-unique-for-rule-2",
              "id": "column3"
            },
            "col4": {
              "cellValue": 10,
              "styleId": "style-unique-for-rule-3",
              "id": "column4"
            },
            "col5": {
              "cellValue": 11,
              "styleId": "style-unique-for-rule-3",
              "id": "column5"
            },
            "col6": {
              "cellValue": 12,
              "styleId": "style-unique-for-rule-3",
              "id": "column6"
            },
            "col7": {
              "cellValue": 42,
              "id": "column7"
            },
            "col8": {
              "cellValue": 3.4,
              "id": "column8"
            }
          },
          {
            "col1": {
              "cellValue": "The handle is comfortable to grip.",
              "altDesc": "The handle is comfortable to grip.",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default"
            },
            "col2": {
              "cellValue": 10,
              "styleId": "style-unique-for-rule-3",
              "id": "column2"
            },
            "col3": {
              "cellValue": 4,
              "styleId": "style-unique-for-rule-1",
              "id": "column3"
            },
            "col4": {
              "cellValue": 6,
              "styleId": "style-unique-for-rule-2",
              "id": "column4"
            },
            "col5": {
              "cellValue": 3,
              "styleId": "style-unique-for-rule-1",
              "id": "column5"
            },
            "col6": {
              "cellValue": 10,
              "styleId": "style-unique-for-rule-3",
              "id": "column6"
            },
            "col7": {
              "cellValue": 18,
              "id": "column7"
            },
            "col8": {
              "cellValue": 2.5,
              "id": "column8"
            }
          },
          {
            "col1": {
              "cellValue": "I feel my teeth are perfectly clean after brushing.",
              "altDesc": "I feel my teeth are perfectly clean after brushing.",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default"
            },
            "col2": {
              "cellValue": 2,
              "styleId": "style-unique-for-rule-1",
              "id": "column2"
            },
            "col3": {
              "cellValue": 10,
              "styleId": "style-unique-for-rule-3",
              "id": "column3"
            },
            "col4": {
              "cellValue": 4,
              "styleId": "style-unique-for-rule-1",
              "id": "column4"
            },
            "col5": {
              "cellValue": 2,
              "styleId": "style-unique-for-rule-1",
              "id": "column5"
            },
            "col6": {
              "cellValue": 7,
              "styleId": "style-unique-for-rule-2",
              "id": "column6"
            },
            "col7": {
              "cellValue": 18,
              "id": "column7"
            },
            "col8": {
              "cellValue": 2.6,
              "id": "column8"
            }
          },
          {
            "col1": {
              "cellValue": "The bristles are gentle on my gums.",
              "altDesc": "The bristles are gentle on my gums.",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default"
            },
            "col2": {
              "cellValue": 12,
              "styleId": "style-unique-for-rule-3",
              "id": "column2"
            },
            "col3": {
              "cellValue": 4,
              "styleId": "style-unique-for-rule-1",
              "id": "column3"
            },
            "col4": {
              "cellValue": 12,
              "styleId": "style-unique-for-rule-3",
              "id": "column4"
            },
            "col5": {
              "cellValue": 7,
              "styleId": "style-unique-for-rule-2",
              "id": "column5"
            },
            "col6": {
              "cellValue": 2,
              "styleId": "style-unique-for-rule-1",
              "id": "column6"
            },
            "col7": {
              "cellValue": 18,
              "id": "column7"
            },
            "col8": {
              "cellValue": 2.6,
              "id": "column8"
            }
          }
        ],
        "metadata": {
          "col1": {
            "type": "text",
            "hoverText": ""
          },
          "col2": {
            "type": "number",
            "hoverText": "Strongly Disagree",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          },
          "col3": {
            "type": "number",
            "hoverText": "Disagree",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          },
          "col4": {
            "type": "number",
            "hoverText": "Neutral",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          },
          "col5": {
            "type": "number",
            "hoverText": "Agree",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          },
          "col6": {
            "type": "number",
            "hoverText": "Strongly Agree",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          },
          "col7": {
            "type": "number",
            "hoverText": "Overall",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          },
          "col8": {
            "type": "number",
            "hoverText": "Average Score",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          }
        },
        "id": "SURVEY_RESULTS_HEAT_GRID",
        "currency": ""
      },
      "tableConfig": {
        "type": "grid",
        "id": "fde7a4f0-dd07-4cf9-b744-b4f1b42d5993",
        "chartType": "GRID",
        "headerRow": true,
        "columnStyleForHeader": false,
        "totalRow": false,
        "bandedRows": false,
        "firstColumn": false,
        "lastColumn": false,
        "bandedColumns": false,
        "transpose": true,
        "subtitleColumn": "col",
        "numberScalingInExport": false,
        "mode": "expand",
        "removeExtraColumn": true,
        "groupingEnabled": false,
        "showFooter": false,
        "numHeaderRows": 1,
        "rowProperties": {
          "style-unique-for-rule-1": {
            "shade": {
              "color": "#a3445e"
            },
            "textStyle": {
              "italic": false,
              "bold": false,
              "font": {
                "color": "#FFFFFF",
                "size": 14
              },
              "underline": false
            },
            "autoFit": false,
            "trimChar": 0
          },
          "style-unique-for-rule-2": {
            "shade": {
              "color": "#18a477"
            },
            "textStyle": {
              "italic": false,
              "bold": false,
              "font": {
                "color": "#FFFFFF",
                "size": 14
              },
              "underline": false
            },
            "autoFit": false,
            "trimChar": 0
          },
          "style-unique-for-rule-3": {
            "shade": {
              "color": "#0b513e"
            },
            "textStyle": {
              "italic": false,
              "bold": false,
              "font": {
                "color": "#FFFFFF",
                "size": 14
              },
              "underline": false
            },
            "autoFit": false,
            "trimChar": 0
          }
        },
        "defaultRowProperty": {
          "textStyle": {
            "alignment": "LEFT"
          },
          "shade": {
            "color": "#FDFDFD"
          },
          "bandedShade": {
            "color": "#e3e3e3"
          },
          "autoFit": false,
          "trimChar": 0,
          "pinnedLeft": false
        },
        "columnProperties": {
          "x0": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 300,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x1": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x2": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x3": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x4": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x5": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x6": {
            "textStyle": { "font": { "size": 14 } },
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x7": {
            "textStyle": { "font": { "size": 14 } },
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          }
        },
        "defaultColumnProperty": {
          "textStyle": {
            "alignment": "CENTER"
          },
          "autoFit": false,
          "trimChar": 0,
          "pinnedLeft": false
        },
        "dataDefinition": [
          {
            "value": "xcol1"
          },
          {
            "value": "xcol2"
          },
          {
            "value": "xcol3"
          },
          {
            "value": "xcol4"
          },
          {
            "value": "xcol5"
          },
          {
            "value": "xcol6"
          },
          {
            "value": "xcol7"
          },
          {
            "value": "xcol8"
          }
        ],
        "altDescEnabled": false,
        "hideInExport": false
      },
      "id": "SURVEY_RESULTS_HEAT_GRID"
    }
  ]
};

// Grid sample response
export const NORMAL_GRID_PREVIEW_RESPONSE: QuestionGridResponse = {
  "qid": "sample-grid-question",
  "components": [
    {
      "type": "grid",
      "chartType": "GRID",
      "objects": {
        "title": "Answer breakdown",
        "attributes": {
          "rowHeaderCount": "1",
          "totalColumns": "2",
          "columnHeaderCount": "1",
          "recordCount": 4,
          "totalRecordCount": 4
        },
        "data": [
          {
            "col2": {
              "cellValue": "Answer",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col2",
              "altDesc": "Answer"
            },
            "col3": {
              "cellValue": "Percentage",
              "id": "column2",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": false,
              "uniqueColumnId": "col3",
              "altDesc": "Percentage"
            }
          },
          {
            "col2": {
              "cellValue": "Every purchase occasion",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default",
              "altDesc": "Every purchase occasion"
            },
            "col3": {
              "cellValue": 42.11,
              "id": "column2"
            }
          },
          {
            "col2": {
              "cellValue": "Most purchase occasions",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default",
              "altDesc": "Most purchase occasions"
            },
            "col3": {
              "cellValue": 27.37,
              "id": "column2"
            }
          },
          {
            "col2": {
              "cellValue": "Some purchase occasions",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default",
              "altDesc": "Some purchase occasions"
            },
            "col3": {
              "cellValue": 10.62,
              "id": "column2"
            }
          },
          {
            "col2": {
              "cellValue": "Rarely or never",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default",
              "altDesc": "Rarely or never"
            },
            "col3": {
              "cellValue": 19.9,
              "id": "column2"
            }
          },
          {
            "col2": {
              "cellValue": "Other",
              "id": "column1",
              "mergeHeaderCell": "NONE",
              "mergeNextCell": false,
              "isConcat": true,
              "uniqueColumnId": "default",
              "altDesc": "Other"
            },
            "col3": {
              "cellValue": 0,
              "id": "column2"
            }
          },
        ],
        "metadata": {
          "col2": {
            "type": "text",
            "hoverText": ""
          },
          "col3": {
            "type": "number",
            "hoverText": "Percentage",
            "isSkipUISorting": false,
            "isSkipColFormatting": false
          }
        },
        "id": "SURVEY_RESULTS_GRID",
        "currency": ""
      },
      "tableConfig": {
        "type": "grid",
        "id": "fde7a4f0-dd07-4cf9-b744-b4f1b42d5993",
        "chartType": "GRID",
        "headerRow": true,
        "columnStyleForHeader": false,
        "totalRow": false,
        "bandedRows": false,
        "firstColumn": false,
        "lastColumn": false,
        "bandedColumns": false,
        "transpose": true,
        "subtitleColumn": "col",
        "numberScalingInExport": false,
        "mode": "expand",
        "removeExtraColumn": true,
        "groupingEnabled": false,
        "showFooter": false,
        "numHeaderRows": 1,
        "rowProperties": {},
        "defaultRowProperty": {
          "bandedShade": { "color": "#e3e3e3" },
          "autoFit": false,
          "trimChar": 0,
          "pinnedLeft": false
        },
        "columnProperties": {
          "x0": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          },
          "x1": {
            "cellTooltip": true,
            "enableColumnResizing": true,
            "enableColumnMoving": true,
            "enableSort": true,
            "enableFilter": true,
            "width": 160,
            "specificColorFormat": true,
            "autoFit": false,
            "trimChar": 0,
            "pinnedLeft": false
          }
        },
        "defaultColumnProperty": {
          "autoFit": false,
          "trimChar": 0,
          "pinnedLeft": false
        },
        "dataDefinition": [
          {
            "value": "xcol2"
          },
          {
            "value": "xcol3"
          }
        ],
        "altDescEnabled": false,
        "hideInExport": false
      },
      "id": "SURVEY_RESULTS_GRID"
    }
  ]
};

export const NPS_GRID_PREVIEW_RESPONSE: QuestionGridResponse = {
  ...NORMAL_GRID_PREVIEW_RESPONSE,
  qid: 'sample-nps-grid-question',
  components: NORMAL_GRID_PREVIEW_RESPONSE.components.map(component => ({
    ...component,
    objects: {
      ...component.objects,
      title: 'NPS Summary',
      attributes: {
        ...component.objects.attributes,
        recordCount: NPS_PIE_DATA.length,
        totalRecordCount: NPS_PIE_DATA.length,
      },
      data: [
        {
          ...component.objects.data[0],
          col2: { ...component.objects.data[0]['col2'], cellValue: 'Group', altDesc: 'Group' },
        },
        ...NPS_PIE_DATA.map((item, index) => ({
          col2: {
            cellValue: item.options,
            id: 'column1',
            mergeHeaderCell: 'NONE',
            mergeNextCell: false,
            isConcat: true,
            uniqueColumnId: 'nps-' + index,
            altDesc: item.options,
          },
          col3: { cellValue: item.metric1 + '%', id: 'column2' },
        })),
      ],
      metadata: {
        ...component.objects.metadata,
        col2: { type: 'text', hoverText: '' },
        col3: { type: 'number', hoverText: 'Percentage', isSkipUISorting: false, isSkipColFormatting: false },
      },
    },
  })),
};
