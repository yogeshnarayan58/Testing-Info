import { Locator } from "@playwright/test";
import { TimeoutOption } from "../../constants/optional-parameter-types";
import { getFirstLocator } from "./locator-utils";
import { BIG_TIMEOUT, SMALL_TIMEOUT } from "../../constants/time-out-constants";
import { getPage } from "./page-utils";



  /**
 * Service function to check if an element is visible on the page.
 * 
 * @param page - The Playwright Page object.
 * @param selector - The CSS selector for the element to check visibility.
 * @returns A promise that resolves to a boolean indicating if the element is visible.
 */
// export async function isElementVisible(selector: string): Promise<boolean> {
//   try {
//     // Use Playwright's `isVisible` method to check if the element is visible
//     // const isVisible = await getPage().isVisible(selector);
    
//     // Return the result (true if visible, false otherwise)
//     // return isVisible;
//   } catch (error) {
//     return false; // Return false if there's an error
//   }
// }

/**
 * Wait until element is visible.
 * @param {string | Locator} input - The input to create the Locator from.
 * @param {TimeoutOption} [options] - Optional timeout options.
 * @returns {Promise<boolean>} - True if the Locator is attached, false otherwise.
 */
export async function waitUntilVisible(input: string | Locator, options?: TimeoutOption): Promise<boolean> {
  const locator = getFirstLocator(input); // Assuming getLocator returns a Playwright Locator
  const timeoutInMs = options?.timeout || SMALL_TIMEOUT;

  try {
    await locator.waitFor({ state: 'visible', timeout: timeoutInMs });
    return true;
  } catch (error) {
    console.log(`isElementAttached- ${error instanceof Error ? error.message : String(error)}`);
    return false;
  }
}