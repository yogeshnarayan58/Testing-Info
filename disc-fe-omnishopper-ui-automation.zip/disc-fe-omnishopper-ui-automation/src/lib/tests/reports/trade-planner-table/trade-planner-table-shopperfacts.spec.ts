import test from "@playwright/test";
import {
  findDataSetByName,
  getDimensionSelectionsByPivot,
  getTestDataByLocale,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { ExportComponent } from "../../../common/components/export/export";
import assertionData from "./assertion-data/assertion-data.json";
import { assert } from "@gfk/gta";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
const reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;

const pivot: string = "Shopper facts";

test.describe("Trade Planner Table - Shopper facts", () => {
  let savedReportTitle: string = "";
  let savedReportUrl: string = "";

  test.beforeAll(() => {
    const isValidTestData =
      reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn(
        "Skipping Trade Planner Table - Shopper facts tests as the required pivot test data is not present"
      );
    }
    test.skip(
      !isValidTestData,
      "Skipping Trade Planner Table - Shopper facts tests as the required pivot test data is not present"
    );
  });
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag:"@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);

      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      // Open additional prompts to ensure madlib is visible
      await dataSelector.clickAdditionalPromptEllipsisIcon();

      // Validate using pattern matching with detailed results
      if (localeData.pivotMadlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any)[
          "shopperfacts"
        ];

        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", expectedMadlibText);

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(new RegExp(expectedMadlibText, "i"));

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else if (localeData.madlibText) {
        // Fallback to single madlib text if pivot-specific not available
        const actualMadlibText = await dataSelector.getMadlibText();
        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", localeData.madlibText);

        assert(actualMadlibText).toMatch(
          new RegExp(localeData.madlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
  test(
    "Validate run report",
    { tag: "@RunReport" },
    async () => {
        test.setTimeout(RUN_TEST_TIMEOUT);
        let basePage = await BasePageFactory.createBasePage();
        dataSelector = new DataSelector(basePage);

        await dataSelector.navigateToUrl(reportUrl);
        await dataSelector.switchPivotDropdown(pivot);
        await dataSelector.clickAdditionalPromptEllipsisIcon();

        // Get Shopper facts pivot data
        const shopperFactsData = getDimensionSelectionsByPivot(
          pivot,
          reportTestData
        );

        await dataSelector.clickMadlibDimension("Products");
        await dataSelector.setMadlibSelection(shopperFactsData["Products"]);

        await dataSelector.clickMadlibDimension("Focus Retailer-SHPGP1");
        await dataSelector.setMadlibSelection(
          shopperFactsData["Focus Retailer-SHPGP1"]
        );

        await dataSelector.clickMadlibDimension("Facts");
        await dataSelector.openPromptFactSelection(shopperFactsData["Facts"]);

        await dataSelector.clickMadlibDimension("Geographies");
        await dataSelector.setMadlibSelection(shopperFactsData["Geographies"]);

        await dataSelector.clickMadlibDimension("Periods");
        await dataSelector.setPeriodMadlibSelection(
          shopperFactsData["Periods"]
        );

        await dataSelector.clickMadlibDimension("Demographics");
        await dataSelector.setMadlibSelection(shopperFactsData["Demographics"]);

        await dataSelector.clickMadlibDimension("Shopper Facts People");
        await dataSelector.waitForMadlibStability();
        await dataSelector.clickMadlibDimension("peopleAddGroupButton");
        await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
        for (const selection of shopperFactsData["Shopper Facts People"].selections) {
        await dataSelector.handlePeopleMenuOptions(selection);
        }

        let dsBasePage = await dataSelector.getBasePage();
        commonTestCase = new CommonTestCase(dsBasePage);
        await commonTestCase.clickRunButton();
        await commonTestCase.waitForReportRunCompletion();

        console.log("run complete in spec");
        const { newReportTitle, newUrl } =
          await commonTestCase.saveReport();
        savedReportTitle = newReportTitle;
        savedReportUrl = newUrl;
        console.log("savedReportTitle:", savedReportTitle);
        console.log("savedReportUrl:", savedReportUrl);
      }
    );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });

  test(
    "Validate PPT export",
    { tag: "@ValidatePPTExport" },
    async () => {
      let exportComponent: ExportComponent;
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      let commonBasePage = await commonTestCase.getBasePage();
      exportComponent = new ExportComponent(commonBasePage);
      await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
    }
  );

  test(
    "Validate Excel export",
    { tag: "@ValidateExcelExport" },
    async () => {
      let exportComponent: ExportComponent;
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      let commonBasePage = await commonTestCase.getBasePage();
      exportComponent = new ExportComponent(commonBasePage);
      await exportComponent.validateExportFunctionality(
        "Excel",
        "Editable objects",
        "Separately"
      );
    }
  );
  }
);
});
