import fs from 'fs';
import path from 'path';
import { config } from '../config';

export type RecordedStatus = 'Pass' | 'Fail' | 'Skip';

export interface RecordedTestResult {
  title: string;
  status: RecordedStatus;
  reportName: string;
  tags: string[];
  errorMessage?: string;
}

type PlaywrightReport = {
  suites?: PlaywrightSuite[];
};

type PlaywrightSuite = {
  title?: string;
  suites?: PlaywrightSuite[];
  specs?: PlaywrightSpec[];
};

type PlaywrightSpec = {
  title: string;
  tags?: string[];
  tests?: PlaywrightTest[];
};

type PlaywrightTest = {
  projectName?: string;
  status?: string;
  results?: PlaywrightTestResult[];
};

type PlaywrightTestResult = {
  status?: string;
  error?: { message?: string };
  errors?: Array<{ message?: string }>;
};

const resolveDefaultReportPath = () =>
  path.resolve(process.cwd(), config.DEFAULT_REPORT_PATH);

export async function readRecordedTestResults(
  reportPath: string = resolveDefaultReportPath()
): Promise<RecordedTestResult[]> {
  try {
    await fs.promises.access(reportPath, fs.constants.R_OK);
  } catch {
    console.warn(
      `[testResultsReader] Report file not found or unreadable at ${reportPath}`
    );
    return [];
  }

  try {
    const content = await fs.promises.readFile(reportPath, 'utf-8');
    const parsed: PlaywrightReport = JSON.parse(content);
    return collectResultsFromSuites(parsed.suites ?? []);
  } catch (error) {
    console.error(
      '[testResultsReader] Unable to parse Playwright JSON report:',
      error
    );
    return [];
  }
}

const collectResultsFromSuites = (
  suites: PlaywrightSuite[]
): RecordedTestResult[] => {
  const results: RecordedTestResult[] = [];
  const seenTestKeys = new Set<string>(); 

  const walkSuites = (
    suite: PlaywrightSuite,
    reportName?: string
  ) => {
    const resolvedReportName = reportName ?? suite.title ?? 'Unknown Report';

    suite.specs?.forEach(spec => {
      spec.tests?.forEach(test => {
        const latestResult = [...(test.results ?? [])].reverse()[0];
        const status = mapStatus(latestResult?.status ?? test.status);
        const errorLines = latestResult?.errors?.map(e => e.message);
        const errorMessage =
          latestResult?.error?.message ||
          (errorLines && errorLines.length > 0
            ? errorLines.join('\n')
            : undefined);

        const title = test.projectName
          ? `[${test.projectName}] ${spec.title}`
          : spec.title;

        const normalizedTags = (spec.tags ?? []).map(tag =>
          tag.startsWith('@') ? tag : `@${tag}`
        );

        const key = `${title}-${resolvedReportName}`;
        if (seenTestKeys.has(key)) {
          return;
        }
        seenTestKeys.add(key);

        results.push({
          title,
          status,
          errorMessage,
          tags: normalizedTags,
          reportName: resolvedReportName.trim()
        });
      });
    });

    suite.suites?.forEach(childSuite =>
      walkSuites(childSuite, resolvedReportName)
    );
  };

  suites.forEach(suite => walkSuites(suite));
  return results;
};

const mapStatus = (status?: string): RecordedStatus => {
  switch (status) {
    case 'passed':
      return 'Pass';
    case 'skipped':
      return 'Skip';
    default:
      return 'Fail';
  }
};
