import { describe, expect, it } from 'vitest';
import {
  ADD_MORE_QUESTIONS_DEFAULT_COUNT,
  createAddMoreQuestionsPayload,
  DimensionKeys,
  QuestionTypes,
  MAXIMUM_OPTIONS_ALLOWED,
  DefaultQuestionTypes
} from './build-survey';

describe('createAddMoreQuestionsPayload', () => {
  it('builds a trimmed payload with the default count', () => {
    const labels: Record<string, string> = {
      [DimensionKeys.demographic]: ' Adults 18-45 ',
      [DimensionKeys.geography]: ' United States ',
      [DimensionKeys.period]: ' Last 30 days ',
      [DimensionKeys.product]: ' Snacks ',
      [DimensionKeys.retailer]: ' All Retailers ',
    };

    const payload = createAddMoreQuestionsPayload(
      dimension => labels[dimension] ?? '',
      '  Generate more  ',
      [{ text: 'Existing question' }],
      [QuestionTypes.Text],
    );

    expect(payload.prompt).toEqual({
      demographic: 'Adults 18-45',
      geography: 'United States',
      period: 'Last 30 days',
      product: 'Snacks',
      questionCount: ADD_MORE_QUESTIONS_DEFAULT_COUNT,
      retailer: 'All Retailers',
      userPrompt: 'Generate more',
      excludeQuestions: [{ text: 'Existing question' }],
      questionTypes: [QuestionTypes.Text],
    });
  });

  it('uses defaults for blank values', () => {
    const payload = createAddMoreQuestionsPayload(
      () => '   ',
      '',
      [],
      [],
    );

    expect(payload.prompt.demographic).toBe('Adults 18-45');
    expect(payload.prompt.geography).toBe('United States');
    expect(payload.prompt.period).toBe('Last 30 days');
    expect(payload.prompt.product).toBe('Snacks');
    expect(payload.prompt.retailer).toBe('All Retailers');
    expect(payload.prompt.userPrompt).toBe('Generate additional relevant survey questions');
  });

  it('uses defaults for null values', () => {
    const payload = createAddMoreQuestionsPayload(
      () => null as unknown as string,
      null as unknown as string,
      [],
      [],
    );

    expect(payload.prompt.demographic).toBe('Adults 18-45');
    expect(payload.prompt.userPrompt).toBe('Generate additional relevant survey questions');
  });

  it('uses a custom question count', () => {
    const payload = createAddMoreQuestionsPayload(() => 'Value', 'Prompt', [], [], 8);

    expect(payload.prompt.questionCount).toBe(8);
  });

describe('MAXIMUM_OPTIONS_ALLOWED constant', () => {
  it('exports MAXIMUM_OPTIONS_ALLOWED as 15', () => {
    expect(MAXIMUM_OPTIONS_ALLOWED).toBe(15);
  });

  it('MAXIMUM_OPTIONS_ALLOWED is a number', () => {
    expect(typeof MAXIMUM_OPTIONS_ALLOWED).toBe('number');
  });
});

describe('DefaultQuestionTypes', () => {
  it('includes SinglePointScale', () => {
    expect(DefaultQuestionTypes).toContain(QuestionTypes.SinglePointScale);
  });

  it('includes MultiplePointScale', () => {
    expect(DefaultQuestionTypes).toContain(QuestionTypes.MultiplePointScale);
  });

  it('includes SingleChoice', () => {
    expect(DefaultQuestionTypes).toContain(QuestionTypes.SingleChoice);
  });

  it('includes MultipleChoice', () => {
    expect(DefaultQuestionTypes).toContain(QuestionTypes.MultipleChoice);
  });

  it('includes StarRating', () => {
    expect(DefaultQuestionTypes).toContain(QuestionTypes.StarRating);
  });

  it('includes NetPromoterScore', () => {
    expect(DefaultQuestionTypes).toContain(QuestionTypes.NetPromoterScore);
  });

  it('has exactly 6 default question types', () => {
    expect(DefaultQuestionTypes.length).toBe(6);
  });

  it('has no duplicate question types', () => {
    const uniqueTypes = new Set(DefaultQuestionTypes);
    expect(uniqueTypes.size).toBe(DefaultQuestionTypes.length);
  });
});
});
