import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { IconButtonModule, StepComponent, StepperComponent, ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { catchError, distinctUntilChanged, filter, map, of, Subject, takeUntil } from 'rxjs';
import { FLOW_TYPES, FlowType, SURVEY_FLOW_STEPS } from '../../../core/config/config';
import { SurveyService } from '../../../features/build-survey/services/survey.service';
import { SurveyCommonService } from '../../services/survey-common.service';
import { DatasetFooterComponent } from '../dataset-footer/dataset-footer.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'survey-crf-survey-wrapper',
  imports: [RouterModule, StepComponent, StepperComponent, CommonModule, IconButtonModule, DatasetFooterComponent, TranslateModule],
  templateUrl: './crf-survey-wrapper.component.html',
  styleUrl: './crf-survey-wrapper.component.scss',
  standalone: true,
})
export class CrfSurveyWrapperComponent implements OnInit, OnDestroy {
  constructor(
    private readonly router: Router,
    private readonly surveyService: SurveyService,
    private readonly translate: TranslateService
  ) { }
  public readonly surveyCommonService = inject(SurveyCommonService);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly destroy$ = new Subject<void>();
  private readonly toastService = inject(ToastService);
  readonly isPanelOpen = computed(() => this.surveyCommonService.isPanelOpen());
  readonly steps = [
    { label: 'SURVEYMOD_SELECT_PANELISTS', route: SURVEY_FLOW_STEPS.SELECT_PANELIST },
    { label: 'SURVEYMOD_BUILD_SURVEY', route: SURVEY_FLOW_STEPS.BUILD_SURVEY },
    { label: 'SURVEYMOD_SURVEY_RESULTS', route: SURVEY_FLOW_STEPS.RESULTS },
  ];

  get currentStep(): number {
    const activeStep = this.surveyCommonService.activeSurveyStep();
    return activeStep === SURVEY_FLOW_STEPS.RESULTS ? this.steps.length : this.steps.findIndex(step => step.route === activeStep);
  }

  get isDatasetEditable(): boolean {
    return this.surveyCommonService.activeSurveyStep() === SURVEY_FLOW_STEPS.SELECT_PANELIST;
  }

  get isDatasetFooterHidden(): boolean {
    return this.isDatasetEditable && !this.surveyCommonService.getSelectedDatasetDisplay();
  }

  ngOnInit(): void {
    this.activatedRoute.firstChild?.paramMap
      .pipe(
        map(params => params.get('surveyId')),
        filter((surveyId): surveyId is string => !!surveyId),
        distinctUntilChanged()
      )
      .subscribe(surveyId => {
        this.ensureSurveyLoaded(surveyId);
      });

    const flowType = this.activatedRoute.snapshot.pathFromRoot
      .map(route => route.data['flowType'])
      .find(Boolean) as FlowType | undefined;
    this.surveyCommonService.setFlowType(flowType ?? FLOW_TYPES.SCRATCH);
  }

  /** Fail-safe redirect keeps users on a recoverable step when deep-link survey restore fails. */
  private ensureSurveyLoaded(surveyId: string): void {
    this.surveyService.ensureSurveyLoaded(surveyId)
      .pipe(
        takeUntil(this.destroy$),
        catchError(() => {
          this.toastService.InsertToast('error', this.translate.instant('SURVEYMOD_LOAD_SURVEY_FAILED'), { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
          void this.router.navigate([SURVEY_FLOW_STEPS.SELECT_PANELIST], { relativeTo: this.activatedRoute.parent ?? this.activatedRoute });
          return of(null);
        }),
      )
      .subscribe();
  }

  /** Step completion rules depend on panelist completion state, not just URL position. */
  isStepCompleted(index: number): boolean {
    return index < this.currentStep ||
      (index === 0 && this.surveyCommonService.panelistCompleted());
  }

  /** Step navigation enforces linear progression and appends surveyId when available to preserve editing context. */
  onStepClick(stepIndex: number): void {
    const step = this.steps[stepIndex];
    if (!step) {
      return;
    }

    // Results page is terminal: do not allow navigating back to previous steps from here.
    if (this.surveyCommonService.activeSurveyStep() === SURVEY_FLOW_STEPS.RESULTS && stepIndex < this.steps.length - 1) {
      return;
    }

    if (stepIndex > this.currentStep) {
      if (stepIndex > 0 && !this.surveyCommonService.panelistCompleted()) {
        return;
      }
      if (stepIndex > this.currentStep + 1) {
        return;
      }
    }
    const surveyId = this.surveyService.currentSurveyId?.trim();
    if (stepIndex !== this.currentStep) {
       this.surveyCommonService.setPanelOpen(false);
    }

    const route = surveyId
      ? [step.route, surveyId]
      : [step.route];

    void this.router.navigate(route, { relativeTo: this.activatedRoute });
  }

  /** Footer click delegates picker open through shared service so selector can react via trigger signal. */
  onDatasetFooterClick(): void {
    if (!this.isDatasetEditable) {
      return;
    }

    this.surveyCommonService.requestDatasetPickerOpen();
  }

  /** Determines if a step can be clicked based on navigation rules. */
  isStepClickable(index: number): boolean {
    const step = this.steps[index];
    if (!step) return false;

    if (this.surveyCommonService.activeSurveyStep() === SURVEY_FLOW_STEPS.RESULTS && index < this.steps.length - 1) {
      return false;
    }

    if (index > this.currentStep) {
      // Previous step must be completed before advancing
      if (!this.isStepCompleted(index - 1)) {
        return false;
      }
      if (index > this.currentStep + 1) {
        return false;
      }
    }
    return true;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
