import test from "@playwright/test";
import {
  findDataSetByName,
  hasPivotInDimensionSelections,
  getDimensionSelectionsByPivot
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";

let reportTestData = findDataSetByName(devTestData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";

test.describe.serial("Consumer Performance Competitive Analysis (Quick Insights) - Retailer", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test(
    "Run Report: Should successfully execute Quick Insights report with selected data",
    {
      tag: "@QI:Report_E2E_Flow",
    },
    async () => {
      const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
      if (!isValidTestData) {
        console.warn('Skipping tests as the required pivot test data is not present');
      }
      test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
      
      test.setTimeout(RUN_TEST_TIMEOUT);
      
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(reportUrl);
      
      let commonBasePage = commonTestCase.getBasePage();
      dataSelector = new DataSelector(commonBasePage);

      const retailerPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
      if (!retailerPivotData) {
        throw new Error("Pivot not found in test data: Retailer");
      }

      // Select all dimensions from test data
      
      // 1. Select Facts
      await dataSelector.clickMadlibDimension("Facts");
      await dataSelector.selectClosedDropdown(retailerPivotData["Facts"]["selections"]);

      // 2. Select Product (singular)
      await dataSelector.clickMadlibDimension("Product");
      await dataSelector.setMadlibSelection(retailerPivotData["Product"]);

      // 3. Select Retailers
      await dataSelector.clickMadlibDimension("Retailers");
      await dataSelector.setMadlibSelection(retailerPivotData["Retailers"]);

      // 4. Select Period
      await dataSelector.clickMadlibDimension("Period");
      await dataSelector.setPeriodMadlibSelection(retailerPivotData["Period"]);

      // 5. Select Comparison Period
      await dataSelector.clickMadlibDimension("Comparison Period");
      await dataSelector.setPeriodMadlibSelection(retailerPivotData["Comparison Period"]);

      // 6. Select Geography
      await dataSelector.clickMadlibDimension("Geography");
      await dataSelector.setMadlibSelection(retailerPivotData["Geography"]);

      // 7. Select Demographic
      await dataSelector.clickMadlibDimension("Demographic");
      await dataSelector.setMadlibSelection(retailerPivotData["Demographic"]);

      // Run report
      let dsBasePage = await dataSelector.getBasePage();
      commonTestCase = new CommonTestCase(dsBasePage);
      await commonTestCase.clickRunButton();
      await commonTestCase.waitForReportRunCompletion();

      console.log("✅ Quick Insights Retailer report executed successfully");

      // Wait for UI to stabilize before saving
      await basePage.getWebActions().delay(SMALL_TIMEOUT);

      // Save report
      const { newReportTitle, newUrl } = await commonTestCase.saveReport();
      savedReportTitle = newReportTitle;
      savedReportUrl = newUrl;

      console.log("Saved Report Title:", savedReportTitle);
      console.log("Saved Report URL:", savedReportUrl);
    }
  );
  
  
  test(
    "Validate PPT export",
    {
      tag: "@QI:ValidatePPTExport",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      test.skip(!savedReportUrl, 'Skipping PPT Export - Report not generated. Run with @Report_E2E_Flow first');
      
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      
      // Wait for report to fully load before exporting
      await commonTestCase.waitForReportRunCompletion();
      console.log("Report loaded successfully - ready for export");
      
      // Small delay for UI stabilization
      await basePage.getWebActions().delay(SMALL_TIMEOUT);
      
      let commonBasePage = commonTestCase.getBasePage();
      let exportComponent = new ExportComponent(commonBasePage);
      
      await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");

      console.log("✅ Quick Insights Retailer PPT export validated successfully");
    }
  );

  test(
    "Validate Excel export",
    {
      tag: "@QI:ValidateExcelExport",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      test.skip(!savedReportUrl, 'Skipping Excel Export - Report not generated. Run with @Report_E2E_Flow first');
      
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      
      // Wait for report to fully load before exporting
      await commonTestCase.waitForReportRunCompletion();
      console.log("Report loaded successfully - ready for export");
      
      // Small delay for UI stabilization
      await basePage.getWebActions().delay(SMALL_TIMEOUT);
      
      let commonBasePage = commonTestCase.getBasePage();
      let exportComponent = new ExportComponent(commonBasePage);
      
      await exportComponent.validateExportFunctionality("Excel", "Editable objects", "Separately");

      console.log("✅ Quick Insights Retailer Excel export validated successfully");
    }
  );

  test(
    "Snapshot: Should successfully create snapshot of Quick Insights report",
    {
      tag: "@QI:Snapshot",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @Report_E2E_Flow first');
      
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      
      let snapshot = new Snapshot(commonTestCase.getBasePage());
      await snapshot.waitForReportRunCompletion();
      await basePage.getWebActions().delay(SMALL_TIMEOUT);
      
      await snapshot.clickSaveIcon();
      await basePage.getWebActions().delay(SMALL_TIMEOUT);
      
      await snapshot.clickSnapshotIcon();
      await basePage.getWebActions().delay(SMALL_TIMEOUT);
      
      assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
      await snapshot.shiftingToSnapshot();

      console.log("✅ Quick Insights Retailer snapshot created successfully");
    }
  );

  test(
    "Validate FullScreen",
    {
      tag: "@QI:ValidateFullScreen",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @Report_E2E_Flow first');
      
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      
      await commonTestCase.fullScreenView();
      
      console.log("✅ Quick Insights Retailer full-screen view validated successfully");
    }
  );

  test(
    "Validate presentationMode",
    {
      tag: "@QI:PresentationMode",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @Report_E2E_Flow first');
      
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(savedReportUrl);
      
      await commonTestCase.presentationMode();
      
      console.log("✅ Quick Insights Retailer presentation mode validated successfully");
    }
 );
});
