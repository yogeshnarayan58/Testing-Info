# Automation plan — remaining / new E2E test cases

Read-only investigation. No code was changed. Scope: `e2e/**` and `libs/survey-mod-lib/**` (app source) only;
third-party packages in `node_modules` (`@nielsen/crf-ui-components`, `@nielsen/crf-data-summary`,
`@nielsen/crf-rv-common`, `@nielseniq/athena-core`) were **not** inspected for this pass — where a case depends on
one of those, it is called out explicitly in step 7.

Two cases in the original ask (TC_BS_20, TC_BS_22 register-in-Prompt, and the TC_AI_05 non-empty-text assertion)
were already implemented earlier in this session — see the note at the top of each section below instead of a plan.

---

## TC_BS_20 — Delete the last question then re-add the same type as last

**Status: already done.** `registerDeleteLastThenReAddTest` now lives in
[build-survey-common-test-cases.ts](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/tests/survey/common-test-cases/build-survey-common-test-cases.ts)
and is called from both
[start-from-scratch.spec.ts](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/tests/survey/start-from-scratch.spec.ts)
(after `registerDeleteLastThenReAddTest`'s sibling, in the same slot as before) and
[start-with-prompt.spec.ts](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/tests/survey/start-with-prompt.spec.ts)
(right after `registerCancelAddQuestionTest`, which itself sits after `registerDeleteDuplicateQuestionTest`, matching the
requested ordering). It starts from whatever question count exists via the shared `ensureAtLeastOneQuestion` /
`ensureAddQuestionEnabled` helpers (also exported from the common file), so it does not assume 0 or exactly N
questions in either flow.

## TC_BS_22 — Discard a new question via Add Question cancel, then add and save one

**Status: already done.** Same commit as TC_BS_20 above; see `registerDiscardNewQuestionThenSaveTest` in the same
file and the same two call sites.

## TC_AI_05 — Generate questions creates AI questions (non-empty text)

**Status: already done.** [start-with-prompt.spec.ts](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/tests/survey/start-with-prompt.spec.ts)'s
TC_AI_05 now loops `index` from 0 to `after` and asserts
`surveyBuilderPage.getQuestionTextDisplay(index).trim() !== ''`, including the index in the failure message. It
reused the existing `getQuestionTextDisplay(index)` on `SurveyBuilderPage` — no new helper or locator was added.

---

## TC_AI_01 — Select Panelists screen shows "Let's get you started with Optiq!", prompt textbox, Generate Survey state

**1. Spec / flow / order.** Prompt only. `select-panelist.component.html` renders the AI-flow heading only when
`surveyCommonService.flowType().aiflow` is true, so this can only run in `start-with-prompt.spec.ts`. Natural slot:
right after the `'Generate Survey: Should fill the prompt and reach the Build Survey page'` setup test is too late
(prompt is already submitted/cleared); it has to run **before** `fillPromptAndGenerate` is called, i.e. right after
the `'Response Count: Should select a response count'` test and before `'Generate Survey: ...'`. At that point the
response count is chosen but the prompt textarea + Generate Survey button are both visible and prompt is still
empty — ideal for asserting both the heading and the disabled-button case in one test.

**2. Reuse.** `StartWithPromptPage` doesn't expose a heading or prompt-state check yet. `SelectPanelistPage` isn't
usable here (different component). `promptTextarea` / `generateSurveyButton` locators already exist in
[start-with-prompt.locator.json](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/locators/survey/start-with-prompt.locator.json)
(`textarea.prompt-input`, `[data-test-id='proceed-to-survey']`) and are reusable for reading/filling the prompt and
checking the button's native `disabled` attribute.

**3. New locators.** Need one for the heading text. [select-panelist.component.html](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/select-panelist/components/select-panelist.component.html) line 3-5:
```html
<div class="title">
  {{ ... ? ('SURVEYMOD_LETS_GET_YOU_STARTED_WITH_OPTIQ' | translate) : (...) }}
</div>
```
`.title` has **no `data-test-id`** → **fragile** (class-only, text content driven by i18n key, exact English text
not verifiable from this repo — see step 7). Recommend `text="Let's get you started with Optiq!"` as an interim
selector (same convention as other text-based locators in this file, e.g. `confirmPublishDialogText`), or request a
`data-test-id="select-panelist-heading"` from the app team. The AI "Optiq" badge image already has a stable ID
(`data-test-id="build-survey-with-ai-optiq-image"`) and could substitute as an aiflow-detection signal if the
heading text turns out unstable.

**4. State.** Needs: dataset selected, 5 filters set, a response count chosen (so the Generate Survey button's only
remaining gate is the empty prompt). Leaves: nothing consumed — the existing `fillPromptAndGenerate` test still runs
right after and fills/submits normally.

**5. Prompt vs Scratch.** This is Prompt-only; Scratch's `select-panelist.component.html` renders the non-AI heading
and never shows the prompt textarea/Generate Survey button (both gated by `flowType().aiflow`).

**6. Effort/risk.** S. Low risk — all elements are in this repo's own template; only risk is the heading text locator
being fragile pending a real data-test-id.

**7. Verify on DEV.** Exact rendered English text of `SURVEYMOD_LETS_GET_YOU_STARTED_WITH_OPTIQ` (i18n strings live in
the host app, not this repo).

---

## TC_AI_03 — Question count 3-10 via slider + number field, including out-of-range

**1. Spec / flow / order.** Prompt only (the slider only appears on the "Customize Questions" screen reached from the
AI flow). Natural slot: right next to `TC_AI_04` (question-type selection), since both live on the same
`survey-question-generator` card shown after `'Generate Survey: ...'` and before `TC_AI_05`'s Generate click —
insert a `TC_AI_03` test between `'Generate Survey: ...'` and `TC_AI_04`.

**2. Reuse.** `StartWithPromptPage.selectQuestionType` / `isQuestionTypeSelected` show the pattern for reading a
sibling control on the same card; `getGeneratedQuestionCount()` is reusable afterward to confirm the actual question
count matches the slider value once Generate is clicked.

**3. New locators.** [question-generator.html](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/build-survey/components/question-generator/question-generator.html):
```html
<niq-slider data-test-id="question-count-slider" [minValue]="minQuestionCount()" [maxValue]="maxQuestionCount()" ...>
@if (isQuestionCountOutOfRange()) {
  <div class="question-count-error" role="alert">{{ 'SURVEYMOD_PLEASE_ENTER_VALUE_BETWEEN' | translate: ... }}</div>
}
<niq-button data-test-id="generate-questions" ... [state]="... isQuestionCountOutOfRange() ? 'disabled' : ...">
```
`question-count-slider` is a **stable** data-test-id already in the app template (flagged as unused in
[LOCATOR_TESTID_INVESTIGATION.md](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/investigation/LOCATOR_TESTID_INVESTIGATION.md)
— "no scoped locator uses it"), so add it to `survey-builder.locator.json`/`start-with-prompt.locator.json`. The
`.question-count-error[role=alert]` has **no data-test-id** → fragile (class + role only); recommend adding
`data-test-id="question-count-error"`. `generate-questions` is already a locator (reused for the disabled check).
The "number field" the task mentions is **not in this repo's template** — `niq-slider` is an external
`@nielseniq/athena-core` (or similar) component; if it renders an internal numeric input synced to the slider, its
markup was not inspected (out of scope this pass) — see step 7.

**4. State.** Needs: prompt submitted, Build Survey question-generator card visible (same state TC_AI_04 needs).
Leaves: whatever `questionCount` value the test ends on becomes the count requested on the next Generate click, so
the test must finish by resetting the slider to a valid value (e.g. the default 5) before TC_AI_04/TC_AI_05 run, or
run entirely with `onGenerateQuestions` never invoked for the out-of-range sub-case.

**5. Prompt vs Scratch.** Scratch never reaches this screen — `showQuestionCount()` / the whole
`survey-question-generator` card is part of the AI-generation step, which Scratch's `BuildSurveyComponent` flow
does not use (Scratch starts from the empty "Add question" panel, not a generator form).

**6. Effort/risk.** M. The slider itself (`niq-slider`) is an external component — setting its value via Playwright
may need `fill`/keyboard arrows rather than a simple click, and its internal numeric-input markup (if any) is
unverified. `ADD_MORE_QUESTIONS_DEFAULT_COUNT = 3`, `MAX_SURVEY_QUESTIONS = 10`, `QUESTION_COUNT_DEFAULT = 5` are
confirmed in [models/build-survey.ts](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/build-survey/models/build-survey.ts),
so the 3-10 range and default are not in question.

**7. Verify on DEV.** Whether `niq-slider` exposes a separate editable number input alongside the thumb (task implies
"slider + number field"); exact interaction needed to set an out-of-range value (typing past max, or dragging).

---

## TC_BS_17 — Cancel the "Publish your survey" popup without publishing

**1. Spec / flow / order.** Both flows (Build Survey is shared). Best slot: inside the existing `test.fixme('TC_BS_16/TC_BS_18: Publish survey', ...)` area in
[start-from-scratch.spec.ts](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/tests/survey/start-from-scratch.spec.ts) —
add a standalone `TC_BS_17` test immediately before it (so Cancel is proven before the fixme'd real-publish test
eventually runs), tagged `@PublishSurvey`. Needs ≥3 questions (same precondition as publish), so place it after
`registerValidateSurveyTest`/`registerDeleteLastThenReAddTest` like the fixme test already does.

**2. Reuse.** `SurveyBuilderPage.publishSurvey(title)` already opens this exact dialog (its internal
`fillSaveCopyDialog` only runs when the title input is visible) — reuse its first half (click
`publishSurveyButton`, wait for `saveCopyTitleInput`) and stop there instead of calling `fillSaveCopyDialog`.
`getQuestionCount()` / `getCurrentUrl()` to assert state is unchanged after Cancel.

**3. New locators.** Confirmed from [survey-header.component.html](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/build-survey/components/survey-header/survey-header.component.html)
line 69-83: the "Publish your survey" popup **is** the same `<crf-uic-save-a-copy>` dialog used for Save Draft —
its title switches to `SURVEYMOD_PUBLISH_YOUR_SURVEY` via `isPublishAction()`, and it has `[cancelText]="'CANCEL' | translate"`
wired to `(closeDialog)="saveDraftDialog.close()"`. The dialog itself is the external
`@nielsen/crf-ui-components` `crf-uic-save-a-copy` (same component `saveCopyTitleInput`/`savePendingChangesButton`
already target) — its Cancel button's internal data-test-id was **not inspected this pass** (see step 7); treat as
**fragile** until confirmed — a text-based `role=button[name="Cancel"]` scoped to the dialog, or (once confirmed) a
stable data-test-id, both work.

**4. State.** Needs: ≥3 questions (so Publish isn't disabled). Leaves: must end back on Build Survey with the same
question count/title as before — i.e. the test must confirm the dialog closed and no navigation/save happened
before any later test (e.g. the real publish fixme) runs.

**5. Prompt vs Scratch.** No difference — `survey-header.component.html` is shared by both flows.

**6. Effort/risk.** S-M. Mechanically simple, but the dialog is third-party, so the Cancel button's selector needs a
DEV check (see step 7) before it can be marked stable.

**7. Verify on DEV.** The internal data-test-id (if any) on the Save-a-copy dialog's Cancel button, and confirm
clicking it does not also discard in-progress typed text in the title field (vs. just closing the dialog).

---

## TC_AI_14 / TC_BS_24 — Create a new folder from the Publish popup, cancel folder creation

**1. Spec / flow / order.** Both flows share the same Save-a-copy/Publish dialog, so write it once in
`build-survey-common-test-cases.ts` as `registerCreateFolderFromPublishTest` and call it from both specs right after
the (not yet implemented) TC_BS_17 test — same precondition (≥3 questions, Publish dialog open).

**2. Reuse.** Start from the same `publishSurveyButton` click `SurveyBuilderPage.publishSurvey()` uses up to the
point the title input is visible; `SurveyBuilderPage`'s private `selectSaveLocation()` already demonstrates reaching
into the dialog's folder tree via the Playwright-native escape hatch
(`(BasePage as any).page as import('playwright').Page`) — the same pattern is needed here for the "+ Create new
folder" trigger and the nested create-folder dialog.

**3. New locators.** From `survey-header.component.html` lines 69-92, `<crf-uic-save-a-copy>` emits `(newFolder)`
when its internal "+ Create new folder" control is clicked, opening `<crf-uic-create-folder #createFolderDialog>`
(cancel → `surveyCommonService.reopenFolderDialog(...)`, save →
`surveyCommonService.createFolderInSelectedLocation(...)`). **Neither `<crf-uic-save-a-copy>` nor this
`<crf-uic-create-folder>` instance carries any `data-test-id` in this app template** (contrast with My Assets' own
`<crf-uic-create-folder data-test-id="create-folder-dialog">` in
[my-assets-page.component.html](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/my-assets/components/my-assets-page.component.html) —
that one is a **different** dialog instance, not reachable from Publish). Both components are external
`@nielsen/crf-ui-components`; their internal "+ Create new folder" label, folder-name input, Cancel, and
Create/Save buttons were **not inspected this pass** — mark all as **fragile** pending a DEV/source check (see step
7). Recommend requesting `data-test-id`s on the Publish-side `#saveDraftDialog`/`#createFolderDialog` hosts, mirroring
what My Assets already has.

**4. State.** Needs: ≥3 questions, Publish dialog open (title input visible). Leaves: cancelling folder creation
must land back on the Save-a-copy/Publish dialog per `reopenFolderDialog(...)` — assert the title input and folder
tree are visible again before closing out, so the next test doesn't inherit a stuck dialog.

**5. Prompt vs Scratch.** No difference — same shared component.

**6. Effort/risk.** M-L. Entirely dependent on an external package's internal DOM, which this pass could not
inspect (per scope). Real risk: the create-folder trigger/dialog markup may need the same native-Playwright
role-based fallback `selectSaveLocation()` already uses, and any `data-test-id`s found there aren't guaranteed
stable across package upgrades.

**7. Verify on DEV.** The full internal markup/data-test-ids of `crf-uic-save-a-copy`'s "+ Create new folder" label
and `crf-uic-create-folder`'s title input / Cancel / Create buttons (this repo only shows the `[createNewFolder]`
label-text binding and the `(cancel)`/`(save)` outputs, not the rendered DOM).

---

## TC_BS_10 (second half) — Saved draft appears in My Assets

**1. Spec / flow / order.** Both flows (`registerSaveDraftTest` is already shared). Extend the existing
`registerSaveDraftTest` in `build-survey-common-test-cases.ts` with a second assertion after the toast check,
rather than adding a new test — keeps the draft-title variable in scope and avoids a second `saveDraft()` call.
Alternative: a new `registerSaveDraftAppearsInMyAssetsTest` run immediately after it in both specs, if a separate
test name per case is preferred.

**2. Reuse.** None yet — no My Assets page object exists in `e2e/page-objects`. `saveDraft(title)` already returns
once the toast model would appear; need to navigate to `/my-assets` (or wait for the toast's own redirect, if any —
unconfirmed, see step 7) and search there.

**3. New locators.** From [my-assets-page.component.html](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/my-assets/components/my-assets-page.component.html)
line 65-66:
```html
<button type="button" class="cell-title" [niqTooltip]="row.title" data-test-id="survey-grid-title">
```
This is a **stable**, own-app data-test-id — use `[data-test-id='survey-grid-title']:has-text('${title}')` as a new
locator. Note the existing `savedAssetGridcellByTitle` locator in `survey-builder.locator.json`
(`role=gridcell[name="${text}"]`) is **defined but never used anywhere** in the page object — it predates this grid
markup and its accessible-name assumption is unverified against the actual ag-grid cell renderer; prefer the new
`survey-grid-title` locator instead of fixing/reusing the old one. Also useful: `my-assets-empty-state` /
`survey-assets-grid` (data-test-ids already in the template) to assert the grid loaded before searching.

**4. State.** Needs: a draft just saved with a known title (`SaveDraft_${Date.now()}` from the existing test).
Leaves: navigates away from Build Survey to My Assets — if this is a new assertion appended to
`registerSaveDraftTest`, every later test in the same `describe.serial` block (stepper tests, validate-survey, etc.)
would break unless the test navigates back to Build Survey afterward. This is the main ordering risk — see step 7.

**5. Prompt vs Scratch.** No difference — same `saveDraft` flow and the same My Assets grid for both.

**6. Effort/risk.** M. Requires: (a) a basic My Assets page object (new file, acceptable per "no terminal / don't
touch libs" since this is e2e-only), (b) deciding how to get back to Build Survey without losing the rest of the
serial run's question state, (c) confirming the grid search doesn't need pagination handling for a freshly-saved
item (likely sorted to the top, unconfirmed).

**7. Verify on DEV.** Whether saving a draft redirects to `/my-assets` automatically (the existing
`verifyPublishSucceeded` does poll for a `/my-assets` redirect after **publish**, but `saveDraft()` has no such
redirect-wait, so draft-save may stay on Build Survey); if so, whether returning to Build Survey via browser back
preserves the in-memory question list the rest of the serial suite depends on.

---

## TC_BS_19 — Continuous typing in the first Rating/NPS question and a newly added one

**1. Spec / flow / order.** Both flows. Best placed right after `registerAddRatingQuestionTest`/`registerAddNPSQuestionTest`
(wherever those already run — Scratch has them directly, Prompt relies on AI-generated questions which may or may
not include Rating/NPS types, see step 5) as a new `registerContinuousTypingTest` in the common file, or
Scratch-only if the Prompt flow's question-type mix can't be guaranteed.

**2. Reuse.** `getQuestionTextDisplay(index)` to verify the final text after typing; `addRatingQuestion`/`addNPSQuestion`
to add the second (new) question. `enterQuestionText`/`openQuestionForEditing` for editing the first question's
existing text via the pencil icon (same pattern as `registerEditQuestionTextTest`/`registerDiscardSaveChangesTest`).

**3. New locators.** None needed structurally — the gap is **behavioral**, not locator-shaped: current helpers call
`enterText()` (effectively a single `fill()`), never character-by-character typing, so no existing method exercises
"continuous typing" at all. A new page-object method is needed that performs sequential keystrokes (e.g. Playwright's
`pressSequentially`) rather than a single `fill()`/`enterText()` call, targeting the **same** `ratingQuestionTextInput`
/ `questionTextInput` locators already in `survey-builder.locator.json` — no new selector required, but see risk
below.

**4. State.** Needs: at least one existing Rating or NPS question (reuse `ensureAtLeastOneQuestion`-style guard, or
require this run after `registerAddRatingQuestionTest`). Leaves: one newly added Rating/NPS question with
typed text, increasing the question count by one (same as any other add-question test) — must respect the 10-question
cap like `registerDeleteLastThenReAddTest` does.

**5. Prompt vs Scratch.** Scratch deterministically has Rating/NPS questions from `registerAddRatingQuestionTest`/
`registerAddNPSQuestionTest`. Prompt's first 10 questions come from AI generation
(`TC_AI_11`'s describe-step) and their types aren't constrained to include Rating/NPS — `allTypes` in TC_AI_04
suggests all 6 types can be selected, but nothing guarantees the *first* generated question is Rating/NPS. The test
must locate a Rating/NPS question by type, not assume index 0 is one, in the Prompt flow.

**6. Effort/risk. HIGH RISK.** `ratingQuestionTextInput`'s selector (`[data-test-id='-input']:visible`) is flagged
**category D — broken/ambiguous** in
[LOCATOR_TESTID_INVESTIGATION.md](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/e2e/investigation/LOCATOR_TESTID_INVESTIGATION.md)
(empty `${questionNumber()}` prefix) and is explicitly unscoped by question index ("interim :visible-based
mitigation" — see `survey-builder.page.ts` comment at `addRatingQuestion`). TC_BS_19 by definition needs **two**
Rating questions open/editable at once (first + newly added) — exactly the scenario this locator cannot
disambiguate today. Recommend fixing the Rating editor's question-text input to use the same
`question-text-input-${questionNumber()}` convention Single/Multiple Choice and NPS already use (dev work in
`libs/survey-mod-lib`, out of scope for this e2e-only task) before or alongside writing TC_BS_19; otherwise this test
will be flaky/order-dependent by construction. Effort L given the locator fix dependency; S-M once that fix lands.

**7. Verify on DEV.** Whether rapid/continuous typing actually reproduces a historical bug (dropped keystrokes,
input reset) — no such issue is referenced in `FLAKINESS.md`/other investigation docs, so the expected failure mode
this case is meant to catch is unclear from code alone.

---

## TC_BS_21 — Same "Last refreshed" date in the footer after reloading Build Survey

**1. Spec / flow / order.** Both flows. Best slot: right after reaching Build Survey and before any question
mutations (so a reload doesn't need to re-verify question state), e.g. immediately after the `'Survey Builder: ...'`
/ `'Generate Survey: ...'` setup test in each spec, or standalone after `registerStepperNavigationTest` (which
already proves the footer/stepper round-trips without losing state).

**2. Reuse.** `crf-survey-wrapper.component.html` hosts the stepper + `<router-outlet>` + `<survey-dataset-footer>`
**once**, wrapping both the Select Panelists and Build Survey routed views — so the footer is the same DOM/locators on
both pages. `SelectPanelistPage.isFooterRefreshedVisible()` and `getFooterRefreshedText()` are fully reusable as-is
on the Build Survey page (same `[data-test-id='rb-report-refreshed-on-block']` locator, already in
`select-panelist.locator.json`); `registerStepperNavigationTest` already instantiates `new SelectPanelistPage(...)`
while on Build Survey, confirming this cross-page reuse pattern is already in use.

**3. New locators.** None — `footerRefreshedOn` already exists and targets the stable `rb-report-refreshed-on-block`
data-test-id. What's missing is a **reload action**, not a locator: no `reload()` helper exists anywhere in
`e2e/page-objects`. Add one using the same native-Playwright escape hatch already used in `survey-builder.page.ts`
(`(BasePage as any).page as import('playwright').Page`) to call `page.reload()`.

**4. State.** Needs: Build Survey loaded with the footer visible (dataset already selected/searched). Leaves: a
full page reload — after `page.reload()`, in-memory question list/editor state is gone, so this must either be the
**last** test in the serial block, or be followed by a check that returns the suite to a known state (reload is
destructive to any component-level signals). Safest slot is near the very end of the serial flow (e.g. after
`registerValidateDisabledUnderThreeTest`/before the final `TC_BS_12` Back-button test in `start-from-scratch.spec.ts`,
since Back-button navigation doesn't depend on question count either).

**5. Prompt vs Scratch.** No difference — same wrapper/footer component for both.

**6. Effort/risk.** S. Low risk mechanically (reusing a well-covered locator); main risk is placement — a careless
reload mid-serial-suite will invalidate every subsequent question-count assumption in the same file.

**7. Verify on DEV.** Whether "Last refreshed" is cached client-side (survives reload unchanged) or re-derived from
a fresh API call on reload (could legitimately change if the underlying data refreshed between page loads) —
`surveyCommonService.getRefreshedDate()`'s source/caching isn't in the templates checked this pass.

---

## TC_SP_05 — All 5 panelist filters show correctly in the summary sentence

**Not in `select-panelist.spec.ts` today** (only TC_SP_03/04/07/08/10/11 exist).

**1. Spec / flow / order.** `select-panelist.spec.ts`'s `'Select Panelists - filters and search'` serial block,
right after the existing `'Setup: ... reach Select Panelists'` test and before `TC_SP_04` (footer), since both read
state right after all 5 filters are set.

**2. Reuse.** `setDimensionSelections(datasetConfig.dimensionSelections)` (already called in the Setup test) sets all
5 filters. `getCurrentFilledTileDimensionValue`/`isDimensionSelectionRetained`-style per-dimension reads exist, but
those check the **collapsed filter tiles**, not the sentence.

**3. New locators.** The "summary sentence" is the `<crf-data-summary id="data-summary" ...>` inside
`panelist-dataselector.component.html` (same component instance reused with `id="publish-data-summary"` in the
Publish popup). `#data-summary` is a **stable** host id already in this app's own template — reusable to scope a
read. Its **internal** text-node structure (how it renders "by ALL X, ALL Y, …") is rendered by the external
`@nielsen/crf-data-summary` package and was **not inspected this pass** (per scope); reading the full sentence text
via `#data-summary` and asserting `.includes()` for each of the 5 selected item labels is doable without new
internal selectors, but is **fragile** until the exact rendered phrasing is confirmed (see step 7 and the
`FLAKINESS.md` note referencing this exact sentence: `"by ALL Babies Age 0 to 3, ALL Cat Owner, ALL Census …"`).

**4. State.** Needs: all 5 filters set (already true right after Setup). Leaves: no mutation — read-only test.

**5. Prompt vs Scratch.** `panelist-dataselector.component.html` and its `#data-summary` host are identical in both
flows; no difference expected.

**6. Effort/risk.** M. Mechanically simple scoping, but asserting on rendered sentence content depends on an
external package's text formatting, which could change with a package upgrade — moderate external-dependency risk.

**7. Verify on DEV.** Exact rendered sentence format/wording for all 5 dimensions together (this repo only supplies
`selections`/`dataPrompts` as inputs to the external renderer).

## TC_SP_06 — Validation message when a filter has 0, 1, or 2 items

**Not in `select-panelist.spec.ts` today.**

**1. Spec / flow / order.** Same serial block, likely right before `TC_SP_07` (Search for Panelists enablement),
since both manipulate individual filter item counts.

**2. Reuse.** `removeDimensionSelectionItem(dimensionPromptResource)` already removes an item from a given filter
(used by `TC_SP_07` to go from 1→0 Product items); `setDimensionSelection(...)` can add back 1 or 2 items.

**3. New locators.** No validation-message locator exists anywhere in `select-panelist.locator.json`. The
filter-count validation itself is driven by `<crf-data-selector-panel-v2>` (external
`@nielsen/crf-data-selector-panel-v2`, see `panelist-dataselector.component.ts` `promptErrorService.errorConfigSubjectV2`
INVALID/VALID stream) — **not inspected this pass**. No message text or error-element markup was found in this
repo's own templates; whatever renders "Please remove 198" (per `FLAKINESS.md`'s screenshot note, for an
over-selected case, not under-selected) lives inside that external panel. Mark as **fragile / unknown**, not just
"needs a new locator" — the message may not even be inspectable without opening the panel in DEV.

**4. State.** Needs: the panelist-filter panel open per dimension (same as any `setDimensionSelection` call).
Leaves: filter item counts changed — should restore to the dataset's standard 1-item-per-filter selections before
`TC_SP_07`/`TC_SP_08` run, since those assume exactly 1 item per filter.

**5. Prompt vs Scratch.** Same external panel in both flows; no difference expected.

**6. Effort/risk.** L. Entirely dependent on an external package's internal validation messaging, which this pass
could not locate in-repo at all (not just "fragile selector" — the message's existence/wording is unconfirmed).

**7. Verify on DEV.** Whether a 0/1/2-item validation message exists at all (vs. only the "0 items → Search
disabled" / "198 over max" behaviors already partially covered by `TC_SP_07`/`FLAKINESS.md`), and its exact text/selector
if so.

## TC_SP_09 — Fewer than 100 eligible participants shows the message and Proceed disabled

**Not in `select-panelist.spec.ts` today.**

**1. Spec / flow / order.** Same serial block, after `TC_SP_08` (search result) — needs a *different*, narrower
panelist-filter combination than the shared `datasetConfig.dimensionSelections` (which is chosen specifically to
yield a high eligible count for `TC_SP_08`/`TC_SP_11`'s response-count-option checks), so this is best as a
**standalone, non-serial** test (its own `basePage`), similar to the existing standalone `TC_SP_03` describe block,
to avoid disturbing the shared dataset's filter state used by every other `TC_SP_*` test.

**2. Reuse.** `getEligibleCount()` (parses `.eligibility` text for a count) and `isProceedToSurveyBuilderDisabledOrAbsent()`
are both directly reusable. `setDimensionSelections`/`clickSearchForPanelists` for setup.

**3. New locators.** `eligibilityMessage` (`.eligibility`, already in `select-panelist.locator.json`) is reusable
to read the **failed-path** text too — confirmed in
[select-panelist.component.html](/c:/Users/yogesh.upadhyay/projects/disc-fe-omni-survey-mod/libs/survey-mod-lib/src/lib/features/select-panelist/components/select-panelist.component.html)
line 16-22: when `isUnhappyPath` the same `.eligibility` div shows `'SURVEYMOD_CRITERIA.FAILED' | translate` instead
of the congratulations text, and the entire `responses-frame` (response-count options) is omitted from the DOM in
that branch — meaning Proceed is disabled simply because `!selectedResponses` is always true (native path, not a
separate disabled check). No new locator needed; `.eligibility`'s current selector is **stable enough** (class-only,
but owned by this app's own template, not an external package) though lacks a `data-test-id` — recommend requesting
one for robustness.

**4. State.** Needs: a dimension-selection combination known to yield ≤100 eligible (not in `dev-test-data.json`
today — the existing `datasetConfig.dimensionSelections` is deliberately broad/high-eligibility). Leaves: no
mutation beyond the search itself; being a standalone block (own `basePage`), it doesn't affect other `TC_SP_*`
tests.

**5. Prompt vs Scratch.** `minEligibleCount = 100` / `isUnhappyPath` logic in `select-panelist.component.ts` is
flow-agnostic; no difference expected, though the Prompt flow additionally hides the prompt-textarea block in this
branch too (`!isUnhappyPath && ...` gates it) — minor additional assertion opportunity for Prompt specifically.

**6. Effort/risk.** M. Needs new, narrower test data (a filter combination that reliably yields <100 eligible) —
this is a data-authoring risk more than a code risk, and depends on the DEV dataset's actual population numbers
being stable enough not to flip above/below 100 over time.

**7. Verify on DEV.** A concrete, stable filter combination that yields <100 eligible for this dataset (cannot be
derived from code — depends on live data volumes).

---

## New case — Empty survey title rejected

**1. Spec / flow / order.** Both flows, right after `registerEditSurveyTitleTest` (same component, same slot makes
sense since both exercise the title-edit flow).

**2. Reuse.** `setSurveyTitle`, `commitSurveyTitle`, `getSurveyTitleDisplay` all reusable as-is to attempt setting an
empty title and read back the result.

**3. New locators.** None needed — same `editSurveyNameIcon`/`surveyTitleInput`/`.survey-title` locators.

**4. State.** Needs: a survey with a title already set (so there's something to compare "did it actually change"
against). Leaves: whatever the actual (not assumed) behavior produces — see step 7, since this directly affects
what later tests should expect `getSurveyTitleDisplay()` to return.

**5. Prompt vs Scratch.** No difference — `survey-header.component.ts` is shared.

**6. Effort/risk.** S to write, but **the expected result is not determinable from code** — see step 7. This is the
highest-uncertainty item in this plan.

**7. Verify on DEV — important.** Inspected `survey-header.component.ts`/`survey.service.ts`:
`disableEdit()` → `surveyCommonService.updateTitle(this.surveyTitle)` → `this._title.set(newTitle)` with **no
`trim()`/empty check/fallback to "Untitled Survey"** at that layer. A `hasValidTitle(title)` guard
(`title?.trim()`) exists in `survey-header.component.ts` but is only invoked for the **direct-save duplicate/existing-asset**
path (`openSaveDraftDialog`'s `isDraftAction()` branch per its spec test "rejects an empty title when directly
saving a duplicate or existing asset"), not for the inline title-edit-on-blur flow the e2e tests exercise. **This
suggests the inline edit may currently accept an empty title** (contrary to the case name "rejected") — must be
confirmed on DEV before writing the assertion, since the test's pass/fail direction depends entirely on this.

## New case — Empty question text blocks Save changes

**1. Spec / flow / order.** Both flows, right after `registerDiscardSaveChangesTest` (same component/pattern:
open for editing, type, then act on Save/Discard).

**2. Reuse.** `openQuestionForEditing(index)`, `enterQuestionText(index, '')`, `saveQuestionChanges(index)`,
`isEditorOpen()`, `getQuestionTextDisplay(index)` — all directly reusable, same pattern as
`registerDiscardSaveChangesTest`.

**3. New locators.** None needed.

**4. State.** Needs: an existing question to edit (index 0, same precondition as `registerDiscardSaveChangesTest`).
Leaves: must end with the original text restored (e.g. by discarding or re-saving valid text) so later index-0-text
assertions in the same serial run aren't broken.

**5. Prompt vs Scratch.** No difference — `commitQuestionDraft`/`isQuestionValid` in
`preview-mode.component.ts`/`survey-question.util.ts` are shared by both flows.

**6. Effort/risk.** S. Confirmed in code: `isQuestionTextValid(text) = !!text?.trim()`, and
`commitQuestionDraft()` (`preview-mode.component.ts`) returns `false` — leaving the editor open / not persisting —
when `!isQuestionValid(next)`. The "Save changes" button itself has **no `[disabled]`/`[state]` binding** in
`question-editor.component.html` (always clickable); the block happens at commit time, not via a disabled button.
So the correct assertion is: after clicking Save with empty text, `isEditorOpen()` stays `true` and
`getQuestionTextDisplay(index)` is unchanged — not that the Save button becomes disabled.

**7. Verify on DEV.** Whether any inline error message is shown when Save is clicked with empty text (no such
element was found in `question-editor.component.html`/`preview-mode.component.html` — the block appears to be
silent).

## New case — Generate Survey disabled with empty prompt

**1. Spec / flow / order.** Prompt only. Natural slot: fold into the same new `TC_AI_01` test above (both check the
Generate Survey button in its initial, pre-prompt state) rather than a separate test — avoids re-deriving the same
preconditions twice.

**2. Reuse.** `generateSurveyButton` locator (`[data-test-id='proceed-to-survey']`) already exists; a native
`disabled` check (`await button.isDisabled()` / `getAttribute('disabled')`) is reusable — no page-object method
currently reads this button's disabled state, but the pattern matches `isSearchForPanelistsEnabled` elsewhere.

**3. New locators.** None.

**4. State.** Needs: response count selected, prompt field empty (the state right before `fillPromptAndGenerate` is
called). Leaves: nothing, if folded into TC_AI_01 and the prompt is left empty for that assertion before the real
`fillPromptAndGenerate` test fills it.

**5. Prompt vs Scratch.** Scratch has no prompt field/Generate Survey button at all (confirmed in
`select-panelist.component.html`: the whole `[disabled]="!selectedResponses || (aiflow && (!userPrompt.trim() || isPromptSettling())) ..."`
button and prompt block are behind `aiflow`).

**6. Effort/risk.** S. Confirmed directly in code: `[disabled]="!selectedResponses || (surveyCommonService.flowType().aiflow && (!userPrompt.trim() || isPromptSettling())) || ..."`
on the `proceed-to-survey` button is a **native** disabled attribute (not a niq-button `state`), so a plain
`isDisabled()` check works without replicating the multi-source disabled-state checks used elsewhere
(`getAddQuestionDisabledState` etc.).

**7. Verify on DEV.** None — fully confirmed from the template's own disabled-binding expression.

## New case — Duplicate option text handled

**1. Spec / flow / order.** Both flows, as an extension of `registerOptionBoundaryTest` (same question/editor
state) or a new sibling test immediately after it.

**2. Reuse.** `addSingleChoiceQuestion`/`openQuestionForEditing`, `fillLabeledField`-equivalent option entry (via
`addOptionToQuestion` + filling "Option N"), `getOptionCount()`, `saveQuestionChanges()`/`clickAddQuestion()` to
attempt saving, `getQuestionTextDisplay` or a new options-read helper to confirm the saved state.

**3. New locators.** None needed for the write path (reuses `optionInputByLabel`/`addOptionButton`). If asserting
the *saved* option values afterward, `optionRow` (already in `survey-builder.locator.json`) can be read for text via
`getWebElementsText`, but there's no existing method that returns option **values** (only `getOptionCount()`/
`getRemoveOptionIconCount()` which count rows/icons) — a small new read helper would be needed, no new locator.

**4. State.** Needs: a Single/Multiple Choice question editor open with ≥2 options. Leaves: either an unsaved draft
discarded, or a saved question with duplicate option text — should discard rather than save to avoid introducing a
duplicate-text question into later tests' question-count/text assumptions.

**5. Prompt vs Scratch.** No difference — `isChoiceOptionsValid` (`survey-question.util.ts`) is shared and does
**not** check for duplicates (`opts.length >= 2 && opts.every(opt => !!opt?.trim())` only — no uniqueness check).

**6. Effort/risk.** S to write, but **behaviorally this is confirmed to NOT be blocked** — `isChoiceOptionsValid`
has no duplicate-detection logic anywhere in `survey-question.util.ts`, and no duplicate-option error message was
found in `choice-editor` templates search. This is a real gap worth flagging: the case name says "duplicate option
text handled", but the code shows it is currently **not handled at all** (two options can have identical text and
still save successfully). The test should assert the actual (permissive) behavior unless product intends to add
validation — flag this to the team rather than assume which behavior is "correct" (see step 7).

**7. Verify on DEV.** Confirm there is no duplicate-option validation anywhere in the UI (code search found none) —
if the product actually wants duplicates blocked, this is a feature gap, not just a missing test.

---

## Summary table

| Case | Spec file(s) | Flow | Status | Effort | Key risk |
|---|---|---|---|---|---|
| TC_BS_20 | both specs | both | **Done** | – | – |
| TC_BS_22 | both specs | both | **Done** | – | – |
| TC_AI_05 (non-empty) | start-with-prompt.spec.ts | Prompt | **Done** | – | – |
| TC_AI_01 | start-with-prompt.spec.ts | Prompt | To write | S | Heading text locator fragile (i18n, no test-id) |
| TC_AI_03 | start-with-prompt.spec.ts | Prompt | To write | M | External `niq-slider` interaction; number-field existence unconfirmed |
| TC_BS_17 | start-from-scratch.spec.ts (+ prompt spec) | both | To write | S-M | Cancel button is in external `crf-uic-save-a-copy` |
| TC_AI_14 / TC_BS_24 | common-test-cases + both specs | both | To write | M-L | Entire create-folder dialog is external, no test-ids found in-repo |
| TC_BS_10 (2nd half) | common-test-cases + both specs | both | To write | M | No My Assets page object yet; navigation-back risk to serial suite |
| TC_BS_19 | common-test-cases (or Scratch-only) + both specs | both (Scratch safer) | To write | **L** (S-M after locator fix) | `ratingQuestionTextInput` is category-D broken/ambiguous; needs 2 Rating inputs disambiguated |
| TC_BS_21 | both specs | both | To write | S | Must be placed last in a serial block (reload resets in-memory state) |
| TC_SP_05 | select-panelist.spec.ts | both (shared) | To write | M | Sentence text rendered by external `crf-data-summary` |
| TC_SP_06 | select-panelist.spec.ts | both (shared) | To write | **L** | Validation message existence/location unconfirmed (external panel) |
| TC_SP_09 | select-panelist.spec.ts | both (shared) | To write | M | Needs new <100-eligible test data, standalone (non-serial) block |
| New: empty survey title | both specs | both | To write | S (but see risk) | **Expected behavior unconfirmed — code suggests empty may be accepted, not rejected** |
| New: empty question text blocks Save | both specs | both | To write | S | Fully confirmed in code — assert editor stays open, not a disabled button |
| New: Generate Survey disabled w/ empty prompt | start-with-prompt.spec.ts (fold into TC_AI_01) | Prompt | To write | S | None — fully confirmed native `disabled` binding |
| New: duplicate option text | both specs | both | To write | S | **Confirmed NOT validated today — flag as product gap, not just a test gap** |

## Recommended order

1. **New: Generate Survey disabled with empty prompt** + **TC_AI_01** (fold together) — fully confirmed, zero
   external-package risk, fastest win.
2. **New: empty question text blocks Save changes** — fully confirmed, reuses existing pattern 1:1.
3. **New: duplicate option text** — fully confirmed (permissive) behavior; quick, but raise the product-gap flag
   first so the assertion direction is agreed before writing it.
4. **TC_SP_09** — needs new test data (<100 eligible combo) but otherwise low code risk; do this before TC_SP_05/06
   since it's standalone and won't block on external-package uncertainty.
5. **TC_BS_17** — small, but confirm the Cancel button selector on DEV first.
6. **TC_BS_21** — small, but decide its placement (end of serial block) alongside TC_BS_17/publish-related ordering.
7. **TC_AI_03** — confirm the "number field" question on DEV before writing, since it changes the interaction
   approach.
8. **New: empty survey title** — get the DEV answer on actual behavior first; the test's assert direction depends
   on it.
9. **TC_SP_05 / TC_SP_06** — both depend on inspecting the external `crf-data-summary`/`crf-data-selector-panel-v2`
   DOM on DEV; do together once that's available.
10. **TC_BS_10 (second half)** — needs a new My Assets page object; medium effort, do once the navigate-back
    question is answered.
11. **TC_AI_14 / TC_BS_24** — needs DEV inspection of the create-folder dialog's internal markup; highest
    external-dependency uncertainty besides TC_SP_06.
12. **TC_BS_19 last** — recommend requesting the Rating question-text-input locator fix
    (`question-text-input-${questionNumber()}`, matching Choice/NPS) in `libs/survey-mod-lib` before writing this
    test, otherwise it is flaky by construction when two Rating questions are open.

## Questions for you

1. **TC_BS_19 locator fix**: should I treat the Rating question-text-input fix
   (`libs/survey-mod-lib/.../rating-editor/rating-editor.component.html`) as a prerequisite dev ticket, or write the
   test against the current ambiguous `:visible`-based locator and accept the flakiness risk?
2. **Empty survey title**: do you want me to verify actual DEV behavior before writing this test, or write it to
   assert "rejected" as specified and let it fail if the code's apparent permissive behavior is confirmed?
3. **Duplicate option text**: should this be filed as a product bug/gap (no validation exists), or is permissive
   (duplicates allowed) actually the intended behavior, in which case the test simply documents that?
4. **TC_BS_10 second half**: is navigating to My Assets and back acceptable mid-serial-suite, or would you prefer a
   fully standalone (non-serial) test with its own `basePage`, even though that means saving a second draft just to
   check My Assets?
5. **TC_AI_14 / TC_BS_24 and TC_BS_17**: can you (or should I, via a follow-up DEV session) get the actual
   data-test-ids on `crf-uic-save-a-copy`'s Cancel/Create-new-folder controls and `crf-uic-create-folder`'s
   fields, so these aren't written against guessed/text-based selectors?
6. **TC_SP_09 test data**: do you have (or can you supply) a filter combination on the DEV dataset that reliably
   yields <100 eligible participants, or should I propose one by trial on DEV?
7. **TC_BS_21 placement**: are you fine with this running last in each serial `describe.serial` block (after it,
   the suite's in-memory question state is gone), or would you prefer it isolated in its own non-serial test file?
