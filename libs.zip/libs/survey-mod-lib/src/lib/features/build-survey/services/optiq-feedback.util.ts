import { AiSuggestion } from '../models/build-survey';

export interface SpellingHighlight {
  text: string;
  state: 'unchanged' | 'removed' | 'added';
}

// Adds text as removed, added or unchanged; removed text is split into words and spaces so spaces are not struck through.
function addHighlight(
  highlights: SpellingHighlight[],
  text: string,
  state: SpellingHighlight['state']
): void {
  if (state === 'removed') {
    for (const wordOrSpacing of text.match(/\s+|\S+/g) ?? []) {
      highlights.push({
        text: wordOrSpacing,
        state: wordOrSpacing.trim() ? 'removed' : 'unchanged',
      });
    }
  } else if (text) {
    highlights.push({ text, state });
  }
}

// Splits the original text into unchanged, removed and added pieces so the edit can be shown inline.
export function buildSpellingHighlights(
  originalText: string,
  suggestion: AiSuggestion
): SpellingHighlight[] | null {
  if (!suggestion.changes?.length || suggestion.changes.length > 3) {
    return null;
  }

  const highlights: SpellingHighlight[] = [];
  let unchangedTextStart = 0;
  // All offsets refer to the original text, not the text after earlier replacements.
  for (const change of suggestion.changes) {
    const { start, end, oldText, newText } = change;

    if (
      !Number.isInteger(start) || !Number.isInteger(end) ||
      start < unchangedTextStart || end < start || end > originalText.length ||
      originalText.slice(start, end) !== oldText
    ) {
      return null;
    }

    addHighlight(highlights, originalText.slice(unchangedTextStart, start), 'unchanged');
    if (oldText === newText) {
      addHighlight(highlights, oldText, 'unchanged');
    } else {
      addHighlight(highlights, oldText, 'removed');
      addHighlight(highlights, newText, 'added');
    }
    unchangedTextStart = end;
  }
  addHighlight(highlights, originalText.slice(unchangedTextStart), 'unchanged');
  return highlights;
}
