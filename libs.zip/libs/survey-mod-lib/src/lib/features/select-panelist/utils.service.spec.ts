import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { SelectPanelistUtilsService } from './utils.service';

describe('SelectPanelistUtilsService', () => {
  let service: SelectPanelistUtilsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SelectPanelistUtilsService);
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  describe('checkFactInDataset', () => {
    const response = { grid: [[{ id: 'id-1', value: 'Label 1' }], [{ id: 'id-2', value: 'Label 2' }]] };

    it('returns true when a payload value matches a grid id or value', () => {
      expect(service.checkFactInDataset({ filter: { values: ['id-2'] } }, response)).toBe(true);
      expect(service.checkFactInDataset({ filter: { values: ['Label 1'] } }, response)).toBe(true);
    });

    it('returns false when no payload value matches', () => {
      expect(service.checkFactInDataset({ filter: { values: ['missing'] } }, response)).toBe(false);
    });

    it('returns false when payload or response is missing', () => {
      expect(service.checkFactInDataset(undefined, response)).toBe(false);
      expect(service.checkFactInDataset({ filter: { values: ['id-1'] } }, undefined)).toBe(false);
      expect(service.checkFactInDataset({}, { grid: [] })).toBe(false);
    });
  });

  describe('refreshedOnDate', () => {
    beforeEach(() => {
      vi.useFakeTimers();
      vi.setSystemTime(new Date(2026, 0, 15, 12, 0, 0));
    });

    it('returns "today" for a timestamp from the current day', () => {
      expect(service.refreshedOnDate(new Date(2026, 0, 15, 1, 30).getTime())).toBe('today');
    });

    it('returns a medium-formatted date for other days', () => {
      expect(service.refreshedOnDate(new Date(2026, 0, 1, 12, 0).getTime())).toBe('Jan 1, 2026');
    });

    it('coerces numeric strings to timestamps', () => {
      expect(service.refreshedOnDate(String(new Date(2026, 0, 15, 2, 0).getTime()))).toBe('today');
    });
  });

  describe('getNextDelay', () => {
    it('returns a value between the base delay and twice the base delay', () => {
      const delay = service.getNextDelay(1000);
      expect(delay).toBeGreaterThanOrEqual(1000);
      expect(delay).toBeLessThan(2000);
    });

    it('uses 1200ms as the default base delay', () => {
      vi.spyOn(window.crypto, 'getRandomValues').mockImplementation((arr: any) => {
        arr[0] = 0;
        return arr;
      });
      expect(service.getNextDelay()).toBe(1200);
    });

    it('scales the jitter with the random value', () => {
      vi.spyOn(window.crypto, 'getRandomValues').mockImplementation((arr: any) => {
        arr[0] = 0x80000000;
        return arr;
      });
      expect(service.getNextDelay(1000)).toBe(1500);
    });
  });
});
