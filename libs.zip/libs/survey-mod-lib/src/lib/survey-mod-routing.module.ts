import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SURVEY_MOD_ROUTES } from './survey-mod.routes';

@NgModule({
  imports: [RouterModule.forChild(SURVEY_MOD_ROUTES)],
  exports: [RouterModule]
})
export class SurveyModRoutingModule {}
