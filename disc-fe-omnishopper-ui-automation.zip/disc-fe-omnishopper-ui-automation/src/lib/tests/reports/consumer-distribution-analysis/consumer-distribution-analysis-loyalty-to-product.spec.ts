import test from "@playwright/test";
import { findDataSetByName, getDimensionSelectionsByPivot, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";

const pivot: string = "Loyalty to Product";

  test.describe("Consumer Distribution Analysis - Loyalty to Product Pivot", async () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;

    test.beforeAll(() => {
        const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
        if (!isValidTestData) {
          console.warn('Skipping tests as the required pivot test data is not present');
        }
        test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
      });
    
    test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
    test(
          "Validate run report",
          {
            tag: "@RunReport",
          },
          async () => {
             test.setTimeout(RUN_TEST_TIMEOUT);
            // Initialize base page with authentication from storage/auth.json (created in global setup)
            let basePage = await BasePageFactory.createBasePage();
            dataSelector = new DataSelector(basePage);
            
            // Navigate to the specific report URL
            await dataSelector.navigateToUrl(reportUrl);
            
            // Click additional prompt ellipsis first to reveal pivot dropdown
            await dataSelector.clickAdditionalPromptEllipsisIcon();
            
            // Switch to "Loyalty to Product" pivot
            await dataSelector.switchPivotDropdown(pivot);
    
            // Get Loyalty to Product pivot data
            const loyaltyToProductData = getDimensionSelectionsByPivot(pivot, reportTestData);
            await dataSelector.waitForMadlibStability();

             await dataSelector.clickMadlibDimension("Product Universe");
            await dataSelector.setMadlibSelection(
             loyaltyToProductData["Product Universe"]
            );   
            
               await dataSelector.clickMadlibDimension("Products");
              await dataSelector.setMadlibSelection(
               loyaltyToProductData["Products"]
              );
              await dataSelector.waitForMadlibStability();
             await dataSelector.clickMadlibDimension("Retailers");
            await dataSelector.setMadlibSelection(
            loyaltyToProductData["Retailers"]
            );

            // Configure Range dimension
            await dataSelector.clickMadlibDimension("Range");
            const rangeConfig = loyaltyToProductData["Range"];
            await dataSelector.clickMadlibDimension("defineNewRangeButton");
            
            await dataSelector.configureRange(
              rangeConfig.volumetricType,     // Volumetric type from dropdown (e.g., "Avg. Price (EQ2)")
              rangeConfig.minValue,           // Min value
              rangeConfig.maxValue,           // Max value
              rangeConfig.incrementValue      // Increment value
            );   
            
            // Wait for madlib to stabilize after Range configuration
            await dataSelector.waitForMadlibStability();

            // await dataSelector.clickMadlibDimension("People");
            // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
            // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
            // await dataSelector.setDimensionSelection(loyaltyToProductData["People"]
            //   .selections)

          
            await dataSelector.clickMadlibDimension("Period");
            await dataSelector.setPeriodMadlibSelection(
              loyaltyToProductData["Period"]
            );
            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.selectClosedDropdown(
              loyaltyToProductData["Facts"]["selections"]
            );
            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(
              loyaltyToProductData["Geography"]
            );
    
            await dataSelector.clickMadlibDimension("Demography");
            await dataSelector.setMadlibSelection(
              loyaltyToProductData["Demography"]
            );
           
                    
             await dataSelector.waitForMadlibStability();
            
             let dsBasePage = await dataSelector.getBasePage();
             commonTestCase = new CommonTestCase(dsBasePage);
             await commonTestCase.clickRunButton();
             await commonTestCase.waitForReportRunCompletion();
             console.log("run complete in spec");
             const { newReportTitle, newUrl } = await commonTestCase.saveReport();
             savedReportTitle = newReportTitle;
             savedReportUrl = newUrl;
             console.log("savedReportTitle:", savedReportTitle);
             console.log("savedReportUrl:", savedReportUrl);
          }
        );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
        test(
                "Validate FullScreen",
                {
                  tag: "@ValidateFullScreen",
                },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  await commonTestCase.fullScreenView();
                }
              );
        
              test(
                "Validate presentationMode",
                {
                  tag: "@PresentationMode",
                },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  await commonTestCase.presentationMode();
                }
              );
        
              test(
                "Validate snapshot",
                { tag: "@Snapshot" },
                async () => {
                  let basePage = await BasePageFactory.createBasePage();
                  const commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
                  await snapshot.waitForReportRunCompletion();
                  await snapshot.clickSaveIcon();
                  await snapshot.clickSnapshotIcon();
                  console.log("Snapshot clicked");
                  assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
                  let snapshotUrl: string = await snapshot.shiftingToSnapshot();
                }
              );
              
        
              test(
                "Validate Excel export",
                {
                  tag: "@ValidateExcelExport",
                },
                async () => {
                  let exportComponent: ExportComponent;
                  let basePage = await BasePageFactory.createBasePage();
                  commonTestCase = new CommonTestCase(basePage);
                  await commonTestCase.navigateToReportUrl(savedReportUrl);
                  let commonBasePage = await commonTestCase.getBasePage();
                  exportComponent = new ExportComponent(commonBasePage);
                  await exportComponent.validateExportFunctionality(
                    "Excel",
                    "Editable objects",
                    "Separately"
                  );
                }
              );
                    

  });
});