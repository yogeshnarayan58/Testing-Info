import { TestBed } from '@angular/core/testing';
import { DOCUMENT } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { DataSummaryService } from './data-summary.service';

describe('DataSummaryService', () => {
  let service: DataSummaryService;
  const translationServiceStub = { instant: vi.fn((key: string) => key) };
  const documentStub: { defaultView: { location: { href: string } } | null } = {
    defaultView: { location: { href: 'https://example.test/survey/results/svy-1?token=secret#section' } },
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: DOCUMENT, useValue: documentStub },
        { provide: TranslateService, useValue: translationServiceStub },
      ],
    });
    translationServiceStub.instant.mockImplementation((key: string) => ({
      'COPY_RIGHT.TITLE': 'Copyright \u00a9',
      'COPY_RIGHT.COMPANY_NAME': 'Nielsen Consumer LLC',
      'COPY_RIGHT.ALL_RIGHTS_RESERVED': 'All Rights Reserved',
    }[key] ?? key));
    documentStub.defaultView = { location: { href: 'https://example.test/survey/results/svy-1?token=secret#section' } };
    service = TestBed.inject(DataSummaryService);
    vi.spyOn(console, 'log').mockImplementation(() => undefined);
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  it('has no summary before a report response arrives', () => {
    expect(service.getDataSummary()).toBeNull();
    expect(service.dataSummary()).toBeNull();
  });

  function survey(name = 'Adult Incontinence Survey') {
    return {
      name,
      reportDetail: {
        requestInstance: {
          datasetLabel: 'Omni Agg SI 3yrs Synd',
          dataViewName: 'Entire Dataset',
          productOfferingCode: 'PANEL_OD_OMNI',
          type: 'Panel On Demand Omnishopper',
          prompts: [
            { promptOrder: 2, preLabel: 'within', promptData: [{ promptSelectionLabel: 'Dollar Store' }] },
            { promptOrder: 1, preLabel: 'Buyers of', promptData: [{ promptSelectionLabel: 'ADULT INCONTINENCE' }] },
            { promptOrder: 3, preLabel: 'in', promptData: [{ promptSelectionLabel: 'Total US' }] },
            { promptOrder: 4, preLabel: 'by', promptData: [{ promptSelectionLabel: 'Total Panel' }] },
            { promptOrder: 5, preLabel: 'during', promptData: [{ promptSelectionLabel: 'Cal Yr 2024 - w/e 12/28/24' }] },
            { hidden: true, preLabel: 'Compare', promptData: [{ promptSelectionLabel: '2 Fact' }] },
            { excludeReportSpec: true, preLabel: 'Buyers of', promptData: [{ promptSelectionLabel: 'Duplicate' }] },
            { validate: false, promptData: [{ promptSelectionLabel: 'Internal' }] },
          ],
        },
      },
    };
  }

  it('generates and stores the requested format from saved survey details', () => {
    const input = survey();
    const before = JSON.stringify(input);
    const summary = service.generateDataSummary(input)!;

    expect(summary.header).toEqual({
      title: input.name,
      summary: 'Buyers of #b#ADULT INCONTINENCE#/b# within #b#Dollar Store#/b# in #b#Total US#/b# by #b#Total Panel#/b# during #b#Cal Yr 2024 - w/e 12/28/24#/b#',
      headerTextStyle: { bold: false, alignment: 'LEFT', font: { name: 'Aktiv Grotesk', color: '#000000', size: 11 }, underline: false },
      titleTextStyle: { bold: false, alignment: 'LEFT', font: { name: 'Aktiv Grotesk', color: '#000000', size: 13 }, underline: false },
    });
    expect(summary.footer.dataSourceInfo.displayText).toBe(
      'Dataset: NielsenIQ Panel On Demand Omnishopper | Omni Agg SI 3yrs Synd (Entire Dataset)',
    );
    expect(summary.footer.dataSourceInfo.dataSourceTextStyle).toEqual({ bold: false, alignment: 'CENTER', font: { name: 'Aktiv Grotesk', color: '#000000', size: 11 } });
    expect(summary.footer.copyrightsInfo.displayText).toBe(
      `Copyright \u00a9 ${new Date().getFullYear()} Nielsen Consumer LLC. All Rights Reserved.`,
    );
    expect(summary.footer.termsAndConditionsInfo.termsAndConditionsTextStyle).toEqual({ bold: false, alignment: 'CENTER', font: { name: 'Aktiv Grotesk', color: '#0000FF', size: 11 }, underline: true });
    expect(summary.footer.termsAndConditionsInfo.termsAndConditionsHyperlinkTextStyle).toEqual(summary.footer.termsAndConditionsInfo.termsAndConditionsTextStyle);
    expect(service.getDataSummary()).toBe(summary);
    expect(service.dataSummary()).toBe(summary);
    expect(console.log).not.toHaveBeenCalled();
    expect(JSON.stringify(input)).toBe(before);
  });

  it('regenerates the title and selections from fresh survey data', () => {
    const first = service.generateDataSummary(survey());
    const updated = survey('Updated survey');
    updated.reportDetail.requestInstance.prompts[0].promptData[0].promptSelectionLabel = 'Updated retailer';
    const summary = service.generateDataSummary(updated)!;

    expect(summary).not.toBe(first);
    expect(summary.header.title).toBe('Updated survey');
    expect(summary.header.summary).toContain('#b#Updated retailer#/b#');
    expect(service.getDataSummary()).toBe(summary);
  });

  it('uses asset title and omits missing selections instead of inventing values', () => {
    const summary = service.generateDataSummary({ name: 'Survey', assetInfo: { title: 'Report title' }, reportDetail: { requestInstance: {} } })!;

    expect(summary.header.title).toBe('Report title');
    expect(summary.header.summary).toBe('');
    expect(summary.footer.dataSourceInfo.displayText).toBe('Dataset: NielsenIQ');
  });

  it('appends currency to the dataset display only when the payload provides it', () => {
    const input = survey();
    input.reportDetail.requestInstance.selectedCurrency = 'USD';

    const summary = service.generateDataSummary(input)!;

    expect(summary.footer.dataSourceInfo.displayText).toBe(
      'Dataset: NielsenIQ Panel On Demand Omnishopper | Omni Agg SI 3yrs Synd (Entire Dataset) | Currency: USD',
    );
  });

  it('adds a translated go-back link for saved published surveys only', () => {
    const input = survey();
    input.assetInfo = { assetId: 'asset-1', status: 'PUBLISHED' };
    const summary = service.generateDataSummary(input)!;

    expect(summary.header.goBackToReportDisplayText).toBe('Go back to report');
    expect(summary.header.goBackToReportTextStyle).toEqual({
      bold: false,
      alignment: 'LEFT',
      font: { name: 'Aktiv Grotesk', color: '#0000FF', size: 11 },
      underline: true,
    });
    expect(summary.header.hyperlink).toBe('https://example.test/survey/results/svy-1');

    const draftSummary = service.generateDataSummary({
      ...input,
      assetInfo: { assetId: 'draft-asset', status: 'DRAFT' },
    })!;
    expect(draftSummary.header).not.toHaveProperty('goBackToReportDisplayText');
    expect(draftSummary.header).not.toHaveProperty('hyperlink');
  });

  it.each(['LIVE', 'CLOSED'] as const)('adds the go-back link for %s surveys', (status) => {
    const summary = service.generateDataSummary({
      ...survey(),
      assetInfo: { assetId: 'asset-1', status },
    })!;

    expect(summary.header.goBackToReportDisplayText).toBe('Go back to report');
    expect(summary.header.hyperlink).toBe('https://example.test/survey/results/svy-1');
  });

  it('uses the translated go-back label when a translation is available', () => {
    translationServiceStub.instant.mockReturnValue('Return to report');
    const summary = service.generateDataSummary({
      ...survey(),
      assetInfo: { assetId: 'asset-1', status: 'PUBLISHED' },
    })!;

    expect(summary.header.goBackToReportDisplayText).toBe('Return to report');
  });

  it('builds the copyright display from Report Builder translation keys', () => {
    translationServiceStub.instant.mockImplementation((key: string) => ({
      'COPY_RIGHT.TITLE': 'Derechos de autor',
      'COPY_RIGHT.COMPANY_NAME': 'Nielsen Consumer',
      'COPY_RIGHT.ALL_RIGHTS_RESERVED': 'Todos los derechos reservados',
    }[key] ?? key));

    const summary = service.generateDataSummary(survey())!;

    expect(summary.footer.copyrightsInfo.displayText).toBe(
      `Derechos de autor ${new Date().getFullYear()} Nielsen Consumer. Todos los derechos reservados.`,
    );
    expect(translationServiceStub.instant).toHaveBeenCalledWith('COPY_RIGHT.TITLE');
    expect(translationServiceStub.instant).toHaveBeenCalledWith('COPY_RIGHT.COMPANY_NAME');
    expect(translationServiceStub.instant).toHaveBeenCalledWith('COPY_RIGHT.ALL_RIGHTS_RESERVED');
  });

  it('omits all go-back metadata when there is no browser URL', () => {
    documentStub.defaultView = null;
    const summary = service.generateDataSummary({
      ...survey(),
      assetInfo: { assetId: 'asset-1', status: 'PUBLISHED' },
    })!;

    expect(summary.header).not.toHaveProperty('goBackToReportDisplayText');
    expect(summary.header).not.toHaveProperty('goBackToReportTextStyle');
    expect(summary.header).not.toHaveProperty('hyperlink');
  });

  it('handles malformed prompts and falls back to available selected labels', () => {
    const summary = service.generateDataSummary({ name: '', reportDetail: { requestInstance: {
      prompts: [null, { hidden: true }, { promptData: [null] }, {
        preLabel: 'in', promptData: [{ allSelectedValues: ['Total US', null, 'Total EU'] }],
      }],
    } } })!;

    expect(summary.header.title).toBe('Untitled Report');
    expect(summary.header.summary).toBe('in #b#Total US, Total EU#/b#');
  });

  it('clears previous data when the survey has no saved request instance', () => {
    service.generateDataSummary(survey());
    vi.mocked(console.log).mockClear();

    expect(service.generateDataSummary({ name: 'Next survey' })).toBeNull();
    expect(service.getDataSummary()).toBeNull();
    expect(console.log).not.toHaveBeenCalled();
  });

  it('generates and stores the summary without logging report data in production', () => {
    vi.stubGlobal('ngDevMode', false);
    const summary = service.generateDataSummary(survey());

    expect(summary?.header.title).toBe('Adult Incontinence Survey');
    expect(service.getDataSummary()).toBe(summary);
    expect(console.log).not.toHaveBeenCalled();
  });
});