import {
  QuestionModel,
  QuestionType,
  QuestionTypes,
} from '../models/build-survey';

/**
 * Converts a QuestionModel to the API format required by the backend.
 */
export function toApiQuestion(question: QuestionModel, index: number) {
  if (!Object.values(QuestionTypes).includes(question.type as QuestionType)) {
    throw new Error(`Unsupported question type: ${question.type}`);
  }
  const text = (question.question ?? '').trim();
  const { answerSpec, validation } = buildAnswerSpec(question);
  return {
    id: `q_${index + 1}`,
    order: `${index + 1}`,
    type: question.type,
    required: !!question.isRequired,
    prompt: { text, helpText: null },
    answerSpec,
    validation
  };
}

/**
 * Formats a string as a slug or returns fallback if validation fails.
 */
export function stringFormat(value: string, fallback: string): string {
  const slug = value.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return slug || fallback;
}

/**
 * Builds API-compatible options array from string labels.
 */
export function toApiOptions(options: string[] | undefined) {
  return (options ?? [])
    .map(option => (option ?? '').trim())
    .filter(Boolean)
    .map((label, index) => ({ value: stringFormat(label, `option_${index + 1}`), label }));
}

/**
 * Builds answerSpec and validation rules based on question type.
 */
export function buildAnswerSpec(question: QuestionModel): {
  answerSpec: Record<string, unknown>;
  validation: Record<string, unknown>;
} {
  switch (question.type) {
    case QuestionTypes.SingleChoice: {
      const options = toApiOptions(question.options);
      return { answerSpec: { options }, validation: { minSelections: question.isRequired ? 1 : 0, maxSelections: 1 } };
    }
    case QuestionTypes.MultipleChoice: {
      const options = toApiOptions(question.options);
      return { answerSpec: { options }, validation: { minSelections: question.isRequired ? 1 : 0, maxSelections: options.length } };
    }
    case QuestionTypes.NetPromoterScore:
      return {
        answerSpec: {
          min: 0,
          max: 10,
          step: 1,
          anchors: {
            min: (question.npsLeftLabel ?? '').trim() || 'Not at all likely',
            max: (question.npsRightLabel ?? '').trim() || 'Extremely likely',
          },
        },
        validation: { minValue: 0, maxValue: 10 },
      };
    case QuestionTypes.StarRating:
      return {
        answerSpec: { rows: toApiOptions(question.rowOptions) },
        validation: { minValue: 1, maxValue: 5 },
      };
    case QuestionTypes.SinglePointScale:
      return {
        answerSpec: {
          rows: toApiOptions(question.rowOptions),
          columns: toApiOptions(question.columnOptions?.length ? question.columnOptions : question.options),
        },
        validation: { minSelections: question.isRequired ? 1 : 0, maxSelections: 1 },
      };
    case QuestionTypes.MultiplePointScale:
      return {
        answerSpec: { rows: toApiOptions(question.rowOptions), columns: toApiOptions(question.columnOptions) },
        validation: { minSelections: question.isRequired ? 1 : 0 },
      };
    default:
      return { answerSpec: {}, validation: {} };
  }
}

/**
 * Sanitizes a field value based on its type (string, array, etc).
 */
export function sanitizeFieldValue(field: string, value: unknown): unknown {
  if (field === 'question' || field === 'npsLeftLabel' || field === 'npsRightLabel') {
    return String(value ?? '').trim();
  }

  if (field === 'options' || field === 'rowOptions' || field === 'columnOptions') {
    return Array.isArray(value)
      ? value.map(v => String(v ?? '').trim())
      : [];
  }

  return value;
}

/**
 * Trims and returns a string, or empty string if value is not a string.
 */
export function toTrimmedString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}
