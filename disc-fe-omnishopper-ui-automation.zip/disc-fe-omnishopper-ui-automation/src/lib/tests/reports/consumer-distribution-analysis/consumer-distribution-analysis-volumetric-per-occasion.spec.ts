import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { findDataSetByName, getDimensionSelectionsByPivot, getTestDataByLocale, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { ExportComponent } from "../../../common/components/export/export";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Volumetric per Occasion";

test.describe("Consumer Distribution Analysis - Volumetric per Occasion Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(reportUrl);
      let commonBasePage = commonTestCase.getBasePage();
      dataSelector = new DataSelector(commonBasePage);
      if (localeData.madlibText) {
        const actualMadlibText = await dataSelector.getMadlibText();
        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", localeData.madlibText);
        assert(actualMadlibText).toMatch(
          new RegExp(localeData.madlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);
          await dataSelector.clickAdditionalPromptEllipsisIcon();
          await dataSelector.switchPivotDropdown(pivot);

          // Get Volumetric per Occasion pivot data
          const volumetricPerOccasionData = getDimensionSelectionsByPivot(pivot, reportTestData);

          await dataSelector.clickMadlibDimension("Product Universe");
          await dataSelector.setMadlibSelection(
            volumetricPerOccasionData["Product Universe"]
          );
          await dataSelector.clickMadlibDimension("Products");
          await dataSelector.setMadlibSelection(
            volumetricPerOccasionData["Products"]
          );
          await dataSelector.waitForMadlibStability();
          await dataSelector.clickMadlibDimension("Retailers");
          await dataSelector.setMadlibSelection(
            volumetricPerOccasionData["Retailers"]
          );
          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.assertFactsDropdown(
            reportAssertData["dataSummary"]["facts"]["factList"]
          );
          await dataSelector.selectClosedDropdown(
            volumetricPerOccasionData["Facts"]["selections"]
          );

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            volumetricPerOccasionData["Geography"]
          );
          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            volumetricPerOccasionData["Period"]
          );
          await dataSelector.clickMadlibDimension("Demographic");
          await dataSelector.setMadlibSelection(
            volumetricPerOccasionData["Demographic"]
          );
          await dataSelector.clickMadlibDimension("Range");
          const rangeConfig = volumetricPerOccasionData["Range"].selections;
          await dataSelector.clickMadlibDimension("defineNewRangeButton");

          await dataSelector.configureRange(
            rangeConfig.volumetricType,     // Volumetric type from dropdown ("Units", "Value", "EQ", "EQ2", "EQ3", "EQ4")
            rangeConfig.minValue,           // Min value
            rangeConfig.maxValue,           // Max value
            rangeConfig.incrementValue      // Increment value
          );
          // await dataSelector.clickMadlibDimension("People");
          // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
          // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
          // for (const selection of reportTestData.dimensionSelections[0]["People"]
          //   .selections) {
          //   await dataSelector.handlePeopleMenuOptions(selection);
          // }

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          console.log("run complete in spec");
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
        );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });

      test(
        "Validate PPT export",
        {
          tag: "@ValidatePPTExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
        }
      );

      test(
        "Validate Excel export",
        {
          tag: "@ValidateExcelExport",
        },
        async () => {
          let exportComponent: ExportComponent;
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = await commonTestCase.getBasePage();
          exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality(
            "Excel",
            "Editable objects",
            "Separately"
          );
        }
      );
    }
  );
});
