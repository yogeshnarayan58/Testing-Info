export interface PeopleMenuType {
  [key: string]: {
    selectorText: string;
    displayText: string;
    tooltipText: string;
  }
}

export interface AssertionMenuOption {
    name: string;
    shouldDisplay: boolean;
    subMenu: AssertionSubMenuOption[];
}

export interface AssertionSubMenuOption {
    name: string;
    shouldDisplay: boolean;
}

