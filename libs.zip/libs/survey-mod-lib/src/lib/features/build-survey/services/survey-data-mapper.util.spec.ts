import { describe, expect, it } from 'vitest';
import { FLOW_TYPES } from '../../../core/config/config';
import { QuestionTypes, SurveyStatusType } from '../models/build-survey';
import {
  buildDraftDatasetConfig,
  fromSavedOptionLabels,
  fromSavedQuestion,
  fromSavedQuestions,
  getExistingQuestionsTitle,
  resolveColumnOptions,
  resolveLaunchUrlByFlow,
} from './survey-data-mapper.util';

describe('survey-data-mapper.util', () => {
  describe('fromSavedQuestions', () => {
    it('should convert array of saved questions to QuestionModel array', () => {
      const savedQuestions = [
        {
          type: QuestionTypes.SingleChoice,
          required: true,
          prompt: { text: 'Question 1' },
          answerSpec: { options: [{ label: 'A' }, { label: 'B' }] },
        },
        {
          type: QuestionTypes.Text,
          required: false,
          prompt: { text: 'Question 2' },
          answerSpec: {},
        },
      ];

      const result = fromSavedQuestions(savedQuestions);

      expect(result).toHaveLength(2);
      expect(result[0].question).toBe('Question 1');
      expect(result[1].question).toBe('Question 2');
    });

    it('should handle null/undefined input', () => {
      expect(fromSavedQuestions(null)).toEqual([]);
      expect(fromSavedQuestions(undefined)).toEqual([]);
    });

    it('should handle empty array', () => {
      expect(fromSavedQuestions([])).toEqual([]);
    });
  });

  describe('fromSavedQuestion', () => {
    it('should convert single saved question to QuestionModel', () => {
      const savedQuestion = {
        type: QuestionTypes.SingleChoice,
        required: true,
        prompt: { text: 'What is your preference?' },
        answerSpec: {
          options: [{ label: 'Option A' }, { label: 'Option B' }],
        },
      };

      const result = fromSavedQuestion(savedQuestion, 0);

      expect(result.questionNumber).toBe(1);
      expect(result.question).toBe('What is your preference?');
      expect(result.isRequired).toBe(true);
      expect(result.type).toBe(QuestionTypes.SingleChoice);
      expect(result.options).toEqual(['Option A', 'Option B']);
    });

    it('should handle NPS question with anchors', () => {
      const savedQuestion = {
        type: QuestionTypes.NetPromoterScore,
        required: false,
        prompt: { text: 'NPS Question' },
        answerSpec: {
          anchors: { min: 'Very Unlikely', max: 'Very Likely' },
        },
      };

      const result = fromSavedQuestion(savedQuestion, 2);

      expect(result.questionNumber).toBe(3);
      expect(result.npsLeftLabel).toBe('Very Unlikely');
      expect(result.npsRightLabel).toBe('Very Likely');
    });

    it('should restore StarRating row labels from answerSpec rows', () => {
      const savedQuestion = {
        type: QuestionTypes.StarRating,
        required: false,
        prompt: { text: 'Rate your favorite movie' },
        answerSpec: {
          rows: [{ value: 'windows', label: 'Windows' }, { value: 'dog', label: 'dog' }],
        },
      };

      const result = fromSavedQuestion(savedQuestion, 0);

      expect(result.rowOptions).toEqual(['Windows', 'dog']);
    });

    it('should increment question number correctly based on index', () => {
      const savedQuestion = {
        type: QuestionTypes.Text,
        prompt: { text: 'Q' },
      };

      const result1 = fromSavedQuestion(savedQuestion, 0);
      const result5 = fromSavedQuestion(savedQuestion, 4);

      expect(result1.questionNumber).toBe(1);
      expect(result5.questionNumber).toBe(5);
    });

    it('should handle missing fields gracefully', () => {
      const savedQuestion = {
        type: undefined,
        required: undefined,
        prompt: undefined,
      };

      const result = fromSavedQuestion(savedQuestion, 0);

      expect(result.type).toBe('');
      expect(result.question).toBe('');
      expect(result.isRequired).toBe(false);
    });

    it('should extract row and column options for scale questions', () => {
      const savedQuestion = {
        type: QuestionTypes.MultiplePointScale,
        required: true,
        prompt: { text: 'Scale Question' },
        answerSpec: {
          rows: [{ label: 'Row 1' }, { label: 'Row 2' }],
          columns: [{ label: 'Col A' }, { label: 'Col B' }, { label: 'Col C' }],
        },
      };

      const result = fromSavedQuestion(savedQuestion, 0);

      expect(result.rowOptions).toEqual(['Row 1', 'Row 2']);
      expect(result.columnOptions).toEqual(['Col A', 'Col B', 'Col C']);
    });
  });

  describe('resolveColumnOptions', () => {
    it('restores single-point rows and columns instead of legacy options', () => {
      const result = fromSavedQuestion({
        type: QuestionTypes.SinglePointScale,
        answerSpec: {
          rows: [{ label: 'Quality' }],
          columns: [{ label: 'Low' }, { label: 'High' }],
          options: [{ label: 'Legacy option' }],
        },
      }, 0);
      expect(result.rowOptions).toEqual(['Quality']);
      expect(result.columnOptions).toEqual(['Low', 'High']);
    });

    it('should return options for SinglePointScale type', () => {
      const answerSpec = {
        options: [{ label: 'Low' }, { label: 'Medium' }, { label: 'High' }],
      };

      const result = resolveColumnOptions(QuestionTypes.SinglePointScale, answerSpec);

      expect(result).toEqual(['Low', 'Medium', 'High']);
    });

    it('should return columns for other scale types', () => {
      const answerSpec = {
        columns: [{ label: 'Col 1' }, { label: 'Col 2' }],
      };

      const result = resolveColumnOptions(QuestionTypes.MultiplePointScale, answerSpec);

      expect(result).toEqual(['Col 1', 'Col 2']);
    });

    it('should handle undefined answerSpec', () => {
      const result = resolveColumnOptions(QuestionTypes.SinglePointScale, undefined);

      expect(result).toEqual([]);
    });

    it('should return empty array when options are missing', () => {
      const result = resolveColumnOptions(QuestionTypes.SinglePointScale, {});

      expect(result).toEqual([]);
    });
  });

  describe('fromSavedOptionLabels', () => {
    it('should extract labels from options array', () => {
      const options = [{ label: 'Label 1' }, { label: 'Label 2' }, { label: 'Label 3' }];

      const result = fromSavedOptionLabels(options);

      expect(result).toEqual(['Label 1', 'Label 2', 'Label 3']);
    });

    it('should trim label values', () => {
      const options = [{ label: '  Label 1  ' }, { label: '  Label 2  ' }];

      const result = fromSavedOptionLabels(options);

      expect(result).toEqual(['Label 1', 'Label 2']);
    });

    it('should filter out empty labels', () => {
      const options = [{ label: 'Label 1' }, { label: '' }, { label: '  ' }, { label: 'Label 2' }];

      const result = fromSavedOptionLabels(options);

      expect(result).toEqual(['Label 1', 'Label 2']);
    });

    it('should handle undefined/null input', () => {
      expect(fromSavedOptionLabels(undefined)).toEqual([]);
      expect(fromSavedOptionLabels(null as any)).toEqual([]);
    });

    it('should handle options with missing label property', () => {
      const options = [{ label: 'Label 1' }, {}, { label: 'Label 2' }];

      const result = fromSavedOptionLabels(options as any);

      expect(result).toEqual(['Label 1', 'Label 2']);
    });
  });

  describe('buildDraftDatasetConfig', () => {
    it('should merge requestInstance and existingDatasetConfig', () => {
      const requestInstance = {
        datasetId: 'req-ds-123',
        datasetLabel: 'Request Dataset',
        dataViewId: 'req-dv-123',
        dataViewName: 'Request View',
        locale: 'en-US',
        datasetStackId: 'req-stack-123',
        productOfferingCode: 'PANEL_OD_OMNI',
      };
      const existingDatasetConfig = {
        id: 'existing-ds-123',
        title: 'Existing Dataset',
        stackId: 'existing-stack-123',
      };

      const result = buildDraftDatasetConfig(requestInstance, existingDatasetConfig);

      expect(result.id).toBe('req-ds-123');
      expect(result.title).toBe('Request Dataset');
      expect(result.dataView.dataViewId).toBe('req-dv-123');
        expect(result.datasetDefaultLocale).toBe('en-US');
      expect(result.productOfferingCode).toBe('PANEL_OD_OMNI');
    });

    it('should use existingDatasetConfig when requestInstance values are missing', () => {
      const requestInstance = {
        datasetId: 'req-123',
      };
      const existingDatasetConfig = {
        id: 'existing-123',
        title: 'Existing Title',
        stackId: 'stack-456',
        datasetDefaultLocale: 'fr-FR',
      };

      const result = buildDraftDatasetConfig(requestInstance, existingDatasetConfig);

      expect(result.id).toBe('req-123');
      expect(result.title).toBe('Existing Title');
      expect(result.stackId).toBe('stack-456');
      expect(result.datasetDefaultLocale).toBe('fr-FR');
    });

    it('should use label as fallback for title', () => {
      const requestInstance = null;
      const existingDatasetConfig = {
        id: 'ds-123',
        label: 'Dataset Label',
      };

      const result = buildDraftDatasetConfig(requestInstance, existingDatasetConfig);

      expect(result.title).toBe('Dataset Label');
      expect(result.label).toBe('Dataset Label');
    });

    it('should handle null both inputs', () => {
      const result = buildDraftDatasetConfig(null, null);

      expect(result).toBeNull();
    });

    it('should build dataView structure with merged values', () => {
      const requestInstance = {
        dataViewId: 'req-dv-id',
        dataViewName: 'Request View Name',
      };
      const existingDatasetConfig = {
        dataView: {
          dataViewId: 'existing-dv-id',
          dataViewName: 'Existing View Name',
        },
      };

      const result = buildDraftDatasetConfig(requestInstance, existingDatasetConfig);

      expect(result.dataView.dataViewId).toBe('req-dv-id');
      expect(result.dataView.dataViewName).toBe('Request View Name');
    });

    it('should preserve existing dataView when requestInstance has no dataView data', () => {
      const requestInstance = { datasetId: 'ds-123' };
      const existingDatasetConfig = {
        dataView: { dataViewId: 'dv-456', dataViewName: 'My View' },
      };

      const result = buildDraftDatasetConfig(requestInstance, existingDatasetConfig);

      expect(result.dataView.dataViewId).toBe('dv-456');
      expect(result.dataView.dataViewName).toBe('My View');
    });
  });

  describe('resolveLaunchUrlByFlow', () => {
    it('should build URL for DRAFT status with SCRATCH flow', () => {
      const flowType = { [FLOW_TYPES.SCRATCH]: true, [FLOW_TYPES.AIFLOW]: false };

      const result = resolveLaunchUrlByFlow(flowType, 'survey-123', SurveyStatusType.DRAFT);

      expect(result).toBe('survey/build-survey/survey-123');
    });

    it('should build URL for DRAFT status with AIFLOW flow', () => {
      const flowType = { [FLOW_TYPES.AIFLOW]: true, [FLOW_TYPES.SCRATCH]: false };

      const result = resolveLaunchUrlByFlow(flowType, 'survey-456', SurveyStatusType.DRAFT);

      expect(result).toBe('survey/aiflow/build-survey/survey-456');
    });

    it('should build URL for PUBLISHED status with SCRATCH flow', () => {
      const flowType = { [FLOW_TYPES.SCRATCH]: true, [FLOW_TYPES.AIFLOW]: false };

      const result = resolveLaunchUrlByFlow(flowType, 'survey-789', SurveyStatusType.PUBLISHED);

      expect(result).toBe('survey/results/survey-789');
    });

    it('should build URL for PUBLISHED status with AIFLOW flow', () => {
      const flowType = { [FLOW_TYPES.AIFLOW]: true, [FLOW_TYPES.SCRATCH]: false };

      const result = resolveLaunchUrlByFlow(flowType, 'survey-111', SurveyStatusType.PUBLISHED);

      expect(result).toBe('survey/aiflow/results/survey-111');
    });

    it('should handle undefined flowType', () => {
      const result = resolveLaunchUrlByFlow(undefined, 'survey-222', SurveyStatusType.DRAFT);

      expect(result).toBe('survey/build-survey/survey-222');
    });

    it('should include survey ID in URL', () => {
      const flowType = { [FLOW_TYPES.SCRATCH]: true };

      const result = resolveLaunchUrlByFlow(flowType, 'my-survey-id', SurveyStatusType.PUBLISHED);

      expect(result).toContain('my-survey-id');
    });
  });

  describe('getExistingQuestionsTitle', () => {
    it('should extract text from questions array', () => {
      const questions = [
        { question: 'First Question' },
        { question: 'Second Question' },
        { question: 'Third Question' },
      ];

      const result = getExistingQuestionsTitle(questions as any);

      expect(result).toHaveLength(3);
      expect(result[0].text).toBe('First Question');
      expect(result[1].text).toBe('Second Question');
      expect(result[2].text).toBe('Third Question');
    });

    it('should trim question text', () => {
      const questions = [
        { question: '  Question 1  ' },
        { question: '  Question 2  ' },
      ];

      const result = getExistingQuestionsTitle(questions as any);

      expect(result[0].text).toBe('Question 1');
      expect(result[1].text).toBe('Question 2');
    });

    it('should filter out empty questions', () => {
      const questions = [
        { question: 'Valid Question' },
        { question: '' },
        { question: '   ' },
        { question: 'Another Valid' },
      ];

      const result = getExistingQuestionsTitle(questions as any);

      expect(result).toHaveLength(2);
      expect(result[0].text).toBe('Valid Question');
      expect(result[1].text).toBe('Another Valid');
    });

    it('should handle null/undefined question field', () => {
      const questions = [
        { question: 'Valid' },
        { question: null },
        { question: undefined },
        { question: 'Another' },
      ];

      const result = getExistingQuestionsTitle(questions as any);

      expect(result).toHaveLength(2);
    });

    it('should handle empty questions array', () => {
      const result = getExistingQuestionsTitle([]);

      expect(result).toEqual([]);
    });

    it('should format result with text property', () => {
      const questions = [{ question: 'Test' }];

      const result = getExistingQuestionsTitle(questions as any);

      expect(result[0]).toHaveProperty('text');
      expect(result[0].text).toBe('Test');
    });
  });
});
