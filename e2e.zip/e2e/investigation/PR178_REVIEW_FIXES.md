# PR #178 Review Fixes

Running log of review-driven cleanup. Later phases append new sections below; earlier sections are never rewritten.

## Phase 1a

| File | Change (one line) | Review comment fixed |
|---|---|---|
| page-objects/common/common-page.ts | Made abstract; added shared withTimeout, waitUntilVisible, clickWhenVisible, fillWhenVisible, getResource, getCurrentUrl, abstract componentName | Manager withTimeout |
| page-objects/common/login.page.ts | Added `componentName = LOGIN_PAGE_COMPONENT_NAME` | Lead #5 |
| page-objects/survey/start-from-scratch.page.ts | Added `componentName = START_FROM_SCRATCH_PAGE_COMPONENT_NAME` | Lead #5 |
| page-objects/survey/start-with-prompt.page.ts | Added `componentName`; removed duplicate withTimeout/waitUntilVisible/getResource; dropped unused WebActions import | Lead #5 |
| page-objects/common/survey-builder.page.ts | Added `componentName`; removed duplicate withTimeout/waitUntilVisible/getResource/clickWhenVisible/fillWhenVisible/getCurrentUrl | Lead #5 |

No public method names, signatures, timeout values, or error/step messages changed.

Test results: _pending_

## Phase 3

| Locator | Old | New |
|---|---|---|
| rephraseWithAiButton | `.rephrase-action >> nth=${text}` | `[data-test-id='rephrase-with-ai-${text}']` |
| rephraseInput | `.rephrase-input` | `[data-test-id='rephrase-input-${text}']` |
| rephraseSendButton | `.rephrase-send` | `[data-test-id='rephrase-send-${text}']` |
| repromptInput | `.reprompt-input` | `[data-test-id='reprompt-input']` |
| repromptSubmitButton | `role=button[name="Submit"]` | `[data-test-id='reprompt-submit']` |
| rephraseQuestion() dynamic selectors | `getResource(name)` for input and send button | `getDynamicResource(name, String(index), this.componentName)` |

Test results: _pending_

## Phase 1b

| File | Change (one line) | Review comment fixed |
|---|---|---|
| page-objects/common/survey-builder.page.ts | Merged getPublishDisabledState/getValidateDisabledState into private getButtonDisabledState | Lead #7 |
| page-objects/common/survey-builder.page.ts | Merged addPointScaleQuestion/addMultiScaleQuestion into private addScaleQuestion | Lead #7 |
| page-objects/common/survey-builder.page.ts | Reformatted line-3 compressed import to one per line | Lead #8 |
| tests/survey/start-from-scratch.spec.ts | Reformatted compressed register...Test import to one per line | Lead #8 |
| tests/survey/start-with-prompt.spec.ts | Reformatted compressed register...Test import to one per line | Lead #8 |
| locators/survey/*.locator.json (5 files) | Removed confirmed-unreferenced entries | related cleanup: duplication |

Deleted: clickBackButton, waitForQuestionEditorClosed, isSurveyVisibleInMyAssets; locator entries optionInput, loggedInLandmark, selectPanelistsTab, buildSurveyButton, firstDataset, entireDatasetOption, selectPanelistsHeading, questionCountSlider, questionCountError, repromptCloseButton.

Kept on purpose: isChangesRecommendedToastVisible (needed in Phase 2); all *NoDataPrompt locator entries (referenced from test-data JSON).

Not deleted: page-objects/common/panelist-flow.helper.ts — user declined the terminal delete command; needs manual removal.

Test results: _pending_

## Phase 2

| File | Change | Review comment fixed |
|---|---|---|
| page-objects/common/survey-builder.page.ts | Added getValidationOutcome(); kept isValidationResultToastVisible | Lead #2 |
| tests/.../build-survey-common-test-cases.ts | registerValidateSurveyTest asserts outcome, conditional tag/link checks | Lead #2 |
| tests/.../build-survey-common-test-cases.ts | registerReviewModeTest: added re-select-0 and sequential-renumber checks | Lead #10 |
| start-from-scratch.spec.ts | Quarantine comment/title reworded; inline Review Mode tests replaced by registerReviewModeTest | Lead #3, #10 |
| start-with-prompt.spec.ts | registerReviewModeTest title aligned; duplicate @StartWithPrompt tags removed | Lead #10, #1 |
| start-from-scratch.spec.ts, start-with-prompt.spec.ts | Unique TC IDs; describe.serial tagged/commented as stateful | Lead #9, #1 |

TC ID renames: TC_BS_03→03a (Single Choice), TC_BS_04→03b (Multiple Choice), TC_BS_05→03c (Rating), TC_BS_07→03d (NPS), TC_BS_08→03e (Point Scale), TC_BS_09→03f (Multi Scale), TC_BS_MAX_QUESTIONS→TC_BS_08, TC_BS_SAVE_DRAFT→TC_BS_10, TC_BS_PUBLISH→TC_BS_16/TC_BS_18, "Generate more questions"→TC_AI_08, "Describe questions to add"→TC_AI_09, "Rephrase with AI"→TC_AI_10.

Fix: review-mode step order (Unselect All needs full selection).

Fix: validation toasts checked in parallel (toast auto-hides).

Fix: "Validating" toast is transient; test passes if it or a result is seen.

Fix: validation asserted on persistent UI state (button change, recommendation tag, Optiq link) instead of transient toasts.

Test results: _pending_

Test results: _pending_

## Manager comment (withTimeout)

| File | Change | withTimeout calls removed |
|---|---|---:|
| utils/base-page-factory.ts | Set Playwright default action and navigation timeouts for LambdaTest and local pages | 0 |
| page-objects/common/survey-builder.page.ts | Removed all wrappers and replaced drag settling with a deadline loop | 35 |
| page-objects/survey/start-with-prompt.page.ts | Removed wrapper from question-type tile click | 1 |
| page-objects/common/common-page.ts | Removed the withTimeout method definition | 0 |
| PR178_REVIEW_FIXES.md | Appended this manager-comment record | 0 |

Test results: _pending_
