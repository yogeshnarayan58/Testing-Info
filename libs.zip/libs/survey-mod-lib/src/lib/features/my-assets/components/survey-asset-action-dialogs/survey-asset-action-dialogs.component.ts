import { ChangeDetectionStrategy, Component, DestroyRef, ViewChild, WritableSignal, computed, inject, output, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Asset } from '@nielsen/crf-lp-common';
import { TreeForderSelectorModule } from '@nielsen/crf-ui-components';
import { ButtonModule, DialogComponent, DialogModule, SpinnerModule, TabModule, TextFieldModule, ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { Observable, Subscription, finalize } from 'rxjs';
import { SurveyGridRow } from '../../models/survey-asset.model';
import { isFolderAsset } from '../../utils/survey-status.util';
import { SurveyAssetActionsService } from '../../services/survey-asset-actions.service';
import { ASSET_TYPE } from '../../constants/my-assets-tabs.constant';

/** State and toast messages for a mutation. */
interface MutationState {
  busy: WritableSignal<boolean>;
  dialog?: DialogComponent;
  successMessage: string;
  errorMessage: string;
}

@Component({
  selector: 'survey-asset-action-dialogs',
  standalone: true,
  imports: [FormsModule, ButtonModule, DialogModule, SpinnerModule, TabModule, TextFieldModule, TreeForderSelectorModule],
  templateUrl: './survey-asset-action-dialogs.component.html',
  styleUrl: './survey-asset-action-dialogs.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyAssetActionDialogsComponent {
  private readonly actions = inject(SurveyAssetActionsService);
  private readonly toast = inject(ToastService);
  private readonly destroyRef = inject(DestroyRef);
  readonly assetsChanged = output<void>();
  readonly renameTitle = signal('');
  readonly renameBusy = signal(false);
  readonly renameValidation = computed(() => {
    const title = this.renameTitle();
    if (!title.length) {
      return 'This field is required.';
    }
    if (title.startsWith(' ')) {
      return 'Cannot use empty spaces at the start.';
    }
    return title.length > 150 ? 'Cannot enter more than 150 characters.' : '';
  });
  readonly folders = signal<Asset[]>([]);
  readonly foldersLoading = signal(false);
  readonly folderLoadFailed = signal(false);
  readonly moveBusy = signal(false);
  readonly rootFolder: Asset = { assetId: 'root', title: 'My assets' };
  readonly selectedFolder = signal<Asset>(this.rootFolder);
  readonly assetsToMove = signal<readonly SurveyGridRow[]>([]);
  readonly moveDisabled = computed(() => this.foldersLoading() || this.folderLoadFailed() || this.moveBusy()
    || !this.assetsToMove().some((row) => (row.parentAsset?.assetId ?? 'root') !== this.selectedFolder().assetId));
  readonly deleteSelection = signal<{ rows: readonly SurveyGridRow[]; permanent: boolean }>({
    rows: [], permanent: false,
  });
  readonly deleteBusy = signal(false);
  readonly restoreBusy = signal(false);
  readonly deleteConfirmation = computed(() => {
    const { rows, permanent } = this.deleteSelection();
    return {
      testId: permanent ? 'survey-delete-permanent' : 'survey-delete',
      title: permanent
        ? (rows.length > 1 ? 'Delete permanently' : 'Confirm deletion')
        : (rows.length === 1 && !isFolderAsset(rows[0]) ? 'Delete' : 'Move to trash'),
      message: this.buildDeleteMessage(rows, permanent),
      busy: this.deleteBusy(),
      buttonLabel: permanent && rows.length === 1 ? 'Delete' : 'Confirm',
      permanent,
    };
  });
  private renameAssetId: string | null = null;
  private folderRequest?: Subscription;

  @ViewChild('renameDialog') renameDialog?: DialogComponent;
  @ViewChild('folderDialog') folderDialog?: DialogComponent;
  @ViewChild('confirmDialog') confirmDialog?: DialogComponent;
  @ViewChild('deleteDialog') deleteDialog?: DialogComponent;

  /** Opens Rename prefilled with the asset's current title. */
  openRename(row: SurveyGridRow): void {
    this.renameAssetId = row.assetId;
    this.renameTitle.set(row.title);
    this.renameDialog?.open();
  }

  /** Submits a valid rename; ignored while a request is pending. */
  saveRename(): void {
    if (this.renameBusy() || this.renameValidation() || !this.renameAssetId) {
      return;
    }
    this.runMutation(this.actions.renameAsset(this.renameAssetId, this.renameTitle()), {
      busy: this.renameBusy,
      dialog: this.renameDialog,
      successMessage: `${this.renameTitle()} was updated`,
      errorMessage: 'Unable to rename the asset. Please try again.',
    });
  }

  /** Opens the folder picker for a snapshot of the selected rows, defaulting to My assets. */
  openMove(rows: readonly SurveyGridRow[]): void {
    this.cancelFolderLoad();
    this.assetsToMove.set([...rows]);
    this.selectedFolder.set(this.rootFolder);
    this.folders.set([]);
    this.folderDialog?.open();
    this.loadFolders();
  }

  /** Fetches destination folders; also used by the Retry link after a failure. */
  loadFolders(): void {
    if (this.foldersLoading()) {
      return;
    }
    this.foldersLoading.set(true);
    this.folderLoadFailed.set(false);
    this.folderRequest = this.actions.fetchMoveFolders().pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => this.foldersLoading.set(false))
    ).subscribe({
      next: (folders) => this.folders.set(folders),
      error: () => {
        this.folderLoadFailed.set(true);
        this.notifyError('Unable to load folders. Please try again.');
      },
    });
  }

  /** Drops a pending folder request so a stale response cannot update a closed or reopened dialog. */
  cancelFolderLoad(): void {
    this.folderRequest?.unsubscribe();
  }

  selectFolder(folder: Asset): void {
    this.selectedFolder.set(folder);
  }

  /** Switches from the folder picker to the confirmation dialog when the move is valid. */
  confirmMove(): void {
    if (this.moveDisabled()) {
      return;
    }
    this.folderDialog?.close();
    this.confirmDialog?.open();
  }

  /** Moves the selected surveys after the user confirms the destination. */
  saveMove(): void {
    if (this.moveBusy()) {
      return;
    }
    this.runMutation(this.actions.moveAssets(this.assetsToMove(), this.selectedFolder()), {
      busy: this.moveBusy,
      dialog: this.confirmDialog,
      successMessage: this.moveSuccessMessage(),
      errorMessage: 'Unable to move the selected surveys. Please try again.',
    });
  }

  private moveSuccessMessage(): string {
    const assets = this.assetsToMove();
    const destination = this.selectedFolder().title;
    return assets.length === 1
      ? `"${assets[0].title}" was successfully moved to ${destination}`
      : `Assets were successfully moved to ${destination}`;
  }

  /** Trashes a single survey directly; folders and bulk selections require confirmation. */
  openDelete(rows: readonly SurveyGridRow[]): void {
    if (this.deleteBusy() || !rows.length) {
      return;
    }
    this.deleteSelection.set({ rows: [...rows], permanent: false });
    const selectedRows = this.deleteSelection().rows;
    if (selectedRows.length === 1 && selectedRows[0].assetType === ASSET_TYPE.DISCOVERSURVEY) {
      this.runMutation(this.actions.trashAssets(selectedRows), {
        busy: this.deleteBusy,
        successMessage: `"${selectedRows[0].title}" has been moved to the trash`,
        errorMessage: 'Unable to delete the selected asset(s). Please try again.',
      });
      return;
    }
    this.deleteDialog?.open();
  }

  /** Moves the selected assets to Trash after the user confirms. */
  saveDelete(): void {
    if (this.deleteBusy()) {
      return;
    }
    const rows = this.deleteSelection().rows;
    this.runMutation(this.actions.trashAssets(rows), {
      busy: this.deleteBusy,
      dialog: this.deleteDialog,
      successMessage: rows.length === 1 ? `Your asset "${rows[0].title}" has been moved to the trash` : `All selected assets have been moved to the trash`,
      errorMessage: 'Unable to delete the selected asset(s). Please try again.',
    });
  }

  /** Opens the "Delete permanently" confirmation (Trash tab only; irreversible on confirm). */
  openDeletePermanently(rows: readonly SurveyGridRow[]): void {
    if (this.deleteBusy() || !rows.length) {
      return;
    }
    this.deleteSelection.set({ rows: [...rows], permanent: true });
    this.deleteDialog?.open();
  }

  saveDeleteConfirmation(): void {
    if (this.deleteSelection().permanent) {
      this.saveDeletePermanently();
    } else {
      this.saveDelete();
    }
  }

  /** Permanently deletes the selected assets after the user confirms. */
  saveDeletePermanently(): void {
    if (this.deleteBusy()) {
      return;
    }
    const rows = this.deleteSelection().rows;
    this.runMutation(this.actions.deletePermanently(rows), {
      busy: this.deleteBusy,
      dialog: this.deleteDialog,
      successMessage: rows.length === 1
        ? `"${rows[0].title}" has been deleted from your assets.`
        : 'All selected assets have been successfully deleted.',
      errorMessage: 'Unable to permanently delete the selected asset(s). Please try again.',
    });
  }

  /** Restores the selection from Trash immediately: unlike delete, this isn't destructive, so no confirmation is needed. */
  restore(rows: readonly SurveyGridRow[]): void {
    if (this.restoreBusy() || !rows.length) {
      return;
    }
    this.runMutation(this.actions.restoreAssets(rows), {
      busy: this.restoreBusy,
      successMessage: rows.length === 1 ? `${rows[0].title} has been restored` : 'Selected assets have been restored',
      errorMessage: 'Unable to restore the selected asset(s). Please try again.',
    });
  }

  /** Builds the Delete / Delete permanently confirmation message for the current selection. */
  private buildDeleteMessage(rows: readonly SurveyGridRow[], permanent: boolean): string {
    if (rows.length > 1) {
      return permanent
        ? `Are you sure you want to delete the selected assets ? This action cannot be undone.`
        : `Are you sure you want to move all the selected assets and all of its contents or sub-folders if any, to the trash?`;
    }
    const row = rows[0];
    if (!row) {
      return '';
    }
    if (permanent) {
      return `Are you sure you want to delete ${row.title} ? This action cannot be undone.`;
    }
    return isFolderAsset(row)
      ? `Are you sure you want to move the folder ${row.title} and all of its contents, including any sub-folders, to the trash?`
      : `Are you sure you want to delete ${row.title} ? It will be moved to the trash.`;
  }

  /** Closes and refreshes only on success; failures show a toast and allow retry. */
  private runMutation(request: Observable<unknown>, state: MutationState): void {
    state.busy.set(true);
    request.pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => state.busy.set(false))
    ).subscribe({
      next: () => {
        state.dialog?.close();
        this.notifySuccess(state.successMessage);
      },
      error: () => this.notifyError(state.errorMessage),
    });
  }

  private notifyError(message: string): void {
    this.toast.InsertToast('error', message, { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
  }

  /** Shows a success toast and asks the parent page to refresh its assets. */
  private notifySuccess(message: string): void {
    this.toast.InsertToast('success', message, { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
    this.assetsChanged.emit();
  }
}
