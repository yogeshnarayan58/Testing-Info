import { BasePage } from '@gfk/gta';
import { CommonPage } from './common-page';
import myAssetsPageResources from '../../locators/survey/my-assets.locator.json';
import { FeatureTogglePage, SURVEY_MODERNIZATION_FMS_TOGGLE_NAME } from './feature-toggle.page';
import { envConfig } from '../../config/env.config';
import { ELEMENT_WAIT_TIMEOUT, NAVIGATION_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';

const MY_ASSETS_PAGE_COMPONENT_NAME = 'myAssetsPage';
const SURVEY_HOME_RELATIVE_PATH = 'survey';

export class MyAssetsPage extends CommonPage {
  protected readonly componentName = MY_ASSETS_PAGE_COMPONENT_NAME;

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(MY_ASSETS_PAGE_COMPONENT_NAME, myAssetsPageResources);
  }

  /** Makes sure the FMS toggle is ON, then goes through the survey home page ("View all surveys"), because the direct my-assets URL redirects to the Reports list. */
  async openMyAssetsPage(baseURL: string = envConfig.BASE_URL): Promise<void> {
    try {
      try {
        await new FeatureTogglePage(this.basePage).enableSurveyModernizationInFms(baseURL);
      } catch (error) {
        console.warn(`FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" step failed, continuing`, error);
      }

      await this.navigateToUrl(this.buildUrl(baseURL, SURVEY_HOME_RELATIVE_PATH));
      await this.clickWhenVisible('viewAllSurveysLink', '"View all surveys" link', NAVIGATION_TIMEOUT);

      const grid = this.webActionHandler.getWebElement(this.getResource('surveyAssetsGrid'));
      await this.waitUntilVisible(grid, 'My assets surveys grid', NAVIGATION_TIMEOUT);

      const myAssetsTab = this.webActionHandler.getWebElement(this.getResource('myAssetsTab'));
      await this.waitUntilVisible(myAssetsTab, 'My assets tab');
      const classTokens = ((await myAssetsTab.getAttribute('class')) ?? '').split(/\s+/);
      const isSelected =
        (await myAssetsTab.getAttribute('aria-selected')) === 'true' ||
        classTokens.includes('active') ||
        classTokens.includes('selected');
      if (!isSelected) {
        await myAssetsTab.click();
        await this.waitUntilVisible(grid, 'My assets surveys grid (after selecting the My assets tab)', NAVIGATION_TIMEOUT);
      }
    } catch (error) {
      throw new Error(`Failed to open the My assets page: ${error instanceof Error ? error.message : error}`);
    }
  }

  private getAssetTitleElement(title: string) {
    return this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('surveyGridTitleByText', title, MY_ASSETS_PAGE_COMPONENT_NAME)
    );
  }

  async isAssetVisibleByTitle(title: string): Promise<boolean> {
    try {
      return await this.getAssetTitleElement(title).isVisible(ELEMENT_WAIT_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to look for "${title}" in My assets: ${error instanceof Error ? error.message : error}`);
    }
  }

  async openFolderByTitle(title: string): Promise<void> {
    try {
      const row = this.getAssetTitleElement(title);
      await this.waitUntilVisible(row, `Folder "${title}" in My assets`);
      await row.click();

      const breadcrumb = this.webActionHandler.getWebElement(this.getResource('folderBreadcrumb'));
      const deadline = Date.now() + ELEMENT_WAIT_TIMEOUT;
      let breadcrumbText = '';
      do {
        if (await breadcrumb.isVisible(ELEMENT_WAIT_TIMEOUT)) {
          breadcrumbText = ((await breadcrumb.getText()) ?? '').trim();
          if (breadcrumbText.includes(title)) {
            return;
          }
        }
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      } while (Date.now() < deadline);
      throw new Error(`folder breadcrumb did not show "${title}" (breadcrumb text: "${breadcrumbText}")`);
    } catch (error) {
      throw new Error(`Failed to open folder "${title}" in My assets: ${error instanceof Error ? error.message : error}`);
    }
  }
}
