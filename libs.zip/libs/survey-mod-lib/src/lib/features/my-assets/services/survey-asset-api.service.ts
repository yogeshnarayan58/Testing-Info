import { Injectable, inject } from '@angular/core';
import { AssetCatalogResponse, SurveyGridAsset, CreateFolderRequest, CreateFolderResponse, SurveyGridRow } from '../models/survey-asset.model';
import { MY_ASSETS_TABS, MyAssetsTabId, getAssetCatalogCacheTag } from '../constants/my-assets-tabs.constant';
import { getStatusDisplay } from '../utils/survey-status.util';
import { buildAssetCatalogRequest } from '../utils/asset-catalog-request.util';
import { ApiService } from '../../../shared/services/api.service';
import { catchError, map, Observable, switchMap, take, tap } from 'rxjs';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { ACFetchApiService, Asset, AssignRightsHelperService, UserService } from '@nielsen/crf-lp-common';

@Injectable({
  providedIn: 'root',
})
export class SurveyAssetApiService {
  private readonly api = inject(ApiService);
  private readonly environment = inject(EnvironmentConfig);
  private readonly assignRightsHelper = inject(AssignRightsHelperService);
  private readonly userService = inject(UserService);
  private readonly assetFetchApi = inject(ACFetchApiService);

  fetchSurveyDetails(row: SurveyGridRow): Observable<SurveyGridRow> {
    return this.assetFetchApi.getAssetInfoByAssetId(row.assetId, {
      userDetails: true,
      associatedUsers: true,
      parentHierarchy: true,
      sourceId: true,
    }, false).pipe(
      map((assets) => {
        const asset = assets.find((item) => item.assetId === row.assetId);
        if (!asset) {
          throw new Error('Survey details were not returned.');
        }
        const details: SurveyGridRow = { ...row, ...asset };
        return { ...details, statusDisplay: getStatusDisplay(details) };
      })
    );
  }

  /** Fetches folder children using hierarchical my-assets API config. */
  fetchFolderChildren(
    folderId: string,
    startRow = 0,
    pageSize = 100,
    sortModel?: Array<{ colId: string; sort: 'asc' | 'desc' }>,
    tab: MyAssetsTabId = MY_ASSETS_TABS.MY_ASSETS
  ): Observable<{ assets: SurveyGridAsset[]; totalCount: number }> {
    return this.userService.getUserData().pipe(
      take(1),
      switchMap((user) => {
        const stablePageSize = pageSize > 0 ? pageSize : 100;
        const request = buildAssetCatalogRequest({
          tab,
          folderId,
          pageCount: stablePageSize,
          pageNumber: Math.floor(startRow / stablePageSize) + 1,
          primarySort: sortModel?.[0]?.colId ?? 'DATE',
          sortOrder: sortModel?.[0]?.sort === 'asc' ? 'ASC' : 'DESC',
          timezone: user?.timezone || 'Etc/Universal',
        });

        // Use ApiService to post with caching instead of assetFetchApi
        return this.api.post<AssetCatalogResponse>(
          `${this.environment.apiUrls.assetCatalogDiscovery}`,
          request,
          { withCredentials: true, cache: true, cacheTag: getAssetCatalogCacheTag(tab, folderId) }
        ).pipe(map((response) => this.toFolderChildrenResult(response)));
      })
    );
  }

  /** Loads a folder and its parent hierarchy for breadcrumb reconstruction. */
  fetchFolderHierarchy(folderId: string): Observable<Asset[]> {
    return this.assetFetchApi.getParentHierarchyByAssetId(folderId, false);
  }

  // Maps LP asset rows to My Assets grid row model.
  private toSurveyGridAsset(asset: Asset | SurveyGridAsset): SurveyGridAsset {
    return {
      ...asset,
      assetId: String(asset.assetId ?? ''),
      assetType: String(asset.assetType ?? ''),
      title: asset.title ?? String(asset.assetId ?? ''),
      lastModifiedTimestamp: asset.lastModifiedTimestamp ?? 0,
      status: typeof asset.status === 'string' ? asset.status : undefined,
      launchURL: asset.launchURL,
      sourceId: asset.sourceId,
      isMyFavorite: asset.isMyFavorite,
    };
  }

  // Normalizes API response shape used by getMyAssets to grid contract.
  private toFolderChildrenResult(response: {
    data?: { assets?: Array<Asset | SurveyGridAsset>; summary?: { totalAssets?: number }; properties?: { totalAssets?: number } };
    summary?: { totalAssets?: number };
  }): { assets: SurveyGridAsset[]; totalCount: number } {
    const assets = response.data?.assets ?? [];
    return {
      assets: assets.map((asset) => this.toSurveyGridAsset(asset)),
      totalCount: Math.max(
        response.data?.summary?.totalAssets
          ?? response.summary?.totalAssets
          ?? response.data?.properties?.totalAssets
          ?? 0,
        assets.length
      ),
    };
  }

  /**
   * Fetches paged survey assets and maps API records into grid rows.
   */
  fetchSurveyAssets(
    startRow: number,
    endRow: number,
    sortModel?: Array<{ colId: string; sort: 'asc' | 'desc' }>,
    pageSize?: number,
    tab: MyAssetsTabId = MY_ASSETS_TABS.MY_ASSETS
  ): Observable<{ assets: SurveyGridAsset[]; totalCount: number }> {
    const stablePageSize = pageSize && pageSize > 0 ? pageSize : Math.max(endRow - startRow, 1);
    const pageCount = stablePageSize;
    const pageNumber = Math.floor(startRow / pageCount) + 1;
    const primarySort = sortModel?.[0]?.colId ?? 'DATE';
    const sortOrder = sortModel?.[0]?.sort === 'asc' ? 'ASC' : 'DESC';

    return this.userService.getUserData().pipe(
      take(1),
      switchMap((user) => {
        const requestBody = buildAssetCatalogRequest({
          tab,
          pageCount,
          pageNumber,
          primarySort,
          sortOrder,
          timezone: user?.timezone || 'Etc/Universal',
        });

        return this.api.post<AssetCatalogResponse>(
          `${this.environment.apiUrls.assetCatalogDiscovery}`,
          requestBody,
          { withCredentials: true, cache: true, cacheTag: getAssetCatalogCacheTag(tab) }
        );
      }),
      map((response) => {
        const assets = response.data?.assets ?? [];
        const totalCount = Math.max(
          response.data?.summary?.totalAssets
            ?? response.summary?.totalAssets
            ?? 0,
          assets.length
        );

        return { assets, totalCount };
      })
    );
  }

  /**
   * Marks or unmarks an asset as a favorite for the current user.
   */
  updateFavorite(assetId: string, isFavorite: boolean): Observable<unknown> {
    return this.api.put(
      `${this.environment.apiUrls.assetCatalogIntegration}/${encodeURIComponent(assetId)}/myAssociation`,
      { isFavorite },
      { withCredentials: true }
    ).pipe(tap(() => this.api.clearCache(this.environment.apiUrls.assetCatalogDiscovery)));
  }

  /**
   * Creates a new folder in the asset catalog
   */
  createFolder(folderName: string, parentFolderId?: string): Observable<CreateFolderResponse> {
    return this.assignRightsHelper.getDefaultRights().pipe(
      take(1),
      switchMap((rights) => {
        const payload: CreateFolderRequest[] = [
          {
            assetType: 'DISCOVERFOLDER',
            title: folderName,
            status: 'OPEN',
            rights: rights,
            ...(parentFolderId ? { parentAsset: { assetId: parentFolderId } } : {}),
          },
        ];

        return this.api.post<CreateFolderResponse>(
          `${this.environment.apiUrls.assetCatalogIntegration}`,
          payload,
          { withCredentials: true }
        );
      }),
      tap(() => this.api.clearCache(this.environment.apiUrls.assetCatalogDiscovery)),
      catchError((error) => {
        console.error('Error creating folder:', error);
        throw error;
      })
    );
  }
}
