import { ChangeDetectionStrategy, Component, DestroyRef, ViewChild, WritableSignal, computed, inject, output, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Asset } from '@nielsen/crf-lp-common';
import { TreeForderSelectorModule } from '@nielsen/crf-ui-components';
import { ButtonModule, DialogComponent, DialogModule, SpinnerModule, TabModule, TextFieldModule, ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { Observable, Subscription, finalize } from 'rxjs';
import { SurveyGridRow } from '../../models/survey-asset.model';
import { SurveyAssetActionsService } from '../../services/survey-asset-actions.service';

/** Per-dialog state and messages used by the shared Rename/Move request handler. */
interface MutationState {
  busy: WritableSignal<boolean>;
  error: WritableSignal<string>;
  dialog?: DialogComponent;
  successMessage: string;
  errorMessage: string;
}

@Component({
  selector: 'survey-asset-action-dialogs',
  standalone: true,
  imports: [FormsModule, ButtonModule, DialogModule, SpinnerModule, TabModule, TextFieldModule, TreeForderSelectorModule],
  templateUrl: './survey-asset-action-dialogs.component.html',
  styleUrl: './survey-asset-action-dialogs.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SurveyAssetActionDialogsComponent {
  private readonly actions = inject(SurveyAssetActionsService);
  private readonly toast = inject(ToastService);
  private readonly destroyRef = inject(DestroyRef);
  readonly assetsChanged = output<void>();
  readonly renameTitle = signal('');
  readonly renameBusy = signal(false);
  readonly renameError = signal('');
  readonly renameValidation = computed(() => {
    const title = this.renameTitle();
    if (!title.length) {
      return 'This field is required.';
    }
    if (title.startsWith(' ')) {
      return 'Cannot use empty spaces at the start.';
    }
    return title.length > 150 ? 'Cannot enter more than 150 characters.' : '';
  });
  readonly folders = signal<Asset[]>([]);
  readonly foldersLoading = signal(false);
  readonly moveBusy = signal(false);
  readonly moveError = signal('');
  readonly rootFolder: Asset = { assetId: 'root', title: 'My assets' };
  readonly selectedFolder = signal<Asset>(this.rootFolder);
  readonly assetsToMove = signal<readonly SurveyGridRow[]>([]);
  readonly moveDisabled = computed(() => this.foldersLoading() || this.moveBusy() || !!this.moveError()
    || !this.assetsToMove().some((row) => (row.parentAsset?.assetId ?? 'root') !== this.selectedFolder().assetId));
  private renameAssetId: string | null = null;
  private folderRequest?: Subscription;

  @ViewChild('renameDialog') renameDialog?: DialogComponent;
  @ViewChild('folderDialog') folderDialog?: DialogComponent;
  @ViewChild('confirmDialog') confirmDialog?: DialogComponent;

  /** Opens Rename prefilled with the asset's current title. */
  openRename(row: SurveyGridRow): void {
    this.renameAssetId = row.assetId;
    this.renameTitle.set(row.title);
    this.renameError.set('');
    this.renameDialog?.open();
  }

  /** Submits a valid rename; ignored while a request is pending. */
  saveRename(): void {
    if (this.renameBusy() || this.renameValidation() || !this.renameAssetId) {
      return;
    }
    this.runMutation(this.actions.renameAsset(this.renameAssetId, this.renameTitle()), {
      busy: this.renameBusy,
      error: this.renameError,
      dialog: this.renameDialog,
      successMessage: `${this.renameTitle()} was updated`,
      errorMessage: 'Unable to rename the asset. Please try again.',
    });
  }

  /** Opens the folder picker for a snapshot of the selected rows, defaulting to My assets. */
  openMove(rows: readonly SurveyGridRow[]): void {
    this.cancelFolderLoad();
    this.assetsToMove.set([...rows]);
    this.selectedFolder.set(this.rootFolder);
    this.folders.set([]);
    this.folderDialog?.open();
    this.loadFolders();
  }

  /** Fetches destination folders; also used by the Retry link after a failure. */
  loadFolders(): void {
    if (this.foldersLoading()) {
      return;
    }
    this.foldersLoading.set(true);
    this.moveError.set('');
    this.folderRequest = this.actions.fetchMoveFolders().pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => this.foldersLoading.set(false))
    ).subscribe({
      next: (folders) => this.folders.set(folders),
      error: () => this.moveError.set('Unable to load folders. Please try again.'),
    });
  }

  /** Drops a pending folder request so a stale response cannot update a closed or reopened dialog. */
  cancelFolderLoad(): void {
    this.folderRequest?.unsubscribe();
  }

  selectFolder(folder: Asset): void {
    this.selectedFolder.set(folder);
  }

  /** Switches from the folder picker to the confirmation dialog when the move is valid. */
  confirmMove(): void {
    if (this.moveDisabled()) {
      return;
    }
    this.folderDialog?.close();
    this.confirmDialog?.open();
  }

  /** Moves the selected surveys after the user confirms the destination. */
  saveMove(): void {
    if (this.moveBusy()) {
      return;
    }
    this.runMutation(this.actions.moveAssets(this.assetsToMove(), this.selectedFolder()), {
      busy: this.moveBusy,
      error: this.moveError,
      dialog: this.confirmDialog,
      successMessage: this.moveSuccessMessage(),
      errorMessage: 'Unable to move the selected surveys. Please try again.',
    });
  }

  private moveSuccessMessage(): string {
    const assets = this.assetsToMove();
    const destination = this.selectedFolder().title;
    return assets.length === 1
      ? `"${assets[0].title}" was successfully moved to ${destination}`
      : `Assets were successfully moved to ${destination}`;
  }

  /**
   * Runs a Rename/Move request with the shared dialog lifecycle: tracks busy state,
   * closes the dialog and notifies the parent on success, or keeps it open with an error for retry.
   */
  private runMutation(request: Observable<unknown>, state: MutationState): void {
    state.busy.set(true);
    state.error.set('');
    request.pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => state.busy.set(false))
    ).subscribe({
      next: () => {
        state.dialog?.close();
        this.notifySuccess(state.successMessage);
      },
      error: () => state.error.set(state.errorMessage),
    });
  }

  /** Shows a success toast and asks the parent page to refresh its assets. */
  private notifySuccess(message: string): void {
    this.toast.InsertToast('success', message, { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
    this.assetsChanged.emit();
  }
}
