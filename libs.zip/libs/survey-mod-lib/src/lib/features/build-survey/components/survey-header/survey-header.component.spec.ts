import { MY_ASSETS_ROOT } from '../../../../shared/utils/survey-folder.util';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { ToastService } from '@nielseniq/athena-core';
import { of, Subject, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { ReviewModeService } from '../../services/review-mode.service';
import { SurveyService } from '../../services/survey.service';
import { SurveyHeaderComponent } from './survey-header.component';
import { ACAssetManageApiService, ACFetchApiService } from '@nielsen/crf-lp-common';

vi.mock('../../services/survey.service', () => ({
  SurveyService: class {},
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class ACFetchApiService {},
  ACAssetManageApiService: class ACAssetManageApiService {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

vi.mock('@nielsen/crf-ui-components', async () => {
  const { NgModule } = await import('@angular/core');
  class DialogsModule {}
  NgModule({})(DialogsModule);
  return {
    DialogsModule,
    SaveACopyComponent: class SaveACopyComponent {},
    CreateFolderComponent: class CreateFolderComponent {},
  };
});

const createMockTranslateService = () => ({
  instant: vi.fn((key: string) => key),
  get: vi.fn((key: string) => of(key)),
  setDefaultLanguage: vi.fn(),
  use: vi.fn().mockReturnValue(of({})),
});

describe('SurveyHeaderComponent', () => {
  let component: SurveyHeaderComponent;
  let router: { navigate: ReturnType<typeof vi.fn> };
  let mockTranslateService: any;
  let activatedRoute: any;
  let surveyService: {
    title: ReturnType<typeof signal<string>>;
    genState: ReturnType<typeof signal<'idle' | 'loading' | 'done'>>;
    questions: ReturnType<typeof signal<unknown[]>>;
    updateTitle: ReturnType<typeof vi.fn>;
    saveSurveyDraft: ReturnType<typeof vi.fn>;
    currentAssetIdValue: string | null;
    surveyIdValue: string | null;
    setSelectedFolder: ReturnType<typeof vi.fn>;
    getSelectedFolder: ReturnType<typeof vi.fn>;
  };
  let reviewModeService: {
    isReviewMode: ReturnType<typeof signal<boolean>>;
    isAllChecked: ReturnType<typeof signal<boolean>>;
    deleteCheckedQuestions: ReturnType<typeof vi.fn>;
    toggleAllChecked: ReturnType<typeof vi.fn>;
    setAllCardsCollapsed: ReturnType<typeof vi.fn>;
    exitReviewMode: ReturnType<typeof vi.fn>;
    enterReviewMode: ReturnType<typeof vi.fn>;
  };
  let surveyCommonService: Pick<SurveyCommonService, 'loadAndOpenFolderDialog' | 'openCreateFolderDialog' | 'reopenFolderDialog' | 'createFolderInSelectedLocation'> & { flowType: ReturnType<typeof signal<{ aiflow: boolean }>> };
  let toastService: { InsertToast: ReturnType<typeof vi.fn> };
  let assetManageApiService: { createAssetFolder: ReturnType<typeof vi.fn> };
  let acFetchApiService: { getMyFolders: ReturnType<typeof vi.fn> };

  beforeEach(() => {
    mockTranslateService = createMockTranslateService();
    router = { navigate: vi.fn() };
    activatedRoute = {
      snapshot: {
        paramMap: convertToParamMap({}),
      },
    };
    surveyService = {
      title: signal('Initial title'),
      genState: signal<'idle' | 'loading' | 'done'>('idle'),
      questions: signal<unknown[]>([]),
      updateTitle: vi.fn(),
      saveSurveyDraft: vi.fn().mockReturnValue(of({ data: null })),
      currentAssetIdValue: null,
      surveyIdValue: null,
      setSelectedFolder: vi.fn(),
      getSelectedFolder: vi.fn().mockReturnValue(null),
    };
    reviewModeService = {
      isReviewMode: signal(false),
      isAllChecked: signal(false),
      deleteCheckedQuestions: vi.fn(),
      toggleAllChecked: vi.fn(),
      setAllCardsCollapsed: vi.fn(),
      exitReviewMode: vi.fn(),
      enterReviewMode: vi.fn(),
    };
    surveyCommonService = { flowType: signal({ aiflow: false }), loadAndOpenFolderDialog: vi.fn(), openCreateFolderDialog: vi.fn(), reopenFolderDialog: vi.fn(), createFolderInSelectedLocation: vi.fn() };
    toastService = { InsertToast: vi.fn() };
    assetManageApiService = { createAssetFolder: vi.fn().mockReturnValue(of({})) };
    acFetchApiService = {
      getMyFolders: vi.fn().mockReturnValue(of({ data: { assets: [] } })),
    };

    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: EnvironmentConfig, useValue: {} },
        { provide: Router, useValue: router },
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: SurveyService, useValue: surveyService },
        { provide: ReviewModeService, useValue: reviewModeService },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: ToastService, useValue: toastService },
        { provide: ACFetchApiService, useValue: acFetchApiService },
        { provide: ACAssetManageApiService, useValue: assetManageApiService },
      ],
    });

    const commonService = TestBed.runInInjectionContext(() => new SurveyCommonService());
    surveyCommonService.loadAndOpenFolderDialog = commonService.loadAndOpenFolderDialog.bind(commonService);
    surveyCommonService.openCreateFolderDialog = commonService.openCreateFolderDialog.bind(commonService);
    surveyCommonService.reopenFolderDialog = commonService.reopenFolderDialog.bind(commonService);
    surveyCommonService.createFolderInSelectedLocation = commonService.createFolderInSelectedLocation.bind(commonService);
    component = TestBed.runInInjectionContext(() => new SurveyHeaderComponent());
  });

  it('initializes the title from the survey service', () => {
    TestBed.tick();

    expect(component.surveyTitle).toBe('Initial title');
  });

  it('updates the title when editing is disabled', () => {
    component.surveyTitle = 'Updated title';
    component.enableEdit();

    component.disableEdit();

    expect(component.isEditing).toBe(false);
    expect(surveyService.updateTitle).toHaveBeenCalledWith('Updated title');
  });

  it('shows actions for generated AI flow surveys or existing questions', () => {
    expect(component.showActionButtons()).toBe(false);

    surveyCommonService.flowType.set({ aiflow: true });
    surveyService.genState.set('done');
    expect(component.showActionButtons()).toBe(true);

    surveyCommonService.flowType.set({ aiflow: false });
    surveyService.genState.set('idle');
    surveyService.questions.set([{}]);
    expect(component.showActionButtons()).toBe(true);
  });

  it('loads folders and opens the location dialog before saving', () => {
    const folders = [{ assetId: 'folder-1', title: 'Research' }];
    acFetchApiService.getMyFolders.mockReturnValue(of({ data: { assets: folders } }));
    const dialog = {
      emptyAssetSelection: vi.fn(),
      open: vi.fn(),
    };
    (component as any).saveDraftDialog = dialog;

    component.openSaveDraftDialog();

    expect(acFetchApiService.getMyFolders).toHaveBeenCalledWith(['DISCOVERFOLDER']);
    expect(component.folders()).toEqual([MY_ASSETS_ROOT, ...folders.map(folder => ({ ...folder, parentAsset: MY_ASSETS_ROOT }))]);
    expect(dialog.emptyAssetSelection).toHaveBeenCalledOnce();
    expect(dialog.open).toHaveBeenCalledOnce();
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
  });

  it('reuses the draft folder and proceeds directly to publish confirmation', () => {
    surveyService.getSelectedFolder.mockReturnValue({ folderId: 'folder-1', name: 'Research' });
    component.surveyTitle = 'Survey';
    const publishReady = vi.fn();
    component.publishReady.subscribe(publishReady);

    component.prepareForPublish();

    expect(publishReady).toHaveBeenCalledOnce();
    expect(acFetchApiService.getMyFolders).not.toHaveBeenCalled();
  });

  it('selects a folder before opening publish confirmation for an unsaved survey', () => {
    const dialog = { emptyAssetSelection: vi.fn(), open: vi.fn() };
    (component as any).saveDraftDialog = dialog;
    const publishReady = vi.fn();
    component.publishReady.subscribe(publishReady);

    component.prepareForPublish();
    component.handleLocationSelection({ title: 'Survey', folder: { assetId: 'folder-2', title: 'Insights' } as any });

    expect(dialog.open).toHaveBeenCalledOnce();
    expect(surveyService.setSelectedFolder).toHaveBeenCalledWith({ folderId: 'folder-2', name: 'Insights' });
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
    expect(publishReady).toHaveBeenCalledOnce();
  });

  it.each(['', '   '])('blocks publish confirmation for blank title %j from an existing folder or the folder dialog', title => {
    const publishReady = vi.fn();
    component.publishReady.subscribe(publishReady);
    surveyService.getSelectedFolder.mockReturnValue({ folderId: 'folder-1', name: 'Research' });
    component.surveyTitle = title;

    component.prepareForPublish();
    component.dialogAction.set('PUBLISHED' as any);
    component.handleLocationSelection({ title, folder: { assetId: 'folder-2', title: 'Insights' } });

    expect(publishReady).not.toHaveBeenCalled();
    expect(surveyService.updateTitle).not.toHaveBeenCalled();
    expect(surveyService.setSelectedFolder).not.toHaveBeenCalled();
    expect(toastService.InsertToast).toHaveBeenCalledTimes(2);
    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'error', 'SURVEYMOD_VALIDATION_NAME_REQUIRED_ERROR', expect.objectContaining({ title: 'Error' }),
    );
  });

  it('keeps the save button loading until folders finish loading', () => {
    const foldersResponse = new Subject<any>();
    acFetchApiService.getMyFolders.mockReturnValue(foldersResponse);

    component.openSaveDraftDialog();

    expect(component.isLoadingFolders()).toBe(true);
    component.openSaveDraftDialog();
    expect(acFetchApiService.getMyFolders).toHaveBeenCalledOnce();

    foldersResponse.next({ data: { assets: [] } });
    foldersResponse.complete();

    expect(component.isLoadingFolders()).toBe(false);
  });

  it('stops the folder loader and shows an error when folder loading fails', () => {
    acFetchApiService.getMyFolders.mockReturnValue(
      throwError(() => new Error('Folder request failed')),
    );

    component.openSaveDraftDialog();

    expect(component.isLoadingFolders()).toBe(false);
    expect(toastService.InsertToast).toHaveBeenCalledWith(
      'error',
      'SURVEYMOD_FAILED_TO_LOAD_FOLDERS',
      expect.objectContaining({ containerClass: 'survey-action-toast' }),
    );
  });

  it.each(['', '   ', '\t\n'])('rejects the blank title %j when saving from the folder dialog', title => {
    component.saveAsDraft({ title, folder: { assetId: 'folder-1', title: 'Folder' } });

    expect(toastService.InsertToast).toHaveBeenCalledExactlyOnceWith(
      'error', 'SURVEYMOD_VALIDATION_NAME_REQUIRED_ERROR', expect.objectContaining({ title: 'Error', containerClass: 'survey-action-toast' }),
    );
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
    expect(surveyService.updateTitle).not.toHaveBeenCalled();
    expect(surveyService.setSelectedFolder).not.toHaveBeenCalled();
    expect(component.isSavingDraft()).toBe(false);
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it.each([null, 'asset-1'])('rejects an empty title when directly saving a duplicate or existing asset %s', assetId => {
    surveyService.currentAssetIdValue = assetId;
    surveyService.getSelectedFolder.mockReturnValue({ folderId: 'folder-1', name: 'Research' });
    component.surveyTitle = '   ';

    component.openSaveDraftDialog();

    expect(toastService.InsertToast).toHaveBeenCalledExactlyOnceWith(
      'error', 'SURVEYMOD_VALIDATION_NAME_REQUIRED_ERROR', expect.objectContaining({ title: 'Error' }),
    );
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
    expect(acFetchApiService.getMyFolders).not.toHaveBeenCalled();
    expect(surveyService.currentAssetIdValue).toBe(assetId);
  });

  it('allows saving after a blank title is corrected', () => {
    const folder = { assetId: 'folder-1', title: 'Research' };
    component.saveAsDraft({ title: '', folder });
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();

    component.saveAsDraft({ title: 'Corrected title', folder });

    expect(surveyService.saveSurveyDraft).toHaveBeenCalledExactlyOnceWith('DRAFT', undefined);
    expect(surveyService.updateTitle).toHaveBeenCalledWith('Corrected title');
    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'success', 'SURVEYMOD_DRAFT_SAVED', expect.any(Object),
    );
  });

  it('saves once, stores returned details, and reuses the asset id', () => {
    const details = { surveyId: 'survey-1', assetInfo: { assetId: 'asset-1' } };
    surveyService.saveSurveyDraft.mockReturnValue(of({ data: details }));

    const selection = { title: 'Draft survey', folder: { assetId: 'folder-1', title: 'Folder' } };
    component.saveAsDraft(selection);
    component.saveAsDraft(selection);

    expect(surveyService.surveyIdValue).toBe('survey-1');
    expect(surveyService.currentAssetIdValue).toBe('asset-1');
    expect(component.surveyDetails()).toEqual(details);
    expect(toastService.InsertToast).toHaveBeenCalledWith('success', expect.any(String), expect.objectContaining({ containerClass: 'survey-action-toast' }));

    surveyService.currentAssetIdValue = 'asset-1';
    component.saveAsDraft(selection);
    expect(surveyService.saveSurveyDraft).toHaveBeenLastCalledWith('DRAFT', 'asset-1');
  });

  it.each([
    [{ code: { message: 'Backend message' } }, 'Backend message'],
    [{ errorMessage: 'Direct message' }, 'Direct message'],
    [{}, 'SURVEYMOD_FAILED_DRAFT'],
  ])('shows the appropriate save error', (backendError, expected) => {
    surveyService.saveSurveyDraft.mockReturnValue(throwError(() => ({ error: backendError })));

    component.saveAsDraft({ title: 'Draft survey', folder: { assetId: 'folder-1', title: 'Folder' } });

    expect(toastService.InsertToast).toHaveBeenCalledWith('error', expected, expect.objectContaining({ title: 'Error' }));
    expect(component.isSavingDraft()).toBe(false);
  });

  it('returns early when a draft save is already in progress', () => {
    component.isSavingDraft.set(true);

    component.saveAsDraft({ title: 'Draft survey', folder: { assetId: 'folder-1', title: 'Folder' } });

    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
  });

  it('stores null survey details when response has no data payload', () => {
    surveyService.saveSurveyDraft.mockReturnValue(of({ data: undefined }));

    component.saveAsDraft({ title: 'Draft survey', folder: { assetId: 'folder-1', title: 'Folder' } });

    expect(component.isSavingDraft()).toBe(false);
    expect(toastService.InsertToast).toHaveBeenCalledWith('success', expect.any(String), expect.any(Object));
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('navigates to the survey list page', () => {
    component.navigateToSurveyListPage();

    expect(router.navigate).toHaveBeenCalledWith(['/survey']);
  });

 

  it('reuses the existing survey folder when saving a draft', () => {
    surveyService.getSelectedFolder.mockReturnValue({ folderId: 'folder-1', name: 'Survey' });
    component.surveyTitle = 'Existing survey';
    surveyService.currentAssetIdValue = 'asset-1';

    component.openSaveDraftDialog();

    expect(acFetchApiService.getMyFolders).not.toHaveBeenCalled();
    expect(surveyService.setSelectedFolder).toHaveBeenCalledWith({ folderId: 'folder-1', name: 'Survey' });
    expect(surveyService.saveSurveyDraft).toHaveBeenCalledWith('DRAFT', 'asset-1');
  });


  const attachDialogs = () => {
    const location = {
      close: vi.fn(), open: vi.fn(), emptyAssetSelection: vi.fn(),
      folder: { assetId: 'parent-1', title: 'Parent' }, defaultTitle: 'Edited survey title',
    };
    const create = {
      close: vi.fn(() => surveyCommonService.reopenFolderDialog(
        location as any,
        create as any,
        component.surveyTitle,
        component.folders,
        component.isLoadingFolders,
        component.isSavingDraft,
        component.folderDialogClosed,
      )), open: vi.fn(),
      resetForm: vi.fn(), updateLoader: vi.fn(),
    };
    (component as any).saveDraftDialog = location;
    (component as any).createFolderDialog = create;
    return { location, create };
  };

  it('uses the shared create-folder dialog without submitting the survey', () => {
    const { location, create } = attachDialogs();
    surveyCommonService.openCreateFolderDialog(location as any, create as any);
    expect(location.close).toHaveBeenCalledOnce();
    expect(create.resetForm).toHaveBeenCalledOnce();
    expect(create.updateLoader).toHaveBeenCalledOnce();
    expect(create.open).toHaveBeenCalledOnce();
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
  });

  it('creates in the selected parent and refreshes the folder selector', () => {
    const { location, create } = attachDialogs();
    const folders = [{ assetId: 'new-folder', title: 'New folder' }];
    acFetchApiService.getMyFolders.mockReturnValue(of({ data: { assets: folders } }));
    surveyCommonService.createFolderInSelectedLocation(location as any, create as any, component.folderDialogClosed, { title: 'New folder' });
    expect(assetManageApiService.createAssetFolder).toHaveBeenCalledWith('DISCOVERFOLDER', 'New folder', location.folder);
    expect(create.close).toHaveBeenCalledOnce();
    expect(component.folders()).toEqual([MY_ASSETS_ROOT, ...folders.map(folder => ({ ...folder, parentAsset: MY_ASSETS_ROOT }))]);
    expect(location.open).toHaveBeenCalledOnce();
    expect(location.defaultTitle).toBe('Edited survey title');
    expect(component.isLoadingFolders()).toBe(false);
  });

  it('stops the create loader and ignores late responses after cancellation', () => {
    const { location, create } = attachDialogs();
    const pending = new Subject<any>();
    assetManageApiService.createAssetFolder.mockReturnValue(pending);
    surveyCommonService.createFolderInSelectedLocation(location as any, create as any, component.folderDialogClosed, { title: 'New folder' });
    surveyCommonService.reopenFolderDialog(location as any, create as any, component.surveyTitle, component.folders, component.isLoadingFolders, component.isSavingDraft, component.folderDialogClosed);
    pending.next({});
    expect(create.updateLoader).toHaveBeenCalled();
    expect(create.close).not.toHaveBeenCalled();
    expect(location.open).toHaveBeenCalledOnce();
    expect(component.isLoadingFolders()).toBe(false);
    expect(surveyService.saveSurveyDraft).not.toHaveBeenCalled();
  });

  it('resets the shared create loader on failure so creation can be retried', () => {
    const { create } = attachDialogs();
    assetManageApiService.createAssetFolder.mockReturnValue(throwError(() => new Error('Failed')));
    surveyCommonService.createFolderInSelectedLocation((component as any).saveDraftDialog, create as any, component.folderDialogClosed, { title: 'New folder' });
    expect(create.updateLoader).toHaveBeenCalledOnce();
    expect(create.close).not.toHaveBeenCalled();
    expect(toastService.InsertToast).toHaveBeenCalledWith('error', 'SURVEYMOD_FOLDER_CREATION_FAILED', expect.any(Object));
  });

  it('stops the draft loader on the first response without waiting for completion', () => {
    const pending = new Subject<any>();
    surveyService.saveSurveyDraft.mockReturnValue(pending);
    component.saveAsDraft({ title: 'Survey', folder: { assetId: 'folder-1' } });
    expect(component.isSavingDraft()).toBe(true);
    pending.next({ data: null });
    expect(component.isSavingDraft()).toBe(false);
  });

  it('restores the title when reopening after the shared modal resets its form', () => {
    const { location } = attachDialogs();
    component.surveyTitle = 'Survey';
    location.defaultTitle = '';
    component.openSaveDraftDialog();
    expect(location.defaultTitle).toBe('Survey');
  });

  it('emits toggleAISuggestions when the Optiq feedback button is clicked', () => {
    const toggled = vi.fn();
    component.toggleAISuggestions.subscribe(toggled);

    component.openAISuggestionsDrawer();

    expect(toggled).toHaveBeenCalledOnce();
  });

});
