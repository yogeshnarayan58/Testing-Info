import { TranslateModule } from '@ngx-translate/core';
import { GRID_TEXT } from '../../constants/grid.constants';
import type { QuestionChartContext } from '../../models/question-result';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, OnInit, inject, signal, viewChildren } from '@angular/core';
import { ButtonModule, CardModule, DropDownModule, IconButtonModule, IconModule, ItemModule, MenuModule, SegmentControlModule } from '@nielseniq/athena-core';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { QuestionChartComponent } from '../question-chart/question-chart.component';
import { NgTemplateOutlet } from '@angular/common';
import { SurveyService } from '../../../build-survey/services/survey.service';
import {
  RESULTS_DASHBOARD_CHART_TYPE_OPTIONS,
  RESULTS_DASHBOARD_CHART_TYPE_VALUES,
  RESULTS_DASHBOARD_QUESTIONS,
  RESULTS_DASHBOARD_SEGMENT_OPTIONS,
  RESULTS_DASHBOARD_STAGE_CONFIG,
  RESULTS_DASHBOARD_SUMMARY_BETA_TEXT,
  RESULTS_DASHBOARD_SUMMARY_LEARN_MORE_TEXT,
  SURVEY_RESULTS_DASHBOARD_STAGES,
  type ResultsDashboardChartTypeOption,
} from '../../models/survey-results';
import { QuestionTypes, type QuestionType } from '../../../build-survey/models/build-survey';

@Component({
  selector: 'survey-results-dashboard',
  standalone: true,
  host: {
    '(document:keydown.escape)': 'collapseQuestion()',
  },
  imports: [TranslateModule, QuestionChartComponent, ButtonModule, IconButtonModule, IconModule, CardModule, SegmentControlModule, DropDownModule, MenuModule, ItemModule, NgTemplateOutlet, CdkScrollable],
  templateUrl: './results-dashboard.component.html',
  styleUrl: './results-dashboard.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResultsDashboardComponent implements OnInit {
  readonly gridText = GRID_TEXT;
  readonly QuestionTypes = QuestionTypes;
  private readonly surveyService = inject(SurveyService);
  private readonly cdr = inject(ChangeDetectorRef);
  readonly expandedQuestionId = signal<string | null>(null);
  readonly expandedScaleQuestionIds = signal<ReadonlySet<string>>(new Set());
  readonly openedChartMenuQuestionId = signal<string | null>(null);
  readonly suppressedExpandTooltipId = signal<string | null>(null);
  private readonly questionHeaders = viewChildren<ElementRef<HTMLElement>>('questionHeader');
  readonly surveyTitle = this.surveyService.title;
  readonly averageRating: number = 3;
  readonly chartContextByQuestionId: Record<string, QuestionChartContext> = {};

  // Mock dashboard stage until API-based stage computation is integrated.
  readonly currentStage: string = SURVEY_RESULTS_DASHBOARD_STAGES.noResponses;

  readonly dashboardState = RESULTS_DASHBOARD_STAGE_CONFIG[this.currentStage];
  readonly isPreCompletionStage = this.currentStage !== SURVEY_RESULTS_DASHBOARD_STAGES.complete;
  readonly summaryBetaText = RESULTS_DASHBOARD_SUMMARY_BETA_TEXT;
  readonly summaryLearnMoreText = RESULTS_DASHBOARD_SUMMARY_LEARN_MORE_TEXT;
  questions = [...RESULTS_DASHBOARD_QUESTIONS];
  readonly segmentOptions = RESULTS_DASHBOARD_SEGMENT_OPTIONS;
  readonly chartTypeOptionsByQuestionType = RESULTS_DASHBOARD_CHART_TYPE_OPTIONS;
  readonly chartTypeLabelByValue: Record<string, string> = Object.values(this.chartTypeOptionsByQuestionType)
    .flat()
    .reduce((acc, option) => {
    acc[option.value] = option.label;
    return acc;
  }, {} as Record<string, string>);
  // Keep each question's segment/chart selection independent.
  readonly selectedByQuestionId: Record<string, { segment: string; chartType: string }> = Object.fromEntries(
    this.questions.flatMap((question) => [
      [question.id, this.createControlSelection(this.getChartTypeOptions(question.type))],
      ...(question.subCards ?? []).map((subCard) => [
        subCard.id,
        this.createControlSelection(this.chartTypeOptionsByQuestionType[question.type], RESULTS_DASHBOARD_CHART_TYPE_VALUES.pie),
      ]),
    ])
  ) as Record<string, { segment: string; chartType: string }>;

  // Set up the details for each question chart.
  ngOnInit(): void {
    for (const question of this.questions) {
      this.chartContextByQuestionId[question.id] = {
        surveyId: 'mock-survey', surveyTitle: this.surveyTitle(),
        question: { qid: question.id, title: question.title, type: question.type },
      };
      for (const subCard of question.subCards ?? []) {
        this.chartContextByQuestionId[subCard.id] = {
          ...this.chartContextByQuestionId[question.id],
          question: { qid: subCard.id, title: subCard.title, type: question.type },
        };
      }
    }
  }

  // Update the selected question's percentage/actual display mode.
  onSegmentChange(questionId: string, value: string | null | undefined): void {
    if (!value) {
      return;
    }

    // Segment control emits a string; map it to the allowed segment values.
    const segmentOption = this.segmentOptions.find((option) => option.value === value);
    if (!segmentOption) {
      return;
    }

    this.selectedByQuestionId[questionId].segment = segmentOption.value;
  }

  // Update the chart type for the selected question only.
  onChartTypeChange(questionId: string, chartType: string): void {
    if (!this.getChartTypeOptionsForId(questionId).some((option) => option.value === chartType)) {
      return;
    }

    this.selectedByQuestionId[questionId].chartType = chartType;
  }

  // Return the selected chart's menu index, defaulting to the first option if none matches.
  getSelectedChartTypeIndex(questionId: string, chartOptions: ReadonlyArray<ResultsDashboardChartTypeOption>): number {
    const selectedIndex = chartOptions.findIndex(
      (option) => option.value === this.selectedByQuestionId[questionId].chartType
    );
    return selectedIndex < 0 ? 0 : selectedIndex;
  }

  // Return chart choices for a question bar or a scale subcard.
  getChartTypeOptions(questionType: QuestionType, isScaleSubCard = false): Array<ResultsDashboardChartTypeOption> {
    if (!isScaleSubCard && (questionType === QuestionTypes.SinglePointScale || questionType === QuestionTypes.MultiplePointScale)) {
      return this.chartTypeOptionsByQuestionType[QuestionTypes.StarRating];
    }
    return this.chartTypeOptionsByQuestionType[questionType];
  }

  // Expand or collapse the scale breakdown for a question.
  toggleScaleBreakdown(questionId: string): void {
    this.expandedScaleQuestionIds.update((expandedIds) => {
      const nextExpandedIds = new Set(expandedIds);
      if (nextExpandedIds.has(questionId)) {
        nextExpandedIds.delete(questionId);
      } else {
        nextExpandedIds.add(questionId);
      }
      return nextExpandedIds;
    });
  }

  // Toggle the breakdown only when the report-card chevron is clicked.
  onScaleCardClick(questionId: string, event: MouseEvent): void {
    const target = event.target;
    if (target instanceof Element && target.closest('.card-header > niq-icon')) {
      this.toggleScaleBreakdown(questionId);
    }
  }

  // Check whether a question's scale breakdown is expanded.
  isScaleBreakdownExpanded(questionId: string): boolean {
    return this.expandedScaleQuestionIds().has(questionId);
  }

  // Create default segment and chart selections for a question or subcard.
  private createControlSelection(
    chartOptions: ReadonlyArray<ResultsDashboardChartTypeOption> = [],
    defaultChartType?: string
  ): { segment: string; chartType: string } {
    return {
      segment: this.segmentOptions[0].value,
      chartType: defaultChartType ?? chartOptions[0]?.value ?? '',
    };
  }

  // Resolve the allowed chart choices from a question or subcard ID.
  private getChartTypeOptionsForId(questionId: string): ReadonlyArray<ResultsDashboardChartTypeOption> {
    const question = this.questions.find((item) => item.id === questionId);
    if (question) {
      return this.getChartTypeOptions(question.type);
    }

    const parentScaleQuestion = this.questions.find((item) => item.subCards?.some((subCard) => subCard.id === questionId));
    return parentScaleQuestion ? this.chartTypeOptionsByQuestionType[parentScaleQuestion.type] : [];
  }

  // Track which question or subcard has its chart menu open.
  onChartMenuOpened(questionId: string, isOpen: boolean): void {
    this.openedChartMenuQuestionId.set(isOpen ? questionId : null);
  }

  // Synchronize the dropdown trigger when CDK closes its overlay on scroll.
  closeChartMenuOnScroll(): void {
    if (this.openedChartMenuQuestionId() !== null) {
      this.openedChartMenuQuestionId.set(null);
    }
  }

  // Expand the selected question, or collapse it if already expanded.
  toggleQuestionExpansion(questionId: string): void {
    // The icon moves during expansion; dismiss its tooltip at the old position.
    this.suppressedExpandTooltipId.set(questionId);
    if (this.expandedQuestionId() === questionId) {
      this.collapseQuestion();
      return;
    }

    this.expandedQuestionId.set(questionId);
  }

  // Exit fullscreen on collapse click or Escape and return to the question.
  collapseQuestion(): void {
    const questionId = this.expandedQuestionId();
    if (questionId === null) {
      return;
    }

    this.suppressedExpandTooltipId.set(questionId);
    this.expandedQuestionId.set(null);
    this.scrollToQuestion(questionId);
  }

  // Restore the normal layout before scrolling the question into view.
  private scrollToQuestion(questionId: string): void {
    this.cdr.detectChanges();
    const element = this.questionHeaders().find(
      ({ nativeElement }) => nativeElement.getAttribute('data-test-id') === `survey-results-question-header-${questionId}`
    )?.nativeElement;
    element?.scrollIntoView({ block: 'center' });
  }

}
