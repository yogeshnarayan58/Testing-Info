import { QuestionType, QuestionTypes } from '../../build-survey/models/build-survey';

export const SURVEY_RESULTS_TAB_VALUES = {
    results: 'results',
    surveySpecs: 'survey-specs',
} as const;

export const SURVEY_RESULTS_TABS: ReadonlyArray<{ name: string; value: string }> = [
    { name: 'Results', value: SURVEY_RESULTS_TAB_VALUES.results },
    { name: 'Survey specs', value: SURVEY_RESULTS_TAB_VALUES.surveySpecs },
];

export const SURVEY_OVERVIEW_TEXTS = {
    responses: 'responses.',
    publishedDate: 'Published',
    closedDate: 'Closed',
    targetAudienceTitle: 'Your target audience',
    responseSectionTitle: 'Number of responses',
    credit_content: "4 credits was used for this survey. Remaining Credits : 16",
};

export type ResultsSummaryMetric = {
    id: string;
    label: string;
    value: string;
    ariaLabel: string;
};

export type ResultsSummaryInsight = {
    id: string;
    title: string;
    description: string;
};

export type ResultsQuestion = {
    id: string;
    title: string;
    type: QuestionType;
    subCards?: ReadonlyArray<ResultsQuestionSubCard>;
};

export type ResultsQuestionSubCard = {
    id: string;
    title: string;
};

export const RESULTS_DASHBOARD_SEGMENT_VALUES = {
    percentage: 'percentage',
    actual: 'actual',
} as const;

export const RESULTS_DASHBOARD_SEGMENT_OPTIONS: ReadonlyArray<{ label: string; value: string }> = [
    { label: 'Percentage', value: RESULTS_DASHBOARD_SEGMENT_VALUES.percentage },
    { label: 'Actual', value: RESULTS_DASHBOARD_SEGMENT_VALUES.actual },
];

export const RESULTS_DASHBOARD_CHART_TYPE_VALUES = {
    bar: 'MULTIBAR_HORIZONTAL',
    column: 'MULTIBAR_VERTICAL',
    pie: 'PIE',
    heatmap: 'heatmap'
} as const;

export type ResultsDashboardChartType = (typeof RESULTS_DASHBOARD_CHART_TYPE_VALUES)[keyof typeof RESULTS_DASHBOARD_CHART_TYPE_VALUES];

export type ResultsDashboardChartTypeOption = {
    label: string;
    value: ResultsDashboardChartType;
    iconName: string;
};

const standardChartOptions: Array<ResultsDashboardChartTypeOption> = [
    { label: 'Bar Chart', value: RESULTS_DASHBOARD_CHART_TYPE_VALUES.bar, iconName: 'horizontal-bar' },
    { label: 'Column Chart', value: RESULTS_DASHBOARD_CHART_TYPE_VALUES.column, iconName: 'vertical-bar' },
    { label: 'Pie Chart', value: RESULTS_DASHBOARD_CHART_TYPE_VALUES.pie, iconName: 'pie' }
];

export const RESULTS_DASHBOARD_CHART_TYPE_OPTIONS: Record<QuestionType, Array<ResultsDashboardChartTypeOption>> = {
    [QuestionTypes.SingleChoice]: standardChartOptions,
    [QuestionTypes.MultipleChoice]: standardChartOptions,
    [QuestionTypes.StarRating]: [
        { label: 'Heatmap', value: RESULTS_DASHBOARD_CHART_TYPE_VALUES.heatmap, iconName: 'data-grid-table' }
    ],
    [QuestionTypes.NetPromoterScore]: standardChartOptions,
    [QuestionTypes.SinglePointScale]: standardChartOptions,
    [QuestionTypes.MultiplePointScale]: standardChartOptions,
    [QuestionTypes.Text]: [],
};

export const SURVEY_RESULTS_DASHBOARD_STAGES = {
    noResponses: 'no-responses',
    inProgress: 'in-progress',
    complete: 'complete',
} as const;

export type ResultsDashboardStageConfig = {
    summaryMetrics: ReadonlyArray<ResultsSummaryMetric>;
    summaryInsights: ReadonlyArray<ResultsSummaryInsight>;
    disclaimerText: string | null;
    isActionsDisabled: boolean;
    showAiSummary: boolean;
};

export const RESULTS_DASHBOARD_SUMMARY_METRICS: ReadonlyArray<ResultsSummaryMetric> = [
    {
        id: 'total-responses',
        label: 'Total Responses',
        value: '400/400',
        ariaLabel: 'Total responses',
    },
    {
        id: 'completion-rate',
        label: 'Completion Rate',
        value: '100%',
        ariaLabel: 'Completion rate',
    },
    {
        id: 'estimated-time-left',
        label: 'Estimated time left on survey',
        value: '0 days',
        ariaLabel: 'Estimated time left',
    },
];

export const RESULTS_DASHBOARD_SUMMARY_INSIGHTS: ReadonlyArray<ResultsSummaryInsight> = [
    {
        id: 'brand-preference',
        title: 'Brand Preference',
        description: 'Colgate remains a trusted brand, but loyalty weakens when competitors offer significant savings.',
    },
    {
        id: 'value-assessment',
        title: 'Value Assessment',
        description: 'Respondents are more likely to compare prices across brands before making a purchase.',
    },
    {
        id: 'competitive-pressure',
        title: 'Competitive Pressure',
        description: 'Crest and Oral-B promotions appear to be influencing brand switching behavior.',
    },
];

export const RESULTS_DASHBOARD_SUMMARY_METRICS_NO_RESPONSES: ReadonlyArray<ResultsSummaryMetric> = [
    {
        id: 'total-responses',
        label: 'Total Responses',
        value: '0/400',
        ariaLabel: 'Total responses',
    },
    {
        id: 'completion-rate',
        label: 'Completion Rate',
        value: '0%',
        ariaLabel: 'Completion rate',
    },
    {
        id: 'estimated-time-left',
        label: 'Estimated time left on survey',
        value: '15 days',
        ariaLabel: 'Estimated time left',
    },
];

export const RESULTS_DASHBOARD_SUMMARY_METRICS_IN_PROGRESS: ReadonlyArray<ResultsSummaryMetric> = [
    {
        id: 'total-responses',
        label: 'Total Responses',
        value: '200/400',
        ariaLabel: 'Total responses',
    },
    {
        id: 'completion-rate',
        label: 'Completion Rate',
        value: '45%',
        ariaLabel: 'Completion rate',
    },
    {
        id: 'estimated-time-left',
        label: 'Estimated time left on survey',
        value: '7 days',
        ariaLabel: 'Estimated time left',
    },
];

export const RESULTS_DASHBOARD_INSUFFICIENT_DATA_DISCLAIMER = 'This data is not ready to be used as it could be inaccurate without adequate responses. Please wait until you have more responses.';

export const RESULTS_DASHBOARD_SUMMARY_BETA_TEXT = 'All insights is in beta and can get things wrong.';
export const RESULTS_DASHBOARD_SUMMARY_LEARN_MORE_TEXT = 'Learn more';

export const RESULTS_DASHBOARD_QUESTIONS: ReadonlyArray<ResultsQuestion> = [
    {
        id: 'q_1',
        title: 'What type of Toothbrush do you use?',
        type: QuestionTypes.SingleChoice,
    },
    {
        id: 'q_2',
        title: 'Please rate your level of agreement with the following statements regarding your current toothbrush:',
        type: QuestionTypes.MultiplePointScale,
        subCards: [
            { id: 'q_2_card_1', title: 'First Card' },
            { id: 'q_2_card_2', title: 'Second Card' },
            { id: 'q_2_card_3', title: 'Third Card' },
        ],
    },
    {
        id: 'q_3',
        title: 'Where do you typically purchase your toothbrush?',
        type: QuestionTypes.SingleChoice,
    },
    {
        id: 'q_4',
        title: 'Which toothbrush brand do you use most often?',
        type: QuestionTypes.SingleChoice,
    },
    {
        id: 'q_5',
        title: 'How satisfied are you with your current toothbrush cleaning performance?',
        type: QuestionTypes.StarRating,
    },
    {
        id: 'q_6',
        title: 'How likely are you to switch to a new toothbrush brand in the next 6 months?',
        type: QuestionTypes.SinglePointScale,
        subCards: [
            { id: 'q_6_card_1', title: 'First Card' },
            { id: 'q_6_card_2', title: 'Second Card' },
            { id: 'q_6_card_3', title: 'Third Card' },
        ],
    },
    {
        id: 'q_7',
        title: 'How much are you willing to pay for a toothbrush?',
        type: QuestionTypes.SingleChoice,
    },
    {
        id: 'q_8',
        title: 'Which additional feature would make you upgrade your toothbrush?',
        type: QuestionTypes.MultipleChoice,
    },
    {
        id: 'q_9',
        title: 'How likely are you to recommend your current toothbrush brand to others?',
        type: QuestionTypes.NetPromoterScore,
    },
    {
        id: 'q_10',
        title: 'How likely are you to recommend this toothbrush to a friend or colleague?',
        type: QuestionTypes.NetPromoterScore,
    },
];

export const RESULTS_DASHBOARD_STAGE_CONFIG: Readonly<Record<string, ResultsDashboardStageConfig>> = {
    [SURVEY_RESULTS_DASHBOARD_STAGES.noResponses]: {
        summaryMetrics: RESULTS_DASHBOARD_SUMMARY_METRICS_NO_RESPONSES,
        summaryInsights: [],
        disclaimerText: RESULTS_DASHBOARD_INSUFFICIENT_DATA_DISCLAIMER,
        isActionsDisabled: true,
        showAiSummary: false,
    },
    [SURVEY_RESULTS_DASHBOARD_STAGES.inProgress]: {
        summaryMetrics: RESULTS_DASHBOARD_SUMMARY_METRICS_IN_PROGRESS,
        summaryInsights: [],
        disclaimerText: RESULTS_DASHBOARD_INSUFFICIENT_DATA_DISCLAIMER,
        isActionsDisabled: true,
        showAiSummary: false,
    },
    [SURVEY_RESULTS_DASHBOARD_STAGES.complete]: {
        summaryMetrics: RESULTS_DASHBOARD_SUMMARY_METRICS,
        summaryInsights: RESULTS_DASHBOARD_SUMMARY_INSIGHTS,
        disclaimerText: null,
        isActionsDisabled: false,
        showAiSummary: true,
    },
};