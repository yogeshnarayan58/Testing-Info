﻿import type { ColDef, ColGroupDef } from 'ag-grid-community';
import type { GridResponse, GridCell, GridProperty, GridTooltipValue } from '../models/question-result';

type GridRow = Record<string, GridCell>;
type GridColumn = ColDef<GridRow> | ColGroupDef<GridRow>;

export function getGridHeaderRowCount(response: GridResponse): number {
  if (response.tableConfig.headerRow === false) return 0;
  const headerRowCount = Number(response.tableConfig.numHeaderRows ?? response.objects.attributes?.['columnHeaderCount'] ?? 1);
  return Math.min(Number.isInteger(headerRowCount) && headerRowCount >= 0 ? headerRowCount : 1, response.objects.data.length);
}

function mergeGridProperties(...properties: (GridProperty | undefined)[]): GridProperty {
  return properties.reduce<GridProperty>((mergedProperties, propertyOverrides) => ({
    ...mergedProperties, ...propertyOverrides,
    shade: { ...mergedProperties.shade, ...propertyOverrides?.shade },
    textStyle: {
      ...mergedProperties.textStyle, ...propertyOverrides?.textStyle,
      font: { ...mergedProperties.textStyle?.font, ...propertyOverrides?.textStyle?.font },
    },
  }), {});
}

export function buildGridColumnDefinitions(response: GridResponse): GridColumn[] {
  const { data: gridData, metadata: gridMetadata } = response.objects;
  const tableConfig = response.tableConfig;
  const columnKeys = [...new Set(gridData.flatMap(row => Object.keys(row)))];
  const headerRowCount = getGridHeaderRowCount(response);

  const createColumnDefinition = (columnKey: string, columnIndex: number, headerCell?: GridCell): ColDef<GridRow> => {
    const columnProperties = mergeGridProperties(
      tableConfig.defaultColumnProperty,
      tableConfig.columnProperties?.['x' + columnIndex],
      tableConfig.columnProperties?.[columnKey],
    );
    const isNumericColumn = gridMetadata[columnKey]?.type === 'number' || gridMetadata[columnKey]?.isFact;
    return {
      colId: columnKey,
      headerName: String(headerCell?.cellValue ?? columnKey),
      headerTooltip: String(headerCell?.originalCellValue ?? (gridMetadata[columnKey]?.hoverText || (headerCell?.cellValue ?? columnKey))),
      headerClass: 'grid-header-centered',
      wrapHeaderText: true, autoHeaderHeight: true, wrapText: true, autoHeight: true,
      width: columnProperties.width,
      // Expand columns proportionally to their configured widths to fill the grid.
      flex: tableConfig.mode === 'expand' && !columnProperties.pinnedLeft
        ? (columnProperties.width ?? 160)
        : (columnProperties.width ? undefined : 1),
      pinned: columnProperties.pinnedLeft ? 'left' : undefined,
      sortable: columnProperties.enableSort ?? true,
      filter: columnProperties.enableFilter ?? false,
      resizable: columnProperties.enableColumnResizing ?? true,
      suppressMovable: !(columnProperties.enableColumnMoving ?? false),
      valueGetter: params => params.data?.[columnKey]?.cellValue,
      tooltipValueGetter: (params): GridTooltipValue => {
        const gridCell = params.data?.[columnKey];
        const isMaskedCell = gridCell?.cellValue === '!' || (gridCell?.cellValueMasked && (gridCell.cellValue == null || gridCell.cellValue === ''));
        if (isMaskedCell) {
          const maskReference = gridCell?.maskRefId == null ? undefined : gridMetadata['maskRef']?.maskReference
            ?.find(reference => String(reference.maskRefId) === String(gridCell.maskRefId));
          return {
            value: '!', masked: true, header: String(headerCell?.cellValue ?? columnKey),
            message: maskReference?.maskReasons?.[0]?.message ?? '',
          };
        }
        return { value: gridCell?.altDesc ?? gridCell?.cellValue };
      },
      cellStyle: params => {
        const gridCell = params.data?.[columnKey];
        const cellProperties = gridCell?.styleId ? tableConfig.rowProperties?.[gridCell.styleId] : undefined;
        const resolvedProperties = mergeGridProperties(tableConfig.defaultRowProperty, columnProperties, cellProperties);
        const textStyle = resolvedProperties.textStyle;
        const isBandedRow = tableConfig.bandedRows === true && params.node?.rowIndex != null && params.node.rowIndex % 2 === 1;
        return {
          backgroundColor: cellProperties?.shade?.color ?? (isBandedRow ? resolvedProperties.bandedShade?.color : undefined) ?? resolvedProperties.shade?.color ?? '',
          color: textStyle?.font?.color ?? '', fontSize: textStyle?.font?.size ? textStyle.font.size + 'px' : '',
          fontWeight: textStyle?.bold ? 'bold' : 'normal', fontStyle: textStyle?.italic ? 'italic' : 'normal',
          textDecoration: textStyle?.underline ? 'underline' : 'none',
          textAlign: resolvedProperties.alignment ?? (isNumericColumn ? 'right' : 'left'),
          paddingLeft: gridCell?.indent ? (8 + gridCell.indent * 12) + 'px' : '8px',
        };
      },
      rowSpan: params => {
        const startRowIndex = params.node?.rowIndex;
        if (startRowIndex == null || params.api.isAnyFilterPresent() || params.api.getColumnState().some(column => column.sort)) return 1;
        const previousCell = startRowIndex > 0 ? params.api.getDisplayedRowAtIndex(startRowIndex - 1)?.data?.[columnKey] : undefined;
        if (previousCell?.mergeNextCell && previousCell.cellValue === params.data?.[columnKey]?.cellValue) return 1;
        let rowSpan = 1;
        let currentCell = params.data?.[columnKey];
        while (currentCell?.mergeNextCell) {
          const nextCell = params.api.getDisplayedRowAtIndex(startRowIndex + rowSpan)?.data?.[columnKey];
          if (!nextCell || nextCell.cellValue !== currentCell.cellValue) break;
          rowSpan++;
          currentCell = nextCell;
        }
        return rowSpan;
      },
    };
  };
  if (headerRowCount <= 1) {
    return columnKeys.map((columnKey, columnIndex) => createColumnDefinition(columnKey, columnIndex, headerRowCount ? gridData[0]?.[columnKey] : undefined));
  }

  // Map merged header rows into AG Grid parent/child groups.
  const buildHeaderGroups = (headerRowIndex: number, startColumnIndex: number, endColumnIndex: number): GridColumn[] => {
    if (headerRowIndex === headerRowCount - 1) {
      return columnKeys.slice(startColumnIndex, endColumnIndex).map((columnKey, offset) =>
        createColumnDefinition(columnKey, startColumnIndex + offset, gridData[headerRowIndex]?.[columnKey]));
    }
    const columnDefinitions: GridColumn[] = [];
    for (let columnIndex = startColumnIndex; columnIndex < endColumnIndex;) {
      let lastMergedColumnIndex = columnIndex;
      while (lastMergedColumnIndex + 1 < endColumnIndex && gridData[headerRowIndex]?.[columnKeys[lastMergedColumnIndex]]?.mergeNextCell) lastMergedColumnIndex++;
      const headerCell = gridData[headerRowIndex]?.[columnKeys[lastMergedColumnIndex]] ?? gridData[headerRowIndex]?.[columnKeys[columnIndex]];
      const childColumns = buildHeaderGroups(headerRowIndex + 1, columnIndex, lastMergedColumnIndex + 1);
      if (headerCell?.cellValue == null || headerCell.cellValue === '') columnDefinitions.push(...childColumns);
      else columnDefinitions.push({
        headerName: String(headerCell.cellValue), headerTooltip: String(headerCell.originalCellValue ?? headerCell.cellValue),
        tooltipComponent: 'gridTooltip', wrapHeaderText: true, autoHeaderHeight: true, marryChildren: true, children: childColumns,
      });
      columnIndex = lastMergedColumnIndex + 1;
    }
    return columnDefinitions;
  };
  return buildHeaderGroups(0, 0, columnKeys.length);
}
