import { BasePage } from "@gfk/gta";
import * as configurePanelResources from "./configure-panel-resources.json";
import { CommonTestCase } from "../common-test-case/common-test-case";
import { SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { assert } from "@gfk/gta";

const CONFIGURE_PANEL_COMPONENT = "ConfigurePanel";

interface ConfigOption {
  value: string;
  default: boolean;
}

interface ConfigSection {
  breakdown?: ConfigOption[];
  changeType?: ConfigOption[];
}

export class ConfigurePanel extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(
      CONFIGURE_PANEL_COMPONENT,
      configurePanelResources
    );
  }

  /**
   * Clicks the report card menu button (meatball menu icon)
   */
  public async clickReportCardMenu(): Promise<void> {
    const menuButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("reportCardMenuButton", CONFIGURE_PANEL_COMPONENT)
    );
    try {
      await menuButton.waitFor(SMALL_TIMEOUT);
      await menuButton.click();
    } catch (error: any) {
      throw new Error(`Failed to click report card menu: ${error.message}`);
    }
  }

  /**
   * Opens the configure panel by clicking on the menu and then configure option
   */
  public async openConfigurePanel(): Promise<void> {
    try {
      await this.clickReportCardMenu();

      const configureOption = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("configureOption", CONFIGURE_PANEL_COMPONENT)
      );
      await configureOption.waitFor(SMALL_TIMEOUT);
      await configureOption.click();

      const panelElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("configurePanelContainer", CONFIGURE_PANEL_COMPONENT)
      );
      await panelElement.waitFor(SMALL_TIMEOUT);
    } catch (error: any) {
      throw new Error(`Failed to open configure panel: ${error.message}`);
    }
  }

  /**
   * Validates configure panel sections against assertion data
   * For reports with both Breakdown and Change Type sections
   * @param expectedConfig - Configuration data with optional breakdown and changeType arrays
   */
  public async validateConfigurePanelSections(expectedConfig: ConfigSection): Promise<void> {
    try {
      if (expectedConfig.breakdown) {
        await this.validateBreakdownSection(expectedConfig.breakdown);
      }

      if (expectedConfig.changeType) {
        await this.validateChangeTypeSection(expectedConfig.changeType);
      }
    } catch (error: any) {
      throw new Error(`Failed to validate configure panel sections: ${error.message}`);
    }
  }

  /**
   * Validates Breakdown section radio button options
   * For reports with breakdown configuration (e.g., decomposition types)
   * @param expectedOptions - Array of options with values and default states
   */
  public async validateBreakdownSection(expectedOptions: ConfigOption[]): Promise<void> {
    for (const expectedOption of expectedOptions) {
      const radioButtonSelector = this.resourceManager.getDynamicResource(
        "radioButtonByLabelDynamic",
        expectedOption.value,
        CONFIGURE_PANEL_COMPONENT
      );
      const radioButton = this.webActionHandler.getWebElement(radioButtonSelector);
      
      await radioButton.waitFor();
      const isVisible = await radioButton.isVisible();
      assert(isVisible).toBeTruthy();

      const checkedAttr = await radioButton.getAttribute("checked");
      const isChecked = checkedAttr === "checked";

      assert(isChecked).toBe(expectedOption.default);
    }
  }

  /**
   * Validates Change Type section radio button options
   * For reports with change type configuration (e.g., Actual, Percent)
   * @param expectedOptions - Array of options with values and default states
   */
  public async validateChangeTypeSection(expectedOptions: ConfigOption[]): Promise<void> {
    for (const expectedOption of expectedOptions) {
      const radioButtonSelector = this.resourceManager.getDynamicResource(
        "radioButtonByLabelDynamic",
        expectedOption.value,
        CONFIGURE_PANEL_COMPONENT
      );
      const radioButton = this.webActionHandler.getWebElement(radioButtonSelector);
      
      await radioButton.waitFor();
      const isVisible = await radioButton.isVisible();
      assert(isVisible).toBeTruthy();

      const checkedAttr = await radioButton.getAttribute("checked");
      const isChecked = checkedAttr === "checked";

      assert(isChecked).toBe(expectedOption.default);
    }
  }

  /**
   * Clicks a specific radio button option by label text
   * @param optionLabel - The label text of the option to click
   */
  public async clickOptionByLabel(optionLabel: string): Promise<void> {
    try {
      const radioButton = this.webActionHandler.getWebElement(
        this.resourceManager.getDynamicResource("radioButtonByLabelDynamic", optionLabel, CONFIGURE_PANEL_COMPONENT)
      );
      await radioButton.waitFor(SMALL_TIMEOUT);
      await radioButton.click();
    } catch (error: any) {
      throw new Error(`Failed to click option "${optionLabel}": ${error.message}`);
    }
  }

  /**
   * Validates radio button options with inline values (no assertion data needed)
   * Recommended for simple cases where options are consistent across datasets
   * @param options - Array of option labels (e.g., ["Actual", "Percent"])
   * @param defaultOption - The option that should be selected by default
   * @param sectionName - Section name for logging
   */
  public async validateRadioOptions(options: string[], defaultOption: string, sectionName: string = "Section"): Promise<void> {
    for (const option of options) {
      const radioButtonSelector = this.resourceManager.getDynamicResource(
        "radioButtonByLabelDynamic",
        option,
        CONFIGURE_PANEL_COMPONENT
      );
      const radioButton = this.webActionHandler.getWebElement(radioButtonSelector);
      
      await radioButton.waitFor();
      const isVisible = await radioButton.isVisible();
      assert(isVisible).toBeTruthy();

      const shouldBeChecked = option === defaultOption;
      const checkedAttr = await radioButton.getAttribute("checked");
      const isChecked = checkedAttr === "checked";

      assert(isChecked).toBe(shouldBeChecked);
    }
  }

  /**
   * Applies the configuration by clicking the Apply button
   */
  public async applyConfiguration(): Promise<void> {
    const applyButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("applyButton", CONFIGURE_PANEL_COMPONENT)
    );
    try {
      await applyButton.waitFor(SMALL_TIMEOUT);
      await applyButton.click();
    } catch (error: any) {
      throw new Error(`Failed to apply configuration: ${error.message}`);
    }
  }

  /**
   * Retrieves all chart legends text from the horizontal bar chart
   * @returns Array of legend text values
   */
  public async getChartLegends(): Promise<string[]> {
    try {
      const legends = await this.webActionHandler.getWebElementsText(
        this.resourceManager.getResource("chartLegends", CONFIGURE_PANEL_COMPONENT)
      );
      return legends.map(legend => legend.trim());
    } catch (error: any) {
      throw new Error(`Failed to get chart legends: ${error.message}`);
    }
  }

  /**
   * Validates chart legends against expected values
   * @param expectedLegends - Array of expected legend text values
   */
  public async validateChartLegends(expectedLegends: string[]): Promise<void> {
    try {
      const actualLegends = await this.getChartLegends();

      assert(actualLegends.length).toBe(expectedLegends.length);

      expectedLegends.forEach((expectedLegend) => {
        assert(actualLegends).toContain(expectedLegend);
      });
    } catch (error: any) {
      throw new Error(`Failed to validate chart legends: ${error.message}`);
    }
  }
}
