import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, ViewEncapsulation } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CrfDataSummaryModule } from '@nielsen/crf-data-summary';
import { IconModule } from '@nielseniq/athena-core';
import { type PanelistSummaryState } from '../../../features/build-survey/models/build-survey';

@Component({
  selector: 'survey-details',
  standalone: true,
  imports: [CommonModule, TranslateModule, CrfDataSummaryModule, IconModule],
  templateUrl: './survey-details.component.html',
  styleUrl: './survey-details.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
})
export class SurveyDetailsComponent {
  readonly title = input.required<string>();
  readonly panelistSummary = input<PanelistSummaryState>({});
  readonly questionCount = input.required<number>();
  readonly responseCount = input.required<number>();
  readonly variant = input.required<'publish' | 'overview'>();
  readonly publishedDate = input<string | null>(null);
  readonly closedDate = input<string | null>(null);
  readonly creditsCharged = input<number | null>(null);
  readonly creditsRemaining = input<number | null>(null);

  testId(suffix: string): string {
    return `${this.variant() === 'publish' ? 'publish' : 'survey-overview'}-${suffix}`;
  }
}
