import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import type { GridResponse, QuestionChartPreview } from '../models/question-result';
import { HEAT_GRID_PREVIEW_RESPONSE, NORMAL_GRID_PREVIEW_RESPONSE, SURVEY_CHART_RESPONSES } from '../constants/survey-results-preview';

@Injectable({ providedIn: 'root' })
export class QuestionChartPreviewService {

  // Table data is independent of chart data.
  loadGrid(): Observable<GridResponse> {
    return of(structuredClone(NORMAL_GRID_PREVIEW_RESPONSE.components[0]));
  }

  // Prepare the selected chart with sample data.
  load(selection: string): Observable<QuestionChartPreview> {
    if (selection === 'heatmap') {
      const gridResponse = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
      return of({ configs: [], properties: {}, data: gridResponse.objects.data, metadata: gridResponse.objects.metadata, gridResponse });
    }
    const sample = SURVEY_CHART_RESPONSES[selection];
    const response = sample?.data[0]?.components[0];
    if (!response) {
      return of({ configs: [], properties: {}, data: [], metadata: {} });
    }
    return of(structuredClone({
      configs: response.chartConfigs,
      properties: response.chartProperty,
      data: response.objects.data,
      metadata: response.objects.metadata,
    }));
  }
}
