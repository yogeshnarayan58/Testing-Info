import { assert, BasePage, PageElement} from "@gfk/gta";
import * as reportPageResources from "./report-page-resources.json";
import { CommonTestCase } from "../common-test-case/common-test-case";
import { SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { WebElement } from "@gfk/gta/dist/core/web/webElement";

const REPORTPAGE = "Report Page";

export class ReportPage extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(REPORTPAGE, reportPageResources);
  }

  /**
   * Validates that no data found placeholder is displayed correctly when there is no data.
   * @returns Promise<void>
   */
  public async assertNoDataFound(): Promise<void> {
    try {
      const noDataElement = this.webActionHandler.getWebElement(
        this.resourceManager.getResource("noDataPlaceholder", REPORTPAGE)
      );
      
      const isVisible = await noDataElement.isVisible();
      if (isVisible) {
        console.log("No data element found and visible. No data found validated successfully");
      } else {
        throw new Error("No data found element is not visible on the page");
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`No data found validation failed: ${errorMessage}`);
    }
  }

  // Validates that no data found placeholder is displayed correctly when there is no data.
  public async assertNoDataFoundByParentElement(parentElement: PageElement): Promise<void> {
    try {
      const parentWebElement: WebElement = this.webActionHandler.getWebElement(parentElement);
      const noDataElement = parentWebElement.getWebElement(
        this.resourceManager.getResource("noDataPlaceholder", REPORTPAGE)
      );

      const isVisible = await noDataElement.isVisible();
      if (isVisible) {
        console.log("No data element found and visible. No data found validated successfully");
      } else {
        throw new Error("No data found element is not visible on the page");
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`No data found validation failed: ${errorMessage}`);
    }
  }

  public async getAllFacts(expectedData: any, componentName: string):Promise<string[]>{
  
      try {
        //Open Facts Dropdown
        const factsElement = this.webActionHandler.getWebElement(
          this.resourceManager.getResource("factsInternalDropdown", componentName)
        );
         await factsElement.waitFor();
         await factsElement.click();
  
        
        const factsTexts: string[] = [];
        // Loop through each question and get its text using 0-based indexing
        for (let i = 0; i < expectedData.length; i++) {
          // Use getDynamicResource with index as the dynamic value (i+1 for 1-based CSS nth-child)
          const factsTextElement = this.webActionHandler.getWebElement(
            this.resourceManager.getDynamicResource("factsInternalDropdownOptions", (i+1).toString(), componentName)
          );
          const text = await factsTextElement.getText();
          factsTexts.push(text?.trim() || "");
        }
  
        return factsTexts;
      } catch (error) {
        throw new Error(`Failed to get all facts texts: ${error}`);
      }
  
    }
  
    /**
     * Validate all question texts in the dropdown
     * @param expectedData Array of expected question texts
     * @param componentName Component name for resource lookup
     */
    public async validateAllFacts(expectedData: string[], componentName: string): Promise<void> {
      try {
        // Retrieve exactly as many questions as we have expected values to validate
        const actualFacts = await this.getAllFacts(expectedData, componentName);
        
        // Validate count
        assert(actualFacts.length).toBe(expectedData.length);
        console.log(`Total facts count validated: ${actualFacts.length}`);
  
        // Validate each question text
        for (let i = 0; i < expectedData.length; i++) {
          assert(actualFacts[i]).toBe(expectedData[i]);
          console.log(`Facts ${i + 1} validated: "${actualFacts[i]}"`);
        }
        
      } catch (error) {
        throw new Error(`Failed to validate all facts: ${error}`);
      }
    }
  
   
  
    public async clickDimension(dimension: string, componentName: string): Promise<void> {
      try {
        // Retrieve the web element corresponding to the specified dimension
        const dimensionElement = this.webActionHandler.getWebElement(
          this.resourceManager.getResource(dimension, componentName)
        );     
  
        // Wait until the element is visible and ready for interaction
        await dimensionElement.waitFor();
        // Click the dimension element
        await dimensionElement.click();
      } catch (error) {
        console.error(`Failed to click  dimension`, error);
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(`Error interacting with dimension  ${errorMessage}`);
      }
    }
  
    public async switchToOption(indexnumber: number, dimension: any, componentName: string): Promise<void> {
      try {
        
        const dataItem = this.webActionHandler.getWebElement(
            this.resourceManager.getDynamicResource("factsInternalDropdownOptions", indexnumber.toString(), componentName)
          );
        console.log(`data item${dataItem}.getText()` );
        await dataItem.waitFor();
        await dataItem.click();
        
        // Wait for selection to update
        await this.webActionHandler.delay(SMALL_TIMEOUT);
        
        console.log(`Successfully switched to option ${indexnumber}`);
      } catch (error) {
        throw new Error(`Failed to switch to option ${indexnumber}: ${error}`);
      }
    }
}
