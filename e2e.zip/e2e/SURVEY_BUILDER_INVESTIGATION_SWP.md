# Start with Prompt (AI) — single investigation log

## Audit conclusions still relevant
- Generate Survey screen = `question-generator` (count/types/Generate) + `preview-mode` (Rephrase/Generate more/Describe) + `reprompt-actions`; most controls lacked data-test-id (now added in libs, not yet on DEV).
- UNKNOWN: `investigation.txt`/`swp-codegen-recording.txt`, `niq-slider` drag mechanics, `[data-testid='quick-survey-quick-1']` owning component — not found/vendored in workspace.
- Skipped: "set question count" method + count-validation test — slider's own min/max bounds the same constants, unreachable via UI.

## Pending: switch to data-test-id once DEV has the new build
| Element | DEV selector used now | data-test-id to switch to |
|---|---|---|
| Rephrase with AI button | `.rephrase-action >> nth=${index}` | `rephrase-with-ai-${index}` |
| Rephrase prompt textarea | `.rephrase-input` | `rephrase-input-${index}` |
| Rephrase send button | `.rephrase-send` | `rephrase-send-${index}` |
| Reprompt panel textarea | `.reprompt-input` | `reprompt-input` |
| Reprompt Close/Submit buttons | `role=button[name="Close"/"Submit"]` | `reprompt-close`/`reprompt-submit` |
| Question-count error message | `.question-count-error` | `question-count-error` |

## Plan: Start with Prompt (AI) Flow
- [x] 1. Audit — read page object/locators/spec + Generate Survey screen source; conclusions above.
- [x] 2. AI flow: page object, locators, tests 1-7 (count-validation test.skip'd; generate/rephrase/suggest/describe tests added).
- [ ] 3. Fixes + reuse tests (in progress):
  - [x] Test 8 hover-gate fix (`questionRow` + nth), dynamic→static resource fix, loading/panel-hidden sequencing fix.
  - [x] Test 8 root cause: `isVisible(timeout)` waits for APPEAR not disappear — replaced with `waitFor(...,'hidden')`/`isHidden()`.
  - [x] DEV evidence: rephrase panel does NOT close on success (source says it should) — panel-closed assertion dropped; rule is "DEV behavior over local source when they conflict".
  - [x] `isVisible(0)` hang (Playwright treats timeout 0 as "wait forever") fixed via `isHidden()`; rephrase panel-open click retried once (never when already open); final checks tolerate both DEV post-success states (panel open-empty or gone); every wait/read now has an explicit timeout constant. Same tolerant fix applied to `describeAndSubmitReprompt`.
  - [x] Reuse audit (read-only, see below) completed.
  - [x] Reuse tests added to start-with-prompt.spec.ts (new `SurveyBuilderPage` methods: `openQuestionForEditing`, `saveQuestionChanges`, `editQuestionText`, `getSurveyTitleDisplay`, `getQuestionTextDisplay`): TC_AI_07 title edit, TC_BS_07 Required star, Edit question (pencil), TC_BS_13/14 Review Mode controls, TC_BS_14 Review Mode delete (last).
  - [x] TC_AI_07 fix: `fill()`/`enterText()` never blurs, and title only commits on `(blur)="disableEdit()"` (survey-header.component.ts) — added `commitSurveyTitle()` (presses Tab) and moved TC_AI_07 right after "Generate more questions" (test 7), matching when `addMoreQuestions()` can no longer race the title (no `title` field in its response, unlike initial `generateQuestions()`).
  - [x] TC_BS_07 fix: `requiredToggle`'s `[data-test-id='-input-checkbox']` matches EVERY question identically (shared attribute bug), so it isn't scoped once more than one editor has rendered — added optional `index` (nth-scoped) to `toggleRequired()`, call site now passes 0; no close/cancel method exists in either page object to assert no other editor is open.
  - [ ] Test independence (serial describe, tests 7-10 not isolated from failures), merge Review tests, verify stepper dimensions.
- [ ] 4. Negative tests + new publish UI (publish<3 blocked, cancel-publish dialog, Edit/Review/Publish survey new UI).
- [ ] 5. Remaining sheet cases: empty Build Survey state, min 2 options, cancel add question, duplicate/delete question, drag-drop reorder (Required star now covered above).
- [ ] 6. Cleanup: remove Start-with-Prompt/Start-from-Scratch duplication, rename tests to sheet IDs.

## AI-generated survey reuse audit (read-only)
`build-survey.component.html` is shared by both flows — review-mode, survey-header, preview-mode question-actions, publish-footer are NOT flowType-gated; only question-generator and the AI-only Generate-more/Describe buttons are `aiflow`-only.
- Fully reusable (now implemented as tests): Review Mode (TC_BS_13/14), Required star (TC_BS_07), Edit pencil, TC_AI_07 title edit, TC_AI_01.
- Need new locators/methods (not implemented): TC_BS_06 duplicate/delete click, TC_BS_08/TC_AI_11 AI-only disabled buttons, TC_BS_09 publish-disabled check, TC_BS_15 drag-drop, TC_AI_04 multi-type selection.
- Not possible/confirmed: TC_AI_06 back-to-prompt — no control found in source, flagged UNKNOWN.

## 9-item batch implemented (TC_AI_04/11, TC_BS_01/05/06/09/14-split/15)
All 9 items implemented with source-confirmed locators/methods (deleteQuestionButton `.delete-action`; new SurveyBuilderPage/StartWithPromptPage methods) — no UNKNOWNs, no `test.fixme`. TC_BS_15's drag uses mouseMove/mouseDown/mouseUp steps (CDK drag, confirmed `cdkDrag`/`.drag-handle` in source) but the step/timing physics needed to trigger a reorder are unverified by an actual run — watch for flakiness.

## Part A/B hardening
- Part A: `hover()`/`click()` have no timeout param (webElement.js delegates to Playwright with none, and `playwright.config.ts` sets no `actionTimeout`, so it's unbounded by default) — wrapped each in `withTimeout()` (Promise.race) in `openQuestionForEditing`/`toggleRequired`/`saveQuestionChanges`, errors now include locator+index+step; no locator/logic changed.
- Part B: extracted `closeBrowserAndAttachVideo()` into `base-page-factory.ts`, used by all 3 `describe.serial` specs' `afterAll` (survey-builder, start-with-prompt, start-from-scratch) — same pattern as before, no duplication.
- `isVisible(0)` hang fix: replaced with `isHidden()` in `closeInlineAddEditorIfOpen()` and the publish-toast poll loop (surveyBuilder.page.ts) — `isVisible(0)` waits forever, not an instant check.


## TC_BS_07 root cause (read-only re-check)
`survey-question-editor` is instantiated once per `.question-row` (mode `edit`/`readonly`) PLUS a separate always-`edit`-mode instance in `.inline-add-editor` (Add Question panel) — niq-toggle/`-input-checkbox` only renders in the `edit`-mode branch, so 2 real matches are possible at once (edited row + open add-panel), confirming the shared-selector bug; `toggleRequired(index)` should scope by `.question-row >> nth=${index} .toggle-container [data-test-id='-input-checkbox']` (or equivalent container-scoped selector), not a bare nth on the page-wide attribute. niq-toggle's internal DOM/exact clickable element (host vs inner input) is UNKNOWN — not found in vendored `@nielseniq` package source (likely AOT-compiled, no readable template).

## TC_BS_07 fix applied
State-aware fix: AI-generated questions can start Required ON, so a blind toggle-click could turn it OFF. Added `isRequiredOn`/`waitForRequiredState`/`setRequired(index, desired)` (no-op if already desired, else opens row editor, clicks row-scoped toggle+Save, confirms new state); test now drives true→false→true via `setRequired`+`waitForRequiredState`.

## TC_AI_04 fix applied
`DefaultQuestionTypes` (build-survey.ts) pre-selects SINGLE_CHOICE/MULTIPLE_CHOICE/STAR_RATING, and multi-mode clicks toggle — blindly clicking them deselected all three. Added state-aware `setQuestionTypeSelected(value, desired)` (checks `isQuestionTypeSelected` first, no-op if already desired).
Rewrite: test now verifies real DEV defaults (Single/Multiple Choice, Rating, NPS selected; Point/Multi Scale not), clicks Point Scale (multi-select check), toggles Single Choice off/on, then restores Point Scale to keep Generate's default set intact; marker remains `state="active"` attribute.
TC_AI_04 marked test.fixme — `state="active"` attribute read is unreliable against real DEV default state; needs the actual selected-state DOM marker re-verified.
TC_AI_11/TC_BS_08 reordered to match scratch's TC_BS_MAX_QUESTIONS sequence exactly (tooltip-hover before disabled-state read, same helpers); hang in isDuplicateTooltipVisibleOnHover is UNKNOWN — likely leftover overlay from Describe-questions panel, not a code difference.

## TC_BS_06 finding
`copyQuestion` (preview-mode.component.ts:436) appends `[...questions, duplicatedQuestion]` — copy lands at END of list, not directly below original as sheet expects. Test downgraded to assert 2 matching-text questions exist + sequential renumbering, with a DEFECT? annotation; position check left as TODO pending product confirmation.

## TC_BS_09 fix applied
`getPublishDisabledState` only read the HOST `state` attribute; DEV greys the inner native `<button>` via `disabled` instead. Now checks host aria-disabled/state/disabled-attr/disabled-class OR inner `<button>.disabled`, returning hostOuterHtml/innerButtonOuterHtml/matchCount/innerText for diagnostics (all surfaced in the TC_BS_09 assertion message).

## Reorder (destructive tests last)
Moved TC_BS_09 (deletes to 2) + TC_BS_14 select-all/delete-all + TC_BS_01 (empty state) to the end, after TC_BS_14 select-one/delete/exit (now asserts >=3 remain). No later test depended on the moved tests' prior position — TC_BS_01/TC_BS_14-select-all only need each other's end-state (0 questions), and nothing after them reads question count. TC_BS_06's copy-text match now compares with whitespace stripped (`getQuestionTextDisplay` flakily drops spaces).

## Test 6/7/13 rewrite
Marker confirmed from source: `[state]="... isSelected(...) ? 'active' : 'default'"` (question-type-list.component.html) - no `hoveredType` setter exists, so `state` is reliable; `isQuestionTypeSelected` now returns `{ selected, outerHtml }`. TC_AI_04 rewritten per new spec: all 6 types selected by default, each toggled off/on. Test 6 (slider out-of-range) deleted; TC_AI_11/TC_BS_08 un-skipped as state-only (no hover), reusing `getAddQuestionDisabledState`/`getDuplicateDisabledState`/AI-button helpers (all now return `outerHtml`).
TC_AI_04 DEV correction: `state` attribute never sets on DEV's niq-button; selected marker is the exact "active" CSS class token on the host (outerHTML-confirmed) - `isQuestionTypeSelected` switched to class-token check.

## Edit question text field selector (TC_AI_09?)
Rating leaves data-test-id unset (defaults to "-input"); Choice/NPS/Scale set it explicitly to "question-text-input-<n>" (source-confirmed, no "-input" suffix) - old `$='-input'`-only selector missed those. Fixed via `:is([data-test-id$='-input'], [data-test-id^='question-text-input']):visible >> nth=0` (question-text field is always first editor input in DOM order); `getQuestionTextFieldElement` is private/only used by `editQuestionText`.

## Edit question text field selector fix 2
Wrapper `<niq-text-field data-test-id="question-text-input-1">` also matched `$='-input'` and `fill()` failed on it (not an input); added `input` tag to scope to the real `<input>` (Rating's input has no wrapper-level id to collide, confirmed only text field in its row via source).

## TC_BS_06 copy-match false-zero on long text
`copyIndexes` compared the 60-char-truncated `textsAfter` (used for logging) against the full `originalText`, so >60-char questions never matched; now computed from untruncated `fullTextsAfter`, truncation kept for `console.log` only.

## TC_BS_07 post-max-10 regression
Current (pre-fix) max-10 test was pure attribute reads (no hover/click) - scratch TC_BS_MAX_QUESTIONS ends right after its final count assertion, no cleanup/mouseMove reset. Restored full hover sequence (isAddQuestionTooltipVisibleOnHover → getAddQuestionDisabledState → isDuplicateTooltipVisibleOnHover → getDuplicateDisabledState → count-stays-10) matching scratch exactly; hover/scrollIntoView calls now wrapped in `withTimeout`; added `getHoverDiagnostics()` (row/actions outerHTML, post-hover visibility, elementFromPoint, visible cdk-overlay-pane count, nearest scrollable ancestor) appended to `isDuplicateTooltipVisibleOnHover`/`openQuestionForEditing` failures.

## Edit question (pencil) fix
Root cause: Rating's `niq-text-field` has no `data-test-id` at all (only Choice/NPS/Scale set `question-text-input-<questionNumber>`), so its inner input renders as literal `-input`; `editQuestionText` now matches the common `[data-test-id$='-input']` suffix scoped to `.question-row >> nth=${index} >> survey-question-editor`, working for any question type. `closeInlineAddEditorIfOpen` now uses `isVisible(0)` (instant, element is normally absent) instead of a 5s wait.
