# Pull Request Template

## Overview
<!-- Provide a brief summary of the changes and their purpose -->

## Changes Made
<!-- List the specific changes made in this PR -->
- [ ] Test data structure updates
- [ ] Component refactoring
- [ ] Resource management updates
- [ ] Page object modifications
- [ ] Bug fixes
- [ ] Documentation updates
- [ ] Refactoring / cleanup
- [ ] Workflow YAML changes
- [ ] New spec/test files added

## Testing
<!-- Describe how the changes have been tested -->
- [ ] Tests validated locally

## ✔ What was tested?
- [ ] New tests created
- [ ] Existing tests updated

### Test Coverage
- [ ] Unit tests passing
- [ ] Integration tests passing
- [ ] UI automation tests passing
- [ ] Manual testing completed

### Test Environment
- [ ] DEV environment tested
- [ ] SI environment tested
- [ ] UAT environment tested

## Impact Assessment
<!-- Assess the impact of these changes -->

### Breaking Changes
- [ ] No breaking changes
- [ ] Breaking changes (please describe below)

### Affected Reports
<!-- List any reports that are affected by these changes -->
- [ ] Trade Planner - Key Facts
- [ ] Trade Planner - Loyalty vs Propensity
- [ ] Consumer Trends
- [ ] Consumer Performance Competitive Mapping
- [ ] Other: _______________

## Framework Compliance
<!-- Ensure changes follow OmniShopper framework patterns -->

### Resource Management
- [ ] All selectors defined in JSON resource files
- [ ] No hardcoded selectors in test code
- [ ] ResourceManager used for element access

### Component Architecture
- [ ] Extends CommonTestCase for shared functionality
- [ ] Follows page object model pattern
- [ ] Proper error handling with descriptive messages

### Configuration
- [ ] Environment-specific configs used
- [ ] Timeout constants utilized
- [ ] Test data follows standard pattern

## Documentation
<!-- Check documentation updates -->
- [ ] README updated if needed
- [ ] Code comments added for complex logic
- [ ] API documentation updated if applicable

## Checklist
<!-- Final checklist before submission -->
- [ ] Code follows project coding standards
- [ ] Self-review completed
- [ ] Tests pass locally
- [ ] No merge conflicts
- [ ] Branch is up to date with target branch

## Related Issues
<!-- Link any related issues -->
Closes #
Related to #

## Screenshots/Evidence
<!-- Add any relevant screenshots or evidence of testing -->


## Workflow Integration Checklist

- [ ] All new `*.spec.ts` files are added to relevant GitHub workflows  
- [ ] Scheduler/cron workflows updated if needed  
- [ ] Manual run workflows updated  
- [ ] Test paths include new test files  


## 🎯 Selector & Resource Management Checks

- [ ] No hard‑coded selectors in `.ts` or `.spec.ts` files  
- [ ] All selectors added to JSON resource files  
- [ ] All selectors accessed through `resourceManager.getResource()`  
- [ ] No direct `page.locator()` usage in Page Objects or tests  


## ⚠️ Error Handling Checklist

- [ ] Multi-step actions wrapped in proper `try/catch`  
- [ ] Errors include meaningful context (component, method, selector key)  
- [ ] No swallowed errors  


## 📁 File & Structure Checks

- [ ] Spec files stored under correct folder structure (e.g., `tests/reports`)  
- [ ] Page Objects/components correctly placed under `src/lib/common/pages`
- [ ] Resources placed under `src/lib/common/pages/<ComponentName>.json`   


## 📌 Data & Localization Verification

### #1 — Dataset Validation (Omni, Homescan, Multicountry)
- [ ] Verified **Omni** dataset is available and correctly configured for the report.
- [ ] Verified **Homescan** dataset is available and correctly configured for the report.
- [ ] Verified **Multicountry** dataset is applied (only if the report supports multi‑country flows).
- [ ] Ensured dataset selections align with the report’s requirements and business logic.
- [ ] Confirmed no test runs or UI flows break due to missing dataset bindings.

---

### #2 — Localization File Validation
- [ ] Verified all required **translation texts** have been added to the localization file.
- [ ] Confirmed availability of:
  - **Title** translations
  - **Description** translations
  - **Madlib** translations
  - **pivotMadlib** translations (if used by the report)
- [ ] Checked translations for **all supported locales**.
- [ ] Ensured no missing or placeholder text remains.

## Additional Notes
<!-- Any additional information that reviewers should know -->