import { TestBed } from '@angular/core/testing';
import { ACAssetManageApiService, ACFetchApiService, AssignRightsHelperService } from '@nielsen/crf-lp-common';
import { EMPTY, firstValueFrom, of, throwError } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SurveyGridRow } from '../models/survey-asset.model';
import { SurveyAssetActionsService } from './survey-asset-actions.service';

vi.mock('@nielsen/crf-lp-common', () => ({
  ACAssetManageApiService: class {},
  ACFetchApiService: class {},
  AssignRightsHelperService: class {},
  AssetTypes: { SHARED_FOLDER: 'DISCOVERSHAREDFOLDER', FOLDER: 'DISCOVERFOLDER' },
  PrimarySort: { NAME: 'NAME' },
  SortOrder: { ASC: 'ASC' },
}));

describe('SurveyAssetActionsService', () => {
  let service: SurveyAssetActionsService;
  let fetch: { getMyFolders: ReturnType<typeof vi.fn>; getAssetInfoByAssetId: ReturnType<typeof vi.fn> };
  let manage: { renameAsset: ReturnType<typeof vi.fn>; moveAssets: ReturnType<typeof vi.fn>; editAssets: ReturnType<typeof vi.fn> };
  let inheritParentAndRights: ReturnType<typeof vi.fn>;
  const row: SurveyGridRow = {
    assetId: 'survey-1', assetType: 'DISCOVERSURVEY', title: 'Survey', lastModifiedTimestamp: 0,
  };
  const root = { assetId: 'root', title: 'My assets' };
  const folder = { assetId: 'folder-1', assetType: 'DISCOVERFOLDER', title: 'Folder', rights: [] };
  const freshSurvey = () => ({ ...row, rights: [] });

  beforeEach(() => {
    fetch = {
      getMyFolders: vi.fn().mockReturnValue(of({ data: { assets: [folder] } })),
      getAssetInfoByAssetId: vi.fn().mockReturnValue(of([freshSurvey(), folder])),
    };
    manage = {
      renameAsset: vi.fn().mockReturnValue(of({ success: true })),
      moveAssets: vi.fn().mockReturnValue(of({ success: true })),
      editAssets: vi.fn().mockReturnValue(of({ success: true })),
    };
    inheritParentAndRights = vi.fn().mockReturnValue([{ assetId: row.assetId, parentAsset: { assetId: folder.assetId } }]);
    TestBed.configureTestingModule({
      providers: [
        SurveyAssetActionsService,
        { provide: ACFetchApiService, useValue: fetch },
        { provide: ACAssetManageApiService, useValue: manage },
        { provide: AssignRightsHelperService, useValue: { inheritParentAndRights } },
      ],
    });
    service = TestBed.inject(SurveyAssetActionsService);
  });

  afterEach(() => TestBed.resetTestingModule());

  it('loads the same folder types and alphabetical sort as Landing Page', async () => {
    expect(await firstValueFrom(service.fetchMoveFolders())).toEqual([folder]);
    expect(fetch.getMyFolders).toHaveBeenCalledWith(
      ['DISCOVERSHAREDFOLDER', 'DISCOVERFOLDER'], { primarySort: 'NAME', sortOrder: 'ASC' }, false, false
    );
  });

  it('uses the shared rename API without mutating grid data', async () => {
    await firstValueFrom(service.renameAsset(row.assetId, 'Updated title'));
    expect(manage.renameAsset).toHaveBeenCalledWith(row.assetId, 'Updated title', false);
    expect(row.title).toBe('Survey');
  });

  it('fetches fresh source and destination rights before using the shared inheritance and edit APIs', async () => {
    await firstValueFrom(service.moveAssets([row], folder));
    expect(fetch.getAssetInfoByAssetId).toHaveBeenCalledWith('survey-1,folder-1', {
      userDetails: true, orderManagementDetails: true, displayAllRights: true, parentAsset: true,
    }, false);
    expect(inheritParentAndRights).toHaveBeenCalledWith([freshSurvey()], folder);
    expect(manage.editAssets).toHaveBeenCalledWith(inheritParentAndRights.mock.results[0].value, {}, false, false);
    expect(manage.moveAssets).not.toHaveBeenCalled();
  });

  it('retains live user and COG rights and removes obsolete rights without mutating fetched assets', async () => {
    const user = { userId: 'user-1', availability: 'OWNED', userInfo: {} };
    const cog = { orderManagementType: 'COG', orderManagementInfo: {} };
    const deleted = { userId: 'deleted-user', availability: 'VIEW' };
    const source = { ...row, rights: [user, cog, deleted] };
    const target = { ...folder, assetType: 'DISCOVERSHAREDFOLDER', rights: [user, deleted] };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([target, source]));
    await firstValueFrom(service.moveAssets([row], target));
    expect(inheritParentAndRights).toHaveBeenCalledWith(
      [{ ...source, rights: [user, cog] }], { ...target, rights: [user] }
    );
    expect(source.rights).toEqual([user, cog, deleted]);
    expect(target.rights).toEqual([user, deleted]);
  });

  it('uses the shared parent-removal flow for moves back to My assets', async () => {
    const source = { ...freshSurvey(), parentAsset: { assetId: 'old-folder' } };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([source]));
    await firstValueFrom(service.moveAssets([row], root));
    expect(fetch.getAssetInfoByAssetId.mock.calls[0][0]).toBe('survey-1');
    expect(manage.moveAssets).toHaveBeenCalledWith([source], root, false);
    expect(manage.editAssets).not.toHaveBeenCalled();
  });

  it('moves multiple surveys and omits surveys already in the destination', async () => {
    const secondRow = { ...row, assetId: 'survey-2' };
    const secondSource = { ...secondRow, rights: [] };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([
      { ...freshSurvey(), parentAsset: { assetId: folder.assetId } }, secondSource, folder,
    ]));
    await firstValueFrom(service.moveAssets([row, secondRow], folder));
    expect(inheritParentAndRights).toHaveBeenCalledWith([secondSource], folder);
  });

  it('omits root-level assets from bulk moves to root', async () => {
    const secondRow = { ...row, assetId: 'survey-2' };
    const secondSource = { ...secondRow, parentAsset: { assetId: folder.assetId }, rights: [] };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey(), secondSource]));
    await firstValueFrom(service.moveAssets([row, secondRow], root));
    expect(manage.moveAssets).toHaveBeenCalledWith([secondSource], root, false);
  });

  it.each([
    { rows: [] },
    { rows: Array.from({ length: 21 }, () => row) },
    { rows: [{ ...row, assetType: 'DISCOVERFOLDER' }] },
  ])(
    'rejects unsupported selections before making a request',
    async ({ rows }) => {
      await expect(firstValueFrom(service.moveAssets(rows, folder))).rejects.toThrow('between 1 and 20 surveys');
      expect(fetch.getAssetInfoByAssetId).not.toHaveBeenCalled();
    }
  );

  it('rejects non-folder destinations', async () => {
    await expect(firstValueFrom(service.moveAssets([row], { assetId: 'other', assetType: 'DISCOVERSURVEY' })))
      .rejects.toThrow('valid destination folder');
  });

  it('rejects moves into the current folder or from root to root', async () => {
    fetch.getAssetInfoByAssetId.mockReturnValue(of([{ ...freshSurvey(), parentAsset: { assetId: folder.assetId } }, folder]));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow('already in this location');
    fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey()]));
    await expect(firstValueFrom(service.moveAssets([row], root))).rejects.toThrow('already in this location');
  });

  it('fails explicitly if sources, destinations or access information are missing', async () => {
    for (const assets of [[folder], [freshSurvey()], [row, folder]]) {
      fetch.getAssetInfoByAssetId.mockReturnValue(of(assets));
      await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow();
    }
    expect(manage.editAssets).not.toHaveBeenCalled();
  });

  it.each([
    [{ ...row, rights: [], status: 'TRASHED' }, folder],
    [freshSurvey(), { ...folder, status: 'TRASHED' }],
  ])('rejects stale assets that are no longer eligible for moving', async (source, target) => {
    fetch.getAssetInfoByAssetId.mockReturnValue(of([source, target]));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow('no longer available for moving');
    expect(manage.editAssets).not.toHaveBeenCalled();
  });

  it('propagates lookup and mutation errors instead of reporting success', async () => {
    const error = new Error('Request failed');
    fetch.getAssetInfoByAssetId.mockReturnValueOnce(throwError(() => error));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toBe(error);
    manage.editAssets.mockReturnValueOnce(throwError(() => error));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toBe(error);
    manage.renameAsset.mockReturnValueOnce(throwError(() => error));
    await expect(firstValueFrom(service.renameAsset(row.assetId, 'New title'))).rejects.toBe(error);
  });

  it('treats empty completions as failures, not successful operations', async () => {
    fetch.getMyFolders.mockReturnValue(EMPTY);
    manage.renameAsset.mockReturnValue(EMPTY);
    manage.editAssets.mockReturnValue(EMPTY);
    await expect(firstValueFrom(service.fetchMoveFolders())).rejects.toThrow('did not return a result');
    await expect(firstValueFrom(service.renameAsset(row.assetId, 'New title'))).rejects.toThrow('did not return a result');
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow('did not return a result');
  });
});
