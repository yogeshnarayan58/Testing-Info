import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { of, Subject, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import { QuestionTypes, SURVEY_VALIDATION_STATE } from '../models/build-survey';
import { ReviewModeService } from '../services/review-mode.service';
import { SurveyService } from '../services/survey.service';
import { ValidationService } from '../services/validation.service';
import { BuildSurveyComponent } from './build-survey.component';

vi.mock('../services/survey.service', () => ({
  SurveyService: class {},
}));

vi.mock('@nielsen/crf-data-summary', () => ({
  CrfDataSummaryModule: class {},
}));

vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class ACFetchApiService {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

vi.mock('@nielsen/crf-ui-components', async () => {
  const { NgModule } = await import('@angular/core');
  class DialogsModule {}
  NgModule({})(DialogsModule);
  return {
    DialogsModule,
    SaveACopyComponent: class SaveACopyComponent {},
  };
});

describe('BuildSurveyComponent', () => {
  const createComponent = (initialSurveyId?: string) => {
    const questionTypesSignal = signal<any[]>([]);
    const surveyService = {
      questions: signal<any[]>([]),
      isEditingQuestion: signal(false),
      isGeneratingQuestions: signal(false),
      questionTypes: questionTypesSignal,
      genState: signal<'idle' | 'loading' | 'done'>('idle'),
      generateQuestions: vi.fn(),
      currentSurveyId: initialSurveyId ?? null,
      publishSurvey: vi.fn().mockReturnValue(of({})),
      getQuestions: vi.fn(() => surveyService.questions()),
      setQuestions: vi.fn((questions: any[]) => surveyService.questions.set(questions)),
      setSurveyId: vi.fn(),
      clearCurrentAssetId: vi.fn(),
      setSelectedFolder: vi.fn(),
      setQuestionTypes: vi.fn((types: any[]) => questionTypesSignal.set(types)),
      loadSurveyForDuplicate: vi.fn(),
      clearSurveyId: vi.fn(),
      getDuplicateFromId: vi.fn(),
      setDuplicateFromId: vi.fn(),
      clearDuplicateFromId: vi.fn(),
    };

    const validationService = {
      surveyAIValidationState: signal('readyForValidation'),
      validateSurvey: vi.fn().mockReturnValue(of({ result: [] })),
      normalizeValidatedQuestions: vi.fn((response: { result: any[] }) => response.result),
      countSuggestions: vi.fn((questions: any[], severity: string) =>
        questions.reduce(
          (count, question) => count +
            (question.suggestions?.filter((item: any) => item.severity === severity).length ?? 0),
          0
        )
      ),
      resetValidation: vi.fn(),
    };

    const reviewModeService = {
      isReviewMode: signal(false),
    };

    const surveyCommonService = {
      flowType: vi.fn().mockReturnValue({ aiflow: false, scratch: true }),
      setActiveSurveyStep: vi.fn(),
      setDatasetFooterVisible: vi.fn(),
      getPanelistDimensionalValue: vi.fn().mockReturnValue({
        DEMO: ['Adults'],
        GEO: ['United States'],
        PRD: ['Last 30 days'],
        PRDC: ['Snacks'],
        RTLR: ['All Retailers'],
      }),
      getUserPrompt: vi.fn().mockReturnValue('Create a survey'),
      surveyLoading: signal(false),
      getSelectPanelistUiState: vi.fn().mockReturnValue({ selectedResponses: 400 }),
      getPanelistDataSelectorState: vi.fn().mockReturnValue({
        selections: [{ id: 'PRDC', values: [{ label: 'Snacks' }] }],
        dataPrompts: [{ id: 'PRDC', label: 'Product' }],
        requestInstance: {},
        reportSpec: {},
      }),
    };
    const publishPopup = {
      open: vi.fn(),
    };

    const activatedRoute = {
      snapshot: { paramMap: convertToParamMap(initialSurveyId ? { surveyId: initialSurveyId } : {}) },
      parent: { snapshot: { paramMap: convertToParamMap({}) } },
    };

    const router = { navigate: vi.fn().mockResolvedValue(true) };
    TestBed.configureTestingModule({
      providers: [
        { provide: SurveyService, useValue: surveyService },
        { provide: ValidationService, useValue: validationService },
        { provide: ReviewModeService, useValue: reviewModeService },
        { provide: SurveyCommonService, useValue: surveyCommonService },
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: Router, useValue: router },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new BuildSurveyComponent());
    component.publishPopup = publishPopup as never;
    TestBed.tick();
    return { component, surveyService, validationService, surveyCommonService, publishPopup, router };
  };

  it('syncs local questions and generation state from survey signal', () => {
    const { component, surveyService } = createComponent();

    surveyService.questions.set([{ question: 'Q1', type: QuestionTypes.Text }]);
    TestBed.tick();

    expect(component.questions()).toHaveLength(1);
    expect(surveyService.genState()).toBe('done');

    surveyService.questions.set([]);
    TestBed.tick();

    expect(surveyService.genState()).toBe('idle');
  });

  it('keeps a new empty AI survey idle so the generator remains available', () => {
    const { component, surveyService, surveyCommonService } = createComponent();
    surveyCommonService.flowType.mockReturnValue({ aiflow: true, scratch: false });
    TestBed.tick();

    expect(component.questions()).toEqual([]);
    expect(surveyService.genState()).toBe('idle');
  });

  it('keeps the AI builder active after deleting every question and adding a replacement', () => {
    const { component, surveyService, surveyCommonService, router } = createComponent('draft-survey');
    surveyCommonService.flowType.mockReturnValue({ aiflow: true, scratch: false });
    surveyService.questions.set([{ question: 'Saved question', type: QuestionTypes.SingleChoice }]);
    TestBed.tick();

    surveyService.questions.set([]);
    TestBed.tick();

    expect(component.questions()).toEqual([]);
    expect(surveyService.genState()).toBe('done');
    expect(router.navigate).not.toHaveBeenCalled();

    surveyService.questions.set([{ question: 'Replacement', type: QuestionTypes.MultipleChoice }]);
    TestBed.tick();

    expect(component.questions()[0].question).toBe('Replacement');
    expect(surveyService.genState()).toBe('done');
  });

  it('resets generation state when leaving the builder', () => {
    const { component, surveyService } = createComponent();
    surveyService.genState.set('done');

    component.ngOnDestroy();

    expect(surveyService.genState()).toBe('idle');
  });

  it.each([false, true])('keeps loading state unchanged while generation is loading with AI flow %s', aiflow => {
    const { surveyService, surveyCommonService } = createComponent();
    surveyCommonService.flowType.mockReturnValue({ aiflow, scratch: !aiflow });

    surveyService.genState.set('loading');
    surveyService.questions.set([]);
    TestBed.tick();

    expect(surveyService.genState()).toBe('loading');
  });

  it('builds generation payload and marks success/failure', () => {
    const { component, surveyService, surveyCommonService } = createComponent();
    surveyService.generateQuestions.mockReturnValueOnce(of({ result: [] }));

    component.onGenerateQuestions({ questionCount: 5, questionTypes: [QuestionTypes.Text] });

    expect(surveyService.genState()).toBe('done');
    expect(component.questionTypes()).toEqual([QuestionTypes.Text]);
    expect(surveyService.generateQuestions).toHaveBeenCalledWith({
      prompt: {
        demographic: 'Adults',
        geography: 'United States',
        period: 'Last 30 days',
        product: 'Snacks',
        questionCount: 5,
        questionTypes: [QuestionTypes.Text],
        retailer: 'All Retailers',
        userPrompt: 'Create a survey',
      },
    });

    surveyCommonService.getPanelistDimensionalValue.mockReturnValue({});
    surveyCommonService.getUserPrompt.mockReturnValue('');
    surveyService.generateQuestions.mockReturnValueOnce(throwError(() => new Error('Failed')));

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [] });
    expect(surveyService.genState()).toBe('idle');
  });

  it('navigates back preserving surveyId when present', () => {
    const { component, router, surveyService } = createComponent('survey-42');

    component.goBack();

    expect(router.navigate).toHaveBeenCalledWith(['select-panelist', 'survey-42'], expect.any(Object));
    expect(surveyService.clearCurrentAssetId).toHaveBeenCalledOnce();
    expect(surveyService.setSelectedFolder).toHaveBeenCalledWith(null);
  });

  it('keeps placeholder actions callable', () => {
    const { component } = createComponent();
    // Component uses constructor and effect for initialization, no ngOnInit needed
    expect(component).toBeDefined();
    expect(component.questions).toBeDefined();
  });

  it('loads duplicate survey from survey service', () => {
    const { component, surveyService } = createComponent();
    surveyService.loadSurveyForDuplicate.mockReturnValue(of(undefined));
    surveyService.getDuplicateFromId.mockReturnValue('source-survey');

    component.ngOnInit();

    expect(surveyService.loadSurveyForDuplicate).toHaveBeenCalledWith('source-survey');
    expect(surveyService.clearDuplicateFromId).toHaveBeenCalled();
  });

  it('sets the active survey step when the build page initializes', () => {
    const { component, surveyCommonService } = createComponent();

    component.ngOnInit();

    expect(surveyCommonService.setActiveSurveyStep).toHaveBeenCalledWith('build-survey');
    expect(surveyCommonService.setDatasetFooterVisible).toHaveBeenCalledWith(true);
  });

  it('requests folder preparation before opening the publish confirmation dialog', () => {
    const { component, surveyService, publishPopup } = createComponent();

    expect(() => component.goBack()).not.toThrow();
    component.publish();

    expect(component.publishRequest()).toBe(true);
    expect(publishPopup.open).not.toHaveBeenCalled();
    expect(surveyService.publishSurvey).not.toHaveBeenCalled();
  });

  it('opens confirmation after the publish folder is ready', () => {
    const { component, publishPopup } = createComponent();

    component.openPublishConfirmation();

    expect(publishPopup.open).toHaveBeenCalledOnce();
  });

  it('keeps generation loading until the request completes', () => {
    const { component, surveyService } = createComponent();
    const pending = new Subject<{ result: unknown[] }>();
    surveyService.generateQuestions.mockReturnValue(pending.asObservable());

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [QuestionTypes.Text] });

    expect(surveyService.genState()).toBe('loading');
    expect(component.questionTypes()).toEqual([QuestionTypes.Text]);

    pending.next({ result: [] });
    pending.complete();
    expect(surveyService.genState()).toBe('done');
  });

  it('safely handles publish when the dialog reference is unavailable', () => {
    const { component } = createComponent();
    component.publishPopup = undefined;

    expect(() => component.publish()).not.toThrow();
  });

  it('clears state when loading duplicate survey fails', () => {
    const { component, surveyService } = createComponent('draft-survey');
    surveyService.getDuplicateFromId.mockReturnValue('source-survey');
    const error$ = throwError(() => new Error('Load failed'));
    surveyService.loadSurveyForDuplicate.mockReturnValue(error$);

    component.ngOnInit();
    TestBed.tick();

    expect(surveyService.clearSurveyId).toHaveBeenCalled();
    expect(surveyService.clearCurrentAssetId).toHaveBeenCalled();
    expect(surveyService.genState()).toBe('idle');
  });

  it('clears duplicate ID after successfully loading survey', () => {
    const { component, surveyService } = createComponent('draft-survey');
    surveyService.getDuplicateFromId.mockReturnValue('source-survey');
    surveyService.loadSurveyForDuplicate.mockReturnValue(of(undefined));

    component.ngOnInit();
    TestBed.tick();

    expect(surveyService.clearDuplicateFromId).toHaveBeenCalled();
  });

  it('clears duplicate ID even when loading fails', () => {
    const { component, surveyService } = createComponent('draft-survey');
    surveyService.getDuplicateFromId.mockReturnValue('source-survey');
    const error$ = throwError(() => new Error('Load failed'));
    surveyService.loadSurveyForDuplicate.mockReturnValue(error$);

    component.ngOnInit();
    TestBed.tick();

    expect(surveyService.clearDuplicateFromId).toHaveBeenCalled();
  });

  it('calls ValidationService with the current survey questions', () => {
    const { component, surveyService, validationService } = createComponent();

    component.onValidateSurvey();

    expect(validationService.validateSurvey).toHaveBeenCalledWith(surveyService.getQuestions());
  });

  describe.each([
    SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION,
    SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW,
    SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH,
  ])('primary footer action in state %s', state => {
    const setup = () => {
      const context = createComponent();
      context.validationService.surveyAIValidationState.set(state);
      context.surveyService.questions.set([{}, {}, {}]);
      TestBed.tick();
      return context;
    };

    it('is enabled with enough questions and nothing in progress', () => {
      expect(setup().component.isPrimaryActionDisabled()).toBe(false);
    });

    it('is disabled with fewer than three questions', () => {
      const { component, surveyService } = setup();
      surveyService.questions.set([{}, {}]);
      TestBed.tick();

      expect(component.isPrimaryActionDisabled()).toBe(true);
    });

    it('is disabled while a question is being edited', () => {
      const { component, surveyService } = setup();
      surveyService.isEditingQuestion.set(true);

      expect(component.isPrimaryActionDisabled()).toBe(true);
    });

    it('is disabled while questions are being generated', () => {
      const { component, surveyService } = setup();
      surveyService.isGeneratingQuestions.set(true);

      expect(component.isPrimaryActionDisabled()).toBe(true);
    });
  });

  it.each([
    [SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW, true],
    [SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH, true],
    [SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION, false],
    [SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS, false],
  ])('shows the feedback panel for validation state %s: %s', (state, expected) => {
    const { component, validationService } = createComponent();

    validationService.surveyAIValidationState.set(state);

    expect(component.showFeedbackPanel()).toBe(expected);
  });

  it('opens the feedback panel after validation returns suggestions', () => {
    const { component, validationService } = createComponent();
    validationService.validateSurvey.mockReturnValue(of({
      result: [{ suggestions: [{ severity: 'MANDATORY' }] }],
    }));

    component.onValidateSurvey();

    expect(component.isFeedbackPanelOpen()).toBe(true);
  });

  it('keeps the feedback panel closed when validation returns no suggestions', () => {
    const { component } = createComponent();
    component.isFeedbackPanelOpen.set(true);

    component.onValidateSurvey();

    expect(component.isFeedbackPanelOpen()).toBe(false);
  });

  it('toggles and closes the feedback panel', () => {
    const { component } = createComponent();

    component.toggleFeedbackPanel();
    expect(component.isFeedbackPanelOpen()).toBe(true);

    component.toggleFeedbackPanel();
    expect(component.isFeedbackPanelOpen()).toBe(false);

    component.toggleFeedbackPanel();
    component.closeFeedbackPanel();
    expect(component.isFeedbackPanelOpen()).toBe(false);
  });

  it('handles validation errors gracefully', () => {
    const { component, validationService } = createComponent();
    validationService.validateSurvey.mockReturnValue(throwError(() => new Error('Validation failed')));

    expect(() => component.onValidateSurvey()).not.toThrow();
    expect(validationService.validateSurvey).toHaveBeenCalledOnce();
  });

  it('toggles publishRequest signal', () => {
    const { component } = createComponent();

    expect(component.publishRequest()).toBe(false);

    component.publish();
    expect(component.publishRequest()).toBe(true);

    component.publish();
    expect(component.publishRequest()).toBe(false);
  });

  it('opens publish confirmation dialog', () => {
    const { component, publishPopup } = createComponent();

    component.openPublishConfirmation();

    expect(publishPopup.open).toHaveBeenCalledOnce();
  });

  it('updates surveyAIValidationState to readyForValidation on successful question generation', () => {
    const { component, surveyService, validationService } = createComponent();
    surveyService.generateQuestions.mockReturnValueOnce(of({ result: [] }));

    component.onGenerateQuestions({ questionCount: 5, questionTypes: [QuestionTypes.Text] });
    TestBed.tick();

    expect(validationService.surveyAIValidationState()).toBe('readyForValidation');
  });

  it('resets validation state on generation error', () => {
    const { component, surveyService, validationService } = createComponent();
    surveyService.generateQuestions.mockReturnValueOnce(throwError(() => new Error('Generation failed')));

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [] });
    TestBed.tick();

    expect(validationService.resetValidation).toHaveBeenCalled();
  });

  it('does not navigate when goBack has no survey ID', () => {
    const { component, router } = createComponent();

    component.goBack();

    expect(router.navigate).toHaveBeenCalledWith(['select-panelist'], expect.any(Object));
  });

  it('resets generation state and validation in ngOnDestroy', () => {
    const { component, surveyService, validationService } = createComponent();
    surveyService.genState.set('done');

    component.ngOnDestroy();

    expect(surveyService.genState()).toBe('idle');
    expect(validationService.resetValidation).toHaveBeenCalled();
  });

  it('buildGenerateSurveyPayload constructs correct payload from component state', () => {
    const { component, surveyService } = createComponent();
    surveyService.generateQuestions.mockReturnValueOnce(of({ result: [] }));

    component.onGenerateQuestions({ questionCount: 5, questionTypes: [QuestionTypes.Text] });

    expect(surveyService.generateQuestions).toHaveBeenCalledWith({
      prompt: {
        demographic: 'Adults',
        geography: 'United States',
        period: 'Last 30 days',
        product: 'Snacks',
        questionCount: 5,
        questionTypes: [QuestionTypes.Text],
        retailer: 'All Retailers',
        userPrompt: 'Create a survey',
      },
    });
  });

  it('handles missing panelist dimensional values in payload generation', () => {
    const { component, surveyService, surveyCommonService } = createComponent();
    surveyCommonService.getPanelistDimensionalValue.mockReturnValue({});
    surveyCommonService.getUserPrompt.mockReturnValue('');
    surveyService.generateQuestions.mockReturnValueOnce(of({ result: [] }));

    component.onGenerateQuestions({ questionCount: 3, questionTypes: [QuestionTypes.Text] });

    expect(surveyService.generateQuestions).toHaveBeenCalledWith({
      prompt: {
        demographic: '',
        geography: '',
        period: '',
        product: '',
        questionCount: 3,
        questionTypes: [QuestionTypes.Text],
        retailer: '',
        userPrompt: '',
      },
    });
  });
});
