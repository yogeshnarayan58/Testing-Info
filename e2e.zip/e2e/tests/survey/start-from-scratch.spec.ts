import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory } from '../../utils/base-page-factory';
import { StartFromScratchPage } from '../../page-objects/survey/start-from-scratch.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Start from scratch', () => {
  let basePage: BasePage;
  let surveyPage: StartFromScratchPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async () => {
    if (basePage) {
      await basePage.getWebActions().closeBrowser();
    }
  });

  test('Start from Scratch: Should display the Start from scratch option on the survey home page', { tag: '@LandStartFromScratch' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    surveyPage = new StartFromScratchPage(basePage);

    await surveyPage.navigateToSurvey();

    const isStartFromScratchVisible = await surveyPage.isStartFromScratchVisible();
    assertTrue(isStartFromScratchVisible, '"Start from scratch" option not visible after navigating to survey');

    await surveyPage.clickStartFromScratch();
  });

  test('Dataset Selection: Should select the dataset and confirm the Choose a dataset screen', { tag: '@DatasetSelection' }, async () => {
    await surveyPage.selectProductOffering('');
    const isDatasetSelectionConfirmed = await surveyPage.searchAndSelectDataset(
      datasetConfig.searchTerm,
      String(DATASET_NAME)
    );

    assertTrue(
      isDatasetSelectionConfirmed,
      `Expected "Choose a dataset" confirmation not visible after selecting ${DATASET_NAME}`
    );

    await surveyPage.proceedToNextAfterDatasetSelection();
    await surveyPage.applyEntireDataset();
  });

  test('Panelist Filters: Should enable Search for Panelists after all 5 filters are set', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should enable Proceed to survey builder after selecting a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.clickSearchForPanelists();
    await selectPanelistPage.click250Responses();

    const isProceedToSurveyBuilderVisible = await selectPanelistPage.isProceedToSurveyBuilderVisible();
    assertTrue(isProceedToSurveyBuilderVisible, 'Proceed to survey builder button not visible after selecting 250 responses');
  });

  test('Survey Builder: Should navigate to the Build Survey page after proceeding', { tag: '@ProceedToSurveyBuilder' }, async () => {
    await selectPanelistPage.clickProceedToSurveyBuilder();
    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after proceeding');
  });
});