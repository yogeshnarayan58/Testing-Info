import { Injectable, signal, computed } from '@angular/core';
import { SurveyService } from './survey.service';

@Injectable({
  providedIn: 'root'
})
export class ReviewModeService {
  // State signals
  private readonly expandedStateSignal = signal<boolean>(false);
  private readonly checkedIndicesSignal = signal<Set<number>>(new Set());
  private readonly collapsedIndicesSignal = signal<Set<number>>(new Set());
  private readonly isReviewModeSignal = signal<boolean>(false);

  // Public read-only computed signals
  readonly expandedState = this.expandedStateSignal.asReadonly();
  readonly checkedIndices = this.checkedIndicesSignal.asReadonly();
  readonly collapsedIndices = this.collapsedIndicesSignal.asReadonly();
  readonly isReviewMode = this.isReviewModeSignal.asReadonly();

  readonly isAllChecked = computed(() => {
    const questions = this.surveyService.getQuestions();
    if (questions.length === 0) return false;
    return this.checkedIndices().size === questions.length;
  });

  readonly hasCheckedItems = computed(() => this.checkedIndices().size > 0);

  constructor(private surveyService: SurveyService) { }

  // Bulk Operations
  toggleAllExpanded(): void {
    this.expandedStateSignal.update(state => !state);
  }

  toggleAllChecked(): void {
    const questions = this.surveyService.getQuestions();
    if (this.isAllChecked()) {
      this.checkedIndicesSignal.set(new Set());
    } else {
      this.checkedIndicesSignal.set(new Set(questions.map((_, i) => i)));
    }
  }
  toggleChecked(index: number): void {
    this.checkedIndicesSignal.update(indices => {
      const newSet = new Set(indices);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  }

  isChecked(index: number): boolean {
    return this.checkedIndices().has(index);
  }

  deleteCheckedQuestions(): void {
    const questions = this.surveyService.getQuestions();
    const remainingQuestions = questions.filter((_, index) => !this.isChecked(index));
    this.surveyService.setQuestions(remainingQuestions);
    this.clearChecked();
    if (remainingQuestions.length === 0) {
      this.isReviewModeSignal.set(false);
    }
  }

  clearChecked(): void {
    this.checkedIndicesSignal.set(new Set());
  }

  // Individual collapse tracking
  isCardCollapsed(index: number): boolean {
    return this.collapsedIndices().has(index);
  }

  toggleCardCollapsed(index: number): void {
    this.collapsedIndicesSignal.update(indices => {
      const newSet = new Set(indices);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  }

  setAllCardsCollapsed(collapsed: boolean): void {
    const questions = this.surveyService.getQuestions();
    if (collapsed) {
      this.collapsedIndicesSignal.set(new Set(questions.map((_, i) => i)));
    } else {
      this.collapsedIndicesSignal.set(new Set());
    }
  }
  enterReviewMode(): void {
    this.isReviewModeSignal.set(true);
    // Collapse all cards by default when entering bulk mode
    this.setAllCardsCollapsed(true);
  }

  exitReviewMode(): void {
    this.isReviewModeSignal.set(false);
    this.clearChecked();
  }
}
