import { assert } from '@gfk/gta';

/**
 * Asserts that a boolean visibility/state check result is true.
 * Page objects in this project return booleans from isVisible()-style
 * methods (via GTA's WebElement), not raw Playwright Locators, so this
 * wraps GTA's assert() around that boolean result for shared, consistent
 * use across specs (mirrors Omni Shopper's assert-utils.ts intent).
 *
 * @param result - boolean result from a page object's isX()/isXLoaded() check
 * @param message - optional context shown on assertion failure
 */
export function assertTrue(result: boolean, message?: string): void {
  assert(result).toBeTruthy();
}