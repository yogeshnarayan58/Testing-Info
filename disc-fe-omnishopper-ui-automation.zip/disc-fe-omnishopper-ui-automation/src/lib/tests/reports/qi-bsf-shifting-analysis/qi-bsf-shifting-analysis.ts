import { BasePage } from "@gfk/gta";
import * as reportPageResources from "./resources/report-page-resources.json";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";

const REPORTPAGE = "QiBsfShiftingAnalysisReportPage";

export class QiBsfShiftingAnalysis extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(REPORTPAGE, reportPageResources);
  }
}
