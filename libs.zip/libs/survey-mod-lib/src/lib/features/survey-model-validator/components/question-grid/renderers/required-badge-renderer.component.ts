import { Component } from '@angular/core';
import type { ICellRendererAngularComp } from 'ag-grid-angular';
import type { ICellRendererParams } from 'ag-grid-community';
import type { QuestionRow } from '../question.model';

/**
 * Renders whether a question is required as a small colored badge.
 */
@Component({
  selector: 'survey-required-badge-renderer',
  standalone: true,
  template: `
    @if (isQuestionRow) {
      <span class="required-badge" [class.required]="isRequired">
        {{ isRequired ? 'Required' : 'Optional' }}
      </span>
    }
  `,
  styles: [`
    :host {
      display: flex;
      align-items: center;
      height: 100%;
    }
    .required-badge {
      display: inline-flex;
      align-items: center;
      padding: 3px 10px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 600;
      line-height: 1.4;
      white-space: nowrap;
      background: #f1f5f9;
      color: #64748b;
    }
    .required-badge.required {
      background: #fee2e2;
      color: #b91c1c;
    }
  `],
})
export class RequiredBadgeRendererComponent implements ICellRendererAngularComp {
  isQuestionRow = false;
  isRequired = false;

  agInit(params: ICellRendererParams<QuestionRow>): void {
    this.setState(params);
  }

  refresh(params: ICellRendererParams<QuestionRow>): boolean {
    this.setState(params);
    return true;
  }

  private setState(params: ICellRendererParams<QuestionRow>): void {
    this.isQuestionRow = params.data?.rowType === 'question';
    this.isRequired = !!params.data?.question?.isRequired;
  }
}
