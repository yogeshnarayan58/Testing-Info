import { NO_ERRORS_SCHEMA, signal, Pipe, PipeTransform } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BreakpointObserver } from '@angular/cdk/layout';
import { of } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CommonSidePanelComponent, DEFAULT_SIDE_PANEL_WIDTH } from './common-side-panel.component';
import template from './common-side-panel.component.html?raw';
import { SurveyActionItemsComponent } from '../survey-action-items/survey-action-items.component';
import actionsTemplate from '../survey-action-items/survey-action-items.component.html?raw';

vi.mock('@nielseniq/athena-core', () => ({
  SidePanelModule: class {},
  IconButtonModule: class {},
  ButtonModule: class {},
  LinkModule: class {},
  TooltipModule: class {},
}));

// Mock TranslatePipe
@Pipe({
  name: 'translate',
  pure: false,
  standalone: true
})
class MockTranslatePipe implements PipeTransform {
  transform(value: string): string {
    return value;
  }
}

describe('CommonSidePanelComponent', () => {
  let fixture: ComponentFixture<CommonSidePanelComponent>;
  let host: HTMLElement;
  let open: ReturnType<typeof signal<boolean>>;
  let width: ReturnType<typeof signal<number>>;
  let closeOnOutsideClick: ReturnType<typeof signal<boolean>>;
  let topnav: HTMLElement;
  let surface: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [{ provide: BreakpointObserver, useValue: { observe: () => of({ matches: false }) } }],
    }).overrideComponent(SurveyActionItemsComponent, {
      set: {
        imports: [],
        schemas: [NO_ERRORS_SCHEMA],
        templateUrl: undefined,
        styleUrl: undefined,
        template: actionsTemplate,
      },
    }).overrideComponent(CommonSidePanelComponent, {
      set: {
        imports: [MockTranslatePipe],
        schemas: [NO_ERRORS_SCHEMA],
        templateUrl: undefined,
        styleUrl: undefined,
        styles: [],
        template,
      },
    }).compileComponents();
    fixture = TestBed.createComponent(CommonSidePanelComponent);
    open = signal(false);
    width = signal(DEFAULT_SIDE_PANEL_WIDTH);
    closeOnOutsideClick = signal(true);
    // Vitest does not run Angular's signal-input compiler transform.
    Object.defineProperties(fixture.componentInstance, {
      open: { value: open },
      width: { value: width },
      closeOnOutsideClick: { value: closeOnOutsideClick },
    });
    host = fixture.nativeElement;
    topnav = document.createElement('div');
    topnav.className = 'topnav';
    document.body.prepend(topnav);
    surface = document.createElement('div');
    surface.className = 'survey-side-panel';
    fixture.detectChanges();
    host.querySelector('niq-side-panel')?.append(surface);
    vi.spyOn(topnav, 'getBoundingClientRect').mockReturnValue(new DOMRect(0, 112, 1200, 40));
  });

  afterEach(() => {
    fixture.destroy();
    topnav.remove();
    vi.unstubAllGlobals();
  });

  function render(): void {
    fixture.detectChanges();
    TestBed.tick();
    fixture.detectChanges();
  }

  function openPanel(): void {
    open.set(true);
    render();
  }

  it('does not apply shell alignment while closed', () => {
    expect(host.classList.contains('viewport-height')).toBe(false);
    expect(host.classList.contains('is-open')).toBe(false);
    expect(host.style.getPropertyValue('--panel-width')).toBe(`${DEFAULT_SIDE_PANEL_WIDTH}px`);
  });

  it('applies the measured top edge only after opening with both elements present', () => {
    width.set(400);
    openPanel();

    expect(host.classList.contains('viewport-height')).toBe(true);
    expect(host.classList.contains('is-open')).toBe(true);
    expect(host.style.getPropertyValue('--panel-top')).toBe('112px');
    expect(host.style.getPropertyValue('--panel-width')).toBe('400px');
    expect(topnav.style.paddingRight).toBe('0px');
    expect(surface.getAttribute('style')).toBeNull();
  });

  it.each(['topnav', 'surface', 'both'])('keeps the normal layout when %s is missing', (missing) => {
    if (missing !== 'surface') topnav.remove();
    if (missing !== 'topnav') surface.remove();
    openPanel();

    expect(host.classList.contains('is-open')).toBe(true);
    expect(host.classList.contains('viewport-height')).toBe(false);
    expect(host.style.getPropertyValue('--panel-top')).toBe('');
    expect(topnav.getBoundingClientRect).not.toHaveBeenCalled();
  });

  it('does not use a panel surface belonging to another component', () => {
    surface.remove();
    topnav.append(surface);
    openPanel();
    expect(host.classList.contains('viewport-height')).toBe(false);
  });

  it('clears alignment and reserved space on close, then remeasures on reopen', () => {
    openPanel();
    open.set(false);
    render();

    expect(host.classList.contains('is-open')).toBe(false);
    expect(host.classList.contains('viewport-height')).toBe(false);
    expect(host.style.getPropertyValue('--panel-top')).toBe('');

    vi.mocked(topnav.getBoundingClientRect).mockReturnValue(new DOMRect(0, 84, 1200, 40));
    openPanel();
    expect(host.style.getPropertyValue('--panel-top')).toBe('84px');
  });

  it('clears stale alignment if topnav is absent on the next opening', () => {
    openPanel();
    open.set(false);
    render();
    topnav.remove();
    openPanel();
    expect(host.classList.contains('viewport-height')).toBe(false);
    expect(host.style.getPropertyValue('--panel-top')).toBe('');
  });

  it.each(['close', 'destroy'])('restores shell right padding and priority on %s', (action) => {
    topnav.style.setProperty('padding-right', '25px', 'important');
    topnav.style.paddingLeft = '48px';
    openPanel();
    expect(topnav.style.paddingRight).toBe('0px');
    expect(topnav.style.getPropertyPriority('padding-right')).toBe('important');
    expect(topnav.style.paddingLeft).toBe('48px');
    width.set(400);
    render();
    expect(topnav.style.paddingRight).toBe('0px');
    if (action === 'destroy') {
      fixture.destroy();
    } else {
      open.set(false);
      render();
    }
    expect(topnav.style.paddingRight).toBe('25px');
    expect(topnav.style.getPropertyPriority('padding-right')).toBe('important');
    expect(topnav.style.paddingLeft).toBe('48px');
  });

  it('removes the temporary padding override when the shell originally used stylesheet padding', () => {
    openPanel();
    open.set(false);
    render();
    expect(topnav.style.getPropertyValue('padding-right')).toBe('');
  });

  describe('shell flex width', () => {
    let shell: HTMLElement;

    beforeEach(() => {
      shell = document.createElement('div');
      shell.className = 'fms-content';
      topnav.before(shell);
      shell.append(topnav);
    });

    afterEach(() => {
      fixture.destroy();
      shell.remove();
    });

    it('allows the shell flex item to shrink even without a page header', () => {
      openPanel();
      expect(shell.style.minWidth).toBe('0px');
      expect(topnav.style.paddingRight).toBe('0px');
      width.set(400);
      render();
      expect(shell.style.minWidth).toBe('0px');
    });

    it.each(['close', 'destroy'])('restores shell styles on %s', (action) => {
      shell.style.setProperty('min-width', '900px', 'important');
      shell.style.color = 'red';
      openPanel();
      expect(shell.style.minWidth).toBe('0px');
      if (action === 'destroy') {
        fixture.destroy();
      } else {
        open.set(false);
        render();
      }
      expect(shell.style.minWidth).toBe('900px');
      expect(shell.style.getPropertyPriority('min-width')).toBe('important');
      expect(shell.style.color).toBe('red');
    });

    it('removes the temporary minimum after close and applies it again on reopen', () => {
      openPanel();
      open.set(false);
      render();
      expect(shell.style.minWidth).toBe('');
      openPanel();
      expect(shell.style.minWidth).toBe('0px');
    });

    it('does not modify the shell when the panel surface is missing', () => {
      surface.remove();
      openPanel();
      expect(shell.getAttribute('style')).toBeNull();
    });
  });

  describe('shell page header', () => {
    let header: HTMLElement;

    beforeEach(() => {
      header = document.createElement('div');
      header.className = 'page-header';
      topnav.append(header);
      vi.spyOn(header, 'getBoundingClientRect').mockReturnValue(new DOMRect(48, 112, 1100, 56));
    });

    it('caps the border-box width at the panel left edge and removes the duplicate shell gutter', () => {
      openPanel();

      expect(header.style.maxWidth).toBe(`max(0px, calc(100vw - ${DEFAULT_SIDE_PANEL_WIDTH}px - 48px))`);
      expect(header.style.minWidth).toBe('0px');
      expect(header.style.boxSizing).toBe('border-box');
      expect(topnav.style.paddingRight).toBe('0px');
    });

    it('uses responsive CSS without resize listeners and follows panel width changes', () => {
      const addListener = vi.spyOn(window, 'addEventListener');
      openPanel();
      expect(addListener.mock.calls.some(([event]) => event === 'resize')).toBe(false);
      expect(header.style.maxWidth).toContain('100vw');

      width.set(400);
      render();
      expect(header.style.maxWidth).toBe('max(0px, calc(100vw - 400px - 48px))');
      expect(host.style.getPropertyValue('--panel-width')).toBe('400px');
      expect(host.querySelector<HTMLElement & { panelWidth: number }>('niq-side-panel')?.panelWidth).toBe(400);
    });

    it('does not assign a negative header width on narrow viewports', () => {
      vi.stubGlobal('innerWidth', 280);
      openPanel();
      expect(header.style.maxWidth).toBe(`max(0px, calc(100vw - ${DEFAULT_SIDE_PANEL_WIDTH}px - 48px))`);
    });

    it.each(['close', 'destroy'])('restores original styles and priorities on %s', (action) => {
      header.style.setProperty('max-width', '95%', 'important');
      header.style.setProperty('min-width', '120px', 'important');
      header.style.setProperty('box-sizing', 'content-box');
      header.style.color = 'red';
      openPanel();
      expect(header.style.maxWidth).not.toBe('95%');

      if (action === 'destroy') {
        fixture.destroy();
      } else {
        open.set(false);
        render();
      }
      expect(header.style.maxWidth).toBe('95%');
      expect(header.style.getPropertyPriority('max-width')).toBe('important');
      expect(header.style.minWidth).toBe('120px');
      expect(header.style.getPropertyPriority('min-width')).toBe('important');
      expect(header.style.boxSizing).toBe('content-box');
      expect(header.style.color).toBe('red');

      window.dispatchEvent(new Event('resize'));
      expect(header.style.maxWidth).toBe('95%');
    });

    it('removes temporary styles and does not compound the cap when reopened', () => {
      openPanel();
      const maxWidth = header.style.maxWidth;
      open.set(false);
      render();
      expect(header.style.maxWidth).toBe('');
      expect(header.style.minWidth).toBe('');
      expect(header.style.boxSizing).toBe('');
      openPanel();
      expect(header.style.maxWidth).toBe(maxWidth);
    });

    it('does not modify headers outside the selected topnav', () => {
      header.remove();
      document.body.append(header);
      try {
        openPanel();
        expect(host.classList.contains('viewport-height')).toBe(true);
        expect(header.getAttribute('style')).toBeNull();
      } finally {
        header.remove();
      }
    });

    it('does not modify the header if the panel surface is absent', () => {
      surface.remove();
      openPanel();
      expect(header.getAttribute('style')).toBeNull();
    });
  });

  describe('survey wrapper without a host topnav', () => {
    let wrapper: HTMLElement;
    let stepper: HTMLElement;

    beforeEach(() => {
      topnav.remove();
      wrapper = document.createElement('survey-crf-survey-wrapper');
      stepper = document.createElement('div');
      stepper.className = 'stepper-wrapper';
      wrapper.append(stepper);
      document.body.append(wrapper);
      wrapper.append(host);
      vi.spyOn(wrapper, 'getBoundingClientRect').mockReturnValue(new DOMRect(0, 64, 1200, 700));
    });

    afterEach(() => wrapper.remove());

    it('anchors the panel to the top of the wrapper and clears the stepper', () => {
      stepper.style.paddingRight = '12px';
      openPanel();
      expect(host.classList.contains('viewport-height')).toBe(true);
      expect(host.style.getPropertyValue('--panel-top')).toBe('64px');
      expect(stepper.style.paddingRight).toBe(`${DEFAULT_SIDE_PANEL_WIDTH + 8}px`);

      open.set(false);
      render();
      expect(host.classList.contains('viewport-height')).toBe(false);
      expect(stepper.style.paddingRight).toBe('12px');
    });

    it('anchors without a stepper present', () => {
      stepper.remove();
      openPanel();
      expect(host.style.getPropertyValue('--panel-top')).toBe('64px');
    });

    it('prefers the host topnav when one exists', () => {
      document.body.prepend(topnav);
      openPanel();
      expect(host.style.getPropertyValue('--panel-top')).toBe('112px');
      expect(stepper.getAttribute('style')).toBeNull();
    });
  });

  describe('header', () => {
    const headerImg = (el: HTMLElement) => el.querySelector<HTMLImageElement>('[side-panel-header-center] img');
    const titleText = (el: HTMLElement) =>
      el.querySelector('[side-panel-header-center] > span')?.textContent?.trim();

    // Inputs are replaced before the first render, because the OnPush view does not track a swapped signal.
    const renderHeader = (config?: { imgSrc: string; altText: string }) => {
      const headerFixture = TestBed.createComponent(CommonSidePanelComponent);
      Object.defineProperty(headerFixture.componentInstance, 'headerImgConfig', { value: signal(config) });
      headerFixture.detectChanges();
      return headerFixture;
    };

    it('renders the title without an image by default', () => {
      const headerFixture = renderHeader();

      expect(headerImg(headerFixture.nativeElement)).toBeNull();
      expect(titleText(headerFixture.nativeElement)).toBe('Survey details');
      headerFixture.destroy();
    });

    it('renders the header image with its source and alt text next to the title', () => {
      const headerFixture = renderHeader({ imgSrc: 'assets/images/optiq.svg', altText: 'optiq icon' });
      const el: HTMLElement = headerFixture.nativeElement;

      expect(headerImg(el)?.getAttribute('src')).toBe('assets/images/optiq.svg');
      expect(headerImg(el)?.getAttribute('alt')).toBe('optiq icon');
      expect(titleText(el)).toBe('Survey details');
      headerFixture.destroy();
    });

    it('omits the image when the config has no source', () => {
      const headerFixture = renderHeader({ imgSrc: '', altText: 'optiq icon' });

      expect(headerImg(headerFixture.nativeElement)).toBeNull();
      headerFixture.destroy();
    });
  });

  it('emits close for the Close button but not a second outside-click request', () => {
    openPanel();
    const close = vi.spyOn(fixture.componentInstance.closeRequested, 'emit');
    const button = host.querySelector<HTMLElement>('[data-test-id="survey-side-panel-close"]');
    expect(button).not.toBeNull();
    button?.click();
    expect(close).toHaveBeenCalledExactlyOnceWith();
  });

  it('closes for outside clicks only when open and enabled', () => {
    const close = vi.spyOn(fixture.componentInstance.closeRequested, 'emit');
    document.body.click();
    expect(close).not.toHaveBeenCalled();
    openPanel();
    document.body.click();
    expect(close).toHaveBeenCalledTimes(1);
    closeOnOutsideClick.set(false);
    render();
    document.body.click();
    expect(close).toHaveBeenCalledTimes(1);
  });

  it.each(['during-click', 'after-click'])('keeps toolbar Info open when rendering %s', (timing) => {
    const toolbar = TestBed.createComponent(SurveyActionItemsComponent);
    const info = { id: 'info', label: 'Info', iconName: 'info' };
    const items = [{ id: 'survey-1' }];
    Object.defineProperties(toolbar.componentInstance, {
      selectedItems: { value: signal(items) },
      actions: { value: signal([info]) },
    });
    toolbar.detectChanges();
    document.body.append(toolbar.nativeElement, host);
    const close = vi.spyOn(fixture.componentInstance.closeRequested, 'emit');
    const action = vi.fn(() => {
      open.set(!open());
      if (timing === 'during-click') render();
    });
    toolbar.componentInstance.actionClick.subscribe(action);
    fixture.componentInstance.closeRequested.subscribe(() => open.set(false));
    const trigger = toolbar.nativeElement.querySelector<HTMLElement>('[data-test-id="survey-action-item-info"]');
    expect(trigger).not.toBeNull();
    try {
      trigger?.click();
      render();
      expect(action).toHaveBeenCalledExactlyOnceWith({ actionId: 'info', items });
      expect(open()).toBe(true);
      expect(host.classList.contains('is-open')).toBe(true);
      expect(close).not.toHaveBeenCalled();

      surface.click();
      expect(close).not.toHaveBeenCalled();

      trigger?.click();
      render();
      expect(open()).toBe(false);
      expect(close).not.toHaveBeenCalled();

      trigger?.click();
      render();
      expect(open()).toBe(true);
      document.body.click();
      render();
      expect(close).toHaveBeenCalledTimes(1);
      expect(open()).toBe(false);
      expect(host.classList.contains('is-open')).toBe(false);
    } finally {
      toolbar.destroy();
      toolbar.nativeElement.remove();
      host.remove();
    }
  });
});
