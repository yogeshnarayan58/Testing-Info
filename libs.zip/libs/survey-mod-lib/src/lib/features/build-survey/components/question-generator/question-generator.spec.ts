import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { ADD_MORE_QUESTIONS_DEFAULT_COUNT, MAX_SURVEY_QUESTIONS, type GenerateQuestionsRequest } from '../../models/build-survey';
import { QuestionGeneratorComponent } from './question-generator';

describe('QuestionGeneratorComponent', () => {
  const createComponent = () =>
    TestBed.runInInjectionContext(() => new QuestionGeneratorComponent());

  it('emits the selected options when generation is requested', () => {
    const component = createComponent();
    let request: GenerateQuestionsRequest | undefined;
    component.generate.subscribe(value => request = value);

    component.onGenerateQuestions();

    expect(request).toEqual({
      questionCount: component.questionCount,
      questionTypes: component.selectedQuestionTypes,
    });
  });

  it('uses the updated default question counts', () => {
    const component = createComponent();

    expect(component.questionCount).toBe(5);
    expect(component.maxQuestionCount()).toBe(MAX_SURVEY_QUESTIONS);
  });

  it('does not emit while generating', () => {
    const component = createComponent();
    let emitted = false;
    component.generate.subscribe(() => emitted = true);
    component.isGenerating = (() => true) as typeof component.isGenerating;

    component.onGenerateQuestions();

    expect(emitted).toBe(false);
  });

  it.each([ADD_MORE_QUESTIONS_DEFAULT_COUNT - 1, MAX_SURVEY_QUESTIONS + 1, 1444])('does not emit for an invalid question count of %s', count => {
    const component = createComponent();
    let emitted = false;
    component.generate.subscribe(() => emitted = true);
    component.onQuestionCountChange(count);

    component.onGenerateQuestions();

    expect(component.isQuestionCountOutOfRange()).toBe(true);
    expect(emitted).toBe(false);
  });

  it('clears range validation and resumes generation after correcting an invalid count', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.generate, 'emit');
    component.onQuestionCountChange(1444);
    component.onGenerateQuestions();
    expect(emit).not.toHaveBeenCalled();

    component.onQuestionCountChange(5);
    component.onGenerateQuestions();

    expect(component.isQuestionCountOutOfRange()).toBe(false);
    expect(emit).toHaveBeenCalledExactlyOnceWith({ questionCount: 5, questionTypes: component.selectedQuestionTypes });
  });

  it('accepts the minimum and maximum question counts', () => {
    const component = createComponent();

    component.onQuestionCountChange(3);
    expect(component.isQuestionCountOutOfRange()).toBe(false);

    component.onQuestionCountChange(MAX_SURVEY_QUESTIONS);
    expect(component.isQuestionCountOutOfRange()).toBe(false);
  });
});
