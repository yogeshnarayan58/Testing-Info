import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { findDataSetByName, getDimensionSelectionsByPivot, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Frequency";
if (reportTestData && hasPivotInDimensionSelections(reportTestData, pivot)) {
  test.describe.serial(
    "Consumer Distribution Analysis - Frequency Pivot",
    { tag: ["@Report_E2E_Flow"] },
    async () => {
    test(
      "Validate run report",
      {
        tag: "@RunReport",
      },
      async () => {
        let commonTestCase: CommonTestCase;
         test.setTimeout(RUN_TEST_TIMEOUT);
        let basePage = await BasePageFactory.createBasePage();
        let dataSelector = new DataSelector(basePage);
        await dataSelector.navigateToUrl(reportUrl);
        await dataSelector.switchPivotDropdown(pivot);
        await dataSelector.clickAdditionalPromptEllipsisIcon();

        // Get Frequency pivot data
        const frequencyData = getDimensionSelectionsByPivot(pivot, reportTestData);

        await dataSelector.clickMadlibDimension("Product Universe");
        await dataSelector.setMadlibSelection(
          frequencyData["Product Universe"]
        );
        await dataSelector.clickMadlibDimension("Products");
        await dataSelector.setMadlibSelection(
          frequencyData["Products"]
        );
        await dataSelector.waitForMadlibStability();
        await dataSelector.clickMadlibDimension("Retailers");
        await dataSelector.setMadlibSelection(
          frequencyData["Retailers"]
        );
        await dataSelector.clickMadlibDimension("Period");
        await dataSelector.setPeriodMadlibSelection(
            frequencyData["Period"]
          );
        await dataSelector.clickMadlibDimension("Facts");
        await dataSelector.assertFactsDropdown(
          reportAssertData["dataSummary"]["facts"]["factList"]
        );
        await dataSelector.selectClosedDropdown(
          frequencyData["Facts"]["selections"]
        );
        await dataSelector.clickMadlibDimension("Geography");
        await dataSelector.setMadlibSelection(
          frequencyData["Geography"]
        );

        await dataSelector.clickMadlibDimension("Demography");
        await dataSelector.setMadlibSelection(
          frequencyData["Demography"]
        );

        // Configure Range (no volumetric type)
        const rangeConfig = frequencyData["Range"];
        await dataSelector.clickMadlibDimension("Range");
        await dataSelector.clickMadlibDimension("defineNewRangeButton");

        await dataSelector.configureRange(
          undefined,                      // Frequency pivot doesn't have volumetric dropdown
          rangeConfig.minValue,           // Min value
          rangeConfig.maxValue,           // Max value
          rangeConfig.incrementValue      // Increment value
        );

        // await dataSelector.clickMadlibDimension("People");
        // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
        // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
        let dsBasePage = await dataSelector.getBasePage();
               commonTestCase = new CommonTestCase(dsBasePage);
               await commonTestCase.clickRunButton();
               await commonTestCase.waitForReportRunCompletion();
               console.log("run complete in spec");
               const { newReportTitle, newUrl } =
                 await commonTestCase.saveReport();
               savedReportTitle = newReportTitle;
               savedReportUrl = newUrl;
               console.log("savedReportTitle:", savedReportTitle);
               console.log("savedReportUrl:", savedReportUrl);
               }
             );
       
             test("openCurrentReportFMS", { tag: "@openCurrentReportFMS" }, async () => {
               test.skip(!savedReportTitle, "Skipping FMS test - Report not generated. Run with @RunReport first");
       
               let basePage = await BasePageFactory.createBasePage();
               let findMyStuff = new FindMyStuff(basePage);
               await findMyStuff.navigateToUrl(config.BASE_URL);
       
               await findMyStuff.openCurrentReportFMS(savedReportTitle);
       
               console.log("Open current report from FMS - Report visible in UI");
             });
           }
         );
       } 
