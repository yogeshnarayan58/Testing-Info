/**
 * Feature-toggle (FMS) page object: reads and turns on the "Enable Survey Modernization in FMS" toggle
 * on the report/featuretoggle page. Used from login so the modernized survey UI is available to the tests.
 */
import { BasePage } from '@gfk/gta';
import { CommonPage } from './common-page';
import featureTogglePageResources from '../../locators/survey/feature-toggle.locator.json';
import { envConfig } from '../../config/env.config';
import { MEDIUM_TIMEOUT, NAVIGATION_TIMEOUT, SMALL_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';

const FEATURE_TOGGLE_PAGE_COMPONENT_NAME = 'featureTogglePage';
const FEATURE_TOGGLE_RELATIVE_PATH = 'report/featuretoggle';

export const SURVEY_MODERNIZATION_FMS_TOGGLE_NAME = 'Enable Survey Modernization in FMS';

export class FeatureTogglePage extends CommonPage {
  protected readonly componentName = FEATURE_TOGGLE_PAGE_COMPONENT_NAME;

  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(FEATURE_TOGGLE_PAGE_COMPONENT_NAME, featureTogglePageResources);
  }

  async openFeatureTogglePage(baseURL: string = envConfig.BASE_URL): Promise<void> {
    try {
      await this.navigateToUrl(this.buildUrl(baseURL, FEATURE_TOGGLE_RELATIVE_PATH));
      const row = this.webActionHandler.getWebElement(this.getResource('surveyModernizationFmsRow'));
      await this.waitUntilVisible(row, `FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" row`, NAVIGATION_TIMEOUT);
    } catch (error) {
      throw new Error(`Failed to open the feature toggle page: ${error instanceof Error ? error.message : error}`);
    }
  }

  /** The switch input exposes its state through aria-checked ("true" = on). */
  async isSurveyModernizationFmsEnabled(): Promise<boolean> {
    try {
      const toggle = this.webActionHandler.getWebElement(this.getResource('surveyModernizationFmsSwitch'));
      return (await toggle.getAttribute('aria-checked')) === 'true';
    } catch (error) {
      throw new Error(
        `Failed to read FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" state: ${error instanceof Error ? error.message : error}`
      );
    }
  }

  private async waitForSurveyModernizationFmsOn(): Promise<boolean> {
    const deadline = Date.now() + MEDIUM_TIMEOUT;
    do {
      if (await this.isSurveyModernizationFmsEnabled()) {
        return true;
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } while (Date.now() < deadline);
    return false;
  }

  /** Idempotent: turns the toggle ON when it is OFF and never turns it off. */
  async enableSurveyModernizationInFms(baseURL: string = envConfig.BASE_URL): Promise<void> {
    await this.openFeatureTogglePage(baseURL);

    if (await this.isSurveyModernizationFmsEnabled()) {
      console.log(`FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" is already ON, nothing to do`);
      return;
    }

    const nativePage = (BasePage as any).page as import('playwright').Page; // a click with a short timeout is not exposed by the GTA wrapper
    const switchResource = this.getResource('surveyModernizationFmsSwitch');
    try {
      await nativePage.locator(switchResource.selectorValue).click({ timeout: SMALL_TIMEOUT });
    } catch {
      // The input has opacity 0 and the label covers it, so click the parent label instead.
      const label = this.webActionHandler.getWebElement(this.getResource('surveyModernizationFmsSwitchLabel'));
      await this.waitUntilVisible(label, `FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" switch label`);
      await label.click();
    }

    if (!(await this.waitForSurveyModernizationFmsOn())) {
      throw new Error(`FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" did not turn ON (aria-checked is not "true")`);
    }

    await nativePage.reload({ waitUntil: 'domcontentloaded', timeout: NAVIGATION_TIMEOUT });
    const row = this.webActionHandler.getWebElement(this.getResource('surveyModernizationFmsRow'));
    await this.waitUntilVisible(row, `FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" row after reload`, NAVIGATION_TIMEOUT);
    if (!(await this.isSurveyModernizationFmsEnabled())) {
      throw new Error(`FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" was not ON after reload`);
    }

    console.log(`FMS toggle "${SURVEY_MODERNIZATION_FMS_TOGGLE_NAME}" was OFF, turned ON successfully`);
  }
}
