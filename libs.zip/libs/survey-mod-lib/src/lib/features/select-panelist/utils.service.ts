import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class SelectPanelistUtilsService {
  constructor() { }

  /**
   * Validates if a fact or value exists in the dataset response grid.
   * Compares filter values from payload against both id and value fields in the grid response.
   * 
   * @param payload - The request payload containing filter values to check
   * @param response - The response object containing the grid data to search against
   * @returns true if any payload value matches a grid id or value; false otherwise
   */
  checkFactInDataset(payload: any, response: any): boolean {
    const payloadValues = payload?.filter?.values || [];
    const grid = response?.grid || [];
    const responseValues = grid.flat().flatMap((item: any) => [
      item.id,
      item.value
    ]);
    return payloadValues.some((value: string) =>
      responseValues.includes(value)
    );
  }

  /**
   * Formats a timestamp to a human-readable date string.
   * Returns 'today' if the timestamp is from today's date, otherwise returns formatted date in 'MMM d, y' format (e.g., 'Jan 1, 2026').
   * 
   * @param value - The timestamp value in milliseconds (coerced to number via multiplication by 1)
   * @returns Formatted date string: 'today' for current date, or 'MMM d, y' format for other dates; null if value is null/undefined
   */
  refreshedOnDate(value: any): string | null {
    const datePipe = new DatePipe('en-US');
    const valueTimestamp = value * 1;
    const today = new Date();
    return datePipe.transform(valueTimestamp, 'yyyyMMdd') === datePipe.transform(today, 'yyyyMMdd')
      ? 'today'
      : datePipe.transform(valueTimestamp, 'mediumDate');
  }

  /**
   * Calculates the next polling delay with random jitter for exponential backoff.
   * Uses crypto API to generate a secure random value, multiplied by the default delay period.
   * 
   * @param defaultDelayPeriod - Base delay period in milliseconds (default: 1200ms)
   * @returns Next delay value with jitter, between defaultDelayPeriod and defaultDelayPeriod * 2
   */
  getNextDelay(defaultDelayPeriod: number = 1200): number {
    const array = new Uint32Array(1);
    window.crypto.getRandomValues(array);
    const randomNumber = array[0] / (0xffffffff + 1);
    return randomNumber * defaultDelayPeriod + defaultDelayPeriod;
  }
}
