import { ElementRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { RatingEditorComponent } from './rating-editor.component';

describe('RatingEditorComponent', () => {
  const createComponent = () => TestBed.runInInjectionContext(() =>
    new RatingEditorComponent(new ElementRef(document.createElement('div'))),
  );

  it('updates the question and emits on text input', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onInputChange('Rate this product');

    expect(component.question()).toBe('Rate this product');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('converts numeric input to text', () => {
    const component = createComponent();

    component.onInputChange(5);

    expect(component.question()).toBe('5');
  });

  it('clears the question for null input', () => {
    const component = createComponent();
    component.question.set('Existing rating question');

    component.onInputChange(null as unknown as string);

    expect(component.question()).toBe('');
  });

  it('updates required state from the toggle', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: true } } as unknown as Event);

    expect(component.isRequired()).toBe(true);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('defaults required state to false when toggle data is missing', () => {
    const component = createComponent();
    component.isRequired.set(true);

    component.toggleChange({ target: {} } as unknown as Event);

    expect(component.isRequired()).toBe(false);
  });
});
