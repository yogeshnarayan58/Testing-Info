import { SHARED_SURVEY_ACCESS_AVAILABILITIES, SURVEY_ACCESS_AVAILABILITY } from './survey-status.constant';

export const MY_ASSETS_TABS = {
  MY_ASSETS: 'my-assets',
  RECENT: 'recent',
  SHARED_WITH_ME: 'shared-with-me',
  MY_FAVORITES: 'my-favorites',
  TRASH: 'trash',
} as const;

export const MY_ASSETS_GRID_PAGE_SIZE = 100;

export const LAST_UPDATED_MINUTES_THRESHOLD = 59;
export const REFRESH_BUTTON_HIDE_MS = 10000;

export const ASSET_AVAILABILITY = {
  OWNED: [SURVEY_ACCESS_AVAILABILITY.OWNED],
  SHARED: SHARED_SURVEY_ACCESS_AVAILABILITIES,
  SHARED_AND_OWNED: [...SHARED_SURVEY_ACCESS_AVAILABILITIES, SURVEY_ACCESS_AVAILABILITY.OWNED],
} as const;

export const ASSET_TYPE = {
  DISCOVERSURVEY: 'DISCOVERSURVEY',
  DISCOVERFOLDER: 'DISCOVERFOLDER',
  DISCOVERSHAREDFOLDER: 'DISCOVERSHAREDFOLDER'
}

export const EMPTY_VALUE_PLACEHOLDER = '--';

export type MyAssetsTabId = (typeof MY_ASSETS_TABS)[keyof typeof MY_ASSETS_TABS];

export function getAssetCatalogCacheTag(tab: MyAssetsTabId, folderId: string | null = null): string {
  return `my-assets:${tab}:${folderId ?? 'root'}`;
}

/** Folder breadcrumbs are supported on these tabs; Recent and Favorites stay flat. */
export const MY_ASSETS_FOLDER_BREADCRUMB_TABS: readonly MyAssetsTabId[] = [
  MY_ASSETS_TABS.MY_ASSETS,
  MY_ASSETS_TABS.SHARED_WITH_ME,
  MY_ASSETS_TABS.TRASH,
];

export interface MyAssetsTab {
  id: MyAssetsTabId;
  label: string;
  routePath: string;
}

export const MY_ASSETS_TABS_LIST: readonly MyAssetsTab[] = [
  { id: MY_ASSETS_TABS.MY_ASSETS, label: 'My assets', routePath: MY_ASSETS_TABS.MY_ASSETS },
  { id: MY_ASSETS_TABS.RECENT, label: 'Recently opened', routePath: MY_ASSETS_TABS.RECENT },
  { id: MY_ASSETS_TABS.SHARED_WITH_ME, label: 'Shared with me', routePath: MY_ASSETS_TABS.SHARED_WITH_ME },
  { id: MY_ASSETS_TABS.MY_FAVORITES, label: 'Favorites', routePath: MY_ASSETS_TABS.MY_FAVORITES },
  { id: MY_ASSETS_TABS.TRASH, label: 'Trash', routePath: MY_ASSETS_TABS.TRASH },
];

export interface MyAssetsEmptyState {
  image: string;
  imageAlt?: string;
  message: string;
  action?: { label: string; route: string };
}

export const MY_ASSETS_EMPTY_STATES: Record<MyAssetsTabId, MyAssetsEmptyState> = {
  [MY_ASSETS_TABS.MY_ASSETS]: {
    image: 'no_report_assets.svg',
    imageAlt: 'No assets',
    message: "You don't have any assets here yet",
    action: { label: 'Create a survey', route: '/survey' },
  },
  [MY_ASSETS_TABS.RECENT]: {
    image: 'recent_open.svg',
    imageAlt: 'No recent assets',
    message: "You haven't opened any assets recently",
  },
  [MY_ASSETS_TABS.SHARED_WITH_ME]: {
    image: 'no_report_assets.svg',
    imageAlt: 'No shared assets',
    message: 'No assets have been shared with you yet',
  },
  [MY_ASSETS_TABS.MY_FAVORITES]: {
    image: 'no_favourite_assets.svg',
    imageAlt: 'No favorite assets',
    message: "You do not have any assets marked as favorites",
  },
  [MY_ASSETS_TABS.TRASH]: {
    image: 'no_report_assets.svg',
    imageAlt: 'No trashed assets',
    message: 'You don\'t have any assets here yet',
  },
};

export type SurveyGridActionType = 'open' | 'open-new-tab' | 'favorite' | 'duplicate' | 'info' | 'edit' | 'trash';

export interface SurveyGridActionEvent<T = unknown> {
  optionType: string;
  row: T;
}