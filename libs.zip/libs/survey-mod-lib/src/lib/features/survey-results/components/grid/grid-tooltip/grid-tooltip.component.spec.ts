import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { readFileSync } from 'node:fs';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it } from 'vitest';
import { GridTooltipComponent } from './grid-tooltip.component';

type GridTooltipParams = Parameters<GridTooltipComponent['agInit']>[0];

const template = readFileSync('libs/survey-mod-lib/src/lib/features/survey-results/components/grid/grid-tooltip/grid-tooltip.component.html', 'utf8');

function createFixture() {
  return TestBed.configureTestingModule({ imports: [TranslateModule.forRoot()] })
    .overrideComponent(GridTooltipComponent, { set: { template, templateUrl: undefined, styleUrl: undefined } })
    .createComponent(GridTooltipComponent);
}

function render(value: GridTooltipParams['value'], location: GridTooltipParams['location'] = 'cell') {
  const fixture = createFixture();
  fixture.componentInstance.agInit({ value, location } as GridTooltipParams);
  fixture.detectChanges();
  return fixture.nativeElement as HTMLElement;
}

describe('GridTooltipComponent', () => {
  it.each([0, '0012', '109.066494'])('preserves the backend tooltip value %s', value => {
    expect(render({ value }).textContent?.trim()).toBe(String(value));
  });
  it('shows the header text and missing-value fallback', () => {
    expect(render('Agreement', 'header').textContent?.trim()).toBe('Agreement');
    TestBed.resetTestingModule();
    expect(render({ value: null }).textContent?.trim()).toBe('- Missing -');
  });
  it('shows the masked header and backend reason', () => {
    const element = render({ value: '!', masked: true, header: 'Count', message: 'Sample too small.' });
    expect(element.textContent).toContain('Value not available');
    expect(element.querySelector('strong')?.textContent).toBe('Count');
    expect(element.textContent).toContain('Sample too small.');
    expect(element.getAttribute('role')).toBe('tooltip');
  });
  it('renders backend text safely without interpreting it as HTML', () => {
    const text = '<img src=x onerror=alert(1)>';
    const element = render({ value: text });
    expect(element.querySelector('img')).toBeNull();
    expect(element.textContent).toContain(text);
  });
  it('translates the masked-value heading using the application translate service', () => {
    const fixture = createFixture();
    const translate = TestBed.inject(TranslateService);
    translate.setTranslation('fr', { 'Value not available': 'Valeur indisponible' });
    translate.use('fr');
    fixture.componentInstance.agInit({ location: 'cell', value: { value: '!', masked: true } } as GridTooltipParams);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.masked-title').textContent).toBe('Valeur indisponible');
  });

  it('updates the OnPush view through signals when tooltip content changes', () => {
    const fixture = createFixture();
    fixture.componentInstance.agInit({ location: 'cell', value: { value: '!', masked: true, header: 'Count', message: 'Unavailable' } } as GridTooltipParams);
    fixture.detectChanges();
    expect(fixture.componentInstance.isMasked()).toBe(true);
    fixture.componentInstance.agInit({ location: 'cell', value: { value: 0 } } as GridTooltipParams);
    fixture.detectChanges();
    expect(fixture.componentInstance.isMasked()).toBe(false);
    expect(fixture.componentInstance.headerText()).toBe('');
    expect(fixture.componentInstance.maskReason()).toBe('');
    expect(fixture.nativeElement.querySelector('.masked-title')).toBeNull();
    expect(fixture.nativeElement.textContent.trim()).toBe('0');
  });

});
