import { TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { beforeEach, describe, expect, it, vi } from 'vitest';

import { SurveyOverview } from './survey-overview.component';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { SurveyStatusType } from '../../../build-survey/models/build-survey';
import { SurveyService } from '../../../build-survey/services/survey.service';

vi.mock('@nielsen/crf-data-summary', () => ({
  CrfDataSummaryModule: class {},
  CrfDataSummaryService: class {},
}));
vi.mock('@nielsen/crf-lp-common', () => ({
  ACFetchApiService: class {},
  ACAssetManageApiService: class {},
  AssetTypes: { FOLDER: 'DISCOVERFOLDER' },
}));

describe('SurveyOverview', () => {
  let component: SurveyOverview;
  const surveyCommonServiceStub = {
    getPanelistDataSelectorState: vi.fn().mockReturnValue({}),
    getSelectPanelistUiState: vi.fn().mockReturnValue({ selectedResponses: 0 }),
  };
  const surveyServiceStub = {
    title: signal('Colgate Marketing Survey').asReadonly(),
    questions: signal([{}, {}, {}]),
    loadedSurveyDetails: vi.fn().mockReturnValue({}),
  };

  beforeEach(async () => {
    surveyCommonServiceStub.getPanelistDataSelectorState.mockReturnValue({ selections: [{ id: 'PRDC' }] });
    surveyCommonServiceStub.getSelectPanelistUiState.mockReturnValue({ selectedResponses: 400 });
    surveyServiceStub.loadedSurveyDetails.mockReturnValue({});

    await TestBed.configureTestingModule({
      providers: [
        { provide: SurveyCommonService, useValue: surveyCommonServiceStub },
        { provide: SurveyService, useValue: surveyServiceStub },
      ],
    });

    component = TestBed.runInInjectionContext(() => new SurveyOverview());
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('returns panelist summary and selected response count from service state', () => {
    expect(component.panelistSummaryState).toEqual({ selections: [{ id: 'PRDC' }] });
    expect(component.selectedResponseCount).toBe(400);
    expect(component.questionCount).toBe(3);
  });

  it('returns safe defaults when service state is nullish', () => {
    surveyCommonServiceStub.getPanelistDataSelectorState.mockReturnValue(null);
    surveyCommonServiceStub.getSelectPanelistUiState.mockReturnValue({ selectedResponses: null });

    expect(component.panelistSummaryState).toEqual({});
    expect(component.selectedResponseCount).toBe(0);
  });

  it('returns a published-date fallback and hides the closed date when survey details are null', () => {
    surveyServiceStub.loadedSurveyDetails.mockReturnValue(null);

    expect(component.publishedDateValue).toBe('-');
    expect(component.closedDateValue).toBeNull();
  });

  it('formats published and closed dates for a closed survey', () => {
    surveyServiceStub.loadedSurveyDetails.mockReturnValue({
      assetInfo: { status: SurveyStatusType.CLOSED },
      delivery: {
        schedule: {
          openAt: '2026-09-22T00:00:00.000Z',
          closeAt: '2026-10-02T00:00:00.000Z',
        },
      },
    });

    expect(component.publishedDateValue).toBe('September 22, 2026');
    expect(component.closedDateValue).toBe('October 2, 2026');
  });

  it.each([SurveyStatusType.PUBLISHED, SurveyStatusType.LIVE])('hides the scheduled close date for a %s survey', (status) => {
    surveyServiceStub.loadedSurveyDetails.mockReturnValue({
      assetInfo: { status },
      delivery: { schedule: { closeAt: '2026-10-02T00:00:00.000Z' } },
    });

    expect(component.closedDateValue).toBeNull();
  });

  it('returns fallback dates for invalid or non-string schedule values on a closed survey', () => {
    surveyServiceStub.loadedSurveyDetails.mockReturnValue({
      assetInfo: { status: SurveyStatusType.CLOSED },
      delivery: {
        schedule: {
          openAt: 'not-a-date',
          closeAt: 123,
        },
      },
    });

    expect(component.publishedDateValue).toBe('-');
    expect(component.closedDateValue).toBe('-');
  });
});
