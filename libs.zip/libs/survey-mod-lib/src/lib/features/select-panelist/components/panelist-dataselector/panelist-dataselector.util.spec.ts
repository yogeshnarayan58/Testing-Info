import { describe, expect, it } from 'vitest';
import { getRestoredPrompts, getRestoredSelections, resolveDatasetName } from './panelist-dataselector.util';

describe('panelist-dataselector util', () => {
  describe('resolveDatasetName', () => {
    it('prefers title, then label, then description, then id', () => {
      expect(resolveDatasetName({ title: 'T', label: 'L', description: 'D', id: 'I' })).toBe('T');
      expect(resolveDatasetName({ label: 'L', description: 'D', id: 'I' })).toBe('L');
      expect(resolveDatasetName({ description: 'D', id: 'I' })).toBe('D');
      expect(resolveDatasetName({ id: 'I' })).toBe('I');
    });

    it('falls back to "Selected Dataset" when details are missing or empty', () => {
      expect(resolveDatasetName(undefined)).toBe('Selected Dataset');
      expect(resolveDatasetName(null)).toBe('Selected Dataset');
      expect(resolveDatasetName({ title: '', id: '' })).toBe('Selected Dataset');
    });
  });

  describe('getRestoredPrompts', () => {
    it('uses dataPrompts first when present', () => {
      const cached = {
        dataPrompts: [{ id: 'a' }],
        panelDataPrompts: [{ id: 'b' }],
        requestInstance: { prompts: [{ id: 'c' }] },
      };
      expect(getRestoredPrompts(cached)).toEqual([{ id: 'a' }]);
    });

    it('falls back to panelDataPrompts, then requestInstance.prompts', () => {
      expect(getRestoredPrompts({ dataPrompts: [], panelDataPrompts: [{ id: 'b' }] })).toEqual([{ id: 'b' }]);
      expect(getRestoredPrompts({ requestInstance: { prompts: [{ id: 'c' }] } })).toEqual([{ id: 'c' }]);
    });

    it('returns an empty array when nothing is cached', () => {
      expect(getRestoredPrompts({})).toEqual([]);
    });

    it('returns a deep copy, not the cached reference', () => {
      const cached = { dataPrompts: [{ id: 'a', nested: { x: 1 } }] };
      const result = getRestoredPrompts(cached);
      result[0].nested.x = 99;
      expect(cached.dataPrompts[0].nested.x).toBe(1);
    });
  });

  describe('getRestoredSelections', () => {
    it('uses cached selections when present', () => {
      expect(getRestoredSelections({ selections: [{ dimension: 'd' }], requestInstance: { dimensionSelections: [{ dimension: 'x' }] } }))
        .toEqual([{ dimension: 'd' }]);
    });

    it('falls back to requestInstance.dimensionSelections, then an empty array', () => {
      expect(getRestoredSelections({ selections: [], requestInstance: { dimensionSelections: [{ dimension: 'x' }] } }))
        .toEqual([{ dimension: 'x' }]);
      expect(getRestoredSelections({})).toEqual([]);
    });
  });
});
