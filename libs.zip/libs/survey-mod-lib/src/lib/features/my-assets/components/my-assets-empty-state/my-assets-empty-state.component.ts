import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { ButtonModule } from '@nielseniq/athena-core';
import { MyAssetsEmptyState } from '../../constants/my-assets-tabs.constant';

@Component({
  selector: 'survey-my-assets-empty-state',
  standalone: true,
  imports: [ButtonModule],
  templateUrl: './my-assets-empty-state.component.html',
  styleUrl: './my-assets-empty-state.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyAssetsEmptyStateComponent {
  config = input.required<MyAssetsEmptyState>();
  actionClick = output<string>();
}
