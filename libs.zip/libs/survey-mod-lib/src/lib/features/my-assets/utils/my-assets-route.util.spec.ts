import { describe, expect, it } from 'vitest';
import { MY_ASSETS_TABS } from '../constants/my-assets-tabs.constant';
import { getMyAssetsFolderUrl, getMyAssetsTabUrl } from './my-assets-route.util';

describe('My Assets route helpers', () => {
	it.each([
		['/survey/my-assets', '/survey/my-assets'],
		['/my-assets/survey/my-assets', '/my-assets/survey/my-assets'],
	])('preserves the host mount for %s', (currentUrl, expectedTabUrl) => {
		expect(getMyAssetsTabUrl(currentUrl, MY_ASSETS_TABS.MY_ASSETS)).toBe(expectedTabUrl);
	});

	it('preserves the Landing Page mount when changing tabs', () => {
		expect(getMyAssetsTabUrl('/my-assets/survey/my-assets', MY_ASSETS_TABS.SHARED_WITH_ME))
			.toBe('/my-assets/survey/shared-with-me');
	});

	it.each([
		['/my-assets/survey/shared-with-me?view=grid', '/my-assets/survey/trash'],
		['/my-assets/survey/shared-with-me#details', '/my-assets/survey/trash'],
	])('preserves the Landing Page mount when changing tabs from %s', (currentUrl, expectedTabUrl) => {
		expect(getMyAssetsTabUrl(currentUrl, MY_ASSETS_TABS.TRASH)).toBe(expectedTabUrl);
	});

	it('builds an encoded folder URL using the current host mount', () => {
		expect(getMyAssetsFolderUrl('/my-assets/survey/my-assets', MY_ASSETS_TABS.MY_ASSETS, 'folder/id 1'))
			.toBe('/my-assets/survey/my-assets/folder/folder%2Fid%201');
	});

	it('defaults to survey prefix when no recognized tab is found in URL', () => {
		expect(getMyAssetsTabUrl('/some/random/path', MY_ASSETS_TABS.MY_ASSETS))
			.toBe('/survey/my-assets');
	});

	it('defaults to survey prefix when URL is empty', () => {
		expect(getMyAssetsTabUrl('', MY_ASSETS_TABS.SHARED_WITH_ME))
			.toBe('/survey/shared-with-me');
	});
});