import { Injectable, inject } from '@angular/core';
import {
  ACAssetManageApiService, ACFetchApiService, Asset, AssetTypes,
  AssignRightsHelperService, PrimarySort, SortOrder,
} from '@nielsen/crf-lp-common';
import { Observable, defer, map, switchMap, take, throwIfEmpty } from 'rxjs';
import { ASSET_TYPE } from '../constants/my-assets-tabs.constant';
import { SurveyGridRow } from '../models/survey-asset.model';

@Injectable({ providedIn: 'root' })
export class SurveyAssetActionsService {
  private readonly assetFetch = inject(ACFetchApiService);
  private readonly assetManage = inject(ACAssetManageApiService);
  private readonly assignRights = inject(AssignRightsHelperService);

  fetchMoveFolders(): Observable<Asset[]> {
    return this.assetFetch.getMyFolders(
      [AssetTypes.SHARED_FOLDER, AssetTypes.FOLDER],
      { primarySort: PrimarySort.NAME, sortOrder: SortOrder.ASC },
      false,
      false
    ).pipe(
      take(1),
      map((response) => response.data.assets),
      throwIfEmpty(() => new Error('The folder request did not return a result.'))
    );
  }

  renameAsset(assetId: string, title: string): Observable<unknown> {
    return this.assetManage.renameAsset(assetId, title, false).pipe(
      take(1),
      throwIfEmpty(() => new Error('The rename request did not return a result.'))
    );
  }

  moveAssets(rows: readonly SurveyGridRow[], destination: Asset): Observable<unknown> {
    return defer(() => {
      if (!rows.length || rows.length > 20 || rows.some((row) => row.assetType !== ASSET_TYPE.DISCOVERSURVEY)) {
        throw new Error('Select between 1 and 20 surveys to move.');
      }
      const isRoot = destination.assetId === 'root';
      if (!isRoot && destination.assetType !== ASSET_TYPE.DISCOVERFOLDER
        && destination.assetType !== ASSET_TYPE.DISCOVERSHAREDFOLDER) {
        throw new Error('Select a valid destination folder.');
      }
      const ids = [...rows.map((row) => row.assetId), ...(!isRoot ? [String(destination.assetId)] : [])];
      const query = {
        userDetails: true,
        orderManagementDetails: true,
        displayAllRights: true,
        parentAsset: true,
      };
      return this.assetFetch.getAssetInfoByAssetId(ids.join(','), query, false).pipe(
        take(1),
        map((assets) => {
          const freshAssets = ids.map((id) => {
            const asset = assets.find((item) => String(item.assetId) === id);
            if (!asset) {
              throw new Error('Some selected assets are no longer available.');
            }
            const copy = structuredClone(asset);
            if (!copy.rights) {
              throw new Error('Access information was not returned for the selected assets.');
            }
            // In-place removal: `rights` is a union of two array types, so `.filter()` would not type-check.
            for (let index = copy.rights.length - 1; index >= 0; index--) {
              const right = copy.rights[index];
              if (!('userInfo' in right) && !('orderManagementInfo' in right)) {
                copy.rights.splice(index, 1);
              }
            }
            return copy;
          });
          if (freshAssets.some((asset) => asset.status === 'TRASHED')) {
            throw new Error('The selected assets are no longer available for moving.');
          }
          const target = isRoot ? destination : freshAssets[freshAssets.length - 1];
          const sources = freshAssets.slice(0, rows.length).filter((asset) =>
            (asset.parentAsset?.assetId == null ? 'root' : String(asset.parentAsset.assetId)) !== String(target.assetId)
          );
          if (!sources.length) {
            throw new Error('The selected surveys are already in this location.');
          }
          return { sources, target };
        }),
        switchMap(({ sources, target }) => {
          if (isRoot) {
            return this.assetManage.moveAssets(sources, target, false);
          }
          const payload: Asset[] = this.assignRights.inheritParentAndRights(sources, target);
          return this.assetManage.editAssets(payload, {}, false, false);
        }),
        throwIfEmpty(() => new Error('The move request did not return a result.'))
      );
    });
  }
}
