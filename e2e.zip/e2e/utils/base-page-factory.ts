import { BasePage } from '@gfk/gta';
import { chromium, test } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { WebActions } from '@gfk/gta/dist/core/web/webActions';
import { getLambdaTestBuildName, getLambdaTestSessionDir } from './configurationDetails';
import { safeJoin, assertContainedDir } from './safe-path';

/**
 * BasePageFactory: wires up a Playwright browser for tests, either
 * locally (default) or against LambdaTest cloud (when LAMBDATEST=true).
 *
 * The local/non-LambdaTest path below is unchanged from before and remains
 * the default: it only ever wires up a local browser via GTA's
 * BasePage.initializer(). storageState is READ-ONLY here: if
 * storage/auth.json exists, it is passed into contextOptions so the browser
 * reuses that session. Writing/saving storageState remains the
 * responsibility of the login page object (via webActions.getStorageState()),
 * not this factory.
 *
 * The LambdaTest path is INERT until LAMBDATEST=true and real credentials
 * (SM_LAMBDATEST_USERNAME/SM_LT_USERNAME + SM_LAMBDATEST_ACCESS_KEY/SM_LT_ACCESS_KEY) are
 * provided - see e2e/.env.example.
 */

// Store session names with timestamp as key (for reporter lookup)
export const sessionRegistry: Array<{ timestamp: number; sessionName: string; title?: string }> = [];

// Map to store session per worker - each worker runs tests sequentially
export const workerSessionMap = new Map<number, string>();

// Global current session tracker - stores the last created session
export let currentLTSession: string | null = null;

export class BasePageFactory {
  static async createBasePage(forceHeadless?: boolean): Promise<BasePage> {
    const isLambdaTest = process.env.LAMBDATEST === 'true';

    let storageState: string | undefined;
    // #cycode_sast_ignore_here Static path: process.cwd() joined with hardcoded literal 'storage/auth.json', no user input
    const authPath = path.resolve(process.cwd(), 'storage/auth.json');

    if (fs.existsSync(authPath)) {
      storageState = authPath;
      console.log('Auth state loaded from storage/auth.json');
    } else {
      console.log('No auth state found - login required');
    }

    if (isLambdaTest) {
      console.log('Connecting to LambdaTest cloud...');

      const ltUser = process.env.SM_LAMBDATEST_USERNAME || process.env.SM_LT_USERNAME;
      const ltAccessKey = process.env.SM_LAMBDATEST_ACCESS_KEY || process.env.SM_LT_ACCESS_KEY;
      const ltProject = process.env.SM_LT_PROJECT || 'OMNI SurveyMod';
      const ltBuildBase = process.env.SM_LT_BUILD || 'Survey Mod Build';
      const ltBuildIdentifier =
        process.env.SM_LT_BUILD_IDENTIFIER ||
        process.env.BUILD_NUMBER ||
        process.env.GITHUB_RUN_NUMBER ||
        undefined;
      const ltBuild = getLambdaTestBuildName(ltBuildBase, ltBuildIdentifier);

      const ltVideo = process.env.SM_LT_VIDEO === 'false' ? false : true;
      const ltNetwork = process.env.SM_LT_NETWORK === 'true';
      const ltConsole = process.env.SM_LT_CONSOLE === 'true';

      const timestamp = Date.now();
      const sessionName = `Test-${timestamp}`;

      const ltOptions: any = {
        platform: 'Windows 11',
        project: ltProject,
        build: ltBuild,
        name: sessionName,
        user: ltUser,
        accessKey: ltAccessKey,
        network: ltNetwork,
        video: ltVideo,
        console: ltConsole,
      };

      if (forceHeadless !== undefined) {
        ltOptions.headless = forceHeadless;
      }

      const wsEndpoint = `wss://cdp.lambdatest.com/playwright?capabilities=${encodeURIComponent(
        JSON.stringify({
          browserName: 'pw-chromium',
          browserVersion: 'latest',
          'LT:Options': ltOptions,
        })
      )}`;

      const browser = await chromium.connect(wsEndpoint);
      console.log(`Connected to LambdaTest (Session: ${sessionName})`);

      const contextOptions: any = {
        acceptDownloads: true,
        viewport: { width: 1920, height: 1080 },
      };

      if (storageState) {
        contextOptions.storageState = storageState;
      }

      const context = await browser.newContext(contextOptions);
      const page = await context.newPage();

      try {
        const rawWorkerIndex = Number(process.env.TEST_WORKER_INDEX || 0);
        // Guarantee a finite numeric worker index before it is ever embedded in a filename.
        const workerIndex = Number.isFinite(rawWorkerIndex) ? rawWorkerIndex : 0;
        // Read testId directly from Playwright's own per-worker TestInfo instead of
        // process.env/global set by the reporter: the reporter (onTestBegin/onTestEnd)
        // runs in Playwright's main process, while this factory runs inside the test's
        // worker process - a *separate* Node process that never sees the reporter's
        // process.env or global mutations. test.info() reads the current test's info
        // from within this same worker process, so it is the only reliable source here.
        // Throws when called outside an active test (e.g. from global-setup.ts's login
        // flow), so it's guarded and simply falls back to null in that case.
        let testId: string | null = null;
        try {
          testId = test.info().testId;
        } catch {
          testId = null;
        }

        const rawSessionDir = getLambdaTestSessionDir();
        // #cycode_sast_ignore_here Static path: process.cwd() joined with hardcoded literal 'test-results', no user input
        const safeSessionDir = assertContainedDir(
          path.resolve(process.cwd(), 'test-results'),
          rawSessionDir
        );
        // #cycode_sast_ignore_here Path validated via assertContainedDir() above - resolves and verifies containment within test-results/
        fs.mkdirSync(safeSessionDir, { recursive: true });

        // store in memory
        (page as any).__LT_SESSION_NAME__ = sessionName;
        sessionRegistry.push({ timestamp, sessionName });
        workerSessionMap.set(workerIndex, sessionName);
        currentLTSession = sessionName;

        // append sessions.jsonl (fallback)
        // #cycode_sast_ignore_here Path validated via safeJoin() - resolves and verifies containment within base directory before use
        fs.appendFileSync(
          safeJoin(safeSessionDir, 'sessions.jsonl'),
          JSON.stringify({ sessionName, timestamp, workerIndex }) + '\n',
          'utf-8'
        );

        if (testId) {
          // Sanitize testId to ensure it is safe for use in file paths
          const sanitizedTestId = testId.replace(/[^a-zA-Z0-9_-]/g, '_');
          // #cycode_sast_ignore_here Path validated via safeJoin(); sanitizedTestId is regex-sanitized before use
          fs.writeFileSync(
            safeJoin(safeSessionDir, `test-${sanitizedTestId}.json`),
            JSON.stringify({ sessionName, timestamp, testId }),
            'utf-8'
          );
          console.log(`[LT Session] ✓ test-${sanitizedTestId}.json written`);
        } else {
          console.warn('[LT Session] Warning: testId not available, using fallback sessions.jsonl');
        }

        // #cycode_sast_ignore_here Path validated via safeJoin(); workerIndex is guaranteed a finite number above, not raw user input
        fs.writeFileSync(
          safeJoin(safeSessionDir, `worker-${workerIndex}.json`),
          JSON.stringify({ sessionName, timestamp }),
          'utf-8'
        );

        console.log(`[LT Session] Registered session: ${sessionName} (worker: ${workerIndex})`);
      } catch (err) {
        console.warn('[LT Session] Could not store session info:', err);
      }

      // Inject into BasePage
      (BasePage as any).browser = browser;
      (BasePage as any).context = context;
      (BasePage as any).page = page;
      (BasePage as any).webActions = new WebActions(page, context);

      return new (BasePage as any)();
    }

    const browserName = process.env.BROWSER_NAME || 'chromium';

    const envHeadless = process.env.HEADLESS !== 'false';
    const headless = forceHeadless ?? envHeadless;
    const browserOptions = { headless };

    const contextOptions = {
      acceptDownloads: true,
     // viewport: null,
      storageState,
    };

    return await BasePage.initializer(browserName, browserOptions, contextOptions);
  }
}
