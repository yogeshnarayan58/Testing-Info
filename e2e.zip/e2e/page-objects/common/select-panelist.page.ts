import { BasePage, WebActions } from '@gfk/gta';
import { ResourceManager } from '../../utils/resource-manager';
import selectPanelistPageResources from '../../locators/survey/select-panelist.locator.json';
import { PANEL_TRANSITION_DELAY, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';

const SELECT_PANELIST_PAGE_COMPONENT_NAME = 'selectPanelistPage';

/**
 * DimensionSelection interface defines hierarchy and UI interaction flags per dimension.
 */
interface DimensionSelection {
  dimensionTab: string;
  items: string[];
  parentItems?: string[];
  requiresFilterIconClick?: boolean;
  filterIconClickAfterParent?: boolean;
  skipParentSearch?: boolean;
}

/**
 * SelectPanelistPage — Rebuilt following Omni Shopper's proven DataSelector pattern.
 * KEY CHANGE: searchIcon clicks are now CONDITIONAL on visibility (isVisible() check)
 * instead of unconditionally assuming the icon must be clicked.
 */
export class SelectPanelistPage {
  private webActionHandler: WebActions;
  private resourceManager: ResourceManager;

  constructor(private basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
    this.resourceManager.registerResources(
      SELECT_PANELIST_PAGE_COMPONENT_NAME,
      selectPanelistPageResources
    );
  }

  /**
   * Process all dimension selections in sequence.
   */
  async setDimensionSelections(selections: DimensionSelection[]): Promise<void> {
    for (const selection of selections) {
      await this.setDimensionSelection(
        selection.dimensionTab,
        selection.items,
        selection.parentItems,
        selection.requiresFilterIconClick,
        selection.filterIconClickAfterParent,
        selection.skipParentSearch
      );
    }
  }

  /**
   * Enter text into search field.
   * Matches Omni Shopper pattern: waitFor() once (no timeout), clear, type.
   */
  private async enterTextInSearchField(inputText: string): Promise<void> {
    const searchField = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('dsSearchBarInput', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await searchField.waitFor();
    await searchField.enterText("");
    await searchField.enterText(inputText);
  }

  /**
   * Reads the value currently displayed on a dimension's tile (same element
   * setDimensionSelection() clicks to open the picker) — placeholder text like
   * "Select Product" when empty, or the selected value once something's chosen.
   */
  private async getCurrentDimensionValue(dimensionPromptResource: string): Promise<string> {
    const dimensionElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(dimensionPromptResource, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await dimensionElement.waitFor();
    const text = await dimensionElement.getText();
    return (text ?? '').trim();
  }

  /**
   * Best-effort placeholder heuristic (NOT a confirmed exact string per dimension —
   * only "Select product"/"Select period" were found, lowercase, in captured i18n data).
   */
  private isPlaceholderValue(value: string): boolean {
    return value.length === 0 || /^select\b/i.test(value.trim());
  }

  /** True if every desired item is already reflected in the current displayed text. */
  private dimensionAlreadyMatches(currentValue: string, itemsToSelect: string[]): boolean {
    if (this.isPlaceholderValue(currentValue) || itemsToSelect.length === 0) {
      return false;
    }
    const normalizedCurrent = currentValue.toLowerCase();
    return itemsToSelect.every((item) => normalizedCurrent.includes(item.toLowerCase()));
  }

  /**
   * Dimensions whose empty-state "no data" prompt disappears from the DOM once a value
   * is selected (replaced by a filled-state tile, data-test-id `ds-${label}_Dimension`,
   * per @nielsen/crf-data-summary's template — both `ds-noDataPrompt_${label}` and
   * `ds-${label}_Dimension` are rendered off the same `prompt.label`, confirmed in
   * nielsen-crf-data-summary.mjs). Maps each dimension's prompt resource key to the
   * exact `${label}` used in that attribute — covers all 5 dimensions.
   */
  private readonly FILLED_TILE_DIMENSION_LABELS: Record<string, string> = {
    productNoDataPrompt: 'Product',
    retailerNoDataPrompt: 'Retailer',
    geographyNoDataPrompt: 'Geography',
    demographicNoDataPrompt: 'Demographic',
    periodNoDataPrompt: 'Period',
  };

  /**
   * Reads the current value from the empty-state prompt when present; when the dimension
   * already has a selection, that prompt isn't in the DOM, so this falls back to reading
   * the filled-state dimension tile instead. Only used for dimensions listed in
   * FILLED_TILE_DIMENSION_LABELS.
   */
  private async getCurrentFilledTileDimensionValue(dimensionPromptResource: string, dimensionLabel: string): Promise<string> {
    const noDataPrompt = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(dimensionPromptResource, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    try {
      if (await noDataPrompt.isVisible()) {
        const text = await noDataPrompt.getText();
        return (text ?? '').trim();
      }
    } catch {
      // empty-state prompt not present — fall through to filled-tile read
    }

    const filledTile = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('filledDimensionTile', dimensionLabel, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await filledTile.waitFor();
    const filledText = await filledTile.getText();
    return (filledText ?? '').trim();
  }

  /**
   * When a different value is already selected, click the filled tile to open its popover
   * with the removable chip, remove it, then click addButton to reopen the picker —
   * replaces the empty-state prompt click used by the default flow. Only used for
   * dimensions listed in FILLED_TILE_DIMENSION_LABELS.
   */
  private async replaceFilledTileDimensionSelection(dimensionLabel: string): Promise<void> {
    const filledTile = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('filledDimensionTile', dimensionLabel, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await filledTile.waitFor();
    await filledTile.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

    const removeIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('removeIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await removeIcon.waitFor();
    await removeIcon.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

    const addButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await addButton.waitFor();
    await addButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  /**
   * Removes the current selection before re-selecting. Direct remove-icon click first;
   * falls back to hover + delete-menu-icon.
   */
  private async removeCurrentDimensionSelection(): Promise<void> {
    const removeIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('removeIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    try {
      if (await removeIcon.isVisible()) {
        await removeIcon.click();
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        return;
      }
    } catch {
      // fall through to hover + delete-menu fallback
    }

    const selectedOption = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('selectedOption', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await selectedOption.waitFor();
    await selectedOption.hover();

    const deleteMenuIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('deleteMenuIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await deleteMenuIcon.waitFor();
    await deleteMenuIcon.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  /**
   * Core dimension selection flow — FULLY REWRITTEN to match Omni Shopper's conditional pattern.
   * 
   * Flow:
   * 1. Click dimension prompt → panel opens
   * 2. IF requiresFilterIconClick: Check isVisible() BEFORE clicking searchIcon (NEW — conditional!)
   * 3. Select parent categories (if any)
   * 4. IF filterIconClickAfterParent: Check isVisible() BEFORE clicking searchIcon
   * 5. Select child items
   * 6. Clear search field
   * 7. Click Done → panel closes
   */
  async setDimensionSelection(
    dimensionPromptResource: string,
    itemsToSelect: string[],
    parentItems?: string[],
    requiresFilterIconClick?: boolean,
    filterIconClickAfterParent?: boolean,
    skipParentSearch?: boolean
  ): Promise<void> {
    try {
      // Step 0: Check-before-click — skip if already correct, remove first if a
      // different value is selected, otherwise fall through to the existing add flow.
      // For dimensions in FILLED_TILE_DIMENSION_LABELS, the empty-state prompt
      // disappears once a value is selected, so the current value is read from the
      // filled-state tile instead. Runs BEFORE any dimension-specific flags below
      // (e.g. Period's skipParentSearch/filterIconClickAfterParent) — it only gates
      // entry into that existing logic, never replaces it.
      const filledTileDimensionLabel = this.FILLED_TILE_DIMENSION_LABELS[dimensionPromptResource];
      const currentValue = filledTileDimensionLabel
        ? await this.getCurrentFilledTileDimensionValue(dimensionPromptResource, filledTileDimensionLabel)
        : await this.getCurrentDimensionValue(dimensionPromptResource);

      if (this.dimensionAlreadyMatches(currentValue, itemsToSelect)) {
        return;
      }

      let skipInitialPromptClick = false;
      if (!this.isPlaceholderValue(currentValue)) {
        if (filledTileDimensionLabel) {
          await this.replaceFilledTileDimensionSelection(filledTileDimensionLabel);
          skipInitialPromptClick = true;
        } else {
          await this.removeCurrentDimensionSelection();
        }
      }

      // Step 1: Click dimension prompt
      // Skipped when replaceFilledTileDimensionSelection() already reopened the picker
      // via the filled tile + addButton.
      if (!skipInitialPromptClick) {
        const dimensionPrompt = this.webActionHandler.getWebElement(
          this.resourceManager.getResource(dimensionPromptResource, SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        await dimensionPrompt.waitFor();
        await dimensionPrompt.click();
        await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
      }

      // Step 2: CONDITIONALLY click searchIcon BEFORE parent (Product, Demographic)
      // ✓ THIS IS THE KEY FIX: Check isVisible() first — matches Omni Shopper's defensive pattern
      if (requiresFilterIconClick) {
        const searchIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource('searchIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        const isVisible = await searchIcon.isVisible();
        if (isVisible) {
          await searchIcon.click();
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        } else {
          // Icon not visible = search bar already open on panel load
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        }
      }

      // Step 3: Select parent categories (hierarchical dimensions: Product, Period)
      if (parentItems && parentItems.length > 0) {
        for (const parentItem of parentItems) {
          // 3a: Search for parent (unless skipParentSearch is true for Period)
          if (!skipParentSearch) {
            await this.enterTextInSearchField(parentItem);
            await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

            const viewport = this.webActionHandler.getWebElement(
              this.resourceManager.getResource('dsSelectionsViewPort', SELECT_PANELIST_PAGE_COMPONENT_NAME)
            );
            await viewport.waitFor();
            await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
          }

          // 3b: Click parent category item (NOT checkbox)
          const parentCategory = this.webActionHandler.getWebElement(
            this.resourceManager.getDynamicResource('categoryItem', parentItem, SELECT_PANELIST_PAGE_COMPONENT_NAME)
          );
          await parentCategory.waitFor();
          await parentCategory.click();
          await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
        }
      }

      // Step 4: CONDITIONALLY click searchIcon AFTER parent (Period only)
      // ✓ Matches Omni Shopper: Check isVisible() before clicking
      if (filterIconClickAfterParent) {
        const searchIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource('searchIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        const isVisible = await searchIcon.isVisible();
        if (isVisible) {
          await searchIcon.click();
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        } else {
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        }
      }

      // Step 5: Select child items
      for (const item of itemsToSelect) {
        await this.enterTextInSearchField(item);
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

        const viewport = this.webActionHandler.getWebElement(
          this.resourceManager.getResource('dsSelectionsViewPort', SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        await viewport.waitFor();
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

        const checkbox = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource('checkboxLabel', item, SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        await checkbox.waitFor();
        await checkbox.click();
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }

      // Step 6: Clear search field before Done
      const searchFieldBeforeDone = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dsSearchBarInput', SELECT_PANELIST_PAGE_COMPONENT_NAME)
      );
      await searchFieldBeforeDone.waitFor();
      await searchFieldBeforeDone.enterText("");
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      // Step 7: Click Done
      const doneButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('doneIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
      );
      await doneButton.waitFor();
      await doneButton.click();
      await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
    } catch (error) {
      console.error(
        `setDimensionSelection failed for '${dimensionPromptResource}':`,
        error instanceof Error ? error.message : error
      );
      throw error;
    }
  }

  async clickSelectPanelistsTab(): Promise<void> {
    const selectPanelistsTab = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('selectPanelistsTab', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await selectPanelistsTab.waitFor();
    await selectPanelistsTab.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  async clickSearchForPanelists(): Promise<void> {
    const searchButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('searchForPanelistsButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await searchButton.waitFor();
    await searchButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async click250Responses(): Promise<void> {
    const button250 = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('250ResponsesButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await button250.waitFor();
    await button250.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async clickProceedToSurveyBuilder(): Promise<void> {
    const proceedButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('proceedToSurveyBuilderButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await proceedButton.waitFor();
    await proceedButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async clickBuildSurvey(): Promise<void> {
    const buildSurveyButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('buildSurveyButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await buildSurveyButton.waitFor();
    await buildSurveyButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async isBuildSurveyPageLoaded(): Promise<boolean> {
    const pageHeading = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('buildSurveyPageHeading', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await pageHeading.waitFor();
    return await pageHeading.isVisible();
  }

  async isSearchForPanelistsButtonVisible(): Promise<boolean> {
    const searchButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('searchForPanelistsButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await searchButton.waitFor();
    return await searchButton.isVisible();
  }

  async isProceedToSurveyBuilderVisible(): Promise<boolean> {
    const proceedButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('proceedToSurveyBuilderButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await proceedButton.waitFor();
    return await proceedButton.isVisible();
  }
}