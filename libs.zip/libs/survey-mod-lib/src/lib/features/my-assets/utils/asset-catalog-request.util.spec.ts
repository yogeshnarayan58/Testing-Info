import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MY_ASSETS_TABS, MyAssetsTabId } from '../constants/my-assets-tabs.constant';
import { buildAssetCatalogRequest } from './asset-catalog-request.util';

describe('buildAssetCatalogRequest', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2026, 9, 28, 12, 0, 0));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  const build = (tab: MyAssetsTabId, folderId?: string) =>
    buildAssetCatalogRequest({
      tab, folderId, pageCount: 100, pageNumber: 2, primarySort: 'TITLE', sortOrder: 'ASC', timezone: 'UTC',
    });

  const types = (tab: MyAssetsTabId, folderId?: string) =>
    build(tab, folderId).assets.map((asset) => asset.assetType ?? asset.status);

  it('builds the My Assets root request excluding published availability', () => {
    const request = build(MY_ASSETS_TABS.MY_ASSETS);
    expect(request.properties).toMatchObject({ pageCount: 100, pageNumber: 2, dateSortType: 'MODIFIED', timezone: 'UTC' });
    expect(request.filters[0]).toMatchObject({ typeKey: 'RLT' });
    expect(request.filters[1]).toMatchObject({
      typeKey: 'AVL', elements: [{ availability: 'OWNED' }], exclusions: [{ availability: 'PUBLISHED' }],
    });
    expect(request.sort).toEqual({ primarySort: 'TITLE', sortOrder: 'ASC' });
    expect(request.datasets).toEqual([]);
    expect(types(MY_ASSETS_TABS.MY_ASSETS)).toHaveLength(3);
  });

  it('uses shared availability without exclusions for shared-with-me', () => {
    const avl = build(MY_ASSETS_TABS.SHARED_WITH_ME).filters[1];
    expect(avl.exclusions).toBeUndefined();
    expect(avl.elements).not.toEqual([{ availability: 'OWNED' }]);
  });

  it('ignores trashed relations and adds the trashed status in trash', () => {
    const request = build(MY_ASSETS_TABS.TRASH);
    expect(request.filters[0].relationStatusToBeIgnored).toEqual(['TRASHED']);
    expect(request.assets).toContainEqual({ status: 'TRASHED' });
  });

  it('builds a flat recent request with opened dates', () => {
    const request = build(MY_ASSETS_TABS.RECENT);
    expect(request.properties).toMatchObject({
      dateSortType: 'OPENED',
      startOpenedDate: '09/27/2026 00:00:00',
      endOpenedDate: '10/28/2026 23:59:00',
      lastOpenedByMe: true,
      lastAccessedByMe: false,
      restrictFlowChildren: true,
    });
    expect(request.filters).toHaveLength(1);
    expect(request.filters[0].typeKey).toBe('AVL');
    expect(request.assets).toHaveLength(1);
  });

  it('builds a flat favorites request', () => {
    const request = build(MY_ASSETS_TABS.MY_FAVORITES);
    expect(request.properties).toMatchObject({ isFavorite: true, dateSortType: 'MODIFIED' });
    expect(request.filters).toHaveLength(1);
    expect(request.assets).toHaveLength(1);
  });

  it('builds folder children requests with hierarchy filter and no root filters', () => {
    const request = build(MY_ASSETS_TABS.MY_ASSETS, 'folder-1');
    expect(request.properties).toMatchObject({ parentAsset: true, showImmediateChildren: true });
    expect(request.filters).toEqual([
      { typeKey: 'HIER', elements: [{ id: 'folder-1' }] },
      { typeKey: 'AVL', elements: [{ availability: 'OWNED' }] },
    ]);
    expect(types(MY_ASSETS_TABS.MY_ASSETS, 'folder-1')).toHaveLength(3);
  });

  it('keeps folder request shape for shared and trash tabs', () => {
    const shared = build(MY_ASSETS_TABS.SHARED_WITH_ME, 'folder-1');
    expect(shared.filters[1].elements?.length).toBeGreaterThan(1);
    const trash = build(MY_ASSETS_TABS.TRASH, 'folder-1');
    expect(trash.filters).toHaveLength(2);
    expect(trash.filters[0]).toEqual({ typeKey: 'HIER', elements: [{ id: 'folder-1' }] });
    expect(trash.assets).toContainEqual({ status: 'TRASHED' });
  });

  it('treats recent and favorites as regular lists when a folder is given', () => {
    const request = build(MY_ASSETS_TABS.RECENT, 'folder-1');
    expect(request.properties.dateSortType).toBe('MODIFIED');
    expect(request.assets).toHaveLength(3);
  });
});
