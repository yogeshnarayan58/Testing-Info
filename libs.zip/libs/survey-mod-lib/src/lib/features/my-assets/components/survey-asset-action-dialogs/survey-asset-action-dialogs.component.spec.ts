import { NO_ERRORS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { of, Subject, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ToastService } from '@nielseniq/athena-core';
import { SurveyGridRow } from '../../models/survey-asset.model';
import { SurveyAssetActionsService } from '../../services/survey-asset-actions.service';
import { SurveyExceptionHandlingService } from '../../../../shared/services/survey-exception-handling.service';
import { SurveyAssetActionDialogsComponent } from './survey-asset-action-dialogs.component';
import template from './survey-asset-action-dialogs.component.html?raw';

vi.mock('@nielsen/crf-ui-components', () => ({ TreeForderSelectorModule: class {} }));
vi.mock('../../services/survey-asset-actions.service', () => ({ SurveyAssetActionsService: class {} }));
vi.mock('../../../../shared/services/survey-exception-handling.service', () => ({ SurveyExceptionHandlingService: class {} }));
vi.mock('@nielseniq/athena-core', () => ({
  ButtonModule: class {}, DialogModule: class {}, SpinnerModule: class {}, TabModule: class {},
  TextFieldModule: class {}, ToastService: class {},
}));

const translatePipe = vi.fn((key: string) => key);

@Pipe({ name: 'translate', standalone: true })
class TranslatePipeStub implements PipeTransform {
  transform(key: string, params?: unknown): string {
    translatePipe(key, params);
    return key;
  }
}

const translateInstant = vi.fn((key: string) => key);

describe('SurveyAssetActionDialogsComponent', () => {
  let component: SurveyAssetActionDialogsComponent;
  let actions: {
    renameAsset: ReturnType<typeof vi.fn>;
    fetchMoveFolders: ReturnType<typeof vi.fn>;
    moveAssets: ReturnType<typeof vi.fn>;
    trashAssets: ReturnType<typeof vi.fn>;
    restoreAssets: ReturnType<typeof vi.fn>;
    deletePermanently: ReturnType<typeof vi.fn>;
  };
  let toast: { InsertToast: ReturnType<typeof vi.fn> };
  let exceptionHandling: { handleApiError: ReturnType<typeof vi.fn> };
  const row: SurveyGridRow = {
    assetId: 'survey-1', assetType: 'DISCOVERSURVEY', title: 'Survey', lastModifiedTimestamp: 0,
  };
  const folder = { assetId: 'folder-1', assetType: 'DISCOVERFOLDER', title: 'Folder' };
  const dialog = () => ({ open: vi.fn(), close: vi.fn() });
  let renameDialog: ReturnType<typeof dialog>;
  let folderDialog: ReturnType<typeof dialog>;
  let confirmDialog: ReturnType<typeof dialog>;
  let deleteDialog: ReturnType<typeof dialog>;

  beforeEach(() => {
    actions = {
      renameAsset: vi.fn().mockReturnValue(of({})),
      fetchMoveFolders: vi.fn().mockReturnValue(of([folder])),
      moveAssets: vi.fn().mockReturnValue(of({})),
      trashAssets: vi.fn().mockReturnValue(of({})),
      restoreAssets: vi.fn().mockReturnValue(of({})),
      deletePermanently: vi.fn().mockReturnValue(of({})),
    };
    toast = { InsertToast: vi.fn() };
    exceptionHandling = { handleApiError: vi.fn() };
    translateInstant.mockClear();
    translatePipe.mockClear();
    TestBed.configureTestingModule({ providers: [
      { provide: SurveyAssetActionsService, useValue: actions },
      { provide: ToastService, useValue: toast },
      { provide: SurveyExceptionHandlingService, useValue: exceptionHandling },
      { provide: TranslateService, useValue: { instant: translateInstant } },
    ] });
    TestBed.overrideComponent(SurveyAssetActionDialogsComponent, {
      set: { template, templateUrl: undefined, styleUrl: undefined, imports: [TranslatePipeStub], schemas: [NO_ERRORS_SCHEMA] },
    });
    component = TestBed.runInInjectionContext(() => new SurveyAssetActionDialogsComponent());
    renameDialog = dialog();
    folderDialog = dialog();
    confirmDialog = dialog();
    deleteDialog = dialog();
    Object.assign(component, { renameDialog, folderDialog, confirmDialog, deleteDialog });
  });

  it('prefills and resets Rename for the selected asset', () => {
    component.openRename(row);
    expect(component.renameTitle()).toBe(row.title);
    component.renameTitle.set('Unsaved edit');
    component.openRename({ ...row, assetId: 'second', title: 'Another survey' });
    expect(component.renameTitle()).toBe('Another survey');
    component.saveRename();
    expect(actions.renameAsset).toHaveBeenCalledExactlyOnceWith('second', 'Another survey');
    expect(renameDialog.open).toHaveBeenCalledTimes(2);
  });

  it.each([
    ['', 'SURVEYMOD_FIELD_REQUIRED', undefined],
    [' Leading space', 'SURVEYMOD_LEADING_SPACE_MESSAGE', undefined],
    ['a'.repeat(151), 'SURVEYMOD_MAX_LENGTH_MESSAGE', { max: 150 }],
    ['a'.repeat(150), '', undefined],
    ['Valid / name & symbols', '', undefined],
  ])('validates Rename input %s', (title, expected, params) => {
    component.renameTitle.set(title);
    if (expected) {
      expect(component.renameValidation()).toBe(expected);
      expect(translateInstant).toHaveBeenCalledWith(expected, ...(params ? [params] : []));
    } else {
      expect(component.renameValidation()).toBe('');
    }
  });

  it('does not submit Rename before an asset is selected or with invalid input', () => {
    component.renameTitle.set('Name');
    component.saveRename();
    component.openRename(row);
    component.renameTitle.set('');
    component.saveRename();
    expect(actions.renameAsset).not.toHaveBeenCalled();
  });

  it('submits Rename once and notifies only after a successful response', () => {
    const request = new Subject<unknown>();
    actions.renameAsset.mockReturnValue(request);
    const changed = vi.spyOn(component.assetsChanged, 'emit');
    component.openRename(row);
    component.renameTitle.set('New name');
    component.saveRename();
    component.saveRename();
    expect(component.renameBusy()).toBe(true);
    expect(actions.renameAsset).toHaveBeenCalledExactlyOnceWith(row.assetId, 'New name');
    expect(changed).not.toHaveBeenCalled();
    request.next({});
    expect(renameDialog.close).toHaveBeenCalledOnce();
    expect(changed).toHaveBeenCalledOnce();
    expect(toast.InsertToast).toHaveBeenCalledWith('success', 'SURVEYMOD_ASSET_RENAME_SUCCESS', expect.any(Object));
    expect(translateInstant).toHaveBeenCalledWith('SURVEYMOD_ASSET_RENAME_SUCCESS', { assetName: 'New name' });
    expect(component.renameBusy()).toBe(true);
    request.complete();
    expect(component.renameBusy()).toBe(false);
  });

  it('keeps Rename open and allows retry after failure', () => {
    const failure = new Error('Failed');
    actions.renameAsset.mockReturnValueOnce(throwError(() => failure));
    component.openRename(row);
    component.saveRename();
    expect(component.renameBusy()).toBe(false);
    expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
    expect(renameDialog.close).not.toHaveBeenCalled();
    expect(toast.InsertToast).not.toHaveBeenCalledWith('success', expect.any(String), expect.any(Object));
    component.saveRename();
    expect(renameDialog.close).toHaveBeenCalledOnce();
  });

  it('opens Move to with a snapshot of the selection and the shared folder list', () => {
    const rows = [row];
    component.openMove(rows);
    rows.push({ ...row, assetId: 'another' });
    expect(component.assetsToMove()).toEqual([row]);
    expect(component.selectedFolder()).toEqual(component.rootFolder);
    expect(component.folders()).toEqual([folder]);
    expect(folderDialog.open).toHaveBeenCalledOnce();
    expect(component.moveDisabled()).toBe(true);
  });

  it('prevents duplicate folder loads and cancels a pending load when closing', () => {
    const request = new Subject<typeof folder[]>();
    actions.fetchMoveFolders.mockReturnValue(request);
    component.openMove([row]);
    component.loadFolders();
    expect(component.foldersLoading()).toBe(true);
    expect(component.moveDisabled()).toBe(true);
    expect(actions.fetchMoveFolders).toHaveBeenCalledOnce();
    component.cancelFolderLoad();
    expect(request.observed).toBe(false);
    expect(component.foldersLoading()).toBe(false);
  });

  it('ignores an obsolete folder request after Move is reopened', () => {
    const previous = new Subject<typeof folder[]>();
    actions.fetchMoveFolders.mockReturnValueOnce(previous);
    component.openMove([row]);
    component.openMove([{ ...row, assetId: 'second' }]);
    previous.next([]);
    expect(previous.observed).toBe(false);
    expect(component.folders()).toEqual([folder]);
    expect(component.assetsToMove()[0].assetId).toBe('second');
  });

  it('shows folder-loading errors and allows retry without submitting a move', () => {
    const failure = new Error('Failed');
    actions.fetchMoveFolders.mockReturnValueOnce(throwError(() => failure));
    component.openMove([row]);
    expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
    expect(toast.InsertToast).not.toHaveBeenCalled();
    expect(component.folderLoadFailed()).toBe(true);
    expect(component.foldersLoading()).toBe(false);
    expect(component.moveDisabled()).toBe(true);
    component.selectFolder(folder);
    component.confirmMove();
    expect(confirmDialog.open).not.toHaveBeenCalled();
    component.loadFolders();
    expect(component.folderLoadFailed()).toBe(false);
    expect(component.folders()).toEqual([folder]);
    expect(component.moveDisabled()).toBe(false);
    expect(actions.moveAssets).not.toHaveBeenCalled();
  });

  it('disables same-folder and root-to-root moves but permits moving back to My assets', () => {
    component.openMove([row]);
    component.confirmMove();
    expect(confirmDialog.open).not.toHaveBeenCalled();
    component.openMove([{ ...row, parentAsset: { assetId: folder.assetId } }]);
    expect(component.moveDisabled()).toBe(false);
    component.selectFolder(folder);
    expect(component.moveDisabled()).toBe(true);
    component.selectFolder(component.rootFolder);
    expect(component.moveDisabled()).toBe(false);
  });

  it('permits bulk moves when at least one survey changes location', () => {
    component.openMove([row, { ...row, assetId: 'second', parentAsset: { assetId: folder.assetId } }]);
    component.selectFolder(folder);
    expect(component.moveDisabled()).toBe(false);
  });

  it('moves once, closes confirmation and notifies the parent only after success', () => {
    const request = new Subject<unknown>();
    actions.moveAssets.mockReturnValue(request);
    const changed = vi.spyOn(component.assetsChanged, 'emit');
    component.openMove([row]);
    component.selectFolder(folder);
    component.confirmMove();
    component.saveMove();
    component.saveMove();
    expect(actions.moveAssets).toHaveBeenCalledExactlyOnceWith([row], folder);
    expect(component.moveBusy()).toBe(true);
    expect(changed).not.toHaveBeenCalled();
    request.next({});
    request.complete();
    expect(component.moveBusy()).toBe(false);
    expect(confirmDialog.close).toHaveBeenCalledOnce();
    expect(changed).toHaveBeenCalledOnce();
    expect(toast.InsertToast).toHaveBeenCalledWith('success', 'SURVEYMOD_ASSET_MOVE_SUCCESS', expect.any(Object));
    expect(translateInstant).toHaveBeenCalledWith('SURVEYMOD_ASSET_MOVE_SUCCESS', { assetName: 'Survey', destination: 'Folder' });
  });

  it('uses the Landing Page bulk message when moving multiple surveys', () => {
    component.openMove([row, { ...row, assetId: 'second' }]);
    component.selectFolder(folder);
    component.saveMove();
    expect(toast.InsertToast).toHaveBeenCalledWith('success', 'SURVEYMOD_ASSETS_MOVE_SUCCESS', expect.any(Object));
    expect(translateInstant).toHaveBeenCalledWith('SURVEYMOD_ASSETS_MOVE_SUCCESS', { destination: 'Folder' });
  });

  it('keeps confirmation open on errors and supports retry', () => {
    const failure = new Error('Failed');
    actions.moveAssets.mockReturnValueOnce(throwError(() => failure));
    component.openMove([row]);
    component.selectFolder(folder);
    component.saveMove();
    expect(component.moveBusy()).toBe(false);
    expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
    expect(confirmDialog.close).not.toHaveBeenCalled();
    expect(toast.InsertToast).not.toHaveBeenCalledWith('success', expect.any(String), expect.any(Object));
    expect(component.moveDisabled()).toBe(false);
    component.saveMove();
    expect(confirmDialog.close).toHaveBeenCalledOnce();
  });

  it.each(['rename', 'move', 'trash', 'permanent', 'restore'] as const)(
    'cancels a pending %s mutation and clears its busy state on destruction', (action) => {
    const request = new Subject<unknown>();
    let busy;
    switch (action) {
      case 'rename':
        actions.renameAsset.mockReturnValue(request);
        component.openRename(row);
        component.saveRename();
        busy = component.renameBusy;
        break;
      case 'move':
        actions.moveAssets.mockReturnValue(request);
        component.openMove([row]);
        component.selectFolder(folder);
        component.saveMove();
        busy = component.moveBusy;
        break;
      case 'trash':
        actions.trashAssets.mockReturnValue(request);
        component.openDelete([row]);
        busy = component.deleteBusy;
        break;
      case 'permanent':
        actions.deletePermanently.mockReturnValue(request);
        component.openDeletePermanently([row]);
        component.saveDeleteConfirmation();
        busy = component.deleteBusy;
        break;
      case 'restore':
        actions.restoreAssets.mockReturnValue(request);
        component.restore([row]);
        busy = component.restoreBusy;
        break;
    }
    expect(busy()).toBe(true);
    TestBed.resetTestingModule();
    expect(request.observed).toBe(false);
    expect(busy()).toBe(false);
    expect(toast.InsertToast).not.toHaveBeenCalled();
    expect(renameDialog.close).not.toHaveBeenCalled();
    expect(confirmDialog.close).not.toHaveBeenCalled();
    expect(deleteDialog.close).not.toHaveBeenCalled();
  });

  it('clears folder loading state when the component is destroyed', () => {
    const request = new Subject<typeof folder[]>();
    actions.fetchMoveFolders.mockReturnValue(request);
    component.openMove([row]);
    expect(component.foldersLoading()).toBe(true);
    TestBed.resetTestingModule();
    expect(request.observed).toBe(false);
    expect(component.foldersLoading()).toBe(false);
  });

  it('renders folder loading and retry without inline API errors, preserving input validation', () => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    const instance = fixture.componentInstance;
    instance.folders.set([folder]);
    instance.selectFolder({ ...folder, assetType: 'DISCOVERSHAREDFOLDER' });
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.querySelector('[data-test-id="survey-move-folder-tree"]')).not.toBeNull();
    expect(element.querySelector('[data-test-id="survey-move-confirm-message"]')?.textContent)
      .toContain('SURVEYMOD_MOVE_CONFIRM_CONTENT');
    expect(translatePipe).toHaveBeenCalledWith('SURVEYMOD_MOVE_CONFIRM_CONTENT', { assetId: 'Folder' });
    instance.selectFolder(instance.rootFolder);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-confirm-message"]')).toBeNull();
    instance.foldersLoading.set(true);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-spinner"]')).not.toBeNull();
    expect(element.querySelector('[data-test-id="survey-move-folder-section"]')?.classList.contains('is-loading')).toBe(true);
    instance.foldersLoading.set(false);
    actions.fetchMoveFolders.mockReturnValueOnce(throwError(() => new Error('Failed')));
    instance.loadFolders();
    instance.renameTitle.set('');
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-retry"]')).not.toBeNull();
    expect(element.querySelector('[role="alert"]')).toBeNull();
    const field = fixture.debugElement.query(By.css('[data-test-id="survey-rename-title"]'));
    expect(field.properties['error']).toBe(true);
    expect(field.properties['errorMessage']).toBe('SURVEYMOD_FIELD_REQUIRED');
    fixture.debugElement.query(By.css('[data-test-id="survey-move-retry"]')).nativeElement.click();
    expect(instance.folderLoadFailed()).toBe(false);
    expect(actions.fetchMoveFolders).toHaveBeenCalledTimes(2);
    instance.folders.set([]);
    fixture.detectChanges();
    expect(element.querySelector('[data-test-id="survey-move-empty-state"]')?.textContent).toContain('SURVEYMOD_NO_FOLDERS');
  });

  it('wires the rendered Rename field and Update button to the mutation', () => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    fixture.detectChanges();
    const instance = fixture.componentInstance;
    Object.assign(instance, { renameDialog });
    instance.openRename(row);
    fixture.detectChanges();
    const field: HTMLElement = fixture.debugElement.query(By.css('[data-test-id="survey-rename-title"]')).nativeElement;
    expect(field.hasAttribute('label')).toBe(false);
    expect(field.getAttribute('title')).toBe('SURVEYMOD_ASSET_NAME');
    fixture.debugElement.query(By.css('[data-test-id="survey-rename-title"]'))
      .triggerEventHandler('ngModelChange', 'Renamed survey');
    fixture.detectChanges();
    fixture.debugElement.query(By.css('[data-test-id="survey-rename-save"]')).nativeElement.click();
    expect(actions.renameAsset).toHaveBeenCalledWith(row.assetId, 'Renamed survey');
    expect(renameDialog.close).toHaveBeenCalledOnce();
  });

  describe('Delete (trash) confirmation', () => {
    it('opens with a snapshot of the selection', () => {
      const folderRow: SurveyGridRow = { ...folder, lastModifiedTimestamp: 0 };
      const rows = [folderRow];
      component.openDelete(rows);
      rows.push({ ...row, assetId: 'another' });
      expect(component.deleteSelection().rows).toEqual([folderRow]);
      expect(deleteDialog.open).toHaveBeenCalledOnce();
    });

    it('trashes a single survey without confirmation and notifies only after success', () => {
      const request = new Subject<unknown>();
      actions.trashAssets.mockReturnValue(request);
      const changed = vi.spyOn(component.assetsChanged, 'emit');
      component.openDelete([row]);
      component.openDelete([row]);
      component.openDeletePermanently([{ ...row, assetId: 'another' }]);
      expect(actions.trashAssets).toHaveBeenCalledExactlyOnceWith([row]);
      expect(component.deleteSelection()).toEqual({ rows: [row], permanent: false });
      expect(component.deleteBusy()).toBe(true);
      expect(deleteDialog.open).not.toHaveBeenCalled();
      expect(changed).not.toHaveBeenCalled();
      expect(toast.InsertToast).not.toHaveBeenCalled();
      request.next({});
      request.complete();
      expect(component.deleteBusy()).toBe(false);
      expect(deleteDialog.close).not.toHaveBeenCalled();
      expect(changed).toHaveBeenCalledOnce();
      expect(toast.InsertToast).toHaveBeenCalledWith('success', 'SURVEYMOD_SURVEY_MOVED_TO_TRASH', expect.any(Object));
      expect(translateInstant).toHaveBeenCalledWith('SURVEYMOD_SURVEY_MOVED_TO_TRASH', { assetName: 'Survey' });
    });

    it('delegates a failed direct delete to exception handling and allows retry', () => {
      const failure = new Error('Failed');
      actions.trashAssets.mockReturnValueOnce(throwError(() => failure));
      const changed = vi.spyOn(component.assetsChanged, 'emit');
      component.openDelete([row]);
      expect(component.deleteBusy()).toBe(false);
      expect(changed).not.toHaveBeenCalled();
      expect(deleteDialog.open).not.toHaveBeenCalled();
      expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
      component.openDelete([row]);
      expect(actions.trashAssets).toHaveBeenCalledTimes(2);
      expect(changed).toHaveBeenCalledOnce();
    });

    it('keeps the dialog open on error and allows retry', () => {
      const request = new Subject<unknown>();
      actions.trashAssets.mockReturnValueOnce(request);
      const changed = vi.spyOn(component.assetsChanged, 'emit');
      const folderRow: SurveyGridRow = { ...folder, lastModifiedTimestamp: 0 };
      component.openDelete([folderRow]);
      expect(actions.trashAssets).not.toHaveBeenCalled();
      expect(deleteDialog.open).toHaveBeenCalledOnce();
      component.saveDeleteConfirmation();
      component.saveDeleteConfirmation();
      expect(actions.trashAssets).toHaveBeenCalledExactlyOnceWith([folderRow]);
      expect(component.deleteConfirmation().busy).toBe(true);
      expect(changed).not.toHaveBeenCalled();
      const failure = new Error('Failed');
      request.error(failure);
      expect(component.deleteBusy()).toBe(false);
      expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
      expect(deleteDialog.close).not.toHaveBeenCalled();
      expect(changed).not.toHaveBeenCalled();
      component.saveDeleteConfirmation();
      expect(deleteDialog.close).toHaveBeenCalledOnce();
      expect(changed).toHaveBeenCalledOnce();
    });
  });

  describe('Delete permanently confirmation (Trash tab)', () => {
    it('deletes permanently once and notifies the parent only after success', () => {
      const request = new Subject<unknown>();
      actions.deletePermanently.mockReturnValue(request);
      const changed = vi.spyOn(component.assetsChanged, 'emit');
      component.openDeletePermanently([row]);
      component.saveDeletePermanently();
      component.saveDeletePermanently();
      expect(actions.deletePermanently).toHaveBeenCalledExactlyOnceWith([row]);
      expect(component.deleteBusy()).toBe(true);
      request.next({});
      request.complete();
      expect(deleteDialog.close).toHaveBeenCalledOnce();
      expect(changed).toHaveBeenCalledOnce();
      expect(toast.InsertToast).toHaveBeenCalledWith('success', 'SURVEYMOD_PERMANENT_DELETE_SUCCESS', expect.any(Object));
      expect(translateInstant).toHaveBeenCalledWith('SURVEYMOD_PERMANENT_DELETE_SUCCESS', { assetName: 'Survey' });
    });

    it('keeps the dialog open on error and allows retry', () => {
      const failure = new Error('Failed');
      actions.deletePermanently.mockReturnValueOnce(throwError(() => failure));
      component.openDeletePermanently([row]);
      component.saveDeletePermanently();
      expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
      expect(component.deleteBusy()).toBe(false);
      expect(deleteDialog.close).not.toHaveBeenCalled();
      component.saveDeletePermanently();
      expect(deleteDialog.close).toHaveBeenCalledOnce();
    });
  });

  describe('Restore (no confirmation needed)', () => {
    it.each([
      { rows: [row], key: 'SURVEYMOD_RESTORE_SUCCESS', params: { assetName: 'Survey' } },
      { rows: [row, { ...row, assetId: 'second' }], key: 'SURVEYMOD_BULK_RESTORE_SUCCESS', params: undefined },
    ])('guards pending restores and notifies once: $key', ({ rows, key, params }) => {
      const request = new Subject<unknown>();
      actions.restoreAssets.mockReturnValueOnce(request);
      const changed = vi.spyOn(component.assetsChanged, 'emit');
      component.restore(rows);
      component.restore(rows);
      expect(actions.restoreAssets).toHaveBeenCalledExactlyOnceWith(rows);
      expect(component.restoreBusy()).toBe(true);
      expect(changed).not.toHaveBeenCalled();
      expect(toast.InsertToast).not.toHaveBeenCalled();
      request.next({});
      request.complete();
      expect(component.restoreBusy()).toBe(false);
      expect(toast.InsertToast).toHaveBeenCalledExactlyOnceWith('success', key, expect.any(Object));
      if (params) {
        expect(translateInstant).toHaveBeenCalledWith(key, params);
      } else {
        expect(translateInstant).toHaveBeenCalledWith(key);
      }
      expect(changed).toHaveBeenCalledOnce();
      component.restore(rows);
      expect(actions.restoreAssets).toHaveBeenCalledTimes(2);
    });

    it('delegates a failed restore to exception handling and does not notify the parent', () => {
      const failure = new Error('Failed');
      actions.restoreAssets.mockReturnValueOnce(throwError(() => failure));
      const changed = vi.spyOn(component.assetsChanged, 'emit');
      component.restore([row]);
      expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
      expect(toast.InsertToast).not.toHaveBeenCalled();
      expect(changed).not.toHaveBeenCalled();
      expect(component.restoreBusy()).toBe(false);
      component.restore([row]);
      expect(actions.restoreAssets).toHaveBeenCalledTimes(2);
      expect(changed).toHaveBeenCalledOnce();
    });

  });

  it.each(['openDelete', 'openDeletePermanently', 'restore'] as const)(
    '%s ignores an empty selection without opening a dialog or starting a mutation', (action) => {
      component[action]([]);
      expect(deleteDialog.open).not.toHaveBeenCalled();
      expect(actions.trashAssets).not.toHaveBeenCalled();
      expect(actions.deletePermanently).not.toHaveBeenCalled();
      expect(actions.restoreAssets).not.toHaveBeenCalled();
      expect(toast.InsertToast).not.toHaveBeenCalled();
    });

  it('wires the rendered folder picker, Move and Confirm buttons without moving prematurely', () => {
    const destination = { ...folder, assetType: 'DISCOVERSHAREDFOLDER' };
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    fixture.detectChanges();
    const instance = fixture.componentInstance;
    Object.assign(instance, { folderDialog, confirmDialog });
    instance.openMove([row]);
    fixture.detectChanges();
    fixture.debugElement.query(By.css('crf-uic-tree-forder-selector'))
      .triggerEventHandler('pathChange', destination);
    fixture.detectChanges();
    fixture.debugElement.query(By.css('[data-test-id="survey-move-select"]')).nativeElement.click();
    expect(folderDialog.close).toHaveBeenCalledOnce();
    expect(confirmDialog.open).toHaveBeenCalledOnce();
    expect(actions.moveAssets).not.toHaveBeenCalled();
    fixture.debugElement.query(By.css('[data-test-id="survey-move-confirm"]')).nativeElement.click();
    expect(actions.moveAssets).toHaveBeenCalledWith([row], destination);
    expect(confirmDialog.close).toHaveBeenCalledOnce();
  });

  it.each([
    {
      permanent: false,
      rows: [{ ...folder, lastModifiedTimestamp: 0 }],
      title: 'SURVEYMOD_MOVE_TO_TRASH',
      buttonLabel: 'SURVEYMOD_CONFIRM',
      messageKey: 'SURVEYMOD_FOLDER_TRASH_CONFIRM',
      messageParams: { assetName: 'Folder' },
      successKey: 'SURVEYMOD_ASSET_MOVED_TO_TRASH',
      successParams: { assetName: 'Folder' },
    },
    {
      permanent: false,
      rows: [row, { ...row, assetId: 'second' }],
      title: 'SURVEYMOD_MOVE_TO_TRASH',
      buttonLabel: 'SURVEYMOD_CONFIRM',
      messageKey: 'SURVEYMOD_BULK_TRASH_CONFIRM',
      messageParams: undefined,
      successKey: 'SURVEYMOD_BULK_ASSETS_MOVED_TO_TRASH',
      successParams: undefined,
    },
    ...[row, { ...folder, lastModifiedTimestamp: 0 }].map((asset) => ({
      permanent: true,
      rows: [asset],
      title: 'SURVEYMOD_CONFIRM_DELETION',
      buttonLabel: 'SURVEYMOD_DELETE',
      messageKey: 'SURVEYMOD_PERMANENT_DELETE_CONFIRM',
      messageParams: { assetName: asset.title },
      successKey: 'SURVEYMOD_PERMANENT_DELETE_SUCCESS',
      successParams: { assetName: asset.title },
    })),
    {
      permanent: true,
      rows: [row, { ...row, assetId: 'second' }],
      title: 'SURVEYMOD_DELETE_PERMANENTLY',
      buttonLabel: 'SURVEYMOD_CONFIRM',
      messageKey: 'SURVEYMOD_BULK_PERMANENT_DELETE_CONFIRM',
      messageParams: undefined,
      successKey: 'SURVEYMOD_BULK_PERMANENT_DELETE_SUCCESS',
      successParams: undefined,
    },
  ])('renders and submits $title for $rows (permanent: $permanent)', ({ permanent, rows, title, buttonLabel, messageKey, messageParams, successKey, successParams }) => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    fixture.detectChanges();
    const instance = fixture.componentInstance;
    Object.assign(instance, { deleteDialog });
    if (permanent) {
      instance.openDeletePermanently(rows);
    } else {
      instance.openDelete(rows);
    }
    fixture.detectChanges();
    const prefix = permanent ? 'survey-delete-permanent' : 'survey-delete';
    expect(fixture.nativeElement.querySelectorAll('niq-dialog')).toHaveLength(4);
    expect(fixture.debugElement.query(By.css(`[data-test-id="${prefix}-heading"]`)).nativeElement.textContent.trim()).toBe(title);
    expect(fixture.debugElement.query(By.css(`[data-test-id="${prefix}-message"]`)).nativeElement.textContent.trim()).toBe(messageKey);
    expect(translateInstant).toHaveBeenCalledWith(messageKey, ...(messageParams ? [messageParams] : []));
    const button = fixture.debugElement.query(By.css(`[data-test-id="${prefix}-confirm"]`)).nativeElement;
    expect(button.textContent.trim()).toBe(buttonLabel);
    expect(deleteDialog.open).toHaveBeenCalledOnce();
    expect(actions.trashAssets).not.toHaveBeenCalled();
    expect(actions.deletePermanently).not.toHaveBeenCalled();
    button.click();
    const mutation = permanent ? actions.deletePermanently : actions.trashAssets;
    const otherMutation = permanent ? actions.trashAssets : actions.deletePermanently;
    expect(mutation).toHaveBeenCalledExactlyOnceWith(rows);
    expect(otherMutation).not.toHaveBeenCalled();
    expect(deleteDialog.close).toHaveBeenCalledOnce();
    expect(toast.InsertToast).toHaveBeenCalledExactlyOnceWith('success', successKey, expect.any(Object));
    expect(translateInstant).toHaveBeenCalledWith(successKey, ...(successParams ? [successParams] : []));
  });

  it('switches delete modes safely and routes failures to exception handling without refreshing', () => {
    const fixture = TestBed.createComponent(SurveyAssetActionDialogsComponent);
    fixture.detectChanges();
    const instance = fixture.componentInstance;
    Object.assign(instance, { deleteDialog });
    const folderRow: SurveyGridRow = { ...folder, lastModifiedTimestamp: 0 };
    instance.openDelete([folderRow]);
    instance.openDeletePermanently([row]);
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('[data-test-id="survey-delete-confirm"]'))).toBeNull();
    const request = new Subject<unknown>();
    const changed = vi.spyOn(instance.assetsChanged, 'emit');
    actions.deletePermanently.mockReturnValue(request);
    instance.saveDeleteConfirmation();
    instance.openDelete([folderRow]);
    instance.openDeletePermanently([{ ...row, assetId: 'second' }]);
    instance.saveDeleteConfirmation();
    expect(instance.deleteSelection().rows).toEqual([row]);
    expect(instance.deleteConfirmation().permanent).toBe(true);
    expect(instance.deleteConfirmation().busy).toBe(true);
    expect(actions.deletePermanently).toHaveBeenCalledExactlyOnceWith([row]);
    expect(actions.trashAssets).not.toHaveBeenCalled();
    const failure = new Error('Failed');
    request.error(failure);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="alert"]')).toBeNull();
    expect(exceptionHandling.handleApiError).toHaveBeenCalledExactlyOnceWith(failure);
    expect(changed).not.toHaveBeenCalled();
    expect(deleteDialog.close).not.toHaveBeenCalled();
    expect(instance.deleteConfirmation().busy).toBe(false);
    instance.openDelete([folderRow]);
    expect(instance.deleteConfirmation().permanent).toBe(false);
  });
});
