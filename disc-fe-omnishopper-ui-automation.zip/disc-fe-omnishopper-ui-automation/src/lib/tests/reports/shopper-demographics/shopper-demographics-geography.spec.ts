import test from "@playwright/test";
import {
  hasPivotInDimensionSelections,
  getDimensionSelectionsByPivot,
  findDataSetByName,
  getTestDataByLocale
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { assert } from "@gfk/gta";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { ExportComponent } from "../../../common/components/export/export";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import prodTestData from "./test-data/prod-test-data.json";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;

const reportTestData = findDataSetByName(testData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;

const pivot: string = "Geography";
let savedReportTitle: string = "";
let savedReportUrl: string = "";


test.describe("Shopper Demographics - Geography Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;
  let formatPanel: FormatPanel;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);

    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });
  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.switchPivotDropdown(pivot);

      if (localeData.madlibText) {
        // Get the actual madlib text
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).geography;

        // Use toMatch for clearer error messages showing exact mismatch
        assert(actualMadlibText).toMatch(
          new RegExp(expectedMadlibText, "i")
        );

      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export",
    { tag: ["@Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);
          let basePage = await BasePageFactory.createBasePage();
          let dataSelector = new DataSelector(basePage);
          await dataSelector.navigateToUrl(reportUrl);
          await dataSelector.switchPivotDropdown(pivot);

          // Get Geography pivot data
          const geographyData = getDimensionSelectionsByPivot(pivot, reportTestData);

          await dataSelector.clickMadlibDimension("Retailer");
          await dataSelector.setMadlibSelection(
            geographyData["Retailer"]
          );

          await dataSelector.clickMadlibDimension("Geographies");
          await dataSelector.setMadlibSelection(
            geographyData["Geographies"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            geographyData["Period"]
          );

          await dataSelector.clickMadlibDimension("Comparison Period");
          await dataSelector.setPeriodMadlibSelection(
            geographyData["Comparison Period"]
          );

          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.selectClosedDropdown(
            geographyData["Facts"]["selections"]
          );

          await dataSelector.clickMadlibDimension("Demography");
          await dataSelector.selectClosedDropdown(
            geographyData["DemoGroup"]["selections"]
          );

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);
          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();
          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();
          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;
        }
      );

      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');
        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);
        await findMyStuff.clickFindMyStuff();
        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("FMS execution successful");
      })
    }
  );

});