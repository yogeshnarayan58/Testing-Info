import { describe, expect, it } from 'vitest';
import { QuestionTypes } from '../models/build-survey';
import {
  buildAnswerSpec,
  sanitizeFieldValue,
  stringFormat,
  toApiOptions,
  toApiQuestion,
  toTrimmedString,
} from './survey-payload.util';

describe('survey-payload.util', () => {
  describe('toApiQuestion', () => {
    it('should convert QuestionModel to API format with Single Choice', () => {
      const question = {
        question: 'What is your favorite color?',
        type: QuestionTypes.SingleChoice,
        options: ['Red', 'Blue', 'Green'],
        isRequired: true,
      };

      const result = toApiQuestion(question, 0);

      expect(result.id).toBe('q_1');
      expect(result.order).toBe('1');
      expect(result.type).toBe(QuestionTypes.SingleChoice);
      expect(result.required).toBe(true);
      expect(result.prompt.text).toBe('What is your favorite color?');
      expect(result.answerSpec.options).toBeDefined();
    });

    it('should throw error for unsupported question type', () => {
      const question = {
        question: 'Test',
        type: 'INVALID_TYPE',
        options: [],
        isRequired: false,
      };

      expect(() => toApiQuestion(question as any, 0)).toThrow('Unsupported question type');
    });

    it('should trim question text', () => {
      const question = {
        question: '  Question with spaces  ',
        type: QuestionTypes.Text,
        options: [],
        isRequired: false,
      };

      const result = toApiQuestion(question, 0);

      expect(result.prompt.text).toBe('Question with spaces');
    });

    it('should use empty text when the question text is missing', () => {
      const question = {
        type: QuestionTypes.Text,
        isRequired: false,
      };

      const result = toApiQuestion(question as any, 0);

      expect(result.prompt.text).toBe('');
    });

    it('should increment index correctly', () => {
      const question = {
        question: 'Test',
        type: QuestionTypes.Text,
        options: [],
        isRequired: false,
      };

      const result1 = toApiQuestion(question, 0);
      const result2 = toApiQuestion(question, 5);

      expect(result1.id).toBe('q_1');
      expect(result2.id).toBe('q_6');
      expect(result2.order).toBe('6');
    });
  });

  describe('stringFormat', () => {
    it('should lowercase string', () => {
      expect(stringFormat('HELLO', 'fallback')).toBe('hello');
    });

    it('should replace spaces with underscores', () => {
      expect(stringFormat('Hello World', 'fallback')).toBe('hello_world');
    });

    it('should remove special characters', () => {
        expect(stringFormat('Hello@World#123', 'fallback')).toBe('hello_world_123');
    });

    it('should trim leading and trailing underscores', () => {
      expect(stringFormat('__hello__', 'fallback')).toBe('hello');
    });

    it('should return fallback for empty string after formatting', () => {
      expect(stringFormat('!!!', 'default_value')).toBe('default_value');
    });

    it('should return fallback for empty input', () => {
      expect(stringFormat('', 'default_value')).toBe('default_value');
    });
  });

  describe('toApiOptions', () => {
    it('should convert string array to API options', () => {
      const result = toApiOptions(['Option 1', 'Option 2', 'Option 3']);

      expect(result).toHaveLength(3);
      expect(result[0]).toEqual({ value: 'option_1', label: 'Option 1' });
      expect(result[1]).toEqual({ value: 'option_2', label: 'Option 2' });
      expect(result[2]).toEqual({ value: 'option_3', label: 'Option 3' });
    });

    it('should trim option values', () => {
      const result = toApiOptions(['  Option 1  ', '  Option 2  ']);

      expect(result[0].label).toBe('Option 1');
      expect(result[1].label).toBe('Option 2');
    });

    it('should filter out empty options', () => {
      const result = toApiOptions(['Option 1', '', null, 'Option 2']);

      expect(result).toHaveLength(2);
    });

    it('should handle undefined input', () => {
      const result = toApiOptions(undefined);

      expect(result).toEqual([]);
    });

    it('should handle null input', () => {
      const result = toApiOptions(null as any);

      expect(result).toEqual([]);
    });

    it('should generate sequential values for options with special characters', () => {
      const result = toApiOptions(['Very Long Option Name!', '@#$%', 'Another One']);

      expect(result[0].value).toBe('very_long_option_name');
      expect(result[1].value).toBe('option_2');
      expect(result[2].value).toBe('another_one');
    });
  });

  describe('buildAnswerSpec', () => {
    it('should build answerSpec for SingleChoice', () => {
      const question = {
        type: QuestionTypes.SingleChoice,
        options: ['A', 'B'],
        isRequired: true,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.options).toHaveLength(2);
      expect(result.validation.minSelections).toBe(1);
      expect(result.validation.maxSelections).toBe(1);
    });

    it('should build answerSpec for MultipleChoice', () => {
      const question = {
        type: QuestionTypes.MultipleChoice,
        options: ['A', 'B', 'C'],
        isRequired: false,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.options).toHaveLength(3);
      expect(result.validation.minSelections).toBe(0);
      expect(result.validation.maxSelections).toBe(3);
    });

    it('should build answerSpec for NetPromoterScore', () => {
      const question = {
        type: QuestionTypes.NetPromoterScore,
        npsLeftLabel: 'Very Unlikely',
        npsRightLabel: 'Very Likely',
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.min).toBe(0);
      expect(result.answerSpec.max).toBe(10);
      expect(result.answerSpec.anchors.min).toBe('Very Unlikely');
      expect(result.answerSpec.anchors.max).toBe('Very Likely');
    });

    it('should use default NPS labels when not provided', () => {
      const question = {
        type: QuestionTypes.NetPromoterScore,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.anchors.min).toBe('Not at all likely');
      expect(result.answerSpec.anchors.max).toBe('Extremely likely');
    });

    it('should build answerSpec for StarRating', () => {
      const question = {
        type: QuestionTypes.StarRating,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.min).toBe(1);
      expect(result.answerSpec.max).toBe(5);
      expect(result.validation.minValue).toBe(1);
      expect(result.validation.maxValue).toBe(5);
    });

    it('should build answerSpec for SinglePointScale', () => {
      const question = {
        type: QuestionTypes.SinglePointScale,
        rowOptions: ['Quality', 'Value'],
        columnOptions: ['Low', 'Medium', 'High'],
        isRequired: true,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.columns).toHaveLength(3);
      expect(result.answerSpec.rows).toEqual([{ value: 'quality', label: 'Quality' }, { value: 'value', label: 'Value' }]);
      expect(result.answerSpec).not.toHaveProperty('options');
      expect(result.validation.maxSelections).toBe(1);
      expect(result.validation.minSelections).toBe(1);
    });

    it('should use options as fallback for SinglePointScale when columnOptions missing', () => {
      const question = {
        type: QuestionTypes.SinglePointScale,
        options: ['A', 'B'],
        columnOptions: undefined,
        isRequired: false,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.columns).toHaveLength(2);
    });

    it('should build answerSpec for MultiplePointScale', () => {
      const question = {
        type: QuestionTypes.MultiplePointScale,
        rowOptions: ['Row 1', 'Row 2'],
        columnOptions: ['Col 1', 'Col 2', 'Col 3'],
        isRequired: true,
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec.rows).toHaveLength(2);
      expect(result.answerSpec.columns).toHaveLength(3);
      expect(result.validation.minSelections).toBe(1);
    });

    it('should handle unknown question type', () => {
      const question = {
        type: 'UNKNOWN_TYPE',
      };

      const result = buildAnswerSpec(question as any);

      expect(result.answerSpec).toEqual({});
      expect(result.validation).toEqual({});
    });
  });

  describe('sanitizeFieldValue', () => {
    it('should trim string fields', () => {
      expect(sanitizeFieldValue('question', '  Test Question  ')).toBe('Test Question');
      expect(sanitizeFieldValue('npsLeftLabel', '  Label  ')).toBe('Label');
      expect(sanitizeFieldValue('npsRightLabel', '  Label  ')).toBe('Label');
    });

    it('should convert non-string to string for text fields', () => {
      expect(sanitizeFieldValue('question', null)).toBe('');
      expect(sanitizeFieldValue('question', undefined)).toBe('');
      expect(sanitizeFieldValue('question', 123)).toBe('123');
    });

    it('should sanitize array fields', () => {
      const result = sanitizeFieldValue('options', ['  A  ', '  B  ', '  C  ']);

      expect(result).toEqual(['A', 'B', 'C']);
    });

    it('should return empty array for non-array value of array fields', () => {
      expect(sanitizeFieldValue('options', 'not an array')).toEqual([]);
      expect(sanitizeFieldValue('rowOptions', null)).toEqual([]);
    });

    it('should return value as-is for other fields', () => {
      expect(sanitizeFieldValue('type', 'SingleChoice')).toBe('SingleChoice');
      expect(sanitizeFieldValue('isRequired', true)).toBe(true);
      expect(sanitizeFieldValue('unknown', { data: 'value' })).toEqual({ data: 'value' });
    });
  });

  describe('toTrimmedString', () => {
    it('should trim string values', () => {
      expect(toTrimmedString('  Hello World  ')).toBe('Hello World');
    });

    it('should return empty string for non-string input', () => {
      expect(toTrimmedString(null)).toBe('');
      expect(toTrimmedString(undefined)).toBe('');
      expect(toTrimmedString(123)).toBe('');
      expect(toTrimmedString({ key: 'value' })).toBe('');
    });

    it('should handle empty string', () => {
      expect(toTrimmedString('')).toBe('');
    });

    it('should handle whitespace-only string', () => {
      expect(toTrimmedString('   ')).toBe('');
    });
  });
});
