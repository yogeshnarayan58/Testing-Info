import { Injectable, SecurityContext, computed, inject, signal } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { GridDataSourceService } from '@nielsen/crf-lp-common';
import { ToastService } from '@nielseniq/athena-core';
import { ToastTime } from '@nielseniq/crf-discover-fe-core';
import { IGetRowsParams } from 'ag-grid-community';
import { defer, Observable, of, Subject } from 'rxjs';
import { catchError, finalize, map, takeUntil, tap } from 'rxjs/operators';
import { SurveyService } from '../../build-survey/services/survey.service';
import { SurveyStatusType } from '../../build-survey/models/build-survey';
import { SurveyCommonService } from '../../../shared/services/survey-common.service';
import {
  SurveyGridActionEvent,
  SurveyGridActionType,
  MY_ASSETS_GRID_PAGE_SIZE,
  MY_ASSETS_FOLDER_BREADCRUMB_TABS,
  MY_ASSETS_TABS_LIST,
  MY_ASSETS_TABS,
  MyAssetsTabId,
  EMPTY_VALUE_PLACEHOLDER
} from '../constants/my-assets-tabs.constant';
import {
  SurveyGridAsset,
  SurveyGridLoadType,
  SurveyGridRow,
  SurveyGridRowsLoadedEvent,
  SurveyGridRowUpdate
} from '../models/survey-asset.model';
import { SurveyAssetApiService } from './survey-asset-api.service';
import { getStatusDisplay, isFolderAsset } from '../utils/survey-status.util';
import { getMyAssetsFolderUrl, getMyAssetsTabUrl } from '../utils/my-assets-route.util';

@Injectable({
  providedIn: 'root',
})
export class SurveyGridHandlerService implements GridDataSourceService<SurveyGridRow[]> {
  readonly pageSize = MY_ASSETS_GRID_PAGE_SIZE;
  private readonly pendingLoads = signal(0);
  readonly isLoading = computed(() => this.pendingLoads() > 0);
  loadFailed = false;
  activeFolderId: string | null = null;
  /** Last data update time per My Assets URL, kept across tab visits so cached views keep their original time. */
  readonly viewUpdatedAt = new Map<string, number>();
  private readonly folderChanged = new Subject<void>();
  private readonly rowUpdatedSubject = new Subject<SurveyGridRowUpdate>();
  /** Emits when a row is mutated outside the grid's data fetch so cell templates can re-render. */
  readonly rowUpdated$ = this.rowUpdatedSubject.asObservable();
  private readonly deleteRequestedSubject = new Subject<SurveyGridRow>();
  readonly deleteRequested$ = this.deleteRequestedSubject.asObservable();
  private readonly rowsLoadedSubject = new Subject<SurveyGridRowsLoadedEvent>();
  /** Emits the outcome of every grid page load and whether it loaded the current view or paginated. */
  readonly rowsLoaded$ = this.rowsLoadedSubject.asObservable();

  private readonly surveyAssetApi = inject(SurveyAssetApiService);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly router = inject(Router);
  private readonly surveyService = inject(SurveyService);
  private readonly surveyCommonService = inject(SurveyCommonService);
  private readonly toastService = inject(ToastService);
  private readonly menuActionHandlers: Record<SurveyGridActionType, (row: SurveyGridRow) => void> = {
    open: (row) => this.onOpenInCurrentWindow(row),
    'open-new-tab': (row) => this.onOpenInNewWindow(row),
    favorite: (row) => this.onFavoriteSurvey(row),
    duplicate: (row) => this.onDuplicateSurvey(row),
    info: (row) => this.onShowSurveyInfo(row),
    edit: (row) => this.onEditSurvey(row),
    trash: (row) => this.deleteRequestedSubject.next(row),
  };

  /** Validates and dispatches an action emitted by the infinite grid. */
  onMenuAction(event: SurveyGridActionEvent<unknown>): void {
    if (!this.isSurveyGridActionType(event.optionType) || !this.isSurveyGridRow(event.row)) {
      return;
    }

    this.menuActionHandlers[event.optionType]?.(event.row);
  }

  /** Loads one grid page; the common infinite grid owns block caching and reuse. */
  getRows(
    rowsParams: IGetRowsParams,
    pageSize: number,
    gridContext: unknown
  ): Observable<[SurveyGridRow[], number]> {
    const folderId = this.activeFolderId;
    const rows = folderId
      ? this.fetchFolderRows(rowsParams, pageSize, folderId, this.getTab(gridContext))
      : this.fetchRows(rowsParams, pageSize, this.getTab(gridContext));
    return defer(() => {
      this.pendingLoads.update((count) => count + 1);
      let receivedResponse = false;
      return rows.pipe(
        tap(() => { receivedResponse = true; }),
        takeUntil(this.folderChanged),
        finalize(() => {
          this.pendingLoads.update((count) => count - 1);
          // Tell the grid the cancelled load has ended so it can load the current folder.
          if (!receivedResponse) {
            rowsParams.failCallback();
          }
        })
      );
    });
  }

  // Cancel the previous folder's load so its response cannot affect the current folder.
  setActiveFolder(folderId: string | null): void {
    if (this.activeFolderId === folderId) {
      return;
    }
    this.activeFolderId = folderId;
    this.folderChanged.next();
  }

  // Loads immediate children for the active folder and maps them to the grid row shape.
  private fetchFolderRows(
    rowsParams: IGetRowsParams,
    pageSize: number,
    folderId: string,
    tab: MyAssetsTabId
  ): Observable<[SurveyGridRow[], number]> {
    this.loadFailed = false;
    return this.surveyAssetApi.fetchFolderChildren(
      folderId,
      rowsParams.startRow,
      pageSize,
      rowsParams.sortModel,
      tab
    ).pipe(
      map(({ assets, totalCount }) => {
        return [assets.map((asset) => {
          const statusDisplay = getStatusDisplay(asset);
          return { ...asset, statusDisplay, statusLabel: statusDisplay?.label ?? EMPTY_VALUE_PLACEHOLDER };
        }), totalCount] as [SurveyGridRow[], number];
      }),
      tap(() => this.emitRowsLoaded(true, rowsParams)),
      catchError(() => {
        this.loadFailed = true;
        this.emitRowsLoaded(false, rowsParams);
        this.toastService.InsertToast('error', 'Something went wrong, please try again.', {
          dismissAfter: ToastTime.DISMISSAFTER,
          size: 'large',
        });
        return of([[], 0] as [SurveyGridRow[], number]);
      })
    );
  }

  /** Fetches and enriches API assets with the display state used by the templates. */
  private fetchRows(
    rowsParams: IGetRowsParams,
    pageSize: number,
    tab: MyAssetsTabId
  ): Observable<[SurveyGridRow[], number]> {
    const { startRow, endRow, sortModel } = rowsParams;
    this.loadFailed = false;

    return this.surveyAssetApi.fetchSurveyAssets(startRow, endRow, sortModel, pageSize, tab).pipe(
      map((assetResponse: { assets: SurveyGridAsset[]; totalCount: number }) => {
        const { assets, totalCount } = assetResponse;
        if (!assets.length) {
          return [[], totalCount] as [SurveyGridRow[], number];
        }

        const mergedRows = assets.map((asset: SurveyGridAsset) => {
          const statusDisplay = getStatusDisplay(asset);
          return {
            ...asset,
            statusDisplay,
            statusLabel: statusDisplay?.label ?? EMPTY_VALUE_PLACEHOLDER,
          };
        });

        return [mergedRows, totalCount] as [SurveyGridRow[], number];
      }),
      tap(() => this.emitRowsLoaded(true, rowsParams)),
      // crf-lp-infinite-grid has no error handler; keep its fallback while distinguishing it from an empty result.
      catchError(() => {
        this.loadFailed = true;
        this.emitRowsLoaded(false, rowsParams);
        this.toastService.InsertToast('error', 'Something went wrong, please try again.', {
          dismissAfter: ToastTime.DISMISSAFTER,
          size: 'large',
        });
        return of([[], 0] as [SurveyGridRow[], number]);
      })
    );
  }

  // crf-lp-infinite-grid re-requests row 0 on initial load, view changes and refreshData(); later blocks are scroll pagination.
  private emitRowsLoaded(success: boolean, rowsParams: IGetRowsParams): void {
    const loadType: SurveyGridLoadType = rowsParams.startRow > 0 ? 'pagination' : 'current-view';
    this.rowsLoadedSubject.next({ success, loadType });
  }

  /** Reads the active tab from the context supplied by crf-lp-infinite-grid. */
  private getTab(gridContext: unknown): MyAssetsTabId {
    if (gridContext && typeof gridContext === 'object' && 'currentTab' in gridContext) {
      const currentTab = gridContext.currentTab;
      if (typeof currentTab === 'string' && Object.values(MY_ASSETS_TABS).includes(currentTab as MyAssetsTabId)) {
        return currentTab as MyAssetsTabId;
      }
    }

    return MY_ASSETS_TABS.MY_ASSETS;
  }

  /** Narrows a string to a supported grid action type. */
  private isSurveyGridActionType(optionType: string): optionType is SurveyGridActionType {
    return optionType in this.menuActionHandlers;
  }

  /** Ensures the payload is a survey row before using it. */
  private isSurveyGridRow(row: unknown): row is SurveyGridRow {
    return !!row && typeof row === 'object' && 'assetId' in row && typeof row.assetId === 'string';
  }

  /** Sanitizes and validates a launch URL before opening a new browser tab. */
  private getSafeLaunchUrl(value: string, status?: string): string | null {
    try {
      const sanitizedValue = this.sanitizer.sanitize(SecurityContext.URL, value);
      if (!sanitizedValue || sanitizedValue.startsWith('unsafe:')) {
        return null;
      }

      const launchPath = sanitizedValue.replace(/^\/+/, '');
      const url = new URL(launchPath, document.baseURI);
      if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        return null;
      }
      if (status?.toUpperCase() === SurveyStatusType.FAILED) {
        url.pathname = url.pathname.replace(/(^|\/)results(?=\/|$)/, '$1build-survey');
      }

      return url.toString();
    } catch {
      return null;
    }
  }

  /** Opens the survey in the same window. */
  private onOpenInCurrentWindow(row: SurveyGridRow): void {
    if (isFolderAsset(row)) {
      const currentTab = this.getActiveTabFromUrl();
      if (!MY_ASSETS_FOLDER_BREADCRUMB_TABS.includes(currentTab)) {
        return;
      }
      this.navigateToFolder(row, currentTab);
      return;
    }

    if (!row.launchURL || !row.sourceId) {
      return;
    }

    const safe = this.getSafeLaunchUrl(row.launchURL, row.status);
    if (!safe) {
      return;
    }

    if (safe.startsWith(document.baseURI)) {
      // Router navigation preserves services; clear the previous survey's session and cache.
      this.surveyCommonService.resetState();
      this.surveyService.reset();
      void this.router.navigateByUrl(safe.replace(document.baseURI, '/'));
    }
  }

  private navigateToFolder(row: SurveyGridRow, tab: MyAssetsTabId): void {
    const rootUrl = getMyAssetsTabUrl(this.router.url, tab);
    const folderUrl = getMyAssetsFolderUrl(this.router.url, tab, row.assetId);
    const parentBreadcrumbs = history.state?.folderBreadcrumbs as Array<{ label: string; url: string }> | undefined;
    const folderBreadcrumbs = [
      ...(parentBreadcrumbs ?? [{ label: this.getTabLabel(tab), url: rootUrl }]),
      { label: row.title, url: folderUrl },
    ];
    void this.router.navigateByUrl(folderUrl, {
      state: this.activeFolderId && !parentBreadcrumbs?.length
        ? {}
        : { folderAsset: row, folderBreadcrumbs },
    });
  }

  // Resolves tab label from the shared tab constant for breadcrumb root text.
  private getTabLabel(tabId: MyAssetsTabId): string {
    return MY_ASSETS_TABS_LIST.find((tab) => tab.id === tabId)?.label ?? 'My assets';
  }

  // Reads the active My Assets tab from the current URL and falls back to My assets.
  private getActiveTabFromUrl(): MyAssetsTabId {
    const segments = (this.router.url ?? '').split(/[?#]/, 1)[0].split('/').filter(Boolean);
    const tabId = [...segments].reverse().find((segment) => Object.values(MY_ASSETS_TABS).includes(segment as MyAssetsTabId));
    return (tabId as MyAssetsTabId | undefined) ?? MY_ASSETS_TABS.MY_ASSETS;
  }

  /** Opens a survey only when its URL and source identifier are valid. */
  private onOpenInNewWindow(row: SurveyGridRow): void {
    if (!row.launchURL || !row.sourceId) {
      return;
    }

    const safe = this.getSafeLaunchUrl(row.launchURL, row.status);
    if (!safe) {
      return;
    }

    const newWin = window.open(safe, '_blank');
    try {
      if (newWin) {
        newWin.opener = null;
      }
    } catch {
      // Ignore cross-origin assignment failures.
    }
  }

  /** Starts a new draft populated from the selected survey. */
  private onDuplicateSurvey(row: SurveyGridRow): void {
    const surveyId = row.sourceId?.trim();
    if (!surveyId) {
      return;
    }

    const isAiFlow = row.launchURL?.includes('/aiflow/') ?? false;
    this.surveyService.setDuplicateFromId(surveyId);
    this.router.navigate(isAiFlow ? ['/survey/aiflow/build-survey'] : ['/survey/build-survey']);
  }

  /** Toggles the favorite state via the API and reflects it on the row once saved. */
  private onFavoriteSurvey(row: SurveyGridRow): void {
    const isMyFavorite = !row.isMyFavorite;
    this.surveyAssetApi.updateFavorite(row.assetId, isMyFavorite).subscribe({
      next: () => {
        row.isMyFavorite = isMyFavorite;
        this.rowUpdatedSubject.next({ action: 'favorite', row });
        const message = isMyFavorite
          ? `Your asset ${row.title} has been added to favorites`
          : `Your asset ${row.title} has been removed from favorites`;
        this.toastService.InsertToast('success', message, { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
      },
      error: () => {
        this.toastService.InsertToast('error', 'Failed to update favorite. Please try again.', { dismissAfter: ToastTime.DISMISSAFTER, size: 'large' });
      },
    });
  }

  /** Updates the URL so the host flow can display survey information. */
  private onShowSurveyInfo(row: SurveyGridRow): void {
  }

  /** Switches the current URL into edit mode for the selected survey. */
  private onEditSurvey(row: SurveyGridRow): void {
    const editUrl = new URL(window.location.href);
    editUrl.searchParams.set('surveyId', row.assetId);
    editUrl.searchParams.set('mode', 'edit');
    window.history.replaceState({}, '', editUrl.toString());
  }

}
