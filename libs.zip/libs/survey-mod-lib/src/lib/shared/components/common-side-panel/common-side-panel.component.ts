import { DOCUMENT } from '@angular/common';
import { ChangeDetectionStrategy, Component, ElementRef, afterRenderEffect, inject, input, output, signal } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IconButtonModule, SidePanelModule } from '@nielseniq/athena-core';
import { HeaderImgConfig } from './common-side-panel.model';

export const DEFAULT_SIDE_PANEL_WIDTH = 336;
const WRAPPER_SELECTOR = 'survey-crf-survey-wrapper';
const STEPPER_PANEL_GAP = 8;

@Component({
  selector: 'survey-common-side-panel',
  standalone: true,
  imports: [SidePanelModule, IconButtonModule, TranslateModule],
  templateUrl: './common-side-panel.component.html',
  styleUrl: './common-side-panel.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[class.is-open]': 'open()',
    '[class.viewport-height]': 'open() && panelTop() !== null',
    '[style.--panel-width]': 'width() + "px"',
    '[style.--panel-top]': 'panelTop() === null ? null : panelTop() + "px"',
    '(document:click)': 'onDocumentClick($event)',
  },
})
export class CommonSidePanelComponent {
  readonly open = input(false);
  readonly title = input('Survey details');
  readonly width = input(DEFAULT_SIDE_PANEL_WIDTH);
  readonly closeOnOutsideClick = input(true);
  readonly closeRequested = output<void>();
  readonly panelTop = signal<number | null>(null);
  private readonly element = inject<ElementRef<HTMLElement>>(ElementRef);
  readonly headerImgConfig = input<HeaderImgConfig>();
  private readonly document = inject(DOCUMENT);

  constructor() {
    // Athena creates its panel surface only after the open input is rendered.
    afterRenderEffect((onCleanup) => {
      const restoreLayout = this.updatePanelLayout();
      if (restoreLayout) {
        onCleanup(restoreLayout);
      }
    });
  }

  private updatePanelLayout(): (() => void) | void {
    if (!this.open()) {
      this.panelTop.set(null);
      return;
    }
    const topnav = this.document.querySelector<HTMLElement>('.topnav');
    // The survey wrapper has no host topnav, so the panel spans from the top of the wrapper (stepper) instead.
    const wrapper = topnav ? null : this.element.nativeElement.closest<HTMLElement>(WRAPPER_SELECTOR);
    const anchor = topnav ?? wrapper;
    const surface = this.element.nativeElement.querySelector<HTMLElement>('.survey-side-panel');
    if (!anchor || !surface) {
      this.panelTop.set(null);
      return;
    }
    this.panelTop.set(anchor.getBoundingClientRect().top);
    const restorations: Array<() => void> = [];
    const setTemporaryStyle = (element: HTMLElement, property: string, value: string, priority = '') => {
      const originalValue = element.style.getPropertyValue(property);
      const originalPriority = element.style.getPropertyPriority(property);
      element.style.setProperty(property, value, priority);
      restorations.push(() => {
        if (originalValue) {
          element.style.setProperty(property, originalValue, originalPriority);
        } else {
          element.style.removeProperty(property);
        }
      });
    };
    if (!topnav) {
      // Keep the stepper's trailing steps out from under the fixed panel surface.
      const stepper = wrapper?.querySelector<HTMLElement>('.stepper-wrapper');
      if (stepper) {
        setTemporaryStyle(stepper, 'padding-right', `${this.width() + STEPPER_PANEL_GAP}px`);
      }
      return () => restorations.forEach((restore) => restore());
    }
    // The shell flex item's automatic minimum otherwise keeps the entire page at its content width.
    const shellContent = topnav.closest<HTMLElement>('.fms-content');
    if (shellContent) {
      setTemporaryStyle(shellContent, 'min-width', '0');
    }
    // The fixed surface sits at the viewport edge, so shell right padding would add a second gutter.
    setTemporaryStyle(topnav, 'padding-right', '0', 'important');
    const header = topnav.querySelector<HTMLElement>('.page-header');
    if (header) {
      const panelWidth = this.width();
      const headerLeft = header.getBoundingClientRect().left;
      setTemporaryStyle(header, 'max-width', `max(0px, calc(100vw - ${panelWidth}px - ${headerLeft}px))`);
      setTemporaryStyle(header, 'min-width', '0');
      setTemporaryStyle(header, 'box-sizing', 'border-box');
    }
    return () => {
      for (const restore of restorations) {
        restore();
      }
    };
  }

  requestClose(): void {
    this.closeRequested.emit();
  }

  onDocumentClick(event: MouseEvent): void {
    if (!this.open() || !this.closeOnOutsideClick()
      || event.composedPath().includes(this.element.nativeElement)) {
      return;
    }
    this.requestClose();
  }
}