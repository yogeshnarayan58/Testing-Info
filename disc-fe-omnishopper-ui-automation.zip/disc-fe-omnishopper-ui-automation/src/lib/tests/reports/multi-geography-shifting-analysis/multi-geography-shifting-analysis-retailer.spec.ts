import test from "@playwright/test";
import {
  findDataSetByName,
  getTestDataByLocale,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import localizationData from "./test-data/localization-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { getDataElement } from "../../test-cases/common-test-cases-helper-service";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Retailer";

if (reportTestData) {
  test.describe("Multi-Geography Shifting Analysis - Retailer Pivot", async () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;

    test.describe.serial(
      "Run, PPT Export, Excel Export",
      { tag: ["@Report_E2E_Flow"] },
      () => {
        test(
          "Report Generation: Validates dimension selection and successful execution with Retailer pivot",
          {
            tag: "@RunReport",
          },
          async () => {
            // Set timeout to 4 minutes (240,000 ms) for this test only
            test.setTimeout(4 * 60 * 1000);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);
            await dataSelector.clickAdditionalPromptEllipsisIcon();

            await dataSelector.switchPivotDropdown(pivot);

            await dataSelector.clickMadlibDimension("Shifting Universe Retailer");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[1]["Shifting Universe Retailer"]
            );
            console.log("selected shifting universe retailer");
            await dataSelector.clickMadlibDimension("Product");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[1]["Product"]
            );
            console.log("selected product");
            await dataSelector.clickMadlibDimension("Comparison Retailers");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[1]["Comparison Retailers"]
            );
            console.log("selected comparison retailers");
            await dataSelector.clickMadlibDimension("Geographies");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[1]["Geographies"]
            );
            console.log("selected geographies");
            await dataSelector.clickMadlibDimension("Period");
            await dataSelector.setPeriodMadlibSelection(
              reportTestData.dimensionSelections[1]["Period"] as any
            );
            console.log("selected period");
            await dataSelector.clickMadlibDimension("Comparison Period");
            await dataSelector.setPeriodMadlibSelection(
              reportTestData.dimensionSelections[1]["Comparison Period"] as any
            );
            console.log("selected comparison period");
            await dataSelector.clickMadlibDimension("Demographic");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[1]["Demographic"]
            );
            console.log("selected demographic");
            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.selectClosedDropdown(
              reportTestData.dimensionSelections[1]["Facts"]["selections"]
            );

            // await dataSelector.clickMadlibDimension("People");
            // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
            // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
            // for (const selection of reportTestData.dimensionSelections[1]["People"]
            //   .selections) {
            //   await dataSelector.handlePeopleMenuOptions(selection);
            // }

            console.log("selected facts");
            let dsBasePage = await dataSelector.getBasePage();
            commonTestCase = new CommonTestCase(dsBasePage);
            await commonTestCase.clickRunButton();
            await commonTestCase.waitForReportRunCompletion();
            console.log("run complete in spec");
            const { newReportTitle, newUrl } =
              await commonTestCase.saveReport();
            savedReportTitle = newReportTitle;
            savedReportUrl = newUrl;
            console.log("savedReportTitle:", savedReportTitle);
            console.log("savedReportUrl:", savedReportUrl);
          }
        );
        test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
          test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

          let basePage = await BasePageFactory.createBasePage();
          let findMyStuff = new FindMyStuff(basePage);
          await findMyStuff.navigateToUrl(config.BASE_URL);

          await findMyStuff.openCurrentReportFMS(savedReportTitle);

          console.log("Open current report from FMS - Report visible in UI");
        });
        test(
          "Validate PPT export",
          {
            tag: "@ValidatePPTExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
          }
        );

        test(
          "Validate Excel export",
          {
            tag: "@ValidateExcelExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality(
              "Excel",
              "Editable objects",
              "Separately"
            );
          }
        );
      }
    );
  });
} else {
  console.warn(
    `::warning title=Missing Test Data::Test suite "Multi-Geography Shifting Analysis - Retailer Pivot" skipped because required test data was not found.`
  );
}
