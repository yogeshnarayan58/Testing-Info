/**
 * Timeout constant for general test operations (2 minutes)
 */
export const MAX_TEST_TIMEOUT = 2 * 60 * 1000; // 120,000 ms

/**
 * Timeout constant for Run function (5 minutes)
 */
export const RUN_TEST_TIMEOUT = 5 * 60 * 1000; // 300,000 ms

/**
 * Timeout constant for navigation operations (1 minute)
 */
export const NAVIGATION_TIMEOUT = 60 * 1000; // 60,000 ms

/**
 * Timeout constant for report title to appear after dataset selection (2 minutes)
 */
export const TITLE_APPEARANCE_TIMEOUT = 2 * 60 * 1000; // 120,000 ms

/**
 * Timeout constant for small actions/assertions (5 seconds)
 */
export const SMALL_TIMEOUT = 5 * 1000; // 5,000 ms

/**
 * Timeout constant for polling intervals (300 milliseconds)
 */
export const POLLING_INTERVAL = 300; // 300 ms

/**
 * Timeout constant for element wait operations (15 seconds)
 */
export const ELEMENT_WAIT_TIMEOUT = 15 * 1000; // 15,000 ms

/**
 * Timeout constant for dataset selector operations (3 seconds)
 */
export const DATASET_SELECTOR_TIMEOUT = 3 * 1000; // 3,000 ms

/**
 * Delay for dataset processing operations (2 seconds)
 */
export const DATASET_PROCESSING_DELAY = 2 * 1000; // 2,000 ms

/**
 * Delay for hover activation and CSS pseudo-element rendering (1 second)
 */
export const HOVER_ACTIVATION_DELAY = 1 * 1000; // 1,000 ms

/**
 * Delay for madlib component appearance (3 seconds)
 */
export const MADLIB_APPEARANCE_DELAY = 3 * 1000; // 3,000 ms

/**
 * Delay for UI state updates and DOM stabilization (500 milliseconds)
 */
export const UI_STATE_UPDATE_DELAY = 500; // 500 ms