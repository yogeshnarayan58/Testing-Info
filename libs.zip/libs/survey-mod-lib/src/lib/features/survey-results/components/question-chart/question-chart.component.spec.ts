import { TranslateModule } from '@ngx-translate/core';
import type { QuestionChartContext, QuestionChartPreview } from '../../models/question-result';
import { signal } from '@angular/core';
import { readFileSync } from 'node:fs';
import { By } from '@angular/platform-browser';
import { TestBed } from '@angular/core/testing';
import { of, Subject, throwError } from 'rxjs';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { QuestionChartComponent } from './question-chart.component';
import { QuestionChartPreviewService } from '../../services/question-chart-preview.service';
import { BAR_CHART_RESPONSE, HEAT_GRID_PREVIEW_RESPONSE, NORMAL_GRID_PREVIEW_RESPONSE } from '../../constants/survey-results-preview';
import { QuestionTypes } from '../../../build-survey/models/build-survey';

vi.mock('../grid/grid.component', async () => {
  const { Component } = await import('@angular/core');
  class MockGrid {}
  Component({ selector: 'survey-grid', standalone: true, template: '',
    inputs: ['response'] })(MockGrid);
  return { GridComponent: MockGrid };
});

vi.mock('@nielseniq/athena-charts', async () => {
  const { Component } = await import('@angular/core');
  const chart = (selector: string) => {
    class MockChart {}
    Component({ selector, standalone: true, template: '',
      inputs: ['data', 'configs', 'properties', 'metadata', 'chartTitle'] })(MockChart);
    return MockChart;
  };
  return {
    NiqHighchartBarChartComponent: chart('niq-highchart-bar'),
    NiqHighchartColumnChartComponent: chart('niq-highchart-column'),
    NiqHighchartPieChartComponent: chart('niq-highchart-pie'),
  };
});

const template = readFileSync('libs/survey-mod-lib/src/lib/features/survey-results/components/question-chart/question-chart.component.html', 'utf8');
const context: QuestionChartContext = { surveyId: 'survey-1', surveyTitle: 'Survey',
  question: { qid: 'question-2', type: 'SINGLE_CHOICE', title: 'Question two' } };

async function setup(load: ReturnType<typeof vi.fn>, type = 'MULTIBAR_HORIZONTAL', loadGrid = vi.fn().mockReturnValue(of(NORMAL_GRID_PREVIEW_RESPONSE.components[0])), questionContext = context) {
  vi.useFakeTimers();
  await TestBed.configureTestingModule({ imports: [TranslateModule.forRoot()], providers: [{ provide: QuestionChartPreviewService, useValue: { load, loadGrid } }] })
    .overrideComponent(QuestionChartComponent, { set: { template, templateUrl: undefined, styleUrl: undefined } })
    .compileComponents();
  const fixture = TestBed.createComponent(QuestionChartComponent);
  const chartType = signal(type);
  const displayMode = signal('percentage');
  Object.defineProperty(fixture.componentInstance, 'displayMode', { value: displayMode });
  // Vitest needs signals supplied without Angular's input transform.
  const contextSignal = signal(questionContext);
  Object.defineProperty(fixture.componentInstance, 'context', { value: contextSignal });
  Object.defineProperty(fixture.componentInstance, 'title', { value: signal(context.question.title) });
  Object.defineProperty(fixture.componentInstance, 'chartType', { value: chartType });
  fixture.detectChanges();
  return { fixture, chartType, displayMode, loadGrid, contextSignal };
}

describe('Question chart selection requests', () => {
  afterEach(() => { TestBed.resetTestingModule(); vi.useRealTimers(); });
  it.each([
    ['MULTIBAR_HORIZONTAL', 'niq-highchart-bar'],
    ['MULTIBAR_VERTICAL', 'niq-highchart-column'],
    ['PIE', 'niq-highchart-pie'],
  ])('renders star rating %s without loading or displaying a supplementary table', async (type, selector) => {
    const result: QuestionChartPreview = {
      configs: [], properties: {}, data: [{ label1: 'Rating', metric1: 10 }], metadata: {},
    };
    const loadGrid = vi.fn().mockReturnValue(throwError(() => new Error('Table failed')));
    const { fixture } = await setup(vi.fn().mockReturnValue(of(result)), type, loadGrid, {
      ...context, question: { ...context.question, type: QuestionTypes.StarRating },
    });
    vi.advanceTimersByTime(300);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector(selector)).not.toBeNull();
    expect(fixture.nativeElement.querySelector('survey-grid')).toBeNull();
    expect(fixture.nativeElement.querySelector('.question-results--chart-only')).not.toBeNull();
    expect(loadGrid).not.toHaveBeenCalled();
    expect(fixture.componentInstance.gridError()).toBe('');
  });

  it('keeps the star rating parent heat grid', async () => {
    const gridResponse = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    const result: QuestionChartPreview = {
      configs: [], properties: {}, data: gridResponse.objects.data,
      metadata: gridResponse.objects.metadata, gridResponse,
    };
    const { fixture, loadGrid } = await setup(vi.fn().mockReturnValue(of(result)), 'heatmap', undefined, {
      ...context, question: { ...context.question, type: QuestionTypes.StarRating },
    });
    vi.advanceTimersByTime(300);
    fixture.detectChanges();
    const grids = fixture.debugElement.queryAll(By.css('survey-grid'));
    expect(grids).toHaveLength(1);
    expect(grids[0].componentInstance.response).toBe(gridResponse);
    expect(loadGrid).not.toHaveBeenCalled();
  });

  it('cancels a pending supplementary table when the question changes to star rating', async () => {
    const gridResponse = new Subject();
    const loadGrid = vi.fn().mockReturnValue(gridResponse);
    const { fixture, contextSignal } = await setup(vi.fn().mockReturnValue(of({
      configs: [], properties: {}, data: [{ label1: 'Answer', metric1: 10 }], metadata: {},
    })), 'PIE', loadGrid);
    expect(gridResponse.observed).toBe(true);
    contextSignal.set({ ...context, question: { ...context.question, type: QuestionTypes.StarRating } });
    fixture.detectChanges();
    expect(gridResponse.observed).toBe(false);
    expect(fixture.componentInstance.normalGrid()).toBeNull();
    expect(loadGrid).toHaveBeenCalledTimes(1);
    contextSignal.set(context);
    fixture.detectChanges();
    expect(loadGrid).toHaveBeenCalledTimes(2);
  });

  it('uses an independent table response without reloading unchanged preview data', async () => {
    const response = new Subject<QuestionChartPreview>();
    const { fixture, displayMode, loadGrid } = await setup(vi.fn().mockReturnValue(response));
    vi.advanceTimersByTime(300);
    const component = BAR_CHART_RESPONSE.data[0].components[0];
    const result: QuestionChartPreview = { configs: component.chartConfigs, properties: component.chartProperty,
      data: component.objects.data, metadata: component.objects.metadata };
    response.next(result);
    fixture.detectChanges();
    const grid = fixture.debugElement.query(By.css('survey-grid')).componentInstance;
    expect(grid.response).toBe(NORMAL_GRID_PREVIEW_RESPONSE.components[0]);
    expect(grid.response).not.toBe(result);
    expect(fixture.nativeElement.querySelector('.question-results--chart-only')).toBeNull();
    expect(loadGrid).toHaveBeenCalledExactlyOnceWith();
    displayMode.set('actual');
    fixture.detectChanges();
    expect(loadGrid).toHaveBeenCalledTimes(1);
  });
  it('reloads for a new dropdown value and ignores the cancelled result', async () => {
    const first = new Subject<QuestionChartPreview>();
    const second = new Subject<QuestionChartPreview>();
    const load = vi.fn().mockReturnValueOnce(first).mockReturnValueOnce(second);
    const { fixture, chartType } = await setup(load);
    expect(load).not.toHaveBeenCalled();
    vi.advanceTimersByTime(300);
    expect(load).toHaveBeenLastCalledWith('MULTIBAR_HORIZONTAL');
    chartType.set('PIE');
    fixture.detectChanges();
    expect(first.observed).toBe(false);
    vi.advanceTimersByTime(300);
    expect(load).toHaveBeenLastCalledWith('PIE');
    expect(first.observed).toBe(false);
    const result: QuestionChartPreview = { configs: [], properties: {}, data: [], metadata: {} };
    second.next(result);
    expect(fixture.componentInstance.chart()).toBe(result);
    expect(fixture.componentInstance.loading()).toBe(false);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.chart-empty[role="status"]').textContent)
      .toContain('No results available for this chart.');
    expect(fixture.nativeElement.querySelector('.question-chart')).toBeNull();
    fixture.destroy();
    expect(second.observed).toBe(false);
  });

  it.each([
    [new Error('Chart failed'), 'Chart failed'],
    ['failure', 'Unable to load chart.'],
  ])('shows the expected message when chart loading fails', async (failure, message) => {
    const { fixture } = await setup(vi.fn().mockReturnValue(throwError(() => failure)));
    vi.advanceTimersByTime(300);
    fixture.detectChanges();

    expect(fixture.componentInstance.error()).toBe(message);
    expect(fixture.componentInstance.loading()).toBe(false);
    expect(fixture.nativeElement.querySelector('[role="status"]').textContent).toContain(message);
    fixture.destroy();
  });

  it.each([
    ['MULTIBAR_HORIZONTAL', 'niq-highchart-bar'],
    ['MULTIBAR_VERTICAL', 'niq-highchart-column'],
    ['PIE', 'niq-highchart-pie']
  ])('renders %s with all chart inputs', async (type, selector) => {
    const response = new Subject<QuestionChartPreview>();
    const { fixture } = await setup(vi.fn().mockReturnValue(response), type);
    expect(fixture.nativeElement.querySelector('.chart-shimmer')).not.toBeNull();
    vi.advanceTimersByTime(300);
    const result: QuestionChartPreview = {
      configs: [], properties: { showLegend: true },
      data: [{ label1: 'Answer', metric1: 10 }], metadata: { metric1: { type: 'number' } },
    };
    response.next(result);
    fixture.detectChanges();
    const charts = fixture.debugElement.queryAll(By.css('.question-chart > *'));
    expect(charts).toHaveLength(1);
    expect(charts[0].nativeElement.tagName.toLowerCase()).toBe(selector);
    for (const input of ['data', 'configs', 'properties', 'metadata'] as const) {
      expect(charts[0].componentInstance[input]).toBe(result[input]);
    }
    expect(charts[0].componentInstance.chartTitle).toBe(context.question.title);
    expect(fixture.nativeElement.querySelector('.chart-shimmer')).toBeNull();
  });
  it('renders a heat response once at full width without a companion chart', async () => {
    const response = new Subject<QuestionChartPreview>();
    const { fixture } = await setup(vi.fn().mockReturnValue(response), 'heatmap');
    vi.advanceTimersByTime(300);
    const gridResponse = structuredClone(HEAT_GRID_PREVIEW_RESPONSE.components[0]);
    response.next({ configs: [], properties: {}, data: gridResponse.objects.data,
      metadata: gridResponse.objects.metadata, gridResponse });
    fixture.detectChanges();
    const grids = fixture.debugElement.queryAll(By.css('survey-grid'));
    expect(grids).toHaveLength(1);
    expect(grids[0].componentInstance.response).toBe(gridResponse);
    expect(fixture.nativeElement.querySelector('.question-results')).toBeNull();
    expect(fixture.nativeElement.querySelector('.question-chart')).toBeNull();
  });

});
