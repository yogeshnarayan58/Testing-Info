import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { findDataSetByName, getDimensionSelectionsByPivot, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { RUN_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Deal";
if (reportTestData && hasPivotInDimensionSelections(reportTestData, pivot)) {
  test.describe.serial(
    "Consumer Distribution Analysis - Deal Pivot",
    { tag: ["@Report_E2E_Flow"] },
    async () => {
    test(
      "Validate run report",
      {
        tag: "@RunReport",
      },
      async () => {
        test.setTimeout(RUN_TEST_TIMEOUT);
        let basePage = await BasePageFactory.createBasePage();
        let dataSelector = new DataSelector(basePage);
        await dataSelector.navigateToUrl(reportUrl);
        await dataSelector.switchPivotDropdown(pivot);
        await dataSelector.clickAdditionalPromptEllipsisIcon();

        // Get Deal pivot data
        const dealData = getDimensionSelectionsByPivot(pivot, reportTestData);
        let commonTestCase: CommonTestCase;
        await dataSelector.clickMadlibDimension("Product Universe");
        await dataSelector.setMadlibSelection(
          dealData["Product Universe"]
        );
        await dataSelector.clickMadlibDimension("Product");
        await dataSelector.setMadlibSelection(
          dealData["Product"]
        );
        await dataSelector.waitForMadlibStability(); 
        await dataSelector.clickMadlibDimension("Retailers");
        await dataSelector.setMadlibSelection(
          dealData["Retailers"]
        );
        await dataSelector.clickMadlibDimension("Facts");
        await dataSelector.assertFactsDropdown(
          reportAssertData["dataSummary"]["facts"]["factList"]
        );
        await dataSelector.selectClosedDropdown(
          dealData["Facts"]["selections"]
        );
        await dataSelector.clickMadlibDimension("Geography");
        await dataSelector.setMadlibSelection(
          dealData["Geography"]
        );

        await dataSelector.clickMadlibDimension("Demography");
        await dataSelector.setMadlibSelection(
          dealData["Demography"]
        );
        // Configure Range (no volumetric type)
        const rangeConfig = dealData["Range"];
        await dataSelector.clickMadlibDimension("Range");
        await dataSelector.clickMadlibDimension("defineNewRangeButton");

        await dataSelector.configureRange(
          rangeConfig.volumetricType,     // Volumetric type from dropdown ("Units", "Value", "EQ", "EQ2", "EQ3", "EQ4")
          rangeConfig.minValue,           // Min value
          rangeConfig.maxValue,           // Max value
          rangeConfig.incrementValue      // Increment value
        );
        await dataSelector.clickMadlibDimension("Period");
        await dataSelector.setPeriodMadlibSelection(
            dealData["Period"]
          );
        // await dataSelector.clickMadlibDimension("People");
        // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
        // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
        let dsBasePage = await dataSelector.getBasePage();
        commonTestCase = new CommonTestCase(dsBasePage);
        await commonTestCase.clickRunButton();
        await commonTestCase.waitForReportRunCompletion();
        console.log("run complete in spec");
        const { newReportTitle, newUrl } =
          await commonTestCase.saveReport();
        savedReportTitle = newReportTitle;
        savedReportUrl = newUrl;
        console.log("savedReportTitle:", savedReportTitle);
        console.log("savedReportUrl:", savedReportUrl);
        await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
      }
    );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');
        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
  });
}
