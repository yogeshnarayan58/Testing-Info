import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory, closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartFromScratchPage } from '../../page-objects/survey/start-from-scratch.page';
import { StartWithPromptPage } from '../../page-objects/survey/start-with-prompt.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { SurveyBuilderPage } from '../../page-objects/common/survey-builder.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import {registerEditSurveyTitleTest,registerRequiredStarTest,registerEditQuestionTextTest,
  registerDiscardSaveChangesTest,registerCancelAddQuestionTest,registerDragDropTest,
  registerDeleteDuplicateQuestionTest,registerReviewModeTest,registerReviewModeDeleteAllTest,
  registerAddSingleChoiceQuestionTest,registerAddMultipleChoiceQuestionTest,registerAddRatingQuestionTest,
  registerAddNPSQuestionTest,registerAddPointScaleQuestionTest,registerAddMultiScaleQuestionTest,
  registerStepperNavigationTest,registerValidateDisabledUnderThreeTest,registerSaveDraftTest,
  registerValidateSurveyTest,registerOptionBoundaryTest,
} from './common-test-cases/build-survey-common-test-cases';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

// Clears the max-questions limit (if hit) so 'Add question' is clickable again.
async function ensureAddQuestionEnabled(surveyBuilderPage: SurveyBuilderPage): Promise<void> {
  const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
  if (addQuestionState.disabled) {
    await surveyBuilderPage.deleteQuestionAt(0);
  }
}

// Empty state has no 'Add question' link - adds via the same type-tile flow TC_BS_03a uses, only when the survey has 0 questions.
async function ensureAtLeastOneQuestion(surveyBuilderPage: SurveyBuilderPage): Promise<void> {
  if ((await surveyBuilderPage.getQuestionCount()) === 0) {
    const { questionText, options } = testData.surveyQuestions.singleChoice;
    await surveyBuilderPage.addSingleChoiceQuestion(questionText, options);
  }
}

// Stateful end-to-end scenario: tests share one browser session and run in order, each building on the previous state.
// Run the whole flow by its tag (e.g. --grep @StartFromScratch). Running a single feature tag alone is not supported.
test.describe.serial('Start from scratch', { tag: '@StartFromScratch' }, () => {
  let basePage: BasePage;
  let surveyPage: StartFromScratchPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'start-from-scratch-video');
    }
  });

  test(
    'Start from Scratch: Should display the Start from scratch option on the survey home page',
    { tag: '@LandStartFromScratch' },
    async () => {
      basePage = await BasePageFactory.createBasePage();
      surveyPage = new StartFromScratchPage(basePage);

      await surveyPage.navigateToSurvey();

      const isStartFromScratchVisible = await surveyPage.isStartFromScratchVisible();
      assertTrue(isStartFromScratchVisible, '"Start from scratch" option not visible after navigating to survey');

      await surveyPage.clickStartFromScratch();
    }
  );

  test('Dataset Selection: Should select the dataset and confirm the Choose a dataset screen', { tag: '@DatasetSelection' }, async () => {
    await surveyPage.selectProductOffering('');
    const isDatasetSelectionConfirmed = await surveyPage.searchAndSelectDataset(datasetConfig.searchTerm, String(DATASET_NAME));

    assertTrue(isDatasetSelectionConfirmed, `Expected "Choose a dataset" confirmation not visible after selecting ${DATASET_NAME}`);

    await surveyPage.proceedToNextAfterDatasetSelection();
    await surveyPage.applyEntireDataset();
  });

  test('Panelist Filters: Should enable Search for Panelists after all 5 filters are set', { tag: '@DataSummary' }, async () => {
    selectPanelistPage = new SelectPanelistPage(basePage);
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);

    const isSearchButtonVisible = await selectPanelistPage.isSearchForPanelistsButtonVisible();
    assertTrue(isSearchButtonVisible, 'Search for Panelists button not visible after setting dimension selections');
  });

  test('Response Count: Should enable Proceed to survey builder after selecting a response count', { tag: '@ResponseCount' }, async () => {
    await selectPanelistPage.clickSearchForPanelists();
    await selectPanelistPage.click250Responses();

    const isProceedToSurveyBuilderVisible = await selectPanelistPage.isProceedToSurveyBuilderVisible();
    assertTrue(isProceedToSurveyBuilderVisible, 'Proceed to survey builder button not visible after selecting 250 responses');
  });

  test('Survey Builder: Should navigate to the Build Survey page after proceeding', { tag: '@ProceedToSurveyBuilder' }, async () => {
    await selectPanelistPage.clickProceedToSurveyBuilder();
    const isLoaded = await selectPanelistPage.isBuildSurveyPageLoaded();
    assertTrue(isLoaded, 'Build Survey page did not load after proceeding');
  });

  test(
    'TC_BS_01: First landing shows "Untitled Survey" and the Add question panel',
    { tag: '@EmptyState' },
    async () => {
      const surveyBuilderPage = new SurveyBuilderPage(basePage);

      const titleDisplay = await surveyBuilderPage.getSurveyTitleDisplay();
      assertTrue(titleDisplay === 'Untitled Survey', `Expected survey title to be "Untitled Survey", got "${titleDisplay}"`);
      assertTrue(
        await surveyBuilderPage.areAddQuestionOptionsVisible(),
        'Expected Add Question options visible on first landing'
      );
    }
  );

  registerEditSurveyTitleTest({ getBasePage: () => basePage }, { title: 'TC_BS_02: Edit survey title', tag: '@EditSurveyTitle' });

  registerAddSingleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03a: Add a Single Choice question', tag: '@SingleChoiceQuestion' }
  );

  registerAddMultipleChoiceQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03b: Add a Multiple Choice question', tag: '@MultipleChoiceQuestion' }
  );

  registerAddRatingQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03c: Add a Rating question', tag: '@RatingQuestion' });

  registerAddNPSQuestionTest({ getBasePage: () => basePage }, { title: 'TC_BS_03d: Add an NPS question', tag: '@NPSQuestion' });

  registerAddPointScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03e: Add a Point Scale question', tag: '@PointScaleQuestion' }
  );

  registerAddMultiScaleQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_03f: Add a Multi Scale question', tag: '@MultiScaleQuestion' }
  );

  registerRequiredStarTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_07: Required star appears when the Required toggle is on', tag: '@RequiredStar' }
  );

  registerEditQuestionTextTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_25: Edit question text via the pencil icon', tag: '@EditQuestion' }
  );

  registerDiscardSaveChangesTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_26: Discard / Save changes on an existing question', tag: '@DiscardSave' }
  );

  registerCancelAddQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_05: Cancelling Add Question leaves the question count unchanged', tag: '@CancelAddQuestion' }
  );

  registerDragDropTest({ getBasePage: () => basePage }, { title: 'TC_BS_15: Drag and drop reorders questions', tag: '@DragDrop' });

  registerDeleteDuplicateQuestionTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_06: Delete and duplicate a question via hover row actions', tag: '@DeleteDuplicate' }
  );

  registerOptionBoundaryTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_04: Options boundary - min 2, max 15', tag: '@OptionBoundary' }
  );

  registerStepperNavigationTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_12: Stepper navigation to Select Panelists retains data and back to Build Survey', tag: '@StepperNavigation' }
  );

  test('TC_BS_08: Max questions (10) disables Add question and Duplicate with limit message', { tag: '@MaxQuestions' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText: ratingText } = testData.surveyQuestions.rating;

    try {
      let questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      while (questionNumbers.length < 10) {
        const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
        if (addQuestionState.disabled) {
          break;
        }
        await surveyBuilderPage.openAddQuestionPanel();
        await surveyBuilderPage.addRatingQuestion(ratingText);
        questionNumbers = await surveyBuilderPage.getQuestionNumbers();
      }

      assertTrue(questionNumbers.length === 10, `Expected 10 questions, got ${questionNumbers.length}: ${JSON.stringify(questionNumbers)}`);

      assertTrue(await surveyBuilderPage.isAddQuestionTooltipVisibleOnHover(), 'limit message after hover on add');
      const addQuestionState = await surveyBuilderPage.getAddQuestionDisabledState();
      assertTrue(addQuestionState.disabled, `add-question disabled (class="${addQuestionState.classAttr}")`);

      assertTrue(await surveyBuilderPage.isDuplicateTooltipVisibleOnHover(), 'limit message after hover on duplicate');
      const duplicateState = await surveyBuilderPage.getDuplicateDisabledState();
      assertTrue(duplicateState.disabled, `duplicate disabled (outerHTML="${duplicateState.outerHtml}")`);

      const questionNumbersAfter = await surveyBuilderPage.getQuestionNumbers();
      assertTrue(questionNumbersAfter.length === 10, 'count stays 10');
    } catch (error) {
      throw new Error(`Failed to verify max-questions limit: ${error instanceof Error ? error.message : error}`);
    }
  });

  registerReviewModeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_13/TC_BS_14: Review Mode controls, select, delete selected, exit', tag: '@ReviewMode' }
  );

  registerSaveDraftTest({ getBasePage: () => basePage }, { title: 'TC_BS_10: Save survey as draft', tag: '@SaveDraft' });

  registerValidateSurveyTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_23: Validate survey: Completes and shows Optiq feedback when there are recommendations', tag: '@ValidateSurvey' }
  );

  test('TC_AI_12: No Optiq-AI action buttons are visible in the Start From Scratch builder', { tag: '@StartFromScratch' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await ensureAtLeastOneQuestion(surveyBuilderPage);

    const promptPage = new StartWithPromptPage(basePage);
    await promptPage.hoverQuestionRow(0);

    assertTrue(
      await promptPage.areAiButtonsHidden(),
      'Expected no rephrase/generate/reprompt AI buttons visible outside the AI-generated flow'
    );
  });

  test('TC_BS_22: Discard a new question via Add Question cancel, then add and save one', { tag: '@CancelAddQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await ensureAtLeastOneQuestion(surveyBuilderPage);
    await ensureAddQuestionEnabled(surveyBuilderPage);
    const countBefore = await surveyBuilderPage.getQuestionCount();

    await surveyBuilderPage.clickAddQuestion();
    await surveyBuilderPage.clickQuestionTypeTile('questionTypeRating');
    await surveyBuilderPage.clickAddQuestion(); // toggles the panel closed, discarding the new question
    const countAfterDiscard = await surveyBuilderPage.getQuestionCount();
    assertTrue(
      countAfterDiscard === countBefore,
      `Expected count unchanged after discard (before ${countBefore}, after ${countAfterDiscard})`
    );

    const { questionText } = testData.surveyQuestions.rating;
    await surveyBuilderPage.clickAddQuestion();
    await surveyBuilderPage.addRatingQuestion(questionText);
    const countAfterSave = await surveyBuilderPage.getQuestionCount();
    assertTrue(countAfterSave === countBefore + 1, `Expected count ${countBefore + 1} after save, got ${countAfterSave}`);
  });

  test('TC_BS_20: Delete the last question then re-add the same type as last', { tag: '@DeleteDuplicate' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await ensureAtLeastOneQuestion(surveyBuilderPage);
    await ensureAddQuestionEnabled(surveyBuilderPage);
    const { questionText } = testData.surveyQuestions.rating;
    await surveyBuilderPage.clickAddQuestion();
    await surveyBuilderPage.addRatingQuestion(questionText);
    const countBefore = await surveyBuilderPage.getQuestionCount();

    await surveyBuilderPage.deleteQuestionAt(countBefore - 1);
    const countAfterDelete = await surveyBuilderPage.getQuestionCount();
    assertTrue(countAfterDelete === countBefore - 1, `Expected ${countBefore - 1} after delete, got ${countAfterDelete}`);

    await surveyBuilderPage.clickAddQuestion();
    await surveyBuilderPage.addRatingQuestion(questionText);
    const countAfterReAdd = await surveyBuilderPage.getQuestionCount();
    assertTrue(countAfterReAdd === countBefore, `Expected ${countBefore} after re-add, got ${countAfterReAdd}`);

    const newLastText = await surveyBuilderPage.getQuestionTextDisplay(countAfterReAdd - 1);
    assertTrue(
      newLastText.replace(/\s+/g, '').includes(questionText.replace(/\s+/g, '')),
      `Expected re-added question to be last with text "${questionText}", got "${newLastText}"`
    );
  });

  test.fixme('TC_BS_16/TC_BS_18: Publish survey', { tag: '@PublishSurvey' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const title = `Publish_${Date.now()}`;
    const SELECTED_RESPONSE_COUNT = 250; // Setup used click250Responses()
    await surveyBuilderPage.ensureQuestionCount(3);
    await surveyBuilderPage.publishSurvey(title);
    const areDimensionsShown = await surveyBuilderPage.isPublishDialogDimensionCountVisible(datasetConfig.dimensionSelections.length);
    assertTrue(areDimensionsShown, `Expected ${datasetConfig.dimensionSelections.length} dimension selections in Confirm publish? dialog`);

    const responseSummaryText = await surveyBuilderPage.getPublishResponseSummaryText();
    assertTrue(
      responseSummaryText.includes(String(SELECTED_RESPONSE_COUNT)),
      `Expected "${SELECTED_RESPONSE_COUNT} responses" in Confirm publish? dialog, got "${responseSummaryText}"`
    );

    const confirmClickTime = Date.now();
    const isPublishConfirmed = await surveyBuilderPage.confirmPublish();
    assertTrue(isPublishConfirmed, 'Expected "Confirm publish?" prompt and "Publishing survey" status to appear');
    const isSuccessToastVisible = await surveyBuilderPage.verifyPublishSucceeded(confirmClickTime);
    assertTrue(isSuccessToastVisible, 'Expected "Survey published successfully" message after publish');
  });

  registerReviewModeDeleteAllTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_27: Review Mode select all, delete all, stay on Build Survey', tag: '@ReviewModeDeleteAll' }
  );

  registerValidateDisabledUnderThreeTest(
    { getBasePage: () => basePage },
    { title: 'TC_BS_09: Validate survey is disabled with fewer than 3 questions', tag: '@ValidateDisabled' }
  );

  test('TC_BS_12: Back button returns to the previous step from the builder', { tag: '@BackButton' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    await surveyBuilderPage.clickBackButton();

    const isProceedToSurveyBuilderVisible = await selectPanelistPage.isProceedToSurveyBuilderVisible();
    assertTrue(isProceedToSurveyBuilderVisible, 'Expected Proceed to survey builder button (previous step) visible after clicking Back');

    const currentUrl = await surveyBuilderPage.getCurrentUrl();
    assertTrue(currentUrl.includes('select-panelist'), `Expected URL to contain "select-panelist" after clicking Back, got: ${currentUrl}`);
  });
});
