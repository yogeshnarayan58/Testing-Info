import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CpfService } from '@nielsen/crf-common';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';

@Injectable({
  providedIn: 'root'
})
export class PanelistDatasetService {
  private readonly environmentConfig = inject(EnvironmentConfig);
  private readonly cpfService = inject(CpfService);


  /**
   * Loads the base report specification for a given dataset and component.
   * Fetches configuration from CPF service and extracts the reportSpec value.
   * 
   * @param datasetDetails - Object containing dataset ID, dataView, and stack ID
   * @param componentId - The component identifier for configuration lookup (e.g., 'OMNI_THL_SURVEY_PANEL')
   * @returns Observable that emits the report specification object or null if not found
   */
  loadBaseReportSpec(datasetDetails: any, componentId: string): Observable<any> {
    const datasetId = datasetDetails?.id;
    const dataViewId = datasetDetails?.dataView?.dataViewId;
    const datasetStackId = datasetDetails?.stackId;

    return new Observable(observer => {
      const sub = this.cpfService.loadConfigurationsBuild(
        datasetId,
        this.environmentConfig.appId,
        componentId,
        undefined,
        dataViewId,
        undefined,
        undefined,
        datasetStackId
      ).subscribe({
        next: (configs: any) => {
          if (!configs) {
            observer.next(null);
            observer.complete();
            return;
          }
          const baseReportSpecArr = this.cpfService.getSpecificConfigurationFromBuildResponse('baseReportSpec', configs);
          const reportSpecValue = baseReportSpecArr?.configValue;
          observer.next(reportSpecValue?.reportSpec || null);
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        },
      });

      return () => sub.unsubscribe();
    });
  }

}
