import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'survey-dataset-footer',
  standalone: true,
  imports: [CommonModule, TranslateModule],
  templateUrl: './dataset-footer.component.html',
  styleUrl: './dataset-footer.component.scss',
})
export class DatasetFooterComponent {
  isEditable = input(true);
  selectedDataset = input<string>('');
  refreshedDate = input<string | null>(null);
  footerClick = output<void>();

  onDatasetFooterClick(): void {
    if (!this.isEditable()) {
      return;
    }

    this.footerClick.emit();
  }
}