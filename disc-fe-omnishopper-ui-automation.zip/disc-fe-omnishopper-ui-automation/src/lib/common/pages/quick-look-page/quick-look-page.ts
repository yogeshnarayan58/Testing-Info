import { BasePage } from "@gfk/gta";
import * as quickLookResources from "./quick-look-page-resources.json";
import { CommonTestCase } from "../common-test-case/common-test-case";
import { SMALL_TIMEOUT } from "../../../constants/time-out-constants";

const QUICK_LOOK_COMPONENT = "QuickLook";

export class QuickLookPage extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(QUICK_LOOK_COMPONENT, quickLookResources);
  }

  /**
   * Retrieves the preview description from QuickLook.
   * @returns The preview description as a string.
   */
  public async getPreviewDescription(): Promise<string> {
    const descriptionElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("previewDesc", QUICK_LOOK_COMPONENT)
    );
    try {
      await descriptionElement.waitFor(SMALL_TIMEOUT);
      return (await descriptionElement.getText()).trim();
    } catch (error: any) {
      throw new Error(`Failed to get preview description: ${error.message}`);
    }
  }

  /**
   * Retrieves the themes from QuickLook as an array.
   * @returns An array of themes.
   */
  public async getPreviewThemes(): Promise<string[]> {
    const themesElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("Themes1", QUICK_LOOK_COMPONENT)
    );
    try {
      await themesElement.waitFor(SMALL_TIMEOUT);
      const text = (await themesElement.getText()).trim();
      return text.split(/\s*,\s*/);
    } catch (error: any) {
      throw new Error(`Failed to get preview themes: ${error.message}`);
    }
  }

  /**
   * Retrieves the datasets from QuickLook as an array.
   * @returns An array of datasets.
   */
  public async getPreviewDatasets(): Promise<string[]> {
    const datasetsElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource("previewDatasets", QUICK_LOOK_COMPONENT)
    );
    try {
      await datasetsElement.waitFor(SMALL_TIMEOUT);
      const text = (await datasetsElement.getText()).trim();
      return text.split(/\s*,\s*/);
    } catch (error: any) {
      throw new Error(`Failed to get preview datasets: ${error.message}`);
    }
  }
}
