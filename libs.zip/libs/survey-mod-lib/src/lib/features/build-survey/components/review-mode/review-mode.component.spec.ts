import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { ReviewModeComponent } from './review-mode.component';
import { SurveyService } from '../../services/survey.service';
import { ReviewModeService } from '../../services/review-mode.service';

vi.mock('../../services/survey.service', () => ({
  SurveyService: class {},
}));

describe('ReviewModeComponent', () => {
  const createComponent = (questions: unknown[] = []) => {
    const surveyService = {
      questions: signal(questions),
      setQuestions: vi.fn(),
    };
    const reviewModeService = {
      setAllCardsCollapsed: vi.fn(),
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: SurveyService, useValue: surveyService },
        { provide: ReviewModeService, useValue: reviewModeService },
      ],
    });

    const component = TestBed.runInInjectionContext(() => new ReviewModeComponent());
    TestBed.tick();
    return { component, surveyService, reviewModeService };
  };

  it('syncs questions from the survey service', () => {
    const questions = [{ question: 'First', questionNumber: 1 }];
    const { component } = createComponent(questions);

    TestBed.tick();

    expect(component.questions()).toEqual(questions);
  });

  it('does nothing when a question is dropped in the same position', () => {
    const { component, surveyService } = createComponent([
      { question: 'First', questionNumber: 1 },
    ]);

    component.drop({ previousIndex: 0, currentIndex: 0 } as any);

    expect(surveyService.setQuestions).not.toHaveBeenCalled();
  });

  it('reorders and renumbers questions after a drop', () => {
    const questions = [
      { question: 'First', questionNumber: 1 },
      { question: 'Second', questionNumber: 2 },
    ];
    const { component, surveyService } = createComponent(questions);

    component.drop({ previousIndex: 0, currentIndex: 1 } as any);

    expect(surveyService.setQuestions).toHaveBeenCalledWith([
      { question: 'Second', questionNumber: 1 },
      { question: 'First', questionNumber: 2 },
    ]);
  });

  it('collapses cards when dragging a non-empty list', () => {
    const { component, reviewModeService } = createComponent([
      { question: 'First', questionNumber: 1 },
    ]);

    component.onDragStart({} as any, 0);

    expect(reviewModeService.setAllCardsCollapsed).toHaveBeenCalledWith(true);
  });

  it('does not collapse cards for an empty list', () => {
    const { component, reviewModeService } = createComponent();

    component.onDragStart({} as any, 0);

    expect(reviewModeService.setAllCardsCollapsed).not.toHaveBeenCalled();
  });
});
