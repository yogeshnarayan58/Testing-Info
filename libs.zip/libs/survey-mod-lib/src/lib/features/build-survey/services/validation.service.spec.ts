import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ToastService } from '@nielseniq/athena-core';
import { EnvironmentConfig } from '@nielseniq/crf-discover-fe-core';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  AiSuggestion,
  QuestionModel,
  SUGGESTION_SEVERITY,
  SURVEY_SUGGESTIONS_STATE,
  SURVEY_VALIDATION_STATE,
} from '../models/build-survey';
import { ApiService } from '../../../shared/services/api.service';
import { ValidationService } from './validation.service';

function createSuggestion(overrides: Partial<AiSuggestion> = {}): AiSuggestion {
  return {
    suggestionId: 'suggestion-1',
    severity: 'MANDATORY',
    ruleCode: 'RULE_1',
    issue: 'Issue',
    rationale: 'Rationale',
    suggestedText: 'Suggested text',
    fieldPath: 'question',
    source: 'AI',
    action: 'REPHRASE',
    ...overrides,
  };
}

function createQuestion(overrides: Partial<QuestionModel> = {}): QuestionModel {
  return {
    id: 'question-1',
    questionNumber: 1,
    question: 'Original question',
    options: ['One', 'Two', 'Three'],
    isRequired: true,
    type: 'SINGLE_CHOICE',
    ...overrides,
  };
}

describe('ValidationService', () => {
  let service: ValidationService;
  let http: HttpTestingController;
  let toastService: { InsertToast: ReturnType<typeof vi.fn> };

  beforeEach(() => {
    toastService = { InsertToast: vi.fn() };
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        ApiService,
        ValidationService,
        {
          provide: EnvironmentConfig,
          useValue: { apiUrls: { surveyAiEngineUrl: '/survey-ai' } },
        },
        { provide: ToastService, useValue: toastService },
      ],
    });
    service = TestBed.inject(ValidationService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    http?.verify();
    TestBed.resetTestingModule();
  });

  it.each([null, {}, { result: null }, { result: 'invalid' }, { result: {} }])(
    'rejects malformed validation results and restores previous state (%j)', response => {
      const questions = [createQuestion()];
      const originalQuestions = structuredClone(questions);
      service.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
      const nextHandler = vi.fn();
      const errorHandler = vi.fn();

      service.validateSurvey(questions).subscribe({ next: nextHandler, error: errorHandler });
      http.expectOne('/survey-ai/validate-survey').flush(response);

      expect(questions).toEqual(originalQuestions);
      expect(nextHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalledExactlyOnceWith(
        expect.objectContaining({ message: 'Invalid survey validation response: result must be an array' })
      );
      expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
      expect(toastService.InsertToast).toHaveBeenCalledTimes(2);
      expect(toastService.InsertToast.mock.lastCall?.[0]).toBe('error');
    }
  );

  it('validates questions and derives review state from the response', () => {
    const mandatory = createSuggestion();
    const question = createQuestion();
    let received: QuestionModel[] | undefined;

    service.validateSurvey([question]).subscribe((response) => {
      received = service.normalizeValidatedQuestions(response);
    });

    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS
    );
    const request = http.expectOne('/survey-ai/validate-survey');
    expect(request.request.method).toBe('POST');
    expect(request.request.headers.get('Content-Type')).toBe('application/json');
    expect(request.request.body.survey.questions[0]).toMatchObject({ id: 'q_1', order: 1 });
    request.flush({
      result: [{ ...question, questionNumber: undefined, suggestions: [mandatory] }],
    });

    expect(received?.[0].questionNumber).toBe(1);
    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW
    );
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.IN_REVIEW);
    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'warning',
      expect.stringContaining('1 required change'),
      expect.objectContaining({ title: 'Changes needed' })
    );
  });

  it('marks a survey ready when validation returns no suggestions', () => {
    service.validateSurvey([createQuestion()]).subscribe();
    http.expectOne('/survey-ai/validate-survey').flush({ result: [createQuestion()] });

    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
    );
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);
    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'success',
      'Your survey is ready to be published.',
      expect.objectContaining({ title: 'Validation complete' })
    );
  });

  it.each([
    [SUGGESTION_SEVERITY.OPTIONAL, SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH],
    [SUGGESTION_SEVERITY.MANDATORY, SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW],
  ])(
    'with %s suggestions left after validation and revalidation, the state is %s',
    (severity, expectedState) => {
      for (let validationAttempt = 0; validationAttempt < 2; validationAttempt++) {
        service.validateSurvey([createQuestion()]).subscribe();
        http.expectOne('/survey-ai/validate-survey').flush({
          result: [createQuestion({ reviewRequired: false, suggestions: [createSuggestion({ severity })] })],
        });
        expect(service.surveyAIValidationState()).toBe(expectedState);
      }
      service.validateSurvey([createQuestion()]).subscribe();
      http.expectOne('/survey-ai/validate-survey').flush({
        result: [createQuestion({ reviewRequired: false, suggestions: [] })],
      });
      expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    }
  );

  it.each([
    [
      1,
      '1 recommendation was identified. Review it to improve survey quality before publishing.',
    ],
    [
      2,
      '2 recommendations were identified. Review recommendations to improve survey quality before publishing.',
    ],
  ])('reports %i optional recommendations', (count, message) => {
    const suggestions = Array.from({ length: count }, (_, index) =>
      createSuggestion({ suggestionId: `optional-${index}`, severity: 'OPTIONAL' })
    );

    service.validateSurvey([createQuestion()]).subscribe();
    http.expectOne('/survey-ai/validate-survey').flush({
      result: [createQuestion({ suggestions })],
    });

    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH
    );
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.IN_REVIEW);
    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'info',
      message,
      expect.objectContaining({ title: 'Changes recommended' })
    );
  });

  it.each([
    SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION,
    SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW,
    SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH,
  ])('reports validation failures and restores the previous state %s', previousState => {
    service.surveyAIValidationState.set(previousState);
    service.surveySuggestionState.set(SURVEY_SUGGESTIONS_STATE.IN_REVIEW);
    let status: number | undefined;
    service.validateSurvey([createQuestion()]).subscribe({
      error: (error) => (status = error.status),
    });
    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.VALIDATION_IN_PROGRESS
    );
    http
      .expectOne('/survey-ai/validate-survey')
      .flush('Unavailable', { status: 503, statusText: 'Unavailable' });

    expect(status).toBe(503);
    expect(service.surveyAIValidationState()).toBe(
      previousState
    );
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.IN_REVIEW);
    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'error',
      'Your survey could not be validated. Please try again.',
      expect.objectContaining({ title: 'Survey not validated' })
    );
  });

  it('counts suggestions and marks only the selected question for review', () => {
    const questions = [
      createQuestion({
        suggestions: [
          createSuggestion(),
          createSuggestion({ suggestionId: 'optional', severity: 'OPTIONAL' }),
        ],
      }),
      createQuestion({ id: 'question-2', questionNumber: 2 }),
    ];

    expect(service.countSuggestions(questions, 'MANDATORY')).toBe(1);
    expect(service.countSuggestions(questions, 'OPTIONAL')).toBe(1);
    const updated = service.markQuestionForReview(questions, 1);
    expect(updated[0].reviewRequired).toBeUndefined();
    expect(updated[1].reviewRequired).toBe(true);
  });

  it('adds an option and reindexes remaining suggestions', () => {
    const add = createSuggestion({
      suggestionId: 'add',
      action: 'ADD_OPTION',
      fieldPath: 'options[1]',
      suggestedText: 'Inserted',
    });
    const rephrase = createSuggestion({
      suggestionId: 'rephrase',
      fieldPath: 'options[1]',
    });
    const questions = [createQuestion({ suggestions: [add, rephrase] })];

    const [updated] = service.applyAddOptionSuggestion(questions, 'question-1', add);

    expect(updated.options).toEqual(['One', 'Inserted', 'Two', 'Three']);
    expect(updated.suggestions).toEqual([
      expect.objectContaining({ suggestionId: 'rephrase', fieldPath: 'options[2]' }),
    ]);
    expect(updated.reviewRequired).toBeUndefined();
  });

  it('handles duplicate additions, missing option arrays, and invalid add suggestions', () => {
    const duplicate = createSuggestion({
      suggestionId: 'duplicate',
      action: 'ADD_OPTION',
      fieldPath: 'options[1]',
      suggestedText: 'Two',
    });
    const unrelated = createQuestion({ id: 'question-2', questionNumber: 2 });
    const duplicateResult = service.applyAddOptionSuggestion(
      [createQuestion({ suggestions: [duplicate] }), unrelated],
      'question-1',
      duplicate
    );

    expect(duplicateResult[0].options).toEqual(['One', 'Two', 'Three']);
    expect(duplicateResult[0].suggestions).toEqual([]);
    expect(duplicateResult[1]).toBe(unrelated);

    const addRow = createSuggestion({
      suggestionId: 'add-row',
      action: 'ADD_OPTION',
      fieldPath: 'rowOptions[0]',
      suggestedText: 'Row',
    });
    const [withRow] = service.applyAddOptionSuggestion(
      [createQuestion({ rowOptions: undefined, suggestions: [addRow] })],
      'question-1',
      addRow
    );
    expect(withRow.rowOptions).toEqual(['Row']);

    const invalidPath = createSuggestion({ suggestionId: 'invalid', fieldPath: 'question' });
    const blankText = createSuggestion({ suggestionId: 'blank', suggestedText: ' ' });
    const invalidQuestion = createQuestion({ suggestions: [invalidPath, blankText] });

    expect(
      service.applyAddOptionSuggestion([invalidQuestion], 'question-1', invalidPath)[0]
    ).toBe(invalidQuestion);
    expect(
      service.applyAddOptionSuggestion([invalidQuestion], 'question-1', blankText)[0]
    ).toBe(invalidQuestion);
    expect(
      service.applyAddOptionSuggestion(
        [invalidQuestion],
        'question-1',
        createSuggestion({ suggestionId: 'missing' })
      )[0]
    ).toBe(invalidQuestion);
  });

  it('rephrases question, label, and option fields without mutating the input', () => {
    const questionSuggestion = createSuggestion({ suggestionId: 'question', suggestedText: 'Updated' });
    const labelSuggestion = createSuggestion({
      suggestionId: 'label',
      fieldPath: 'npsLeftLabel',
      suggestedText: 'Unlikely',
    });
    const optionSuggestion = createSuggestion({
      suggestionId: 'option',
      fieldPath: 'options[1]',
      suggestedText: 'Second',
    });
    const original = createQuestion({
      npsLeftLabel: 'Low',
      suggestions: [questionSuggestion, labelSuggestion, optionSuggestion],
    });

    let questions = service.rephraseSuggestion([original], 'question-1', questionSuggestion);
    questions = service.rephraseSuggestion(questions, 'question-1', labelSuggestion);
    questions = service.rephraseSuggestion(questions, 'question-1', optionSuggestion);

    expect(questions[0]).toMatchObject({
      question: 'Updated',
      npsLeftLabel: 'Unlikely',
      options: ['One', 'Second', 'Three'],
      suggestions: [],
    });
    expect(original).toMatchObject({
      question: 'Original question',
      npsLeftLabel: 'Low',
      options: ['One', 'Two', 'Three'],
    });
  });

  it('ignores invalid rephrase suggestions and unrelated questions', () => {
    const valid = createSuggestion({ suggestionId: 'valid', suggestedText: 'Updated' });
    const unrelated = createQuestion({ id: 'question-2', questionNumber: 2 });
    const result = service.rephraseSuggestion(
      [createQuestion({ suggestions: [valid] }), unrelated],
      'question-1',
      valid
    );
    expect(result[1]).toBe(unrelated);

    const blank = createSuggestion({ suggestionId: 'blank', suggestedText: ' ' });
    const invalidPath = createSuggestion({ suggestionId: 'invalid', fieldPath: 'unknown' });
    const missingOptions = createSuggestion({ suggestionId: 'missing-options', fieldPath: 'rowOptions[0]' });
    const outOfRange = createSuggestion({ suggestionId: 'out-of-range', fieldPath: 'options[9]' });
    const question = createQuestion({
      rowOptions: undefined,
      suggestions: [blank, invalidPath, missingOptions, outOfRange],
    });

    for (const item of [blank, invalidPath, missingOptions, outOfRange]) {
      expect(service.rephraseSuggestion([question], 'question-1', item)[0]).toBe(question);
    }
    expect(
      service.rephraseSuggestion(
        [question],
        'question-1',
        createSuggestion({ suggestionId: 'missing' })
      )[0]
    ).toBe(question);
  });

  it('dismisses only the selected suggestion', () => {
    const selected = createSuggestion({ suggestionId: 'selected' });
    const remaining = createSuggestion({ suggestionId: 'remaining', severity: 'OPTIONAL' });
    const unrelated = createQuestion({ id: 'question-2', questionNumber: 2 });
    const questions = [createQuestion({ suggestions: [selected, remaining] }), unrelated];

    const [updated] = service.dismissSuggestion(questions, 'question-1', 'selected');

    expect(updated.suggestions).toEqual([remaining]);
    expect(updated.reviewRequired).toBeUndefined();
    expect(service.dismissSuggestion(questions, 'question-1', 'selected')[1]).toBe(unrelated);
  });

  it('removes an option, drops suggestions for it, and shifts later paths', () => {
    const remove = createSuggestion({
      suggestionId: 'remove',
      action: 'REMOVE',
      fieldPath: 'options[1]',
    });
    const sameOption = createSuggestion({
      suggestionId: 'same-option',
      fieldPath: 'options[1]',
    });
    const addAtRemovedPosition = createSuggestion({
      suggestionId: 'add',
      action: 'ADD_OPTION',
      fieldPath: 'options[1]',
    });
    const laterOption = createSuggestion({
      suggestionId: 'later',
      fieldPath: 'options[2]',
    });
    const questions = [
      createQuestion({ suggestions: [remove, sameOption, addAtRemovedPosition, laterOption] }),
    ];

    const [updated] = service.removeOptionSuggestion(questions, 'question-1', remove);

    expect(updated.options).toEqual(['One', 'Three']);
    expect(updated.suggestions).toEqual([
      expect.objectContaining({ suggestionId: 'add', fieldPath: 'options[1]' }),
      expect.objectContaining({ suggestionId: 'later', fieldPath: 'options[1]' }),
    ]);
  });

  it('ignores invalid option removals and preserves unrelated questions', () => {
    const missingList = createSuggestion({
      suggestionId: 'missing-list',
      action: 'REMOVE',
      fieldPath: 'rowOptions[0]',
    });
    const outOfRange = createSuggestion({
      suggestionId: 'out-of-range',
      action: 'REMOVE',
      fieldPath: 'options[9]',
    });
    const invalidPath = createSuggestion({
      suggestionId: 'invalid',
      action: 'REMOVE',
      fieldPath: 'question',
    });
    const target = createQuestion({
      rowOptions: undefined,
      suggestions: [missingList, outOfRange, invalidPath],
    });
    const unrelated = createQuestion({ id: 'question-2', questionNumber: 2 });

    for (const item of [missingList, outOfRange, invalidPath]) {
      const result = service.removeOptionSuggestion(
        [target, unrelated],
        'question-1',
        item
      );
      expect(result[0]).toBe(target);
      expect(result[1]).toBe(unrelated);
    }
    expect(
      service.removeOptionSuggestion(
        [target],
        'question-1',
        createSuggestion({ suggestionId: 'missing' })
      )[0]
    ).toBe(target);
  });

  it('formats plural mandatory changes with a single recommendation', () => {
    const suggestions = [
      createSuggestion({ suggestionId: 'mandatory-1' }),
      createSuggestion({ suggestionId: 'mandatory-2' }),
      createSuggestion({ suggestionId: 'optional', severity: 'OPTIONAL' }),
    ];

    service.validateSurvey([createQuestion()]).subscribe();
    http.expectOne('/survey-ai/validate-survey').flush({
      result: [createQuestion({ suggestions })],
    });

    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'warning',
      '2 required changes and 1 recommendation was identified. Required changes must be resolved before publishing.',
      expect.objectContaining({ title: 'Changes needed' })
    );
  });

  it('updates validation and suggestion states after the final mandatory fix', () => {
    service.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);

    service.syncAfterSuggestionChange([
      createQuestion({
        suggestions: [createSuggestion({ severity: 'MANDATORY' })],
      }),
    ]);
    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW
    );
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.IN_REVIEW);

    service.syncAfterSuggestionChange([
      createQuestion({
        suggestions: [createSuggestion({ severity: 'OPTIONAL' })],
      }),
    ]);
    expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.IN_REVIEW);
    service.syncAfterSuggestionChange([createQuestion({ suggestions: [] })]);
    expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
  });

  it('invalidates publish-ready state and resets validation', () => {
    service.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    service.surveySuggestionState.set(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);

    service.invalidateSurveyValidation();
    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW
    );
    expect(toastService.InsertToast).toHaveBeenLastCalledWith(
      'info',
      'Your survey has changed. Please revalidate before publishing.',
      expect.objectContaining({ title: 'Revalidation needed' })
    );

    service.resetValidation();
    expect(service.surveyAIValidationState()).toBe(
      SURVEY_VALIDATION_STATE.READY_FOR_VALIDATION
    );
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);
  });

  it.each([
    SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW,
    SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH,
  ])('retains existing review requirements after the last suggestion is applied from %s', state => {
    service.surveyAIValidationState.set(state);
    const fix = createSuggestion({ suggestedText: 'Updated question' });
    const questions = service.rephraseSuggestion(
      [createQuestion({ reviewRequired: true, suggestions: [fix] })], 'question-1', fix
    );

    service.syncAfterSuggestionChange(questions);

    expect(questions[0].reviewRequired).toBe(true);
    expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
  });

  it.each([true, false, undefined])('preserves reviewRequired=%s across suggestion actions', reviewRequired => {
    const fix = createSuggestion({ fieldPath: 'options[1]', suggestedText: 'Updated option' });
    const original = createQuestion({ reviewRequired, suggestions: [fix] });
    const questions = [original];
    const results = [
      service.applyAddOptionSuggestion(questions, 'question-1', fix),
      service.rephraseSuggestion(questions, 'question-1', fix),
      service.dismissSuggestion(questions, 'question-1', fix.suggestionId),
      service.removeOptionSuggestion(questions, 'question-1', fix),
    ];

    for (const result of results) {
      expect(result[0].reviewRequired).toBe(reviewRequired);
      expect(result[0].suggestions).toEqual([]);
    }
    expect(original.suggestions).toEqual([fix]);
    expect(original.options).toEqual(['One', 'Two', 'Three']);
  });

  it('allows publishing after applying the last suggestion without pending review', () => {
    service.surveyAIValidationState.set(SURVEY_VALIDATION_STATE.VALIDATION_IN_REVIEW);
    const fix = createSuggestion({ suggestedText: 'Updated question' });
    const questions = service.rephraseSuggestion(
      [createQuestion({ reviewRequired: false, suggestions: [fix] })], 'question-1', fix
    );

    service.syncAfterSuggestionChange(questions);

    expect(questions[0].reviewRequired).toBe(false);
    expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.ALL_APPLIED);
  });

  it('uses the review flag cleared by the backend after successful revalidation', () => {
    const edited = createQuestion({ reviewRequired: true, suggestions: [] });
    let normalized: QuestionModel[] = [];
    service.validateSurvey([edited]).subscribe(response => {
      normalized = service.normalizeValidatedQuestions(response);
    });
    http.expectOne('/survey-ai/validate-survey').flush({
      result: [{ ...edited, reviewRequired: false }],
    });

    expect(normalized[0].reviewRequired).toBe(false);
    expect(service.surveyAIValidationState()).toBe(SURVEY_VALIDATION_STATE.READY_FOR_PUBLISH);
    expect(service.surveySuggestionState()).toBe(SURVEY_SUGGESTIONS_STATE.NO_SUGGESTION);
    expect(edited.reviewRequired).toBe(true);
  });

  it.each([true, false, undefined])('preserves the backend reviewRequired value %s', reviewRequired => {
    const original = createQuestion({ questionNumber: 5, reviewRequired });

    const normalized = service.normalizeValidatedQuestions({ result: [original] });

    expect(normalized[0].reviewRequired).toBe(reviewRequired);
    expect(normalized[0].questionNumber).toBe(1);
    expect(original.questionNumber).toBe(5);
  });
});
