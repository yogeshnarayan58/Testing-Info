import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import prodTestData from "./test-data/prod-test-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { findDataSetByName, getDimensionSelectionsByPivot, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";

// Determine which test data to use based on environment
const isProdEnvironment = config.ENV?.startsWith('PROD_');
const testData = isProdEnvironment ? prodTestData : devTestData;
const reportTestData = findDataSetByName(testData, config.DATASET);
const reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Contribution";
if (reportTestData && hasPivotInDimensionSelections(reportTestData, pivot)) {
  test.describe.serial(
    "Consumer Distribution Analysis - Contribution Pivot",
    { tag: ["@Report_E2E_Flow"] },
    async () => {
    test(
      "Validate run report",
      {
        tag: "@RunReport",
      },
      async () => {
         test.setTimeout(RUN_TEST_TIMEOUT);
        let basePage = await BasePageFactory.createBasePage();
        let dataSelector = new DataSelector(basePage);
        await dataSelector.navigateToUrl(reportUrl);
        await dataSelector.switchPivotDropdown(pivot);
        await dataSelector.clickAdditionalPromptEllipsisIcon();

        // Get Contribution pivot data
        const contributionData = getDimensionSelectionsByPivot(pivot, reportTestData);

        await dataSelector.clickMadlibDimension("Product Universe");
        await dataSelector.setMadlibSelection(
          contributionData["Product Universe"]
        );
        await dataSelector.clickMadlibDimension("Products");
        await dataSelector.setMadlibSelection(
          contributionData["Products"]
        );
        await dataSelector.waitForMadlibStability();
        await dataSelector.clickMadlibDimension("Retailers");
        await dataSelector.setMadlibSelection(
          contributionData["Retailers"]
        );
        await dataSelector.clickMadlibDimension("Facts");
        await dataSelector.assertFactsDropdown(
          reportAssertData["dataSummary"]["facts"]["factList"]
        );
        await dataSelector.selectClosedDropdown(
          contributionData["Facts"]["selections"]
        );
        await dataSelector.clickMadlibDimension("Geography");
        await dataSelector.setMadlibSelection(
          contributionData["Geography"]
        );
        await dataSelector.clickMadlibDimension("Period");
        await dataSelector.setPeriodMadlibSelection(
            contributionData["Period"]
          );
        await dataSelector.clickMadlibDimension("Demography");
        await dataSelector.setMadlibSelection(
          contributionData["Demography"]
        );

        // Configure Range (with volumetric type)
        await dataSelector.clickMadlibDimension("Range");
        const rangeConfig = contributionData["Range"];
        await dataSelector.clickMadlibDimension("defineNewRangeButton");

        await dataSelector.configureRange(
          rangeConfig.volumetricType,     // Volumetric type from dropdown ("Units", "Value", "EQ", "EQ2", "EQ3", "EQ4", "Occasions")
          rangeConfig.minValue,           // Min value %
          rangeConfig.maxValue,           // Max value %
          rangeConfig.incrementValue,    // Increment value %
          rangeConfig.splitBasedOn        // Split based on ("Buyers" or "Volumetric") - optional for Contribution
        );

        // Wait for madlib to stabilize after all dimension selections
        await dataSelector.waitForMadlibStability();

        // Get base page and create CommonTestCase instance
        let dsBasePage = await dataSelector.getBasePage();
        let commonTestCase = new CommonTestCase(dsBasePage);
        
        // Click run button and wait for completion
        await commonTestCase.clickRunButton();
        await commonTestCase.waitForReportRunCompletion();
        console.log("run complete in spec");
        
        // Save the report
        const { newReportTitle, newUrl } = await commonTestCase.saveReport();
        savedReportTitle = newReportTitle;
        savedReportUrl = newUrl;
        console.log("savedReportTitle:", savedReportTitle);
        console.log("savedReportUrl:", savedReportUrl);
      }
    );
      test("openCurrentReportFMS", { tag: '@openCurrentReportFMS' }, async () => {
        test.skip(!savedReportTitle, 'Skipping FMS test - Report not generated. Run with @RunReport first');

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);

        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        console.log("Open current report from FMS - Report visible in UI");
      });
  });
}
