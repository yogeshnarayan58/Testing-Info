import { HttpClient, HttpContext, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { catchError, defer, Observable, shareReplay, throwError } from 'rxjs';

/** Options for JSON API calls. Authentication and interceptors use the existing HttpClient. */
export interface ApiRequestOptions {
  headers?: HttpHeaders | Record<string, string | string[]>;
  params?:
    | HttpParams
    | Record<string, string | number | boolean | readonly (string | number | boolean)[]>;
  context?: HttpContext;
  withCredentials?: boolean;
}

export interface ApiGetOptions extends ApiRequestOptions {
  /** GETs are cached by default. Disable for polling or data that must always be fresh. */
  cache?: boolean;
}

export interface ApiPostOptions extends ApiRequestOptions {
  /** Enable only for POST endpoints that read data, such as asset searches. */
  cache?: boolean;
  /** Group cached reads for targeted invalidation without clearing other views. */
  cacheTag?: string;
}

export interface ApiPutOptions extends ApiRequestOptions {
  /** Enable only when repeated identical PUTs should reuse the first successful response. */
  cache?: boolean;
  /** Group cached reads for targeted invalidation without clearing other views. */
  cacheTag?: string;
}

/**
 * The shared HTTP entry point for survey-mod. No additional host providers are required.
 *
 * @example
 * private readonly api = inject(ApiService);
 * this.api.get<Survey[]>('/surveys');
 * this.api.get<JobStatus>('/jobs/123', { cache: false });
 * this.api.post<Survey>('/surveys', payload);
 * this.api.post<Survey[]>('/assets/search', filters, { cache: true });
 * this.api.put<Survey>('/surveys/123', payload);
 * this.api.put<Survey>('/surveys/123', payload, { cache: true });
 * this.api.delete('/surveys/123');
 * this.api.clearCache('/surveys'); // Invalidate affected reads after a successful write.
 *
 * POST and PUT caching is opt-in. Writes do not automatically clear cached responses.
 * Call clearCache when data or the active user/tenant changes. Responses stay in memory
 * until explicitly cleared or the root injector is destroyed. Errors are never cached.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly cache = new Map<string, { url: string; cacheTag?: string; response: Observable<unknown> }>();
  private readonly contextIds = new WeakMap<HttpContext, number>();
  private nextContextId = 0;

  constructor(@Inject(HttpClient) private readonly http: HttpClient) {}

  get<T>(url: string, options: ApiGetOptions = {}): Observable<T> {
    const { cache = true, ...httpOptions } = options;
    if (!cache) {
      return this.http.get<T>(url, httpOptions);
    }

    const key = this.cacheKey('GET', url, httpOptions);
    return this.cachedRequest(url, key, () => this.http.get<T>(url, httpOptions), false);
  }

  post<T = object>(url: string, body: unknown, options?: ApiPostOptions): Observable<T> {
    return this.requestWithBody<T>('POST', url, body, options);
  }

  put<T = object>(url: string, body: unknown, options?: ApiPutOptions): Observable<T> {
    return this.requestWithBody<T>('PUT', url, body, options);
  }

  delete<T = object>(url: string, options?: ApiRequestOptions): Observable<T> {
    return options ? this.http.delete<T>(url, options) : this.http.delete<T>(url);
  }

  /** Clear one URL (including every payload/parameter variant), or all responses after a context change. */
  clearCache(url?: string, cacheTag?: string): void {
    if (url === undefined && cacheTag === undefined) {
      this.cache.clear();
      return;
    }

    for (const [key, entry] of this.cache) {
      if ((url === undefined || entry.url === url)
        && (cacheTag === undefined || entry.cacheTag === cacheTag)) {
        this.cache.delete(key);
      }
    }
  }

  private requestWithBody<T>(
    method: 'POST' | 'PUT',
    url: string,
    body: unknown,
    options?: ApiPostOptions | ApiPutOptions
  ): Observable<T> {
    const { cache = false, cacheTag, ...httpOptions } = options ?? {};
    const requestFactory =
      method === 'POST'
        ? () => (options ? this.http.post<T>(url, body, httpOptions) : this.http.post<T>(url, body))
        : () => (options ? this.http.put<T>(url, body, httpOptions) : this.http.put<T>(url, body));

    if (!cache) {
      return requestFactory();
    }

    const key = JSON.stringify([this.cacheKey(method, url, httpOptions), this.serializeBody(body), cacheTag ?? null]);
    return this.cachedRequest(url, key, requestFactory, false, cacheTag);
  }

  private cachedRequest<T>(
    url: string,
    key: string,
    requestFactory: () => Observable<T>,
    refCount = true,
    cacheTag?: string
  ): Observable<T> {
    // Look up on subscription so clearCache also affects previously created observables.
    return defer(() => {
      const cached = this.cache.get(key);
      if (cached) {
        return cached.response as Observable<T>;
      }

      const response = defer(requestFactory).pipe(
        catchError((error: unknown) => {
          if (this.cache.get(key)?.response === response) {
            this.cache.delete(key);
          }
          return throwError(() => error);
        }),
        // Opted-in POST/PUT requests finish even if callers unsubscribe mid-request.
        shareReplay({ bufferSize: 1, refCount })
      );
      this.cache.set(key, { url, cacheTag, response });
      return response;
    });
  }

  private cacheKey(method: string, url: string, options: ApiRequestOptions): string {
    const headers =
      options.headers instanceof HttpHeaders ? options.headers : new HttpHeaders(options.headers);
    const params =
      options.params instanceof HttpParams
        ? options.params
        : new HttpParams({ fromObject: options.params });
    const context = options.context;
    if (context && !this.contextIds.has(context)) {
      this.contextIds.set(context, ++this.nextContextId);
    }
    return JSON.stringify([
      method,
      url,
      params
        .keys()
        .sort()
        .map((key) => [key, params.getAll(key)]),
      headers
        .keys()
        .sort()
        .map((key) => [key.toLowerCase(), headers.getAll(key)]),
      options.withCredentials ?? false,
      context ? this.contextIds.get(context) : null,
    ]);
  }

  private serializeBody(body: unknown): string | undefined {
    // Equivalent JSON objects share a key regardless of their property order.
    return JSON.stringify(body, (_key, value: unknown) => {
      if (value && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) {
        return Object.fromEntries(
          Object.entries(value).sort(([left], [right]) => left.localeCompare(right))
        );
      }

      return value;
    });
  }
}
