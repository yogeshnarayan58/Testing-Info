import test from "@playwright/test";
import {
  findDataSetByName,
  getTestDataByLocale,
  getDimensionSelectionsByPivot,
  hasPivotInDimensionSelections,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import localizationData from "./test-data/localization-data.json";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import assertionData from "./assertion-data/assertion-data.json";
import { InsightsPanel } from "../../../common/components/insights-panel/insights-panel";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { assert } from "@gfk/gta";
import { ExportComponent } from "../../../common/components/export/export";
import { RUN_TEST_TIMEOUT, MAX_TEST_TIMEOUT, SMALL_TIMEOUT } from "../../../constants/time-out-constants";
import { FormatPanel } from "../../../common/components/format-panel/formatPanel";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { ConfigurePanel } from "../../../common/pages/configure-panel/configure-panel";
import * as noDataTestData from "./test-data/no-data-test-data.json";
import { ReportPage } from "../../../common/pages/report-page/report-page";
import { QiBsfShiftingAnalysis } from "./qi-bsf-shifting-analysis";
import { FindMyStuff } from "../../../common/pages/find-my-stuff-page/find-my-stuff-page";
import { ReportFlowPage } from "../../../common/pages/report-flow-page/report-flow-page";


let reportTestData = findDataSetByName(devTestData, config.DATASET);
let reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Product";
let formatPanel: FormatPanel;

test.describe("Shifting analysis(Quick Insights) - Product Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData =
      reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn("Skipping tests as the required pivot test data is not present");
    }
    test.skip(!isValidTestData, "Skipping tests as the required pivot test data is not present");
  });

  test(
    "QuickLook: Should display correct preview information when template is selected",
    {
      tag: "@QI:QuickLook",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      let landingPage = new LandingPage(basePage);
      await landingPage.navigateToUrl(config.BASE_URL);
      await landingPage.clickAnalyseMyData();
      await landingPage.clickChooseATemplate();
      let chooseAtemplatePage = new ChooseAtemplatePage(landingPage.getBasePage());
      await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
      await chooseAtemplatePage.hoverThumbnailBySrc(devTestData.common.thumbnailSrc);
      await chooseAtemplatePage.clickQuickLookInfoButton();
      let quickLookPage = new QuickLookPage(chooseAtemplatePage.getBasePage());
      const previewDescriptionValue = await quickLookPage.getPreviewDescription();
      assert(previewDescriptionValue).toBe(localeData.description);
      const themesValue = await quickLookPage.getPreviewThemes();
      assertionData.common.themes.forEach((expectedTheme: string) => {
        assert(themesValue).toContain(expectedTheme);
      });
      const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
      assertionData.common.dataSets.forEach((expectedDataset: string) => {
        assert(previewDatasetsValue).toContain(expectedDataset);
      });
    }
  );

  test(
    "Insights Panel: Should validate business questions and report metadata",
    {
      tag: "@QI:Insights",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      const insightsPanel = new InsightsPanel(basePage);
      await insightsPanel.navigateToUrl(reportUrl);
      await insightsPanel.clickInsightsIcon();
      const isTitleVisible = await insightsPanel.isReportInsightsTitleVisible();
      assert(isTitleVisible).toBeTruthy();
      const isCloseIconVisible = await insightsPanel.isReportInsightsPanelCloseIconVisible();
      assert(isCloseIconVisible).toBeTruthy();
      const insightsReportTitle = await insightsPanel.getInsightsReportTitle();
      assert(insightsReportTitle?.trim()).toBe(localeData.title);
      const description = await insightsPanel.getInsightsPanelDescription();
      assert(description?.trim()).toBe(localeData.description);
      const isBusinessTitleVisible = await insightsPanel.isBusinessQuestionsTitleVisible();
      assert(isBusinessTitleVisible).toBeTruthy();
      await insightsPanel.validateBusinessQuestions(localeData.businessQuestions);
      await insightsPanel.closeInsightsPanel();
    }
  );

  test(
    "Validate the pivot selection",
    {
      tag: "@QI:Pivot List Verification",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      dataSelector = new DataSelector(basePage);
      await dataSelector.navigateToUrl(reportUrl);
      await dataSelector.assertPivotDropdown(
        reportAssertData["dataSummary"]["pivot"]["pivotList"]
      );
    }
  );

  test(
    "Validate default format panel",
    {
      tag: "@QI:Format Panel Default Verification",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      formatPanel = new FormatPanel(basePage);
      await formatPanel.navigateToUrlAndCheckMadlibVisbility(reportUrl);
      await formatPanel.openFormatPanel();
      await formatPanel.testDefaultFormatPanel(reportAssertData["formatPanel"]["default"]);
      await formatPanel.closeFormatPanel();
    }
  );

  test(
    "Validate Configure Panel",
    {
      tag: "@QI:configurepanel",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(reportUrl);

      let commonBasePage = commonTestCase.getBasePage();
      let configurePanel = new ConfigurePanel(commonBasePage);

      await configurePanel.openConfigurePanel();

      await configurePanel.validateRadioOptions(
        reportAssertData["configurePanel"]["breakDown"]["options"],
        reportAssertData["configurePanel"]["breakDown"]["defaultSelection"],
        "Breakdown"
      );

      await configurePanel.validateRadioOptions(
        reportAssertData["configurePanel"]["changeType"]["options"],
        reportAssertData["configurePanel"]["changeType"]["defaultSelection"],
        "Change Type"
      );
    }
  );

  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@QI:MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(reportUrl);
      let commonBasePage = commonTestCase.getBasePage();
      dataSelector = new DataSelector(commonBasePage);

      if (localeData.pivotMadlibText) {
        const actualMadlibText = await dataSelector.getMadlibText();
        const expectedMadlibText = (localeData.pivotMadlibText as any).product;
        assert(actualMadlibText).toMatch(new RegExp(expectedMadlibText, "i"));
      } else {
        console.warn(`No madlib text pattern defined for locale: ${localeData.locale}`);
      }
    }
  );

  test.describe.serial(
    "Run, PPT Export, Excel Export, Add Blank Report",
    { tag: ["@QI:Report_E2E_Flow"] },
    () => {
      test(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@QI:RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);

          const productPivotData = getDimensionSelectionsByPivot(pivot, reportTestData);
          if (!productPivotData) {
            throw new Error("Pivot not found in test data: Product");
          }

          const result = await runReportWithData(productPivotData, reportUrl);
          savedReportTitle = result.savedReportTitle;
          savedReportUrl = result.savedReportUrl;
        }
      );


      test(
        "Validate Add Blank Report",
        {
          tag: "@QI:ValidateAddBlankReport",
        },
        async () => {
          test.skip(!savedReportUrl, 'Skipping Add Blank Report - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

          // Budget covers: load saved report, copy it, reload the copy, then a full blank-report run
          test.setTimeout(RUN_TEST_TIMEOUT * 2 + MAX_TEST_TIMEOUT * 2);
          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);

          // Make a copy of the current report
          const { newReportTitle, newUrl } = await commonTestCase.makeAcopy();

          // makeAcopy only closes the tab; release the browser before launching the next one
          await basePage.closeBrowserInstance();

          // Create a new CommonTestCase for the new report flow  
          let newBasePage = await BasePageFactory.createBasePage();
          let newCommonTestCase = new CommonTestCase(newBasePage);

          // Navigate to the new URL using CommonTestCase
          await newCommonTestCase.navigateToReportUrl(newUrl);

          // Create ReportFlowPage with the same base page
          let reportFlowPage = new ReportFlowPage(newBasePage);

          // Test the correct workflow: Add Menu -> Add Blank Report
          await reportFlowPage.clickAddMenuIcon();

          // Wait briefly for dropdown to appear
          await reportFlowPage.webActionHandler.delay(SMALL_TIMEOUT);

          // Validate all three dropdown options are present
          await reportFlowPage.validateAddMenuDropdownOptions();

          // Click "Add blank report" option directly from dropdown
          await reportFlowPage.clickAddBlankReportOption();
  
          // Wait for blank report to be created
          await reportFlowPage.waitForBlankReportIndicator();

          // Validate that blank report was created successfully
          await reportFlowPage.validateBlankReportCreation();
          // Validate that the report title shows 'Untitled'
          await reportFlowPage.validateUntitledReportTitle();

          // Run the complete blank report workflow (dataset selector, apply dataset, madlib selections, and report execution)
          await reportFlowPage.runBlankReport(config.DATASET);

          // Switch back to the original report tab
          await reportFlowPage.clickReportByName(newReportTitle);

          // Wait for the madlib to stabilize and validate it's loaded properly
          const dataSelector = new DataSelector(newBasePage);
          await dataSelector.waitForMadlibStability();
          const madlibText = await dataSelector.getMadlibText();

          // Assert that madlib text is not empty and contains expected content
          assert(madlibText.length).toBeGreaterThan(0);
        }
      )

      test(
        "Validate FullScreen",
        {
          tag: "@QI:ValidateFullScreen",
        },
        async () => {
          test.skip(!savedReportUrl, "Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.fullScreenView();
        }
      );

      test(
        "Validate presentationMode",
        {
          tag: "@QI:PresentationMode",
        },
        async () => {
          test.skip(!savedReportUrl, "Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          await commonTestCase.presentationMode();
        }
      );

      test(
        "Validate PPT export",
        {
          tag: "@QI:ValidatePPTExport",
        },
        async () => {
          test.skip(!savedReportUrl, "Skipping PPT Export - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          let exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality(
            "PowerPoint",
            "Editable objects",
            "Separately"
          );
        }
      );

      test(
        "Validate Excel export",
        {
          tag: "@QI:ValidateExcelExport",
        },
        async () => {
          test.skip(!savedReportUrl, "Skipping Excel Export - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let commonBasePage = commonTestCase.getBasePage();
          let exportComponent = new ExportComponent(commonBasePage);
          await exportComponent.validateExportFunctionality(
            "Excel",
            "Editable objects",
            "Separately"
          );
        }
      );

      test("Validate snapshot", { tag: "@QI:Snapshot" }, async () => {
        test.skip(!savedReportUrl, "Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        const commonTestCase = new CommonTestCase(basePage);
        await commonTestCase.navigateToReportUrl(savedReportUrl);
        let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
        await snapshot.waitForReportRunCompletion();
        await snapshot.clickSaveIcon();
        await snapshot.clickSnapshotIcon();
        assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
        await commonTestCase.webActionHandler.delay(SMALL_TIMEOUT);
        let snapshotUrl: string = await snapshot.shiftingToSnapshot();
        console.log("Snapshot shifted to right:", snapshotUrl);
      });



      test("openCurrentReportFMS", { tag: "@QI:openCurrentReportFMS" }, async () => {
        test.skip(!savedReportTitle, "Skipping openCurrentReportFMS - Report not generated. Run with @RunReport first or use @Report_E2E_Flow");

        let basePage = await BasePageFactory.createBasePage();
        let findMyStuff = new FindMyStuff(basePage);
        await findMyStuff.navigateToUrl(config.BASE_URL);
        await findMyStuff.clickFindMyStuff();
        await findMyStuff.openCurrentReportFMS(savedReportTitle);

        const openedReportUrl = await findMyStuff.webActionHandler.getPageUrl();
        assert(new URL(openedReportUrl).pathname).toBe(new URL(savedReportUrl).pathname);
      });
    }
  );

  test(
    "No data report run",
    {
      tag: "@QI:NoDataRun",
    },
    async () => {
      test.setTimeout(RUN_TEST_TIMEOUT);
      const noDataDataset = findDataSetByName(noDataTestData, config.DATASET);
      if (!noDataDataset) {
         throw new Error(`No-data test dataset not found for DATASET="${config.DATASET}"`);
       }
      const noDataReportUrl = config.BASE_URL + noDataDataset?.navUrlWithDataSetId;
      const productPivotData = getDimensionSelectionsByPivot(pivot, noDataDataset);
      if (!productPivotData) {
        throw new Error(`Pivot not found in test data: Product`);
      }
      const result = await runReportWithData(productPivotData, noDataReportUrl);
      let basePage = await BasePageFactory.createBasePage();
      let commonTestCase = new CommonTestCase(basePage);
      await commonTestCase.navigateToReportUrl(result.savedReportUrl);
      await commonTestCase.waitForReportRunCompletion(); 
      let commonBasePage = await commonTestCase.getBasePage();
      let reportPage = new ReportPage(commonBasePage);
      let reportPageBED = new QiBsfShiftingAnalysis(commonBasePage);
      const containerParentElement = reportPageBED.resourceManager.getResource("reportContainerTag");
      await reportPage.assertNoDataFoundByParentElement(containerParentElement);
    }
  );
});

async function runReportWithData(
  testData: any,
  reportUrl: string
): Promise<{ savedReportTitle: string; savedReportUrl: string }> {
  let basePage = await BasePageFactory.createBasePage();
  let commonTestCase = new CommonTestCase(basePage);
  await commonTestCase.navigateToReportUrl(reportUrl);

  let commonBasePage = commonTestCase.getBasePage();
  let dataSelector = new DataSelector(commonBasePage);

  await dataSelector.waitForMadlibStability();

  await dataSelector.clickMadlibDimension("Shifting Universe Product");
  await dataSelector.setMadlibSelection(testData["Shifting Universe Product"]);

  await dataSelector.clickMadlibDimension("Facts");
  await dataSelector.selectClosedDropdown(testData["Facts"]["selections"]);

  await dataSelector.clickMadlibDimension("Comparison Products PRDC");
  await dataSelector.setMadlibSelection(testData["Comparison Products PRDC"]);

  await dataSelector.clickMadlibDimension("Retailers");
  await dataSelector.setMadlibSelection(testData["Retailers"]);

  await dataSelector.clickMadlibDimension("Period");
  await dataSelector.setPeriodMadlibSelection(testData["Period"]);

  await dataSelector.clickMadlibDimension("Comparison Period");
  await dataSelector.setPeriodMadlibSelection(testData["Comparison Period"]);

  await dataSelector.clickMadlibDimension("Geography");
  await dataSelector.setMadlibSelection(testData["Geography"]);

  await dataSelector.clickMadlibDimension("Demographic");
  await dataSelector.setMadlibSelection(testData["Demographic"]);

  let dsBasePage = dataSelector.getBasePage();
  commonTestCase = new CommonTestCase(dsBasePage);
  await commonTestCase.clickRunButton();
  await commonTestCase.waitForReportRunCompletion();

  const { newReportTitle, newUrl } = await commonTestCase.saveReport();

  console.log("savedReportTitle:", newReportTitle);
  console.log("savedReportUrl:", newUrl);

  return {
    savedReportTitle: newReportTitle,
    savedReportUrl: newUrl,
  };
}
