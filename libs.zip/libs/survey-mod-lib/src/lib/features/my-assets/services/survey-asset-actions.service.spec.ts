import { SURVEY_ACCESS_AVAILABILITY } from '../constants/survey-status.constant';
import { TestBed } from '@angular/core/testing';
import { ACAssetManageApiService, ACFetchApiService, AssignRightsHelperService } from '@nielsen/crf-lp-common';
import { EMPTY, firstValueFrom, of, throwError } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SurveyGridRow } from '../models/survey-asset.model';
import { SurveyAssetActionsService } from './survey-asset-actions.service';

vi.mock('@nielsen/crf-lp-common', () => ({
  ACAssetManageApiService: class {},
  ACFetchApiService: class {},
  AssignRightsHelperService: class {},
  AssetTypes: { SHARED_FOLDER: 'DISCOVERSHAREDFOLDER', FOLDER: 'DISCOVERFOLDER' },
  PrimarySort: { NAME: 'NAME' },
  SortOrder: { ASC: 'ASC' },
}));

describe('SurveyAssetActionsService', () => {
  let service: SurveyAssetActionsService;
  let fetch: { getMyFolders: ReturnType<typeof vi.fn>; getAssetInfoByAssetId: ReturnType<typeof vi.fn> };
  let manage: {
    renameAsset: ReturnType<typeof vi.fn>; moveAssets: ReturnType<typeof vi.fn>; editAssets: ReturnType<typeof vi.fn>;
    trashAssets: ReturnType<typeof vi.fn>; restoreAssets: ReturnType<typeof vi.fn>; deletePermanently: ReturnType<typeof vi.fn>;
  };
  let inheritParentAndRights: ReturnType<typeof vi.fn>;
  const row: SurveyGridRow = {
    assetId: 'survey-1', assetType: 'DISCOVERSURVEY', title: 'Survey', lastModifiedTimestamp: 0,
  };
  const root = { assetId: 'root', title: 'My assets' };
  const folder = { assetId: 'folder-1', assetType: 'DISCOVERFOLDER', title: 'Folder', rights: [] };
  const freshSurvey = () => ({ ...row, rights: [] });

  beforeEach(() => {
    fetch = {
      getMyFolders: vi.fn().mockReturnValue(of({ data: { assets: [folder] } })),
      getAssetInfoByAssetId: vi.fn().mockReturnValue(of([freshSurvey(), folder])),
    };
    manage = {
      renameAsset: vi.fn().mockReturnValue(of({ success: true })),
      moveAssets: vi.fn().mockReturnValue(of({ success: true })),
      editAssets: vi.fn().mockReturnValue(of({ success: true })),
      trashAssets: vi.fn().mockReturnValue(of({ success: true })),
      restoreAssets: vi.fn().mockReturnValue(of({ success: true })),
      deletePermanently: vi.fn().mockReturnValue(of({ success: true })),
    };
    inheritParentAndRights = vi.fn().mockReturnValue([{ assetId: row.assetId, parentAsset: { assetId: folder.assetId } }]);
    TestBed.configureTestingModule({
      providers: [
        SurveyAssetActionsService,
        { provide: ACFetchApiService, useValue: fetch },
        { provide: ACAssetManageApiService, useValue: manage },
        { provide: AssignRightsHelperService, useValue: { inheritParentAndRights } },
      ],
    });
    service = TestBed.inject(SurveyAssetActionsService);
  });

  afterEach(() => TestBed.resetTestingModule());

  it('loads the same folder types and alphabetical sort as Landing Page', async () => {
    expect(await firstValueFrom(service.fetchMoveFolders())).toEqual([folder]);
    expect(fetch.getMyFolders).toHaveBeenCalledWith(
      ['DISCOVERSHAREDFOLDER', 'DISCOVERFOLDER'], { primarySort: 'NAME', sortOrder: 'ASC' }, false, false
    );
  });

  it('uses the shared rename API without mutating grid data', async () => {
    await firstValueFrom(service.renameAsset(row.assetId, 'Updated title'));
    expect(manage.renameAsset).toHaveBeenCalledWith(row.assetId, 'Updated title', false);
    expect(row.title).toBe('Survey');
  });

  it('fetches fresh source and destination rights before using the shared inheritance and edit APIs', async () => {
    await firstValueFrom(service.moveAssets([row], folder));
    expect(fetch.getAssetInfoByAssetId).toHaveBeenCalledWith('survey-1,folder-1', {
      userDetails: true, orderManagementDetails: true, displayAllRights: true, parentAsset: true,
    }, false);
    expect(inheritParentAndRights).toHaveBeenCalledWith([freshSurvey()], folder);
    expect(manage.editAssets).toHaveBeenCalledWith(inheritParentAndRights.mock.results[0].value, {}, false, false);
    expect(manage.moveAssets).not.toHaveBeenCalled();
  });

  it('retains live user and COG rights and removes obsolete rights without mutating fetched assets', async () => {
    const user = { userId: 'user-1', availability: SURVEY_ACCESS_AVAILABILITY.OWNED, userInfo: {} };
    const cog = { orderManagementType: 'COG', orderManagementInfo: {} };
    const deleted = { userId: 'deleted-user', availability: SURVEY_ACCESS_AVAILABILITY.VIEW };
    const source = { ...row, rights: [user, cog, deleted] };
    const target = { ...folder, assetType: 'DISCOVERSHAREDFOLDER', rights: [user, deleted] };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([target, source]));
    await firstValueFrom(service.moveAssets([row], target));
    expect(inheritParentAndRights).toHaveBeenCalledWith(
      [{ ...source, rights: [user, cog] }], { ...target, rights: [user] }
    );
    expect(source.rights).toEqual([user, cog, deleted]);
    expect(target.rights).toEqual([user, deleted]);
  });

  it('uses the shared parent-removal flow for moves back to My assets', async () => {
    const source = { ...freshSurvey(), parentAsset: { assetId: 'old-folder' } };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([source]));
    await firstValueFrom(service.moveAssets([row], root));
    expect(fetch.getAssetInfoByAssetId.mock.calls[0][0]).toBe('survey-1');
    expect(manage.moveAssets).toHaveBeenCalledWith([source], root, false);
    expect(manage.editAssets).not.toHaveBeenCalled();
  });

  it('moves multiple surveys and omits surveys already in the destination', async () => {
    const secondRow = { ...row, assetId: 'survey-2' };
    const secondSource = { ...secondRow, rights: [] };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([
      { ...freshSurvey(), parentAsset: { assetId: folder.assetId } }, secondSource, folder,
    ]));
    await firstValueFrom(service.moveAssets([row, secondRow], folder));
    expect(inheritParentAndRights).toHaveBeenCalledWith([secondSource], folder);
  });

  it('omits root-level assets from bulk moves to root', async () => {
    const secondRow = { ...row, assetId: 'survey-2' };
    const secondSource = { ...secondRow, parentAsset: { assetId: folder.assetId }, rights: [] };
    fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey(), secondSource]));
    await firstValueFrom(service.moveAssets([row, secondRow], root));
    expect(manage.moveAssets).toHaveBeenCalledWith([secondSource], root, false);
  });

  it.each([
    { rows: [] },
    { rows: Array.from({ length: 21 }, () => row) },
    { rows: [{ ...row, assetType: 'DISCOVERFOLDER' }] },
  ])(
    'rejects unsupported selections before making a request',
    async ({ rows }) => {
      await expect(firstValueFrom(service.moveAssets(rows, folder))).rejects.toThrow('between 1 and 20 surveys');
      expect(fetch.getAssetInfoByAssetId).not.toHaveBeenCalled();
    }
  );

  it('rejects non-folder destinations', async () => {
    await expect(firstValueFrom(service.moveAssets([row], { assetId: 'other', assetType: 'DISCOVERSURVEY' })))
      .rejects.toThrow('valid destination folder');
  });

  it('rejects moves into the current folder or from root to root', async () => {
    fetch.getAssetInfoByAssetId.mockReturnValue(of([{ ...freshSurvey(), parentAsset: { assetId: folder.assetId } }, folder]));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow('already in this location');
    fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey()]));
    await expect(firstValueFrom(service.moveAssets([row], root))).rejects.toThrow('already in this location');
  });

  it('fails explicitly if sources, destinations or access information are missing', async () => {
    for (const assets of [[folder], [freshSurvey()], [row, folder]]) {
      fetch.getAssetInfoByAssetId.mockReturnValue(of(assets));
      await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow();
    }
    expect(manage.editAssets).not.toHaveBeenCalled();
  });

  it.each([
    [{ ...row, rights: [], status: 'TRASHED' }, folder],
    [freshSurvey(), { ...folder, status: 'TRASHED' }],
  ])('rejects stale assets that are no longer eligible for moving', async (source, target) => {
    fetch.getAssetInfoByAssetId.mockReturnValue(of([source, target]));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow('no longer available for moving');
    expect(manage.editAssets).not.toHaveBeenCalled();
  });

  it('propagates lookup and mutation errors instead of reporting success', async () => {
    const error = new Error('Request failed');
    fetch.getAssetInfoByAssetId.mockReturnValueOnce(throwError(() => error));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toBe(error);
    manage.editAssets.mockReturnValueOnce(throwError(() => error));
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toBe(error);
    manage.renameAsset.mockReturnValueOnce(throwError(() => error));
    await expect(firstValueFrom(service.renameAsset(row.assetId, 'New title'))).rejects.toBe(error);
  });

  it('treats empty completions as failures, not successful operations', async () => {
    fetch.getMyFolders.mockReturnValue(EMPTY);
    manage.renameAsset.mockReturnValue(EMPTY);
    manage.editAssets.mockReturnValue(EMPTY);
    await expect(firstValueFrom(service.fetchMoveFolders())).rejects.toThrow('did not return a result');
    await expect(firstValueFrom(service.renameAsset(row.assetId, 'New title'))).rejects.toThrow('did not return a result');
    await expect(firstValueFrom(service.moveAssets([row], folder))).rejects.toThrow('did not return a result');
  });

  describe('trashAssets', () => {
    it('fetches fresh asset details (for parentAsset/rights) before trashing, like moveAssets does', async () => {
      fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey()]));
      await firstValueFrom(service.trashAssets([row]));
      expect(fetch.getAssetInfoByAssetId).toHaveBeenCalledWith('survey-1', {
        userDetails: true, orderManagementDetails: true, displayAllRights: true, parentAsset: true,
      }, false);
      expect(manage.trashAssets).toHaveBeenCalledWith([freshSurvey()], false);
    });

    it('trashes multiple assets (bulk delete / delete folder use the same call)', async () => {
      const secondRow = { ...row, assetId: 'folder-1', assetType: 'DISCOVERFOLDER' };
      fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey(), folder]));
      await firstValueFrom(service.trashAssets([row, secondRow]));
      expect(fetch.getAssetInfoByAssetId.mock.calls[0][0]).toBe('survey-1,folder-1');
      expect(manage.trashAssets).toHaveBeenCalledWith([freshSurvey(), folder], false);
    });

    it('rejects an empty selection before making any request', async () => {
      await expect(firstValueFrom(service.trashAssets([]))).rejects.toThrow('Select at least one asset');
      expect(fetch.getAssetInfoByAssetId).not.toHaveBeenCalled();
      expect(manage.trashAssets).not.toHaveBeenCalled();
    });

    it('fails explicitly when a selected asset is no longer available', async () => {
      fetch.getAssetInfoByAssetId.mockReturnValue(of([]));
      await expect(firstValueFrom(service.trashAssets([row]))).rejects.toThrow('no longer available');
      expect(manage.trashAssets).not.toHaveBeenCalled();
    });

    it('propagates lookup and mutation errors, and treats empty completions as failures', async () => {
      const error = new Error('Request failed');
      fetch.getAssetInfoByAssetId.mockReturnValueOnce(throwError(() => error));
      await expect(firstValueFrom(service.trashAssets([row]))).rejects.toBe(error);
      manage.trashAssets.mockReturnValueOnce(throwError(() => error));
      await expect(firstValueFrom(service.trashAssets([row]))).rejects.toBe(error);
      manage.trashAssets.mockReturnValue(EMPTY);
      await expect(firstValueFrom(service.trashAssets([row]))).rejects.toThrow('did not return a result');
    });
  });

  describe('restoreAssets', () => {
    it('fetches fresh asset details (for parentAsset.status) before restoring', async () => {
      const trashedParentChild = { ...freshSurvey(), parentAsset: { assetId: folder.assetId, status: 'TRASHED' } };
      fetch.getAssetInfoByAssetId.mockReturnValue(of([trashedParentChild]));
      await firstValueFrom(service.restoreAssets([row]));
      expect(fetch.getAssetInfoByAssetId).toHaveBeenCalledWith('survey-1', {
        userDetails: true, orderManagementDetails: true, displayAllRights: true, parentAsset: true,
      }, false);
      expect(manage.restoreAssets).toHaveBeenCalledWith([trashedParentChild], false);
    });

    it('rejects an empty selection before making any request', async () => {
      await expect(firstValueFrom(service.restoreAssets([]))).rejects.toThrow('Select at least one asset');
      expect(manage.restoreAssets).not.toHaveBeenCalled();
    });

    it('fails explicitly when a selected asset is no longer available', async () => {
      fetch.getAssetInfoByAssetId.mockReturnValue(of([]));
      await expect(firstValueFrom(service.restoreAssets([row]))).rejects.toThrow('no longer available');
      expect(manage.restoreAssets).not.toHaveBeenCalled();
    });

    it('propagates mutation errors and treats empty completions as failures', async () => {
      fetch.getAssetInfoByAssetId.mockReturnValue(of([freshSurvey()]));
      const error = new Error('Request failed');
      manage.restoreAssets.mockReturnValueOnce(throwError(() => error));
      await expect(firstValueFrom(service.restoreAssets([row]))).rejects.toBe(error);
      manage.restoreAssets.mockReturnValue(EMPTY);
      await expect(firstValueFrom(service.restoreAssets([row]))).rejects.toThrow('did not return a result');
    });
  });

  describe('deletePermanently', () => {
    it('deletes by assetId only, without re-fetching fresh asset details first', async () => {
      await firstValueFrom(service.deletePermanently([row, { ...row, assetId: 'survey-2' }]));
      expect(fetch.getAssetInfoByAssetId).not.toHaveBeenCalled();
      expect(manage.deletePermanently).toHaveBeenCalledWith(
        [{ assetId: 'survey-1' }, { assetId: 'survey-2' }], false
      );
    });

    it('rejects an empty selection before making any request', async () => {
      await expect(firstValueFrom(service.deletePermanently([]))).rejects.toThrow('Select at least one asset');
      expect(manage.deletePermanently).not.toHaveBeenCalled();
    });

    it('propagates mutation errors and treats empty completions as failures', async () => {
      const error = new Error('Request failed');
      manage.deletePermanently.mockReturnValueOnce(throwError(() => error));
      await expect(firstValueFrom(service.deletePermanently([row]))).rejects.toBe(error);
      manage.deletePermanently.mockReturnValue(EMPTY);
      await expect(firstValueFrom(service.deletePermanently([row]))).rejects.toThrow('did not return a result');
    });
  });
});
