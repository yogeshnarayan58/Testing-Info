# Select Panelists — MEDIUM test cases: investigation

Scope: read-only investigation. Only this file was written (e2e/investigation/ is gitignored via e2e/.gitignore).

Source files inspected
- App: `libs/survey-mod-lib/src/lib/features/select-panelist/components/select-panelist.component.{html,ts}`,
  `.../panelist-dataselector/panelist-dataselector.component.{html,ts}`,
  `libs/survey-mod-lib/src/lib/shared/components/dataset-footer/dataset-footer.component.html`,
  `.../crf-survey-wrapper/crf-survey-wrapper.component.html`, `.../shared/utils/survey-dataset-display.util.ts`
- External (node_modules, read only): `@nielsen/crf-rv-common` dataset-selector (Product Offering modal), `@nielseniq/athena-core` niq-button
- e2e: `page-objects/common/select-panelist.page.ts`, `panelist-flow.helper.ts`, `dataset-selection.helper.ts`,
  `page-objects/survey/start-from-scratch.page.ts`, `locators/survey/select-panelist.locator.json`, `locators/survey/start-from-scratch.locator.json`,
  `tests/survey/start-from-scratch.spec.ts`, `test-data/dev-test-data.json`

Caveat: i18n strings (`SURVEYMOD_*`) are NOT in this repo (provided by the host), so the exact English text could not be verified here.

---

## A) App source

### A1. "Search for Panelists" button — `panelist-dataselector.component.html`
- Element: `<niq-button id="report-btn-run" data-cy="report-btn-run" class="primary-btn run-btn" ...>` (the niq-button HOST element).
- Selector: `#report-btn-run` (existing e2e locator `[id='report-btn-run']`). **Stable id** (hard-coded in template). No `data-test-id`; `data-cy` is also present.
- Rendering rule (`runButtonState`, default `'hidden'`):
  - `hidden` -> element is NOT in the DOM (`@if (!hasCompletedPanelistSearch() && runButtonState !== 'hidden')`). It is hidden before any selection is made and again after the search report completes (`reportCompleted$` -> `'hidden'`).
  - `disabled` -> set after every selection change (`updateDataSelections`, ts ~L382), after dataset change (~L252), or when the prompt-validation event says not `VALID` / no selections (~L146-152).
  - `default` (enabled) -> prompt validation `promptStatus === 'VALID'`.
  - `loading` -> after click.
- How DISABLED is shown (confirmed in app template):
  1. CSS class on the host: `report-btn-run-disabled` (`[ngClass]`).
  2. niq-button input `[state]="'disabled'"` -> niq-button `classes` getter = `${size} ${state} ${mode} ${variant}`, so a `disabled` class token lands on its inner element; `disabled` getter = `super.disabled || state() === 'disabled'`.
  - NOT confirmed (niq-button template is a huge inline string in athena-core): whether a native `disabled` attribute or `aria-disabled` is rendered on the inner `<button>`. Existing e2e code for other niq-buttons checks aria-disabled / `state` attr / class token / inner `.disabled` property (see `survey-builder.page.ts` getAddQuestionDisabledState / Publish). **Recommended assertion:** `#report-btn-run.report-btn-run-disabled` (stable, from our own template) and, for "enabled", `:not(.report-btn-run-disabled)`.
- Gotcha: because the host stays in the DOM while disabled, `isVisible()` is true for disabled AND enabled states.

### A2. "Cancel" on the "Product Offering" modal — NOT in this repo's source
- The modal is rendered by `<re-dataset-picker>` / `crf-dataset-selector` from `@nielsen/crf-rv-common` (node_modules), opened with `openDialog()` (starts at `DialogStep.PRODUCT_OFFERING`), closed with `closeDialog()` / `datasetTypeSelection.close()`.
- Cancel button: `data-test-id="cancel-dataset-btn"` and `id="cancel-dataset-btn"` (found in the compiled template; `cancelDataSetTypeDialog(isCancel)` handler). **Stable id**. Not verified at runtime whether the same id is reused on later steps (Dataset / Data view) — the id looks step-agnostic, so scope it inside the Product Offering container.
- Modal root: `<niq-dialog>` whose container class comes from `getDialogContainerClass()`:
  `ds-picker-container ds-picker-type-selection ds-picker-(new|old)-width`. For the Product Offering step use `.ds-picker-container.ds-picker-type-selection`. **Class-based, no data-test-id on the root found** (`data-test-id="ds-picker-container"` does not exist). Moderately stable (semantic class, but owned by another package).
- Heading: existing e2e locator uses `role=heading[name="Product Offering"]` (text based).
- Next button on that step: `[data-test-id='btn-next-dataset']` (already in e2e).

### A3. "Congratulations there are <count> people eligible for your criteria" — `select-panelist.component.html`
- Container: `<div class="eligibility">` (inside `<panelist-dataselector>` content projection). **No data-test-id** -> class selector `.eligibility` (unstable-ish, styling class).
- Text = `SURVEYMOD_CONGRATULATIONS_THERE_ARE` + ` {{ householdCount }} ` + `SURVEYMOD_PEOPLE_ELIGIBLE_FOR_YOUR_CRITERIA` as plain text nodes in one div. **The count has NO own element** — it must be parsed from `.eligibility` text (regex on digits; value is `eligibleCount.toLocaleString()`, so it can contain thousands separators, e.g. `12,345`).
- Not rendered while `surveyCommonService.dataSelectorLoading()` is true. When `isUnhappyPath` (`eligibleCount <= 100`) the same `.eligibility` div shows `SURVEYMOD_CRITERIA.FAILED` instead (text differs).
- Only rendered when `reportData` is true (after Search for Panelists completes).

### A4. Response-count options and "+ More options" — `select-panelist.component.html`
- Count buttons: `<button [attr.data-test-id]="'select-response-count-' + count">` inside `.responses`; label `"<count> Responses"`. **Stable data-test-id**: `select-response-count-100|150|200|250|300|400|500` (base list `[100,150,200,250,300,400,500]`).
- Extra options after More: 600, 700, 800, 900, 1000 -> `select-response-count-600..1000`.
- Filtering: `filteredResponseCounts` only renders counts `<= eligibleCount`; renders none when `isUnhappyPath` (eligibleCount <= 100). So the full 100..500 list only appears when eligible count >= 500.
- Selected state: class `selected` on the button (`.responses button.selected`).
- "+ More options" button: `<button class="more-options" data-test-id="toggle-more-response-options">`. **Stable data-test-id**. Rendered ONLY when `flowType().scratch` (Start from scratch flow; not in the AI/prompt flow). Text toggles `+ More options` <-> `− Fewer options` (the +/− is in a `<span aria-hidden="true">`).

### A5. "More responses takes longer and also affects metering. 100 responses = 1 credit"
- `<div class="question">` inside `<div class="responses-frame">` — text from `SURVEYMOD_EXPECTED_RESPONSES_MESSAGE` with params `{response: 100, credit: 1}`. **No data-test-id**; use `.responses-frame .question` (class) or text match.
- Rendered only when `!isUnhappyPath && !dataSelectorLoading()` (and `reportData`).

### A6. Footer — `survey-dataset-footer` (`dataset-footer.component.html`), hosted in `crf-survey-wrapper`
- Visibility: `surveyCommonService.datasetFooterVisible()`; `select-panelist.component.ts` ngOnInit sets it to true. Wrapper div: `.dataset-footer` (gets `read-only` class when not editable).
- Source label: `<span class="dataset-label">` (text `SURVEYMOD_SOURCE`, "Source"). No test id.
- Value: `<span class="selected-value">` — ONE string built by `buildDatasetDisplay()`: `NielsenIQ <datasetTypeName> | <datasetTitle> | <dataViewName>` (parts joined with `" | "`, empties dropped). So **source name, dataset name and view are NOT separate elements**; "Entire Dataset" is the `dataView.dataViewName` (3rd segment) — split on `" | "`. The span has `id="select-dataset"` ONLY when the footer is editable (`isEditable()`); otherwise no id. Click on it triggers `onDatasetFooterClick()` (re-opens the dataset picker).
- Last refreshed: `<div id="refreshedOnBlock" data-test-id="rb-report-refreshed-on-block"><span>Last refreshed: {{ refreshedDate() }}</span></div>`. **Stable data-test-id + id**. Rendered only `@if (refreshedDate())` (absent when no date).
- Date format is whatever `surveyCommonService.getRefreshedDate()` provides (not formatted in the template).

### Other relevant Select Panelist elements (found while investigating)
- Page "Cancel" button: `<button class="cancel">` in `.footer` of select-panelist.component.html — NO test id and no click handler; unrelated to the Product Offering modal's Cancel.
- "Proceed to survey builder" / "Generate survey": `[data-test-id='proceed-to-survey']`, `[disabled]` native attribute when no response count selected (a true native `disabled` attribute).
- Dimension tiles: `ds-noDataPrompt_<Label>` (empty) / `ds-<Label>_Dimension` (filled) from `@nielsen/crf-data-summary`.

---

## B) e2e today

### B1. Coverage by item

| Item | Locator (select-panelist.locator.json / start-from-scratch.locator.json) | Method | Verdict |
|---|---|---|---|
| Search for Panelists button | `searchForPanelistsButton` = `[id='report-btn-run']` | `clickSearchForPanelists()`, `isSearchForPanelistsButtonVisible()` | Exists, but **no disabled/enabled check** (visible is true when disabled). Note `waitFor()` will time out if the button is still `hidden` (before any selection). |
| Product Offering modal root / Cancel | none (only `productOfferingHeading` role=heading and `nextButton` `btn-next-dataset`) | `StartFromScratchPage.selectProductOffering()` (Next only) | **Missing**: no Cancel locator, no modal root, no "is modal open" check. |
| Eligibility message / count | none | none | **Missing** |
| Response-count options | `250ResponsesButton` (text `250 Responses`), `selectedResponseCountButton` (`.responses button.selected`) | `click250Responses()`, `getSelectedResponseCountDataTestId()` | Partial: only 250 is clickable; no generic `select-response-count-<n>`, no list of rendered options. `selectedResponseCountButton` returns data-test-id. |
| "+ More options" button | none | none | **Missing** |
| "100 responses = 1 credit" message | none | none | **Missing** |
| Footer (source / dataset / view) | none | none | **Missing** |
| Footer "Last refreshed" | none | none | **Missing** |
| Proceed button | `proceedToSurveyBuilderButton` | `clickProceedToSurveyBuilder()`, `isProceedToSurveyBuilderVisible()` | Exists (visible only; no disabled check) |
| Dimension tiles / filled tiles | `*NoDataPrompt`, `filledDimensionTile`, `addButton`, `removeIcon`, ... | `setDimensionSelection(s)`, `isDimensionSelectionRetained()` | Exists |
| Dataset-picker helpers | start-from-scratch.locator.json: `searchToggle`, `searchInput`, `datasetByLabel`, `defaultDataset`, `chooseDatasetBreadcrumb` (`dataset-picker-title`), `chooseDataviewBreadcrumb`, `dialogElement` (`title-second-dialog`), `applyButton` | `searchAndSelectDataset()` (dataset-selection.helper.ts), `applyEntireDataset()`, `proceedToNextAfterDatasetSelection()` | Exists |

Other facts:
- `panelist-flow.helper.ts` exports `completePanelistSelectionFlow(basePage, dimensionSelections)` = setDimensionSelections -> clickSearchForPanelists -> click250Responses -> clickProceedToSurveyBuilder -> isBuildSurveyPageLoaded. It is only defined; no references found in `e2e/**/*.ts`. It has NO partial/intermediate hooks.
- `dataset-selection.helper.ts` has no Cancel/close logic; it ends by clicking a dataset item. It handles "already on dataview screen" by returning true.

### B2. How the Product Offering modal is opened/closed today
- **Opened implicitly**: `StartFromScratchPage.clickStartFromScratch()` clicks `[data-testid='quick-survey-quick-2']`; the app then opens the picker at Product Offering (`openDialog()`).
- `selectProductOffering(_productOffering)` (argument ignored): if heading `role=heading[name="Product Offering"]` is visible, waits for it and clicks `[data-test-id='btn-next-dataset']` (Next). If the heading isn't shown it silently returns.
- **Closed implicitly only by progressing**: Next -> dataset step -> `searchAndSelectDataset` -> `proceedToNextAfterDatasetSelection()` clicks `[data-test-id='apply-dataset-btn']` -> `applyEntireDataset()` waits for `[data-test-id='title-second-dialog']` and clicks `apply-dataset-btn` again. There is NO explicit close/cancel and no assertion that the modal is closed or open.
- To automate the Cancel case you need new locators: `[data-test-id='cancel-dataset-btn']` and root `.ds-picker-container.ds-picker-type-selection`, plus visibility waits; and decide what is expected after Cancel (the app-side `cancelDataSetTypeDialog(isCancel=true)` -> `emitDatasetOnCancel` — behaviour not exercised in e2e).

### B3. Can `setDimensionSelection` be called for 4 of 5 filters only, then the 5th later?
**Yes.** 
- `setDimensionSelections(selections[])` is just a for-loop over `setDimensionSelection(...)`, each call is independent and ends by clicking Done (panel closes, `PANEL_TRANSITION_DELAY`). It holds no cross-call state, and there is no "all 5 required" check.
- `dev-test-data.json -> datasets[<name>].dimensionSelections` is an array of 5 entries (productNoDataPrompt, retailerNoDataPrompt, geographyNoDataPrompt, demographicNoDataPrompt, periodNoDataPrompt). Test can pass `selections.slice(0, 4)` first and later call `setDimensionSelection(...)` (or `setDimensionSelections([fifth])`) with the 5th entry's fields. Order is irrelevant to the code; the existing array order is product, retailer, geography, demographic, period.
- Check-before-click guard: each call first reads the current dimension value (via `FILLED_TILE_DIMENSION_LABELS` for all 5); if already matching it returns early, if a different value it removes then re-selects. So re-calling is idempotent.
- Caveats for the "disabled until all 5 set" test:
  - After the 1st selection the Search button appears in `disabled` state (not hidden); it becomes enabled only when prompt validation reports `VALID` (after the 5th). Before any selection it is not in the DOM, so `isSearchForPanelistsButtonVisible()` (which does `waitFor()`) will throw/timeout — don't use it for the "before" state.
  - Need new method(s) e.g. `isSearchForPanelistsEnabled()` using `#report-btn-run` class `report-btn-run-disabled` (+ optionally inner button disabled).
  - `setDimensionSelection` parameters are positional (dimensionTab, items, parentItems, requiresFilterIconClick, filterIconClickAfterParent, skipParentSearch); `DimensionSelection` interface is not exported, but `Parameters<SelectPanelistPage['setDimensionSelections']>[0]` works (used in panelist-flow.helper.ts).
  - The existing spec test "Should enable Search for Panelists after all 5 filters are set" only asserts visibility — it never proves enabled.
  - Period uses `skipParentSearch` / `filterIconClickAfterParent`; these are data-driven, no code change needed.

---

## Summary of gaps to build (suggested)
1. Locators: `cancelDatasetButton` `[data-test-id='cancel-dataset-btn']`, `productOfferingDialog` `.ds-picker-container.ds-picker-type-selection`, `eligibilityMessage` `.eligibility`, `responseCountByValue` `[data-test-id='select-response-count-${text}']`, `responseCountOptions` `[data-test-id^='select-response-count-']`, `moreResponseOptionsButton` `[data-test-id='toggle-more-response-options']`, `responsesCreditMessage` `.responses-frame .question`, `footerSelectedValue` `.dataset-footer .selected-value`, `footerSourceLabel` `.dataset-footer .dataset-label`, `footerLastRefreshed` `[data-test-id='rb-report-refreshed-on-block']`.
2. Methods: `isSearchForPanelistsEnabled/Disabled()`, `isSearchForPanelistsPresent()`, `getEligibleCount()`, `getResponseCountOptions()`, `clickResponseCount(n)`, `clickMoreOptions()`, `getResponsesCreditMessage()`, `getFooterDetails()` (split by " | "), `getLastRefreshedText()`, `cancelProductOffering()`, `isProductOfferingModalOpen()`.
3. Data dependency: the response-count list depends on eligible count (needs >= 500 for 100..500 all present) and More options exists only in the Start-from-scratch flow; test data must give a high-eligibility criteria set.
