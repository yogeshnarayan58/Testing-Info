import { BasePage, WebActions } from "@gfk/gta";
import * as landingPageResources from "./landing-page-resources.json";
import { ResourceManager } from "../../utils/resource-manager";
import { CommonTestCase } from "../common-test-case/common-test-case";
import { MAX_TEST_TIMEOUT } from "../../../constants/time-out-constants";

const LANDINGPAGE = "Landing page";

export class LandingPage extends CommonTestCase {
  constructor(basePage: BasePage) {
    super(basePage);
    // Register multiple resources for the same component
    this.resourceManager.registerResources(LANDINGPAGE, landingPageResources);
  }

  /**
   * Waits for the "Choose a Template" element and clicks it to navigate.
   */
  public async clickChooseATemplate() {
    const chooseTemplateElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "chooseAtemplate",
        LANDINGPAGE
      )
    );
    
    try {
      await chooseTemplateElement.waitFor(MAX_TEST_TIMEOUT, "visible");
      await chooseTemplateElement.click();
    } catch (error: any) {
      throw new Error(
        `Failed to click 'Choose a Template' element (resource: chooseAtemplate, component: ${LANDINGPAGE}): ${error?.message || error}`
      );
    }
  }

  /**
   * Waits for the "Find my stuff" element and clicks it to navigate.
   */
  public async clickFindMyStuff() {
    const findMyStuffElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "findMyStuff",
        LANDINGPAGE
      )
    );
    
    try {
      await findMyStuffElement.waitFor(MAX_TEST_TIMEOUT, "visible");
      await findMyStuffElement.click();
    } catch (error: any) {
      throw new Error(
        `Failed to click 'Find my stuff' element (resource: findMyStuff, component: ${LANDINGPAGE}): ${error?.message || error}`
      );
    }
  }

  /**
   * Waits for the "Analyse My Data" button and clicks it.
   */
  public async clickAnalyseMyData() {
    const analyseDataButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "analyseMyData",
        LANDINGPAGE
      )
    );
    
    try {
      await analyseDataButton.waitFor(MAX_TEST_TIMEOUT, "visible");
      await analyseDataButton.click();
    } catch (error: any) {
      throw new Error(
        `Failed to click 'Analyse My Data' button (resource: analyseMyData, component: ${LANDINGPAGE}): ${error?.message || error}`
      );
    }
  }

  /**
   * Returns the base page instance.
   * @returns {BasePage} The base page instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }
}
