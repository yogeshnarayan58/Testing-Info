import { expect } from "@playwright/test";
import { getFormatPanelSelections } from "../../common/utils/helper-service";
import { getPage } from "../../common/utils/page-utils";
/**
 * Method makes sure to call the Default formal panel checks based on testData and Data set
 * @param testData - Should have formatPanelSelections object.
 * @param dataset - String to match Data set id. 
 */
export async function checkDefaultFormatPanelAfterRun(
  testData: any,
  dataset: string
) {
  await checkDefaultFormatPanel(testData, dataset);
  await checkIfChartsMatching(testData, dataset);
}

export async function checkDefaultFormatPanel(
  testData: any,
  dataset: string
) {
  console.log("Satrt - Inside format panel selections default checks");
  const formatPanelSelections = await getFormatPanelSelections(
    testData,
    dataset
  );
  if (!formatPanelSelections) {
    console.log(`Selections not found for ${dataset}.`);
    return;
  }
  await openFormatPanel();
  await testDefaultFormatPanel(formatPanelSelections.default);
  await closeFormatPanel();
  console.log("End - Inside format panel selections default checks");
}

/**
 * Method checks the default state of format panel selections - when report is opened intially.
 * @param formatPanelSelections 
 */
export async function testDefaultFormatPanel(formatPanelSelections: any) {
  console.log("Checking the default state of format panel based on formatPanelSelections");
  for (let index = 0; index < formatPanelSelections.length; index++) {
    const formatPanelItem = formatPanelSelections[index];
    const formatpanelLabelLoc = await getPage().locator(
      `[data-test-id="checkbox-property-${formatPanelItem.id}"]>div>label`
    );
    await expect(formatpanelLabelLoc).toContainText(formatPanelItem.value);

    const checkBoxLoc = await getPage().locator(
      `[data-test-id="checkbox-property-${formatPanelItem.id}"]>div`
    );
    if (formatPanelItem.selected) {
      await expect(checkBoxLoc).toHaveClass(
        "checkbox-container medium checked"
      );
    } else {
      await expect(checkBoxLoc).toHaveClass(
        "checkbox-container medium unchecked"
      );
    }
  }
}

/**
 * Method call the main method responsible for checking the Components matching the format panel 
 * @param testData 
 * @param dataset 
 * @returns 
 */
export async function checkIfChartsMatching(
    testData: any,
    dataset: string
  ) {
  const formatPanelSelections = await getFormatPanelSelections(
    testData,
    dataset
  );
  if (!formatPanelSelections) {
    console.log(`Selections not found for ${dataset}.`);
    return;
  }
  await openFormatPanel();
  await testFormatPanelSelectionMatchWithChart(formatPanelSelections.default);
  await closeFormatPanel();
}

/**
 * This method will test the components based on the formatPanelSelections sent.
 * This can be reused to check the format panel changes of each component- based on formatPanelSelections sent.
 * @param formatPanelSelections 
 */
export async function testFormatPanelSelectionMatchWithChart(formatPanelSelections: any) {
    console.log("Am inside testFormatPanelSelectionMatchWithChart")
    for (let index = 0; index < formatPanelSelections.length; index++) {
      
      const formatPanelItem = formatPanelSelections[index];
      if(formatPanelItem.value.toLowerCase()==='grid lines'){ 
            console.log("Am inside the format panel check @@@@@@grid lines");
            if(formatPanelItem?.components?.length > 0){
                for (let j = 0; j < formatPanelItem.components.length; j++){
                    const gridLinesLoc = await getPage().locator(`${formatPanelItem.components[j]} > highcharts-chart > div > svg > g > path`).first();
                    console.log("Am inside formatSelections list for loop", gridLinesLoc);
                    if(formatPanelItem.selected){
                        await expect(gridLinesLoc).toHaveAttribute('stroke', '#e6e6e6');
                    }
                    else {
                        await expect(gridLinesLoc).not.toHaveAttribute('stroke', '#e6e6e6');
                    }
                }
            }
       } 

      if(formatPanelItem.value.toLowerCase()==='data labels'){
        console.log("Am inside the format panel check @@@@@@data labels");
        console.log(formatPanelItem);
        if(formatPanelItem?.components?.length > 0){
            for (let k = 0; k < formatPanelItem.components.length; k++){
                console.log(formatPanelItem.components[k])
                const dataLabelLoc = await getPage().locator(`${formatPanelItem.components[k]} > highcharts-chart .highcharts-data-labels`).first();
                console.log("Am getting inside expect loop", dataLabelLoc);
                if(formatPanelItem.selected){
                    await expect(dataLabelLoc).toBeAttached();
                } else {
                    await expect(dataLabelLoc).not.toBeAttached();
                }
            }
        }
        
      }

      if(formatPanelItem.value.toLowerCase()==='characteristic short description'){
        console.log("Am inside the format panel check @@@@@@characteristic short description");
        const labelLocaltor = await getPage().getByText(`...${formatPanelItem.labelToTest}`).first();
        if(formatPanelItem.selected){
            await expect(labelLocaltor).toBeAttached();
        } else {
            await expect(labelLocaltor).not.toBeAttached();
        }
      }
      
    }
}

/**
 * Method helps in opening format panel
 */
export async function openFormatPanel() {
    console.log("Trying to open format panel !!");
    await getPage().waitForSelector('[id="report-card-menu"]', {
      state: "attached",
      timeout: 300000,
    });
    await getPage().waitForSelector('[id="report-card-menu"]', {
      state: "visible", // Wait for the element to become visible
      timeout: 30000, // Set a timeout of 30 seconds
    });
    await getPage().locator('[id="report-card-menu"]').click();
  
    await getPage().locator('[data-test-id="rb-menu-open-format-panel"]').click();

    console.log("Format panel is open now !!");
    await getPage().waitForTimeout(2000);
}

/**
 * Method helps in closing format panel
 */
export async function closeFormatPanel(){
    await getPage().locator('crf-rc-format-panel [data-test-id="-icon"]').click();
}

// For grid lines ??
//niq-highchart-waterfall > highcharts-chart > div > svg > g > path  - to have attribute -- stroke="#e6e6e6" ---

// For data labels ?? -highcharts-data-labels -- Confirmed the
// bar chart - highcharts-label-box - class is getting added
//line chart -  highcharts-chart > div > svg > g > g > text > tspan

// For legends ??