import { Component, inject } from '@angular/core';
import { SurveyDetailsComponent } from '../../../../shared/components/survey-details/survey-details.component';
import { CardModule } from '@nielseniq/athena-core';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { PanelistSummaryState, SurveyStatusType } from '../../../build-survey/models/build-survey';
import { formatSurveyDate } from '../../../../shared/utils/survey-date.util';

@Component({
  selector: 'survey-survey-overview',
  standalone: true,
  imports: [SurveyDetailsComponent, CardModule],
  templateUrl: './survey-overview.component.html',
  styleUrls: ['./survey-overview.component.scss'],
})
export class SurveyOverview {
  private readonly surveyService = inject(SurveyService);
  readonly surveyTitle = this.surveyService.title;
  private readonly surveyCommonService = inject(SurveyCommonService);

  /** Use saved selector state when API data is missing. */
  get panelistSummaryState(): PanelistSummaryState {
    return this.surveyCommonService.getPanelistDataSelectorState() ?? {};
  }

  get questionCount(): number {
    return this.surveyService.questions().length;
  }

  /** Number of selected responses shown in the UI. */
  get selectedResponseCount(): number {
    return this.surveyCommonService.getSelectPanelistUiState().selectedResponses ?? 0;
  }

  /** Published date from API */
  get publishedDateValue(): string {
    const details = ((this.surveyService.loadedSurveyDetails() as unknown as Record<string, unknown> | null) ?? {});
    const delivery = (details['delivery'] as Record<string, unknown>) ?? {};
    const schedule = (delivery['schedule'] as Record<string, unknown>) ?? {};
    return formatSurveyDate(schedule['openAt']);
  }

  /** Closed date from API */
  get closedDateValue(): string | null {
    const survey = this.surveyService.loadedSurveyDetails();
    if (survey?.assetInfo?.status !== SurveyStatusType.CLOSED) {
      return null;
    }
    const details = survey as unknown as Record<string, unknown>;
    const delivery = (details['delivery'] as Record<string, unknown>) ?? {};
    const schedule = (delivery['schedule'] as Record<string, unknown>) ?? {};
    return formatSurveyDate(schedule['closeAt']);
  }

}