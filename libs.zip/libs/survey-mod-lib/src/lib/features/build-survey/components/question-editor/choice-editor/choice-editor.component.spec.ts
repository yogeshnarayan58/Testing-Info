import { ElementRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it, vi } from 'vitest';
import { ChoiceEditorComponent } from './choice-editor.component';

describe('ChoiceEditorComponent', () => {
  const createComponent = () => TestBed.runInInjectionContext(() =>
    new ChoiceEditorComponent(new ElementRef(document.createElement('div'))),
  );

  it('updates the question and emits a change', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onQuestionChange('Choose one');

    expect(component.question()).toBe('Choose one');
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('adds and edits options', () => {
    const component = createComponent();

    component.addOption();
    expect(component.options()).toEqual(['', '', '']);

    component.onOptionEdit(1, 'Second option');
    expect(component.options()).toEqual(['', 'Second option', '']);
  });

  it('removes an option when more than two exist', () => {
    const component = createComponent();
    component.options.set(['One', 'Two', 'Three']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeOption(1);

    expect(component.options()).toEqual(['One', 'Three']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('keeps the minimum two options', () => {
    const component = createComponent();
    const initialOptions = component.options();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeOption(0);

    expect(component.options()).toEqual(initialOptions);
    expect(emit).not.toHaveBeenCalled();
  });

  it('updates required state from the toggle', () => {
    const component = createComponent();

    component.toggleChange({ target: { checked: true } } as unknown as Event);

    expect(component.isRequired()).toBe(true);
  });

  it('defaults missing toggle data to false', () => {
    const component = createComponent();
    component.isRequired.set(true);

    component.toggleChange({ target: {} } as unknown as Event);

    expect(component.isRequired()).toBe(false);
  });

  it('computes isAtMaxOptions as false when below maximum', () => {
    const component = createComponent();
    component.options.set(['Option 1', 'Option 2', 'Option 3']);

    expect(component.isAtMaxOptions()).toBe(false);
  });

  it('computes isAtMaxOptions as true when at maximum', () => {
    const component = createComponent();
    const maxOptions = Array.from({ length: 15 }, (_, i) => `Option ${i + 1}`);
    component.options.set(maxOptions);

    expect(component.isAtMaxOptions()).toBe(true);
  });

  it('computes isAtMaxOptions as true when exceeding maximum', () => {
    const component = createComponent();
    const maxOptions = Array.from({ length: 16 }, (_, i) => `Option ${i + 1}`);
    component.options.set(maxOptions);

    expect(component.isAtMaxOptions()).toBe(true);
  });

  it('updates isAtMaxOptions when options change', () => {
    const component = createComponent();
    expect(component.isAtMaxOptions()).toBe(false);

    const maxOptions = Array.from({ length: 15 }, (_, i) => `Option ${i + 1}`);
    component.options.set(maxOptions);

    expect(component.isAtMaxOptions()).toBe(true);
  });

  it('isAtMaxOptions reflects real-time changes via addOption', () => {
    const component = createComponent();
    expect(component.isAtMaxOptions()).toBe(false);

    // Add options until we reach the max
    for (let i = 0; i < 13; i++) {
      component.addOption();
    }

    expect(component.isAtMaxOptions()).toBe(true);
  });

  it('emits formChange when adding option', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.addOption();

    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('emits formChange when editing option', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.onOptionEdit(0, 'New value');

    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('handles empty option values', () => {
    const component = createComponent();
    component.options.set(['Option 1', 'Option 2']);

    component.onOptionEdit(0, '');

    expect(component.options()[0]).toBe('');
  });

  it('preserves other options when editing one', () => {
    const component = createComponent();
    component.options.set(['Option 1', 'Option 2', 'Option 3']);

    component.onOptionEdit(1, 'Modified');

    expect(component.options()).toEqual(['Option 1', 'Modified', 'Option 3']);
  });

  it('removes option only when more than minimum exist', () => {
    const component = createComponent();
    component.options.set(['One', 'Two', 'Three', 'Four']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeOption(2);

    expect(component.options()).toEqual(['One', 'Two', 'Four']);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('prevents removing options when only two remain', () => {
    const component = createComponent();
    component.options.set(['One', 'Two']);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.removeOption(0);

    expect(component.options()).toEqual(['One', 'Two']);
    expect(emit).not.toHaveBeenCalled();
  });

  it('removes option at the end of the list', () => {
    const component = createComponent();
    component.options.set(['One', 'Two', 'Three']);

    component.removeOption(2);

    expect(component.options()).toEqual(['One', 'Two']);
  });

  it('removes first option when count exceeds minimum', () => {
    const component = createComponent();
    component.options.set(['One', 'Two', 'Three']);

    component.removeOption(0);

    expect(component.options()).toEqual(['Two', 'Three']);
  });

  it('updates required state from toggle checked true', () => {
    const component = createComponent();
    component.isRequired.set(false);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: true } } as unknown as Event);

    expect(component.isRequired()).toBe(true);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('updates required state from toggle checked false', () => {
    const component = createComponent();
    component.isRequired.set(true);
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: false } } as unknown as Event);

    expect(component.isRequired()).toBe(false);
    expect(emit).toHaveBeenCalledTimes(1);
  });

  it('handles toggle without checked property', () => {
    const component = createComponent();
    const emit = vi.spyOn(component.formChange, 'emit');

    component.toggleChange({ target: { checked: undefined } } as unknown as Event);

    expect(component.isRequired()).toBe(false);
    expect(emit).toHaveBeenCalledTimes(1);
  });
});
