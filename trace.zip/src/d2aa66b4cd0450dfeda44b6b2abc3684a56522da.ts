import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory } from '../../utils/base-page-factory';
import { assertTrue } from '../../page-objects/common/assert-utils';
import { StartFromScratchPage } from '../../page-objects/survey/start-from-scratch.page';
import { completePanelistSelectionFlow } from '../../page-objects/common/panelist-flow.helper';
import { SurveyBuilderPage } from '../../page-objects/survey/surveyBuilder.page';
import devTestData from '../../test-data/dev-test-data.json';

const datasetNames = Object.keys(devTestData.datasets) as Array<keyof typeof devTestData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = devTestData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

test.describe.serial('Survey Builder', () => {
  let basePage: BasePage;

  test.afterAll(async () => {
    if (basePage) {
      await basePage.getWebActions().closeBrowser();
    }
  });

  test('Setup: reach Build Survey page via Start from Scratch', { tag: '@SurveyBuilderSetup' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    const startFromScratchPage = new StartFromScratchPage(basePage);
    // TEMPORARY LOCAL-ONLY BYPASS — DO NOT COMMIT TO PR:
    // Home page buttons (Start from scratch / Start with a Prompt / Template)
    // are broken in this dev environment. Hardcoding direct navigation to
    // survey/select-panelist so Build Survey tests can be verified now.
    // Revert to the real clickStartFromScratch() flow once the home page
    // is fixed, and remove this hardcoded URL before any commit.
    const selectPanelistURL = startFromScratchPage.buildUrl(
      'https://si.connect.nielseniq.io/reportexperience-dev/',
      'survey/select-panelist'
    );
    await startFromScratchPage.navigateToUrl(selectPanelistURL);

    const reachedBuildSurvey = await completePanelistSelectionFlow(basePage, datasetConfig.dimensionSelections);

    assertTrue(reachedBuildSurvey, 'Expected to land on Build Survey page after panelist selection flow');
  });

  test('TC_BS_02: Edit survey title', { tag: '@EditSurveyTitle' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.setSurveyTitle(devTestData.surveyQuestions.surveyTitle);
  });

  test('TC_BS_03: Add a Single Choice question', { tag: '@SingleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);
    const { questionText, options } = devTestData.surveyQuestions.singleChoice;

    await surveyBuilderPage.addSingleChoiceQuestion(1, questionText, options);
  });

  test('TC_BS_04: Add a Multiple Choice question', { tag: '@MultipleChoiceQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, options } = devTestData.surveyQuestions.multipleChoice;

    await surveyBuilderPage.addMultipleChoiceQuestion(2, questionText, options);
  });

  test('TC_BS_05: Add a Rating question', { tag: '@RatingQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    await surveyBuilderPage.addRatingQuestion();
  });

  test.fixme(
    'TC_BS_06: Add a Text question',
    { tag: '@TextQuestion' },
    async () => {
      // BLOCKED: no confirmed locator for the "Text" question type exists yet
      // (never exercised in the Codegen capture). addTextQuestion() is not
      // implemented on SurveyBuilderPage. Unblock once questionTypeText is
      // confirmed and added to survey-builder.locator.json.
    }
  );

  test('TC_BS_07: Add an NPS question', { tag: '@NPSQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText } = devTestData.surveyQuestions.nps;

    await surveyBuilderPage.addNPSQuestion(3, questionText);
  });

  test.fixme(
    'TC_BS_08: Add a Point Scale question',
    { tag: '@PointScaleQuestion' },
    async () => {
      // BLOCKED: "+ Row"/"+ Column" add buttons for Point Scale are
      // UNCONFIRMED — the manual test case itself flags this as unverified.
      // Unblock once confirmed against live DOM; addPointScaleQuestion()
      // is implemented and ready to use once that's done.
    }
  );

  test('TC_BS_09: Add a Multi Scale question', { tag: '@MultiScaleQuestion' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.clickAddQuestion();
    const { questionText, rows, columns } = devTestData.surveyQuestions.multiScale;

    await surveyBuilderPage.addMultiScaleQuestion(4, questionText, rows, columns);
  });

  test.fixme(
    'TC_BS_14: Publish survey end-to-end',
    { tag: '@PublishSurvey' },
    async () => {
      // BLOCKED: dev-team-confirmed non-functional — Publish is currently a
      // no-op with no backend support. Unblock once backend ships.
    }
  );

  test('TC_BS_16: Save survey as draft', { tag: '@SaveDraft' }, async () => {
    const surveyBuilderPage = new SurveyBuilderPage(basePage);

    await surveyBuilderPage.saveDraft();
    // Only verifies the click does not throw — exact success confirmation
    // behavior is not independently verified yet.
  });
});