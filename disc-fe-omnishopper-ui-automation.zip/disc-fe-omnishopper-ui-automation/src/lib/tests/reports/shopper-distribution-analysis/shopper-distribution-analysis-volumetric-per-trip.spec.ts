import test from "@playwright/test";
import devTestData from "./test-data/dev-test-data.json";
import localizationData from "./test-data/localization-data.json";
import assertionData from "./test-data/assertion-data.json";
import { assert } from "@gfk/gta";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { findDataSetByName, getDimensionSelectionsByPivot, getTestDataByLocale, hasPivotInDimensionSelections } from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";

const reportTestData = findDataSetByName(devTestData, config.DATASET);
let reportAssertData: any = findDataSetByName(assertionData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";
const pivot: string = "Volumetric per Trip";
 test.describe("Shopper distribution analysis - Volumetric per Trip Pivot", () => {
  let dataSelector: DataSelector;
  let commonTestCase: CommonTestCase;

  test.beforeAll(() => {
    const isValidTestData = reportTestData && hasPivotInDimensionSelections(reportTestData, pivot);
    if (!isValidTestData) {
      console.warn('Skipping tests as the required pivot test data is not present');
    }
    test.skip(!isValidTestData, 'Skipping tests as the required pivot test data is not present');
  });
  test(
    "Madlib Validation: Should validate madlib text content matches expected pattern",
    {
      tag: "@MadlibValidation",
    },
    async () => {
      let basePage = await BasePageFactory.createBasePage();
      commonTestCase = new CommonTestCase(basePage);
      commonTestCase.navigateToReportUrl(reportUrl);
      let commonBasePage = commonTestCase.getBasePage();
      dataSelector = new DataSelector(commonBasePage);
      if (localeData.madlibText) {
        const actualMadlibText = await dataSelector.getMadlibText();
        console.log("Actual Madlib Text:", actualMadlibText);
        console.log("Expected Pattern:", localeData.madlibText);
        assert(actualMadlibText).toMatch(
          new RegExp(localeData.madlibText, "i")
        );

        console.log(
          " Madlib validation passed for locale:",
          localeData.locale
        );
      } else {
        console.warn(
          `No madlib text pattern defined for locale: ${localeData.locale}`
        );
      }
    }
  );

        test.skip(
        "Report Generation: Validates dimension selection and successful execution",
        {
          tag: "@RunReport",
        },
        async () => {
          test.setTimeout(RUN_TEST_TIMEOUT);

          let basePage = await BasePageFactory.createBasePage();
          commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(reportUrl);

          let commonBasePage = commonTestCase.getBasePage();
          dataSelector = new DataSelector(commonBasePage);

          await dataSelector.clickAdditionalPromptEllipsisIcon();
          await dataSelector.assertPivotDropdown(
            reportAssertData["dataSummary"]["pivot"]["pivotlList"]
          );

          // Get pivot data
          const volumetricPerBuyerData = getDimensionSelectionsByPivot(
            pivot,
            reportTestData
          );

          await dataSelector.clickMadlibDimension("Retailer Universe");
          await dataSelector.setMadlibSelection(
            volumetricPerBuyerData["Retailer Universe"]
          );

          await dataSelector.clickMadlibDimension("Retailers");
          await dataSelector.setMadlibSelection(
            volumetricPerBuyerData["Retailers"]
          );

          await dataSelector.waitForMadlibStability();

          await dataSelector.clickMadlibDimension("Facts");
          await dataSelector.assertFactsDropdown(
            reportAssertData["dataSummary"]["facts"]["factList"]
          );
          await dataSelector.selectClosedDropdown(
            volumetricPerBuyerData["Facts"]["selections"]
          );

          await dataSelector.clickMadlibDimension("Geography");
          await dataSelector.setMadlibSelection(
            volumetricPerBuyerData["Geography"]
          );

          await dataSelector.clickMadlibDimension("Period");
          await dataSelector.setPeriodMadlibSelection(
            volumetricPerBuyerData["Period"]
          );

          await dataSelector.clickMadlibDimension("Demographic");
          await dataSelector.setMadlibSelection(
            volumetricPerBuyerData["Demographic"]
          );

          await dataSelector.clickMadlibDimension("Range");
          const rangeConfig = volumetricPerBuyerData["Range"].selections;

          await dataSelector.clickMadlibDimension("defineNewRangeButton");

          await dataSelector.configureRange(
            rangeConfig.volumetricType,
            rangeConfig.minValue,
            rangeConfig.maxValue,
            rangeConfig.incrementValue
          );

          let dsBasePage = await dataSelector.getBasePage();
          commonTestCase = new CommonTestCase(dsBasePage);

          await commonTestCase.clickRunButton();
          await commonTestCase.waitForReportRunCompletion();

          console.log("run complete in spec");

          const { newReportTitle, newUrl } =
            await commonTestCase.saveReport();

          savedReportTitle = newReportTitle;
          savedReportUrl = newUrl;

          console.log("savedReportTitle:", savedReportTitle);
          console.log("savedReportUrl:", savedReportUrl);
        }
      );
    }
  );
