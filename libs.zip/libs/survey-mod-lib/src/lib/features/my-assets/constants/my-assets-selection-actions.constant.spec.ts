import { SURVEY_ACCESS_AVAILABILITY } from './survey-status.constant';
import { describe, expect, it, vi } from 'vitest';
import { ASSET_TYPE, MY_ASSETS_TABS, MyAssetsTabId } from './my-assets-tabs.constant';
import { getMyAssetsSelectionActions, MY_ASSETS_SELECTION_ACTIONS } from './my-assets-selection-actions.constant';
import { SurveyGridRow } from '../models/survey-asset.model';

vi.mock('@nielsen/crf-lp-common', () => ({
  RIGHTS_CONFIG: { EDITOR_RIGHTS: ['OWNED', 'EDIT'] },
}));

const survey = (status?: string, assetId = 'survey-1'): SurveyGridRow => ({
  assetId,
  assetType: ASSET_TYPE.DISCOVERSURVEY,
  title: 'Survey',
  lastModifiedTimestamp: 0,
  status,
});

describe('getMyAssetsSelectionActions', () => {
  const userId = 'current-user';
  const owner = (): SurveyGridRow => ({
    ...survey('CLOSED'),
    rights: [{ userId, availability: SURVEY_ACCESS_AVAILABILITY.OWNED }],
  });
  const actionsFor = (
    rows: SurveyGridRow[],
    tab: MyAssetsTabId = MY_ASSETS_TABS.MY_ASSETS,
    canEdit = true,
    currentUserId: string | undefined = userId
  ) => getMyAssetsSelectionActions(tab, currentUserId, {
    checkAvailableRightsForMe: vi.fn().mockReturnValue(canEdit),
  }).filter((action) => action.isVisible?.(rows) ?? true).map((action) => action.id);

  it('preserves all single owned closed-survey actions in My Assets', () => {
    expect(actionsFor([owner()])).toEqual(
      ['open-new-tab', 'move', 'duplicate', 'rename', 'share', 'delete', 'export', 'info']
    );
  });

  it.each([MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES])(
    'preserves owned-survey actions except Move to in %s',
    (tab) => {
      expect(actionsFor([owner()], tab)).toEqual(['open-new-tab', 'duplicate', 'rename', 'share', 'delete', 'export', 'info']);
    }
  );

  it.each([MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES])(
    'preserves rights-based management actions for owned folders in %s',
    (tab) => {
      expect(actionsFor([{ ...folder(), rights: owner().rights }], tab)).toEqual(['rename', 'share', 'delete', 'info']);
    }
  );

  it.each([MY_ASSETS_TABS.MY_ASSETS, MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES])(
    'does not expose owner actions for shared editors in %s',
    (tab) => {
      const row = { ...survey('CLOSED'), rights: [{ userId, availability: SURVEY_ACCESS_AVAILABILITY.EDIT }] };
      expect(actionsFor([row], tab)).toEqual([
        'open-new-tab', ...(tab === MY_ASSETS_TABS.MY_ASSETS ? ['move'] : []),
        'duplicate', 'rename', 'share', 'export', 'info',
      ]);
    }
  );

  it.each([SURVEY_ACCESS_AVAILABILITY.VIEW, SURVEY_ACCESS_AVAILABILITY.STRICT_VIEW])('hides editing and destructive actions for %s access in every non-Trash tab', (availability) => {
    const row = { ...survey('CLOSED'), rights: [{ userId, availability }] };
    for (const tab of [MY_ASSETS_TABS.MY_ASSETS, MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES]) {
      expect(actionsFor([row], tab, false)).toEqual(['open-new-tab', 'duplicate', 'export', 'info']);
      expect(actionsFor([{ ...folder(), rights: row.rights }], tab, false)).toEqual(['info']);
    }
  });

  it('uses the Landing Page editor-rights helper for the current user', () => {
    const checkAvailableRightsForMe = vi.fn().mockReturnValue(false);
    const row = owner();
    const actions = getMyAssetsSelectionActions(MY_ASSETS_TABS.MY_ASSETS, userId, { checkAvailableRightsForMe });
    actions.forEach((action) => action.isVisible?.([row]));
    expect(checkAvailableRightsForMe).toHaveBeenCalledWith(row, userId, ['OWNED', 'EDIT']);
  });

  it.each([MY_ASSETS_TABS.MY_ASSETS, MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES])(
    'does not grant delete because another user owns the asset in %s', (tab) => {
      expect(actionsFor([{ ...owner(), rights: [{ userId: 'someone-else', availability: SURVEY_ACCESS_AVAILABILITY.OWNED }] }], tab))
        .not.toContain('delete');
    }
  );

  it.each([MY_ASSETS_TABS.MY_ASSETS, MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES])(
    'permits trashing assets owned by a COG without a named user in %s', (tab) => {
      expect(actionsFor([{ ...owner(), rights: [{ availability: SURVEY_ACCESS_AVAILABILITY.OWNED, orderManagementType: 'COG' }] }], tab))
        .toContain('delete');
      expect(actionsFor([{ ...owner(), rights: [{ userId: 'someone-else', availability: SURVEY_ACCESS_AVAILABILITY.OWNED, orderManagementType: 'COG' }] }], tab))
        .not.toContain('delete');
    }
  );

  it('keeps editing actions hidden until the current user is known', () => {
    const actions = getMyAssetsSelectionActions(MY_ASSETS_TABS.MY_ASSETS, undefined, {
      checkAvailableRightsForMe: vi.fn().mockReturnValue(true),
    });
    expect(actions.filter((action) => action.isVisible?.([owner()])).map((action) => action.id))
      .toEqual(['open-new-tab', 'duplicate', 'export', 'info']);
    expect(actions.filter((action) => action.isVisible?.([owner(), owner()]))).toEqual([]);
  });

  it.each(['DRAFT', 'PUBLISHED', 'LIVE', undefined])('preserves closed-only Share for %s surveys', (status) => {
    for (const tab of [MY_ASSETS_TABS.MY_ASSETS, MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES]) {
      expect(actionsFor([{ ...owner(), status }], tab)).not.toContain('share');
      expect(actionsFor([{ ...owner(), status }], tab)).not.toContain('export');
    }
  });

  it.each([ASSET_TYPE.DISCOVERFOLDER, ASSET_TYPE.DISCOVERSHAREDFOLDER])('preserves owned folder actions for %s', (assetType) => {
    expect(actionsFor([{ ...owner(), assetType }])).toEqual(['rename', 'share', 'delete', 'info']);
  });

  it.each([ASSET_TYPE.DISCOVERSURVEY, ASSET_TYPE.DISCOVERFOLDER, ASSET_TYPE.DISCOVERSHAREDFOLDER])(
    'shows only restore, permanent delete and info for a single trashed %s',
    (assetType) => {
      expect(actionsFor([{ ...owner(), assetType, status: 'TRASHED' }], MY_ASSETS_TABS.TRASH))
        .toEqual(['restore', 'delete', 'info']);
    }
  );

  it('uses a distinct permanent-delete label in Trash', () => {
    expect(getMyAssetsSelectionActions(MY_ASSETS_TABS.TRASH, userId, {
      checkAvailableRightsForMe: vi.fn(),
    }).find((action) => action.id === 'delete')?.label).toBe('Delete permanently');
  });

  it('does not move folders in a mixed selection, matching Landing Page', () => {
    expect(actionsFor([owner(), { ...folder(), rights: owner().rights }])).toEqual(['delete']);
  });

  it('requires ownership of every row for bulk Delete in My Assets', () => {
    const shared = { ...owner(), rights: [{ userId, availability: SURVEY_ACCESS_AVAILABILITY.EDIT }] };
    expect(actionsFor([owner(), shared])).not.toContain('delete');
    expect(actionsFor([owner(), folder()])).not.toContain('delete');
    const cogOwned = { ...owner(), rights: [{ availability: SURVEY_ACCESS_AVAILABILITY.OWNED, orderManagementType: 'COG' }] };
    expect(actionsFor([owner(), cogOwned])).toContain('delete');
  });

  it.each([MY_ASSETS_TABS.SHARED_WITH_ME, MY_ASSETS_TABS.RECENT, MY_ASSETS_TABS.MY_FAVORITES])(
    'does not expose bulk Delete in %s', (tab) => {
      expect(actionsFor([owner(), owner()], tab)).toEqual([]);
    }
  );

  it.each([MY_ASSETS_TABS.MY_ASSETS, MY_ASSETS_TABS.TRASH])('limits bulk mutations to 20 assets in %s', (tab) => {
    const rows = Array.from({ length: 20 }, (_, index) => ({ ...owner(), assetId: String(index) }));
    expect(actionsFor(rows, tab)).toEqual(tab === MY_ASSETS_TABS.TRASH ? ['restore', 'delete'] : ['move', 'delete']);
    expect(actionsFor([...rows, owner()], tab)).toEqual([]);
  });

  it('requires edit rights for every survey in a bulk move', () => {
    const rows = [owner(), { ...owner(), assetId: 'second' }];
    expect(actionsFor(rows, MY_ASSETS_TABS.MY_ASSETS, false)).not.toContain('move');
  });

  it('does not show Info for multiple trashed assets', () => {
    expect(actionsFor([owner(), folder()], MY_ASSETS_TABS.TRASH)).toEqual(['restore', 'delete']);
  });

  it.each(Object.values(MY_ASSETS_TABS))('shows no actions for an empty selection in %s', (tab) => {
    expect(actionsFor([], tab)).toEqual([]);
  });
});

const folder = (assetType = ASSET_TYPE.DISCOVERFOLDER, assetId = 'folder-1'): SurveyGridRow => ({
  assetId,
  assetType,
  title: 'Folder',
  lastModifiedTimestamp: 0,
});

const visibleActionIds = (rows: SurveyGridRow[]): string[] =>
  MY_ASSETS_SELECTION_ACTIONS
    .filter((action) => action.isVisible?.(rows) ?? true)
    .map((action) => action.id);

describe('MY_ASSETS_SELECTION_ACTIONS', () => {
  it('shows every action for a single closed survey', () => {
    expect(visibleActionIds([survey('CLOSED')])).toEqual(
      ['open-new-tab', 'move', 'duplicate', 'rename', 'share', 'delete', 'export', 'info']
    );
  });

  it.each(['DRAFT', 'PUBLISHED', 'LIVE', undefined])('hides share for a single %s survey', (status) => {
    expect(visibleActionIds([survey(status)])).toEqual(
      ['open-new-tab', 'move', 'duplicate', 'rename', 'delete', 'info']
    );
  });

  it('matches closed status case-insensitively', () => {
    expect(visibleActionIds([survey('closed')])).toContain('share');
    expect(visibleActionIds([survey('closed')])).toContain('export');
  });

  it.each([ASSET_TYPE.DISCOVERFOLDER, ASSET_TYPE.DISCOVERSHAREDFOLDER])('shows only info, rename, share and delete for a single %s', (type) => {
    expect(visibleActionIds([folder(type)])).toEqual(['rename', 'share', 'delete', 'info']);
  });

  it('shows only move and delete for multiple surveys', () => {
    expect(visibleActionIds([survey('CLOSED'), survey('DRAFT', 'survey-2')])).toEqual(['move', 'delete']);
  });

  it('shows only move and delete for a mixed multi selection', () => {
    expect(visibleActionIds([survey('CLOSED'), folder()])).toEqual(['move', 'delete']);
  });
});
