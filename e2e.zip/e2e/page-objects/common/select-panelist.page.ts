import { BasePage, WebActions } from '@gfk/gta';
import { ResourceManager } from '../../utils/resource-manager';
import selectPanelistPageResources from '../../locators/survey/select-panelist.locator.json';
import { PANEL_TRANSITION_DELAY, UI_STATE_UPDATE_DELAY, MEDIUM_TIMEOUT, SMALL_TIMEOUT } from '../../constants/timeout-constants';

const SELECT_PANELIST_PAGE_COMPONENT_NAME = 'selectPanelistPage';

interface DimensionSelection {
  dimensionTab: string;
  items: string[];
  parentItems?: string[];
  requiresFilterIconClick?: boolean;
  filterIconClickAfterParent?: boolean;
  skipParentSearch?: boolean;
}

export class SelectPanelistPage {
  private webActionHandler: WebActions;
  private resourceManager: ResourceManager;

  constructor(private basePage: BasePage) {
    this.webActionHandler = basePage.getWebActions();
    this.resourceManager = new ResourceManager({});
    this.resourceManager.registerResources(SELECT_PANELIST_PAGE_COMPONENT_NAME, selectPanelistPageResources);
  }

  async setDimensionSelections(selections: DimensionSelection[]): Promise<void> {
    for (const selection of selections) {
      await this.setDimensionSelection(
        selection.dimensionTab,
        selection.items,
        selection.parentItems,
        selection.requiresFilterIconClick,
        selection.filterIconClickAfterParent,
        selection.skipParentSearch
      );
    }
  }

  private async enterTextInSearchField(inputText: string): Promise<void> {
    const searchField = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('dsSearchBarInput', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await searchField.waitFor();
    await searchField.enterText('');
    await searchField.enterText(inputText);
  }

  private async getCurrentDimensionValue(dimensionPromptResource: string): Promise<string> {
    const dimensionElement = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(dimensionPromptResource, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await dimensionElement.waitFor();
    const text = await dimensionElement.getText();
    return (text ?? '').trim();
  }

  private isPlaceholderValue(value: string): boolean {
    return value.length === 0 || /^select\b/i.test(value.trim());
  }

  private dimensionAlreadyMatches(currentValue: string, itemsToSelect: string[]): boolean {
    if (this.isPlaceholderValue(currentValue) || itemsToSelect.length === 0) {
      return false;
    }
    const normalizedCurrent = currentValue.toLowerCase();
    return itemsToSelect.every((item) => normalizedCurrent.includes(item.toLowerCase()));
  }

  private readonly FILLED_TILE_DIMENSION_LABELS: Record<string, string> = {
    productNoDataPrompt: 'Product',
    retailerNoDataPrompt: 'Retailer',
    geographyNoDataPrompt: 'Geography',
    demographicNoDataPrompt: 'Demographic',
    periodNoDataPrompt: 'Period',
  };

  private async getCurrentFilledTileDimensionValue(dimensionPromptResource: string, dimensionLabel: string): Promise<string> {
    const noDataPrompt = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(dimensionPromptResource, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    try {
      if (await noDataPrompt.isVisible()) {
        const text = await noDataPrompt.getText();
        return (text ?? '').trim();
      }
    } catch {
      // empty-state prompt not present — fall through to filled-tile read
    }

    const filledTile = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('filledDimensionTile', dimensionLabel, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await filledTile.waitFor();
    const filledText = await filledTile.getText();
    return (filledText ?? '').trim();
  }

  private async replaceFilledTileDimensionSelection(dimensionLabel: string): Promise<void> {
    const filledTile = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('filledDimensionTile', dimensionLabel, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await filledTile.waitFor();
    await filledTile.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

    const removeIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('removeIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await removeIcon.waitFor();
    await removeIcon.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

    const addButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('addButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await addButton.waitFor();
    await addButton.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  async removeDimensionSelectionItem(dimensionPromptResource: string): Promise<void> {
    const dimensionLabel = this.FILLED_TILE_DIMENSION_LABELS[dimensionPromptResource];
    if (!dimensionLabel) {
      throw new Error(`No filled-state tile is mapped for '${dimensionPromptResource}'`);
    }
    const filledTile = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('filledDimensionTile', dimensionLabel, SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await filledTile.waitFor();
    await filledTile.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

    const removeIcon = this.getSelectPanelistElement('lastRemoveIcon');
    await removeIcon.waitFor();
    await removeIcon.click();
    await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
  }

  private async removeCurrentDimensionSelection(): Promise<void> {
    const removeIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('removeIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    try {
      if (await removeIcon.isVisible()) {
        await removeIcon.click();
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        return;
      }
    } catch {
      // fall through to hover + delete-menu fallback
    }

    const selectedOption = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('selectedOption', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await selectedOption.waitFor();
    await selectedOption.hover();

    const deleteMenuIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('deleteMenuIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await deleteMenuIcon.waitFor();
    await deleteMenuIcon.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async setDimensionSelection(
    dimensionPromptResource: string,
    itemsToSelect: string[],
    parentItems?: string[],
    requiresFilterIconClick?: boolean,
    filterIconClickAfterParent?: boolean,
    skipParentSearch?: boolean
  ): Promise<void> {
    try {
      const filledTileDimensionLabel = this.FILLED_TILE_DIMENSION_LABELS[dimensionPromptResource];
      const currentValue = filledTileDimensionLabel
        ? await this.getCurrentFilledTileDimensionValue(dimensionPromptResource, filledTileDimensionLabel)
        : await this.getCurrentDimensionValue(dimensionPromptResource);

      if (this.dimensionAlreadyMatches(currentValue, itemsToSelect)) {
        return;
      }

      let skipInitialPromptClick = false;
      if (!this.isPlaceholderValue(currentValue)) {
        if (filledTileDimensionLabel) {
          await this.replaceFilledTileDimensionSelection(filledTileDimensionLabel);
          skipInitialPromptClick = true;
        } else {
          await this.removeCurrentDimensionSelection();
        }
      }

      // Step 1: Click dimension prompt
      // Skipped when replaceFilledTileDimensionSelection() already reopened the picker
      // via the filled tile + addButton.
      if (!skipInitialPromptClick) {
        const dimensionPrompt = this.webActionHandler.getWebElement(
          this.resourceManager.getResource(dimensionPromptResource, SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        await dimensionPrompt.waitFor();
        await dimensionPrompt.click();
        await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
      }

      // Step 2: CONDITIONALLY click searchIcon BEFORE parent (Product, Demographic)
      // The search bar may already be open, so click only when the icon is visible.
      if (requiresFilterIconClick) {
        const searchIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource('searchIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        const isVisible = await searchIcon.isVisible();
        if (isVisible) {
          await searchIcon.click();
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        } else {
          // Icon not visible = search bar already open on panel load
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        }
      }

      // Step 3: Select parent categories (hierarchical dimensions: Product, Period)
      if (parentItems && parentItems.length > 0) {
        for (const parentItem of parentItems) {
          // 3a: Search for parent (unless skipParentSearch is true for Period)
          if (!skipParentSearch) {
            await this.enterTextInSearchField(parentItem);
            await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

            const viewport = this.webActionHandler.getWebElement(
              this.resourceManager.getResource('dsSelectionsViewPort', SELECT_PANELIST_PAGE_COMPONENT_NAME)
            );
            await viewport.waitFor();
            await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
          }

          // 3b: Click parent category item (NOT checkbox)
          const parentCategory = this.webActionHandler.getWebElement(
            this.resourceManager.getDynamicResource('categoryItem', parentItem, SELECT_PANELIST_PAGE_COMPONENT_NAME)
          );
          await parentCategory.waitFor();
          await parentCategory.click();
          await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
        }
      }

      // Step 4: CONDITIONALLY click searchIcon AFTER parent (Period only)
      // Click only when the search icon is visible.
      if (filterIconClickAfterParent) {
        const searchIcon = this.webActionHandler.getWebElement(
          this.resourceManager.getResource('searchIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        const isVisible = await searchIcon.isVisible();
        if (isVisible) {
          await searchIcon.click();
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        } else {
          await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
        }
      }

      // Step 5: Select child items
      for (const item of itemsToSelect) {
        await this.enterTextInSearchField(item);
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

        const viewport = this.webActionHandler.getWebElement(
          this.resourceManager.getResource('dsSelectionsViewPort', SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        await viewport.waitFor();
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

        const checkbox = this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource('checkboxLabel', item, SELECT_PANELIST_PAGE_COMPONENT_NAME)
        );
        await checkbox.waitFor();
        await checkbox.click();
        await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
      }

      // Step 6: Clear search field before Done
      const searchFieldBeforeDone = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('dsSearchBarInput', SELECT_PANELIST_PAGE_COMPONENT_NAME)
      );
      await searchFieldBeforeDone.waitFor();
      await searchFieldBeforeDone.enterText('');
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);

      // Step 7: Click Done
      const doneButton = this.webActionHandler.getWebElement(
        this.resourceManager.getResource('doneIcon', SELECT_PANELIST_PAGE_COMPONENT_NAME)
      );
      await doneButton.waitFor();
      await doneButton.click();
      await this.webActionHandler.delay(PANEL_TRANSITION_DELAY);
    } catch (error) {
      console.error(`setDimensionSelection failed for '${dimensionPromptResource}':`, error instanceof Error ? error.message : error);
      throw error;
    }
  }

  async clickSearchForPanelists(): Promise<void> {
    const searchButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('searchForPanelistsButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await searchButton.waitFor();
    await searchButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async click250Responses(): Promise<void> {
    const button250 = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('250ResponsesButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await button250.waitFor();
    await button250.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async clickProceedToSurveyBuilder(): Promise<void> {
    const proceedButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('proceedToSurveyBuilderButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await proceedButton.waitFor();
    await proceedButton.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async isBuildSurveyPageLoaded(): Promise<boolean> {
    const pageHeading = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('buildSurveyPageHeading', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await pageHeading.waitFor();
    return await pageHeading.isVisible();
  }

  async isSearchForPanelistsButtonVisible(): Promise<boolean> {
    const searchButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('searchForPanelistsButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await searchButton.waitFor();
    return await searchButton.isVisible();
  }

  async isProceedToSurveyBuilderVisible(): Promise<boolean> {
    const proceedButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('proceedToSurveyBuilderButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await proceedButton.waitFor(MEDIUM_TIMEOUT);
    return await proceedButton.isVisible(MEDIUM_TIMEOUT);
  }

  async isProceedToSurveyBuilderEnabled(): Promise<boolean> {
    const proceedButton = this.getSelectPanelistElement('proceedToSurveyBuilderButton');
    const deadline = Date.now() + MEDIUM_TIMEOUT;
    do {
      if (!(await proceedButton.isHidden())) {
        const classTokens = ((await proceedButton.getAttribute('class')) ?? '').split(/\s+/);
        const ariaDisabled = await proceedButton.getAttribute('aria-disabled');
        const disabledAttr = await proceedButton.getAttribute('disabled');
        const isDisabled = classTokens.includes('disabled') || ariaDisabled === 'true' || disabledAttr !== null;
        if (!isDisabled) {
          return true;
        }
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } while (Date.now() < deadline);
    return false;
  }

  async isProceedToSurveyBuilderDisabledOrAbsent(): Promise<boolean> {
    const proceedButton = this.getSelectPanelistElement('proceedToSurveyBuilderButton');
    if (await proceedButton.isHidden()) {
      return true;
    }
    return !(await this.isProceedToSurveyBuilderEnabled());
  }

  async getCurrentUrl(): Promise<string> {
    return this.webActionHandler.getPageUrl();
  }

  async getSelectedResponseCountDataTestId(): Promise<string | null> {
    const selectedButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource('selectedResponseCountButton', SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await selectedButton.waitFor(MEDIUM_TIMEOUT);
    return selectedButton.getAttribute('data-test-id');
  }

  async isAnyResponseCountSelected(): Promise<boolean> {
    return (await this.getSelectPanelistElement('selectedResponseCountButton').getCount()) > 0;
  }

  async isDimensionSelectionRetained(dimensionPromptResource: string, itemsToSelect: string[]): Promise<boolean> {
    const dimensionLabel = this.FILLED_TILE_DIMENSION_LABELS[dimensionPromptResource];
    if (!dimensionLabel) {
      throw new Error(`No FILLED_TILE_DIMENSION_LABELS entry for '${dimensionPromptResource}'`);
    }
    const currentValue = await this.getCurrentFilledTileDimensionValue(dimensionPromptResource, dimensionLabel);
    return this.dimensionAlreadyMatches(currentValue, itemsToSelect);
  }

  private getSelectPanelistElement(resourceName: string) {
    return this.webActionHandler.getWebElement(this.resourceManager.getResource(resourceName, SELECT_PANELIST_PAGE_COMPONENT_NAME));
  }

  async isSearchForPanelistsEnabled(): Promise<boolean> {
    const searchButton = this.getSelectPanelistElement('searchForPanelistsButton');
    const deadline = Date.now() + MEDIUM_TIMEOUT;
    do {
      if (!(await searchButton.isHidden())) {
        const classTokens = ((await searchButton.getAttribute('class')) ?? '').split(/\s+/);
        const ariaDisabled = await searchButton.getAttribute('aria-disabled');
        const isDisabled = classTokens.includes('disabled') || classTokens.includes('report-btn-run-disabled') || ariaDisabled === 'true';
        if (!isDisabled) {
          return true;
        }
      }
      await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
    } while (Date.now() < deadline);
    return false;
  }

  async isSearchForPanelistsDisabledOrAbsent(): Promise<boolean> {
    const searchButton = this.getSelectPanelistElement('searchForPanelistsButton');
    if (await searchButton.isHidden()) {
      return true;
    }
    return !(await this.isSearchForPanelistsEnabled());
  }


  async isSelectDatasetButtonVisible(): Promise<boolean> {
    return this.getSelectPanelistElement('selectDatasetButton').isVisible(SMALL_TIMEOUT);
  }

  async getEligibleCount(): Promise<number> {
    const eligibility = this.getSelectPanelistElement('eligibilityMessage');
    await eligibility.waitFor();
    const text = (await eligibility.getText()) ?? '';
    const match = text.match(/\d[\d,]*/);
    if (!match) {
      throw new Error(`No eligible count found in eligibility message: "${text.trim()}"`);
    }
    return Number(match[0].replace(/,/g, ''));
  }

  async isResponseCountOptionVisible(count: number): Promise<boolean> {
    const option = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('responseCountOption', String(count), SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    return option.isVisible(MEDIUM_TIMEOUT);
  }

  async clickResponseCountOption(count: number): Promise<void> {
    const option = this.webActionHandler.getWebElement(
      this.resourceManager.getDynamicResource('responseCountOption', String(count), SELECT_PANELIST_PAGE_COMPONENT_NAME)
    );
    await option.waitFor();
    await option.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async getVisibleResponseCountOptionsCount(): Promise<number> {
    return this.getSelectPanelistElement('visibleResponseCountOptions').getCount();
  }

  async clickMoreOptions(): Promise<void> {
    const moreOptions = this.getSelectPanelistElement('moreOptionsButton');
    await moreOptions.waitFor();
    await moreOptions.click();
    await this.webActionHandler.delay(UI_STATE_UPDATE_DELAY);
  }

  async isMoreOptionsVisible(): Promise<boolean> {
    return this.getSelectPanelistElement('moreOptionsButton').isVisible(MEDIUM_TIMEOUT);
  }

  async clickFewerOptions(): Promise<void> {
    await this.clickMoreOptions();
  }

  async moveMouseAwayFromResponseOptions(): Promise<void> {
    await this.webActionHandler.mouseMove(0, 0);
  }

  async getResponsesCreditMessageText(): Promise<string> {
    const message = this.getSelectPanelistElement('responsesCreditMessage');
    await message.waitFor();
    return ((await message.getText()) ?? '').trim();
  }

  async getFooterSelectedValueText(): Promise<string> {
    const selectedValue = this.getSelectPanelistElement('footerSelectedValue');
    await selectedValue.waitFor();
    return ((await selectedValue.getText()) ?? '').trim();
  }

  async getFooterParts(): Promise<{ source: string; dataset: string; view: string }> {
    const [source = '', dataset = '', view = ''] = (await this.getFooterSelectedValueText()).split(' | ').map((part) => part.trim());
    return { source, dataset, view };
  }

  async isFooterRefreshedVisible(): Promise<boolean> {
    return this.getSelectPanelistElement('footerRefreshedOn').isVisible(MEDIUM_TIMEOUT);
  }

  async getFooterRefreshedText(): Promise<string> {
    const refreshedOn = this.getSelectPanelistElement('footerRefreshedOn');
    await refreshedOn.waitFor();
    return ((await refreshedOn.getText()) ?? '').trim();
  }
}
