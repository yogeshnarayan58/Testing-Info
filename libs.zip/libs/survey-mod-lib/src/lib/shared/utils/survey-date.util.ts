/**
 * Formats an API date string as "Month Day, Year" (for eg: September 22, 2026) and returns '-' or emptyPlaceholder for invalid inputs.
 */
export function formatSurveyDate(value: unknown, emptyPlaceholder?: string): string {
  if (typeof value !== 'string') {
    return emptyPlaceholder ?? '-';
  }

  const parsedDate = new Date(value);
  if (Number.isNaN(parsedDate.getTime())) {
    return emptyPlaceholder ?? '-';
  }

  return new Intl.DateTimeFormat('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  }).format(parsedDate);
}
