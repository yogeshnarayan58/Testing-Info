import { BasePage, WebActions } from "@gfk/gta";
import * as ChooseATemplateResources from "./choose-a-template-page-resources.json";
import { ResourceManager } from "../../utils/resource-manager";
import { CommonTestCase } from "../common-test-case/common-test-case";

// Register the DataSelector resources
const CHOOSE_A_TEMPLATE = "ChooseAtemplate";

export class ChooseAtemplatePage extends CommonTestCase{
  constructor(basePage: BasePage) {
    super(basePage);
    this.resourceManager.registerResources(CHOOSE_A_TEMPLATE, ChooseATemplateResources);
  }

  /**
   * Clicks on the "By Business Objective" element.
   */
  public async clickBusinessObjective() {
    const businessObjective = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "businessObjective",
        CHOOSE_A_TEMPLATE
      )
    );
    await businessObjective.waitFor();
    await businessObjective.click();
  }

  /**
   * Clicks on the "All templates" element.
   */
  public async clickAllTemplates() {
    const businessObjective = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "allTemplates",
        CHOOSE_A_TEMPLATE
      )
    );
    await businessObjective.waitFor();
    await businessObjective.click();
  }

  /**
   * Waits for the search icon and clicks it.
   */
  public async clickSearchIcon() {
    const searchIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "inputSearchIcon",
        CHOOSE_A_TEMPLATE
      )
    );
    await searchIcon.waitFor();
    await searchIcon.click();
  }

  /**
   * Types the given text into the search input field.
   * @param query - The search text to enter.
   */
  public async enterSearchText(query: string) {
    const searchInput = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "inputSearch",
        CHOOSE_A_TEMPLATE
      )
    );
    await searchInput.enterText(query);
  }

  /**
   * Clicks on the search icon and types the provided query into the search input.
   * @param query - The text to be typed into the search input.
   */
  public async clickSearchIconAndEnterText(query: string) {
    const searchIcon = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "templateSearchBar",
        CHOOSE_A_TEMPLATE
      )
    );
    await searchIcon.waitFor();
    await searchIcon.click();

    const searchInput = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "templateSearchBar",
        CHOOSE_A_TEMPLATE
      )
    );
    await searchInput.enterText(query);
    await this.pressEnterKey();
  }

  /**
   * Hovers over the first search result card title.
   */
  public async hoverOnFirstSearchResult() {
    await this.webActionHandler
      .getWebElement(this.resourceManager.getResource(
        "templateCardTitle",
        CHOOSE_A_TEMPLATE
      ))
      .waitFor();
    await this.webActionHandler.getWebElementsText(this.resourceManager.getResource(
      "templateCardTitle",
      CHOOSE_A_TEMPLATE
    ));
    await this.webActionHandler.getWebElement(this.resourceManager.getResource(
      "templateCardTitle",
      CHOOSE_A_TEMPLATE
    )).hover();
  }

  /**
   * Clicks on the "Quick Look Info" button.
   */
  public async clickQuickLookInfoButton() {
    const quickLookButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "previewButton",
        CHOOSE_A_TEMPLATE
      )
    );
    await quickLookButton.waitFor();
    await quickLookButton.click();
  }

  public async openTemplateButton() {
    const quickLookButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "openButton",
        CHOOSE_A_TEMPLATE
      )
    );
    await quickLookButton.waitFor();
    await quickLookButton.click();
  }

  public async selectReportTitle() {
    await this.webActionHandler
    .getWebElement(this.resourceManager.getResource(
      "reportTitle",
      CHOOSE_A_TEMPLATE
    ))
    .waitFor();
    console.log(
      "reportTitle:",
      await this.webActionHandler
        .getWebElement(this.resourceManager.getResource(
          "reportTitle",
          CHOOSE_A_TEMPLATE
        ))
        .isVisible()
    );
    await this.webActionHandler.getWebElementsText(this.resourceManager.getResource(
      "reportTitle",
      CHOOSE_A_TEMPLATE
    ));
    await this.webActionHandler.getWebElement(this.resourceManager.getResource(
      "reportTitle",
      CHOOSE_A_TEMPLATE
    )).hover();
  }

  public async clickNextbtnDataSet() {
    const quickLookButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "nextBtnDataset",
        CHOOSE_A_TEMPLATE
      )
    );
    await quickLookButton.waitFor();
    await quickLookButton.click();
  }


  public async clickApplyDataset() {
    const quickLookButton = this.webActionHandler.getWebElement(
      this.resourceManager.getResource(
        "applyDataset",
        CHOOSE_A_TEMPLATE
      )
    );
    await quickLookButton.waitFor();
    await quickLookButton.click();
  }

  /**
     * Gets a report thumbnail by its source URL
     * @param partialSrc Partial or full source URL to search for
     * @returns The thumbnail image web element with matching src
     */
    public getThumbnailBySrc(partialSrc: string) {
      try {
        return this.webActionHandler.getWebElement(
          this.resourceManager.getDynamicResource("reportThumbnailBySrc", partialSrc, CHOOSE_A_TEMPLATE)
        );
      } catch (error: any) {
        throw new Error(`Failed to get thumbnail with src containing '${partialSrc}': ${error.message || error}`);
      }
    }
  
    /**
     * Hovers over a report thumbnail by its source URL
     * @param partialSrc Partial or full source URL to search for
     * @returns Promise resolving when hover is complete
     */
    public async hoverThumbnailBySrc(partialSrc: string): Promise<void> {
      try {
        const thumbnailElement = this.getThumbnailBySrc(partialSrc);
        await thumbnailElement.waitFor();
        await thumbnailElement.hover();
      } catch (error: any) {
        throw new Error(`Failed to hover over thumbnail with src containing '${partialSrc}': ${error.message || error}`);
      }
    }

    /**
     * Clicks on a report thumbnail by its source URL
     * @param partialSrc Partial or full source URL to search for
     * @returns Promise resolving when click is complete
     */
    public async clickThumbnailBySrc(partialSrc: string): Promise<void> {
      try {
        const thumbnailElement = this.getThumbnailBySrc(partialSrc);
        await thumbnailElement.waitFor();
        await thumbnailElement.click();
      } catch (error: any) {
        throw new Error(`Failed to click on thumbnail with src containing '${partialSrc}': ${error.message || error}`);
      }
    }

  /**
   * Returns the base page instance.
   * @returns {BasePage} The base page instance
   */
  public getBasePage(): BasePage {
    return this.basePage;
  }

}
