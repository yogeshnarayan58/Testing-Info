import test from "@playwright/test";
import {
  findDataSetByName,
  getTestDataByLocale,
} from "../../../common/utils/helper-service";
import { config } from "../../../playwright/config";
import devTestData from "./test-data/dev-test-data.json";
import localizationData from "./test-data/localization-data.json";
import assertionData from "./assertion-data/assertion-data.json";
import { BasePageFactory } from "../../../common/utils/base-page-factory";
import { DataSelector } from "../../../common/components/data-selector/data-selector";
import { CommonTestCase } from "../../../common/pages/common-test-case/common-test-case";
import { LandingPage } from "../../../common/pages/landing-page/landing-page";
import { ChooseAtemplatePage } from "../../../common/pages/choose-a-template-page/choose-a-template-page";
import { QuickLookPage } from "../../../common/pages/quick-look-page/quick-look-page";
import { assert } from "@gfk/gta";
import { RUN_TEST_TIMEOUT } from "../../../constants/time-out-constants";
import { Snapshot } from "../../../common/pages/snapshot-page/snapshot-page";
import { ExportComponent } from "../../../common/components/export/export";


const reportTestData = findDataSetByName(devTestData, config.DATASET);
const localeData = getTestDataByLocale(config.LOCALE, localizationData as any);
let reportUrl = config.BASE_URL + reportTestData?.navUrlWithDataSetId;
let savedReportTitle: string = "";
let savedReportUrl: string = "";


  test.describe("Panel Preview Template validation", async () => {
    let dataSelector: DataSelector;
    let commonTestCase: CommonTestCase;

    test.beforeAll(() => {
        const isValidTestData = reportTestData;
        if (!isValidTestData) {
          console.warn('Skipping Panel Preview Template tests as the test data is not present');
        }
        test.skip(!isValidTestData, 'Skipping Panel Preview Template tests as the test data is not present');
      });

    test(
      "QuickLook: Should display correct preview information when template is selected",
      {
        tag: "@QuickLook",
      },
      async () => {
        let basePage = await BasePageFactory.createBasePage();
        let landingPage = new LandingPage(basePage);
        await landingPage.navigateToUrl(config.BASE_URL + "/reports-templates?tab=ALL_TEMPLATES");
        let chooseAtemplatePage = new ChooseAtemplatePage(
          landingPage.getBasePage()
        );
        await chooseAtemplatePage.clickSearchIconAndEnterText(localeData.title);
        await chooseAtemplatePage.hoverThumbnailBySrc(
          devTestData.common.thumbnailSrc
        );
        await chooseAtemplatePage.clickQuickLookInfoButton();
        let quickLookPage = new QuickLookPage(
          chooseAtemplatePage.getBasePage()
        );
        const previewDescriptionValue = await quickLookPage.getPreviewDescription();
        assert(previewDescriptionValue).toBe(localeData.description);       
        const previewDatasetsValue = await quickLookPage.getPreviewDatasets();
        assertionData.common.dataSets.forEach((expectedDataset: string) => {
          assert(previewDatasetsValue).toContain(expectedDataset);
        });
      }
    );
    test(
          "Madlib Validation: Should validate madlib text content matches expected pattern",
          {
            tag: "@MadlibValidation",
          },
          async () => {
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);
    
            if (localeData.madlibText) {
    
              const actualMadlibText = await dataSelector.getMadlibText();
              console.log("Actual Madlib Text:", actualMadlibText);
              console.log("Expected Pattern:", localeData.madlibText);
    
              assert(actualMadlibText).toMatch(
                new RegExp(localeData.madlibText, "i")
              );
    
              console.log(
                " Madlib validation passed for locale:",
                localeData.locale
              );
            } else {
              console.warn(
                `No madlib text pattern defined for locale: ${localeData.locale}`
              );
            }
          }
        );

    test.describe.serial(
      "Run, PPT Export, Excel Export",
      { tag: ["@Report_E2E_Flow"] },
      () => {
        test(
          "Report Generation: Validates dimension selection and successful execution",
          {
            tag: "@RunReport",
          },
          async () => {
            test.setTimeout(RUN_TEST_TIMEOUT);
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(reportUrl);            
            let commonBasePage = commonTestCase.getBasePage();
            dataSelector = new DataSelector(commonBasePage);

            await dataSelector.clickAdditionalPromptEllipsisIcon();

            await dataSelector.clickMadlibDimension("Facts");
            await dataSelector.multiSelectDropDown(
              reportTestData.dimensionSelections[0]["Facts"]["selections"]["value"]
            );            
            await dataSelector.clickMadlibDimension("blankSpace");

            await dataSelector.clickMadlibDimension("Geography");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Geography"]
            );

            await dataSelector.clickMadlibDimension("Periods");
            await dataSelector.setPeriodMadlibSelection(
              reportTestData.dimensionSelections[0]["Periods"]
            );

            await dataSelector.clickMadlibDimension("Demographic");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Demographic"]
            );

            await dataSelector.clickMadlibDimension("Products");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Products"]
            );

            await dataSelector.clickMadlibDimension("Retailer");
            await dataSelector.setMadlibSelection(
              reportTestData.dimensionSelections[0]["Retailer"]
            );

            // await dataSelector.clickMadlibDimension("People");
            // await dataSelector.clickMadlibDimension("peopleAddGroupButton");
            // await dataSelector.clickMadlibDimension("peopleAddGroupDropdown");
            // for (const selection of reportTestData.dimensionSelections[0]["People"].selections) {
            //   await dataSelector.handlePeopleMenuOptions(selection);
            // }

            let dsBasePage = await dataSelector.getBasePage();
            commonTestCase = new CommonTestCase(dsBasePage);
            await commonTestCase.clickRunButton();
            await commonTestCase.waitForReportRunCompletion();
            console.log("run complete in spec");
            const { newReportTitle, newUrl } = 
            await commonTestCase.saveReport();
             savedReportTitle = newReportTitle;
             savedReportUrl = newUrl;
             console.log("savedReportTitle:", savedReportTitle);
             console.log("savedReportUrl:", savedReportUrl);
          }
         
        );

        test(
          "Validate FullScreen",
          {
            tag: "@ValidateFullScreen",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping FullScreen - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.fullScreenView();
            // TODO: add assertions specific to full-screen behavior (report-specific checks)
          }
        );

        test(
          "Validate presentationMode",
          {
            tag: "@PresentationMode",
          },
          async () => {
            test.skip(!savedReportUrl, 'Skipping PresentationMode - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            await commonTestCase.presentationMode();
            // TODO: add assertions specific to presentation mode (report-specific checks)
          }
        );

        test("Validate snapshot", { tag: "@Snapshot" }, async () => {
          test.skip(!savedReportUrl, 'Skipping Snapshot - Report not generated. Run with @RunReport first or use @Report_E2E_Flow');

          let basePage = await BasePageFactory.createBasePage();
          const commonTestCase = new CommonTestCase(basePage);
          await commonTestCase.navigateToReportUrl(savedReportUrl);
          let snapshot: Snapshot = new Snapshot(commonTestCase.getBasePage());
          await snapshot.waitForReportRunCompletion();
          await snapshot.clickSaveIcon();
          await snapshot.clickSnapshotIcon();
          console.log('Snapshot clicked');
          assert(await snapshot.issuccessPopupVisible()).toBeTruthy();
          let snapshotUrl: string = await snapshot.shiftingToSnapshot();
          console.log('Snapshot shifted to right:', snapshotUrl);
          // TODO: add assertions specific to this report's snapshot (report-specific checks)
        });

        test(
          "Validate PPT export",
          {
            tag: "@ValidatePPTExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality("PowerPoint", "Editable objects", "Separately");
          }
        );

        test(
          "Validate Excel export",
          {
            tag: "@ValidateExcelExport",
          },
          async () => {
            let exportComponent: ExportComponent;
            let basePage = await BasePageFactory.createBasePage();
            commonTestCase = new CommonTestCase(basePage);
            await commonTestCase.navigateToReportUrl(savedReportUrl);
            let commonBasePage = await commonTestCase.getBasePage();
            exportComponent = new ExportComponent(commonBasePage);
            await exportComponent.validateExportFunctionality(
              "Excel",
              "Editable objects",
              "Separately"
            );
          }
        );
       
      }
    );
  });

