import { Component } from '@angular/core';
import type { ICellRendererAngularComp } from 'ag-grid-angular';
import type { ICellRendererParams } from 'ag-grid-community';
import type { QuestionRow, QuestionType } from '../question.model';

interface TypeMeta {
  label: string;
  className: string;
}

const TYPE_META: Record<QuestionType, TypeMeta> = {
  SINGLE_CHOICE: { label: 'Single Choice', className: 'badge-single' },
  MULTIPLE_CHOICE: { label: 'Multiple Choice', className: 'badge-multiple' },
  STAR_RATING: { label: 'Star Rating', className: 'badge-star' },
  NET_PROMOTER_SCORE: { label: 'NPS', className: 'badge-nps' },
  SINGLE_POINT_SCALE: { label: 'Point Scale', className: 'badge-point-scale' },
  MULTIPLE_POINT_SCALE: { label: 'Multi Point Scale', className: 'badge-multi-point-scale' },
};

/**
 * Renders the question `type` as a coloured badge/pill.
 */
@Component({
  selector: 'survey-type-badge-renderer',
  standalone: true,
  template: `
    @if (meta) {
      <span class="type-badge" [class]="meta.className">{{ meta.label }}</span>
    }
  `,
  styles: [`
    :host {
      display: flex;
      align-items: center;
      height: 100%;
    }
    .type-badge {
      display: inline-flex;
      align-items: center;
      padding: 3px 10px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 600;
      line-height: 1.4;
      white-space: nowrap;
    }
    .badge-single { background: #e0edff; color: #1d4ed8; }
    .badge-multiple { background: #e6f7ec; color: #15803d; }
    .badge-star { background: #fef3c7; color: #b45309; }
    .badge-nps { background: #ede9fe; color: #6d28d9; }
    .badge-point-scale { background: #fce7f3; color: #be185d; }
    .badge-multi-point-scale { background: #ffe4e6; color: #be123c; }
  `],
})
export class TypeBadgeRendererComponent implements ICellRendererAngularComp {
  meta: TypeMeta | null = null;

  agInit(params: ICellRendererParams<QuestionRow>): void {
    this.setState(params);
  }

  refresh(params: ICellRendererParams<QuestionRow>): boolean {
    this.setState(params);
    return true;
  }

  private setState(params: ICellRendererParams<QuestionRow>): void {
    const type = params.data?.question?.type;
    this.meta = type ? TYPE_META[type] : null;
  }
}
