import { test } from '@playwright/test';
import { BasePage } from '@gfk/gta';
import { BasePageFactory, closeBrowserAndAttachVideo } from '../../utils/base-page-factory';
import { StartFromScratchPage } from '../../page-objects/survey/start-from-scratch.page';
import { SelectPanelistPage } from '../../page-objects/common/select-panelist.page';
import { assertTrue } from '../../page-objects/common/assert-utils';
import testData from '../../test-data/dev-test-data.json';
import { MEDIUM_TIMEOUT, UI_STATE_UPDATE_DELAY } from '../../constants/timeout-constants';

const datasetNames = Object.keys(testData.datasets) as Array<keyof typeof testData.datasets>;
const DATASET_NAME = datasetNames[0];
const datasetConfig = testData.datasets[DATASET_NAME];

if (!datasetConfig) {
  throw new Error('No dataset found in dev-test-data.json');
}

const MIN_ELIGIBLE_COUNT = 100;
const RESPONSE_COUNT_OPTIONS = [100, 150, 200, 250, 300, 400, 500];
const CREDIT_RESPONSES = '100';
const REFRESHED_PREFIX = 'Last refreshed';
const TOO_FEW_PARTICIPANTS_MESSAGE =
  'Your current criteria returns too few eligible participants. Try expanding your selection (e.g., geography, demographics, or time frame) to increase your audience size';

test.describe('Select Panelists - Product Offering modal', { tag: '@SelectPanelist' }, () => {
  let basePage: BasePage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'select-panelist-modal-video');
    }
  });

  test('TC_SP_03: Cancelling the Product Offering modal applies no dataset', { tag: '@SPModalCancel' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    const surveyPage = new StartFromScratchPage(basePage);
    const selectPanelistPage = new SelectPanelistPage(basePage);

    await surveyPage.navigateToSurvey();
    await surveyPage.clickStartFromScratch();
    assertTrue(await surveyPage.isProductOfferingModalVisible(), 'Product Offering modal not visible after clicking Start from scratch');

    await surveyPage.cancelProductOfferingModal();
    assertTrue(!(await surveyPage.isProductOfferingModalVisible()), 'Product Offering modal still visible after clicking Cancel');

    const currentUrl = await surveyPage.getCurrentUrl();
    assertTrue(currentUrl.includes('select-panelist'), `Expected URL to contain "select-panelist" after cancelling, got "${currentUrl}"`);
    assertTrue(
      await selectPanelistPage.isSelectDatasetButtonVisible(),
      '"Select dataset" empty-state button not shown after cancelling the modal'
    );
    assertTrue(
      await selectPanelistPage.isSearchForPanelistsDisabledOrAbsent(),
      'Select Panelists screen ("Search for Panelists") should not be shown after cancelling the modal'
    );
  });
});

test.describe.serial('Select Panelists - filters and search', { tag: '@SelectPanelist' }, () => {
  let basePage: BasePage;
  let surveyPage: StartFromScratchPage;
  let selectPanelistPage: SelectPanelistPage;

  test.afterAll(async ({}, testInfo) => {
    if (basePage) {
      await closeBrowserAndAttachVideo(basePage, testInfo, 'select-panelist-video');
    }
  });

  test('Setup: Should land on the survey home page and start from scratch', { tag: '@SPSetup' }, async () => {
    basePage = await BasePageFactory.createBasePage();
    surveyPage = new StartFromScratchPage(basePage);

    await surveyPage.navigateToSurvey();
    assertTrue(await surveyPage.isStartFromScratchVisible(), '"Start from scratch" option not visible after navigating to survey');
    await surveyPage.clickStartFromScratch();
  });

  test('Setup: Should select the product offering and dataset and reach Select Panelists', { tag: '@SPSetup' }, async () => {
    await surveyPage.selectProductOffering('');
    const isDatasetSelectionConfirmed = await surveyPage.searchAndSelectDataset(datasetConfig.searchTerm, String(DATASET_NAME));
    assertTrue(isDatasetSelectionConfirmed, `Expected "Choose a dataset" confirmation not visible after selecting ${DATASET_NAME}`);

    await surveyPage.proceedToNextAfterDatasetSelection();
    await surveyPage.applyEntireDataset();

    selectPanelistPage = new SelectPanelistPage(basePage);
    assertTrue(await selectPanelistPage.isFooterRefreshedVisible(), 'Select Panelists screen not loaded after applying the dataset view');
  });

  test('TC_SP_05: All 5 filters are shown correctly in the summary sentence', { tag: '@SPSummary' }, async () => {
    const selections = datasetConfig.dimensionSelections;
    assertTrue(selections.length === 5, `Expected 5 dimension selections in test data, got ${selections.length}`);

    // Already-matching dimensions are skipped, so this only fills in whatever is not yet set.
    await selectPanelistPage.setDimensionSelections(selections);

    for (const selection of selections) {
      const actual = await selectPanelistPage.getDimensionTileValue(selection.dimensionTab);
      for (const item of selection.items) {
        assertTrue(
          actual.toLowerCase().includes(item.toLowerCase()),
          `Dimension "${selection.dimensionTab}": expected summary to show "${item}", got "${actual}"`
        );
      }
    }
  });

  test('TC_SP_04: Footer shows the source, dataset and view with a "Last refreshed" date', { tag: '@SPFooter' }, async () => {
    const { source, dataset, view } = await selectPanelistPage.getFooterParts();
    assertTrue(source.length > 0, 'Footer source is empty');
    assertTrue(dataset === String(DATASET_NAME), `Expected footer dataset "${DATASET_NAME}", got "${dataset}"`);
    assertTrue(view.length > 0, 'Footer view is empty');

    assertTrue(await selectPanelistPage.isFooterRefreshedVisible(), 'Footer "Last refreshed" is not visible');
    const refreshedText = await selectPanelistPage.getFooterRefreshedText();
    assertTrue(
      refreshedText.startsWith(REFRESHED_PREFIX),
      `Expected footer text to start with "${REFRESHED_PREFIX}", got "${refreshedText}"`
    );
  });

  test('TC_SP_07: Search for Panelists is enabled only when every filter has exactly 1 selection', { tag: '@SPSearchButton' }, async () => {
    const [product] = datasetConfig.dimensionSelections;
    assertTrue(
      await selectPanelistPage.isSearchForPanelistsEnabled(),
      'Search for Panelists should be enabled with 1 item in every filter'
    );

    await selectPanelistPage.removeDimensionSelectionItem(product.dimensionTab);
    assertTrue(
      await selectPanelistPage.isSearchForPanelistsDisabledOrAbsent(),
      'Search for Panelists should be disabled with 0 Product items'
    );

    await selectPanelistPage.setDimensionSelections([product]);
    assertTrue(await selectPanelistPage.isSearchForPanelistsEnabled(), 'Search for Panelists should be enabled with 1 Product item');
  });

  test('TC_SP_06: Filter validation banner and counter reflect the number of selected items', { tag: '@SPFilterValidation' }, async () => {
    const [product] = datasetConfig.dimensionSelections;
    const expectState = async (messageText: string, counter: RegExp, context: string) => {
      let lastMessage: string;
      let lastCounter: string;
      const deadline = Date.now() + MEDIUM_TIMEOUT;
      do {
        try {
          lastMessage = await selectPanelistPage.getFilterValidationMessage();
        } catch (error) {
          lastMessage = `<${error instanceof Error ? error.message : error}>`;
        }
        try {
          lastCounter = await selectPanelistPage.getFilterCounterText();
        } catch (error) {
          lastCounter = `<${error instanceof Error ? error.message : error}>`;
        }
        if (lastMessage.includes(messageText) && counter.test(lastCounter)) {
          return;
        }
        await basePage.getWebActions().delay(UI_STATE_UPDATE_DELAY);
      } while (Date.now() < deadline);
      assertTrue(
        false,
        `${context}: expected message "${messageText}" and counter ${counter} within ${MEDIUM_TIMEOUT}ms, last seen message "${lastMessage}", counter "${lastCounter}"`
      );
    };

    await selectPanelistPage.removeDimensionSelectionItem(product.dimensionTab);
    await expectState('Please select 1', /0\/1/, 'With 0 Product items');

    await selectPanelistPage.setDimensionSelections([product]);
    await expectState('Looking good!', /1\/1/, 'With 1 Product item');

    await selectPanelistPage.setDimensionSelections([{ ...product, items: [product.items[0], 'Automotive'] }]);
    await expectState('Please remove 1', /2\/1/, 'With 2 Product items');

    await selectPanelistPage.removeDimensionSelectionItem(product.dimensionTab);
    await selectPanelistPage.setDimensionSelections([product]);
    await expectState('Looking good!', /1\/1/, 'After restoring 1 Product item');
  });

  test('TC_SP_08: Search result shows eligible count, response options and credit message', { tag: '@SPSearchResult' }, async () => {
    await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);
    assertTrue(await selectPanelistPage.isSearchForPanelistsEnabled(), 'Search for Panelists should be enabled with all 5 filters set');

    await selectPanelistPage.clickSearchForPanelists();

    const eligibleCount = await selectPanelistPage.getEligibleCount();
    assertTrue(eligibleCount >= MIN_ELIGIBLE_COUNT, `Expected eligible count >= ${MIN_ELIGIBLE_COUNT}, got ${eligibleCount}`);

    // Options above the eligible count are not offered, so only those within it are expected.
    const expectedOptions = RESPONSE_COUNT_OPTIONS.filter((option) => option <= eligibleCount);
    for (const option of expectedOptions) {
      assertTrue(
        await selectPanelistPage.isResponseCountOptionVisible(option),
        `Response option ${option} not visible (eligible ${eligibleCount})`
      );
    }

    assertTrue(await selectPanelistPage.isMoreOptionsVisible(), '"+ More options" is not visible');

    const creditMessage = await selectPanelistPage.getResponsesCreditMessageText();
    assertTrue(creditMessage.length > 0, 'Credit message is empty');
    assertTrue(
      creditMessage.includes(CREDIT_RESPONSES) && /credit/i.test(creditMessage),
      `Expected credit message to contain "${CREDIT_RESPONSES}" and "credit", got "${creditMessage}"`
    );
  });

  test('TC_SP_11 - + More options shows additional response count choices', { tag: '@SPMoreOptions' }, async () => {
    const eligibleCount = await selectPanelistPage.getEligibleCount();
    const expectedOptions = RESPONSE_COUNT_OPTIONS.filter((option) => option <= eligibleCount);
    for (const option of expectedOptions) {
      assertTrue(
        await selectPanelistPage.isResponseCountOptionVisible(option),
        `Default response option ${option} not visible (eligible ${eligibleCount})`
      );
    }

    assertTrue(await selectPanelistPage.isMoreOptionsVisible(), '"+ More options" is not visible');
    const countBeforeMoreOptions = await selectPanelistPage.getVisibleResponseCountOptionsCount();

    await selectPanelistPage.clickMoreOptions();
    const countAfterMoreOptions = await selectPanelistPage.getVisibleResponseCountOptionsCount();

    const expectedExpandedCount = [...RESPONSE_COUNT_OPTIONS, 600, 700, 800, 900, 1000]
      .filter((option) => option <= eligibleCount).length;
    assertTrue(
      countAfterMoreOptions === expectedExpandedCount,
      `Expected ${expectedExpandedCount} visible response options after expansion (before: ${countBeforeMoreOptions}, eligible: ${eligibleCount}), got ${countAfterMoreOptions}`
    );

    await selectPanelistPage.clickFewerOptions();
  });

  test(
    'TC_SP_10 - selecting a response count enables Proceed, and changing a filter resets it',
    { tag: '@SPResponseCount' },
    async () => {
      const [product] = datasetConfig.dimensionSelections;

      await selectPanelistPage.moveMouseAwayFromResponseOptions();
      assertTrue(
        await selectPanelistPage.isProceedToSurveyBuilderDisabledOrAbsent(),
        'Proceed to survey builder should be disabled before a response count is selected'
      );

      await selectPanelistPage.clickResponseCountOption(RESPONSE_COUNT_OPTIONS[0]);
      assertTrue(
        await selectPanelistPage.isProceedToSurveyBuilderEnabled(),
        `Proceed to survey builder should be enabled after selecting ${RESPONSE_COUNT_OPTIONS[0]} responses`
      );

      await selectPanelistPage.removeDimensionSelectionItem(product.dimensionTab);
      await selectPanelistPage.setDimensionSelections([product]);
      assertTrue(await selectPanelistPage.isSearchForPanelistsEnabled(), 'Search for Panelists should be enabled with 1 Product item');
      await selectPanelistPage.clickSearchForPanelists();
      assertTrue(
        await selectPanelistPage.isResponseCountOptionVisible(RESPONSE_COUNT_OPTIONS[0]),
        'Expected response options to reappear after the updated panelist search'
      );

      const isResponseCountStillSelected = await selectPanelistPage.isAnyResponseCountSelected();
      assertTrue(!isResponseCountStillSelected, 'Expected no response count to remain selected after changing a filter');
      assertTrue(
        await selectPanelistPage.isProceedToSurveyBuilderDisabledOrAbsent(),
        'Proceed to survey builder should be disabled again after changing a filter'
      );
    }
  );

  test(
    'TC_SP_09: Too few eligible participants shows a message and blocks proceeding',
    { tag: '@SPTooFewParticipants' },
    async () => {
      const selections = datasetConfig.dimensionSelections.map((selection) =>
        selection.dimensionTab === 'retailerNoDataPrompt' ? { ...selection, items: ['Beauty Supply'] } : selection
      );
      await selectPanelistPage.setDimensionSelections(selections);

      try {
        assertTrue(
          await selectPanelistPage.isSearchForPanelistsEnabled(),
          'Search for Panelists should be enabled with all 5 filters set'
        );
        await selectPanelistPage.clickSearchForPanelists();

        const message = (await selectPanelistPage.getEligibilityMessageText()).replace(/\s+/g, ' ');
        assertTrue(
          message === TOO_FEW_PARTICIPANTS_MESSAGE,
          `Expected eligibility message "${TOO_FEW_PARTICIPANTS_MESSAGE}", got "${message}"`
        );

        const optionCount = await selectPanelistPage.getVisibleResponseCountOptionsCount();
        assertTrue(optionCount === 0, `Expected no response count options with too few participants, found ${optionCount}`);

        assertTrue(
          await selectPanelistPage.isProceedToSurveyBuilderDisabledOrAbsent(),
          'Proceed to survey builder should be disabled or absent with too few eligible participants'
        );
      } finally {
        await selectPanelistPage.setDimensionSelections(datasetConfig.dimensionSelections);
      }
    }
  );
});
