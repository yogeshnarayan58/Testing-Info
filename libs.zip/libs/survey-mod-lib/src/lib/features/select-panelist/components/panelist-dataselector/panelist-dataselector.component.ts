import { CdkScrollable } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, Component, Injector, OnDestroy, OnInit, afterNextRender, effect, inject, output } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { DimensionSelection, Prompt, ReportSpecObject } from '@nielsen/crf-common';
import { CrfDataSelectorPanelModuleV2, PromptErrorConfigService } from '@nielsen/crf-data-selector-panel-v2';
import { CrfDataSummaryModule, CrfDataSummaryService } from '@nielsen/crf-data-summary';
import { IdentityService } from '@nielsen/crf-lp-common';
import { DatasetService as CrfDatasetService, CrfRvCommonModule, DataSetType, PubSubEventEnum, ReDataSetConfig, pubSub } from '@nielsen/crf-rv-common';
import { ButtonModule } from '@nielseniq/athena-core';
import { EnvironmentConfig, ListCallDatasetService, PreferencesService } from '@nielseniq/crf-discover-fe-core';
import { cloneDeep } from 'lodash-es';
import { Subject, takeUntil } from 'rxjs';
import { SurveyCommonService } from '../../../../shared/services/survey-common.service';
import { buildDatasetDisplay } from '../../../../shared/utils/survey-dataset-display.util';
import { SurveyService } from '../../../build-survey/services/survey.service';
import { SurveyPanelistReportPayload, createSurveyPanelistReportPayload } from '../../models/report-payload.model';
import { mockValuesMultiCharPayload } from '../../models/requestInstance';
import { PanelistDatasetService } from '../../services/panelist-dataset.service';
import { RunReportService } from '../../services/run-report.service';
import { SelectPanelistUtilsService } from '../../utils.service';
import {
  dropDrillByContextFromSelectionChildren,
  getRestoredPrompts,
  getRestoredSelections,
  removeNullProperties,
  removePromptForSelection,
  resolveDatasetName,
} from './panelist-dataselector.util';
@Component({
  selector: 'panelist-dataselector',
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    ButtonModule,
    CdkScrollable,
    CrfDataSummaryModule,
    CrfDataSelectorPanelModuleV2,
    CrfRvCommonModule,
  ],
  templateUrl: './panelist-dataselector.component.html',
  styleUrl: './panelist-dataselector.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class PanelistDataselectorComponent implements OnInit, OnDestroy {
  public readonly environmentConfig = inject(EnvironmentConfig);
  private readonly translate = inject(TranslateService);
  private readonly identityService = inject(IdentityService);
  private readonly preferenceService = inject(PreferencesService);
  private readonly crfDatasetService = inject(CrfDatasetService);
  private readonly dataSummaryService = inject(CrfDataSummaryService);
  private readonly runReportService = inject(RunReportService);
  private readonly promptErrorService = inject(PromptErrorConfigService);
  readonly surveyCommonService = inject(SurveyCommonService);
  private readonly injector = inject(Injector);
  private readonly panelistDatasetService = inject(PanelistDatasetService);
  private readonly selectPanelistUtilsService = inject(SelectPanelistUtilsService);
  private readonly listCallDatasetService = inject(ListCallDatasetService);
  private readonly surveyService = inject(SurveyService);
  public readonly isLocal: boolean = !!this.environmentConfig?.local?.cookies;
  public datasetName: string = '';
  public componentId: string = '';
  public dataSelectorConfig: any;
  public currentPrompt: Prompt | undefined;
  public selections: DimensionSelection[] = [];
  public dataPrompts: Prompt[] = [];
  public apploaded = false;
  public applicationId = this.environmentConfig.appId;
  public showAdditionalPrompts = true;
  public isShowDsPanel = false;
  public runButtonState: string = 'hidden';
  public isFactAvailableInDataset: boolean = false;
  public isCheckingDataset: boolean = false;
  public showNoDatasetState: boolean = false;
  public panelDataPrompts: Prompt[] = [];
  protected readonly unSubscribe: Subject<void> = new Subject<void>();
  readonly datasetSelected = output<string>();
  panelToggled = output<boolean>();
  criteriaChanged = output<void>();
  reportPayload: SurveyPanelistReportPayload = createSurveyPanelistReportPayload({ jobId: '' });

  reportSpec = this.reportPayload.reportSpec as ReportSpecObject;
  public dataSetInfo: ReDataSetConfig | null = null;
  private isRestoringSelectorState = false;
  private isDatasetChanged = false;
  private hasRestoredInitialState = false;
  protected readonly dataSetTypes = [
    DataSetType.PANEL_OD_OMNI,
    DataSetType.PANEL_OD_HSCN,
  ];
  constructor() {
    this.dataSelectorConfig = this.environmentConfig.dataSelectorConfig;
  }

  ngOnInit(): void {
    pubSub.subscribe(
      PubSubEventEnum.OnCancelDataSet,
      () => {
        if (!this.datasetName) {
          this.showNoDatasetState = true;
        }
      },
      'PanelistDataselector'
    );
    pubSub.publish(PubSubEventEnum.OnDataSetTypesChange, this.dataSetTypes);
    pubSub.subscribe(
      PubSubEventEnum.OnDataSetChange,
      (config: ReDataSetConfig) => {
        this.afterDatasetChange(config);
      },
      'PanelistDataselector',
    );

    this.syncSelectorState();
    // Consolidated restore effect: waits for async cache hydration, then restores once.
    effect(() => {
      const cachedSelectorState = this.surveyCommonService.getPanelistDataSelectorState();
      const cachedDatasetConfig = this.surveyCommonService.getSelectedDatasetConfig();

      if (this.hasRestoredInitialState || this.datasetName) {
        return;
      }

      if (cachedSelectorState && this.selections.length === 0 && this.dataPrompts.length === 0) {
        this.syncSelectorState();
      }

      if (cachedDatasetConfig) {
        this.hasRestoredInitialState = !!this.datasetName;
      }
    }, { injector: this.injector });

    let lastTrigger = this.surveyCommonService.getDatasetPickerOpenTrigger();
    effect(() => {
      const trigger = this.surveyCommonService.getDatasetPickerOpenTrigger();
      if (trigger === lastTrigger) {
        return;
      }
      lastTrigger = trigger;
      this.datasetPicker();
    }, { injector: this.injector });
    this.promptErrorService.errorConfigSubjectV2
      .pipe(takeUntil(this.unSubscribe))
      .subscribe((data: any) => {
        if (!this.selections || this.selections.length === 0) {
          this.runButtonState = 'disabled';
          return;
        }
        const isValid = data?.promptStatus === 'VALID';
        this.syncSelectorState({});
        this.runButtonState = isValid ? 'default' : 'disabled';
      });
   
    this.runReportService.reportCompleted$
      .pipe(takeUntil(this.unSubscribe))
      .subscribe((response) => {
        if (response) {
          this.runButtonState = 'hidden';
          this.currentPrompt = undefined;
        }
      });

    this.runReportService.stoprun
      .pipe(takeUntil(this.unSubscribe))
      .subscribe(() => {
        if (this.runButtonState === 'loading') {
          this.runButtonState = 'default';
        }
      });

    this.identityService.getUser().pipe(takeUntil(this.unSubscribe)).subscribe({
      next: (val) => {
        if (val) {
          this.preferenceService.setHomeStackId(val?.organization?.homeStackId);
          if (this.reportPayload.requestInstance) {
            this.reportPayload.requestInstance['attributes'] = { modelId: 'THL-F', userId: val?.userName };
          }
        }
        this.apploaded = true;
        const hasSurveyRouteContext = !!this.surveyService.currentSurveyId?.trim();
         if (!hasSurveyRouteContext && !this.surveyCommonService.getSelectedDatasetConfig() && !this.surveyCommonService.hasCompletedPanelistSearch()) {
          afterNextRender(() => this.datasetPicker(), { injector: this.injector });
        }
      },
      error: () => { this.apploaded = true; }
    });
  }

  /* Data summary */
  public onPromptClick(promptId: string): void {
    if (this.runButtonState === 'loading') {
      return;
    }
    this.isShowDsPanel = true;
    this.panelDataPrompts = this.dataPrompts;
    //this.currentPrompt = this.dataPrompts.find((el) => el.id === promptId);
	this.currentPrompt = removeNullProperties(
      this.dataPrompts.find((el) => el.id === promptId) as Record<string, unknown> | undefined
    ) as Prompt | undefined;
    this.panelToggled.emit(true);
    this.surveyCommonService.notifyPanelToggled(true);
  }

  /**
   * Keeps dataset switch handling atomic so stale selector criteria does not leak
   * across datasets while still preserving restore-mode behavior for draft reloads.
   *
   * @param datasetDetails Dataset metadata selected from the picker.
   * @returns void
   */
  public onUpdateDataset(datasetDetails: ReDataSetConfig): void {
    if (!datasetDetails?.id) {
      return;
    }

    this.applyDatasetSharedContext(datasetDetails);
    this.resetCriteriaIfNeeded();

    this.dataSetInfo = datasetDetails;
    this.updateRequestInstanceDatasetContext(datasetDetails);

    this.datasetName = resolveDatasetName(datasetDetails);
    this.showNoDatasetState = false;
    this.componentId = "OMNI_THL_SURVEY_PANEL";
    this.currentPrompt = undefined;

    this.checkDatasetFactAvailability(datasetDetails);
    this.loadBaseReportSpec(datasetDetails);
    this.hidePanel();
    this.datasetSelected.emit(this.datasetName);
    this.surveyCommonService.notifyDatasetSelected(this.datasetName);
    this.syncSelectorState({} as any);
  }

  private applyDatasetSharedContext(datasetDetails: ReDataSetConfig): void {
    this.surveyCommonService.setDataViewId(datasetDetails.dataView?.dataViewId?.trim() || null);
    this.surveyCommonService.setSelectedDatasetConfig(datasetDetails);
  }

  private resetCriteriaIfNeeded(): void {
    const hasExistingCriteria = this.selections.length > 0 || this.dataPrompts.length > 0 || this.panelDataPrompts.length > 0;
    const hasCompletedSearch = this.surveyCommonService.hasCompletedPanelistSearch();

    if (this.isRestoringSelectorState || hasExistingCriteria || hasCompletedSearch) {
      return;
    }

    this.selections = [];
    this.dataPrompts = [];
    this.panelDataPrompts = [];
    this.runButtonState = 'disabled';
    this.criteriaChanged.emit();
    this.surveyCommonService.notifyCriteriaChanged();
  }

  private updateRequestInstanceDatasetContext(datasetDetails: ReDataSetConfig): void {
    if (!this.reportPayload.requestInstance) {
      return;
    }

    Object.assign(this.reportPayload.requestInstance, {
      datasetId: datasetDetails?.id,
      datasetLabel: datasetDetails?.title,
      dataViewId: datasetDetails?.dataView?.dataViewId,
      dataViewName: datasetDetails?.dataView?.dataViewName,
      locale: datasetDetails?.datasetDefaultLocale,
      datasetStackId: datasetDetails?.stackId,
      productOfferingCode: datasetDetails?.productOfferingCode,
    });
  }

  private checkDatasetFactAvailability(datasetDetails: ReDataSetConfig): void {
    this.isCheckingDataset = true;
    this.isFactAvailableInDataset = false;

    this.runReportService.triggerValuesMultiChar(mockValuesMultiCharPayload, datasetDetails)
      .pipe(takeUntil(this.unSubscribe))
      .subscribe((response: any) => {
        this.isFactAvailableInDataset = this.selectPanelistUtilsService.checkFactInDataset(mockValuesMultiCharPayload, response);
        this.isCheckingDataset = false;
      });
  }

  private setDatasetInfo(config: ReDataSetConfig) {
    const dataSetDetails = this.listCallDatasetService.getDatasetByIdRegion(config.id || '', config.stackId);
    config.title = dataSetDetails?.label;
    config.solution = dataSetDetails?.solution;
  
    const selectedDataset = buildDatasetDisplay(config);
    const refreshedDate = this.selectPanelistUtilsService.refreshedOnDate(config.refreshedOn);
    this.surveyCommonService.setSelectedDatasetConfig(config);
    this.surveyCommonService.setSelectedDatasetDisplay(selectedDataset);
    this.surveyCommonService.setRefreshedDate(refreshedDate);
    this.onUpdateDataset(config);
     }

  /** Only react to picker-driven dataset events to prevent duplicate initialization from pub-sub emissions. */
   private afterDatasetChange(config: ReDataSetConfig) {
    if (!config) {
      return;
    }
    if (this.isDatasetChanged || !this.datasetName) {
      this.setDatasetInfo(config);
    }
    this.isDatasetChanged = false;
  }

  private datasetPicker() {
    this.isDatasetChanged = true;
    pubSub.publish(PubSubEventEnum.OnDataSetTypesChange, this.dataSetTypes);
    this.openDatasetPickerModal();
  }

  private loadBaseReportSpec(datasetDetails: any): void {
    this.panelistDatasetService.loadBaseReportSpec(datasetDetails, this.componentId)
      .pipe(takeUntil(this.unSubscribe))
      .subscribe((reportSpec: any) => {
        if (reportSpec) {
          this.reportPayload.reportSpec = reportSpec;
          this.reportSpec = reportSpec;
          this.syncSelectorState({ reportSpec });
        }
      });
  }

  hidePanel() {
    this.isShowDsPanel = false;
    this.currentPrompt = undefined;
    this.panelToggled.emit(false);
    this.surveyCommonService.notifyPanelToggled(false);
  }

      updatePrompts(event: any): void {
    // if (this.isRestoringSelectorState) return;

    const hasExistingPromptData = this.dataPrompts.some((p: any) => (p?.promptData?.length ?? 0) > 0);
    const cachedState = this.surveyCommonService.getPanelistDataSelectorState();
    const hasCachedPromptData = (cachedState?.dataPrompts || []).some((p: any) => (p?.promptData?.length ?? 0) > 0);
    this.dataPrompts = removePromptForSelection(this.dataPrompts);

    if (!this.isShowDsPanel && (hasExistingPromptData || hasCachedPromptData)) {
      if (!hasExistingPromptData && hasCachedPromptData) {
        this.panelDataPrompts = this.dataPrompts;
        Object.assign(this.reportPayload.requestInstance, { prompts: this.dataPrompts });
      }
      return;
    }

    this.dataPrompts = removePromptForSelection(event);
    this.panelDataPrompts = event;
    Object.assign(this.reportPayload.requestInstance, { prompts: this.dataPrompts });
    this.syncSelectorState({} as any);
  }

  /** Selection updates always pass through merge and normalization to preserve non-edited prompt branches. */
  updateDataSelections(event: any): void {
    if (this.runButtonState === 'loading') {
      return;
    }
    if (this.isRestoringSelectorState) return;

    if (event?.fromCPF) {
      const hasExisting = this.selections.some((s: any) => (s?.children?.length ?? 0) > 0);
      const cachedState = this.surveyCommonService.getPanelistDataSelectorState();
      const hasCached = (cachedState?.selections || []).some((s: any) => (s?.children?.length ?? 0) > 0);
      if (hasExisting || hasCached) {
        this.selections = cloneDeep(hasExisting ? this.selections : cachedState.selections);
        this.selections = dropDrillByContextFromSelectionChildren(this.selections);
        this.panelDataPrompts = cloneDeep(this.dataPrompts);
        return;
      }
    }

    this.selections = this.surveyCommonService.mergeSelections(
      cloneDeep(event.selections) || [],
      this.selections,
      this.currentPrompt?.id
    );
    this.selections = dropDrillByContextFromSelectionChildren(this.selections);
    Object.assign(this.reportPayload.requestInstance, { dimensionSelections: this.selections });
    this.runButtonState = 'disabled';
    this.criteriaChanged.emit();
    this.surveyCommonService.notifyCriteriaChanged();
    this.handleDataSummary();
    this.syncSelectorState({} as any);
  }

  /** Data summary is derived from canonical selections to keep prompt chips and request payload in sync. */
  public handleDataSummary(): void {
    this.dataPrompts = this.dataSummaryService.preparePromptData(this.selections, cloneDeep(this.dataPrompts)) as any;
  
  }

  /** RequestInstance prompt mapping is centralized so publish/run payloads use identical prompt snapshots. */
  private assignPromptsToRequestInstance(): void {
    if (this.reportPayload.requestInstance) {
      Object.assign(this.reportPayload.requestInstance, { prompts: this.dataPrompts ?? [] });
    }
  }

  /** Sync to shared service allows build-survey flows to consume prompt labels without re-reading CPF state. */
  private syncPromptsToReportPayload(): void {
    this.assignPromptsToRequestInstance();
    this.surveyCommonService.setPanelistDimensionalValue(this.surveyCommonService.extractPromptSelectionLabels(this.dataPrompts));
  }
  
  /** Run action commits current selector payload and transitions run state atomically. */
  runDashboard() {
    if (this.runButtonState === 'default') {
      this.syncPromptsToReportPayload();
      this.runReportService.reportPayload = this.reportPayload;
      this.runButtonState = 'loading';
      this.hidePanel();
      this.runReportService.runReport();
    }
  }

 /** Open action clears transient no-dataset warning before invoking the picker modal. */
 openDatasetPicker(): void {
    this.showNoDatasetState = false;
    this.openDatasetPickerModal();
  }

  /** Picker modal is triggered through shared pub-sub so external selector module can own modal lifecycle. */
  private openDatasetPickerModal(): void {
    if (this.crfDatasetService.openDatasetPicker?.closed) {
      this.crfDatasetService.openDatasetPicker = new Subject<unknown>();
    }
    this.crfDatasetService.openDatasetPicker.next({
      getFromPreference: false,
      autoApply: false,
    });
    pubSub.publish(PubSubEventEnum.OpenDataSetModal, {});
  }

  /**
   * Centralizes persist/restore to keep selector state, report payload, and cached
   * draft hydration aligned, which prevents diverging state across navigation events.
   *
   * @param partialState Partial state to persist; when omitted, restores from cache.
   * @returns void
   */
  private syncSelectorState(partialState?: Partial<any>): void {
    if (partialState !== undefined) {
      this.persistSelectorState(partialState as any);
      return;
    }

    this.restoreSelectorState();
  }

  /** Persist writes a full snapshot so cross-route navigation can restore selector/report state deterministically. */
  private persistSelectorState(state: any): void {
    this.surveyCommonService.setPanelistDataSelectorState({
      datasetName: state.datasetName ?? this.datasetName,
      dataSetInfo: state.dataSetInfo ?? this.dataSetInfo,
      componentId: state.componentId ?? this.componentId,
      dataPrompts: state.dataPrompts ?? this.dataPrompts,
      panelDataPrompts: state.panelDataPrompts ?? this.panelDataPrompts,
      selections: state.selections ?? this.selections,
      isFactAvailableInDataset: state.isFactAvailableInDataset ?? this.isFactAvailableInDataset,
      requestInstance: state.requestInstance ?? this.reportPayload.requestInstance,
      reportSpec: state.reportSpec ?? this.reportPayload.reportSpec,
    });
  }

  /** Restore merges cached selector state back into report payload while preserving defaults for missing branches. */
  private restoreSelectorState(): void {
    const cachedState = this.surveyCommonService.getPanelistDataSelectorState();
    if (!cachedState) {
      return;
    }

    const hasCompletedSearch = this.surveyCommonService.hasCompletedPanelistSearch();
    const restoredReportSpec = cloneDeep(cachedState.reportSpec) ?? this.reportPayload.reportSpec;
    const restoredPrompts = getRestoredPrompts(cachedState);
    const restoredSelections = getRestoredSelections(cachedState);

    this.datasetName = cachedState.datasetName || this.datasetName;
    this.dataSetInfo = cachedState.dataSetInfo || this.dataSetInfo;
    this.componentId = cachedState.componentId || this.componentId;
    this.dataPrompts = restoredPrompts;
    if (hasCompletedSearch && this.dataPrompts.length > 0) {
      this.dataPrompts = this.dataPrompts.map((prompt) => ({
        ...prompt,
        validate: prompt?.validate === false ? true : prompt?.validate,
        isError: false,
      }));
      this.currentPrompt = undefined;
    }

    this.selections = restoredSelections;
	this.selections = dropDrillByContextFromSelectionChildren(this.selections);
    this.reportPayload.reportSpec = restoredReportSpec;
    this.reportSpec = restoredReportSpec;
    this.reportPayload.requestInstance = { ...this.reportPayload.requestInstance, ...cloneDeep(cachedState.requestInstance) };
    Object.assign(this.reportPayload.requestInstance, {
      prompts: this.dataPrompts,
      dimensionSelections: this.selections,
    });

    this.isFactAvailableInDataset = cachedState.isFactAvailableInDataset
      ?? (this.selections.length > 0 || this.dataPrompts.length > 0);
    this.syncPromptsToReportPayload();
    this.refreshSummaryAfterRestore();
  }

  /** Summary refresh is deferred via microtask so selector flags settle before downstream prompt listeners run. */
  private refreshSummaryAfterRestore(): void {
    if (this.selections.length === 0 && this.dataPrompts.length === 0) {
      return;
    }

    this.isRestoringSelectorState = true;
    this.handleDataSummary();
    this.panelDataPrompts = cloneDeep(this.dataPrompts);
    queueMicrotask(() => {
      this.isRestoringSelectorState = false;
    });
  }

  ngOnDestroy(): void {
    this.unSubscribe.next();
    this.unSubscribe.complete();
    pubSub.unsubscribe('PanelistDataselector');
  }
}
