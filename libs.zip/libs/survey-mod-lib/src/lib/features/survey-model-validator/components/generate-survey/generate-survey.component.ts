import { ChangeDetectionStrategy, Component, computed, DestroyRef, inject, OnInit, signal, ViewChild } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ButtonModule, DialogComponent, DialogModule, TextFieldModule } from '@nielseniq/athena-core';
import { finalize, map, Observable, take } from 'rxjs';
import { QuestionGeneratorComponent } from '../../../build-survey/components/question-generator/question-generator';
import {
  GenerateQuestionsRequest,
  GenerateSurveyPayload,
  QuestionModel,
  QuestionType,
  QuestionTypeOptions,
  QuestionTypes,
} from '../../../build-survey/models/build-survey';
import {
  GenerateAndValidateSurveyPayload,
  GenerateAndValidateSurveyResponse,
  ValidateSurveyPayload,
  ValidateSurveyQuestion,
  ValidateSurveyQuestionDraft,
  ValidateSurveyResponse,
  ValidationSuggestion,
  ValidationSuggestionDetails,
  ValidationResult,
} from '../../models/survey-model-validator.model';
import { SurveyModelValidatorService } from '../../services/survey-model-validator.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
interface WorkflowResultState {
  surveyTitle: string;
  questions: Array<QuestionModel | ValidateSurveyQuestion>;
  validation: ValidateSurveyResponse | null;
  localValidation: ValidationResult | null;
  responseJson: string;
}

interface GenerationExecutionResult {
  response: { result: QuestionModel[]; title?: string } | GenerateAndValidateSurveyResponse;
  validation: ValidateSurveyResponse | null;
  questions: Array<QuestionModel | ValidateSurveyQuestion>;
  title: string;
}

type SurveyActionTab = 'generate' | 'validate' | 'both';
type EditableQuestionField = 'question' | 'type' | 'isRequired' | 'npsLeftLabel' | 'npsRightLabel' | 'reviewRequired';

const BULK_QUESTION_TEMPLATES: Partial<Record<QuestionType, Omit<ValidateSurveyQuestion, 'id' | 'order' | 'reviewRequired'>>> = {
  [QuestionTypes.SingleChoice]: {
    question: 'Which product feature do you value most?',
    type: QuestionTypes.SingleChoice,
    options: ['Quality', 'Price', 'Design', 'Ease of use'],
    isRequired: true,
  },
  [QuestionTypes.MultipleChoice]: {
    question: 'Which of these brands have you purchased recently?',
    type: QuestionTypes.MultipleChoice,
    options: ['Brand A', 'Brand B', 'Brand C', 'Other'],
    isRequired: true,
  },
  [QuestionTypes.StarRating]: {
    question: 'How would you rate your overall experience?',
    type: QuestionTypes.StarRating,
    isRequired: true,
  },
  [QuestionTypes.NetPromoterScore]: {
    question: 'How likely are you to recommend us to a friend or colleague?',
    type: QuestionTypes.NetPromoterScore,
    npsLeftLabel: 'Not at all likely',
    npsRightLabel: 'Extremely likely',
    isRequired: true,
  },
  [QuestionTypes.SinglePointScale]: {
    question: 'How satisfied are you with each product feature?',
    type: QuestionTypes.SinglePointScale,
    rowOptions: ['Quality', 'Value', 'Packaging'],
    columnOptions: ['Very dissatisfied', 'Dissatisfied', 'Neutral', 'Satisfied', 'Very satisfied'],
    isRequired: true,
  },
  [QuestionTypes.MultiplePointScale]: {
    question: 'How often do you use each product feature?',
    type: QuestionTypes.MultiplePointScale,
    rowOptions: ['Feature A', 'Feature B', 'Feature C'],
    columnOptions: ['Never', 'Rarely', 'Sometimes', 'Often', 'Very often'],
    isRequired: false,
  },
};

/**
 * Internal QA tool: reuses the existing survey-question-generator component (question count +
 * question types) unmodified, projecting extra selection-context fields into its
 * `surveyGeneratorExtra` content slot. On (generate), independently triggers the generate-questions
 * AI flow with hand-entered context, then prints the raw response and runs it through
 * SurveyModelValidatorService so structural problems are surfaced without needing to walk the full
 * select-panelist/build-survey wizard. Does not read from or write to
 * SurveyService/SurveyCommonService shared state.
 */
@Component({
  selector: 'survey-generate-survey',
  standalone: true,
  imports: [TextFieldModule, ButtonModule, DialogModule, QuestionGeneratorComponent, NgTemplateOutlet, TranslateModule],
  templateUrl: './generate-survey.component.html',
  styleUrl: './generate-survey.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GenerateSurveyComponent implements OnInit {
  private readonly validatorService = inject(SurveyModelValidatorService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly translate = inject(TranslateService);
  private generationPromptEdited = false;
  private validationPromptEdited = false;

  @ViewChild(QuestionGeneratorComponent) private questionGenerator?: QuestionGeneratorComponent;

  readonly tabs = [
    { id: 'generate', label: 'Generate questions' },
    { id: 'validate', label: 'Validate questions' },
    { id: 'both', label: 'Generate + Validate questions' },
  ] as const;
  readonly questionTypeOptions = QuestionTypeOptions;
  readonly maxQuestionCount = 10;
  readonly activeTab = signal<SurveyActionTab>('generate');
  product = 'Food';
  retailer = 'Dollar store';
  demographic = 'Total Panel';
  geography = 'Total US';
  period = 'Cal Yr 2024 - w/e 12/28/24';
  surveyTitle = '';
  readonly generationSystemPrompt = signal('');
  readonly validationSystemPrompt = signal('');
  userPrompt = '';

  readonly isGenerating = signal(false);
  readonly isValidating = signal(false);
  readonly generateWorkflowResult = signal<WorkflowResultState | null>(null);
  readonly validateWorkflowResult = signal<WorkflowResultState | null>(null);
  readonly combinedWorkflowResult = signal<WorkflowResultState | null>(null);
  readonly errorMessage = signal<string | null>(null);
  readonly bulkQuestionDrafts = signal<ValidateSurveyQuestionDraft[]>([]);
  readonly bulkQuestionError = signal<string | null>(null);
  readonly bulkEntryMode = signal<'form' | 'json'>('form');
  readonly bulkJsonText = signal('');
  private readonly parsedBulkJson = computed(() => this.parseBulkQuestionsJson(this.bulkJsonText()));
  @ViewChild('bulkQuestionDialog') private bulkQuestionDialog?: DialogComponent;
  readonly validationQuestions = signal<ValidateSurveyQuestion[]>([
    {
      id: 'q_1',
      order: 1,
      question: 'How would you rate the overall performance of the product?',
      type: 'SINGLE_CHOICE',
      options: ['Excellent', 'Good', 'Fair', 'Poor'],
      rowOptions: [],
      columnOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
      isRequired: true,
      reviewRequired: true,
    },
  ]);

  get isGenerationMode(): boolean {
    return this.activeTab() !== 'validate';
  }

  get showQuestionTypeControls(): boolean {
    return this.activeTab() !== 'validate';
  }

  get actionLabel(): string {
    return this.tabs.find((tab) => tab.id === this.activeTab())?.label ?? this.tabs[0].label;
  }

  get validationQuestionCount(): number {
    return this.validationQuestions().length;
  }

  get availableBulkQuestionSlots(): number {
    return Math.max(0, this.maxQuestionCount - this.validationQuestionCount);
  }

  get availableBulkDraftSlots(): number {
    return Math.max(0, this.maxQuestionCount - this.bulkQuestionDrafts().length);
  }

  get hasInvalidBulkQuestionDraft(): boolean {
    return this.bulkQuestionDrafts().some((question) => !question.question.trim());
  }

  get bulkJsonValidationError(): string | null {
    return this.parsedBulkJson().error;
  }

  get isBulkJsonImportDisabled(): boolean {
    return !this.bulkJsonText().trim() || this.bulkJsonValidationError !== null;
  }

  get isBulkQuestionTemplateDisabled(): boolean {
    const jsonText = this.bulkJsonText().trim();
    if (!jsonText) return false;
    const { questions, error } = this.parsedBulkJson();
    return error !== null || (questions?.length ?? 0) >= this.maxQuestionCount;
  }

  get systemPrompt() {
    return this.activeTab() === 'validate' ? this.validationSystemPrompt : this.generationSystemPrompt;
  }

  get isActionDisabled(): boolean {
    if (this.isGenerating() || this.isValidating()) return true;
    if (this.activeTab() === 'validate') {
      return this.validatePanelistCriteria() !== null || this.validateQuestionEditor(this.validationQuestions()) !== null;
    }
    const count = this.questionGenerator?.questionCount ?? 5;
    return this.validateGenerationInputs() !== null || !Number.isInteger(count) || count < 1 || count > this.maxQuestionCount;
  }

  ngOnInit(): void {
    this.validatorService.extractPrompts().pipe(
      take(1),
      takeUntilDestroyed(this.destroyRef),
    ).subscribe({
      next: ({ generateQuestionSystemPrompt, validateSurveySystemPrompt }) => {
        if (!this.generationPromptEdited) this.generationSystemPrompt.set(generateQuestionSystemPrompt ?? '');
        if (!this.validationPromptEdited) this.validationSystemPrompt.set(validateSurveySystemPrompt ?? '');
      },
      error: () => {
        this.errorMessage.set('Failed to load the system prompt. You can enter it manually.');
      },
    });
  }

  onTabChange(value: string | number): void {
    if (this.isGenerating() || this.isValidating()) return;
    if (value !== 'generate' && value !== 'validate' && value !== 'both') return;

    this.activeTab.set(value);
    this.errorMessage.set(null);
  }

  typeLabel(type: string | undefined): string {
    const label = this.questionTypeOptions.find((option) => option.value === type)?.label;
    return label ? this.translate.instant(label) : (type ?? this.translate.instant('SURVEYMOD_QUESTION'));
  }

  suggestionDetails(suggestion: ValidationSuggestion): ValidationSuggestionDetails {
    return typeof suggestion === 'string' ? { issue: suggestion } : suggestion;
  }

  formatSuggestionLabel(value: string): string {
    return value
      .split('_')
      .map((part) => part.charAt(0) + part.slice(1).toLowerCase())
      .join(' ');
  }

  getValidationForQuestion(
    result: WorkflowResultState,
    question: QuestionModel | ValidateSurveyQuestion,
    index: number,
  ): ValidateSurveyResponse['result'][number] | undefined {
    const { id: expectedId, order } = this.normalizeQuestionIdentity(question, index);
    const validationResults = result.validation?.result ?? [];
    return validationResults.find((validation) => validation.id?.trim() === expectedId)
      ?? validationResults.find((validation) => !validation.id?.trim() && validation.order === order);
  }

  questionOrder(question: QuestionModel | ValidateSurveyQuestion, index: number): number {
    return this.normalizeQuestionIdentity(question, index).order;
  }

  statusCount(result: WorkflowResultState, status: 'APPROVED' | 'NEEDS_MANDATORY_CHANGES'): number {
    return result.validation?.result.filter((question) => question.status === status).length ?? 0;
  }

  reviewedCount(result: WorkflowResultState): number {
    return result.validation?.result.filter((question) => question.status !== undefined).length ?? 0;
  }

  unreviewedCount(result: WorkflowResultState): number {
    return Math.max(0, result.questions.length - this.reviewedCount(result));
  }

  isQuestionReviewRequired(question: QuestionModel | ValidateSurveyQuestion): boolean {
    return !('reviewRequired' in question) || question.reviewRequired !== false;
  }

  onSystemPromptChange(value: string): void {
    if (this.activeTab() === 'validate') {
      this.onValidationSystemPromptChange(value);
    } else {
      this.generationPromptEdited = true;
      this.generationSystemPrompt.set(value);
    }
  }

  onValidationSystemPromptChange(value: string): void {
    this.validationPromptEdited = true;
    this.validationSystemPrompt.set(value);
  }

  onProductChange(value: string | number): void {
    this.product = String(value ?? '');
  }

  onRetailerChange(value: string | number): void {
    this.retailer = String(value ?? '');
  }

  onDemographicChange(value: string | number): void {
    this.demographic = String(value ?? '');
  }

  onGeographyChange(value: string | number): void {
    this.geography = String(value ?? '');
  }

  onPeriodChange(value: string | number): void {
    this.period = String(value ?? '');
  }

  onUserPromptChange(value: string | number): void {
    this.userPrompt = String(value ?? '');
  }

  onSurveyTitleChange(value: string | number): void {
    this.surveyTitle = String(value ?? '');
  }

  onAction(): void {
    if (this.isActionDisabled) return;

    if (this.activeTab() === 'validate') {
      this.onValidateQuestions();
      return;
    }

    this.questionGenerator?.onGenerateQuestions();
  }

  addValidationQuestion(): void {
    const questions = this.validationQuestions();
    if (questions.length >= this.maxQuestionCount) {
      return;
    }

    const nextNumber = questions.length + 1;
    this.validationQuestions.set([...questions, this.createEmptyValidationQuestion(nextNumber)]);
  }

  openBulkQuestionDialog(): void {
    const existingQuestions = this.validationQuestions().map((question) => ({
      ...question,
      options: question.options ? [...question.options] : undefined,
      rowOptions: question.rowOptions ? [...question.rowOptions] : undefined,
      columnOptions: question.columnOptions ? [...question.columnOptions] : undefined,
    }));
    this.bulkQuestionDrafts.set(existingQuestions.length ? existingQuestions : [this.createEmptyBulkQuestionDraft()]);
    this.bulkQuestionError.set(null);
    this.bulkEntryMode.set('form');
    this.bulkJsonText.set('');
    this.bulkQuestionDialog?.open?.();
  }

  closeBulkQuestionDialog(): void {
    this.bulkQuestionDialog?.close?.();
    this.bulkQuestionDrafts.set([]);
    this.bulkQuestionError.set(null);
    this.bulkEntryMode.set('form');
    this.bulkJsonText.set('');
  }

  toggleBulkEntryMode(): void {
    if (this.bulkEntryMode() === 'form') {
      this.bulkJsonText.set(this.serializeBulkQuestionDrafts());
      this.bulkEntryMode.set('json');
    } else {
      const { questions, error } = this.parsedBulkJson();
      if (error || !questions) {
        this.bulkQuestionError.set(error ?? 'JSON must be a non-empty array of questions.');
        return;
      }
      this.bulkQuestionDrafts.set(questions);
      this.bulkEntryMode.set('form');
    }
    this.bulkQuestionError.set(null);
  }

  private serializeBulkQuestionDrafts(): string {
    return this.serializeBulkQuestions(this.bulkQuestionDrafts());
  }

  private serializeBulkQuestions(questions: ValidateSurveyQuestionDraft[]): string {
    const serializedQuestions = questions.map((question) => {
      const serialized: Record<string, unknown> = {
        question: question.question,
        type: question.type,
        isRequired: question.isRequired ?? false,
      };
      if (question.options?.length) serialized['options'] = question.options;
      if (question.rowOptions?.length) serialized['rowOptions'] = question.rowOptions;
      if (question.columnOptions?.length) serialized['columnOptions'] = question.columnOptions;
      if (question.npsLeftLabel) serialized['npsLeftLabel'] = question.npsLeftLabel;
      if (question.npsRightLabel) serialized['npsRightLabel'] = question.npsRightLabel;
      return serialized;
    });
    return JSON.stringify(serializedQuestions, null, 2);
  }

  addBulkQuestionTemplate(type: string): void {
    const { questions, error } = this.parsedBulkJson();
    if (error) {
      this.bulkQuestionError.set(error);
      return;
    }
    const questionType = this.questionTypeOptions.find((option) => option.value === type)?.value;
    if (!questionType) return;
    const template = BULK_QUESTION_TEMPLATES[questionType];
    if (!template) return;

    const existingQuestions = questions ?? [];
    if (existingQuestions.length >= this.maxQuestionCount) return;
    this.bulkJsonText.set(this.serializeBulkQuestions([
      ...existingQuestions,
      { ...template, reviewRequired: true },
    ]));
    this.bulkQuestionError.set(null);
  }

  onBulkQuestionTemplateChange(event: Event): void {
    const selector = event.currentTarget as HTMLSelectElement;
    const selectedType = selector.value;
    selector.value = '';
    this.addBulkQuestionTemplate(selectedType);
  }

  importBulkQuestionsFromJson(): void {
    const { questions, error } = this.parsedBulkJson();
    if (error || !questions) {
      this.bulkQuestionError.set(error);
      return;
    }

    this.bulkQuestionError.set(null);
    this.bulkQuestionDrafts.set(questions);
    this.commitBulkQuestions();
  }

  private parseBulkQuestionsJson(jsonText: string): { questions: ValidateSurveyQuestionDraft[] | null; error: string | null } {
    if (!jsonText.trim()) {
      return { questions: null, error: null };
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(jsonText);
    } catch {
      return { questions: null, error: 'Enter valid JSON containing an array of questions.' };
    }
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return { questions: null, error: 'JSON must be a non-empty array of questions.' };
    }
    if (parsed.length > this.maxQuestionCount) {
      return { questions: null, error: `JSON can contain up to ${this.maxQuestionCount} questions total.` };
    }

    const allowedFields = new Set([
      'question', 'type', 'options', 'rowOptions', 'columnOptions',
      'npsLeftLabel', 'npsRightLabel', 'isRequired',
    ]);
    const importedQuestions: ValidateSurveyQuestionDraft[] = [];
    for (const [index, value] of parsed.entries()) {
      const questionNumber = index + 1;
      if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        return { questions: null, error: `Question ${questionNumber} must be a JSON object.` };
      }
      const entry = value as Record<string, unknown>;
      const unsupportedField = Object.keys(entry).find((field) => !allowedFields.has(field));
      if (unsupportedField) {
        return { questions: null, error: `Question ${questionNumber} has unsupported field "${unsupportedField}".` };
      }
      if (typeof entry['question'] !== 'string' || !entry['question'].trim()) {
        return { questions: null, error: `Question ${questionNumber} needs question text.` };
      }
      if (typeof entry['type'] !== 'string' || !this.questionTypeOptions.some((option) => option.value === entry['type'])) {
        return { questions: null, error: `Question ${questionNumber} has an unsupported question type.` };
      }
      if (typeof entry['isRequired'] !== 'boolean') {
        return { questions: null, error: `Question ${questionNumber} must set "isRequired" to true or false.` };
      }

      const question: ValidateSurveyQuestionDraft = {
        question: entry['question'].trim(),
        type: entry['type'] as QuestionType,
        isRequired: entry['isRequired'],
        reviewRequired: true,
      };
      for (const field of ['options', 'rowOptions', 'columnOptions'] as const) {
        if (field in entry) {
          if (!Array.isArray(entry[field]) || !entry[field].every((item) => typeof item === 'string')) {
            return { questions: null, error: `Question ${questionNumber} field "${field}" must be an array of strings.` };
          }
          question[field] = (entry[field] as string[]).map((item) => item.trim()).filter(Boolean);
        }
      }
      for (const field of ['npsLeftLabel', 'npsRightLabel'] as const) {
        if (field in entry) {
          if (typeof entry[field] !== 'string') {
            return { questions: null, error: `Question ${questionNumber} field "${field}" must be text.` };
          }
          question[field] = (entry[field] as string).trim();
        }
      }
      importedQuestions.push(question);
    }
    return { questions: importedQuestions, error: null };
  }

  addBulkQuestionDraft(): void {
    if (this.availableBulkDraftSlots < 1) return;
    this.bulkQuestionDrafts.update((drafts) => [...drafts, this.createEmptyBulkQuestionDraft()]);
    this.bulkQuestionError.set(null);
  }

  removeBulkQuestionDraft(index: number): void {
    this.bulkQuestionDrafts.update((drafts) => drafts.filter((_, draftIndex) => draftIndex !== index));
    this.bulkQuestionError.set(null);
  }

  updateBulkQuestionDraft<Field extends EditableQuestionField>(
    index: number,
    field: Field,
    value: NonNullable<ValidateSurveyQuestionDraft[Field]>,
  ): void {
    this.bulkQuestionDrafts.update((drafts) =>
      drafts.map((question, questionIndex) =>
        questionIndex === index ? { ...question, [field]: value } : question,
      ),
    );
  }

  updateBulkQuestionDraftList(index: number, field: 'options' | 'rowOptions' | 'columnOptions', value: string): void {
    const values = value.split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
    this.bulkQuestionDrafts.update((drafts) =>
      drafts.map((question, questionIndex) =>
        questionIndex === index ? { ...question, [field]: values } : question,
      ),
    );
  }

  commitBulkQuestions(): void {
    const drafts = this.bulkQuestionDrafts();
    if (drafts.length < 1) {
      this.bulkQuestionError.set('Add at least one question.');
      return;
    }
    if (drafts.length > this.maxQuestionCount) {
      this.bulkQuestionError.set(`You can add up to ${this.maxQuestionCount} questions total.`);
      return;
    }
    const blankQuestionIndex = drafts.findIndex((question) => !question.question.trim());
    if (blankQuestionIndex !== -1) {
      this.bulkQuestionError.set(`Question ${blankQuestionIndex + 1} needs question text.`);
      return;
    }

    const questions = drafts.map((question, index) => ({
      ...question,
      id: `q_${index + 1}`,
      order: index + 1,
    }));
    this.validationQuestions.set(questions);
    this.closeBulkQuestionDialog();
  }

  private createEmptyValidationQuestion(order: number): ValidateSurveyQuestion {
    return {
      id: order > 0 ? `q_${order}` : '',
      order,
      question: '',
      type: 'SINGLE_CHOICE',
      options: [],
      rowOptions: [],
      columnOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
      isRequired: false,
      reviewRequired: true,
    };
  }

  private createEmptyBulkQuestionDraft(): ValidateSurveyQuestionDraft {
    return {
      question: '',
      type: 'SINGLE_CHOICE',
      options: [],
      rowOptions: [],
      columnOptions: [],
      npsLeftLabel: '',
      npsRightLabel: '',
      isRequired: false,
      reviewRequired: true,
    };
  }

  removeValidationQuestion(index: number): void {
    this.validationQuestions.set(
      this.validationQuestions()
        .filter((_, questionIndex) => questionIndex !== index)
        .map((question, questionIndex) => ({ ...question, id: `q_${questionIndex + 1}`, order: questionIndex + 1 })),
    );
  }

  updateValidationQuestion<Field extends EditableQuestionField>(
    index: number,
    field: Field,
    value: NonNullable<ValidateSurveyQuestion[Field]>,
  ): void {
    this.validationQuestions.update((questions) =>
      questions.map((question, questionIndex) =>
        questionIndex === index ? { ...question, [field]: value } : question,
      ),
    );
  }

  updateValidationQuestionList(index: number, field: 'options' | 'rowOptions' | 'columnOptions', value: string): void {
    const values = value.split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
    this.validationQuestions.update((questions) =>
      questions.map((question, questionIndex) =>
        questionIndex === index ? { ...question, [field]: values } : question,
      ),
    );
  }

  /** Handles the (generate) output emitted by the reused survey-question-generator component. */
  onGenerateQuestions(request: GenerateQuestionsRequest): void {
    if (this.isGenerating() || this.isValidating()) {
      return;
    }

    const validationError = this.validateGenerationInputs();
    if (validationError) {
      this.errorMessage.set(validationError);
      return;
    }

    if (!Number.isInteger(request.questionCount) || request.questionCount < 1 || request.questionCount > this.maxQuestionCount) {
      this.errorMessage.set(`Number of questions must be an integer between 1 and ${this.maxQuestionCount}.`);
      return;
    }

    const prompt = {
      demographic: this.demographic.trim(),
      geography: this.geography.trim(),
      period: this.period.trim(),
      product: this.product.trim(),
      questionCount: request.questionCount,
      questionTypes: request.questionTypes,
      retailer: this.retailer.trim(),
      userPrompt: this.userPrompt.trim(),
    };
    const generationSystemPrompt = this.generationSystemPrompt().trim();
    const validationSystemPrompt = this.validationSystemPrompt().trim();
    const payload: GenerateSurveyPayload = {
      prompt: {
        ...prompt,
        ...(generationSystemPrompt ? { systemPrompt: generationSystemPrompt } : {}),
      },
    };
    const { questionTypes, ...combinedPrompt } = prompt;
    const combinedPayload: GenerateAndValidateSurveyPayload = {
      prompt: {
        ...combinedPrompt,
        ...(questionTypes.length ? { questionTypes } : {}),
        generateQuestionSystemPrompt: generationSystemPrompt,
        validateSurveySystemPrompt: validationSystemPrompt,
      },
    };

    this.isGenerating.set(true);
    this.errorMessage.set(null);

    const runValidation = this.activeTab() === 'both';
    this.isValidating.set(runValidation);
    const response$: Observable<GenerationExecutionResult> = runValidation
      ? this.validatorService.generateAndValidateSurvey(combinedPayload).pipe(
        map((response): GenerationExecutionResult => ({
          response,
          validation: response,
          questions: response.result,
          title: response.title?.trim() ?? '',
        })),
      )
      : this.validatorService.generateQuestions(payload).pipe(
        map((response): GenerationExecutionResult => ({
          response,
          validation: null,
          questions: response?.result ?? [],
          title: response?.title?.trim() ?? '',
        })),
      );

    response$.pipe(
      map((result) => {
        if (result.questions.length > this.maxQuestionCount) {
          throw new Error(`The generator returned more than ${this.maxQuestionCount} questions.`);
        }
        const questionsForValidation = result.questions.map((question) => this.toQuestionModel(question));
        return { ...result, localValidation: this.validatorService.validateQuestions(questionsForValidation) };
      }),
      finalize(() => {
        this.isGenerating.set(false);
        this.isValidating.set(false);
      }),
    ).subscribe({
      next: ({ response, validation, questions, title, localValidation }) => {
        const state: WorkflowResultState = {
          surveyTitle: title,
          questions,
          validation,
          localValidation,
          responseJson: JSON.stringify(response, null, 2),
        };
        if (runValidation) this.combinedWorkflowResult.set(state);
        else this.generateWorkflowResult.set(state);
      },
      error: (error: unknown) => {
        const message = error instanceof Error ? error.message : 'Failed to generate or validate questions.';
        this.errorMessage.set(message);
      },
    });
  }

  onValidateQuestions(): void {
    if (this.isGenerating() || this.isValidating()) {
      return;
    }

    const contextError = this.validatePanelistCriteria();
    if (contextError) {
      this.errorMessage.set(contextError);
      return;
    }

    const questions = this.validationQuestions();
    const validationError = this.validateQuestionEditor(questions);
    if (validationError) {
      this.errorMessage.set(validationError);
      return;
    }

    const normalizedQuestions = questions.map((question, index) => this.normalizeQuestionIdentity(question, index));
    this.errorMessage.set(null);
    const reviewQuestions = normalizedQuestions.filter((question) => question.reviewRequired !== false);
    const localValidation = reviewQuestions.length
      ? this.validatorService.validateQuestions(reviewQuestions.map((question) => this.toQuestionModel(question)))
      : null;
    this.isValidating.set(true);

    this.validatorService.validateSurveyWithPrompt(this.buildValidationPayload(normalizedQuestions, this.surveyTitle)).pipe(
      finalize(() => this.isValidating.set(false)),
    ).subscribe({
      next: (response) => {
        this.validateWorkflowResult.set({
          surveyTitle: this.surveyTitle.trim(),
          questions: normalizedQuestions,
          validation: response,
          localValidation,
          responseJson: JSON.stringify(response, null, 2),
        });
      },
      error: (error: unknown) => {
        this.errorMessage.set(error instanceof Error ? error.message : 'Failed to validate questions.');
      },
    });
  }

  private validateQuestionEditor(questions: ValidateSurveyQuestion[]): string | null {
    if (questions.length < 1 || questions.length > this.maxQuestionCount) {
      return `Add between 1 and ${this.maxQuestionCount} questions to validate.`;
    }

    const ids = new Set<string>();
    const orders = new Set<number>();
    for (const [index, question] of questions.entries()) {
      if (!question.question.trim()) {
        return `Question ${index + 1} needs question text.`;
      }
      const id = question.id?.trim();
      if (!id) {
        return `Question ${index + 1} needs a question ID.`;
      }
      if (ids.has(id)) {
        return `Question IDs must be unique. Duplicate: ${id}.`;
      }
      ids.add(id);
      if (!Number.isInteger(question.order) || question.order < 1) {
        return `Question ${index + 1} needs a valid question order.`;
      }
      if (orders.has(question.order)) {
        return `Question orders must be unique. Duplicate: ${question.order}.`;
      }
      orders.add(question.order);
    }

    return null;
  }

  private validatePanelistCriteria(): string | null {
    const requiredFields: Array<[string, string]> = [
      ['product', this.product],
      ['retailer', this.retailer],
      ['demographic', this.demographic],
      ['geography', this.geography],
      ['period', this.period],
    ];
    const missingField = requiredFields.find(([, value]) => !value.trim());
    return missingField ? `${missingField[0]} is required.` : null;
  }

  private validateGenerationInputs(): string | null {
    const requiredFields: Array<[string, string]> = [
      ['userPrompt', this.userPrompt],
      ['product', this.product],
      ['retailer', this.retailer],
      ['geography', this.geography],
      ['demographic', this.demographic],
      ['period', this.period],
    ];
    if (this.activeTab() === 'both') {
      requiredFields.push(
        ['Generation system prompt', this.generationSystemPrompt()],
        ['Validation system prompt', this.validationSystemPrompt()],
      );
    }
    const missingField = requiredFields.find(([, value]) => !value.trim());
    return missingField ? `${missingField[0]} is required.` : null;
  }

  private buildValidationPayload(
    questions: Array<QuestionModel | ValidateSurveyQuestion>,
    surveyTitle: string,
    context: Pick<GenerateSurveyPayload['prompt'], 'product' | 'retailer' | 'geography' | 'demographic' | 'period' | 'userPrompt'> = {
      product: this.product.trim(),
      retailer: this.retailer.trim(),
      geography: this.geography.trim(),
      demographic: this.demographic.trim(),
      period: this.period.trim(),
      userPrompt: this.userPrompt.trim(),
    },
  ): ValidateSurveyPayload {
    const survey: ValidateSurveyPayload['survey'] = {
      questions: questions.map((question, index) => {
        const identity = this.normalizeQuestionIdentity(question, index);
        return {
          id: identity.id,
          order: identity.order,
          question: question.question.trim(),
          type: question.type as QuestionType,
          options: question.options ?? [],
          rowOptions: question.rowOptions ?? [],
          columnOptions: question.columnOptions ?? [],
          npsLeftLabel: question.npsLeftLabel ?? '',
          npsRightLabel: question.npsRightLabel ?? '',
          isRequired: question.isRequired ?? false,
          reviewRequired: 'reviewRequired' in question ? question.reviewRequired ?? true : true,
        };
      }),
    };

    const validationSystemPrompt = this.validationSystemPrompt().trim();
    if (validationSystemPrompt) survey.systemPrompt = validationSystemPrompt;
    if (surveyTitle.trim()) survey.surveyTitle = surveyTitle.trim();
    if (context.product.trim()) survey.product = context.product.trim();
    if (context.retailer.trim()) survey.retailer = context.retailer.trim();
    if (context.geography.trim()) survey.geography = context.geography.trim();
    if (context.demographic.trim()) survey.demographic = context.demographic.trim();
    if (context.period.trim()) survey.period = context.period.trim();
    if (context.userPrompt.trim()) survey.userPrompt = context.userPrompt.trim();

    return { survey };
  }

  private normalizeQuestionIdentity(
    question: QuestionModel | ValidateSurveyQuestion,
    index: number,
  ): ValidateSurveyQuestion {
    const sourceId = 'id' in question ? question.id : 'questionId' in question ? question.questionId : undefined;
    const sourceOrder = 'order' in question ? question.order : question.questionNumber;
    return {
      ...question,
      id: typeof sourceId === 'string' && sourceId.trim() ? sourceId.trim() : `q_${index + 1}`,
      order: typeof sourceOrder === 'number' && Number.isInteger(sourceOrder) && sourceOrder > 0
        ? sourceOrder
        : index + 1,
      question: question.question.trim(),
      type: question.type as QuestionType | undefined,
      isRequired: question.isRequired ?? false,
    };
  }

  private toQuestionModel(question: QuestionModel | ValidateSurveyQuestion): QuestionModel {
    return {
      question: question.question,
      type: question.type ?? '',
      isRequired: question.isRequired as QuestionModel['isRequired'],
      options: question.options,
      rowOptions: question.rowOptions,
      columnOptions: question.columnOptions,
      npsLeftLabel: question.npsLeftLabel,
      npsRightLabel: question.npsRightLabel,
      reviewRequired: question.reviewRequired,
    };
  }
}
